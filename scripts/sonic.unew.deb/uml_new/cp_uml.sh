#!/bin/bash

UML_LATEST=/sw/pub/release/uml/osp_uml_32

if [ ! -f ./root_fs ]; then
  echo "cp $UML_LATEST/root_fs ."
  cp $UML_LATEST/root_fs .

  echo "chmod -xw ./root_fs"
  chmod -xw ./root_fs
fi

exit 0
