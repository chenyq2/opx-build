#!/bin/bash

if [ $# != 2 ]; then
    echo "Usage: ./init-intf.sh cfgfile dutname"
    exit 1;
fi

cfgfile=$1
dutname=$2

# up interfaces
intnum=`cat $cfgfile | grep CLT_MAX_INTERFACES | awk '{print $3}'`
for ((i = 0; i <= $intnum; i++)) do
    ifconfig eth$i up mtu 1600 >/dev/null 2>&1
    ip address flush dev eth$i scope link >/dev/null 2>&1
done
#!/bin/bash

if [ $# != 2 ]; then
    echo "Usage: ./init-intf.sh cfgfile dutname"
    exit 1;
fi

cfgfile=$1
dutname=$2

# up interfaces
intnum=`cat $cfgfile | grep CLT_MAX_INTERFACES | awk '{print $3}'`
for ((i = 0; i <= $intnum; i++)) do
    ifconfig eth$i up mtu 1600 >/dev/null 2>&1
    ip address flush dev eth$i scope link >/dev/null 2>&1
done
