#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int main(int argc, char *argv[])
{
    int sk;
    struct ifreq ifr;
    struct sockaddr_in *sin;
    int ret;

    if (argc != 4)
    {
        fprintf(stderr, "Usage: umlcfg <dev> <addr> <port>\n");
        return -1;
    }

    sk = socket(PF_INET, SOCK_DGRAM, 0);

    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, argv[1]);

#if 0
    ret = ioctl(sk, SIOCGIFINDEX, &ifr);
    if (ret < 0)
    {
        fprintf(stderr, "%s: %s\n", argv[1], strerror(errno));
        return -1;
    }
#endif
    
    sin = (struct sockaddr_in *)&ifr.ifr_addr;
    sin->sin_family = AF_INET;
    sin->sin_addr.s_addr = inet_addr(argv[2]);
    sin->sin_port = htons(atoi(argv[3]));
    ret = ioctl(sk, SIOCDEVPRIVATE + 0xF, &ifr);

    if (ret < 0)
    {
        fprintf(stderr, "%s: %s\n", argv[1], strerror(errno));
        return -1;
    }

    return 0;
}
