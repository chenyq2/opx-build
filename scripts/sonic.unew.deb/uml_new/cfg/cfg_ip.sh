# !/bin/bash

#
# this script executed in uml environment
#

if [ $# != 3 ] && [ $# != 4 ]; then
    echo "Usage: ./cfg_ip.sh cfgfile name cur_dir [gen]"
    exit 1;
fi

cfgfile=$1
dutname=$2
curdir=$3

# get management interface name
manint=`cat $cfgfile | grep MAN_INTERFACE_DUT | awk '{ print $3}'`
if [ "$dutname" = "CTP" ]; then
    manint=`cat $cfgfile | grep MAN_INTERFACE_CTP | awk '{ print $3}'`
fi

if [ "$dutname" = "CLT" ]; then
    manint=`cat $cfgfile | grep MAN_INTERFACE_CLT | awk '{ print $3}'`
fi
if [ "$dutname" = "SRV" ]; then
    manint=`cat $cfgfile | grep MAN_INTERFACE_SRV | awk '{ print $3}'`
fi

IPADDR=""
get_man_ip_address()
{
    cfgfile="$1"
    name="$2"

    # Calc management ip address
    if [ $name = "CTP" ]; then
        IPADDR=`cat $cfgfile | grep CTP_M_ADDR | awk '{ print $3}'`
    elif [ $name = "CLT" ]; then
        IPADDR=`cat $cfgfile | grep CLT_M_ADDR | awk '{ print $3}'`
    elif [ $name = "SRV" ]; then
        IPADDR=`cat $cfgfile | grep SRV_M_ADDR | awk '{ print $3}'`
    else
        type=`echo $name | awk '{ split($0,a,"-"); print a[1]}'`
        if [ $type = "E300" ]; then
            sname=`echo $name | awk '{ split($0,a,"-"); print a[2]}'`
            BIPADDR=`cat $cfgfile | grep E300_M_BASE_ADDR | awk '{ print $3}'`
            idx=`expr substr $sname 4 1`
            idx=`expr $idx - 1`
            prefix=`echo $BIPADDR | awk '{ split($0,a,"." ); print a[1]"."a[2]"."a[3] }'`
            suffix=`echo $BIPADDR | awk '{ split($0,a,"." ); print a[4] }'`
            IPADDR=$prefix"."`expr $suffix + $idx`
        elif [ $type = "E800" ]; then
            stype=`echo $name | awk '{ split($0,a,"-"); print a[2]}'`
            sname=`echo $name | awk '{ split($0,a,"-"); print a[3]}'`
            BIPADDR=`cat $cfgfile | grep E800_M_BASE_ADDR | awk '{ print $3}'`
            prefix=`echo $BIPADDR | awk '{ split($0,a,"." ); print a[1]"."a[2]"."a[3] }'`
            suffix=`echo $BIPADDR | awk '{ split($0,a,"." ); print a[4] }'`
            if [ $stype = "DUT2" ]; then
                suffix=`expr $suffix + 20`
            elif [ $stype = "DUT3" ]; then
                suffix=`expr $suffix + 30`   
            elif [ $stype = "DUT4" ]; then
                suffix=`expr $suffix + 40`
            elif [ $stype = "DUT5" ]; then
                suffix=`expr $suffix + 50`
            elif [ $stype = "DUT6" ]; then
                suffix=`expr $suffix - 20`         
            fi
            nidx=`expr substr $sname 1 1`
            idx=`expr substr $sname 2 2`
            if [ $nidx = "L" ]; then
                idx=`expr $idx + 2`
            fi
            idx=`expr $idx - 1`
            IPADDR=$prefix"."`expr $suffix + $idx`
        else
            echo "WARNING: Invalid dut name"
            exit 1
        fi
    fi
    return 
}

set_inter_comm_ip()
{
    cfgfile="$1"
    name="$2"
    dir="$3"
    COMM_VRF=65

    icint=`cat $cfgfile | grep E800_INTERCOMM_INTERFACE | awk '{ print $3}'`
    if [ $name = "CTP" ] || [ $name = "CLT" ] || [ $name = "SRV" ]; then
        return
    fi

    type=`echo $name | awk '{ split($0,a,"-"); print a[1]}'`
    if [ $type = "E300" ]; then
        return
    fi
    
    ICADDR=""
    if [ $type = "E800" ]; then
        stype=`echo $name | awk '{ split($0,a,"-"); print a[2]}'`
        sname=`echo $name | awk '{ split($0,a,"-"); print a[3]}'`
        BIPADDR=`cat $cfgfile | grep E800_IC_BASE_ADDR | awk '{ print $3}'`
        prefix=`echo $BIPADDR | awk '{ split($0,a,"." ); print a[1]"."a[2] }'`
        suffix=`echo $BIPADDR | awk '{ split($0,a,"." ); print a[4] }'`
        nidx=`expr substr $sname 1 1`
        idx=`expr substr $sname 2 2`
        if [ $nidx = "L" ]; then
            idx=`expr $idx + 2`
            #return
        fi
        idx=`expr $idx - 1`
        ICADDR=$prefix"."`expr $suffix + $idx`".1"
    else
        echo "WARNING: Invalid dut name"
        exit 1
    fi

    SLOT_NO=`expr $suffix + $idx`;
    echo "Board Slot Number: $SLOT_NO"
    echo -n $SLOT_NO > /etc/slot_no

    if [ $type = "E800" ]; then
        if [ $sname = "S1" -o $sname = "S2" ]; then
            echo "Add the internal interface to special vrf"
            /centec_switch/sbin/busybox ip vrf add $COMM_VRF COMM_VRF
            /centec_switch/sbin/busybox ip link set $icint vrf $COMM_VRF
            /centec_switch/sbin/chvrf -n COMM_VRF /usr/sbin/in.tftpd -l -c -s /tftpboot &
        fi
    fi    
    

    echo "Configuration Inter-Communication IP Address for $name ..."
    #echo "chvrf `cat $cfgfile | grep VRF_IC_ID | awk '{print $3}'` ifconfig $icint $ICADDR/24 up"
    #chvrf `cat $cfgfile | grep VRF_IC_ID | awk '{print $3}'` ifconfig $icint $ICADDR/24 up
    echo "ifconfig $icint $ICADDR/16 up"
    if [ $type = "E800" ]; then
        if [ $sname = "S1" -o $sname = "S2" ]; then
            chvrf $COMM_VRF ifconfig $icint $ICADDR/16 up
    				chvrf $COMM_VRF sysctl -w net.ipv4.neigh.$icint.ucast_solicit=3
    				chvrf $COMM_VRF sysctl -w net.ipv4.neigh.$icint.mcast_solicit=3
    				chvrf $COMM_VRF sysctl -w net.ipv4.neigh.$icint.app_solicit=0
    	  else
            ifconfig $icint $ICADDR/16 up
    				sysctl -w net.ipv4.neigh.$icint.ucast_solicit=3
    				sysctl -w net.ipv4.neigh.$icint.mcast_solicit=3
    				sysctl -w net.ipv4.neigh.$icint.app_solicit=0
    		fi
    fi
    	  
    if [ $? != 0 ]; then
        echo -e "\nConfiguration inter-Communication IP Address for $name failed!"
        exit 1
    fi
    echo "Configuration inter-Communication IP Address for $name Done"

    richmondint=`cat $cfgfile | grep RICHMOND_COMM_INTERFACE | awk '{ print $3}'`
    ifconfig $richmondint 0.0.0.0 up
    sysctl -w net.ipv4.neigh.$richmondint.ucast_solicit=3
    sysctl -w net.ipv4.neigh.$richmondint.mcast_solicit=3
    sysctl -w net.ipv4.neigh.$richmondint.app_solicit=0
    return 
}

get_man_ip_address $cfgfile $dutname $curdir
if [ $# == 4 ]; then
    echo $IPADDR
    exit 0
fi

MANG_VRF=mgmt
echo "Configuration IP Address for $name ..."
if [ "$dutname" = "CTP" ] || [ "$dutname" = "CLT" ] || [ "$dutname" = "SRV" ]; then
    echo "ifconfig $manint $IPADDR/24 up"
    ifconfig $manint $IPADDR/24 up

    sysctl -w net.ipv4.neigh.$manint.ucast_solicit=3
    sysctl -w net.ipv4.neigh.$manint.mcast_solicit=3
    sysctl -w net.ipv4.neigh.$manint.app_solicit=0
else
    echo "ip link set $manint namespace $MANG_VRF"
    ip link set $manint netns $MANG_VRF

    echo "ip netns exec $MANG_VRF ifconfig $manint $IPADDR/24 up"
    ip netns exec $MANG_VRF ifconfig $manint $IPADDR/24 up

    echo "ip netns exec $MANG_VRF ifconfig lo 127.0.0.1 up"
    ip netns exec $MANG_VRF ifconfig lo 127.0.0.1 up

    ip netns exec $MANG_VRF sysctl -w net.ipv4.neigh.$manint.ucast_solicit=3
    ip netns exec $MANG_VRF sysctl -w net.ipv4.neigh.$manint.mcast_solicit=3
    ip netns exec $MANG_VRF sysctl -w net.ipv4.neigh.$manint.app_solicit=0
fi
echo "Configuration IP Address for $name Done"

set_inter_comm_ip $cfgfile $dutname $curdir
exit 0
