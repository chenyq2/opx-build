#!/bin/bash

if [ $# != 3 ]; then
    echo "Usage: ./pms-e800-s.sh cfgfile dutname imagepath"
    exit 1;
fi

cfgfile=$1
dutname=$2
imagepath=$3

echo "Centec Switch DUT Initialize..."
CTCOSDIR=/centec_switch
cp -fr $CTCOSDIR/etc/fea_cfg_metro_advanced /etc/fea_cfg

# line card binary packge
#rm -fr /tftpboot/lcimg.md5 /tftpboot/lcimg.tar.gz
#cp -fr $CTCOSDIR/lcpkg/lcimg.md5 /tftpboot/lcimg.md5
#cp -fr $CTCOSDIR/lcpkg/lcimg.tar.gz /tftpboot/lcimg.tar.gz
#chmod 777 /tftpboot/lcimg.*
#chown nobody:nobody /tftpboot/lcimg.*

# initialize syslog-ng configuration file
rm -fr /etc/syslog-ng.conf
$CTCOSDIR/sbin/init-syslog-ng.sh

# initialize ntpd configuration file
mkdir -p /etc/ntp
cp -fr $CTCOSDIR/etc/ntp.conf /etc/ntp.conf
cp -fr $CTCOSDIR/etc/ntpkeys.conf /etc/ntp/keys

# starting ntpd
COMM_VRF=65
NTP_PORT=124
echo "Start ntpd..."
$CTCOSDIR/sbin/ntpd -c /etc/ntp.conf -p /var/run/ntpd.pid -g
$CTCOSDIR/sbin/chvrf $COMM_VRF $CTCOSDIR/sbin/ntpd -c /etc/ntp.conf -p /var/run/ntpdvrf.pid -g -o $NTP_PORT

# make node for cmodel
mknod /dev/ctc_cmodel c 121 0
mknod /dev/ctc_memchk_one_page_shm c 111 0

# insert modules
echo "Insert kernel modules..."
insmod $CTCOSDIR/sbin/mpls.ko
#insmod $CTCOSDIR/sbin/baymemreg.ko
#insmod $CTCOSDIR/sbin/ctcx.ko master_dev_ifname=eth98
#insmod $CTCOSDIR/sbin/cmodel.ko

SLOT_NO=$(cat /etc/slot_no)
chvrf $COMM_VRF ifconfig eth100 down
ifconfig eth100 hw ether fe:fd:00:00:$SLOT_NO:00
chvrf $COMM_VRF ifconfig eth100 up

ifconfig eth98 down
ifconfig eth98 hw ether fe:fd:00:00:$SLOT_NO:00
ifconfig eth98 up

insmod $CTCOSDIR/sbin/peth_km.ko
insmod $CTCOSDIR/sbin/rmt.ko rmt_dev_name=eth100 rmt_dev_vrf_id=$COMM_VRF

$CTCOSDIR/sbin/hsrvd -d

#sleep 1s, then start chsm, else bug 9181 may happen
sleep 1

# start chsm
echo "Start chsm..."
$CTCOSDIR/sbin/chsm -n $CTCOSDIR/sbin/nsm 

# starting up syslog-ng
echo "Start syslog-ng..."
$CTCOSDIR/sbin/angel syslog-ng -Ff /etc/syslog-ng.conf

# setting logroate daily cron job
rm -fr $CTCOSDIR/sbin/crond
ln -s /usr/bin/busybox $CTCOSDIR/sbin/crond
mkdir -p /etc/crontabs
echo "59 23 */1 * * /centec_switch/sbin/dailyrotate.sh" > /etc/crontabs/root
echo "Start crond..."
$CTCOSDIR/sbin/crond -c /etc/crontabs

echo -n "Detect chassis type..."
while true; do
    if [ -f /tmp/ctcos_chassis_type ] ; then
        break;
    fi
    echo -n "."
    sleep 1;
done
echo "Done!"

# start PMs
PMLIST="ospfd ripd ospf6d ripngd bgpd onmd mstpd pimd pim6d lacpd imi authd ldpd ptpd rsvpd oamd ssmd"
for pmname in $PMLIST; do
    echo "Start $pmname..."
    $CTCOSDIR/sbin/$pmname -d
done

# starting dhcp relay
$CTCOSDIR/sbin/dhcrelay6 -d -q
$CTCOSDIR/sbin/dhcrelay6 -4 -d -q
 
# starting dhcp client
echo "Start dhclient..."
echo "" > /etc/dhclient.conf
$CTCOSDIR/sbin/dhclient

# start dhcp server
echo "Start dhcpd6..."
$CTCOSDIR/sbin/dhcpd6 -4 -q

echo "Start SNMPD..."
snmpd -c /centec_switch/etc/snmpd.conf

echo "Start SSHD..."
# kill old dropbear
killall sshd

# prepare sshd configuration files
rm -fr /etc/ssh
mkdir -p /etc/ssh
chmod 755 /etc/ssh
cp -fr /centec_switch/etc/ssh* /etc/ssh/
cp -fr /centec_switch/etc/moduli /etc/ssh/
chmod 600 /etc/ssh/*
mkdir -p /etc/ssh/keys
chmod 700 /etc/ssh/keys
mkdir -p /var/empty
chmod 755 /var/empty
SSHD_USR=`cat /etc/passwd | grep sshd`
if [ "$SSHD_USR" == "" ]; then
    echo "sshd:*:74:74:Privilege-separated SSH:/var/empty:/sbin/nologin" >> /etc/passwd
fi
sleep 1
/centec_switch/sbin/sshd

echo -n "Waiting system initialize."
while true; do
    if [ -f /tmp/imi_done ] ; then
        break;
    fi

    echo -n "."
    sleep 1;
done

echo

echo "Centec Switch System Initialize Done"

MANG_VRF=64
#echo "Starting telnetd..."
/centec_switch/sbin/chvrf $MANG_VRF /centec_switch/sbin/busybox telnetd -l /centec_switch/sbin/imish

echo "  Loading startup configuration file"
if [ ! -f /mnt/flash/startup-config.conf ] ; then
    touch /mnt/flash/startup-config.conf
fi
imish -s -f /mnt/flash/startup-config.conf

while true; do
    echo -n "."
    if [ -f /tmp/startup_cfg_done ] ; then
        break;
    elif [ -f /tmp/standby_startup_cfg_done ] ; then
        break;
    fi

    sleep 1;
done

echo 
echo "  Loading startup configuration done..."
echo "============================================="

# add by zhuj at 2011.01.06 for linux-2.6.32.23
# enlarge kernel neigh number
echo 512 > /proc/sys/net/ipv4/neigh/default/gc_thresh1
echo 2048 > /proc/sys/net/ipv4/neigh/default/gc_thresh2
echo 4096 > /proc/sys/net/ipv4/neigh/default/gc_thresh3

#echo "Startup cmodel"
#echo "enter cmodel" > /tmp/.cmodel.cfg
#echo "config sim enable usemem cmodel" >> /tmp/.cmodel.cfg
#/centec_switch/sbin/ctcli cmodel /tmp/aaa -f /tmp/.cmodel.cfg
