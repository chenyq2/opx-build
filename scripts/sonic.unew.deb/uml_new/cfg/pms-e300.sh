#!/bin/bash

if [ $# != 3 ]; then
    echo "Usage: ./pms-e300.sh cfgfile dutname imagepath"
    exit 1;
fi

cfgfile=$1
dutname=$2
imagepath=$3

export LD_LIBRARY_PATH=/centec_switch/lib

echo "Centec Switch DUT Initialize..."
OSPDIR=/centec_switch
rm -fr /tmp/fea_done

#cp -fr $OSPDIR/etc/fea_cfg_metro_advanced /etc/fea_cfg
#cp -fr $OSPDIR/etc/ShowIpeDiscardType.txt /tmp/ShowIpeDiscardType.txt
#cp -fr $OSPDIR/etc/ShowEpeDiscardType.txt /tmp/ShowEpeDiscardType.txt

# initialize syslog-ng configuration file
#rm -fr /etc/syslog-ng.conf
#$OSPDIR/sbin/init-syslog-ng.sh

# initialize code file structure
mkdir -p /mnt/flash/cold
mkdir -p /mnt/flash/cold/bak
mkdir -p /mnt/flash/cold/cmd
mkdir -p /mnt/flash/cold/log
mkdir -p /mnt/flash/cold/running
mkdir -p /var/empty/sshd
mkdir -p /var/run

#For openflow
OF_LOG_DIR=/tmp/openvswitch/var/log
OF_RUN_DIR=/tmp/openvswitch/var/run
OF_DB_DIR=/mnt/flash/openvswitch/etc/db

mkdir -p $OF_RUN_DIR
mkdir -p $OF_LOG_DIR
mkdir -p $OF_DB_DIR

cp -f /centec_switch/etc/mem_profile_hybrid_default.cfg /etc
cp -f /centec_switch/etc/mem_profile_default.cfg /etc
cp -f /centec_switch/etc/mem_profile_tap_default.cfg /etc


echo "copy new conf db to $OF_DB_DIR/conf.db"
cp -f /centec_switch/etc/openflow/conf.db $OF_DB_DIR/conf.db
# initialize ntpd configuration file
mkdir -p /etc/ntp
cp -fr $OSPDIR/etc/ntp.conf /etc/ntp.conf
cp -fr $OSPDIR/etc/ntpkeys.conf /etc/ntp/keys
# starting ntpd
echo "Start ntpd..."
$OSPDIR/sbin/ntpd -c /etc/ntp.conf -p /var/run/ntpd.pid -g
# kill dropbear sshd
killall sshd >/dev/null 2>&1

# prepare sshd configuration files
rm -fr /etc/ssh
mkdir -p /etc/ssh
chmod 755 /etc/ssh
cp -fr /centec_switch/etc/ssh/* /etc/ssh/
cp -fr /centec_switch/lib/security/pam_ctc.so /lib/security/
cp -fr /centec_switch/lib/lib*.so* /lib/ 2>&1 >/dev/null
chmod 600 /etc/ssh/*
mkdir -p /etc/ssh/keys
chmod 700 /etc/ssh/keys
mkdir -p /var/empty
chmod 755 /var/empty
SSHD_USR=`cat /etc/passwd | grep sshd`
if [ "$SSHD_USR" == "" ]; then
    echo "sshd:*:74:74:Privilege-separated SSH:/var/empty:/sbin/nologin" >> /etc/passwd
fi
cp -fr /centec_switch/etc/httpd.conf /centec_switch/etc/server.pem /etc
rm -fr /sbin/httpd
ln -s /centec_switch/sbin/lighttpd /sbin/httpd
rm -fr /var/www
ln -s /centec_switch/www /var/www
rm -fr /var/www/web_platform.py

# initialize diag log structure
mkdir -p /mnt/flash/info

# Init veth pair which is used for mgmt/default namespace port forwarding.
echo "Setup veth pair..."
source $OSPDIR/etc/init-veth.sh

# initialize syslog-ng configuration file
rm -fr /etc/syslog-ng.conf
$OSPDIR/sbin/init-syslog-ng.sh

# starting up syslog-ng
echo "Start syslog-ng..."
# start syslog-ng in foreground, otherwise we can not send the signal to
# it to change the timezone.
$OSPDIR/sbin/syslog-ng -Ff /etc/syslog-ng.conf &

# start snmp trap agent
/centec_switch/sbin/trap_agent -d

echo "Insert kernel modules..."

echo "Start PMs ..."
#$OSPDIR/sbin/zebra &
$OSPDIR/sbin/ccs &
$OSPDIR/sbin/cds &
sleep 2
$OSPDIR/sbin/switch &
$OSPDIR/sbin/opm &
$OSPDIR/sbin/routed &
$OSPDIR/sbin/appcfg &
$OSPDIR/sbin/ptp &
$OSPDIR/sbin/bhm &
$OSPDIR/sbin/dhcrelay -4 -d
echo "Start dhclient..."
echo "" > /etc/dhclient.conf
$OSPDIR/sbin/dhclient
$OSPDIR/sbin/dhcsnooping -d
$OSPDIR/sbin/authd -d
$OSPDIR/sbin/zebra -d
$OSPDIR/sbin/ospfd -d
$OSPDIR/sbin/ctctop &
# start openflow
$OSPDIR/sbin/ovsdb-server /mnt/flash/openvswitch/etc/db/conf.db \
    --remote=punix:/tmp/openvswitch/var/run/db.sock \
    --remote=db:Open_vSwitch,Open_vSwitch,manager_options \
    --pidfile=/tmp/openvswitch/var/run/ovsdb-server.pid \
    --unixctl=/tmp/openvswitch/var/run/ovsdb-server.ctl \
    --verbose=ANY:syslog:off &

$OSPDIR/sbin/ovs-vswitchd unix:/tmp/openvswitch/var/run/db.sock \
    --pidfile=/tmp/openvswitch/var/run/ovs-vswitchd.pid \
    --verbose=ANY:syslog:err &


sleep 2 
echo "Start chsm ..."
$OSPDIR/sbin/chsm &

echo "Waiting the fea initialize..."
$OSPDIR/sbin/fea & 
# waiting fea done
while true; do          
    if [ -f /tmp/fea_done ] ; then
        break;           
    fi                       
    echo -n "."          
    sleep 1;                
done

cdbctl update/cdb/sys/sys_global/init_done/1

echo "init done"
echo "Loading startup configuration file"
klish -q -s /mnt/flash/startup-config.conf

sleep 1
echo "Loading startup configuration done..."

MANG_VRF=64
#echo "Starting telnetd..."
ip netns exec mgmt /centec_switch/sbin/busybox telnetd -b :: -l /centec_switch/sbin/klish
ip netns exec default /centec_switch/sbin/busybox telnetd -b :: -l /centec_switch/sbin/klish

exit 0
