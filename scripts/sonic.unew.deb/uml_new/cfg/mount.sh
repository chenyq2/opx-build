# !/bin/bash

#
# this script executed in uml environment
#

if [ $# != 5 ]; then
    echo "Usage: ./mount.sh home prefix hostname dutname imagepath"
    exit 1;
fi

lcase () {
    echo -n $1|dd conv=lcase 2>/dev/null
}

homestr=$1
prefix=$2
hostname=$3
dutname=$4
imagepath=$5
name=`lcase $dutname`

if [[ $name == e800* ]]; then
prefixdir=../../$prefix
else
prefixdir=../$prefix
fi

mkdir -p /umlroot

echo "Mount local file system for $dutname ..."
# mount common directory
mount -t hostfs -o $homestr/$prefix none /umlroot
#mount -t hostfs -o $prefixdir none /umlroot

# prepare cf card and flash
mkdir -p /mnt/cf
mkdir -p /mnt/flash
mkdir -p /mnt/flash/boot
mkdir -p /mnt/infoexchange
mkdir -p /centec_switch
#mount -t hostfs -o $prefixdir/$name/cf none /mnt/cf
#mount -t hostfs -o $prefixdir/$name/flash none /mnt/flash
#mount -t hostfs -o $prefixdir/infoexchange none /mnt/infoexchange
mount -t hostfs -o $homestr/$prefix/$name/cf none /mnt/cf
mount -t hostfs -o $homestr/$prefix/$name/flash none /mnt/flash
mount -t hostfs -o $homestr/$prefix/$name/flash/boot none /mnt/flash/boot
mount -t hostfs -o $homestr/$prefix/infoexchange none /mnt/infoexchange
mount -t hostfs -o $imagepath none /centec_switch
#mkdir -p /ctcdata
#mount -t hostfs -o /ctcdata none /ctcdata

echo "Mount local file system for $dutname Done"
exit 0
