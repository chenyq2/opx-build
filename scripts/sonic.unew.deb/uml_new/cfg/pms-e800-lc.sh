#!/bin/bash

if [ $# != 3 ]; then
    echo "Usage: ./pms-e800-lc.sh cfgfile dutname imagepath"
    exit 1;
fi

cfgfile=$1
dutname=$2
imagepath=$3


echo "Centec Switch DUT Initialize..."
CTCOSDIR=/centec_switch
SLOT_NO=$(cat /etc/slot_no)

ifconfig eth100 hw ether fe:fd:00:00:$SLOT_NO:00
insmod $CTCOSDIR/sbin/rmt.ko rmt_dev_name=eth100

ifconfig eth96 down
ifconfig eth96 hw ether fe:fd:00:00:$SLOT_NO:01
ifconfig eth96 up
ifconfig eth97 down
ifconfig eth97 hw ether fe:fd:00:00:$SLOT_NO:02
ifconfig eth97 up

# starting up syslog-ng
echo "Start syslog..."
busybox klogd
busybox syslogd -O /mnt/flash/syslog -l 8 -s 1024 -b 14 -R 172.16.1.1 -L

# start PMs
PMLIST="lcd"
for pmname in $PMLIST; do
    echo "Start $pmname..."
    $CTCOSDIR/sbin/$pmname 
done

exit 0
