# !/bin/bash

#
# this script executed in uml environment
#

if [ $# != 2 ]; then
    echo "Usage: ./sysctl.sh cfgfile dutname"
    exit 1;
fi

cfgfile=$1
dutname=$2
manint=`cat $cfgfile | grep MAN_INTERFACE_DUT | awk '{ print $3}'`
if [ $dutname = "CTP" ]; then
    manint=`cat $cfgfile | grep MAN_INTERFACE_CTP | awk '{ print $3}'`
fi

if [ $dutname = "CLT" ]; then
    manint=`cat $cfgfile | grep MAN_INTERFACE_CLT | awk '{ print $3}'`
fi
    
if [ $dutname = "SRV" ]; then
    manint=`cat $cfgfile | grep MAN_INTERFACE_SRV | awk '{ print $3}'`
fi

if [ $dutname != "CTP" ] && [ $dutname != "CLT" ] && [ $dutname != "SRV" ]; then
    # for memory protect
    sysctl -w vm.overcommit_memory=2
    sysctl -w vm.overcommit_ratio=95
 
    #for icmp redirect, for bug 13190
    sysctl -w net.ipv4.conf.all.send_redirects=0
    
    # for ipv4/6 neigh
    sysctl -w net.ipv4.conf.default.force_igmp_version=2
    sysctl -w net.ipv4.conf.all.accept_source_route=1
    # disable kernel ARP
    sysctl -w net.ipv4.neigh.default.ucast_solicit=0
    sysctl -w net.ipv4.neigh.default.mcast_solicit=0
    sysctl -w net.ipv4.neigh.default.app_solicit=1
    sysctl -w net.ipv4.neigh.default.retrans_time_ms=3000
    sysctl -w net.ipv6.neigh.default.ucast_solicit=0
    sysctl -w net.ipv6.neigh.default.mcast_solicit=0
    sysctl -w net.ipv6.neigh.default.app_solicit=1
    sysctl -w net.ipv6.conf.default.dad_transmits=0
    sysctl -w net.ipv6.conf.all.dad_transmits=0
    sysctl -w net.ipv6.conf.all.router_solicitation_delay=0
    sysctl -w net.ipv6.conf.default.router_solicitation_delay=0
    sysctl -w net.ipv6.neigh.default.retrans_time_ms=3000
    sysctl -w net.ipv6.neigh.default.gc_thresh1=256
    sysctl -w net.ipv6.neigh.default.gc_thresh2=1024
    sysctl -w net.ipv6.neigh.default.gc_thresh3=2048
    sysctl -w net.ipv6.conf.default.disable_ipv6=1

    #enable 8192 entries for ARP
    sysctl -w net.ipv4.neigh.default.gc_thresh1=3072
    sysctl -w net.ipv4.neigh.default.gc_thresh2=12288
    sysctl -w net.ipv4.neigh.default.gc_thresh3=24576

    # Configure socket max memberships
    sysctl -w net.ipv4.igmp_max_memberships=1000 2>&1 > /dev/null
fi

# for syslog message lost :bug 18873, make burst message form 10 to 128
sysctl -w net.unix.max_dgram_qlen=128

# for coredump
sysctl -w kernel.core_pattern='/mnt/flash/%e.core'
sysctl -w net.core.rmem_max=32000000
sysctl -w net.core.rmem_default=4000000
sysctl -w net.core.wmem_max=32000000
sysctl -w net.core.wmem_default=4000000

# for new kernel
sysctl -w net.ipv4.conf.eth0.arp_ignore=1
sysctl -w net.ipv4.conf.eth1.arp_ignore=1
sysctl -w net.ipv4.conf.eth2.arp_ignore=1
sysctl -w net.ipv4.conf.eth3.arp_ignore=1
sysctl -w net.ipv4.conf.eth4.arp_ignore=1
sysctl -w net.ipv4.conf.eth5.arp_ignore=1
sysctl -w net.ipv4.conf.eth6.arp_ignore=1
sysctl -w net.ipv4.conf.eth7.arp_ignore=1
sysctl -w net.ipv4.conf.eth8.arp_ignore=1
sysctl -w net.ipv4.conf.eth9.arp_ignore=1
sysctl -w net.ipv4.conf.eth10.arp_ignore=1
sysctl -w net.ipv4.conf.eth11.arp_ignore=1
sysctl -w net.ipv4.conf.eth12.arp_ignore=1
sysctl -w net.ipv4.conf.eth13.arp_ignore=1
sysctl -w net.ipv4.conf.eth14.arp_ignore=1
sysctl -w net.ipv4.conf.eth15.arp_ignore=1
sysctl -w net.ipv4.conf.eth16.arp_ignore=1
sysctl -w net.ipv4.conf.eth17.arp_ignore=1
sysctl -w net.ipv4.conf.eth18.arp_ignore=1
sysctl -w net.ipv4.conf.eth19.arp_ignore=1
sysctl -w net.ipv4.conf.eth20.arp_ignore=1
sysctl -w net.ipv4.conf.eth21.arp_ignore=1
sysctl -w net.ipv4.conf.eth22.arp_ignore=1
sysctl -w net.ipv4.conf.eth23.arp_ignore=1
sysctl -w net.ipv4.conf.eth24.arp_ignore=1
sysctl -w net.ipv4.conf.eth25.arp_ignore=1
sysctl -w net.ipv4.conf.eth26.arp_ignore=1
sysctl -w net.ipv4.conf.eth27.arp_ignore=1
sysctl -w net.ipv4.conf.eth28.arp_ignore=1
sysctl -w net.ipv4.conf.eth29.arp_ignore=1
sysctl -w net.ipv4.conf.eth30.arp_ignore=1
sysctl -w net.ipv4.conf.eth31.arp_ignore=1
sysctl -w net.ipv4.conf.eth32.arp_ignore=1
sysctl -w net.ipv4.conf.eth33.arp_ignore=1
sysctl -w net.ipv4.conf.eth34.arp_ignore=1
sysctl -w net.ipv4.conf.eth35.arp_ignore=1
sysctl -w net.ipv4.conf.eth36.arp_ignore=1
sysctl -w net.ipv4.conf.eth37.arp_ignore=1
sysctl -w net.ipv4.conf.eth38.arp_ignore=1
sysctl -w net.ipv4.conf.eth39.arp_ignore=1
sysctl -w net.ipv4.conf.eth40.arp_ignore=1
sysctl -w net.ipv4.conf.eth41.arp_ignore=1
sysctl -w net.ipv4.conf.eth42.arp_ignore=1
sysctl -w net.ipv4.conf.eth43.arp_ignore=1
sysctl -w net.ipv4.conf.eth44.arp_ignore=1
sysctl -w net.ipv4.conf.eth45.arp_ignore=1
sysctl -w net.ipv4.conf.eth46.arp_ignore=1
sysctl -w net.ipv4.conf.eth47.arp_ignore=1
sysctl -w net.ipv4.conf.eth48.arp_ignore=1
sysctl -w net.ipv4.conf.eth49.arp_ignore=1
sysctl -w net.ipv4.conf.eth50.arp_ignore=1
sysctl -w net.ipv4.conf.eth51.arp_ignore=1
sysctl -w net.ipv4.conf.eth52.arp_ignore=1
sysctl -w net.ipv4.conf.eth53.arp_ignore=1
sysctl -w net.ipv4.conf.eth54.arp_ignore=1
sysctl -w net.ipv4.conf.eth55.arp_ignore=1
sysctl -w net.ipv4.conf.eth56.arp_ignore=1
sysctl -w net.ipv4.conf.eth57.arp_ignore=1
sysctl -w net.ipv4.conf.eth58.arp_ignore=1
sysctl -w net.ipv4.conf.eth59.arp_ignore=1
sysctl -w net.ipv4.conf.eth60.arp_ignore=1
sysctl -w net.ipv4.conf.eth61.arp_ignore=1
sysctl -w net.ipv4.conf.eth62.arp_ignore=1
sysctl -w net.ipv4.conf.eth63.arp_ignore=1
sysctl -w net.ipv4.conf.eth64.arp_ignore=1
sysctl -w net.ipv4.conf.eth65.arp_ignore=1
sysctl -w net.ipv4.conf.eth66.arp_ignore=1
sysctl -w net.ipv4.conf.eth67.arp_ignore=1
sysctl -w net.ipv4.conf.eth68.arp_ignore=1
sysctl -w net.ipv4.conf.eth69.arp_ignore=1
sysctl -w net.ipv4.conf.eth70.arp_ignore=1
sysctl -w net.ipv4.conf.eth71.arp_ignore=1
sysctl -w net.ipv4.conf.eth72.arp_ignore=1
sysctl -w net.ipv4.conf.eth73.arp_ignore=1
sysctl -w net.ipv4.conf.eth74.arp_ignore=1
sysctl -w net.ipv4.conf.eth75.arp_ignore=1
sysctl -w net.ipv4.conf.eth76.arp_ignore=1
sysctl -w net.ipv4.conf.eth77.arp_ignore=1
sysctl -w net.ipv4.conf.eth78.arp_ignore=1
sysctl -w net.ipv4.conf.eth79.arp_ignore=1
sysctl -w net.ipv4.conf.eth80.arp_ignore=1
sysctl -w net.ipv4.conf.eth81.arp_ignore=1
sysctl -w net.ipv4.conf.eth82.arp_ignore=1
sysctl -w net.ipv4.conf.eth83.arp_ignore=1
sysctl -w net.ipv4.conf.eth84.arp_ignore=1
sysctl -w net.ipv4.conf.eth85.arp_ignore=1
sysctl -w net.ipv4.conf.eth86.arp_ignore=1
sysctl -w net.ipv4.conf.eth87.arp_ignore=1
sysctl -w net.ipv4.conf.eth88.arp_ignore=1
sysctl -w net.ipv4.conf.eth89.arp_ignore=1
sysctl -w net.ipv4.conf.eth90.arp_ignore=1
sysctl -w net.ipv4.conf.eth91.arp_ignore=1
sysctl -w net.ipv4.conf.eth92.arp_ignore=1
sysctl -w net.ipv4.conf.eth93.arp_ignore=1
sysctl -w net.ipv4.conf.eth94.arp_ignore=1
sysctl -w net.ipv4.conf.eth95.arp_ignore=1

exit 0
