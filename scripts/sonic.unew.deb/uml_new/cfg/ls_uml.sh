#!/bin/bash

find ./|grep linux | awk '{ print "rm -fr "$0}'
find ./|grep root_fs | awk '{ print "rm -fr "$0}'
