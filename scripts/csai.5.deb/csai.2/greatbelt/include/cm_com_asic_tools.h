/****************************************************************************
 * cm_sim_asic_tools.h: store tools in each module and some emualtion board tools.
 *
 * Copyright: (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       ZhouW.
 * Date:         2010-09-20.
 * Reason:       Greatbelt First Create.
 ****************************************************************************/

#ifndef _CM_SIM_ASIC_TOOLS_H_
#define _CM_SIM_ASIC_TOOLS_H_
/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "cm_com_common.h"
#include "cm_ipe.h"

enum
{
    DS_QUE_LINK_LIST_BASE,
    FL_QUE_LINK_HEAD,
    FL_QUE_LINK_TAIL,
    FL_QUE_LINK_COUNTER,
    FL_BUF_STORE_BASE,
    FL_BUF_STORE_HEAD0,
    FL_BUF_STORE_TAIL0,
    FL_BUF_STORE_COUNTER0,
    FL_BUF_STORE_HEAD1,
    FL_BUF_STORE_TAIL1,
    FL_BUF_STORE_COUNTER1,
    FL_BUF_STORE_HEAD2,
    FL_BUF_STORE_TAIL2,
    FL_BUF_STORE_COUNTER2,
    FL_BUF_STORE_HEAD3,
    FL_BUF_STORE_TAIL3,
    FL_BUF_STORE_COUNTER3,
    FL_BUF_STORE_TABLE_CTRL_ADDR,
    FL_NET_RX_BASE,
    FL_NET_RX_HEAD,
    FL_NET_RX_TAIL,
    FL_NET_RX_COUNTER,
    FAB_VOQ_FREE_CELL_BASE,
    FAB_VOQ_FREE_CELL_HEAD,
    FAB_VOQ_FREE_CELL_TAIL,
    FAB_VOQ_FREE_CELL_CNT,
    MAX_ADDR_NUM
};

struct linklist
{
    uint32 base;
    uint32 head;
    uint32 tail;
    uint32 entry_size;
    uint32 np_offset;
    uint32 np_star_bit;
    uint32 np_end_bit;
    uint32 index_start;
    uint32 index_end;
    uint32 index_num;
    char  *desc;
};
typedef struct linklist link_list_t;

struct linklist_c
{
    uint32 base;
    uint32 head;
    uint32 tail;
    uint32 entry_size;
    uint32 np_offset;
    uint32 np_star_bit;
    uint32 np_end_bit;
    uint32 index_start;
    uint32 index_end;
    uint32 index_num;
	uint32 table_ctrl_addr;
    char  *desc;
};
typedef struct linklist_c link_list_c_t;

#define SIM_ASIC_MAX_PATH_LEN 256

struct sim_asic_store_file_name_s
{
    char ipe_inpkt_name[SIM_ASIC_MAX_PATH_LEN];
    char qmgt_inpkt_name[SIM_ASIC_MAX_PATH_LEN];
    char epe_inpkt_name[SIM_ASIC_MAX_PATH_LEN];
    char oam_inpkt_name[SIM_ASIC_MAX_PATH_LEN];
    char cpu_nettx_inpkt_name[SIM_ASIC_MAX_PATH_LEN];
    char cpu_netrx_inpkt_name[SIM_ASIC_MAX_PATH_LEN];
    char rx_pkt_cnt_name[SIM_ASIC_MAX_PATH_LEN];
    char tx_pkt_cnt_name[SIM_ASIC_MAX_PATH_LEN];
    char ipe_bhdr_input_name[SIM_ASIC_MAX_PATH_LEN];
    char epe_bhdr_input_name[SIM_ASIC_MAX_PATH_LEN];
    char macrx_input_name[SIM_ASIC_MAX_PATH_LEN];
    char mactx_output_name[SIM_ASIC_MAX_PATH_LEN];
    /* use for higig test (store higig header) */
    bool sghdr_tx_store_en;
    bool sghdr_mux_store_en;
    char sghdr_tx_outpkt_name[SIM_ASIC_MAX_PATH_LEN];
    char sghdr_mux_inpkt_name[SIM_ASIC_MAX_PATH_LEN];
};
typedef struct sim_asic_store_file_name_s sim_asic_store_file_name_t;

extern sim_asic_store_file_name_t store_file_name;

extern int32 sim_asic_ipe_inpkt(char *file_name);
extern int32 sim_asic_qmgt_inpkt(char *file_name);
extern int32 sim_asic_epe_inpkt(char *file_name);
extern int32 sim_asic_cpu_netrx_inpkt(char *file_name);
extern int32 sim_asic_oam_inpkt(char* file_name);
extern int32 sim_asic_bhdr_inpkt(char *file_name);
extern int32 sim_asic_epe_bhdr_inpkt(char *file_name);
extern int32 sim_asic_ipe_bhdr_inpkt(char *file_name);
extern int32 sim_asic_rx_pkt_cnt(char *file_name);
extern int32 sim_asic_tx_pkt_cnt(char *file_name);
extern int32 sim_asic_macrx_inpkt_filename(char *file_name);
extern int32 sim_asic_mactx_outpkt_filename(char *file_name);

extern int32 sim_asic_gen_ipe_inpkt(ipe_in_pkt_t *ipkt);
extern int32 sim_asic_gen_qmgt_inpkt(queue_in_pkt_t* qpkt);
extern int32 sim_asic_gen_epe_inpkt(epe_in_pkt_t* epkt);
extern int32 sim_asic_gen_cpu_netrx_inpkt(out_pkt_t* cpupkt);
extern int32 sim_asic_gen_oam_inpkt(oam_in_pkt_t* in_pkt);
extern int32 sim_asic_gen_epe_bhdr_inpkt(ms_packet_header_t *bheader);
extern int32 sim_asic_gen_ipe_bhdr_inpkt(ipe_in_pkt_t *ipkt);
extern int32 sim_asic_gen_rx_pkt_cnt(int32 *p_arr);
extern int32 sim_asic_gen_tx_pkt_cnt(int32 *p_arr);
extern int32 sim_asic_gen_macrx_inpkt(uint32 chipid_offset, uint8 *pkt, uint32 packet_length, uint32 mac_num);
extern int32 sim_asic_gen_mactx_outpkt(uint32 chipid, uint8 *pkt, uint32 packet_length, uint32 chanid);

extern int32 sim_asic_emu_check_integrity_gen_compare(uint8 chip_id, char *src_file,  char *dest_file);
extern int32 sim_asic_emu_check_integrity_gen_result(uint8 chip_id, char *src_file,  char *dest_file);

#endif
