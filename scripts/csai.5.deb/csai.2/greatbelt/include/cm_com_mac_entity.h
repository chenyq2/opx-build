/****************************************************************************
 * cm_com_mac_entity.h:  All packet type Deinfines.
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Revision:      V1.0.
 * Author:
 * Date:         2010-11-1.
 * Reason:       First Create.
 *
 * Modify History:
 ****************************************************************************/
#ifndef _CM_COM_MAC_ENTITY_H_
#define _CM_COM_MAC_ENTITY_H_

/****************************************************************************
 * Header Files
 *
 ****************************************************************************/
#include "cm_com_common.h"

/****************************************************************************
 * Defines and Macros
 *
 ****************************************************************************/
/* The mapping between the MacNumber and the ChannelId */
#define MIN_1G_MACNUM         0
#define MAX_1G_MACNUM         47
#define MIN_SG_MACNUM         48
#define MAX_SG_MACNUM         59
#define INTERLAKEN_MACNUM     61
#define I_LOOPBACK_MACNUM     I_LOOPBACK_CHANID
#define CPU_MACNUM            60
#define DMA_MACNUM            DMA_CHANID
#define OAM_MACNUM            OAM_CHANID
#define E_LOOPBACK_MACNUM     E_LOOPBACK_CHANID

/* �������PTP engine�ļ���оƬģ�� */
enum ptp_engine_access_module_e
{
    PTP_ENGINE_ACCESS_MAC_RX,
    PTP_ENGINE_ACCESS_MAC_TX,
    PTP_ENGINE_ACCESS_EPE_NEXTHOP,
    PTP_ENGINE_ACCESS_IPE_OAM,
};
typedef enum ptp_engine_access_module_e ptp_engine_access_module_t;

#if (SDK_WORK_PLATFORM==1)
extern int32
get_ptp_engine_timestamp(ptp_engine_access_module_t access_module, bool ns_format, uint32 *mbs, uint32 *lbs);

/* �ٵķ���PTP engine����ts�ӿ� */
#define GET_PTP_ENGINE_TIMESTAMP(access_module, ns_format, msb, lsb) \
do \
{ \
    int32 ret = get_ptp_engine_timestamp(access_module, ns_format, msb, lsb); \
    if (ret < 0) \
    { \
        CMODEL_DEBUG_OUT_INFO("ERROR!! Invalid chip module access PTP engine!! module name = %d\n", (access_module)); \
    } \
} \
while (0)
#else
#define GET_PTP_ENGINE_TIMESTAMP(access_module, ns_format, msb, lsb)
#endif
/****************************************************************************
 *
 * Global and Declarations
 *
 ***************************************************************************/

/****************************************************************************
 *
 * Functions
 *
***************************************************************************/
extern int32 sim_mac_install(uint32 chip_id_offset);

#endif

