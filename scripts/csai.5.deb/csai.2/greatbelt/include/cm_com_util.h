/****************************************************************************
 * cm_sim_util.h    Useful utility and const for ASIC C-Model.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Anchor Xie.
 * Date:         2010-07-11.
 * Reason:       First Create.
 ****************************************************************************/
#ifndef _CM_SIM_UTIL_H_
#define _CM_SIM_UTIL_H_

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "cm_com_common.h"
#include "ctcutil_pkt.h"
#include "cm_lib.h"
#include "cm_com_engine.h"

/****************************************************************************
 *
* Defines and Macros
*
****************************************************************************/

#define GET_TIMESTAMP31_0_IN_HEADER(p_header) \
    ((p_header->src_ctag_offset_type_u.timestamp_31 << 31) \
     | (p_header->ttl_u.timestamp_30_23 << 23) \
     | (p_header->rxtx_fcl_22_17_u.timestamp_22_17 << 17) \
     | (p_header->src_cvlan_id_valid_u.timestamp_16 << 16) \
     | (p_header->src_cvlan_id_u.timestamp_15_4 << 4) \
     | (p_header->rxtx_fcl3_u.timestamp_3 << 3) \
     | (p_header->rxtx_fcl2_1_u.timestamp_2_1 << 1) \
     | (p_header->rxtx_fcl0_u.timestamp_0))

#define GET_TIMESTAMP61_32_IN_HEADER(p_header) \
    ((p_header->fid_u.share3.timestamp_61_48 << 16) \
    | (p_header->logic_src_port_u.timestamp_47_32))

#define SET_TIMESTAMP31_0_IN_HEADER(p_header,timestamp31_0) \
    do \
    { \
        uint32 time_stamp_tmp = timestamp31_0; \
        p_header->src_ctag_offset_type_u.timestamp_31 = (time_stamp_tmp >> 31) & 0x1; \
        p_header->ttl_u.timestamp_30_23 = (time_stamp_tmp >> 23) & 0xFF; \
        p_header->rxtx_fcl_22_17_u.timestamp_22_17 = (time_stamp_tmp >> 17) & 0x3F; \
        p_header->src_cvlan_id_valid_u.timestamp_16 = (time_stamp_tmp >> 16) & 0x1; \
        p_header->src_cvlan_id_u.timestamp_15_4 = (time_stamp_tmp >> 4) & 0xFFF; \
        p_header->rxtx_fcl3_u.timestamp_3 = (time_stamp_tmp >> 3) & 0x1; \
        p_header->rxtx_fcl2_1_u.timestamp_2_1 = (time_stamp_tmp >> 1) & 0x3; \
        p_header->rxtx_fcl0_u.timestamp_0 = time_stamp_tmp & 0x1; \
    } \
    while (0);

#define SET_TIMESTAMP61_32_IN_HEADER(p_header,timestamp61_32) \
    do \
    { \
        uint32 time_stamp_tmp = timestamp61_32; \
        p_header->fid_u.share3.timestamp_61_48 =  (time_stamp_tmp >> 16) & 0xFFFF; \
        p_header->logic_src_port_u.timestamp_47_32 = time_stamp_tmp & 0xFFFF; \
    } \
    while (0);

struct store_pkt
{
    uint32 pkt_id;
    uint32 rcd;
    uint8 *packet;
};
typedef struct store_pkt store_pkt_t;

/* use for check cmodel module discard type */
enum
{
    DISCARD_CHECK_IPE_MODULE,
    DISCARD_CHECK_EPE_MODULE,
};

/* define driver allocation construct on cmodel UML testing */
struct per_chip_allocate_status_s
{
    /*----- tcam allocation use ---*/
    uint32 cur_inner_ddr_alloc_entry_num;
    uint32 cur_ext_ddr_alloc_entry_num;
    uint32 cur_inner_tcam_alloc_entry_num;
    uint32 cur_ext_tcam_alloc_entry_num;

    /* record the used block number */
    uint32 blk_cnt;

    /* Record QDR current allocated entry number */
    uint32 cur_qdr_ram_alloc_entry_num;

    /* Record Vlan share memory current allocated entry number */
    uint32 cur_vlan_share_mem_alloc_entry_num;

    /* Hash key allocation's information*/
    uint32 cur_hash_key_alloc_entry_num;
    bool hash_key_in_48k;

    bool initialized;
};
typedef struct per_chip_allocate_status_s per_chip_allocate_status_t;

/* whole packet compare, check ip/tcp/udp checksum control */
struct chk_checksum_flag_s
{
    bool ignore_ip_checksum;
    bool ignore_tcp_checksum;
    bool ignore_udp_checksum;
};
typedef struct chk_checksum_flag_s chk_checksum_flag_t;

/* whole packet compare, check ipv4/ipv6/udp total length */
struct chk_total_length_flag_s
{
    bool ignore_ipv4_total_length;
    bool ignore_ipv6_total_length;
    bool ignore_udp_total_length;
};
typedef struct chk_total_length_flag_s chk_total_length_flag_t;

enum rsv_channel_type_s
{
    /* channel */
    RSV_CHAN_TYPE_INTLK_CHAN,
    RSV_CHAN_TYPE_ILOOP_CHAN,
    RSV_CHAN_TYPE_CPU_CHAN,
    RSV_CHAN_TYPE_DMA_CHAN,
    RSV_CHAN_TYPE_OAM_CHAN,
    RSV_CHAN_TYPE_ELOOP_CHAN,

    DRV_CHAN_TYPE_MAX
};
typedef enum rsv_channel_type_s rsv_channel_type_t;

/****************************************************************************
 *
* Global and Declarations
*
****************************************************************************/
/****************************************************************************
 *
* Functions
*
***************************************************************************/
extern int32
sim_store_outpkt_filename(char *file_name);

extern int32
sim_output_packet(uint8 *packet, uint32 packet_length, uint8 chip_id, uint32 channel);

extern int32
sim_oam_create_output(oam_in_pkt_t* oam_pkt, list_head_t* out_pkt);

extern int32
sim_oam_mallocate_memory(oam_in_pkt_t* oam_pkt);

extern int32
sim_oam_free_memory(oam_in_pkt_t* oam_pkt);

extern int32
sim_oam_output_packet(uint8 *packet, uint32 packet_length, uint8 chip_id, uint32 chan);

extern int32
sim_ipe_create_output(ipe_in_pkt_t *in_pkt, list_head_t *out_pkt_list);

extern int32
sim_ipe_mallocate_memory(ipe_in_pkt_t *npkt);

extern int32
sim_ipe_free_memory(ipe_in_pkt_t *ipkt);

extern int32
sim_qmgt_mallocate_memory(queue_in_pkt_t *qpkt);

extern int32
sim_qmgt_free_memory(queue_in_pkt_t *qpkt);

extern int32
sim_epe_mallocate_memory(epe_in_pkt_t *epkt);

extern int32
sim_epe_free_memory(epe_in_pkt_t* epkt);

extern int32
sim_epe_create_output(epe_in_pkt_t *in_pkt, queue_in_pkt_t *out_pkt);

/** @brief cmodel cli use to do each share table(dsvlan and dsvlanstatus) allocation process*/
extern int32
sim_alloc_vlan_share_mem_allocate_proc(uint32* tbl_id, uint32* entry_num);

/**
 @brief cmodel cli use to show each tcam key allocation result process
*/
extern int32
sim_alloc_tcam_alloc_show_proc(void);

/**
 @brief cmodel cli use to creat check discard result file
*/
extern int32
sim_discard_check_file(char *file_name);

/**
 @brief cmodel cli use to check discard type
*/
extern int32
sim_check_discard_type(uint32 chipid, uint32 moduleid, uint32 discard_type, bool is_pkt_cnt, uint32 cnt);

/**
 @brief cmodel cli use to creat check all discard is null result file
*/
extern int32
sim_creat_check_no_any_discard_result_file(char *file_name);

/**
 @brief cmodel cli use to check discard type is NULL
*/
extern int32
sim_check_all_discard_type_is_null(uint32 chipid);

/**
 @brief cmodel cli use to creat check table is NULL result file
*/
extern int32
sim_check_table_is_null_result_file(char *file_name);


extern int32
sim_check_table_is_null(uint32 chip_id, tbls_id_t tbl_id);

/**
 @brief cmodel cli use to flush the table's all memory (set 0)
*/
extern int32
sim_flush_table(uint32 chip_id, tbls_id_t tbl_id);

extern void
sim_cmodel_debug_show_discard(ctc_cmodel_debug_module_t module, uint8 discard_type);

extern void
sim_cmodel_debug_show_tcam_tbl(tbls_id_t tcam_tbl_id, uint8 found_flag, uint32 index);

extern void
sim_cmodel_debug_show_hash_tbl(tbls_id_t debug_table_id, fib_key_type_t hash_type, uint8 found_flag, uint32 key_index);


extern uint32
sim_get_channel(uint32 chip_id, rsv_channel_type_t type);

#if 0
/**
 @brief cmodel cli use to check discard type
*/
extern void
sim_store_discard_type(uint32 moduleid, uint32 discard_type);
#endif

/**
 @brief cmodel use to convert between greatbelt header from networks and cmodel using header structure.
*/
extern void cm_gen_greatbelt_packet_header(ms_packet_header_t* p_gb_header,
                                          greatbelt_packet_header_t* p_cm_gb_header,
                                          uint8 to_cm_using_hdr);

extern void cm_gen_greatbelt_packet_header_outer(packet_header_outer_t* p_gb_header_outer,
                                                 cm_greatbelt_packet_header_outer_t* p_cm_gb_header_outer,
                                                 uint8 to_cm_using_hdr);

extern void cm_set_ptp_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32 high_64_32,uint32 low_31_0);
extern void cm_get_ptp_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32 *high_64_32,uint32 *low_31_0);
extern void cm_set_dm_rx_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32 high_64_32,uint32 low_31_0);
extern void cm_get_dm_rx_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32 *high_64_32,uint32 *low_31_0);
extern void cm_set_dm_tx_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32 high_61_32,uint32 low_31_0);
extern void cm_get_dm_tx_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32 *high_61_32,uint32 *low_31_0);


#endif

