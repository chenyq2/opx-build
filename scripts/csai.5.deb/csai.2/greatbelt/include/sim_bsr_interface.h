/****************************************************************************
 * sim_bsr_interface.h
 *
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V4.29.3.
 * Author:       ZhouW
 * Date:         2011-11-12
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#ifndef _SIM_BSR_INTERFACE_H_
#define _SIM_BSR_INTERFACE_H_

#include "sim_common.h"

extern int32 cosim_bsr_enqueue_taildrop(void *bus, bool *succ);
extern void cosim_bsr_linklist_check(void);
extern void cosim_get_bufstore_info(uint32 head_buffer_ptr, uint32 tail_buffer_ptr,
                        uint32 buffer_count, uint32 head_buf_offset, uint32 msg_type);
extern int32 sim_store_fwd_met_fifo_bus(void *ms_metfifo);
extern int32 sim_store_fwd_enqueue_bus(void *ms_enqueue);
extern int32 sim_store_fwd_dequeue_bus(void *ms_dequeue);

extern int32 cosim_fwd_met_fifo_verify(void *bus, bool *succ);
extern int32 cosim_fwd_enqueue_verify(void *bus, bool *succ);
extern int32 cosim_fwd_dequeue_verify(void *bus, bool *succ);
extern int32
cosim_do_bsr(uint32 chipid, uint32 chanid, uint32 pkt_len, uint8 *pkt, uint8 *exception);

#endif

