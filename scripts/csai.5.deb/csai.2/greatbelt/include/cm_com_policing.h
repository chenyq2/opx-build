/****************************************************************************
 * cm_com_policing.h    Provides SHARE policing handle function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Version:        V2.0
 * Author:         Jiangsz
 * Date:           2011-04-11.
 * Reason:         Create for spec V2.0.
 *
 ****************************************************************************/

#ifndef CM_COM_POLICING_H_
#define CM_COM_POLICING_H_

struct policing_info_s
{
    uint32 chip_id         :5;
    uint32 packet_length   :14;
    uint32 color           :2;
    uint32 layer3_offset   :8;
    uint32 policer_valid0  :1;
    uint32 policer_ptr0    :13;
    uint32 policer_valid1  :1;
    uint32 policer_ptr1    :13;
    uint32 ipg             :8;

    uint32 sop             :1; /* here check policer common interface, add by zhouw ?? */
    uint32 eop             :1;
    uint32 sop_color       :2;
    uint32 color_drop_code :2;

    uint32 mark_drop       :1;
    uint32 new_color       :2;
};

typedef struct policing_info_s policing_info_t;

extern int32  cm_com_policing_operation(policing_info_t* policing_info);

#endif
