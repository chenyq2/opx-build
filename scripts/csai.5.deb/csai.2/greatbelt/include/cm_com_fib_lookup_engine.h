/****************************************************************************
 * cm_com_fib_lookup_engine.h  All error code Deinfines, include SDK error code.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Vision:       V1.0.
 * Author:       XuZx
 * Date:         2011-12-3.
 * Reason:       Create for GreatBelt.
 *
 * Vision:       V4.2.1
 * Revisor:      XuZx
 * Date:         2011-07-09.
 * Reason:       Revise for GreatBelt v4.2.1.
 *
 * Vision:       V4.7.1
 * Revisor:      XuZx
 * Date:         2011-08-01.
 * Reason:       Revise for GreatBelt v4.7.1.
 *
 * Vision:       V5.1.0
 * Revisor:      XuZx
 * Date:         2011-12-12.
 * Reason:       Revise for GreatBelt v5.1.0.
 ****************************************************************************/
#include "sal.h"

struct fib_key_type_ipv4_ucast_s
{
    uint32 l4_source_port  :16;
    uint32 l4_dest_port    :16;

    uint32 ip_sa           :32;
    uint32 ip_da           :32;
};
typedef struct fib_key_type_ipv4_ucast_s fib_key_type_ipv4_ucast_t;

struct fib_key_type_ipv4_mcast_s
{
    uint32 l4_source_port  :16;
    uint32 l4_dest_port    :16;

    uint32 ip_sa           :32;
    uint32 ip_da           :32;
};
typedef struct fib_key_type_ipv4_mcast_s fib_key_type_ipv4_mcast_t;

struct fib_key_type_ipv6_ucast_s
{
    uint32 pointer      :18;
    uint32 ipv6_mid     :13;
    uint32 rsv0         :1;

    uint32 rsv          :16;
    uint32 l4_dest_port :16;

    uint32 ip_da127_96  :32;
    uint32 ip_da95_64   :32;
    uint32 ip_da63_32   :32;
    uint32 ip_da31_0    :32;
};
typedef struct fib_key_type_ipv6_ucast_s fib_key_type_ipv6_ucast_t;

struct fib_key_type_ipv6_mcast_s
{
    uint32 l4_source_port  :16;
    uint32 l4_dest_port    :16;

    uint32 ip_da127_96     :32;
    uint32 ip_da95_64      :32;
    uint32 ip_da63_32      :32;
    uint32 ip_da31_0       :32;

    uint32 ip_sa127_96     :32;
    uint32 ip_sa95_64      :32;
    uint32 ip_sa63_32      :32;
    uint32 ip_sa31_0       :32;

    uint32 pointer         :11;
    uint32 rev             :21;
};
typedef struct fib_key_type_ipv6_mcast_s fib_key_type_ipv6_mcast_t;

struct fib_key_type_ipv4_rpf_s
{
    uint16 l4_source_port  :16;
    uint16 l4_dest_port    :16;

    uint32 ip_sa           :32;
    uint32 ip_da           :32;
};
typedef struct fib_key_type_ipv4_rpf_s fib_key_type_ipv4_rpf_t;

struct fib_key_type_ipv6_rpf_s
{
    uint32 pointer         :18;
    uint32 mid             :13;
    uint32 rsv0            :1;

    uint32 rsv1            :16;
    uint32 l4_source_port  :16;

    uint32 ip_sa127_96     :32;
    uint32 ip_sa95_64      :32;
    uint32 ip_sa63_32      :32;
    uint32 ip_sa31_0       :32;
};
typedef struct fib_key_type_ipv6_rpf_s fib_key_type_ipv6_rpf_t;

struct fib_key_type_ipv4_nat_sa_port_s
{
    uint32 l4_source_port  :16;
    uint32 l4_dest_port    :16;

    uint32 ip_sa           :32;
    uint32 ip_da           :32;
};
typedef struct fib_key_type_ipv4_nat_sa_port_s fib_key_type_ipv4_nat_sa_port_t;

struct fib_key_type_ipv6_nat_sa_port_s
{
    uint32 rsv            :16;
    uint32 l4_source_port :16;

    uint32 ip_sa127_96    :32;
    uint32 ip_sa95_64     :32;
    uint32 ip_sa63_32     :32;
    uint32 ip_sa31_0      :32;
};
typedef struct fib_key_type_ipv6_nat_sa_port_s fib_key_type_ipv6_nat_sa_port_t;

struct fib_key_type_mac_ipv4_multicast_s
{
    uint32 l4_source_port :16;
    uint32 l4_dest_port   :16;

    uint32 ip_sa          :32;
    uint32 ip_da          :32;
};
typedef struct fib_key_type_mac_ipv4_multicast_s fib_key_type_mac_ipv4_multicast_t;

struct fib_key_type_mac_ipv6_multicast_s
{
    uint32 ip_sa127_96    :32;
    uint32 ip_sa95_64     :32;
    uint32 ip_sa63_32     :32;
    uint32 ip_sa31_0      :32;

    uint32 ip_da127_96    :32;
    uint32 ip_da95_64     :32;
    uint32 ip_da63_32     :32;
    uint32 ip_da31_0      :32;
};
typedef struct fib_key_type_mac_ipv6_multicast_s fib_key_type_mac_ipv6_multicast_t;

struct fib_key_type_mac_s
{
    uint32 rsv                :16;
    uint32 mapped_mac47_32    :16;

    uint32 mapped_mac31_0     :32;
};
typedef struct fib_key_type_mac_s fib_key_type_mac_t;

struct fib_key_type_fcoe_s
{
    uint32 fcoe_did          :24;
    uint32 rsv1              :8;
};
typedef struct fib_key_type_fcoe_s fib_key_type_fcoe_t;

struct fib_key_type_fcoe_rpf_s
{
    uint32 fcoe_sid          :24;
    uint32 rsv1              :8;
};
typedef struct fib_key_type_fcoe_rpf_s fib_key_type_fcoe_rpf_t;

struct fib_key_type_trill_ucast_s
{
    uint32 egress_nickname    :16;
};
typedef struct fib_key_type_trill_ucast_s fib_key_type_trill_ucast_t;

struct fib_key_type_trill_mcast_s
{
    uint32 egress_nickname    :16;
};
typedef struct fib_key_type_trill_mcast_s fib_key_type_trill_mcast_t;

struct fib_key_type_trill_mcast_vlan_s
{
    uint32 rsv                :4;
    uint32 vlan_id            :12;
    uint32 egress_nickname    :16;
};
typedef struct fib_key_type_trill_mcast_vlan_s fib_key_type_trill_mcast_vlan_t;

struct fib_key_type_acl_s
{
    uint32 global_src_port        :14;
    uint32 layer3_header_protocol :8;
    uint32 dscp                   :6;
    uint32 cos                    :3;
    uint32 is_ipv4_key            :1;

    uint32 mapped_mac31_0         :32;
    uint32 mapped_mac47_32        :16;
    uint32 l4_source_port         :16;

    uint32 ip_sa                  :32;
    uint32 ip_da                  :32;

    uint32 is_arp_key             :1;
    uint32 l4_dest_port           :16;
    uint32 is_logic_port          :1;
    uint32 vlan_id                :12;
    uint32 rsv                    :2;

    uint16 ether_type;
};
typedef struct fib_key_type_acl_s fib_key_type_acl_t;

struct fib_key_s
{
    union
    {
        fib_key_type_ipv4_ucast_t          ipv4_ucast;
        fib_key_type_ipv4_mcast_t          ipv4_mcast;
        fib_key_type_ipv6_ucast_t          ipv6_ucast;
        fib_key_type_ipv6_mcast_t          ipv6_mcast;
        fib_key_type_ipv4_rpf_t            ipv4_rpf;
        fib_key_type_ipv6_rpf_t            ipv6_rpf;
        fib_key_type_ipv4_nat_sa_port_t    ipv4_nat_sa_port;
        fib_key_type_ipv6_nat_sa_port_t    ipv6_nat_sa_port;
        fib_key_type_mac_ipv4_multicast_t  mac_ipv4_mcast;
        fib_key_type_mac_ipv6_multicast_t  mac_ipv6_mcast;
        fib_key_type_mac_t                 mac;
        fib_key_type_fcoe_t                fcoe;
        fib_key_type_fcoe_rpf_t            fcoe_rpf;
        fib_key_type_trill_mcast_vlan_t    trill_mcast_vlan;
        fib_key_type_trill_ucast_t         trill_ucast;
        fib_key_type_trill_mcast_t         trill_mcast;
        fib_key_type_acl_t                 acl;
    }key;
    union
    {
        uint32 vsi_id;
        uint32 vrf_id;
    }id;
    uint32 layer4_type;
};
typedef struct fib_key_s fib_key_t;

struct push_info_s
{
    uint8 default_entry_valid;
    uint8 valid;
    uint8 conflict;
    void* data;
};
typedef struct push_info_s push_info_t;

extern int32
cm_com_fib_lookup_engine_lookup_handle(uint8, fib_key_t*, fib_key_type_t, lookup_result_t*);

