/****************************************************************************
 * sim_epe_interface.h
 *
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V4.29.3.
 * Author:       ZhouW
 * Date:         2011-11-12
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#ifndef _SIM_EPE_INTERFACE_H_
#define _SIM_EPE_INTERFACE_H_

#include "sim_common.h"

extern int32
cosim_do_epe(uint32 chipid, uint32 chanid, uint32 pkt_len, uint8 *pkt);

extern int32 sim_store_epe_aq2cs_bus(void *in_pkt);
extern int32 sim_store_epe_cs2om_bus(void *in_pkt);
extern int32 sim_store_epe_ha2hp_bus(void *in_pkt);
extern int32 sim_store_epe_ha2nh_bus(void *in_pkt);
extern int32 sim_store_epe_ha2pr_bus(void *pars_info);
extern int32 sim_store_epe_hp2aq_bus(void *in_pkt);
extern int32 sim_store_epe_hp2he_bus(void *in_pkt);
extern int32 sim_store_epe_hp2om_bus(void *in_pkt);
extern int32 sim_store_epe_nh2hp_bus(void *in_pkt);
extern int32 sim_store_epe_om2he_bus(void *in_pkt);
extern int32 sim_store_epe_pr2hp_bus(void *in_pkt);
extern int32 sim_store_epe_nettx_bus(void *in_pkt);
extern int32 sim_store_epe_excp_bus(void *in_pkt);
extern int32 sim_store_epe_ha2nh_sharelm_bus(void *in_pkt);
extern int32 sim_store_epe_ha2nh_sharenat_bus(void *in_pkt);
extern int32 sim_store_epe_ha2nh_shareoam_bus(void *in_pkt);
extern int32 sim_store_epe_ha2nh_shareptp_bus(void *in_pkt);
extern int32 sim_store_epe_ha2nh_sharedm_bus(void *in_pkt);
extern int32 sim_store_epe_hp2oam_sharelm_bus(void *in_pkt);
extern int32 sim_store_epe_hp2oam_sharenat_bus(void *in_pkt);
extern int32 sim_store_epe_hp2oam_shareoam_bus(void *in_pkt);
extern int32 sim_store_epe_hp2oam_shareptp_bus(void *in_pkt);
extern int32 sim_store_epe_hp2oam_sharedm_bus(void *in_pkt);
extern int32 sim_store_epe_np2hp_sharelm_bus(void *in_pkt);
extern int32 sim_store_epe_np2hp_sharenat_bus(void *in_pkt);
extern int32 sim_store_epe_np2hp_shareoam_bus(void *in_pkt);
extern int32 sim_store_epe_np2hp_shareptp_bus(void *in_pkt);
extern int32 sim_store_epe_np2hp_sharedm_bus(void *in_pkt);
extern int32 sim_store_epe_oam2he_sharelm_bus(void *in_pkt);
extern int32 sim_store_epe_oam2he_sharenat_bus(void *in_pkt);
extern int32 sim_store_epe_oam2he_shareoam_bus(void *in_pkt);
extern int32 sim_store_epe_oam2he_shareptp_bus(void *in_pkt);
extern int32 sim_store_epe_oam2he_sharedm_bus(void *in_pkt);

extern int32 cosim_epe_aq2cs_verify(void *bus, bool *succ);
extern int32 cosim_epe_cs2om_verify(void *bus, bool *succ);
extern int32 cosim_epe_ha2hp_verify(void *bus, bool *succ);
extern int32 cosim_epe_ha2nh_verify(void *bus, bool *succ);
extern int32 cosim_epe_ha2pr_verify(void *bus, bool *succ);
extern int32 cosim_epe_hp2aq_verify(void *bus, bool *succ);
extern int32 cosim_epe_hp2he_verify(void *bus, bool *succ);
extern int32 cosim_epe_hp2om_verify(void *bus, bool *succ);
extern int32 cosim_epe_nh2hp_verify(void *bus, bool *succ);
extern int32 cosim_epe_om2he_verify(void *bus, bool *succ);
extern int32 cosim_epe_pr2hp_verify(void *bus, bool *succ);
extern int32 cosim_epe_nettx_verify(void *bus,bool *succ);
extern int32 cosim_epe_excp_verify(void *bus, bool *succ);
extern int32 cosim_epe_ha2nh_sharelm_verify(void *bus, bool *succ);
extern int32 cosim_epe_ha2nh_sharenat_verify(void *bus, bool *succ);
extern int32 cosim_epe_ha2nh_shareoam_verify(void *bus,bool *succ);
extern int32 cosim_epe_ha2nh_shareptp_verify(void *bus, bool *succ);
extern int32 cosim_epe_ha2nh_sharedm_verify(void *bus, bool *succ);
extern int32 cosim_epe_hp2oam_sharelm_verify(void *bus, bool *succ);
extern int32 cosim_epe_hp2oam_sharenat_verify(void *bus, bool *succ);
extern int32 cosim_epe_hp2oam_shareoam_verify(void *bus,bool *succ);
extern int32 cosim_epe_hp2oam_shareptp_verify(void *bus, bool *succ);
extern int32 cosim_epe_hp2oam_sharedm_verify(void *bus, bool *succ);
extern int32 cosim_epe_np2hp_sharelm_verify(void *bus, bool *succ);
extern int32 cosim_epe_np2hp_sharenat_verify(void *bus, bool *succ);
extern int32 cosim_epe_np2hp_shareoam_verify(void *bus,bool *succ);
extern int32 cosim_epe_np2hp_shareptp_verify(void *bus, bool *succ);
extern int32 cosim_epe_np2hp_sharedm_verify(void *bus, bool *succ);
extern int32 cosim_epe_oam2he_sharelm_verify(void *bus, bool *succ);
extern int32 cosim_epe_oam2he_sharenat_verify(void *bus, bool *succ);
extern int32 cosim_epe_oam2he_shareoam_verify(void *bus,bool *succ);
extern int32 cosim_epe_oam2he_shareptp_verify(void *bus, bool *succ);
extern int32 cosim_epe_oam2he_sharedm_verify(void *bus, bool *succ);

#endif

