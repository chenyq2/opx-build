/****************************************************************************
 * sim_table_interface.h
 *
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V4.29.3.
 * Author:       ZhouW
 * Date:         2011-11-12
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#ifndef _SIM_TABLE_INTERFACE_H_
#define _SIM_TABLE_INTERFACE_H_

#include "sim_common.h"

#define SIM_MTU (9600 + 64)
struct sim_pkt_cmp_s
{
    list_head_t head;

    uint8 pkt[SIM_MTU];
    uint32 chan_id;
    uint32 chip_id;
    uint32 packet_length;  /* total length, includes packet length and packet header length if it exits */
    uint8 discard;
    uint32 discard_type;
};
typedef struct sim_pkt_cmp_s sim_pkt_cmp_t;

extern int32 sim_store_table_info(uint8 chip_id, uint32 tbl_id, uint32 index, uint32 *data, bool is_write_dsoam);

extern int32 cosim_cmp_table(rtl_tbl_info_t *rtl_tbl_info_bus, bool *succ);

extern int32 cosim_chk_outpkt_empty(FILE *fp, uint8 mod_id);

extern int32 cosim_chk_table_empty(FILE *fp);

#endif

