/****************************************************************************
 * cm_com_interrupt.h  Interrupt for ASIC C-Model.
 * Copyright:      (c)2012 Centec Networks Inc. All rights reserved.
 *
 * Revision:        V1.0.
 * Author:         kcao.
 * Date:           2012-11-20.
 * Reason:         First Create.
 ****************************************************************************/
#ifndef _CM_COM_INTERRUPT_H_
#define _CM_COM_INTERRUPT_H_

/****************************************************************************
 *
* Header Files
*
****************************************************************************/

/****************************************************************************
 *
* Defines and Macros
*
****************************************************************************/
/* sup-level interrupt type, should be same to ctc_interrupt_type_gb_t */
enum cm_interrupt_type_gb_e
{
    /* ASIC Internal Interrupt */
    CM_INTR_GB_CHIP_FATAL = 0,             /**< [GB] sup fatal exception appear, sub-intr [0,47] */
    CM_INTR_GB_CHIP_NORMAL,                /**< [GB] sup normal exception appear, sub-intr [0,85] */

    /* Functional Interrupts */
    CM_INTR_GB_FUNC_PTP_TS_CAPTURE,        /**< [GB] PTP RX timestamp capture, when 1PPS or SyncPulse received */
    CM_INTR_GB_FUNC_PTP_MAC_TX_TS_CAPTURE, /**< [GB] PTP TX timestamp capture, for 2-step */
    CM_INTR_GB_FUNC_PTP_TOD_PULSE_IN,      /**< [GB] PTP 1PPS received */
    CM_INTR_GB_FUNC_PTP_TOD_CODE_IN_RDY,   /**< [GB] PTP TOD input code is ready */
    CM_INTR_GB_FUNC_PTP_SYNC_PULSE_IN,     /**< [GB] PTP SyncPulse received */
    CM_INTR_GB_FUNC_PTP_SYNC_CODE_IN_RDY,  /**< [GB] PTP Sync Interface input code is ready */
    CM_INTR_GB_FUNC_OAM_TX_PKT_STATS,      /**< [GB] OAM Auto TX to notify packet number exceed threshold */
    CM_INTR_GB_FUNC_OAM_TX_OCTET_STATS,    /**< [GB] OAM Auto TX to notify packet octets exceed threshold */
    CM_INTR_GB_FUNC_OAM_RX_PKT_STATS,      /**< [GB] OAM Auto RX to notify packet number exceed threshold */
    CM_INTR_GB_FUNC_OAM_RX_OCTET_STATS,    /**< [GB] OAM Auto RX to notify packet octets exceed threshold */
    CM_INTR_GB_FUNC_OAM_DEFECT_CACHE,      /**< [GB] OAM defect cache to notify OAM status change */
    CM_INTR_GB_FUNC_OAM_CLEAR_EN_3,        /**< [GB] OAM Auto TX to notify session 3 TX number reach */
    CM_INTR_GB_FUNC_OAM_CLEAR_EN_2,        /**< [GB] OAM Auto TX to notify session 2 TX number reach */
    CM_INTR_GB_FUNC_OAM_CLEAR_EN_1,        /**< [GB] OAM Auto TX to notify session 1 TX number reach */
    CM_INTR_GB_FUNC_OAM_CLEAR_EN_0,        /**< [GB] OAM Auto TX to notify session 0 TX number reach */
    CM_INTR_GB_FUNC_MDIO_XG_CHANGE,        /**< [GB] MDIO detects any status changes of XG PHYs */
    CM_INTR_GB_FUNC_MDIO_1G_CHANGE,        /**< [GB] MDIO detects any status changes of 1G PHYs */
    CM_INTR_GB_FUNC_CHAN_LINKDOWN_SCAN_OK, /**< [GB] Linkagg protect switch done */
    CM_INTR_GB_FUNC_IPE_LEARN_CACHE,       /**< [GB] Learning cache to notify SW learning */
    CM_INTR_GB_FUNC_IPE_FIB_LEARN_FIFO,    /**< [GB] HW learning or aging */
    CM_INTR_GB_FUNC_IPE_AGING_FIFO,        /**< [GB] Aging FIFO to notify SW aging */
    CM_INTR_GB_FUNC_STATS_FIFO,            /**< [GB] Statistics exceed the threshold */
    CM_INTR_GB_FUNC_MET_LINK_SCAN_DONE,    /**< [GB] APS protect switch done */

    /* DMA Interrupt */
    CM_INTR_GB_DMA_FUNC,                   /**< [GB] DMA channel need to handle, sub-intr [0,16] */
    CM_INTR_GB_DMA_NORMAL,                 /**< [GB] DMA channel exception appear, sub-intr [0,47] */

    /* PCIe Interrupt */
    CM_INTR_GB_PCIE_SECOND,                /**< [GB] PCIe secondary exception appear */
    CM_INTR_GB_PCIE_PRIMARY,               /**< [GB] PCIe primary exception appear */
    CM_INTR_GB_MAX
};
typedef enum cm_interrupt_type_gb_e cm_interrupt_type_gb_t;

/**
 @brief [GB] CM_INTR_GB_DMA_FUNC interrupt sub-type
*/
enum cm_interrupt_type_gb_sub_dma_func_e
{
    CM_INTR_GB_SUB_DMA_FUNC_RX_CHAN_0 = 0,
    CM_INTR_GB_SUB_DMA_FUNC_RX_CHAN_1,
    CM_INTR_GB_SUB_DMA_FUNC_RX_CHAN_2,
    CM_INTR_GB_SUB_DMA_FUNC_RX_CHAN_3,
    CM_INTR_GB_SUB_DMA_FUNC_RX_CHAN_4,
    CM_INTR_GB_SUB_DMA_FUNC_RX_CHAN_5,
    CM_INTR_GB_SUB_DMA_FUNC_RX_CHAN_6,
    CM_INTR_GB_SUB_DMA_FUNC_RX_CHAN_7,
    CM_INTR_GB_SUB_DMA_FUNC_TX_CHAN_0,
    CM_INTR_GB_SUB_DMA_FUNC_TX_CHAN_1,
    CM_INTR_GB_SUB_DMA_FUNC_TX_CHAN_2,
    CM_INTR_GB_SUB_DMA_FUNC_TX_CHAN_3,
    CM_INTR_GB_SUB_DMA_FUNC_TX_CHAN_4,
    CM_INTR_GB_SUB_DMA_FUNC_TX_CHAN_5,
    CM_INTR_GB_SUB_DMA_FUNC_TX_CHAN_6,
    CM_INTR_GB_SUB_DMA_FUNC_TX_CHAN_7,
    CM_INTR_GB_SUB_DMA_FUNC_BURST,
    CM_INTR_GB_SUB_DMA_FUNC_MAX
};
typedef enum cm_interrupt_type_gb_sub_dma_func_e cm_interrupt_type_gb_sub_dma_func_t;

#define CM_INTR_GB_SUP_FUNC_BIT_BEGIN   CM_INTR_GB_FUNC_PTP_TS_CAPTURE     /* GbSupInterruptFunction is begin with 2 */
#define CM_INTR_GB_SUP_FUNC_BIT_END     CM_INTR_GB_FUNC_MET_LINK_SCAN_DONE /* GbSupInterruptFunction is end with 24 */

#define CM_INTR_INDEX_VAL_SET           0
#define CM_INTR_INDEX_VAL_RESET         1
#define CM_INTR_INDEX_MASK_SET          2
#define CM_INTR_INDEX_MASK_RESET        3
#define CM_INTR_INDEX_MAX               4

#define CM_INTR_STAT_SIZE               3
#define CM_INTR_ALL                     ((uint32)-1)    /**< all interrupt bits of sup-level/sub-level */

/****************************************************************************
 *
* Global and Declarations
*
****************************************************************************/

int32
cm_com_interrupt_set(uint8 lchip, uint32 enable, uint32 intr, uint32 sub_intr);

#endif

