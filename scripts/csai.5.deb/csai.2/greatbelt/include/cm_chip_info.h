/****************************************************************************
 * cm_chip_info.h: some chip information deinfinition.
 *
 * Copyright (c)2010 Centec Networks Inc. All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiang.
 * Date:         2010-11-01.
 * Reason:       First Create.
 ****************************************************************************/
#ifndef _CM_CHIP_INFO_H_
#define _CM_CHIP_INFO_H_

/* define each interface channel id */
#define RESOURCE_GROUPID_OFFSET         256

/* define network port chanid */
#define GMAC_MIN_CHANID                 0
#define GMAC_MAX_CHANID                 47
#define SGMAC_MIN_CHANID                48
#define SGMAC_MAX_CHANID                55
#define SGMAC_MIN_CHANID_SUPPORT_HIGIG  52
#define SGMAC_MAX_CHANID_SUPPORT_HIGIG  55
#define ELOG_MIN_CHANID                 64
#define ELOG_MAX_CHANID                 119

/* the following macro should be updated according to the humber RTL design */
#define NETWORK_MIN_CHANID              0
#define NETWORK_MAX_CHANID              55

/*
#define INTERLAKEN_CHANID               56
#define I_LOOPBACK_CHANID               57
#define CPU_CHANID                      58
#define DMA_CHANID                      59
#define OAM_CHANID                      60
#define E_LOOPBACK_CHANID               61
*/

#define INTERLAKEN_CHANID               \
        sim_get_channel(0, RSV_CHAN_TYPE_INTLK_CHAN)
#define I_LOOPBACK_CHANID               \
        sim_get_channel(0, RSV_CHAN_TYPE_ILOOP_CHAN)
#define CPU_CHANID                      \
        sim_get_channel(0, RSV_CHAN_TYPE_CPU_CHAN)
#define DMA_CHANID                      \
        sim_get_channel(0, RSV_CHAN_TYPE_DMA_CHAN)
#define OAM_CHANID                      \
        sim_get_channel(0, RSV_CHAN_TYPE_OAM_CHAN)
#define E_LOOPBACK_CHANID               \
        sim_get_channel(0, RSV_CHAN_TYPE_ELOOP_CHAN)

#define MAX_CHANID                      64  /* use for channelID to macNum */

/* define each interface resource group id */
#define OAM_RESOURCE_GROUPID            (RESOURCE_GROUPID_OFFSET+OAM_CHANID)
#define E_LOOP_RESOURCE_GROUPID         (RESOURCE_GROUPID_OFFSET+E_LOOPBACK_CHANID)
#define I_LOOP_RESOURCE_GROUPID         (RESOURCE_GROUPID_OFFSET+I_LOOPBACK_CHANID)
#define CPU_RESOURCE_GROUPID            (RESOURCE_GROUPID_OFFSET+CPU_CHANID)
#define DMA_RESOURCE_GROUPID            (RESOURCE_GROUPID_OFFSET+DMA_CHANID)
#define ELOG_RESOURCE_GROUPID           (RESOURCE_GROUPID_OFFSET+62)

#define IS_INTERLAKEN_CHANNEL(channel_id)  (INTERLAKEN_CHANID == (channel_id))

/* CRC field offset in packet header */
#define GREATBELT_HDR_CRC_OFFSET 15

/* humber chip's info */
#define HUMBER_HEADER_LEN         32
#define HUMBER_EXCEPTION_LEN      4
#define HUMBER_CPUMAC_HDR_LEN     16

/* GreatBelt chip's info */
#define GREAT_BELT_HEADER_LEN     32
#define GREAT_BELT_EXCEPTION_LEN  8
#define GREAT_BELT_CPUMAC_HDR_LEN 20 /* MacDa + MacSa + VlanTag(4B) + EtherType(2B) + Rsv(2B) */
#define MAX_LOCAL_PHY_PORT        128
#define MAX_NETWORK_PORT_WO_MUX   60 /* Max network port number without using mux/demux */

/*SYSTEM MODIFY, Added by huangxt for SDK bug 23015, 2013-05-24*/
#define GREAT_BELT_DMA_PKT_CRC_LEN 4

#define MAX_MEP_LEVEL             8
#define GREAT_BELT_DMA_PKT_CRC_LEN 4

#endif

