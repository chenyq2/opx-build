#ifndef _CM_LIB_H_
#define _CM_LIB_H_

#include "cm_chip_info.h"

#include "cm_com_sgmac_info.h"

#if (HOST_IS_LE == 1)
#include "cm_com_parser_le.h"
#endif

#if (HOST_IS_LE == 0)
#include "cm_com_parser_be.h"
#endif

#include "cm_com_common.h"
#include "cm_com_engine.h"
#include "cm_com_sysengine.h"
#include "cm_com_swemu_sys.h"
#include "cm_com_cmodel_init.h"
#include "cm_com_mac_entity.h"
#include "cm_com_stats.h"
#include "cm_com_userid_lookup.h"
#include "cm_com_fib_lookup_engine.h"
#include "cm_com_lpm_engine.h"
#include "cm_com_asic_tools.h"
#include "cm_com_util.h"
#include "cm_com_cfg_kit.h"
#include "cm_com_interrupt.h"
#include "cm_com_dma.h"
#include "cm_sim_cli.h"

#include "sram_model.h"
#include "tcam_model.h"


/*some cm_XXX.h function declearation contain struct defined in drv_struct_XX.h, so their dependce should be notice
  * XuZx 2010-11-9
  */
#include "cm_ipe.h"
#include "cm_epe.h"
#include "cm_fwd.h"
#include "cm_oam.h"

#include "cm_com_asic_model.h"
#include "cm_com_tcam_engine.h"

#define CONSOLE_DEBUG_OUT(fmt, args...)                      \
{                                                            \
    FILE * fp_console = NULL;                                \
    fp_console = fopen("/dev/console", "w+");                \
    fprintf(fp_console, fmt"\n", ##args);                    \
    fclose(fp_console);                                      \
}

#if (SDK_WORK_PLATFORM == 1)
#include "sim_interface.h"
#endif

#endif

