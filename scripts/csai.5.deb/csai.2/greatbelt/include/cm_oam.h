/****************************************************************************
 * cm_oam.h  All packet type Deinfines.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       JiangJf
 * Date:         2010-11-08.
 * Reason:       First Create.
 ****************************************************************************/
#ifndef _CM_OAM_H_
#define _CM_OAM_H_

#include "cm_com_common.h"
#include "cm_ipe.h"

/* Received OAM type */
enum oam_rx_type_e
{
    OAM_NONE,
    OAM_ETHER,
    OAM_IP_BFD,
    OAM_PBT,
    OAM_PBB_BSI,
    OAM_PBB_BV,
    OAM_MPLS,
    OAM_MPLS_BFD,
    OAM_ACH,
    OAM_RX_TYPE_RSV0,
    OAM_TRILL_BFD,
    OAM_TRILL_BFD_ECHO,
    OAM_RX_TYPE_RSV1,
    OAM_RX_TYPE_RSV2,
    OAM_RX_TYPE_RSV3,
    OAM_RX_TYPE_RSV4,
};
typedef enum oam_rx_type_e oam_rx_type_t;

/* JiangJf TODO: define OAM L2 type */
enum oam_l2_type_e
{
    OAM_L2_UNKNOWN,
    OAM_L2_ETH_V2,
    OAM_L2_ETH_SAP,
    OAM_L2_ETH_SNAP,
    OAM_L2_RESERVED
};
typedef enum oam_l2_type_e oam_l2_type_t;

/* JiangJf TODO: define OAM L3 type */
enum oam_l3_type_e
{
    OAM_L3_UNKNOWN,
    OAM_L3_IP,
    OAM_L3_IP_V4,
    OAM_L3_IP_V6,
    OAM_L3_MPLS,
    OAM_L3_MPLS_MCAST,
    OAM_L3_ETHOAM = 9,
    OAM_L3_RESERVED
};
typedef enum oam_l3_type_e oam_l3_type_t;

/* OAM type in packet parser */
enum oam_type_e
{
    OAM_TYPE_NONE   = 0,
    ETHER_CCM       = 1,
    ETHER_APS       = 2, /* opCode=39*/
    ETHER_1DM       = 3,
    ETHER_DMM       = 4,
    ETHER_DMR       = 5,
    ETHER_RAPS      = 6, /* opcode = 40*/
    ETHER_LBM       = 7, /* opcode = 3, bug 889*/
    ETHER_LBR       = 8, /* opcode = 2, bug 889*/
    ETHER_LMR       = 9, /* opcode = 42 */
    ETHER_LMM       = 10,/* opcode = 43 */
    MPLSTP_LBM      = 11,/* opcode = 3 */
    ETHER_TST       = 12,/* opcode = 37 */
    ETHER_LTR       = 13,/* opcode = 4 */
    ETHER_LTM       = 14,/* opcode = 5 */
    ETH_OTHER       = 15,/* other than CCM and APS */
    MPLSTP_DM       = 16,
    MPLSTP_DLM      = 17,
    MPLSTP_DLMDM    = 18,
    MPLSTP_CV       = 19,  /*MPLS-TP BFD CV */
    MPLSTP_CSF      = 20, /*MPLS-TP CSF*/
    ETH_CSF         = 21, /* ETH CSF*/
    MCC             = 22, /*ACH MCC/ETH MCC*/
    MPLS_OTHER      = 23,
    MPLS_OAM        = 28,
    BFD_OAM         = 29,
    SCC             = 30, /*ACH SCC/ETH SCC*/
};
typedef enum oam_type_e oam_tp_t;

/* define oam op code according to Y.1731 */
enum oam_op_code_s
{
    OAM_OP_CCM  = 1,
    OAM_OP_LBR  = 2,
    OAM_OP_LBM  = 3,
    OAM_OP_LTR  = 4,
    OAM_OP_LTM  = 5,
    OAM_OP_AIS  = 33,
    OAM_OP_TST  = 37,
    OAM_OP_APS  = 39,
    OAM_OP_RAPS = 40,
    OAM_OP_MCC  = 41,
    OAM_OP_LMR  = 42,
    OAM_OP_LMM  = 43,
    OAM_OP_1DM  = 45,
    OAM_OP_DMR  = 46,
    OAM_OP_DMM  = 47,
};
typedef enum oam_op_code_s oam_op_code_t;

/* define oam tlv type according to Y.1731*/
enum oam_tlv_type_e
{
    OAM_TLV_TYPE_END        = 0,
    OAM_TLV_TYPE_SENDER_ID  = 1,
    OAM_TLV_TYPE_PORT_STS   = 2,
    OAM_TLV_TYPE_DATA       = 3,
    OAM_TLV_TYPE_IF_STS     = 4,
    OAM_TLV_TYPE_REPLY_INGS = 5,
    OAM_TLV_TYPE_REPLY_EGS  = 6,
    OAM_TLV_TYPE_TEST       = 32,
    OAM_TLV_TYPE_TARGET_ID  = 33,/*0x21*/
    OAM_TLV_TYPE_REPLY_ID   = 34,/*0x22*/
};
typedef enum oam_tlv_type_e oam_tlv_type_t;

/* JiangJf TODO: define OAM lookup type, refer to oam spec for correct value */
enum oam_lookup_type_e
{
    OAM_LOOKUP_TYPE_NONE,
    OAM_LOOKUP_TYPE_MPLS_LABEL,
    OAM_LOOKUP_TYPE_MPLS_SECTION,
    OAM_LOOKUP_TYPE_PBT_OAM,
    OAM_LOOKUP_TYPE_ETHER_OAM,
    OAM_LOOKUP_TYPE_BFD_OAM,
};
typedef enum oam_lookup_type_e oam_lookup_type_t;

/* define lm lookup type, only 1 and 2 are valid */
enum oam_lm_lookup_type_e
{
    LM_NONE,
    LM_ETHER,
    LM_MPLS,
};
typedef enum oam_lm_lookup_type_e oam_lm_lookup_type_t;

/* define lm type*/
enum oam_lm_type_e
{
    LM_TYPE_NONE,
    LM_TYPE_DUAL,
    LM_TYPE_SINGLE,
    LM_TYPE_RESV,
};
typedef enum oam_lm_type_e oam_lm_type_t;

/* define lm cos type*/
enum oam_lm_cos_type_e
{
    LM_COS_TYPE_ALL,
    LM_COS_TYPE_SPECIFIED_COS,
    LM_COS_TYPE_PER_COS,
    LM_COS_TYPE_RESV,
};
typedef enum oam_lm_cos_type_e oam_lm_cos_type_t;

/* MEP type, refer to DsBfdMep */
enum mep_type_e
{
    ETH_CCM_MEP,
    PBT_CCM_MEP,
    TRILL_BFD_MEP,
    FFD_MEP,
    CV1_MEP,
    BFD_MEP,
    ACH_Y1731_MEP,
    ACH_BFD_MEP,
};
typedef enum mep_type_e mep_type_t;

/* MA ID type, refer to DsMa */
enum maid_type_e
{
    MA_ID_TYPE_TTSI_IPV4       = 0,
    MA_ID_TYPE_RESERVED        = 1,
    MA_ID_TYPE_RESERVED_STRING = 2,
    MA_ID_TYPE_RESERVED2       = 3,
};
typedef enum maid_type_e maid_type_t;

/* BFD state */
enum bfd_state_e
{
    BFD_STATE_ADMIN_DOWN = 0,
    BFD_STATE_DOWN       = 1,
    BFD_STATE_INIT       = 2,
    BFD_STATE_UP         = 3,
};
typedef enum bfd_state_e bfd_state_t;

/* OAM exceptions in packet info */
enum oam_exception_e
{
    OAM_EXCEPTION_0_OAM_PDU_INVALID                        = 0,
    OAM_EXCEPTION_1_SOME_RDI_DEFECT                        = 1,
    OAM_EXCEPTION_2_SOME_MAC_STATUS_DEFECT                 = 2,
    OAM_EXCEPTION_3_HIGH_VERSION_ETH_OAM_TO_CPU            = 3,
    OAM_EXCEPTION_4_ERROR_CCM_DEFECT_RMEP_NOT_FOUND        = 4,
    OAM_EXCEPTION_5_XCON_CCM_DEFECT                        = 5,
    OAM_EXCEPTION_6_CCM_SEQ_NUM_ERROR                      = 6,
    OAM_EXCEPTION_7_DS_OR_CTRL_REG_CONFIG_ERROR            = 7,
    OAM_EXCEPTION_8_ETH_CCM_TLV_OPTION                     = 8,
    OAM_EXCEPTION_9_SLOW_OAM_PDU_TO_CPU                    = 9,
    OAM_EXCEPTION_10_ETH_TST_TO_CPU                        = 10,
    OAM_EXCEPTION_11_BFD_MPLS_DM_DLM_OAM_PDU_INVALID       = 11,
    OAM_EXCEPTION_12_BIG_INTERVAL_OR_SW_MEP_TO_CPU         = 12,
    OAM_EXCEPTION_13_SOURCE_MAC_MISMATCH                   = 13,
    OAM_EXCEPTION_14_MPLS_TP_DLM_TO_CPU                    = 14,
    OAM_EXCEPTION_15_MPLS_TP_DM_DLMDM_TO_CPU               = 15,
    OAM_EXCEPTION_16_APS_PDU_TO_CPU                        = 16,
    OAM_EXCEPTION_17_ERROR_CCM_DEFECT_CCM_INTERVAL_MISMATCH = 17,
    OAM_EXCEPTION_18_DM_TO_CPU                              = 18,
    OAM_EXCEPTION_19_MD_LEVEL_LOWER_THAN_PASSIVE_MEP        = 19,
    OAM_EXCEPTION_20_CSF_TO_CPU                             = 20,
    OAM_EXCEPTION_21_MIP_RECEIVE_NON_PROCESS_PDU            = 21,
    OAM_EXCEPTION_22_MCC_PDU_TO_CPU                         = 22,
    OAM_EXCEPTION_23_PBT_MM_DEFECT_PDU_TO_CPU               = 23,
    OAM_EXCEPTION_24_SEND_EQUAL_LTM_LTR_TO_CPU              = 24,
    OAM_EXCEPTION_25_EQUAL_LBR_TO_CPU                       = 25,
    OAM_EXCEPTION_26_LBM_MAC_DA_MEP_ID_CHECK_FAIL           = 26,
    OAM_EXCEPTION_27_LM_TO_CPU                              = 27,
    OAM_EXCEPTION_28_LEARNING_BFD_TO_CPU                    = 28,
    OAM_EXCEPTION_29_ERROR_BFD_TO_CPU                       = 29,
    OAM_EXCEPTION_30_BFD_TIMER_NEGOTIATION_TO_CPU           = 30,
    OAM_EXCEPTION_31_SCC_PDU_TO_CPU                         = 31,

};
typedef enum oam_exception_e oam_exception_t;

#if (HOST_IS_LE == 0)
union ma_id_u
{
    struct
    {
        uint32 ma_id_383_to352;
        uint32 ma_id_351_to320;
        uint32 ma_id_319_to288;
        uint32 ma_id_287_to256;
        uint32 ma_id_255_to224;
        uint32 ma_id_223_to192;
        uint32 ma_id_191_to160;
        uint32 ma_id_159_to128;
        uint32 ma_id_127_to96;
        uint32 ma_id_95_to64;
        uint32 ma_id_63_to32;
        uint32 ma_id_31_to0;

        //int8 ma_id[48];
    }eth;
    struct
    {
        uint32 ach_mepid_field0_223_to192;
        uint32 ach_mepid_field0_191_to160;
        uint32 ach_mepid_field0_159_to128;
        uint32 ach_mepid_field0_127_to96;
        uint32 ach_mepid_field0_95_to64;
        uint32 ach_mepid_field0_63_to32;
        uint32 ach_mepid_field0_31_to0;

        uint32 res_0       :12;
        uint32 detect_mult :8;
        uint32 version     :3;
        uint32 diag        :5;
        uint32 stat        :2;
        uint32 pbit        :1;
        uint32 fbit        :1;

        uint32 my_disc;

        uint32 your_disc;

        uint32 desired_min_tx_interval;

        uint32 required_min_rx_interval;
    }bfd;
    struct
    {
        uint32 rsv0             :32;
        uint32 rsv1             :32;
        uint32 rsv2             :32;
        uint32 rsv3             :32;
        uint32 rsv4             :32;
        uint32 rsv5             :32;

        uint32 rsv6             :24;
        uint32 dmlm_tlv_type    :8;

        uint32 dflags           :4;
        uint32 mplstp_dm_rptf   :4;
        uint32 mplstp_dm_rtf    :4;
        uint32 mplstp_dm_qtf    :4;
        uint32 control_code     :8;
        uint32 flags            :4;
        uint32 version          :4;

        uint32 counter1_63_to32 :32;
        uint32 counter1_31_to0  :32;

        uint32 timestamp1_63_to32 :32;
        uint32 timestamp1_31_to0  :32;
    }dlm;
};
typedef union ma_id_u ma_id_t;

union ccm_seq_num_u
{
    struct
    {
        uint32 ccm_seq_num;
    }eth;

    struct
    {
        uint32 res_0     :24;
        uint32 csf_flags  :8;
    }csf;

    struct
    {
        uint32 res_0                        :16;
        uint32 ach_mepid_field2_287_to272   :16;
    }bfd;

};
typedef union ccm_seq_num_u ccm_seq_num_t;

union mac_sa_u
{
    struct
    {
        uint32 rsv            :16;
        uint32 mac_sa_47_to32 :16;

        uint32 mac_sa_31_to0  :32;
        //uint8 mac_sa5;
        //uint8 mac_sa4;
        //uint8 mac_sa3;
        //uint8 mac_sa2;
        //uint8 mac_sa1;
        //uint8 mac_sa0;
    }eth;

    struct
    {
        uint32 rsv                        :16;
        uint32 ach_mepid_field1_271_to256 :16;

        uint32 ach_mepid_field1_255_to224 :32;
    }bfd;

};
typedef union mac_sa_u mac_sa_t;

union mac_da_u
{
    struct
    {
        uint32 rsv            :16;
        uint32 mac_da_47_to32 :16;

        uint32 mac_da_31_to0  :32;
    }eth;

};
typedef union mac_da_u mac_da_t;

#else

union ma_id_u
{
    struct
    {
        uint32 ma_id_383_to352;
        uint32 ma_id_351_to320;
        uint32 ma_id_319_to288;
        uint32 ma_id_287_to256;
        uint32 ma_id_255_to224;
        uint32 ma_id_223_to192;
        uint32 ma_id_191_to160;
        uint32 ma_id_159_to128;
        uint32 ma_id_127_to96;
        uint32 ma_id_95_to64;
        uint32 ma_id_63_to32;
        uint32 ma_id_31_to0;
    }eth;
    struct
    {
        uint32 ach_mepid_field0_223_to192;
        uint32 ach_mepid_field0_191_to160;
        uint32 ach_mepid_field0_159_to128;
        uint32 ach_mepid_field0_127_to96;
        uint32 ach_mepid_field0_95_to64;
        uint32 ach_mepid_field0_63_to32;
        uint32 ach_mepid_field0_31_to0;

        uint32 fbit        :1;
        uint32 pbit        :1;
        uint32 stat        :2;
        uint32 diag        :5;
        uint32 version     :3;
        uint32 detect_mult :8;
        uint32 res_0       :12;

        uint32 my_disc;

        uint32 your_disc;

        uint32 desired_min_tx_interval;

        uint32 required_min_rx_interval;
    }bfd;
    struct
    {
        uint32 rsv0             :32;
        uint32 rsv1             :32;
        uint32 rsv2             :32;
        uint32 rsv3             :32;
        uint32 rsv4             :32;
        uint32 rsv5             :32;

        uint32 dmlm_tlv_type    :8;
        uint32 rsv6             :24;

        uint32 version          :4;
        uint32 flags            :4;
        uint32 control_code     :8;
        uint32 mplstp_dm_qtf    :4;
        uint32 mplstp_dm_rtf    :4;
        uint32 mplstp_dm_rptf   :4;
        uint32 dflags           :4;

        uint32 counter1_63_to32 :32;

        uint32 counter1_31_to0  :32;

        uint32 timestamp1_63_to32 :32;

        uint32 timestamp1_31_to0  :32;
    }dlm;
};
typedef union ma_id_u ma_id_t;

union ccm_seq_num_u
{
    struct
    {
        uint32 ccm_seq_num;
    }eth;

    struct
    {
        uint32 csf_flags  :8;
        uint32 res_0     :24;
    }csf;

    struct
    {
        uint32 ach_mepid_field2_287_to272   :16;
        uint32 res_0                        :16;
    }bfd;

};
typedef union ccm_seq_num_u ccm_seq_num_t;

union mac_sa_u
{
    struct
    {
        uint32 mac_sa_47_to32 :16;
        uint32 rsv            :16;

        uint32 mac_sa_31_to0  :32;
    }eth;

    struct
    {
        uint32 ach_mepid_field1_271_to256 :16;
        uint32 rsv                        :16;

        uint32 ach_mepid_field1_255_to224 :32;
    }bfd;

};
typedef union mac_sa_u mac_sa_t;

union mac_da_u
{
    struct
    {
        uint32 mac_da_47_to32 :16;
        uint32 rsv            :16;

        uint32 mac_da_31_to0  :32;
    }eth;
};
typedef union mac_da_u mac_da_t;

#endif

/* JiangJf TODO: shall modify according to spec */
struct oam_parser_result_s
{
    mac_sa_t mac_sa;
    mac_da_t mac_da;

    uint32 md_lvl                          :3;
    uint32 rdi                             :1;
    uint32 present_traffic                 :1;
    uint32 ccm_interval                    :3;
    uint32 oam_pdu_invalid                 :1;
    uint32 mpls_lbm_pdu_invalid            :1;
    uint32 rmep_id                         :13;
    uint32 high_version_oam                :1;
    uint32 port_status_valid               :1;
    uint32 if_status_valid                 :1;
    uint32 tlv_options                     :1;
    uint32 resv0                           :5;

    ccm_seq_num_t ccm_seq_num;
    ma_id_t ma_id;

    uint32 ma_id_length                    :8;
    uint32 oam_type                        :5;
    uint32 packet_offset                   :7;
    uint32 layer3_offset                   :8;
    uint32 is_l2_eth_oam                   :1;
    uint32 ttsi_valid                      :1;

    uint32 op_code                         :8;
    uint32 tlv_length                      :16;
    uint32 next_type                       :8;

    uint32 bfd_oam_pdu_invalid             :1;
    uint32 port_status_value               :8;
    uint32 if_status_value                 :8;
    uint32 resv1                           :15;

};
typedef struct oam_parser_result_s oam_parser_result_t;

/* JiangJf TODO: shall modify according to spec */
struct oam_pkt_info
{
    uint32 rx_oam_type              :4;
    uint32 link_oam                 :1;
    uint32 mep_index                :14;
    uint32 mep_on_remote_chip       :1;
    uint32 is_slow_oam_type         :1;
    uint32 is_mep_hit               :1;
    uint32 equal_dm                 :1;
    uint32 equal_lm                 :1;
    uint32 layer4_offset            :8;

    uint32 packet_offset            :7;
    uint32 by_pass_all              :1;
    uint32 is_defect_free           :1;
    uint32 mip_en                   :1;
    uint32 rmep_index               :14;
    uint32 equal_lb                 :1;
    uint32 oam_use_fid              :1;
    uint32 defect_priority          :6;

    uint32 next_hop_ptr             :18;
    uint32 first_pkt_rx             :1;
    uint32 is_up                    :1;
    uint32 local_phy_port           :8;
    uint32 seq_num_chk_pass         :1;
    uint32 cpu_exception_valid      :1; /*cmodel add*/
    uint32 hard_discard             :1; /*cmodel add*/

    uint32 src_vlan_ptr             :14;
    uint32 global_src_port          :14;
    uint32 defect_type              :3;
    uint32 relay_all_to_cpu         :1;

    uint32 ingress_src_port         :14;
    uint32 ma_index                 :13;
    uint32 relay_to_cpu_valid       :1; /*cmodel add*/
    uint32 defect_sub_type          :3;
    uint32 relay_to_bsr_valid       :1; /*cmodel add*/


    uint32 equal_eth_tst            :1;
    uint32 packet_length            :14;
    uint32 lm_received_packet       :1;
    uint32 share_mac_en             :1;
    uint32 operation_type           :3;
    uint32 label_num                :2;
    uint32 discard                  :1;
    uint32 rsv_0                    :9;

    uint32 mpls_label_disable       :4;
    uint32 mpls_tp_entropy_label    :20;
    uint32 rmep_not_found           :1;

    uint8 port_mac[6] ;
    uint8 bridge_mac[6] ;
    uint32 exception;
    uint32 rx_fcl;
    uint32 rx_fcb;
    void* parser_result;
    ms_packet_header_t *bheader;
};
typedef struct oam_pkt_info oam_pkt_info_t;


struct oam_error_cache_pkt_info_s
{
    uint32 mep_index            :14;
    uint32 rmep_index           :14;
    uint32 defect_type          :3;
    uint32 update_info_valid    :1;

    uint32 defect_sub_type      :3;
    uint32 chip_id              :5;
    uint32 packet_info_valid    :1;
    uint32 is_rmep_valid        :1;
    uint32 rsv_0                :22;

    void* pkt_info;
    void* parser_result;
};
typedef struct oam_error_cache_pkt_info_s oam_error_cache_pkt_info_t;

struct oam_generate_ccm_pkt_info_s
{

    uint32 mep_index    :14;
    uint32 rmep_index   :14;
    uint32 is_tx_csf    :1;
    uint32 is_tx_cv     :1;
    uint32 rsv_0        :2;

    uint32 chip_id      :5;
    uint32 rsv_1        :27;

    void * p_ds_mep;
    void * p_ds_rmep;
    void * p_ds_ma;

};
typedef struct oam_generate_ccm_pkt_info_s oam_generate_ccm_pkt_info_t;

struct oam_parser_info_s
{
    uint32 packet_length        :14;
    uint32 svlan_tpid_index     :2;
    uint32 pbb_src_port_type    :3;
    uint32 by_pass_all          :1;
    uint32 rx_oam_type          :4;
    uint32 packet_offset        :7;
    uint32 rsv_0                :1;
};
typedef struct oam_parser_info_s oam_parser_info_t;

extern uint32 hard_error;
extern int32 cm_oam_header_adjust_handle(oam_in_pkt_t* in_pkt);
extern int32 cm_oam_packet_parser_handle(oam_in_pkt_t* in_pkt,oam_parser_info_t* parser_info );
extern int32 cm_oam_pdu_check(oam_in_pkt_t* in_pkt);
extern int32 cm_oam_receive_process_handle(oam_in_pkt_t* in_pkt);
extern int32 cm_oam_header_edit_handle(oam_in_pkt_t* in_pkt);
extern int32 cm_oam_error_cache_handle(oam_error_cache_pkt_info_t* oam_error_pkt_info);
extern int32 cm_oam_generate_ccm(oam_generate_ccm_pkt_info_t * gen_ccm_pkt_info);
extern uint32 cm_oam_lookup_get_rmep_index(oam_in_pkt_t* in_pkt);

extern uint8 cm_oam_gen_header_hash(uint16 mep_index, uint16 rmep_index, uint8 old_crc);
extern int32 cm_oam_com_get_link_agg_port(uint8 chip_id ,uint16 dest_id, uint8 crc);
#endif


