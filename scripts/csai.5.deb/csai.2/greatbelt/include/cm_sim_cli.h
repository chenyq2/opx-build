/****************************************************************************
 * cm_sim_cli.h:  provides all cli inter face.
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Revision:      V1.0.
 * Author:       Zhouw.
 * Date:         2010-07-08.
 * Reason:       First Create.
 *
 * Modify History:
****************************************************************************/
#ifndef _CM_SIM_CLI_H_
#define _CM_SIM_CLI_H_

/****************************************************************************
 * Header Files
****************************************************************************/
#include "cm_lib.h"

/****************************************************************************
 * Defines and Macros
****************************************************************************/
struct proc_field_info
{
    uint8 chip_id_offset;
    tbls_id_t tbl_id;
    fld_id_t field_id;
    uint32 value;
    uint32 index;
    bool mask;
    bool tcam_write_trigger; /* per-field set tcam key load cfg trigger on emulation board */
};
typedef struct proc_field_info proc_field_t;

/****************************************************************************
 * Global and Declarations
****************************************************************************/

/****************************************************************************
 * Functions
****************************************************************************/
extern int32
sim_cfg_set_field(proc_field_t* filed_info);

#if (SDK_WORK_PLATFORM==0)
extern int32
sim_cfg_emu_set_tcam_field(proc_field_t *field_info);
#endif

extern int32
sim_cfg_get_field(proc_field_t* filed_info);

extern int32
sim_asic_ipe_inpkt(char *file_name);

extern int32
sim_asic_qmgt_inpkt(char *file_name);

extern int32
sim_asic_epe_inpkt(char *file_name);

extern int32
sim_asic_cpu_netrx_inpkt(char *file_name);

extern int32
sim_asic_oam_inpkt(char* file_name);

extern int32
sim_asic_bhdr_inpkt(char *file_name);

extern int32
sim_asic_epe_bhdr_inpkt(char *file_name);

extern int32
sim_asic_ipe_bhdr_inpkt(char *file_name);

extern int32
sim_store_outpkt_filename(char *file_name);

extern int32
sim_store_oam_outpkt_filename(char *file_name);

extern int32
sim_asic_rx_tx_pkt_cnt(char *file_name);

extern int32
sim_whole_compare_file(char *file1, char *file2, chk_checksum_flag_t *ignor_check_sum,chk_total_length_flag_t *ignor_total_length);

extern int32
sim_compare_rslt_file(char *file_name);

extern int32
sim_chk_tbl_rslt_file(char *file_name);

extern int32
sim_store_chk_tbl_result(bool *succ);

extern int32
sim_model_init(um_emu_mode_t mode);

extern int32
sim_model_release(void);

#endif
