/****************************************************************************
 * cm_com_comdel_init.h    Useful utility and const for ASIC C-Model.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:      V1.0.
 * Author:       Jiang.
 * Date:         2010-11-1.
 * Reason:       First Create.
 ****************************************************************************/
#ifndef _CM_COM_COMDEL_INIT_H_
#define _CM_COM_COMDEL_INIT_H_

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "sal.h"

/****************************************************************************
 *
* Defines and Macros
*
****************************************************************************/
#ifndef ENABLE
#define ENABLE 1
#endif
#ifndef DISABLE
#define DISABLE 0
#endif

enum mem_type
{
    USE_ASIC,
    USE_SIM,
};

/****************************************************************************
 *
* Global and Declarations
*
****************************************************************************/
extern uint8 hg_plus_version;

extern int32 sim_model_init(um_emu_mode_t um_emu_mode);

extern int32 sim_model_release(void);

/* dump asic sram cfg */
extern int32 sim_model_sram_mem_dump(char *filename);

/* dump asic tcam cfg */
extern int32 sim_model_tcam_mem_dump(char *filename);

extern void swemu_set_um_emu_mode(um_emu_mode_t mode);

extern um_emu_mode_t swemu_get_um_emu_mode(void);

#endif

