/****************************************************************************
 * cm_com_common.h  All packet type Deinfines.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiang.
 * Date:         2010-11-1.
 * Reason:       First Create.
 ****************************************************************************/

#ifndef _CM_COM_COMMON_H_
#define _CM_COM_COMMON_H_

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "sal.h"
#include "../ctckal/include/ctcutil_list.h"
#include "drv_lib.h"
#include "cm_chip_info.h"
/****************************************************************************
 *
* Defines and Macros
*
****************************************************************************/
/* only cmodel using the marco */
#define CM_IOCTL sim_ioctl

#define TIME_ONE_S_TO_NS      1000000000  /* 1s = 1000000000ns */
#define TIME_STAMP_LENGTH     8           /* timestamp length is 8 Bytes */
#define MTU                   (9600 + 64) /* 64 bytes for forwarding headers */

#define MAX_MACNUM           62
#define MAX_NETMAC_NUM       60

#define CRC_LEN               4

#define LINE_LEN_MAX          128
#define EMPTY_LINE(C)         ((C) == '\0' ||(C) == '\r' || (C) == '\n' )
#define WHITE_SPACE(C)        ((C) == '\t' || (C) == ' ')

#define MUX_LENGTH_TYPE_BYTES 4

/* define MAX chip number */
#define CM_MAX_CHIP_NUM     2

/* define bit operations  */
#define CM_BIT_ISSET(flag, bit)     (((flag) & (1 << (bit))) ? 1: 0)
#define CM_BIT_SET(flag, bit)       ((flag) = (flag) |(1 << (bit)) )
#define CM_BIT_UNSET(flag, bit)     ((flag) = (flag) & (~(1 << (bit)) ))

#define CM_UINT32_BITS      32

/* define bitmap array operation */
/* internal used */
#define _CM_BMP_OP(_bmp, _offset, _op)     \
    (_bmp[(_offset) / CM_UINT32_BITS] _op (1U << ((_offset) % CM_UINT32_BITS)))

/* bmp should be a array of uint32, e.g. uint32 bmp[2] */

/* init bitmap */
#define CM_BMP_INIT(bmp)                   \
    sal_memset((bmp), 0, sizeof((bmp)));

/* check bitmap */
#define CM_BMP_OFFSET_CHECK(bmp, offset)   \
    ((0 <= offset) && ((offset) < CM_BMP_BITS(bmp)))

/* set bit */
#define CM_BMP_SET(bmp, offset)            \
    _CM_BMP_OP((bmp), (offset), |=)

/* unset bit */
#define CM_BMP_UNSET(bmp, offset)          \
    _CM_BMP_OP((bmp), (offset), &= ~)

/* get bit set */
#define CM_BMP_ISSET(bmp, offset)          \
    _CM_BMP_OP((bmp), (offset), &)

/* get bit count */
#define CM_BMP_BITS(bmp)                   \
    ((CTC_UINT32_BITS * sizeof((bmp)) / sizeof(uint32)))

/* bit iterate begin */
#define CM_BMP_ITER_BEGIN(bmp, offset)                             \
do {                                                                \
    for ((offset) = 0; (offset) < CM_BMP_BITS((bmp)); (offset)++)  \
        if (CM_BMP_ISSET((bmp), (offset)))

/* bit iterate end */
#define CM_BMP_ITER_END(bmp, offset)       \
} while (0);


typedef int32 (*CMODEL_DEBUG_OUT_CALLBACK)(char*, uint32);
extern bool cmodel_debug_on;
extern bool ctc_cmodel_debug_on;
extern bool cmodel_internal_output;
extern CMODEL_DEBUG_OUT_CALLBACK cmodel_debug_cb;
extern bool ctc_cmodel_debug_check_flag(uint32 typeenum);

enum ctc_cmodel_debug_flag_s
{
    CTC_CMODEL_DEBUG_FLAG_FWD_PATH            = 0x01,
    CTC_CMODEL_DEBUG_FLAG_PARSER_INFO         = 0x02,
    CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE        = 0x04,
    CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY          = 0x08,
    CTC_CMODEL_DEBUG_FLAG_KEY_INFO            = 0x10,
    CTC_CMODEL_DEBUG_FLAG_TABLE_PTR           = 0x20,
    CTC_CMODEL_DEBUG_FLAG_QMGT_HDR            = 0x40,
    CTC_CMODEL_DEBUG_FLAG_QMGT_MSG            = 0x80,
    CTC_CMODEL_DEBUG_FLAG_QMGT_LINKAGG        = 0x100,
    CTC_CMODEL_DEBUG_FLAG_AGING               = 0x200,
};
typedef enum ctc_cmodel_debug_flag_s ctc_cmodel_debug_flag_t;

enum ctc_cmodel_debug_module_s
{
    CTC_CMODEL_DEBUG_IPE,
    CTC_CMODEL_DEBUG_EPE
};
typedef enum ctc_cmodel_debug_module_s ctc_cmodel_debug_module_t;


#define CTC_CMODEL_DEBUG_OUT(typeenum, fmt, args...) \
{                                       \
    if (ctc_cmodel_debug_check_flag(typeenum)) \
    {                                   \
         char _buf[256];                \
         if(NULL == cmodel_debug_cb)    \
         {                              \
            sal_printf(fmt, ##args);    \
         }                              \
         else                           \
         {                              \
            sal_snprintf(_buf, 256, fmt, ##args);\
            cmodel_debug_cb(_buf, sal_strlen(_buf));\
         }                              \
    }                                   \
}

/* CModel debug Marc */
#define CMODEL_DEBUG_OUT_INFO(fmt, args...)  \
    do\
    {\
        char _buf[256];\
        if (cmodel_debug_on)\
        {\
            if (NULL == cmodel_debug_cb)\
            {\
                sal_printf(fmt, ##args);\
            }\
            else\
            {\
                sal_snprintf(_buf, 256, fmt, ##args);\
                cmodel_debug_cb(_buf, sal_strlen(_buf));\
            }\
        }\
    }\
    while (0)

#define CMODEL_DEBUG_INTERNAL_OUT_INFO(fmt, args...)  \
    do\
    {\
        if (cmodel_internal_output)\
        {\
            CMODEL_DEBUG_OUT_INFO(fmt, ##args);\
        }\
    }\
    while (0)

#define CMODEL_DEBUG_OUT_FILE_LINE_FUNC() \
    do\
    {\
        CMODEL_DEBUG_INTERNAL_OUT_INFO("++++ File:%s line:%d function:%s\n", __FILE__, __LINE__, __FUNCTION__);\
    }\
    while (0)

/* destMap[21:0] = {mcast, destchip[4:0], destid[15:0]} */
#define SET_MCAST_IN_DESTMAP(destmap, value)\
    (destmap) &= 0x1FFFFF;\
    (destmap) |= (((value) & 0x1)<<21);\

#define GET_MCAST_IN_DESTMAP(destmap) (((destmap)>>21) & 0x1)

#define SET_DESTCHIPID_IN_DESTMAP(destmap, value)\
    (destmap) &= 0x20FFFF;\
    (destmap) |= (((value) & 0x1F)<<16);\

#define GET_DESTCHIPID_IN_DESTMAP(destmap) (((destmap)>>16) & 0x1F)

#define SET_DESTID_IN_DESTMAP(destmap, value)\
    (destmap) &= 0x3F0000;\
    (destmap) |= ((value) & 0xFFFF);\

#define GET_DESTID_IN_DESTMAP(destmap) ((destmap) & 0xFFFF)

struct cm_com_module_bus_s
{
    uint32 pkt_len              :14;
    uint32 dest_id_discard      :1;
    uint32 resv                 :17;
    uint8 packet_header[GREAT_BELT_HEADER_LEN];
    uint32 sub_chan_id;
};
typedef struct cm_com_module_bus_s cm_com_module_bus_t;

struct ms_net_tx_s
{
   uint32 ptp_offset          :8;
   uint32 udp_ptp             :1;
   uint32 layer4_check_sum    :16;
   uint32 frag_info1          :1;
   uint32 channel_lized_valid :1;
   uint32 loopback_en         :1;
   uint32 mac_valid           :1;
};
typedef struct ms_net_tx_s ms_net_tx_t;

/* IPE engine input structure */
struct ipe_in_pkt_s
{
    uint32      pkt_id;
    uint8       *pkt;          /* Input packet content */
    void*       pkt_info;
    uint32      packet_length; /* Total length includes packet length and packet header length if it exits */
    uint32      chan_id;       /* Source channel ID */
    uint32      chip_id;       /* Source Chip ID */
    bool        channelinfo_ptpen;
    cm_com_module_bus_t module_bus;
};
typedef struct ipe_in_pkt_s ipe_in_pkt_t;

/* EPE engine input structure */
struct epe_in_pkt_s
{
    uint32      pkt_id;
    uint8*      pkt;
    void*       pkt_info;
    uint32      chip_id;
    uint32      chan_id;
    uint32      packet_length;   /* Total length includes packet length and packet header length */
    cm_com_module_bus_t module_bus;
    ms_net_tx_t ms_net_tx;
};
typedef struct epe_in_pkt_s epe_in_pkt_t;

/* BSR engine input structure */
struct queue_in_pkt_s
{
    uint32      pkt_id;
    uint8*      pkt;
    void*       pkt_info;
    uint32      chan_id;
    uint32      chip_id;
    uint32      packet_length;  /* Total length includes packet length and packet header length*/
    uint32      local_phy_port;
    uint32      from_fabric;
    void*       exception;
    cm_com_module_bus_t module_bus;
};
typedef struct queue_in_pkt_s queue_in_pkt_t;

/* OAM engine input structure */
struct oam_in_pkt_s
{
    uint32      pkt_id;
    uint8*      pkt;
    void*       pkt_info;
    uint32      chan_id;
    uint32      chip_id;
    uint32      packet_length;
    cm_com_module_bus_t module_bus;
};
typedef struct oam_in_pkt_s oam_in_pkt_t;

struct cm_int64_s
{
    uint32 high_63_32;
    uint32 low_31_0;
};
typedef struct cm_int64_s cm_uint64_t;

struct mac_message_type_s
{
   cm_uint64_t timestamp;

   uint32 time_stamp_valid    :1;
   uint32 ptp_offset_type     :2;
   uint32 egress_latency      :16;
   uint32 tc                  :4;
   uint32 dp                  :2;
   uint32 reserved0           :7;

   uint32 ptp_edit_type       :2;
   uint32 udp_ptp             :1;
   uint32 layer4_checksum     :16;
   uint32 frag_info1          :1;
   uint32 ptp_sequence_id     :2;
   uint32 ptp_offset          :7;
   uint32 reserved2           :3;

   uint32 udp_check_sum_offset :16;
   uint32 timestamp_offset    :8;
   uint32 is_ptp_offset       :1;
};
typedef struct mac_message_type_s mac_message_type_t;

/* Each engine output structure */
struct out_pkt_s
{
    list_head_t head;

    uint32      pkt_id;
    uint8       *pkt;
    uint32      chan_id;
    uint32      chip_id;
    uint32      packet_length;  /* Total length includes packet length and packet header length if it exits */
    uint32      local_phy_port;
    uint32      dest_queue;
    uint32      from_fabric;
    uint32      mac_num;
    void        *exception;
    bool        channelinfo_ptpen;
    mac_message_type_t mac_msg;
    cm_com_module_bus_t module_bus;
};
typedef struct out_pkt_s out_pkt_t;

struct sim_model_s
{
    int32 (*cm_do_ipe)(ipe_in_pkt_t*, list_head_t*);
    int32 (*cm_do_fwd)(queue_in_pkt_t*, list_head_t*, void*);
    int32 (*cm_do_epe)(epe_in_pkt_t*, list_head_t*);
    int32 (*cm_do_oam)(oam_in_pkt_t*, list_head_t*);
    int32 (*mac_tx[MAX_MACNUM])(out_pkt_t*, bool*);
    int32 (*mac_rx[MAX_MACNUM])(out_pkt_t*, bool*);
    int32 (*macnum2chanid)(uint8, uint32, uint32*);
    int32 (*chanid2macnum)(uint8, uint32, uint32*);
    int32 (*mac_stats_receive)(out_pkt_t*);
    int32 (*mac_stats_transmit)(out_pkt_t*);
    int32 (*sim_write_mem)(uint8, uint32, uint32*, int32);
    int32 (*sim_read_mem)(uint8, uint32, uint32*, int32);
    int32 (*sim_remove_mem)(uint8, uint32);

    int32 (*tcam_init)(uint8);
    int32 (*tcam_lookup)(uint8, uint32, uint32*, uint32*);
    int32 (*tcam_write)(uint8, uint8, uint32, uint32*, int32);
    int32 (*tcam_read)(uint8, uint8, uint32, uint32*, int32);
    int32 (*tcam_mem_dump)(uint8*);
};
typedef struct sim_model_s sim_model_t;

enum chip_type_e
{
    HDR_VERSION_GREATBELT = 0,
    HDR_VERSION_HUMBER = 1
};
typedef enum chip_type_e chip_type_t;

enum mark_color_e
{
    COLOR_RESERVED,
    COLOR_RED,
    COLOR_YELLOW,
    COLOR_GREEN
};
typedef enum mark_color_e mark_color_t;

enum ds_type_e
{
    DS_TYPE_FWD,
    DS_TYPE_L2EDIT,
    DS_TYPE_L3EDIT,
    DS_TYPE_DISCARD,
    DS_TYPE_NUM
};
typedef enum ds_type_e ds_type_t;

enum exception_type_ipe_e
{
    EXCEPTION_TYPE_USER_ID,
    EXCEPTION_TYPE_PROTOCOL_VLAN,
    EXCEPTION_TYPE_LAYER2,
    EXCEPTION_TYPE_LAYER3,
    EXCEPTION_TYPE_ICMP_REDIRECT,
    EXCEPTION_TYPE_LEARNING_CACHE_FULL,
    EXCEPTION_TYPE_ROUTE_MCAST_RPF_FAIL,
    EXCEPTION_TYPE_OTHER
};
typedef enum exception_type_ipe_e exception_type_ipe_t;

enum exception_type_epe_e
{
    EXCEPTION_TYPE_EGRESS_VLAN_XLATE,
    EXCEPTION_TYPE_PARSER_LEN_ERROR,
    EXCEPTION_TYPE_TTL_CHK_FAIL,
    EXCEPTION_TYPE_OAM_1,
    EXCEPTION_TYPE_OAM_2,
    EXCEPTION_TYPE_MTU_CHK_FAIL,
    EXCEPTION_TYPE_STRIP_OFFSET_ERROR,
    EXCEPTION_TYPE_ICMP_ERROR_MSG
};
typedef enum exception_type_epe_e exception_type_epe_t;

enum exception_sub_type_layer2_e
{
    /* 0x1 -- 0x35 User define */
    EXCEPTION_SUB_TYPE_EFM               = 0x0,
    EXCEPTION_SUB_TYPE_SYS_SECURITY      = 0x36,
    EXCEPTION_SUB_TYPE_PARSER_LEN_ERROR  = 0x37,
    EXCEPTION_SUB_TYPE_LAYER2_PTP        = 0x38,
    EXCEPTION_SUB_TYPE_STORM_CTL         = 0x3A,
    EXCEPTION_SUB_TYPE_VSI_SECURITY      = 0x3B,
    EXCEPTION_SUB_TYPE_VLAN_SECURITY     = 0x3C,
    EXCEPTION_SUB_TYPE_PORT_SECURITY     = 0x3D,
    EXCEPTION_SUB_TYPE_SRC_MISMATCH      = 0x3E,
    EXCEPTION_SUB_TYPE_MAC_SA            = 0x3F
};
typedef enum exception_sub_type_layer2_e exception_sub_type_layer2_t;

enum exception_sub_type_other_e
{
    EXCEPTION_SUB_TYPE_RESERVED0             = 0x0,
    EXCEPTION_SUB_TYPE_SGMAC_CTL_MSG         = 0x1,
    EXCEPTION_SUB_TYPE_PARSER_LEN_ERR        = 0x2,
    EXCEPTION_SUB_TYPE_PBB_TCI_NCA           = 0x3,
    EXCEPTION_SUB_TYPE_PTP                   = 0x4,
    EXCEPTION_SUB_TYPE_PLD_OFFSET_ERR        = 0x5,
    EXCEPTION_SUB_TYPE_RESERVED1             = 0x6,
    EXCEPTION_SUB_TYPE_RESERVED2             = 0x7,
    EXCEPTION_SUB_TYPE_ETHERNET_OAM_ERR      = 0x8,
    EXCEPTION_SUB_TYPE_MPLS_OAM_TTL_CHK_FAIL = 0x9,
    EXCEPTION_SUB_TYPE_MPLS_TMPLS_OAM        = 0xA,
    EXCEPTION_SUB_TYPE_DCN                   = 0xB,
    EXCEPTION_SUB_TYPE_RESERVED3             = 0xC,
    EXCEPTION_SUB_TYPE_ACH_ERR               = 0xD,
    EXCEPTION_SUB_TYPE_SECTION_OAM_EXP       = 0xE,
    EXCEPTION_SUB_TYPE_OAM_HASH_CONFLICT     = 0xF,
    EXCEPTION_SUB_TYPE_NO_MEP_MIP_DIS        = 0x10
};
typedef enum exception_sub_type_other_e exception_sub_type_other_t;

enum mux_length_type_e
{
    MUX_LENGTH_TYPE0,
    MUX_LENGTH_TYPE1,
    MUX_LENGTH_TYPE2,
    MUX_LENGTH_TYPE3,
};
typedef enum mux_length_type_e mux_length_type_t;

enum ptp_offset_type_e
{
    PTP_OFFSET_TYPE_PTPV1,
    PTP_OFFSET_TYPE_PTPV2,
    PTP_OFFSET_TYPE_RESERVED,
    PTP_OFFSET_TYPE_OTHER,
    PTP_OFFSET_TYPE_NUM
};
typedef enum ptp_offset_type_e ptp_offset_type_t;

#if (HOST_IS_LE == 0)
/* the following is greatbelt header share fields' define */

union gbhdr_src_ctag_offset_type_u
{
    uint32 src_ctag_offset_type   :1;
    uint32 rxtx_fcl_31            :1;
    uint32 dm_timestamp_61        :1;
    uint32 ptp_timestamp_61       :1;
};
typedef union gbhdr_src_ctag_offset_type_u gbhdr_src_ctag_offset_type_t;

union gbhdr_src_vlanid_u
{
    uint32 src_vlan_id          :12;

    uint32 isid_23_12           :12;

};
typedef union gbhdr_src_vlanid_u gbhdr_src_vlanid_t;


union gbhdr_rxtx_fcl_22_17_u
{
    uint32 rxtx_fcl_22_17                    :6;
    uint32 dm_timestamp_60_55                :6;
    uint32 ptp_timestamp_60_55               :6;
};
typedef union gbhdr_rxtx_fcl_22_17_u gbhdr_rxtx_fcl_22_17_t;

union gdhdr_flow_u
{
    uint32  rev_0                           :8;

    struct
    {
        uint32 flow_id                               :4;
        uint32 rsv                                   :1;
        uint32 is_leaf                               :1;
        uint32 port_mac_sa_en                        :1;
        uint32 from_cpu_lm_up_disable                :1;
    }share1;

};
typedef union gdhdr_flow_u gdhdr_flow_t;

union gbhdr_ttl_u
{
    uint32 ttl                  :8;

    uint32 rxtx_fcl_30_23       :8;
    uint32 dm_timestamp_54_47   :8;
    uint32 ptp_offset           :8;

    struct
    {
        uint32 rev_0            :2;
        uint32 ctag_action      :2;
        uint32 src_ctag_cos     :3;
        uint32 src_ctag_cfi     :1;
    }share1;
};
typedef union gbhdr_ttl_u gbhdr_ttl_t;

union gdhdr_src_port_isolate_id_u
{
    uint32 source_port_isolate_id  :6;

    struct
    {
        uint32 ptp_offset_type   :2;
        uint32 ptp_edit_type       :2;
        uint32 ptp_sequence_id     :2;
    }share1;

    struct
    {
        uint32 oam_dest_chip_id    :5;
        uint32 is_up               :1;
    }share2;
};
typedef union gdhdr_src_port_isolate_id_u gdhdr_src_port_isolate_id_t;

union gbhdr_pbb_src_port_type_u
{
    uint32 pbb_src_port_type        :3;

    struct
    {
        uint32 pt_enable            :1;
        uint32 l4_source_port_valid :1;
        uint32 ip_sa_valid          :1;
    }share1;

    struct
    {
        uint32 lm_received_packet   :1;
        uint32 lm_packet_type       :2;
    }share2;

    struct
    {
        uint32 rev_0                 :1;
        uint32 ptp_extra_offset     :2;
    }share3;
};
typedef union gbhdr_pbb_src_port_type_u gbhdr_pbb_src_port_type_t;


union gbhdr_svlan_tpid_index_u
{
    uint32 svlan_tpid_index                :2;
    struct
    {
        uint32 rev_0                        :1;
        uint32 mpls_label_space_valid      :1;
    }share1;

};
typedef union gbhdr_svlan_tpid_index_u gbhdr_svlan_tpid_index_t;

union gdhdr_loopback_discard_u
{
    uint32 loopback_discard            :1;
    uint32 ds_next_hop_dot_bypass_all  :1;
};
typedef union gdhdr_loopback_discard_u gdhdr_loopback_discard_t;

union gdhdr_src_cvlanid_valid_u
{
    uint32 src_cvlanid_valid       :1;

    uint32 rxtx_fcl_16             :1;
    uint32 dm_timestamp_46         :1;
    uint32 ptp_timestamp_54        :1;
};
typedef union gdhdr_src_cvlanid_valid_u gdhdr_src_cvlanid_valid_t;

union gdhdr_src_cvlanid_u
{
    uint32 src_cvlan_id            :12;

    uint32 isid_11_0               :12;

    uint32 dm_timestamp_45_34      :12;
    uint32 ptp_timestamp_53_42     :12;

    uint32 rxtx_fcl_15_4           :12;
};
typedef union gdhdr_src_cvlanid_u gdhdr_src_cvlanid_t;

union gdhdr_src_vlan_ptr_s
{
    struct
    {
        uint32 from_cpu_lm_down_disable     :1;
        uint32 ingress_edit_en         :1;
        uint32 outer_vlan_is_cvlan     :1;
        uint32 src_vlan_ptr            :13;
    }share1;

    uint32 rev_1                  :16;
};
typedef union gdhdr_src_vlan_ptr_s gdhdr_src_vlan_ptr_t;

union gbhdr_fid_u
{
    struct
    {
        uint32 acl_dscp_valid      :1;
        uint32 capwap_tunnel_valid :1;
        uint32 fid                 :14;
    }share1;

    uint32 rx_fcb_31_16            :16;

    uint32 dm_timestamp_33_18      :16;
    uint32 ptp_timestamp_41_26     :16;

    struct
    {
        uint32 ip_sa_39_32           :8;
        uint32 ip_sa_mode            :2;
        uint32 src_address_mode      :1;
        uint32 ipv4_src_embeded_mode :1;
        uint32 ip_sa_prefix_length   :3;
        uint32 rev_1                 :1;
    }share2;
};
typedef union gbhdr_fid_u gbhdr_fid_t;

union gbhdr_logic_src_port_u
{
    struct
    {
        uint32 rev_0                  :1;
        uint32 pbb_check_discard      :1;
        uint32 logic_src_port         :14;
    }share1;

    uint32 l4_source_port             :16;

    uint32 rx_fcb_15_0                :16;
    uint32 dm_timestamp_17_2          :16;
};
typedef union gbhdr_logic_src_port_u gbhdr_logic_src_port_t;

union gbhdr_rxtx_fcl_3_u
{
    uint32 rxtx_fcl_3                 :1;
    uint32 capwap_tunnel_type         :1;
    uint32 sgmac_strip_header         :1;
    uint32 dm_timestamp_1_1           :1;
    uint32 ptp_timestamp_25_25        :1;
};
typedef union gbhdr_rxtx_fcl_3_u gbhdr_rxtx_fcl_3_t;

union gbhdr_rxtx_fcl_2_1_u
{
    uint32 rxtx_fcl_2_1              :2;
    uint32 capwap_state              :2;
    uint32 ptp_timestamp_24_23       :2;
};
typedef union gbhdr_rxtx_fcl_2_1_u gbhdr_rxtx_fcl_2_1_t;

union gbhdr_rxtx_fcl_0_u
{
    uint32 rxtx_fcl_0               :1;
    uint32 oam_use_fid              :1;
    uint32 c2c_check_disable        :1;
    uint32 ptp_timestamp_22_22      :1;
    uint32 dm_timestamp_0_0         :1;
};
typedef union gbhdr_rxtx_fcl_0_u gbhdr_rxtx_fcl_0_t;

union gbhdr_mep_index_u
{
    uint32 mep_index                     :14;
    struct
    {
        uint32 rev_0                     :2;
        uint32 mpls_label_disable        :4;
        uint32 rev_1                     :8;
    }share1;
};
typedef union gbhdr_mep_index_u gbhdr_mep_index_t;

union gbhdr_ip_sa_u
{
    struct
    {
        uint32 mac_known                 :1;
        uint32 src_dscp                  :6;
        uint32 rev_0                     :5;
        uint32 is_ipv4                   :1;
        uint32 cvlan_tag_operation_valid :1;
        uint32 acl_dscp                  :6;
        uint32 isid_valid                :1;
        uint32 ecn_aware                 :1;
        uint32 congestion_valid          :1;
        uint32 ecn_en                    :1;
        uint32 layer3_offset             :8;
    }share1;

    struct
    {
        uint32 rx_oam                    :1;
        uint32 mip_en_or_cw_added        :1;
        uint32 mep_index                 :14;
        uint32 link_oam                  :1;
        uint32 gal_exist                 :1;
        uint32 entropy_label_exist       :1;
        uint32 oam_type                  :4;
        uint32 dm_en                     :1;
        uint32 rev_1                     :1;
        uint32 local_phy_port            :7;
    }share2;

    struct
    {
        uint32 rx_oam                    :1;
        uint32 mip_en_or_cw_added        :1;
        uint32 mpls_label_disable        :4;
        uint32 rev_2                     :10;
        uint32 link_oam                  :1;
        uint32 gal_exist                 :1;
        uint32 entropy_label_exist       :1;
        uint32 oam_type                  :4;
        uint32 dm_en                     :1;
        uint32 rev_1                     :1;
        uint32 local_phy_port            :7;
    }share3;

    struct
    {
        uint32 mac_known                 :1;
        uint32 src_dscp                  :6;
        uint32 rev_3                     :3;
        uint32 ptp_timestamp_21_0        :22;
    }share4;

    uint32 ip_sa                         :32;

    uint32 tx_fcb_31_0                   :32;
};
typedef union gbhdr_ip_sa_u gbhdr_ip_sa_t;

union gbhdr_outer_timestamp_107_96_u
{
   struct
   {
     uint32 rx_oam    :1;
     uint32 from_cpu_or_oam  :1;
     uint32 oam_type  :4;
     uint32 is_up     :1;
     uint32 link_oam  :1;
     uint32 gal_exist :1;
     uint32 entropy_label_exist  :1;
     uint32 dm_en     :1;
     uint32 mip_en_or_cw_added :1;
   }share1;

   struct
   {
     uint32 ptp_sequence_id   :2;
     uint32 ptp_extra_offset  :2;
     uint32 ptp_edit_type     :2;
     uint32 rev_0             :6;
   }share2;

   struct
   {
     uint32 flow_id           :4;
     uint32 capwap_state      :2;
     uint32 pbb_check_discard :1;
     uint32 rev_1             :5;

   }share3;

   struct
   {
     uint32 dm_offset         :8;
     uint32 rev_2             :4;

   }share4;

   struct
   {
     uint32 l4_source_port_valid  :1;
     uint32 ip_sa_valid           :1;
     uint32 src_address_mode      :1;
     uint32 ipv4_src_embeded_mode :1;
     uint32 pt_enable             :1;
     uint32 ip_sa_prefix_length   :3;
     uint32 ip_sa_mode            :2;
     uint32 rev_3                 :2;
   }share5;

   uint32 timestamp_107_96 :12;
};
typedef union gbhdr_outer_timestamp_107_96_u gbhdr_outer_timestamp_107_96_t;

union gbhdr_outer_timestamp_95_64_u
{
   struct
   {
      uint32 oam_packet_offset7_5  :3;
      uint32 oam_dest_chip  :5;
      uint32 oam_packet_offset4  :1;
      uint32 local_phy_port :7;
      uint32 oam_packet_offset3_2  :2;
      uint32 mep_index    :14;
   }share1;
   struct
   {
      uint32 oam_packet_offset7_5  :3;
      uint32 oam_dest_chip  :5;
      uint32 oam_packet_offset4  :1;
      uint32 local_phy_port :7;
      uint32 oam_packet_offset3_2  :2;
      uint32 mpls_label_disable :4;
      uint32 rev_3  :10;
   }share2;

   struct
   {
      uint32 src_dscp :6;
      uint32 rev_4 :26;
   }share3;

   struct
   {
      uint32 ptp_offset :8;
      uint32 rev_5      :24;
   }share4;

   uint32 timestamp_95_64 ;
};

typedef union gbhdr_outer_timestamp_95_64_u gbhdr_outer_timestamp_95_64_t;

union gbhdr_outer_timestamp_63_32_u
{
   struct
   {
      uint32 l4_source_port  :16;
      uint32 rev_0           :8;
      uint32 ip_sa_39_32     :8;
   }share1;

   struct
   {
      uint32 oam_packet_offset1_0 :2;
      uint32 timestamp_61_32   :30;
   }share2;

   uint32 rev_1;
};

typedef union gbhdr_outer_timestamp_63_32_u gbhdr_outer_timestamp_63_32_t;


union gbhdr_outer_timestamp_31_0_u
{
   uint32 ip_sa_31_0 ;
   uint32 timestamp_31_0 ;
};

typedef union gbhdr_outer_timestamp_31_0_u gbhdr_outer_timestamp_31_0_t;

union gbhdr_outer_oam_tunnel_en_u
{
    uint32 oam_tunnel_en     :1;
    uint32 c2c_disable       :1;

};
typedef union gbhdr_outer_oam_tunnel_en_u gbhdr_outer_oam_tunnel_en_t;

#else

/* the following is greatbelt header share fields' define */
union gbhdr_src_ctag_offset_type_u
{
    uint32 rxtx_fcl_31            :1;
    uint32 src_ctag_offset_type   :1;
    uint32 dm_timestamp_61        :1;
    uint32 ptp_timestamp_61       :1;
};
typedef union gbhdr_src_ctag_offset_type_u gbhdr_src_ctag_offset_type_t;

union gbhdr_src_vlanid_u
{
    uint32 isid_23_12           :12;
    uint32 src_vlan_id          :12;
};
typedef union gbhdr_src_vlanid_u gbhdr_src_vlanid_t;

union gbhdr_rxtx_fcl_22_17_u
{
    uint32 ptp_timestamp_60_55               :6;
    uint32 dm_timestamp_60_55                :6;
    uint32 rxtx_fcl_22_17                    :6;
};
typedef union gbhdr_rxtx_fcl_22_17_u gbhdr_rxtx_fcl_22_17_t;

union gdhdr_flow_u
{
    struct
    {
        uint32 from_cpu_lm_up_disable                :1;
        uint32 port_mac_sa_en                        :1;
        uint32 is_leaf                               :1;
        uint32 rsv                                   :1;
        uint32 flow_id                               :4;
    }share1;

    uint32  rev_0                           :8;

};
typedef union gdhdr_flow_u gdhdr_flow_t;

union gbhdr_ttl_u
{
    uint32 ttl                  :8;

    uint32 rxtx_fcl_30_23       :8;
    uint32 dm_timestamp_54_47   :8;
    uint32 ptp_offset           :8;

    struct
    {
        uint32 src_ctag_cfi     :1;
        uint32 src_ctag_cos     :3;
        uint32 ctag_action      :2;
        uint32 rev_0             :2;
    }share1;
};
typedef union gbhdr_ttl_u gbhdr_ttl_t;

union gdhdr_src_port_isolate_id_u
{
    uint32 source_port_isolate_id  :6;

    struct
    {
        uint32 ptp_sequence_id     :2;
        uint32 ptp_edit_type       :2;
        uint32 ptp_offset_type     :2;
    }share1;

    struct
    {
        uint32 is_up               :1;
        uint32 oam_dest_chip_id    :5;
    }share2;

};
typedef union gdhdr_src_port_isolate_id_u gdhdr_src_port_isolate_id_t;

union gbhdr_pbb_src_port_type_u
{
    uint32 pbb_src_port_type        :3;

    struct
    {
        uint32 ip_sa_valid          :1;
        uint32 l4_source_port_valid :1;
        uint32 pt_enable            :1;
    }share1;

    struct
    {
        uint32 lm_packet_type       :2;
        uint32 lm_received_packet   :1;
    }share2;

    struct
    {
        uint32 ptp_extra_offset     :2;
        uint32 rev_0                 :1;
    }share3;
};
typedef union gbhdr_pbb_src_port_type_u gbhdr_pbb_src_port_type_t;


union gbhdr_svlan_tpid_index_u
{
    uint32 svlan_tpid_index                :2;
    struct
    {
        uint32 mpls_label_space_valid      :1;
        uint32 rev_0                        :1;
    }share1;
};
typedef union gbhdr_svlan_tpid_index_u gbhdr_svlan_tpid_index_t;

union gdhdr_src_cvlanid_valid_u
{
    uint32 rxtx_fcl_16               :1;
    uint32 src_cvlanid_valid         :1;
    uint32 dm_timestamp_46           :1;
    uint32 ptp_timestamp_54          :1;
};
typedef union gdhdr_src_cvlanid_valid_u gdhdr_src_cvlanid_valid_t;

union gdhdr_loopback_discard_u
{
    uint32 ds_next_hop_dot_bypass_all  :1;
    uint32 loopback_discard            :1;
};
typedef union gdhdr_loopback_discard_u gdhdr_loopback_discard_t;


union gdhdr_src_cvlanid_u
{
    uint32 rxtx_fcl_15_4           :12;
    uint32 dm_timestamp_45_34      :12;
    uint32 ptp_timestamp_53_42     :12;
    uint32 isid_11_0               :12;
    uint32 src_cvlan_id            :12;
};
typedef union gdhdr_src_cvlanid_u gdhdr_src_cvlanid_t;

union gdhdr_src_vlan_ptr_s
{
    struct
    {
        uint32 src_vlan_ptr            :13;
        uint32 outer_vlan_is_cvlan     :1;
        uint32 ingress_edit_en         :1;
        uint32 from_cpu_lm_down_disable     :1;
    }share1;

    uint32 rev_1                  :16;
};
typedef union gdhdr_src_vlan_ptr_s gdhdr_src_vlan_ptr_t;

union gbhdr_fid_u
{
    struct
    {
        uint32 fid                   :14;
        uint32 capwap_tunnel_valid   :1;
        uint32 acl_dscp_valid        :1;
    }share1;

    uint32 rx_fcb_31_16              :16;

    uint32 dm_timestamp_33_18        :16;
    uint32 ptp_timestamp_41_26       :16;

    struct
    {
        uint32 rev_1                 :1;
        uint32 ip_sa_prefix_length   :3;
        uint32 ipv4_src_embeded_mode :1;
        uint32 src_address_mode      :1;
        uint32 ip_sa_mode            :2;
        uint32 ip_sa_39_32           :8;
    }share2;
};
typedef union gbhdr_fid_u gbhdr_fid_t;

union gbhdr_logic_src_port_u
{
    struct
    {
        uint32 logic_src_port         :14;
        uint32 pbb_check_discard      :1;
        uint32 rev_0                    :1;
    }share1;

    uint32 l4_source_port             :16;

    uint32 rx_fcb_15_0                :16;

    uint32 dm_timestamp_17_2          :16;

};
typedef union gbhdr_logic_src_port_u gbhdr_logic_src_port_t;

union gbhdr_rxtx_fcl_3_u
{
    uint32 capwap_tunnel_type         :1;
    uint32 rxtx_fcl_3                 :1;
    uint32 sgmac_strip_header         :1;
    uint32 dm_timestamp_1_1           :1;
    uint32 ptp_timestamp_25_25        :1;
};
typedef union gbhdr_rxtx_fcl_3_u gbhdr_rxtx_fcl_3_t;

union gbhdr_rxtx_fcl_2_1_u
{
    uint32 capwap_state               :2;
    uint32 ptp_timestamp_24_23        :2;
    uint32 rxtx_fcl_2_1               :2;
};
typedef union gbhdr_rxtx_fcl_2_1_u gbhdr_rxtx_fcl_2_1_t;

union gbhdr_rxtx_fcl_0_u
{
    uint32 c2c_check_disable        :1;
    uint32 oam_use_fid              :1;
    uint32 rxtx_fcl_0               :1;
    uint32 ptp_timestamp_22_22      :1;
    uint32 dm_timestamp_0_0         :1;
};
typedef union gbhdr_rxtx_fcl_0_u gbhdr_rxtx_fcl_0_t;


union gbhdr_ip_sa_u
{
    struct
    {
        uint32 layer3_offset             :8;
        uint32 ecn_en                    :1;
        uint32 congestion_valid          :1;
        uint32 ecn_aware                 :1;
        uint32 isid_valid                :1;
        uint32 acl_dscp                  :6;
        uint32 cvlan_tag_operation_valid :1;
        uint32 is_ipv4                   :1;
        uint32 rev_0                     :5;
        uint32 src_dscp                  :6;
        uint32 mac_known                 :1;
    }share1;

    struct
    {
        uint32 local_phy_port            :7;
        uint32 rev_1                     :1;
        uint32 dm_en                     :1;
        uint32 oam_type                  :4;
        uint32 entropy_label_exist       :1;
        uint32 gal_exist                 :1;
        uint32 link_oam                  :1;
        uint32 mep_index                 :14;
        uint32 mip_en_or_cw_added        :1;
        uint32 rx_oam                    :1;
    }share2;

    struct
    {
        uint32 local_phy_port            :7;
        uint32 rev_2                     :1;
        uint32 dm_en                     :1;
        uint32 oam_type                  :4;
        uint32 entropy_label_exist       :1;
        uint32 gal_exist                 :1;
        uint32 link_oam                  :1;
        uint32 rev_1                     :10;
        uint32 mpls_label_disable        :4;
        uint32 mip_en_or_cw_added        :1;
        uint32 rx_oam                    :1;
    }share3;

    struct
    {
        uint32 ptp_timestamp_21_0        :22;
        uint32 rev_3                     :3;
        uint32 src_dscp                  :6;
        uint32 mac_known                 :1;
    }share4;

    uint32 ip_sa                         :32;

    uint32 tx_fcb_31_0                   :32;
};
typedef union gbhdr_ip_sa_u gbhdr_ip_sa_t;

union gbhdr_outer_timestamp_107_96_u
{
   struct
   {
     uint32 mip_en_or_cw_added :1;
     uint32 dm_en   :1;
     uint32 entropy_label_exist  :1;
     uint32 gal_exist :1;
     uint32 link_oam  :1;
     uint32 is_up     :1;
     uint32 oam_type  :4;
     uint32 from_cpu_or_oam  :1;
     uint32 rx_oam    :1;

   }share1;

   struct
   {
     uint32 rev_0             :6;
     uint32 ptp_edit_type     :2;
     uint32 ptp_extra_offset  :2;
     uint32 ptp_sequence_id   :2;
   }share2;

   struct
   {
     uint32 rev_1             :5;
     uint32 pbb_check_discard :1;
     uint32 capwap_state      :2;
     uint32 flow_id           :4;
   }share3;

   struct
   {
     uint32 rev_2             :4;
     uint32 dm_offset         :8;
   }share4;

   struct
   {
     uint32 rev_3                 :2;
     uint32 ip_sa_mode            :2;
     uint32 ip_sa_prefix_length   :3;
     uint32 pt_enable             :1;
     uint32 ipv4_src_embeded_mode :1;
     uint32 src_address_mode      :1;
     uint32 ip_sa_valid           :1;
     uint32 l4_source_port_valid  :1;
   }share5;

   uint32 timestamp_107_96 :12;
};
typedef union gbhdr_outer_timestamp_107_96_u gbhdr_outer_timestamp_107_96_t;

union gbhdr_outer_timestamp_95_64_u
{
   struct
   {
      uint32 mep_index    :14;
      uint32 oam_packet_offset3_2  :2;
      uint32 local_phy_port :7;
      uint32 oam_packet_offset4  :1;
      uint32 oam_dest_chip  :5;
      uint32 oam_packet_offset7_5  :3;
   }share1;

   struct
   {
      uint32 rev_3  :10;
      uint32 mpls_label_disable :4;
      uint32 oam_packet_offset3_2  :2;
      uint32 local_phy_port :7;
      uint32 oam_packet_offset4  :1;
      uint32 oam_dest_chip  :5;
      uint32 oam_packet_offset7_5  :3;
   }share2;

    struct
   {
      uint32 rev_4 :26;
      uint32 src_dscp :6;
   }share3;

   struct
   {
      uint32 rev_5      :24;
      uint32 ptp_offset :8;
   }share4;

   uint32 timestamp_95_64 ;
};

typedef union gbhdr_outer_timestamp_95_64_u  gbhdr_outer_timestamp_95_64_t;

union gbhdr_outer_timestamp_63_32_u
{
   struct
   {
      uint32 ip_sa_39_32     :8;
      uint32 rev_0           :8;
      uint32 l4_source_port  :16;
   }share1;

   struct
   {
      uint32 timestamp_61_32   :30;
      uint32 oam_packet_offset1_0  :2;
   }share2;

   uint32 rev_1;
};

typedef union gbhdr_outer_timestamp_63_32_u gbhdr_outer_timestamp_63_32_t;


union gbhdr_outer_timestamp_31_0_u
{
   uint32 ip_sa_31_0 ;
   uint32 timestamp_31_0 ;
};

typedef union gbhdr_outer_timestamp_31_0_u gbhdr_outer_timestamp_31_0_t;


union gbhdr_outer_oam_tunnel_en_u
{
    uint32 oam_tunnel_en     :1;
    uint32 c2c_disable       :1;

};
typedef union gbhdr_outer_oam_tunnel_en_u gbhdr_outer_oam_tunnel_en_t;

#endif



/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/
#define LM_CMD_READ(chip_id, lm_index, cmd, ds_oam_lm_stats) \
do{ \
        if(lm_index < 128) { \
            cmd = DRV_IOR(DsOamLmStats0_t, DRV_ENTRY_FLAG); \
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, lm_index, cmd, &ds_oam_lm_stats)); \
        } else if(lm_index < 256) { \
            cmd = DRV_IOR(DsOamLmStats1_t, DRV_ENTRY_FLAG); \
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, lm_index - 128, cmd, &ds_oam_lm_stats)); \
        } else { \
            ds_oam_lm_stats_t ds_oam_lm_stats_dyn; \
            sal_memset(&ds_oam_lm_stats_dyn, 0, sizeof(ds_oam_lm_stats_t)) ;\
            cmd = DRV_IOR(DsOamLmStats_t, DRV_ENTRY_FLAG);  \
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, lm_index - 256, cmd, &ds_oam_lm_stats_dyn)); \
            ds_oam_lm_stats.rx_fcb_r    = ds_oam_lm_stats_dyn.rx_fcb_r; \
            ds_oam_lm_stats.rx_fcl      = ds_oam_lm_stats_dyn.rx_fcl;   \
            ds_oam_lm_stats.rx_fcl_r    = ds_oam_lm_stats_dyn.rx_fcl_r; \
            ds_oam_lm_stats.tx_fcb_r    = ds_oam_lm_stats_dyn.tx_fcb_r; \
            ds_oam_lm_stats.tx_fcf_r    = ds_oam_lm_stats_dyn.tx_fcf_r; \
            ds_oam_lm_stats.tx_fcl      = ds_oam_lm_stats_dyn.tx_fcl;   \
        } \
}while(0)

#define LM_CMD_WRITE(chip_id, lm_index, cmd, ds_oam_lm_stats) \
do{ \
        if(lm_index < 128) { \
            cmd = DRV_IOW(DsOamLmStats0_t, DRV_ENTRY_FLAG); \
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, lm_index, cmd, &ds_oam_lm_stats)); \
        } else if(lm_index < 256) { \
            cmd = DRV_IOW(DsOamLmStats1_t, DRV_ENTRY_FLAG); \
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, lm_index - 128, cmd, &ds_oam_lm_stats)); \
        } else { \
            ds_oam_lm_stats_t ds_oam_lm_stats_dyn; \
            sal_memset(&ds_oam_lm_stats_dyn, 0, sizeof(ds_oam_lm_stats_t)) ;\
            ds_oam_lm_stats_dyn.rx_fcb_r = ds_oam_lm_stats.rx_fcb_r   ; \
            ds_oam_lm_stats_dyn.rx_fcl   = ds_oam_lm_stats.rx_fcl     ; \
            ds_oam_lm_stats_dyn.rx_fcl_r = ds_oam_lm_stats.rx_fcl_r   ; \
            ds_oam_lm_stats_dyn.tx_fcb_r = ds_oam_lm_stats.tx_fcb_r   ; \
            ds_oam_lm_stats_dyn.tx_fcf_r = ds_oam_lm_stats.tx_fcf_r   ; \
            ds_oam_lm_stats_dyn.tx_fcl   = ds_oam_lm_stats.tx_fcl     ; \
            cmd = DRV_IOW(DsOamLmStats_t, DRV_ENTRY_FLAG);  \
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, lm_index - 256, cmd, &ds_oam_lm_stats_dyn)); \
        } \
}while(0)

extern sim_model_t g_sim_model[];


#define     MAX_LM_INFO_NUM     3
#define     MAX_MEP_LEVEL       8

struct cm_oam_lm_info_s
{
    uint8 valid[MAX_LM_INFO_NUM];
    uint8 is_up[MAX_LM_INFO_NUM];
    uint16 lm_index_base[MAX_LM_INFO_NUM];
    uint8 lm_level[MAX_LM_INFO_NUM];
    uint8 lm_type[MAX_LM_INFO_NUM];
    uint8 lm_cos_type[MAX_LM_INFO_NUM];
    uint8 lm_cos[MAX_LM_INFO_NUM];
};
typedef struct cm_oam_lm_info_s cm_oam_lm_info_t;

/* a+b */
extern cm_uint64_t cm_add64(cm_uint64_t a, cm_uint64_t b);

/* a-b */
extern cm_uint64_t cm_sub64(cm_uint64_t a, cm_uint64_t b);




/****************************************************************************
 *
 * Functions
 *
****************************************************************************/

#endif
