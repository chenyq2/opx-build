/****************************************************************************
 * cm_com_stats.h  Useful statistics for ASIC C-Model.
 * Copyright:      (c)2010 Centec Networks Inc. All rights reserved.
 *
 * Revision:        V1.0.
 * Author:         ZhouW.
 * Date:           2010-09-20.
 * Reason:         First Create.
 ****************************************************************************/
#ifndef _CM_COM_STATS_H_
#define _CM_COM_STATS_H_

/****************************************************************************
 *
* Header Files
*
****************************************************************************/

/****************************************************************************
 *
* Defines and Macros
*
****************************************************************************/
enum stats_type_e
{
    CM_STATS_RAM0_1G,
    CM_STATS_RAM1_1G,
    CM_STATS_RAM2_1G,
    CM_STATS_RAM3_1G,
    CM_STATS_RAM4_1G,
    CM_STATS_RAM5_1G,
    CM_STATS_RAM6_1G,
    CM_STATS_RAM7_1G,
    CM_STATS_RAM8_1G,
    CM_STATS_RAM9_1G,
    CM_STATS_RAM10_1G,
    CM_STATS_RAM11_1G,
    CM_STATS_RAM0_10G,
    CM_STATS_RAM1_10G,
    CM_STATS_RAM2_10G,
    CM_STATS_RAM3_10G,
    CM_STATS_RAM4_10G,
    CM_STATS_RAM5_10G,
    CM_STATS_RAM6_10G,
    CM_STATS_RAM7_10G,
    CM_STATS_RAM8_10G,
    CM_STATS_RAM9_10G,
    CM_STATS_RAM10_10G,
    CM_STATS_RAM11_10G,
    CM_STATS_CPU_MAC,
    CM_STATS_ELOOP,
    CM_STATS_EXCEPTION,
    CM_STATS_COMPLETE_DISCARD,
    CM_STATS_INTERLAKEN_RX_MAC,
    CM_STATS_INTERLAKEN_TX_MAC,
    CM_STATS_DEFAULT, /* use DsStats memory */
    /*
    CM_INGRESS_PORT,
    CM_EGRESS_PORT,
    CM_INGRESS_GLOBAL_FWD,
    CM_EGRESS_GLOBAL_FWD,
    CM_INGRESS_PORT_LOG,
    CM_EGRESS_PORT_LOG,
    CM_FLOW_OR_QUEUE,
    */
    CM_INGRESS_DISCARD,
    CM_EGRESS_DISCARD,
    CM_STATS_MAX
};
typedef enum stats_type_e stats_type_t;

/* temp code, add by zhouw */
#define IPE_DISCARD_TYPE_STATS_OFFSET 0x300
#define EPE_DISCARD_TYPE_STATS_OFFSET 0x400

/****************************************************************************
 *
* Global and Declarations
*
****************************************************************************/
/*******************************************************************************
 * Name   :  sim_increase_statistics
 * Purpose:  Add statistics counter to DsStats.
 * Input  :  .......
 * Output :  ......
 * Return :  SUCCESS
 *           Other   = ErrCode
 * Note   :  N/A
*******************************************************************************/
extern int32
sim_increase_statistics(uint8 chip, uint8 type, uint32 index, uint32 packet_length);

/*******************************************************************************
 * Name   :  sim_clear_statistics
 * Purpose:  Clear DsStats.
 * Input  :  .......
 * Output :  ......
 * Return :  SUCCESS
 *           Other   = ErrCode
 * Note   :  N/A
*******************************************************************************/
extern int32
sim_clear_statistics(uint8 chip, uint8 type, uint32 index);

#endif

