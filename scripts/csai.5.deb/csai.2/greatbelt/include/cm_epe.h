/****************************************************************************
 * cm_epe.h: All packet type Deinfines.
 * Copyright (c)2010 Centec Networks Inc. All rights reserved.
 *
 * Revision:     V1.0.
 * Author:       Zhouw.
 * Date:         2010-11-11.
 * Reason:       First Create.
 *
 * Modify History:
 *
 * Revision:     V1.0.
 * Author:       JiaK.
 * Date:         2010-11-16.
 * Reason:       add members to packetinfo struct.
 ****************************************************************************/
#ifndef _CM_EPE_H_
#define _CM_EPE_H_

#include "cm_com_common.h"
#include "cm_ipe.h"

/* EPE module layer2 edit type value meanings definition */
enum layer2_edit_type_e
{
    L2_ETH_V2,                            /* 0 */
    L2_ETH_SNAP,                          /* 1 */
    L2_ETH_INVALID
};
typedef enum layer2_rewrite_type_e layer2_edit_type_t;

/* EPE module layer2 edit operation type value meanings definition */
enum layer2_rewrite_type_e
{
    L2_REW_NONE,                            /* 0 */
    L2_REW_LOOPBACK,                        /* 1 */
    L2_REW_ETH_4W,                          /* 2 */
    L2_REW_ETH_8W,                          /* 3 */
    L2_REW_MAC_SWAP,                        /* 4 */
    L2_REW_FLEX_8W,                         /* 5 */
    L2_REW_PBB_4W,                          /* 6 */
    L2_REW_PBB_8W,                          /* 7 */
    L2_REW_INVALID
};
typedef enum layer2_rewrite_type_e layer2_rewrite_type_t;

/* EPE module layer3 edit operation type value meanings definition */
enum layer3_rewrite_type_e
{
    L3_REW_NONE,                            /* 0 */
    L3_REW_MPLS_4W,                         /* 1 */
    L3_REW_MPLS_8W,                         /* 2 */
    L3_REW_NAT_4W,                          /* 3 */
    L3_REW_TUNNEL_V4,                       /* 4 */
    L3_REW_TUNNEL_V6,                       /* 5 */
    L3_REW_FLEX,                            /* 6 */
    L3_REW_NAT_8W,                          /* 7 */
    L3_REW_INVALID
};
typedef enum layer3_rewrite_type_e layer3_rewrite_type_t;

/* EPE module payload operation type value meanings definition */
enum cm_payload_op_type_e
{
    CM_PLD_OP_NONE,                         /* 0: Payload no any operation */
    CM_PLD_OP_ROUTE,                        /* 1: Payload Router operation with TTL-1 */
    CM_PLD_OP_BRIDGE,                       /* 2: For egress vlan translation, QinQ ... */
    CM_PLD_OP_BRIDGE_VPLS,                  /* 3: For VPLS horizon split for Humber, to VC for SGMAC */
    CM_PLD_OP_BRIDGE_INNER,                 /* 4: For Inner header VLAN */
    CM_PLD_OP_MIRROR,                       /* 5 */
    CM_PLD_OP_ROUTE_NOTTL,                  /* 6: Payload Router operation without TTL-1 */
    CM_PLD_OP_ROUTE_COMPACT,                /* 7 */
    CM_PLD_OP_MAX_TYPE                      /* 8: Invalid value */
};
typedef enum cm_payload_op_type_e cm_payload_op_type_t;

enum ptp_edit_type_e
{
    PTP_CAPTURE_ONLY,                        /* 0: Capture timestamp and store in register */
    PTP_REPLACE_ONLY,                        /* 1: Capture timestamp and replace to packet */
    PTP_NULL_OPERATION,                      /* 2: Do not take any operation */
    PTP_CORRECTION,                          /* 3: Capture timestamp and calculate the correction field value */
};
typedef enum ptp_edit_type_e ptp_edit_type_t;

enum roaming_state_type_e
{
    HA = 1,          /* 1 */
    FA = 2,          /* 2 */
};
typedef enum roaming_state_type_e roaming_state_type_t;

enum ttl_packet_type_e
{
    TTL_TYPE_IPV4,           /* 0 */
    TTL_TYPE_IPV6,           /* 1 */
    TTL_TYPE_MPLS,           /* 2 */
    TTL_TYPE_TRILL,          /* 3 */
};
typedef enum ttl_packet_type_e ttl_packet_type_t;

enum packet_header_l3_type_e
{
    PKT_HDR_L3_TYPE_IPV4 = 1,
    PKT_HDR_L3_TYPE_IPV6 = 2

};
typedef enum packet_header_l3_type_e packet_header_l3_type_t;

/* EPE module discard type value meanings definition */
enum epe_pktinfo_discard_type_e
{
    /* 0~9 */
    EPE_DISCARD_EPE_HDR_ADJ_DEST_ID_DISCARD,                    /* 0 */
    EPE_DISCARD_EPE_HDR_ADJ_PKT_ERR_DISCARD,                    /* 1 */
    EPE_DISCARD_EPE_HDR_ADJ_BYTE_REMOVE_ERR,                    /* 2 */
    EPE_DISCARD_DEST_PHY_PORT_DEST_ID_DISCARD,                  /* 3 */
    EPE_DISCARD_PORT_ISOLATE_DISCARD,                           /* 4 */
    EPE_DISCARD_DS_VLAN_TRANS_DIS,                              /* 5 */
    EPE_DISCARD_BRG_TO_SAME_PORT_DISCARD,                       /* 6 */
    EPE_DISCARD_VPLS_HORIZON_SPLIT_DISCARD,                     /* 7 */
    EPE_DISCARD_EGRESS_VLAN_FILTER_DISCARD,                     /* 8 */
    EPE_DISCARD_EGRESS_STP_DISCARD,                             /* 9 */

    /* 10~19 */
    EPE_DISCARD_EGRESS_PARSER_LEN_ERR_DISCARD,                  /* 10 */
    EPE_DISCARD_EGRESS_PBB_CHK_DISCARD,                         /* 11 */
    EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD,                      /* 12 */
    EPE_DISCARD_802_3_OAM_DISCARD,                              /* 13 */
    EPE_DISCARD_EGRESS_TTL_FAIL,                                /* 14 */
    EPE_DISCARD_REMOTE_MIRROR_ESCAPE_DISCARD,                   /* 15 */
    EPE_DISCARD_TUNNEL_MTU_CHK_DISCARD,                         /* 16 */
    EPE_DISCARD_INTERFACE_MTU_CHK_DISCARD,                      /* 17 */
    EPE_DISCARD_LOGIC_PORT_CHK_DISCARD,                         /* 18 */
    EPE_DISCARD_EGRESS_ACL_DISCARD,                             /* 19 */

    /* 20~29 */
    EPE_DISCARD_EGRESS_QOS_DISCARD,                             /* 20 */
    EPE_DISCARD_EGRESS_POLICING_DISCARD,                        /* 21 */
    EPE_DISCARD_CRC_ERR,                                        /* 22 */
    EPE_DISCARD_ROUTE_PAYLOAD_OPERATION_DISCARD,                /* 23 */
    EPE_DISCARD_BRG_PAYLOAD_OPERATION_DISCARD,                  /* 24 */
    EPE_DISCARD_PT_LAYER4_OFFSET_LAGER_DISCARD,                 /* 25 */
    EPE_DISCARD_BFD_DISCARD,                                    /* 26 */
    EPE_DISCARD_PORT_REFLECTIVE_CHK_DISCARD,                    /* 27 */
    EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD,                    /* 28 */
    EPE_DISCARD_OAM_EGDE_PORT_DISCARD,                          /* 29 */

    /* 30~39*/
    EPE_DISCARD_NAT_PT_ICMP_ERR,                                /* 30 */
    EPE_DISCARD_RESERVED0,
    EPE_DISCARD_LOCAL_OAM_DISCARD,                              /* 32 */
    EPE_DISCARD_OAM_FILTERING_DISCARD,                          /* 33 */
    EPE_DISCARD_OAM_HASH_CONFILICT_DISCARD,                     /* 34 */
    EPE_DISCARD_IPDA_EQUALS_TO_IPSA_DISCARD,                    /* 35 */
    EPE_DISCARD_RESERVED1,                                      /* 36 */
    EPE_DISCARD_TRILL_PAYLOAD_OPERATION_DISCARD,                /* 37 */
    EPE_DISCARD_PBB_CHK_FAIL_DISCARD,                           /* 38 */
    EPE_DISCARD_DS_NEXT_HOP_DATA_VIOLATE,                       /* 39 */
    EPE_DISCARD_DEST_VLAN_PTR_DISCARD,                          /* 40 */
    EPE_DISCARD_DS_L3_EDIT_DATA_VIOLATE_1,                      /* 41 */
    EPE_DISCARD_DS_L3_EDIT_DATA_VIOLATE_2,                      /* 42 */
    EPE_DISCARD_DS_L3_EDIT_NAT_DATA_VIOLATE,                    /* 43 */
    EPE_DISCARD_DS_L2_EDIT_DATA_VIOLATE_1,                      /* 44 */
    EPE_DISCARD_DS_L2_EDIT_DATA_VIOLATE_2,                      /* 45 */
    EPE_DISCARD_PACKET_HEADER_C2C_TTL_ZERO,                     /* 46 */
    EPE_DISCARD_PT_UDP_CHECKSUM_IS_ZERO,                        /* 47 */
    EPE_DISCARD_OAM_TO_LOCAL_DISCARD,                           /* 48 */
    EPE_DISCARD_TYPE_MAX_NUM
};
typedef enum epe_pktinfo_discard_type_e epe_pktinfo_discard_type_t;

/* EPE module Vlan tag operation value meanings definition */
enum epe_vlantag_operation_type_e
{
    VTAG_OP_NONE,         /* 0: No operation */
    VTAG_OP_REPLACE,      /* 1: Replace vlan tag */
    VTAG_OP_ADD,          /* 2: Add vlan tag */
    VTAG_OP_DELETE,       /* 3: Delete vlan tag */
    VTAG_OP_MAX           /* 4: Invalid Value */
};
typedef enum epe_vlantag_operation_type_e epe_vlantag_operation_type_t;

enum epe_lm_packet_type_e
{
    EPE_LM_PACKET_TYPE_NONE = 0x0,
    EPE_LM_PACKET_TYPE_ETHER_CCM = 0x8,
    EPE_LM_PACKET_TYPE_ETHER_LMM = 0x9,
    EPE_LM_PACKET_TYPE_ETHER_LMR = 0xA,
    EPE_LM_PACKET_TYPE_ACH = 0xB,
    EPE_LM_PACKET_TYPE_TP1731_CCM = 0xC,
    EPE_LM_PACKET_TYPE_TP1731_LMM = 0xD,
    EPE_LM_PACKET_TYPE_TP1731_LMR = 0xE,
};
typedef enum epe_lm_packet_type_e epe_lm_packet_type_t;

enum epe_l2_edit_extra_header_type_e
{
    EXTRA_HEADER_TYPE_NONE=0,
    EXTRA_HEADER_TYPE_ETHERNET,
    EXTRA_HEADER_TYPE_MPLS,
    EXTRA_HEADER_TYPE_NO_L2_EDIT,
};
typedef enum epe_l2_edit_extra_header_type_e epe_l2_edit_extra_header_type_t;

union epe_share_fields_u
{
    struct
    {
        uint32 res                            :32;
        uint32 new_ip_sa_39_32                :8;
        uint32 new_ip_sa_31_0                 :32;
        uint32 new_l4_source_port             :16;
        uint32 new_ip_sa_valid                :1;
        uint32 new_l4_source_port_valid       :1;
        uint32 pt_enable                      :1;
        uint32 ipv4_src_embeded_mode          :1;
        uint32 ip_sa_mode                     :2;
        uint32 src_address_mode               :1;
        uint32 ip_sa_prefix_length            :3;
    }nat;

    struct
    {
        uint32 res                            :30;
        uint32 ptp_edit_type                  :2;
        uint32 ptp_sequence_id                :2;
        uint32 ptp_extra_offset               :2;
        uint32 time_stamp_61_32               :30;
        uint32 time_stamp_31_0                :32;
    }ptp;

    struct
    {
        uint32 lm_packet_type                 :3;
        uint32 tx_fcb                         :32;
        uint32 rx_fcb                         :32;
        uint32 rxtx_fcl                         :32;
    }lmtx;

    struct
    {
        uint32 res                            :6;
        uint32 gal_exist                      :1;
        uint32 entropy_label_exist            :1;
        uint32 oam_dest_chip_id               :5;
        uint32 mep_index                      :14;
        uint32 rx_oam_type                    :4;
        uint32 mip_en                         :1;
        uint32 link_or_section_oam            :1;
        uint32 lm_received_packet             :1;
        uint32 dm_en                          :1;
        uint32 rx_fcb_or_time_stamp_63_32      :32;
        uint32 rxtx_fcl_or_time_stamp_31_0   :32;
    }oam;

    struct
    {
        uint32 res1                           :29;
        uint32 dm_offset                      :8;
        uint32 time_stamp_61_32               :30;
        uint32 time_stamp_31_0                :32;
    }dmtx;
};
typedef union epe_share_fields_u epe_share_fields_t;

struct epe_packet_info_s
{
    void *acl_data0;                                                    /* aclqos */
    void *acl_data1;                                                    /* aclqos */
    void *acl_data2;                                                    /* aclqos */
    void *acl_data3;                                                    /* aclqos */
    void *lm_chan0_data;                                                /* used by epe_acl_qos */
    void *lm_chan1_data;                                                /* used by epe_acl_qos */
    void *lm_chan2_data;                                                /* used by epe_acl_qos */
    void *lm_info0;                                                     /* used by epe_acl_qos */
    void *lm_info1;                                                     /* used by epe_acl_qos */
    void *lm_info2;                                                     /* used by epe_acl_qos */

    void *lm_chan0_data_tcam;                                           /* used by epe_acl_qos */
    void *lm_chan1_data_tcam;                                           /* used by epe_acl_qos */
    void *lm_chan2_data_tcam;                                           /* used by epe_acl_qos */
    void *lm_info0_tcam;                                                /* used by epe_acl_qos */
    void *lm_info1_tcam;                                                /* used by epe_acl_qos */
    void *lm_info2_tcam;                                                /* used by epe_acl_qos */

    uint8 *l3_header;                                                   /* used by epe_layer3_edit */
    uint8 *l2_header;                                                   /* used by epe_layer2_edit */
    uint8 *l2_edit;                                                     /* used by epe_layer2_edit */
    uint8 *l3_edit;                                                     /* used by epe_layer3_edit */
    uint8 *DsNextHopBits;                                               /* used by epe_header_adjust */
    uint32 *parser_result;
    greatbelt_exception_info_t *bexception;                             /* used by epe_header_edit */
    ms_packet_header_t *bheader;                                        /* used by epe_header_edit */
    ms_packet_header_t *old_packet_header;                              /* used by epe_header_adjust */
    epe_share_fields_t share_fields_u;                                  /* used by epe header_adjust */

    uint32 packet_length                        :14;                    /* used by epe_header_adjust */
    uint32 packet_length_adjust_type            :1;                     /* used by epe_header_adjust */
    uint32 packet_length_adjust                 :8;                     /* used by epe_header_adjust */
    uint32 mux_length_type                      :2;
    uint32 discard                              :1;                     /* used by epe_header_adjust */
    uint32 discard_type                         :6;                     /* used by epe_header_adjust */

    uint32 hash_conflict0                       :1;                     /*EPE oam, pop ds, only for CModel*/
    uint32 hash_conflict1                       :1;                     /*EPE oam, pop ds, only for CModel*/
    uint32 hash_conflict2                       :1;                     /*EPE oam, pop ds, only for CModel*/
    uint32 exception                            :8;
    uint32 new_ttl                              :8;                     /* used by epe_payload_process */
    uint32 use_ttl_from_packet                  :1;                     /* used by epe_nexthop_mapper */
    //uint32 egress_filtering_en                  :1;                     /* used by epe_nexthop_mapper */
    uint32 new_ttl_valid                        :1;                     /* used by epe_payload_process */
    uint32 routed_port                          :1;                     /* used by epe_nexthop_mapper */
    uint32 local_phy_port                       :7;                     /* used by epe_header_adjust */

    uint32 flow_policer_ptr                     :13;                    /* used by epe_acl_qos */
    uint32 color                                :2;                     /* used by epe_header_adjust */
    uint32 mapped_cos                           :3;                     /* used by epe_nexthop_mapper */
    uint32 loopback_en                          :1;                     /* used by epe_nexthop_mapper */
    uint32 new_ip_check_sum_valid               :1;                     /* used by epe_payload_process */
    uint32 payload_operation                    :3;                     /* used by epe_nexthop_mapper */
    uint32 src_dscp                             :6;                     /* used by epe_header_adjust */
    uint32 new_cfi                              :1;                     /* used by epe_payload_process */
    uint32 flow_policer_valid                   :1;                     /* used by epe_acl_qos */

    uint32 new_ip_check_sum                     :16;                    /* used by epe_payload_process */
    uint32 new_l4_dest_port_valid               :1;                     /* used by epe_layer3_edit */
    uint32 new_l4_checksum_valid                :1;                     /* used by epe_layer3_edit */
    uint32 new_dscp                             :6;                     /* used by epe_payload_process */
    uint32 packet_ttl                           :8;                     /* used by epe_header_adjust */

    uint32 new_cos                              :3;                     /* used by epe_payload_process */
    uint32 strip_offset                         :8;                     /* used by epe_payload_process */
    uint32 mapped_dscp                          :6;                     /* used by epe_nexthop_mapper */
    uint32 source_cfi                           :1;                     /* used by epe_header_adjust */
    uint32 mapped_exp                           :3;                     /* used by epe_nexthop_mapper */
    uint32 l3_new_header_len                    :7;                     /* used by epe_layer3_edit */
    uint32 resv_0                               :4;

    uint32 dest_map                             :22;                    /* used by epe_header_adjust */
    uint32 new_dscp_valid                       :1;                     /* used by epe_payload_process */
    uint32 acl_log_id0                          :2;                     /* aclqos */
    uint32 acl_log_id1                          :2;                     /* aclqos */

    uint32 acl_log_id2                          :2;                     /* aclqos */
    uint32 acl_log_id3                          :2;                     /* aclqos */
    uint32 next_hop_ptr                         :17;                    /* used by epe_header_adjust */
    uint32 mac_sa                               :8;                     /* used by epe_nexthop_mapper */
    uint32 acl_log_en0                          :1;                     /* aclqos */
    uint32 acl_log_en1                          :1;                     /* aclqos */

    uint32 acl_log_en2                          :1;                     /* aclqos */
    uint32 acl_log_en3                          :1;                     /* aclqos */
    uint32 priority                             :6;                     /* used by epe_header_adjust */
    uint32 source_port                          :16;                    /* used by epe_header_adjust */
    uint32 mcast_ttl_threshold                  :8;                     /* used by epe_nexthop_mapper */
    uint32 l2_span_id                           :2;                     /* used by epe_nexthop_mapper */

    uint32 l2_span_en                           :1;                     /* used by epe_nexthop_mapper */
    uint32 mtu_size                             :14;                    /* used by epe_nexthop_mapper */
    uint32 dest_mux_port_type                   :3;                     /* used by epe_nexthop_mapper */
    uint32 dot1_q_en                            :2;                     /* used by epe_nexthop_mapper */
    uint32 l3_acl_routed_only                   :1;                     /* used by epe_nexthop_mapper */
    uint32 l3_acl_en0                           :1;                     /* used by epe_nexthop_mapper */
    uint32 l3_acl_en1                           :1;                     /* used by epe_nexthop_mapper */
    uint32 l3_acl_en2                           :1;                     /* used by epe_nexthop_mapper */
    uint32 l3_acl_en3                           :1;                     /* used by epe_nexthop_mapper */
    uint32 l3_ipv6_acl_en0                      :1;                     /* used by epe_nexthop_mapper */
    uint32 l3_ipv6_acl_en1                      :1;                     /* used by epe_nexthop_mapper */
    uint32 mtu_exception_en                     :1;                     /* used by epe_nexthop_mapper */
    uint32 replace_dscp                         :1;                     /* used by epe_nexthop_mapper */
    uint32 mtu_check_en                         :1;                     /* used by epe_nexthop_mapper */
    uint32 mcast_flooding_disable               :1;                     /* used by epe_nexthop_mapper */
    uint32 untag_default_vlan_id                :1;                     /* used by epe_nexthop_mapper */

    uint32 global_dest_port                     :14;                    /* used by epe_nexthop_mapper */
    uint32 default_vlan_id                      :12;                    /* used by epe_nexthop_mapper */
    uint32 l2_acl_en0                           :1;                     /* used by epe_nexthop_mapper */
    uint32 l2_acl_en1                           :1;                     /* used by epe_nexthop_mapper */
    uint32 l2_acl_en2                           :1;                     /* used by epe_nexthop_mapper */
    uint32 l2_acl_en3                           :1;                     /* used by epe_nexthop_mapper */
    uint32 bridge_en                            :1;                     /* used by epe_nexthop_mapper */
    uint32 output_svlan_id_valid                :1;                     /* used by epe_nexthop_mapper */

    uint32 output_svlan_id                      :12;                    /* used by epe_nexthop_mapper */
    uint32 output_cvlan_id                      :12;                    /* used by epe_nexthop_mapper */
    uint32 output_cvlan_id_valid                :1;                     /* used by epe_nexthop_mapper */
    uint32 port_policer_valid                   :1;                     /* used by epe_nexthop_mapper */
    uint32 acl_port_num                         :6;                     /* used by epe_nexthop_mapper */

    uint32 ucast_flooding_disable               :1;                     /* used by epe_nexthop_mapper */
    uint32 l2_ipv6_acl_en0                      :1;                     /* used by epe_nexthop_mapper */
    uint32 l2_ipv6_acl_en1                      :1;                     /* used by epe_nexthop_mapper */
    uint32 pbb_src_port_type                    :3;                     /* used by epe_header_adjust */
    uint32 pbb_dest_port_type                   :3;                     /* used by epe_nexthop_mapper */
    uint32 force_ipv4_to_mackey                 :1;                     /* used by epe_nexthop_mapper */
    uint32 force_ipv6_to_mackey                 :1;                     /* used by epe_nexthop_mapper */
    uint32 packet_type                          :3;                     /* used by epe_header_adjust */
    uint32 header_packet_type                   :3;
    uint32 source_cos                           :3;                     /* used by epe_header_adjust */
    uint32 source_port_isolate_id               :6;                     /* used by epe_header_adjust */
    uint32 next_hop_ext                         :1;                     /* used by epe_header_adjust */
    uint32 svlan_tag_operation                  :2;                     /* used by epe_payload_process */
    uint32 cvlan_tag_operation                  :2;                     /* used by epe_payload_process */
    uint32 stag_operation_disable               :1;                     /* used by epe_nexthop_mapper */
    uint32 ctag_operation_disable               :1;                     /* used by epe_nexthop_mapper */
    uint32 stag_action                          :2;                     /* used by epe_header_adjust */

    uint32 ctag_action                          :2;                     /* used by epe_header_adjust */
    uint32 svlan_id_action                      :2;                     /* used by epe_nexthop_mapper */
    uint32 cvlan_id_action                      :2;                     /* used by epe_nexthop_mapper */
    uint32 src_cvlan_id_valid                   :1;                     /* used by epe_header_adjust */
    uint32 src_cvlan_id                         :12;                    /* used by epe_header_adjust */
    uint32 src_svlan_id_valid                   :1;                     /* used by epe_header_adjust */
    uint32 stag_cos_action                      :2;                     /* used by epe_nexthop_mapper */
    uint32 ctag_cos_action                      :2;                     /* used by epe_nexthop_mapper */
    uint32 src_ctag_cos                         :3;                     /* used by epe_header_adjust */
    uint32 src_ctag_cfi                         :1;                     /* used by epe_header_adjust */
    uint32 src_ctag_offset_type                 :1;                     /* used by epe_header_adjust */
    uint32 l3_span_en                           :1;                     /* used by epe_nexthop_mapper */
    uint32 ctag_add_mode                        :1;                     /* used by epe_nexthop_mapper */
    uint32 svlan_xlate_valid                    :1;                     /* used by epe_nexthop_mapper */

    uint32 cvlan_xlate_valid                    :1;                     /* used by epe_nexthop_mapper */
    uint32 vlan_xlate_mode                      :1;                     /* used by epe_nexthop_mapper */
    uint32 xlate_svlan_tpid_index_en            :1;                     /* used by epe_nexthop_mapper */
    uint32 xlate_svlan_tpid_index               :2;                     /* used by epe_nexthop_mapper */
    uint32 xlate_svlan_id                       :12;                    /* used by epe_nexthop_mapper */
    uint32 xlate_stag_cos                       :3;                     /* used by epe_nexthop_mapper */
    uint32 xlate_stag_cfi                       :1;                     /* used by epe_nexthop_mapper */
    uint32 xlate_ctag_cfi                       :1;                     /* used by epe_nexthop_mapper */
    uint32 cvlan_tagged                         :1;                     /* used by epe_nexthop_mapper */
    uint32 svlan_tagged                         :1;                     /* used by epe_nexthop_mapper */
    uint32 xlate_ctag_cos                       :3;                     /* used by epe_nexthop_mapper */
    uint32 xlate_cvlan_id                       :12;                    /* used by epe_nexthop_mapper */
    uint32 src_vlan_ptr                         :13;                    /* used by epe_header_adjust */
    uint32 stp_check_en                         :1;                     /* used by epe_nexthop_mapper */
    uint32 untag_default_svlan                  :1;                     /* used by epe_nexthop_mapper */
    uint32 cvlan_id_offset_type                 :1;                     /* used by epe_payload_process */
    uint32 svlan_tpid_index                     :2;                     /* used by epe_nexthop_mapper */
    uint32 new_ip_da_valid                      :1;                     /* used by epe_layer3_edit */

    uint32 l2_new_svlan_tag                     :32;                    /* used by epe_layer2_edit */
    uint32 l2_new_cvlan_tag                     :32;                    /* used by epe_layer2_edit */

    uint32 logic_src_port                       :14;                    /* used by epe_header_adjust */
    uint32 discard_non_8023_oam                 :1;                     /* used by epe_nexthop_mapper */

    uint32 dest_vlan_ptr                        :13;                    /* used by epe_nexthop_mapper */
    uint32 port_mac_sa_en                       :1;                     /* used by epe_header_adjust */
    uint32 l3_span_id                           :2;                     /* used by epe_nexthop_mapper */
    uint32 port_log_en                          :1;                     /* used by epe_nexthop_mapper */
    uint32 ipg_index                            :2;                     /* used by epe_nexthop_mapper */
    uint32 mapped_cfi                           :1;                     /* used by epe_nexthop_mapper */
    uint32 random_log_en                        :1;                     /* used by epe_nexthop_mapper */
    uint32 new_macsa_valid                      :1;                     /* used by epe_layer2_edit */
    uint32 logic_port_check                     :1;                     /* used by epe_nexthop_mapper */
    uint32 service_acl_qos_en                   :1;                     /* used by epe_nexthop_mapper */
    uint32 exception_en                         :1;                     /* used by epe_nexthop_mapper */    /* 3->2 */
    uint32 svlan_tag_disable                    :1;                     /* used by epe_nexthop_mapper */
    uint32 cvlan_tag_disable                    :1;                     /* used by epe_nexthop_mapper */
    uint32 oam_tunnel_en                        :1;                     /* used by epe_header_adjust */

    uint32 ptp_offset                           :8;                     /* used by epe_nexthop_mapper */
    uint32 fid                                  :14;                    /* used by epe_header_adjust */
    uint32 outer_vlan_is_cvlan                  :1;                     /* used by epe_header_adjust */
    uint32 derive_stag_cos                      :1;                     /* used by epe_nexthop_mapper */
    uint32 replace_stag_cos                     :1;                     /* used by epe_nexthop_mapper */
    uint32 replace_ctag_cos                     :1;                     /* used by epe_nexthop_mapper */
    uint32 resv_1                               :5;

    uint32 new_macda_lower32                    :32;                    /* used by epe_layer2_edit */
    uint32 new_macsa_lower32                    :32;                    /* used by epe_layer2_edit */

    uint32 new_macda_upper16                    :16;                    /* used by epe_layer2_edit */
    uint32 new_macsa_upper16                    :16;                    /* used by epe_layer2_edit */

    uint32 mcast_id                             :14;                    /* used by epe_header_adjust */
    uint32 logic_dest_port                      :14;                    /* used by epe_nexthop_mapper */
    uint32 copy_ctag_cos                        :1;                     /* used by epe_nexthop_mapper */
    uint32 service_policer_valid                :1;                     /* used by epe_nexthop_mapper */
    uint32 stag_cfi                             :1;                     /* used by epe_nexthop_mapper */
    uint32 copy_dscp                            :1;                     /* used by epe_nexthop_mapper */

    uint32 stag_cos                             :3;                     /* used by epe_nexthop_mapper */
    uint32 new_itag_valid                       :1;                     /* used by epe_nexthop_mapper */
    uint32 new_macda_valid                      :1;                     /* used by epe_layer2_edit */
    uint32 new_itag                             :24;                    /* used by epe_nexthop_mapper */
    uint32 itag_offset_type                     :1;                     /* used by epe_layer2_edit */
    uint32 mirror_tag_add                       :1;                     /* used by epe_nexthop_mapper */
    uint32 tagged_mode                          :1;                     /* used by epe_nexthop_mapper */

    uint32 parser_length                        :14;                    /* used by epe_header_adjust */
    uint32 layer3_offset                        :8;                     /* used by epe_acl_qos */
    uint32 layer4_offset                        :8;                     /* used by epe_acl_qos */
    uint32 tpid_swap                            :1;                     /* used by epe_nexthop_mapper */
    uint32 cos_swap                             :1;                     /* used by epe_nexthop_mapper */

    uint32 inner_svlan_tpid_en                  :1;                     /* used by epe_nexthop_mapper */
    uint32 inner_svlan_tpid_index               :2;                     /* used by epe_nexthop_mapper */
    uint32 header_hash                          :8;                     /* used by epe_header_adjust */
    uint32 logic_port_type                      :1;                     /* used by epe_header_adjust */
    uint32 lm_write_packet                      :1;                     /* used by epe_header_adjust */
    uint32 mac_da_svlan_en                      :1;                     /* used by epe_nexthop_mapper */
    uint32 fcoe_oui_index                       :8;                     /* used by epe_nexthop_mapper */
    uint32 route_no_l2_edit                     :1;                     /* used by epe_nexthop_mapper */
    uint32 resv_3                               :4;

    uint32 new_ip_sa63_32;                                              /* used by epe_layer3_edit */
    uint32 new_ip_sa95_64;                                              /* used by epe_layer3_edit */
    uint32 new_ip_sa127_96;                                             /* used by epe_layer3_edit */

    uint32 mac_47_to_32                         :16;                    /* used by epe_nexthop_mapper */
    uint32 from_cpu_or_oam                      :1;                     /* used by epe_header_adjust */
    uint32 ether_oam_valid                      :1;                     /* used by epe_nexthop_mapper */
    uint32 lm_lookup_type                       :2;                     /* used by epe_nexthop_mapper */
    uint32 src_leaf                             :1;                     /* used by epe_header_adjust */
    uint32 is_leaf                              :1;                     /* used by epe_nexthop_mapper */
    uint32 ctag_dei_en                          :1;                     /* used by epe_nexthop_mapper */
    uint32 port_mac_sa_type                     :1;                     /* used by epe_nexthop_mapper */

    uint32 mac_31_to_0                          :32;                    /* used by epe_nexthop_mapper */

    uint32 interface_id                         :10;                    /* used by epe_nexthop_mapper */
    uint32 interface_vlan_id                    :12;                    /* used by epe_nexthop_mapper */
    uint32 interface_vlan_id_en                 :1;                     /* used by epe_nexthop_mapper */
    uint32 interface_svlan_tagged               :1;                     /* used by epe_nexthop_mapper */
    uint32 flow_stats0_valid                    :1;                     /* used by epe_acl_qos */
    uint32 flow_stats1_valid                    :1;                     /* used by epe_acl_qos */

    uint32 flow_stats2_valid                    :1;                     /* used by epe_nexthop_mapper */
    uint32 tx_dm_en                             :1;                     /* used by epe_header_adjust */
    uint32 dm_offset                            :8;
    uint32 new_ttl_packet_type                  :2;                     /* used by epe_payload_process */
    uint32 stp_id                               :7;                     /* used by epe_nexthop_mapper */
    uint32 mcast                                :1;                     /* used by epe_nexthop_mapper */
    uint32 port_mac_sa                          :8;                     /* used by epe_nexthop_mapper */
    uint32 operation_type                       :3;                     /* used by epe_header_adjust */
    uint32 tmp_complete_discard                 :1;                     /* used by epe_header_edit */

    uint32 flow_stats0_ptr                      :16;                    /* aclqos */
    uint32 flow_stats1_ptr                      :16;                    /* aclqos */

    uint32 flow_stats2_ptr                      :16;                    /* used by epe_nexthop_mapper */
    uint32 oam_use_fid                          :1;                     /* used by epe_header_adjust */
    uint32 ptp_id                               :1;                     /* used by epe_header_adjust */

    uint32 l2_new_header_len                    :5;                     /* used by epe_layer2_edit */
    uint32 cw_add                               :1;                     /* used by epe_header_adjust */
    uint32 ether_oam_edge_port                  :1;                     /* used by epe_nexthop_mapper */
    uint32 oam_lookup_en                        :1;                     /* used by epe_acl_qos */
    uint32 mpls_section_lm_en                   :1;                     /* used by epe_nexthop_mapper */
    uint32 src_vlan_id                          :12;                    /* used by epe_header_adjust */
    uint32 roaming_state                        :2;                     /* used by epe_header_adjust */

    uint32 asymmetry_delay31_0                  :32;                    /* used by epe_nexthop_mapper */

    uint32 new_l4_dest_port                     :16;                    /* used by epe_layer3_edit */
    uint32 new_l4_check_sum                     :16;                    /* used by epe_layer3_edit */

    uint32 new_ip_da;                                                   /* used by epe_layer3_edit */
    uint32 new_ip_da63_32;                                              /* used by epe_layer3_edit */
    uint32 new_ip_da95_64;                                              /* used by epe_layer3_edit */
    uint32 new_ip_da127_96;                                             /* used by epe_layer3_edit */

    uint32 link_oam2_lm_en                      :1;                     /* used by epe_layer3_edit */
    uint32 link_oam1_lm_en                      :1;                     /* used by epe_layer3_edit */
    uint32 bcast_mac_addr                       :1;
    uint32 mcast_mac_addr                       :1;
    uint32 tmp_stats_length                     :14;                    /* used by epe_header_edit */
    uint32 tmp_strip_error                      :1;                     /* used by epe_header_edit */
    uint32 port_reflective_discard              :1;                     /* used by epe_nexthop_mapper */
    uint32 default_pcp                          :3;                     /* used by epe_nexthop_mapper */
    uint32 mpls_lm_valid0                       :1;                     /* used by epe_layer3_edit */
    uint32 mpls_lm_valid1                       :1;                     /* used by epe_layer3_edit */
    uint32 mpls_lm_valid2                       :1;                     /* used by epe_layer3_edit */
    uint32 section_lm_exp                       :3;                     /* used by epe_layer3_edit */

    uint32 mpls_lm_label0                       :20;                    /* used by epe_layer3_edit */
    uint32 mpls_lm_label1                       :20;                    /* used by epe_layer3_edit */
    uint32 mpls_lm_exp0                         :3;                     /* used by epe_layer3_edit */
    uint32 mpls_lm_exp1                         :3;                     /* used by epe_layer3_edit */
    uint32 mpls_lm_exp2                         :3;                     /* used by epe_layer3_edit */
    uint32 resv_4                               :1;
    uint32 to_tx_timestamp_62                   :1;                     /* used by header editing */
    uint32 acl_en0                              :1;                     /* aclqos */
    uint32 acl_en1                              :1;                     /* aclqos */
    uint32 acl_en2                              :1;                     /* aclqos */
    uint32 acl_en3                              :1;                     /* aclqos */
    uint32 lm_lookup_en0                        :1;                     /* used by epe_acl_qos */
    uint32 lm_lookup_en1                        :1;                     /* used by epe_acl_qos */
    uint32 lm_lookup_en2                        :1;                     /* used by epe_acl_qos */
    uint32 lm_result_valid0                     :1;                     /* CModel uses to pass paramters between files, not by spec*/
    uint32 lm_result_valid1                     :1;                     /* CModel uses to pass paramters between files, not by spec*/
    uint32 lm_result_valid2                     :1;                     /* CModel uses to pass paramters between files, not by spec*/

    uint32 mpls_lm_label2                       :20;                    /* used by epe_layer3_edit */
    uint32 packet_cos0                          :3;                     /* used by epe_acl_qos */
    uint32 packet_cos1                          :3;                     /* used by epe_acl_qos */
    uint32 packet_cos2                          :3;                     /* used by epe_acl_qos */
    uint32 oam_tcam_lookup_en                   :1;                     /* used by epe_acl_qos */
    uint32 lm_result_valid0_tcam                :1;                     /* used by epe_acl_qos */
    uint32 lm_result_valid1_tcam                :1;                     /* used by epe_acl_qos */

    uint32 lm_result_valid2_tcam                :1;                     /* used by epe_acl_qos */
    uint32 oam_lookup_num                       :2;                     /* used by epe_acl_qos */
    uint32 evb_default_local_phy_port_valid     :1;                     /* used by epe_nexthop_mapper */
    uint32 evb_default_logic_port_valid         :1;
    //uint32 oam_offset                           :1;                     /* used by epe_header_adjust */
    uint32 default_logic_dest_port              :14;                    /* used by epe_nexthop_mapper */
    uint32 next_hop_offset                      :2;
    uint32 non_crc                              :1;                     /* used by epe_header_adjust */
    uint32 congestion_valid                     :1;                     /* used by epe_header_adjust */
    uint32 mac_known                            :1;                     /* used by epe_header_adjust */

    uint32 is_up                                :1;                     /* used by epe_header_adjust */
    uint32 vlan_use_src                         :1;                     /* used by epe_nexthop_mapper */
    uint32 known_mcast_flooding_disable         :1;                     /* used by epe_nexthop_mapper */
    uint32 bcast_flooding_disable               :1;                     /* used by epe_nexthop_mapper */
    uint32 flooding_discard_type                :1;                     /* used by epe_nexthop_mapper */
    uint32 udp_ptp                              :1;                     /* used by epe_nexthop_mapper */
    uint32 ptp_offset_type                      :2;                     /* used by epe_nexthop_mapper */
    uint32 ether_oam_discard                    :1;                     /* used by epe_nexthop_mapper */
    uint32 agg_flow_policer_valid               :1;                     /* aclqos */
    uint32 agg_flow_policer_ptr                 :13;                    /* aclqos */
    uint32 exception_index                      :3;                     /* used by epe_nexthop_mapper */
    uint32 aps_protecting_en1                   :1;                     /* used by epe_header_adjust */
    uint32 aps_protecting_en2                   :1;                     /* used by epe_header_adjust */
    uint32 pbb_check_discard                    :1;                     /* used by epe_header_adjust */
    uint32 link_oam_en                          :1;                     /* used by epe_next_hop_mapper */

    uint32 ipv6_key_use_label                   :1;                     /* aclqos */
    uint32 ipv4_key_use_label                   :1;                     /* aclqos */
    uint32 mpls_key_use_label                   :1;                     /* aclqos */
    uint32 mac_key_use_label                    :1;                     /* aclqos */
    uint32 l3_acl_label                         :10;                    /* aclqos */
    uint32 l2_acl_label                         :10;                    /* aclqos */
    uint32 entropy_label_exist                  :1;                     /* used by epe_header_adjust */
    uint32 link_lm_type                         :2;                     /* used by epe_nexthop_mapper */
    uint32 link_lm_cos                          :3;                     /* used by epe_nexthop_mapper */
    uint32 link_lm_cos_type                     :2;                     /* used by epe_nexthop_mapper */

    uint32 gal_exist                            :1;                     /* used by epe_header_adjust */
    uint32 l2_match                             :1;                     /* used by epe_nexthop_mapper */
    uint32 is_port_mac                          :1;                     /* used by epe_l2_edit */
    uint32 bypass_all                           :1;                     /* used by epe_header_adjust */
    uint32 ds_nexthop_dot_bypass_all            :1;
    uint32 tunnel_mtu_check                     :1;                     /* used by epe_nexthop_mapper */
    uint32 tunnel_mtu_size                      :14;                    /* used by epe_nexthop_mapper */
    uint32 ingress_header_valid                 :1;                     /* used by epe_header_adjust */
    uint32 l3_edit_ptr_bit0                     :1;                     /* used by epe_nexthop_mapper */
    uint32 l2_edit_ptr_bit0                     :1;                     /* used by epe_nexthop_mapper */
    uint32 mpls_label_disable                   :4;                     /* used by epe_header_adjust */
    uint32 s_cfi_action                         :2;                     /* used by epe_nexthop_mapper */
    uint32 c_cfi_action                         :2;                     /* used by epe_nexthop_mapper */
    uint32 priority_tag_en                      :1;                     /* used by epe_nexthop_mapper */

    uint32 ingress_header_dest_map              :22;                    /* used by epe_header_adjust */
    uint32 ingress_header_header_hash           :8;                     /* used by epe_header_adjust */
    uint32 ingress_header_color                 :2;                     /* used by epe_header_adjust */

    uint32 ingress_header_source_port           :14;                    /* used by epe_header_adjust */
    uint32 ingress_header_operation_type        :3;                     /* used by epe_header_adjust */
    uint32 ingress_header_priority              :6;                     /* used by epe_header_adjust */
    uint32 mpls_label_space                     :8;                     /* used by epe_nexthop_mapper */
    uint32 source_port_extender                 :1;                     /* used by epe_header_adjust */

    uint32 is_tcp                               :1;                     /* used by acl */
    uint32 is_udp                               :1;                     /* used by acl */
    uint32 parser_offset                        :3;                     /* used by epe_header_adjust */
    uint32 ds_l3_edit_exist                     :1;                     /* used by epe_next_hop_mapper */
    uint32 ds_l2_edit_exist                     :1;                     /* used by epe_next_hop_mapper */
    uint32 asymmetry_delay35_32                 :4;                     /* used by epe_next_hop_mapper */
    uint32 source_channel_link_aggregate_en     :1;                     /* used by epe_layer2_edit */
    uint32 source_channel_link_aggregate        :7;                     /* used by epe_layer2_edit */
    uint32 dest_channel_link_aggregate_en       :1;                     /* used by epe_layer2_edit */
    uint32 dest_channel_link_aggregate          :7;                     /* used by epe_layer2_edit */
    uint32 link_lm_index_base                   :14;                    /* uded by epe_nexthop_mapper */
    uint32 ether_lm_valid                       :1;                     /* uded by epe_nexthop_mapper */
    uint32 use_logic_port                       :1;                     /* uded by epe_nexthop_mapper */
    uint32 packet_header_en_egress              :1;                     /* used by epe_header_adjust */
    uint32 from_fabric                          :1;                     /* used by epe_header_adjust */
    uint32 packet_header_en                     :1;                     /* used by epe_header_adjust */
    uint32 acl_dscp_valid                       :1;                     /* used by epe_header_adjust */
    uint32 force_ipv6_key                       :1;                     /* used by epe_header_adjust */
    uint32 default_dei                          :1;                     /* used by epe_header_adjust */
    uint32 old_svlan_id                         :12;                    /* used by epe_payload_process */
    uint32 old_stag_cos                         :3;                     /* used by epe_payload_process */
    uint32 old_stag_cfi                         :1;                     /* used by epe_payload_process */
    uint32 old_cvlan_id                         :12;                    /* used by epe_payload_process */
    uint32 old_ctag_cos                         :3;                     /* used by epe_payload_process */
    uint32 old_ctag_cfi                         :1;                     /* used by epe_payload_process */
    uint32 l2_header_added                      :1;                     /* used by epe_nexthop_mapper */
    uint32 mac_da_mcast_mode                    :1;                     /* used by epe_nexthop_mapper */
    uint32 checksum_old_dscp                    :6;                     /* used by epe_payload_process */
    uint32 new_ip_checksum                      :16;                    /* used by epe_layer3_edit */
    uint32 link_or_section_oam                  :1;                     /* used by epe_header_adjust */
    uint32 ttl_no_decrease                      :1;                     /* used by epe_nexthop_mapper */
    uint32 l3_rewrite_type                      :3;                     /* used by epe_layer3_edit */
    uint32 share_type                           :3;                     /* used by epe header_adjust */
    uint32 frag_info                            :2;                     /* used by epe header_edit */
    uint32 ingress_edit_en                      :1;                     /* used by epe_header_adjust */
    uint32 egress_logic_port_check_en           :1;                     /* used by epe_header_adjust */
    uint32 mac_sa_type                          :2;                     /* used by epe_next_hop */
    uint32 default_logic_port_check_en          :1;                     /* used by epe_next_hop */
    uint32 default_physical_port_check_en       :1;                     /* used by epe_next_hop */
    uint32 default_logic_dest_port_check_en     :1;                     /* used by epe_next_hop */
    uint32 mirrored_packet                      :1;                     /* used by epe_payload */
    uint32 cvlan_space                          :1;
    uint32 bridge_operation                     :1;                     /* used by epe_header_adjust */
    uint32 ingress_edit_nexthop_bypass_all      :1;                     /* used by epe_header_adjust */
    uint32 oam_vlan_valid                       :1;                     /* used by epe_payload */
    uint32 oam_vlan                             :12;                    /* used by epe_payload */
    uint32 oam_cos                              :3;                     /* used by epe_payload */
    uint32 port_loopback_index                  :3;                     /* used by epe_nexthop_mapper */

    uint32 lm_packet_type                       :4;                     /*tmp for share fields*/
    uint32 rx_oam_type                          :4;

    uint32 from_cpu_lm_down_disable             :1;
    uint32 from_cpu_lm_up_disable               :1;

    uint32 ingress_header_ip_da;                                        /* used by epe_header_edit */
    uint32 checksum_old_ecn                     :2;
    ms_packet_header_t *ingress_header;                                 /* used by epe_header_adjust */

};
typedef struct epe_packet_info_s epe_packet_info_t;

extern int32
cm_epe_header_adjust_handle(epe_in_pkt_t* ipkt);

extern int32
cm_epe_nexthop_mapper_handle(epe_in_pkt_t* ipkt);

extern int32
cm_epe_payload_process_handle(epe_in_pkt_t* ipkt);

extern int32
cm_epe_layer3_editing_handle(epe_in_pkt_t *ipkt);

extern int32
cm_epe_layer2_editing_handle(epe_in_pkt_t *ipkt);

extern int32
cm_epe_aclqos_handle(epe_in_pkt_t *ipkt);

extern int32
cm_epe_classification_handle(epe_in_pkt_t *ipkt);

extern int32
cm_epe_oam_process_handle(epe_in_pkt_t *ipkt);

extern int32
cm_epe_header_editing_handle(epe_in_pkt_t *ipkt);

extern int32
cm_epe_net_tx_handle(epe_in_pkt_t* ipkt, list_head_t* out_pkt_l);

#endif


