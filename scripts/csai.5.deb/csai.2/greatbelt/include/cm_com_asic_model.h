/****************************************************************************
 * cm_com_asic_model.h    All ASIC model Deinfines and routines.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiang.
 * Date:         2010-11-1.
 * Reason:       First Create.
 ****************************************************************************/
#ifndef _CM_COM_ASIC_DV_H_
#define _CM_COM_ASIC_DV_H_

#include "cm_ipe.h"
#include "cm_fwd.h"
#include "cm_epe.h"
#include "cm_oam.h"
#include "ctcutil_list.h"

extern int32
cm_do_ipe(ipe_in_pkt_t *in_pkt, list_head_t *out_pkt);

extern int32
cm_do_fwd(queue_in_pkt_t *in_pkt, list_head_t *out_pkt, void *pkt_buf_info);

extern int32
cm_do_epe(epe_in_pkt_t *in_pkt, list_head_t *out_pkt);

extern int32
cm_do_oam(oam_in_pkt_t* in_pkt, list_head_t *out_pkt);

#endif

