/****************************************************************************
 * sim_interface.h
 *
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V4.29.3.
 * Author:       ZhouW
 * Date:         2011-10-24
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#ifndef _SIM_INTERFACE_H_
#define _SIM_INTERFACE_H_

#define COSIM_DEBUG_CFG "cosim_debug_flag.cfg"

#include "sim_common.h"

extern char* sim_module_name[];
extern char* sim_ipe_bus_name[];
extern char* sim_bsr_bus_name[];
extern char* sim_epe_bus_name[];
extern char* sim_oam_bus_name[];
extern char** sim_x_bus[];
extern list_head_t* sim_x_moduel_list[];

/* cosim API */
struct cosim_api_callback_fun_s
{
    int32(*cmp_ipe_bus[SIM_IPE_NUM])(void*, bool*);
    int32(*cmp_epe_bus[SIM_EPE_NUM])(void*, bool*);
    int32(*cmp_bsr_bus[SIM_BSR_NUM])(void*, bool*);
    int32(*cmp_oam_bus[SIM_OAM_NUM])(void*, bool*);

    int32(*cmp_key)(uint32, uint8*, bool*);
    int32(*cmp_outpkt)(uint32, uint32, uint32, uint8*, uint8, bool*);
    int32(*cmp_table)(rtl_tbl_info_t*, bool*);
    int32(*cmp_bhdr)(void*, uint8, bool*, bool*);

    int32(*tblname_to_id)(uint32*, char*);
    void(*get_buf_info)(uint32, uint32, uint32, uint32, uint32);
    int32(*do_tail_drop)(void*, bool*);
    int32(*do_module)(uint32, uint32, uint32, uint8*, uint8, void*);
    int32(*chk_linklist)(void);
    int32(*oam_update)(uint32, uint32, cosim_oam_update_type_t, uint32, uint32);
};
typedef struct cosim_api_callback_fun_s cosim_api_callback_fun_t;

/*********************************************/
/* init Cosim interfaces and cmodel */
extern int32
sim_interface_init(char*, char*, bool);

/* release Cosim interfaces and cmodel */
extern int32 sim_interface_release(void);
extern int32 sim_interface_load_debug_bus_cfg(char*);
extern bool sim_field_compare(uint32, uint32, char*);
extern int32 sim_check_key(uint32, uint32*, uint32*, bool*);

extern cosim_api_callback_fun_t cosim_api;

#endif

