/****************************************************************************
 * sim_key_chk_interface.h
 *
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V4.29.3.
 * Author:       ZhouW
 * Date:         2011-11-12
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#ifndef _SIM_KEY_CHK_INTERFACE_H_
#define _SIM_KEY_CHK_INTERFACE_H_

#include "sim_common.h"

/* Hash&Tcam key struct */
struct store_key_info_s
{
    list_head_t head;

    uint32 key[MAX_ENTRY_WORD];
    tbls_id_t tblid;
};
typedef struct store_key_info_s store_key_info_t;

extern int32 sim_store_hash_tcam_key(void *key, tbls_id_t tblid);

extern int32 cosim_hash_tcam_key_verify(uint32 table_id, uint8 *key,  bool *succ);

#endif

