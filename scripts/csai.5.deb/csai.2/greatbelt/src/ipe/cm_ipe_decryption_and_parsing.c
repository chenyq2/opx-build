/****************************************************************************
 * cm_ipe_decryption_and_parsing.c: Provides IPE decryption/parsing handle function.
 * Copyright: (C) 2010 Centec Networks Inc. All rights reserved.
 *
 * Modify History:
 * Vision:    V1.0.
 * Author:    XuZx
 * Date:      2010-10-19
 * Reason:    Create for GreatBelt
 *
 * Revision:  V2.0
 * Author:    XuZx.
 * Date:      2011-4-6.
 * Reason:    SYNC for GreateBelt v2.0
 *
 * Revision:  V5.7.0
 * Author:    Wangcy.
 * Date:      2012-1-12.
 * Reason:    SYNC for GreateBelt v5.7.0
 *
 * Reversion: V5.11.0
 * Author:    ZhouW
 * Date:      2012-03-01.
 * Reason:    sync spec v5.11.0.
 *
 * Reversion: V5.13.0
 * Author:    Wangcy
 * Date:      2012-03-12.
 * Reason:    sync spec v5.13.0.
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
****************************************************************************/
/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
/****************************************************************************
 * Name:       cm_ipe_dcpt_and_parsing_handle
 * Purpose:    handle IPE decryption and parsing.
 * Parameters:
 * Input:      p_in_pkt  -- pointer to buffer which save input packet and packet
 *                      header, and processing informations informations.
 * Output:     p_in_pkt  -- pointer to buffer which save input packet and packet
 *                      header, and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32 cm_ipe_dcpt_and_parsing_handle(ipe_in_pkt_t* p_in_pkt)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    parser_info_t parser_info;
    ds_phy_port_t ds_phy_port;
    ipe_port_mac_ctl1_t ipe_port_mac_ctl_1;
    uint32 cmd = 0;
    ms_packet_header_t temp_bridge_header;
    greatbelt_packet_header_t cm_packet_header;
    uint32 header_mac_da_39_to_8 = 0, header_mac_da_47_to_40 = 0;
    bool port_mac_match = FALSE, system_mac_match = FALSE, header_mac_da_match = FALSE;

    DRV_PTR_VALID_CHECK(p_in_pkt);

    sal_memset(&ds_phy_port, 0, sizeof(ds_phy_port));
    cmd = DRV_IOR(DsPhyPort_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_in_pkt->chip_id, pkt_info->local_phy_port, cmd, &ds_phy_port));

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s, Port %d\n", "IPE Parsing Process",
                                        pkt_info->local_phy_port);

    /* use htonX function, alway keep to host endian */
    sal_memset(&temp_bridge_header, 0, sizeof(temp_bridge_header));
    sal_memcpy(&temp_bridge_header, p_in_pkt->module_bus.packet_header, GREAT_BELT_HEADER_LEN);
    DRV_IF_ERROR_RETURN(swap32((uint32 *)(&temp_bridge_header), GREAT_BELT_HEADER_LEN /4, NETWORK_TO_HOST));
    cm_gen_greatbelt_packet_header(&temp_bridge_header, &cm_packet_header, TRUE);

    /* DS_PHY_PORT */
    pkt_info->vlan_range_type = ds_phy_port.vlan_range_type;
    pkt_info->vlan_range_profile = ds_phy_port.vlan_range_profile;
    pkt_info->vlan_range_profile_en = ds_phy_port.vlan_range_profile_en;

    if (!pkt_info->from_cpu_or_oam)
    {
        pkt_info->outer_vlan_is_cvlan = ds_phy_port.outer_vlan_is_cvlan;
    }
    else
    {
        pkt_info->outer_vlan_is_cvlan = FALSE; /* OAM/CPU set PacketHeader.outerVlanIsCVlan */
    }

    if (ds_phy_port.src_discard)
    {
        if (!pkt_info->discard)
        {
           pkt_info->discard_type = IPE_DISCARD_DS_PHYPORT_SRC_DISCARD;
           pkt_info->discard = TRUE;
        }
        CMODEL_DEBUG_OUT_INFO("++++ Discard! DsPhyPort.srcDiscard is set, portId = %d !\n",
                              pkt_info->local_phy_port);
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }

    pkt_info->pbb_src_port_type = ds_phy_port.pbb_port_type;
    pkt_info->svlan_tpid_index = ds_phy_port.svlan_tpid_index;

    pkt_info->port_mac_label = ds_phy_port.port_mac_label;
    pkt_info->port_mac_type = ds_phy_port.port_mac_type;

    sal_memset(&ipe_port_mac_ctl_1, 0, sizeof(ipe_port_mac_ctl_1));
    cmd = DRV_IOR(IpePortMacCtl1_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_in_pkt->chip_id, 0, cmd, &ipe_port_mac_ctl_1));

    header_mac_da_39_to_8 = (((pkt_info->header_mac_da47_32 & 0xFF) << 24) | (pkt_info->header_mac_da31_0 >> 8));
    header_mac_da_47_to_40 = (pkt_info->header_mac_da47_32 >> 8);

    if (0 == pkt_info->port_mac_type)
    {
        port_mac_match = (header_mac_da_39_to_8 == ipe_port_mac_ctl_1.port_mac_type0_39_8)
                    && (header_mac_da_47_to_40 == ipe_port_mac_ctl_1.port_mac_type0_47_40);
    }
    else if (1 == pkt_info->port_mac_type)
    {
        port_mac_match = (header_mac_da_39_to_8 == ipe_port_mac_ctl_1.port_mac_type1_39_8)
                    && (header_mac_da_47_to_40 == ipe_port_mac_ctl_1.port_mac_type1_47_40);
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! DsPhyPort.portMacType can not cfg 2 or 3!!\n");
    }

    system_mac_match = ipe_port_mac_ctl_1.system_mac_en
        && (pkt_info->header_mac_da31_0 == ipe_port_mac_ctl_1.system_mac31_0)
        && (pkt_info->header_mac_da47_32 == ipe_port_mac_ctl_1.system_mac47_32);

    header_mac_da_match = port_mac_match || system_mac_match;

    if (pkt_info->header_mac_da_check && !header_mac_da_match)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_STACKING_NETWORK_HEADER_CHK_ERR; /* 35 */
            CMODEL_DEBUG_OUT_INFO("CModelDebug: HeaderMacDa check discard!!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (ds_phy_port.packet_type_valid)
    {
        pkt_info->packet_type = ds_phy_port.packet_type;
    }
    else
    {
        pkt_info->packet_type = pkt_info->packet_type;
    }

    /* time stamp is append to all packets for length less than 249 whether PTP/OAM is enabled,
     * extracted and removed here for packet save.
     * ChannelInfo.ptpEn used to differentiate packet with length between 249 and 256 for packet
     * with/without timestamp
     * Data path adjust packetLength according to ChannelInfo.ptpEn (packetLength = totalLength - 8) */
    /* NOTE,timestamp, ptp_en, cmodel can not implement,how to get ptpen&timestamp*/
    if (p_in_pkt->channelinfo_ptpen)
    {
        /* Get timestamp at the pkt tail */
        pkt_info->time_stamp_valid = TRUE;
        pkt_info->time_stamp31_0
                 = MAKE_UINT32(p_in_pkt->pkt[p_in_pkt->packet_length-4], p_in_pkt->pkt[p_in_pkt->packet_length-3],
                        p_in_pkt->pkt[p_in_pkt->packet_length-2], p_in_pkt->pkt[p_in_pkt->packet_length-1]);
        pkt_info->time_stamp61_32
                 = MAKE_UINT32(p_in_pkt->pkt[p_in_pkt->packet_length-8], p_in_pkt->pkt[p_in_pkt->packet_length-7],
                        p_in_pkt->pkt[p_in_pkt->packet_length-6], p_in_pkt->pkt[p_in_pkt->packet_length-5]);

        pkt_info->packet_length -= TIME_STAMP_LENGTH;
        p_in_pkt->packet_length -= TIME_STAMP_LENGTH;
        /* remove timestamp from packet */
        sal_memset(p_in_pkt->pkt+p_in_pkt->packet_length, 0, TIME_STAMP_LENGTH);
    }

    /* REQUEST_PARSING */
    /* PacketInfo.packetLength[13:0] is length for data path which is stored in PacketBuffer, including CRC, MUX Header,
       SGMAC Header. */
    /* Maximal parsed bytes is 256 including removal bytes, but except 32 bytes Packet header in case of Loopback and
       8 bytes timestamp in case of network port */
    sal_memset(&parser_info, 0, sizeof(parser_info));

    parser_info.pkt = p_in_pkt->pkt;
    parser_info.parser_length = (pkt_info->packet_length > 256) ? 256 : pkt_info->packet_length;
    parser_info.packet_type = pkt_info->packet_type;
    parser_info.parser_layer4_type = L4_TYPE_NONE;
    parser_info.svlan_tpid_index = pkt_info->svlan_tpid_index;
    parser_info.outer_vlan_is_cvlan = pkt_info->outer_vlan_is_cvlan;
    parser_info.chip_id = p_in_pkt->chip_id;
    parser_info.port_id = pkt_info->local_phy_port;
    parser_info.payload_offset = 0;
    parser_info.mux_length_type = pkt_info->mux_length_type;
    parser_info.non_crc = pkt_info->non_crc;
    /* rtl' pktHdr pktLen is zero when actual len > 256B (do not include ILOOP)!! */
    if ((pkt_info->packet_length > 256) && !pkt_info->is_loop)
    {
        pkt_info->packet_length = 0; /* pseudo value */
    }
#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_ipe_bus[SIM_IPE_HA2PR])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_HA2PR]((void *)p_in_pkt));
    }
    if (cosim_db.store_ipe_bus[SIM_IPE_HA2IM])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_HA2IM]((void *)p_in_pkt));
    }
 #endif

    parser_info.parser_result = (parsing_result_t *)pkt_info->parser_rslt;

    DRV_IF_ERROR_RETURN(cm_com_parser_packet_parsing(&parser_info));

    return DRV_E_NONE;
}

