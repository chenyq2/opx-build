/****************************************************************************
 * cm_ipe_acl_qos.c: Provides IPE ACL and QoS handle function.
 * Copyright:     (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Version:      V1.0.
 * Author:       Jiang
 * Date:         2010-09-30.
 * Reason:       First Create.
 *
 * Modify History:
 * Reversion:    V1.01
 * Author:       XuZx
 * Date:         2010-11-13.
 * Reason:       Revise for first formal spec.
 *
 * Reversion:    V1.02
 * Author:       XuZx
 * Date:         2010-11-22.
 * Reason:       Revise for second formal spec.
 *
 * Reversion:    V2.0
 * Author:       Jiangsz
 * Date:         2011-04-07.
 * Reason:       sync spec v2.0.

 * Reversion:    V4.2.1
 * Author:       Shenhg
 * Date:         2011-06-30.
 * Reason:       sync spec v4.2.1.
 *
 * Reversion:    V4.29.0
 * Author:       wangcy
 * Date:         2011-09-29.
 * Reason:       sync spec v4.29.0.
 *
 * Reversion:    V5.1.0
 * Author:       wangcy
 * Date:         2011-12-12.
 * Reason:       sync spec v5.1.0.
 *
 * Reversion:    V5.6.0
 * Author:       wangcy
 * Date:         2012-01-07.
 * Reason:       sync spec v5.6.0.
 *
 * Reversion:    V5.11.0
 * Author:       ZhouW
 * Date:         2012-03-01.
 * Reason:       sync spec v5.11.0.
 *
 * Reversion:    V5.13.0
 * Author:       ZhouW
 * Date:         2012-03-12.
 * Reason:       sync spec v5.13.0.
 *
 * Reversion:    V5.15.0.1
 * Author:       Wangcy
 * Date:         2012-03-23.
 * Reason:       sync spec v5.15.0.1
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "cm_lib.h"
#include "ctcutil_lib.h"
#include "drv_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/
/* used to store acl valid information for sub routine */
struct cm_ipe_acl_qos_info_s
{

    uint32 flow_priority_valid :1;
    uint32 flow_priority :6;
    uint32 flow_color :2;
    uint32 acl0_stats_valid :1;
    uint32 acl1_stats_valid :1;
    uint32 acl2_stats_valid :1;
    uint32 acl3_stats_valid :1;
    uint32 ds_acl_flow_policer_valid :1;
    uint32 ds_acl_agg_flow_policer_valid :1;
    uint32 acl0_stats_ptr :16;
    uint32 acl1_stats_ptr :16;
    uint32 acl2_stats_ptr :16;
    uint32 acl3_stats_ptr :16;
    uint32 ds_acl_qos_policy_valid :1;
    uint32 ds_acl_qos_domain_valid :1;
    uint32 ds_acl_flow_priority_valid :1;
    uint32 ds_acl_ds_fwd_ptr_valid :1;
    uint32 ds_acl_flow_id_valid :1;
    uint32 ds_acl_stag_action_valid :1;
    uint32 ds_acl_ctag_action_valid :1;
    uint32 ds_acl_svlan_tpid_index_valid :1;
    uint32 ds_acl_outer_vlan_status_valid :1;
    uint32 ds_acl_dscp_valid :1;
    uint32 exception_to_cpu_valid :1;

    uint32 svlan_id :12;
    uint32 scos     :3;
    uint32 scfi     :1;
    uint32 s_tag_action  :2;
    uint32 s_vlan_id_action  :2;
    uint32 s_cos_action  :2;
    uint32 s_cfi_action  :2;

    uint32 cvlan_id :12;
    uint32 ccos     :3;
    uint32 ccfi     :1;
    uint32 c_tag_action  :2;
    uint32 c_vlan_id_action  :2;
    uint32 c_cos_action  :2;
    uint32 c_cfi_action  :2;
    uint32 ctag_add_mode :1;

    uint32 svlan_tpid_index :2;
    uint32 outer_vlan_status    :1;
    uint32 ds_acl_timestamp_valid :1;

};

enum aclqos_stag_action_e
{
    ACLQOS_STAG_ACTION_NONE,                  /* 0 */
    ACLQOS_STAG_ACTION_MODIFY,                /* 1 */
    ACLQOS_STAG_ACTION_ADD,                   /* 2 */
    ACLQOS_STAG_ACTION_DELETE,                /* 3 */
};
typedef enum aclqos_stag_action_e aclqos_stag_action_t;

enum aclqos_ctag_action_e
{
    ACLQOS_CTAG_ACTION_NONE,                  /* 0 */
    ACLQOS_CTAG_ACTION_MODIFY,                /* 1 */
    ACLQOS_CTAG_ACTION_ADD,                   /* 2 */
    ACLQOS_CTAG_ACTION_DELETE,                /* 3 */
};
typedef enum aclqos_ctag_action_e aclqos_ctag_action_t;

enum aclqos_svlan_id_action_e
{
    ACLQOS_SVLAN_ID_ACTION_NONE,              /* 0 */
    ACLQOS_SVLAN_ID_ACTION_SWAP,              /* 1 */
    ACLQOS_SVLAN_ID_ACTION_USER,              /* 2 */
};
typedef enum aclqos_svlan_id_action_e aclqos_svlan_id_action_t;

enum aclqos_cvlan_id_action_e
{
    ACLQOS_CVLAN_ID_ACTION_NONE,              /* 0 */
    ACLQOS_CVLAN_ID_ACTION_SWAP,              /* 1 */
    ACLQOS_CVLAN_ID_ACTION_USER,              /* 2 */
};
typedef enum aclqos_cvlan_id_action_e aclqos_cvlan_id_action_t;

enum aclqos_scos_action_e
{
    ACLQOS_SCOS_ACTION_NONE,                 /* 0 */
    ACLQOS_SCOS_ACTION_SWAP,                 /* 1 */
    ACLQOS_SCOS_ACTION_USER,                 /* 2 */
    ACLQOS_SCOS_ACTION_MAPPED,               /* 3 */
};
typedef enum aclqos_scos_action_e aclqos_scos_action_t;

enum aclqos_ccos_action_e
{
    ACLQOS_CCOS_ACTION_NONE,                 /* 0 */
    ACLQOS_CCOS_ACTION_SWAP,                 /* 1 */
    ACLQOS_CCOS_ACTION_USER,                 /* 2 */
    ACLQOS_CCOS_ACTION_MAPPED,               /* 3 */
};
typedef enum aclqos_ccos_action_e aclqos_ccos_action_t;

enum aclqos_scfi_action_e
{
    ACLQOS_SCFI_ACTION_NONE,                 /* 0 */
    ACLQOS_SCFI_ACTION_SWAP,                 /* 1 */
    ACLQOS_SCFI_ACTION_USER,                 /* 2 */
    ACLQOS_SCFI_ACTION_MAPPED,               /* 3 */
};
typedef enum aclqos_scfi_action_e aclqos_scfi_action_t;

enum aclqos_ccfi_action_e
{
    ACLQOS_CCFI_ACTION_NONE,                 /* 0 */
    ACLQOS_CCFI_ACTION_SWAP,                 /* 1 */
    ACLQOS_CCFI_ACTION_USER,                 /* 2 */
    ACLQOS_CCFI_ACTION_MAPPED,               /* 3 */
};
typedef enum aclqos_ccfi_action_e aclqos_ccfi_action_t;

typedef struct cm_ipe_acl_qos_info_s cm_ipe_acl_qos_info_t;

struct cm_ipe_acl_app_cam_c_s
{
    uint32 app_data_value :32;
    uint32 app_data_mask :32;
};
typedef struct cm_ipe_acl_app_cam_c_s cm_ipe_acl_app_cam_c_t;

struct cm_ipe_acl_app_cam_result_c_s
{
   uint32 result_valid :1;
   uint32 rsv_0        :7;
   uint32 flow_id      :4;
   uint32 rsv_1        :20;
};
typedef struct cm_ipe_acl_app_cam_result_c_s cm_ipe_acl_app_cam_result_c_t;

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/

/****************************************************************************
 * Name:       _cm_ipe_acl_qos_process_ds_acl0
 * Purpose:    PROCESS_DS_ACL sub-routine
 * Parameters:
 * Input:      acl_qos_info -- acl qos module variables
 *             in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Return:     DRV_E_NONE -- success.
 *             Other -- ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_acl_qos_process_ds_acl0(ipe_in_pkt_t* in_pkt, cm_ipe_acl_qos_info_t* p_acl_qos_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t* parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;
    ds_acl_t* acl_data = NULL;
    ipe_acl_qos_ctl_t ipe_acl_qos_ctl;
    uint16 random_threshold = 0;
    uint32 random = 0;
    uint32 cmd = 0;
    uint8 chip_id = in_pkt->chip_id;
    uint32 cam_index = 0;
    uint16 stats_ptr = 0;

    ipe_acl_app_cam_t ipe_acl_app_cam;
    ipe_acl_app_cam_result_t ipe_acl_app_cam_result;
    cm_ipe_acl_app_cam_c_t acl_app_cam_tmp;
    cm_ipe_acl_app_cam_result_c_t acl_app_cam_result_tmp;

    sal_memset(&ipe_acl_app_cam, 0, sizeof(ipe_acl_app_cam));
    sal_memset(&ipe_acl_app_cam_result, 0, sizeof(ipe_acl_app_cam_result));

    /* get DSAclQos Data */
    acl_data = (ds_acl_t *)pkt_info->acl_data0;

    sal_memset(&ipe_acl_qos_ctl, 0, sizeof(ipe_acl_qos_ctl));
    cmd = DRV_IOR(IpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_qos_ctl));


    /* process discard flags */
    if (acl_data->discard_packet
        && ((OAM_NONE == pkt_info->rx_oam_type) || ipe_acl_qos_ctl.oam_obey_acl_discard))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_ACLQOS_DISCARD_PKT;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DsAcl discardPacket is set by acl0!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (acl_data->deny_bridge)
    {
        pkt_info->deny_bridge = TRUE;
    }

    if (acl_data->deny_learning)
    {
        pkt_info->deny_learning = TRUE;
    }

    if (acl_data->deny_route)
    {
        pkt_info->deny_route = TRUE;
    }

    /* process random log */
    ctcutil_rand(0, 0x7FFF, &random); /* software random may be diffrent from ASIC */
    random_threshold = (1 << acl_data->random_threshold_shift);
    if (acl_data->random_log_en && (random < random_threshold))
    {
        pkt_info->acl_log_en0 = TRUE;
        pkt_info->acl_log_id0 = acl_data->acl_log_id;
    }

    /* flow policer */
    if (0x0 != acl_data->flow_policer_ptr)
    {
        pkt_info->flow_policer_valid = TRUE;
        pkt_info->flow_policer_ptr = acl_data->flow_policer_ptr;
        p_acl_qos_info->ds_acl_flow_policer_valid = TRUE;
    }

    if (0x0 != acl_data->agg_flow_policer_ptr)
    {
        pkt_info->agg_flow_policer_valid = TRUE;
        pkt_info->agg_flow_policer_ptr = acl_data->agg_flow_policer_ptr;
        p_acl_qos_info->ds_acl_agg_flow_policer_valid = TRUE;

    }

    /* stats */
    stats_ptr = (acl_data->stats_ptr15_14 << 14)|(acl_data->stats_ptr13_12 << 12)|
                (acl_data->stats_ptr11_4 << 4)|(acl_data->stats_ptr3_0);
    if (0x0 != stats_ptr)
    {
        p_acl_qos_info->acl0_stats_valid = TRUE;
        p_acl_qos_info->acl0_stats_ptr = stats_ptr;
    }

    /* overwrite qos policy */
    if (QOS_POLICY_INVALID != acl_data->qos_policy)
    {
        pkt_info->qos_policy = acl_data->qos_policy;
        p_acl_qos_info->ds_acl_qos_policy_valid = TRUE;
    }

    /* overwrite qosDomain[2:0] */
    if (0 != acl_data->qos_domain)
    {
        pkt_info->qos_domain = acl_data->qos_domain;
        p_acl_qos_info->ds_acl_qos_domain_valid = TRUE;
    }

    /* copy priority field */
    if (0x0 != acl_data->color)
    {
        p_acl_qos_info->flow_priority_valid = TRUE;
        p_acl_qos_info->flow_priority = acl_data->priority;
        p_acl_qos_info->flow_color = acl_data->color;
        p_acl_qos_info->ds_acl_flow_priority_valid = TRUE;
    }

    /* dsFwdPtr */
    if (0x0 != acl_data->ds_fwd_ptr)
    {
        pkt_info->ds_fwd_ptr_valid = TRUE;
        pkt_info->ds_fwd_ptr = acl_data->ds_fwd_ptr +
                               (((L3_TYPE_IPV4 == parser_result->layer3_type) || (L3_TYPE_IPV6 == parser_result->layer3_type))
                               ? ((parser_result->l3_s.ip_ecmp_hash) % ((0xF & acl_data->equal_cost_path_num) + 1)) : 0);
        /* ======== bug 4928 metal fix ECO begin ========= */
        //pkt_info->payload_packet_type = pkt_info->packet_type;
        //pkt_info->payload_offset = 0;
        if(acl_data->ccfi)
        {
            pkt_info->payload_packet_type = pkt_info->packet_type;
            pkt_info->payload_offset = 0;
        }
        /* ======== bug 4928 metal fix ECO end ========= */

        p_acl_qos_info->ds_acl_ds_fwd_ptr_valid = TRUE;

        if (pkt_info->fatal_exception_valid && !ipe_acl_qos_ctl.fatal_exception_bypass_redirect)
        {
            pkt_info->fatal_exception_valid = FALSE;
        }
    }

    if (acl_data->timestamp_en && !pkt_info->exception_en && pkt_info->time_stamp_valid)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PTP;
        p_acl_qos_info->ds_acl_timestamp_valid = TRUE;

        if (!pkt_info->discard && ipe_acl_qos_ctl.timestamp_packet_discard)
        {
            pkt_info->discard_type = IPE_DISCARD_PTP_ACL_EXCEPTION;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DsAcl discardPacket is set by acl0!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (acl_data->exception_to_cpu)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_RESERVED1;
        p_acl_qos_info->exception_to_cpu_valid = TRUE;
    }

    if (0 != acl_data->flow_id)
    {
        pkt_info->flow_id = acl_data->flow_id;
        p_acl_qos_info->ds_acl_flow_id_valid = TRUE;
    }

    if (acl_data->match_app_data && pkt_info->app_data_valid)
    {
        cmd = DRV_IOR(IpeAclAppCam_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_app_cam));

        cmd = DRV_IOR(IpeAclAppCamResult_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_app_cam_result));

        for (cam_index = 0; cam_index < 8; cam_index++)
        {
            sal_memset(&acl_app_cam_tmp, 0, sizeof(acl_app_cam_tmp));
            sal_memset(&acl_app_cam_result_tmp, 0, sizeof(acl_app_cam_result_tmp));

            switch (cam_index)
            {
                case 0:
                    acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask0;
                    acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value0;
                    acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid0;
                    acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id0;
                    break;
                case 1:
                    acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask1;
                    acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value1;
                    acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid1;
                    acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id1;
                    break;
                case 2:
                    acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask2;
                    acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value2;
                    acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid2;
                    acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id2;
                    break;
                case 3:
                    acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask3;
                    acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value3;
                    acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid3;
                    acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id3;
                    break;
                case 4:
                    acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask4;
                    acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value4;
                    acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid4;
                    acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id4;
                    break;
                case 5:
                    acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask5;
                    acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value5;
                    acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid5;
                    acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id5;
                    break;
                case 6:
                    acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask6;
                    acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value6;
                    acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid6;
                    acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id6;
                    break;
                case 7:
                    acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask7;
                    acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value7;
                    acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid7;
                    acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id7;
                    break;
                default:
                    break;
            }

            /* use parser1's appdata, had confirmed with peiyu */
            if ((parser_result1->l4_s.app_data & acl_app_cam_tmp.app_data_mask)
                 == (acl_app_cam_tmp.app_data_value & acl_app_cam_tmp.app_data_mask))
            {
                if (acl_app_cam_result_tmp.result_valid)
                {
                    pkt_info->flow_id = acl_app_cam_result_tmp.flow_id;
                    p_acl_qos_info->ds_acl_flow_id_valid = TRUE;
                    break;
                }
            }
        }
    }

    /* VLAN tag editing */
    if (ACLQOS_STAG_ACTION_NONE != acl_data->s_tag_action)
    {
        p_acl_qos_info->ds_acl_stag_action_valid = TRUE;
        p_acl_qos_info->svlan_id = (acl_data->svlan_id11_4<<4)
                             | (acl_data->svlan_id3_2<<2) | acl_data->svlan_id1_0;
        p_acl_qos_info->scos = (acl_data->scos2<<2)|acl_data->scos1_0;;
        p_acl_qos_info->scfi = acl_data->scfi;
        p_acl_qos_info->s_tag_action = acl_data->s_tag_action;
        p_acl_qos_info->s_vlan_id_action = acl_data->s_vlan_id_action;
        p_acl_qos_info->s_cos_action = acl_data->s_cos_action;
        p_acl_qos_info->s_cfi_action = acl_data->s_cfi_action;
    }

    if (ACLQOS_CTAG_ACTION_NONE != acl_data->c_tag_action)
    {
        p_acl_qos_info->ds_acl_ctag_action_valid = TRUE;
        p_acl_qos_info->cvlan_id = acl_data->cvlan_id;
        p_acl_qos_info->ccos = acl_data->ccos;
        p_acl_qos_info->ccfi = acl_data->ccfi;
        p_acl_qos_info->c_tag_action = acl_data->c_tag_action;
        p_acl_qos_info->c_vlan_id_action = acl_data->c_vlan_id_action;
        p_acl_qos_info->c_cos_action = acl_data->c_cos_action;
        p_acl_qos_info->c_cfi_action = acl_data->c_cfi_action;
        p_acl_qos_info->ctag_add_mode = acl_data->ctag_add_mode;
    }

    if (acl_data->svlan_tpid_index_en)
    {
        p_acl_qos_info->ds_acl_svlan_tpid_index_valid = TRUE;
        p_acl_qos_info->svlan_tpid_index = acl_data->svlan_tpid_index;
    }

    if (0 != acl_data->outer_vlan_status)
    {
        p_acl_qos_info->ds_acl_outer_vlan_status_valid = TRUE;
        p_acl_qos_info->outer_vlan_status = IS_BIT_SET(acl_data->outer_vlan_status,0);
    }

    /* new DSCP */
    if (acl_data->dscp_valid)
    {
        pkt_info->acl_dscp_valid = TRUE;
        pkt_info->acl_dscp = acl_data->acl_dscp;
        p_acl_qos_info->ds_acl_dscp_valid = TRUE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_acl_qos_process_ds_acl1
 * Purpose:    PROCESS_DS_ACL sub-routine
 * Parameters:
 * Input:      acl_qos_info -- acl qos module variables
 *             in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Return:     DRV_E_NONE -- success.
 *             Other -- ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_acl_qos_process_ds_acl1(ipe_in_pkt_t* in_pkt, cm_ipe_acl_qos_info_t* p_acl_qos_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t* parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;
    ds_acl_t* acl_data = NULL;
    ipe_acl_qos_ctl_t ipe_acl_qos_ctl;
    uint16 random_threshold = 0;
    uint32 random = 0;
    uint32 cmd = 0;
    uint8 chip_id = in_pkt->chip_id;
    uint32 cam_index = 0;
    uint16 stats_ptr = 0;

    ipe_acl_app_cam_t ipe_acl_app_cam;
    ipe_acl_app_cam_result_t ipe_acl_app_cam_result;
    cm_ipe_acl_app_cam_c_t acl_app_cam_tmp;
    cm_ipe_acl_app_cam_result_c_t acl_app_cam_result_tmp;

    sal_memset(&ipe_acl_app_cam, 0, sizeof(ipe_acl_app_cam));
    sal_memset(&ipe_acl_app_cam_result, 0, sizeof(ipe_acl_app_cam_result));

    /* get DSAclQos Data */
    acl_data = (ds_acl_t *)pkt_info->acl_data1;

    sal_memset(&ipe_acl_qos_ctl, 0, sizeof(ipe_acl_qos_ctl));
    cmd = DRV_IOR(IpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_qos_ctl));


    /* process discard flags */
    if (acl_data->discard_packet
        && ((OAM_NONE == pkt_info->rx_oam_type) || ipe_acl_qos_ctl.oam_obey_acl_discard))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_ACLQOS_DISCARD_PKT;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DsAcl discardPacket is set by acl1!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (acl_data->deny_bridge)
    {
        pkt_info->deny_bridge = TRUE;
    }

    if (acl_data->deny_learning)
    {
        pkt_info->deny_learning = TRUE;
    }

    if (acl_data->deny_route)
    {
        pkt_info->deny_route = TRUE;
    }

    /* process random log */
    ctcutil_rand(0, 0x7FFF, &random); /* software random may be diffrent from ASIC */
    random_threshold = (1 << acl_data->random_threshold_shift);
    if (acl_data->random_log_en && (random < random_threshold))
    {
        pkt_info->acl_log_en1 = TRUE;
        pkt_info->acl_log_id1 = acl_data->acl_log_id;
    }

    /* flow policer */
    if (0x0 != acl_data->flow_policer_ptr && !p_acl_qos_info->ds_acl_flow_policer_valid)
    {
        pkt_info->flow_policer_valid = TRUE;
        pkt_info->flow_policer_ptr = acl_data->flow_policer_ptr;
        p_acl_qos_info->ds_acl_flow_policer_valid = TRUE;
    }

    if (0x0 != acl_data->agg_flow_policer_ptr && !p_acl_qos_info->ds_acl_agg_flow_policer_valid)
    {
        pkt_info->agg_flow_policer_valid = TRUE;
        pkt_info->agg_flow_policer_ptr = acl_data->agg_flow_policer_ptr;
        p_acl_qos_info->ds_acl_agg_flow_policer_valid = TRUE;
    }

    /* stats */
    stats_ptr = (acl_data->stats_ptr15_14 << 14)|(acl_data->stats_ptr13_12 << 12)|
                (acl_data->stats_ptr11_4 << 4)|(acl_data->stats_ptr3_0);
    if (0x0 != stats_ptr)
    {
        p_acl_qos_info->acl1_stats_valid = TRUE;
        p_acl_qos_info->acl1_stats_ptr = stats_ptr;
    }


    /* overwrite qos policy */
    if (QOS_POLICY_INVALID != acl_data->qos_policy && !p_acl_qos_info->ds_acl_qos_policy_valid)
    {
        pkt_info->qos_policy = acl_data->qos_policy;
        p_acl_qos_info->ds_acl_qos_policy_valid = TRUE;
    }

    /* overwrite qosDomain[2:0] */
    if (0 != acl_data->qos_domain && !p_acl_qos_info->ds_acl_qos_domain_valid)
    {
        pkt_info->qos_domain = acl_data->qos_domain;
        p_acl_qos_info->ds_acl_qos_domain_valid = TRUE;
    }

    /* copy priority field */
    if (0x0 != acl_data->color && !p_acl_qos_info->ds_acl_flow_priority_valid)
    {
        p_acl_qos_info->flow_priority_valid = TRUE;
        p_acl_qos_info->flow_priority = acl_data->priority;
        p_acl_qos_info->flow_color = acl_data->color;
        p_acl_qos_info->ds_acl_flow_priority_valid = TRUE;
    }

    /* dsFwdPtr */
    if (0x0 != acl_data->ds_fwd_ptr && !p_acl_qos_info->ds_acl_ds_fwd_ptr_valid)
    {
        pkt_info->ds_fwd_ptr_valid = TRUE;
        pkt_info->ds_fwd_ptr = acl_data->ds_fwd_ptr +
                               (((L3_TYPE_IPV4 == parser_result->layer3_type) || (L3_TYPE_IPV6 == parser_result->layer3_type))
                               ? ((parser_result->l3_s.ip_ecmp_hash) % ((0xF & acl_data->equal_cost_path_num) + 1)) : 0);
        /* ======== bug 4928 metal fix ECO begin ========= */
        //pkt_info->payload_packet_type = pkt_info->packet_type;
        //pkt_info->payload_offset = 0;
        if(acl_data->ccfi)
        {
            pkt_info->payload_packet_type = pkt_info->packet_type;
            pkt_info->payload_offset = 0;
        }
        /* ======== bug 4928 metal fix ECO end ========= */
        p_acl_qos_info->ds_acl_ds_fwd_ptr_valid = TRUE;

        if (pkt_info->fatal_exception_valid && !ipe_acl_qos_ctl.fatal_exception_bypass_redirect)
        {
            pkt_info->fatal_exception_valid = FALSE;
        }
    }


    if (acl_data->timestamp_en && !pkt_info->exception_en && pkt_info->time_stamp_valid && !p_acl_qos_info->ds_acl_timestamp_valid)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PTP;
        p_acl_qos_info->ds_acl_timestamp_valid = TRUE;

        if (!pkt_info->discard && ipe_acl_qos_ctl.timestamp_packet_discard)
        {
            pkt_info->discard_type = IPE_DISCARD_PTP_ACL_EXCEPTION;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DsAcl discardPacket is set by acl1!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (acl_data->exception_to_cpu && !p_acl_qos_info->exception_to_cpu_valid)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_RESERVED1;
        p_acl_qos_info->exception_to_cpu_valid = TRUE;
    }

    if (!p_acl_qos_info->ds_acl_flow_id_valid)
    {
        if (0 != acl_data->flow_id)
        {
            pkt_info->flow_id = acl_data->flow_id;
            p_acl_qos_info->ds_acl_flow_id_valid = TRUE;
        }

        if (acl_data->match_app_data && pkt_info->app_data_valid)
        {
            cmd = DRV_IOR(IpeAclAppCam_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_app_cam));

            cmd = DRV_IOR(IpeAclAppCamResult_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_app_cam_result));

            for (cam_index = 0; cam_index < 8; cam_index++)
            {
                sal_memset(&acl_app_cam_tmp, 0, sizeof(acl_app_cam_tmp));
                sal_memset(&acl_app_cam_result_tmp, 0, sizeof(acl_app_cam_result_tmp));

                switch (cam_index)
                {
                    case 0:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask0;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value0;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid0;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id0;
                        break;
                    case 1:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask1;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value1;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid1;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id1;
                        break;
                    case 2:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask2;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value2;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid2;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id2;
                        break;
                    case 3:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask3;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value3;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid3;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id3;
                        break;
                    case 4:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask4;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value4;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid4;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id4;
                        break;
                    case 5:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask5;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value5;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid5;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id5;
                        break;
                    case 6:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask6;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value6;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid6;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id6;
                        break;
                    case 7:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask7;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value7;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid7;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id7;
                        break;
                    default:
                        break;
                }

                /* use parser1's appdata, had confirmed with peiyu */
                if ((parser_result1->l4_s.app_data & acl_app_cam_tmp.app_data_mask)
                     == (acl_app_cam_tmp.app_data_value & acl_app_cam_tmp.app_data_mask))
                {
                    if (acl_app_cam_result_tmp.result_valid)
                    {
                        pkt_info->flow_id = acl_app_cam_result_tmp.flow_id;
                        p_acl_qos_info->ds_acl_flow_id_valid = TRUE;
                        break;
                    }
                }
            }
        }
    }


    /* VLAN tag editing */
    if (ACLQOS_STAG_ACTION_NONE != acl_data->s_tag_action && !p_acl_qos_info->ds_acl_stag_action_valid)
    {
        p_acl_qos_info->ds_acl_stag_action_valid = TRUE;
        p_acl_qos_info->svlan_id = (acl_data->svlan_id11_4<<4)
                             | (acl_data->svlan_id3_2<<2) | acl_data->svlan_id1_0;
        p_acl_qos_info->scos = (acl_data->scos2<<2)|acl_data->scos1_0;
        p_acl_qos_info->scfi = acl_data->scfi;
        p_acl_qos_info->s_tag_action = acl_data->s_tag_action;
        p_acl_qos_info->s_vlan_id_action = acl_data->s_vlan_id_action;
        p_acl_qos_info->s_cos_action = acl_data->s_cos_action;
        p_acl_qos_info->s_cfi_action = acl_data->s_cfi_action;
    }

    if (ACLQOS_CTAG_ACTION_NONE != acl_data->c_tag_action && !p_acl_qos_info->ds_acl_ctag_action_valid)
    {
        p_acl_qos_info->ds_acl_ctag_action_valid = TRUE;
        p_acl_qos_info->cvlan_id = acl_data->cvlan_id;
        p_acl_qos_info->ccos = acl_data->ccos;
        p_acl_qos_info->ccfi = acl_data->ccfi;
        p_acl_qos_info->c_tag_action = acl_data->c_tag_action;
        p_acl_qos_info->c_vlan_id_action = acl_data->c_vlan_id_action;
        p_acl_qos_info->c_cos_action = acl_data->c_cos_action;
        p_acl_qos_info->c_cfi_action = acl_data->c_cfi_action;
        p_acl_qos_info->ctag_add_mode = acl_data->ctag_add_mode;
    }

    if (acl_data->svlan_tpid_index_en && !p_acl_qos_info->ds_acl_svlan_tpid_index_valid)
    {
        p_acl_qos_info->ds_acl_svlan_tpid_index_valid = TRUE;
        p_acl_qos_info->svlan_tpid_index = acl_data->svlan_tpid_index;
    }

    if (0 != acl_data->outer_vlan_status && !p_acl_qos_info->ds_acl_outer_vlan_status_valid)
    {
        p_acl_qos_info->ds_acl_outer_vlan_status_valid = TRUE;
        p_acl_qos_info->outer_vlan_status = IS_BIT_SET(acl_data->outer_vlan_status,0);
    }

    /* new DSCP */
    if (acl_data->dscp_valid && !p_acl_qos_info->ds_acl_dscp_valid)
    {
        pkt_info->acl_dscp_valid = TRUE;
        pkt_info->acl_dscp = acl_data->acl_dscp;
        p_acl_qos_info->ds_acl_dscp_valid = TRUE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_acl_qos_process_ds_acl2
 * Purpose:    PROCESS_DS_ACL sub-routine
 * Parameters:
 * Input:      acl_qos_info -- acl qos module variables
 *             in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Return:     DRV_E_NONE -- success.
 *             Other -- ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_acl_qos_process_ds_acl2(ipe_in_pkt_t* in_pkt, cm_ipe_acl_qos_info_t* p_acl_qos_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t* parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;
    ds_acl_t* acl_data = NULL;
    ipe_acl_qos_ctl_t ipe_acl_qos_ctl;
    uint16 random_threshold = 0;
    uint32 random = 0;
    uint32 cmd = 0;
    uint8 chip_id = in_pkt->chip_id;
    uint32 cam_index = 0;
    uint16 stats_ptr = 0;

    ipe_acl_app_cam_t ipe_acl_app_cam;
    ipe_acl_app_cam_result_t ipe_acl_app_cam_result;
    cm_ipe_acl_app_cam_c_t acl_app_cam_tmp;
    cm_ipe_acl_app_cam_result_c_t acl_app_cam_result_tmp;

    sal_memset(&ipe_acl_app_cam, 0, sizeof(ipe_acl_app_cam));
    sal_memset(&ipe_acl_app_cam_result, 0, sizeof(ipe_acl_app_cam_result));

    /* get DSAclQos Data */
    acl_data = (ds_acl_t *)pkt_info->acl_data2;

    sal_memset(&ipe_acl_qos_ctl, 0, sizeof(ipe_acl_qos_ctl));
    cmd = DRV_IOR(IpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_qos_ctl));


    /* process discard flags */
    if (acl_data->discard_packet
        && ((OAM_NONE == pkt_info->rx_oam_type) || ipe_acl_qos_ctl.oam_obey_acl_discard))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_ACLQOS_DISCARD_PKT;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DsAcl discardPacket is set by acl2!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (acl_data->deny_bridge)
    {
        pkt_info->deny_bridge = TRUE;
    }

    if (acl_data->deny_learning)
    {
        pkt_info->deny_learning = TRUE;
    }

    if (acl_data->deny_route)
    {
        pkt_info->deny_route = TRUE;
    }

    /* process random log */
    ctcutil_rand(0, 0x7FFF, &random); /* software random may be diffrent from ASIC */
    random_threshold = (1 << acl_data->random_threshold_shift);
    if (acl_data->random_log_en && (random < random_threshold))
    {
        pkt_info->acl_log_en2 = TRUE;
        pkt_info->acl_log_id2 = acl_data->acl_log_id;
    }

    /* flow policer */
    if (0x0 != acl_data->flow_policer_ptr && !p_acl_qos_info->ds_acl_flow_policer_valid)
    {
        pkt_info->flow_policer_valid = TRUE;
        pkt_info->flow_policer_ptr = acl_data->flow_policer_ptr;
        p_acl_qos_info->ds_acl_flow_policer_valid = TRUE;
    }

    if (0x0 != acl_data->agg_flow_policer_ptr && !p_acl_qos_info->ds_acl_agg_flow_policer_valid)
    {
        pkt_info->agg_flow_policer_valid = TRUE;
        pkt_info->agg_flow_policer_ptr = acl_data->agg_flow_policer_ptr;
        p_acl_qos_info->ds_acl_agg_flow_policer_valid = TRUE;
    }

    /* stats */
    stats_ptr = (acl_data->stats_ptr15_14 << 14)|(acl_data->stats_ptr13_12 << 12)|
                (acl_data->stats_ptr11_4 << 4)|(acl_data->stats_ptr3_0);
    if (0x0 != stats_ptr)
    {
        p_acl_qos_info->acl2_stats_valid = TRUE;
        p_acl_qos_info->acl2_stats_ptr = stats_ptr;
    }


    /* overwrite qos policy */
    if (QOS_POLICY_INVALID != acl_data->qos_policy && !p_acl_qos_info->ds_acl_qos_policy_valid)
    {
        pkt_info->qos_policy = acl_data->qos_policy;
        p_acl_qos_info->ds_acl_qos_policy_valid = TRUE;
    }

    /* overwrite qosDomain[2:0] */
    if (0 != acl_data->qos_domain && !p_acl_qos_info->ds_acl_qos_domain_valid)
    {
        pkt_info->qos_domain = acl_data->qos_domain;
        p_acl_qos_info->ds_acl_qos_domain_valid = TRUE;
    }

    /* copy priority field */
    if (0x0 != acl_data->color && !p_acl_qos_info->ds_acl_flow_priority_valid)
    {
        p_acl_qos_info->flow_priority_valid = TRUE;
        p_acl_qos_info->flow_priority = acl_data->priority;
        p_acl_qos_info->flow_color = acl_data->color;
        p_acl_qos_info->ds_acl_flow_priority_valid = TRUE;
    }

    /* dsFwdPtr */
    if (0x0 != acl_data->ds_fwd_ptr && !p_acl_qos_info->ds_acl_ds_fwd_ptr_valid)
    {
        pkt_info->ds_fwd_ptr_valid = TRUE;
        pkt_info->ds_fwd_ptr = acl_data->ds_fwd_ptr +
                               (((L3_TYPE_IPV4 == parser_result->layer3_type) || (L3_TYPE_IPV6 == parser_result->layer3_type))
                               ? ((parser_result->l3_s.ip_ecmp_hash) % ((0xF & acl_data->equal_cost_path_num) + 1)) : 0);
        /* ======== bug 4928 metal fix ECO begin ========= */
        //pkt_info->payload_packet_type = pkt_info->packet_type;
        //pkt_info->payload_offset = 0;
        if(acl_data->ccfi)
        {
            pkt_info->payload_packet_type = pkt_info->packet_type;
            pkt_info->payload_offset = 0;
        }
        /* ======== bug 4928 metal fix ECO end ========= */
        p_acl_qos_info->ds_acl_ds_fwd_ptr_valid = TRUE;

        if (pkt_info->fatal_exception_valid && !ipe_acl_qos_ctl.fatal_exception_bypass_redirect)
        {
            pkt_info->fatal_exception_valid = FALSE;
        }
    }


    if (acl_data->timestamp_en && !pkt_info->exception_en && pkt_info->time_stamp_valid && !p_acl_qos_info->ds_acl_timestamp_valid)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PTP;
        p_acl_qos_info->ds_acl_timestamp_valid = TRUE;

        if (!pkt_info->discard && ipe_acl_qos_ctl.timestamp_packet_discard)
        {
            pkt_info->discard_type = IPE_DISCARD_PTP_ACL_EXCEPTION;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DsAcl discardPacket is set by acl2!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (acl_data->exception_to_cpu && !p_acl_qos_info->exception_to_cpu_valid)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_RESERVED1;
        p_acl_qos_info->exception_to_cpu_valid = TRUE;
    }

    if (!p_acl_qos_info->ds_acl_flow_id_valid)
    {
        if (0 != acl_data->flow_id)
        {
            pkt_info->flow_id = acl_data->flow_id;
            p_acl_qos_info->ds_acl_flow_id_valid = TRUE;
        }

        if (acl_data->match_app_data && pkt_info->app_data_valid)
        {
            cmd = DRV_IOR(IpeAclAppCam_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_app_cam));

            cmd = DRV_IOR(IpeAclAppCamResult_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_app_cam_result));

            for (cam_index = 0; cam_index < 8; cam_index++)
            {
                sal_memset(&acl_app_cam_tmp, 0, sizeof(acl_app_cam_tmp));
                sal_memset(&acl_app_cam_result_tmp, 0, sizeof(acl_app_cam_result_tmp));

                switch (cam_index)
                {
                    case 0:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask0;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value0;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid0;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id0;
                        break;
                    case 1:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask1;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value1;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid1;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id1;
                        break;
                    case 2:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask2;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value2;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid2;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id2;
                        break;
                    case 3:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask3;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value3;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid3;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id3;
                        break;
                    case 4:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask4;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value4;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid4;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id4;
                        break;
                    case 5:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask5;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value5;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid5;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id5;
                        break;
                    case 6:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask6;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value6;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid6;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id6;
                        break;
                    case 7:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask7;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value7;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid7;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id7;
                        break;
                    default:
                        break;
                }

                /* use parser1's appdata, had confirmed with peiyu */
                if ((parser_result1->l4_s.app_data & acl_app_cam_tmp.app_data_mask)
                     == (acl_app_cam_tmp.app_data_value & acl_app_cam_tmp.app_data_mask))
                {
                    if (acl_app_cam_result_tmp.result_valid)
                    {
                        pkt_info->flow_id = acl_app_cam_result_tmp.flow_id;
                        p_acl_qos_info->ds_acl_flow_id_valid = TRUE;
                        break;
                    }
                }
            }
        }
    }


    /* VLAN tag editing */
    if (ACLQOS_STAG_ACTION_NONE != acl_data->s_tag_action && !p_acl_qos_info->ds_acl_stag_action_valid)
    {
        p_acl_qos_info->ds_acl_stag_action_valid = TRUE;
        p_acl_qos_info->svlan_id = (acl_data->svlan_id11_4<<4)
                             | (acl_data->svlan_id3_2<<2) | acl_data->svlan_id1_0;;
        p_acl_qos_info->scos = (acl_data->scos2<<2)|acl_data->scos1_0;;
        p_acl_qos_info->scfi = acl_data->scfi;
        p_acl_qos_info->s_tag_action = acl_data->s_tag_action;
        p_acl_qos_info->s_vlan_id_action = acl_data->s_vlan_id_action;
        p_acl_qos_info->s_cos_action = acl_data->s_cos_action;
        p_acl_qos_info->s_cfi_action = acl_data->s_cfi_action;
    }

    if (ACLQOS_CTAG_ACTION_NONE != acl_data->c_tag_action && !p_acl_qos_info->ds_acl_ctag_action_valid)
    {
        p_acl_qos_info->ds_acl_ctag_action_valid = TRUE;
        p_acl_qos_info->cvlan_id = acl_data->cvlan_id;
        p_acl_qos_info->ccos = acl_data->ccos;
        p_acl_qos_info->ccfi = acl_data->ccfi;
        p_acl_qos_info->c_tag_action = acl_data->c_tag_action;
        p_acl_qos_info->c_vlan_id_action = acl_data->c_vlan_id_action;
        p_acl_qos_info->c_cos_action = acl_data->c_cos_action;
        p_acl_qos_info->c_cfi_action = acl_data->c_cfi_action;
        p_acl_qos_info->ctag_add_mode = acl_data->ctag_add_mode;
    }

    if (acl_data->svlan_tpid_index_en && !p_acl_qos_info->ds_acl_svlan_tpid_index_valid)
    {
        p_acl_qos_info->ds_acl_svlan_tpid_index_valid = TRUE;
        p_acl_qos_info->svlan_tpid_index = acl_data->svlan_tpid_index;
    }

    if (0 != acl_data->outer_vlan_status && !p_acl_qos_info->ds_acl_outer_vlan_status_valid)
    {
        p_acl_qos_info->ds_acl_outer_vlan_status_valid = TRUE;
        p_acl_qos_info->outer_vlan_status = IS_BIT_SET(acl_data->outer_vlan_status,0);
    }

    /* new DSCP */
    if (acl_data->dscp_valid && !p_acl_qos_info->ds_acl_dscp_valid)
    {
        pkt_info->acl_dscp_valid = TRUE;
        pkt_info->acl_dscp = acl_data->acl_dscp;
        p_acl_qos_info->ds_acl_dscp_valid = TRUE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_acl_qos_process_ds_acl3
 * Purpose:    PROCESS_DS_ACL sub-routine
 * Parameters:
 * Input:      acl_qos_info -- acl qos module variables
 *             in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Return:     DRV_E_NONE -- success.
 *             Other -- ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_acl_qos_process_ds_acl3(ipe_in_pkt_t* in_pkt, cm_ipe_acl_qos_info_t* p_acl_qos_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t* parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;
    ds_acl_t* acl_data = NULL;
    ipe_acl_qos_ctl_t ipe_acl_qos_ctl;
    uint16 random_threshold = 0;
    uint32 random = 0;
    uint32 cmd = 0;
    uint8 chip_id = in_pkt->chip_id;
    uint32 cam_index = 0;
    uint16 stats_ptr = 0;

    ipe_acl_app_cam_t ipe_acl_app_cam;
    ipe_acl_app_cam_result_t ipe_acl_app_cam_result;
    cm_ipe_acl_app_cam_c_t acl_app_cam_tmp;
    cm_ipe_acl_app_cam_result_c_t acl_app_cam_result_tmp;

    sal_memset(&ipe_acl_app_cam, 0, sizeof(ipe_acl_app_cam));
    sal_memset(&ipe_acl_app_cam_result, 0, sizeof(ipe_acl_app_cam_result));

    /* get DSAclQos Data */
    acl_data = (ds_acl_t *)pkt_info->acl_data3;

    sal_memset(&ipe_acl_qos_ctl, 0, sizeof(ipe_acl_qos_ctl));
    cmd = DRV_IOR(IpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_qos_ctl));


    /* process discard flags */
    if (acl_data->discard_packet
        && ((OAM_NONE == pkt_info->rx_oam_type) || ipe_acl_qos_ctl.oam_obey_acl_discard))   /* IP BFD ?? */
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_ACLQOS_DISCARD_PKT;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DsAcl discardPacket is set by acl3!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (acl_data->deny_bridge)
    {
        pkt_info->deny_bridge = TRUE;
    }

    if (acl_data->deny_learning)
    {
        pkt_info->deny_learning = TRUE;
    }

    if (acl_data->deny_route)
    {
        pkt_info->deny_route = TRUE;
    }

    /* process random log */
    ctcutil_rand(0, 0x7FFF, &random); /* software random may be diffrent from ASIC */
    random_threshold = (1 << acl_data->random_threshold_shift);
    if (acl_data->random_log_en && (random < random_threshold))
    {
        pkt_info->acl_log_en3 = TRUE;
        pkt_info->acl_log_id3 = acl_data->acl_log_id;
    }

    /* flow policer */
    if (0x0 != acl_data->flow_policer_ptr && !p_acl_qos_info->ds_acl_flow_policer_valid)
    {
        pkt_info->flow_policer_valid = TRUE;
        pkt_info->flow_policer_ptr = acl_data->flow_policer_ptr;
        p_acl_qos_info->ds_acl_flow_policer_valid = TRUE;
    }

    if (0x0 != acl_data->agg_flow_policer_ptr && !p_acl_qos_info->ds_acl_agg_flow_policer_valid)
    {
        pkt_info->agg_flow_policer_valid = TRUE;
        pkt_info->agg_flow_policer_ptr = acl_data->agg_flow_policer_ptr;
        p_acl_qos_info->ds_acl_agg_flow_policer_valid = TRUE;
    }

    /* stats */
    stats_ptr = (acl_data->stats_ptr15_14 << 14)|(acl_data->stats_ptr13_12 << 12)|
                (acl_data->stats_ptr11_4 << 4)|(acl_data->stats_ptr3_0);
    if (0x0 != stats_ptr)
    {
        p_acl_qos_info->acl3_stats_valid = TRUE;
        p_acl_qos_info->acl3_stats_ptr = stats_ptr;
    }


    /* overwrite qos policy */
    if (QOS_POLICY_INVALID != acl_data->qos_policy && !p_acl_qos_info->ds_acl_qos_policy_valid)
    {
        pkt_info->qos_policy = acl_data->qos_policy;
        p_acl_qos_info->ds_acl_qos_policy_valid = TRUE;
    }

    /* overwrite qosDomain[2:0] */
    if (0 != acl_data->qos_domain && !p_acl_qos_info->ds_acl_qos_domain_valid)
    {
        pkt_info->qos_domain = acl_data->qos_domain;
        p_acl_qos_info->ds_acl_qos_domain_valid = TRUE;
    }

    /* copy priority field */
    if (0x0 != acl_data->color && !p_acl_qos_info->ds_acl_flow_priority_valid)
    {
        p_acl_qos_info->flow_priority_valid = TRUE;
        p_acl_qos_info->flow_priority = acl_data->priority;
        p_acl_qos_info->flow_color = acl_data->color;
        p_acl_qos_info->ds_acl_flow_priority_valid = TRUE;
    }

    /* dsFwdPtr */
    if (0x0 != acl_data->ds_fwd_ptr && !p_acl_qos_info->ds_acl_ds_fwd_ptr_valid)
    {
        pkt_info->ds_fwd_ptr_valid = TRUE;
        pkt_info->ds_fwd_ptr = acl_data->ds_fwd_ptr +
                               (((L3_TYPE_IPV4 == parser_result->layer3_type) || (L3_TYPE_IPV6 == parser_result->layer3_type))
                               ? ((parser_result->l3_s.ip_ecmp_hash) % ((0xF & acl_data->equal_cost_path_num) + 1)) : 0);
        /* ======== bug 4928 metal fix ECO begin ========= */
        //pkt_info->payload_packet_type = pkt_info->packet_type;
        //pkt_info->payload_offset = 0;
        if(acl_data->ccfi)
        {
            pkt_info->payload_packet_type = pkt_info->packet_type;
            pkt_info->payload_offset = 0;
        }
        /* ======== bug 4928 metal fix ECO end ========= */
        p_acl_qos_info->ds_acl_ds_fwd_ptr_valid = TRUE;

        if (pkt_info->fatal_exception_valid && !ipe_acl_qos_ctl.fatal_exception_bypass_redirect)
        {
            pkt_info->fatal_exception_valid = FALSE;
        }
    }

    if (acl_data->timestamp_en && !pkt_info->exception_en && pkt_info->time_stamp_valid && !p_acl_qos_info->ds_acl_timestamp_valid)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PTP;

        if (!pkt_info->discard && ipe_acl_qos_ctl.timestamp_packet_discard)
        {
            pkt_info->discard_type = IPE_DISCARD_PTP_ACL_EXCEPTION;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DsAcl discardPacket is set by acl3!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (acl_data->exception_to_cpu && !p_acl_qos_info->exception_to_cpu_valid)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_RESERVED1;
        p_acl_qos_info->exception_to_cpu_valid = TRUE;
    }

    if (!p_acl_qos_info->ds_acl_flow_id_valid)
    {
        if (0 != acl_data->flow_id)
        {
            pkt_info->flow_id = acl_data->flow_id;
            p_acl_qos_info->ds_acl_flow_id_valid = TRUE;
        }

        if (acl_data->match_app_data && pkt_info->app_data_valid)
        {
            cmd = DRV_IOR(IpeAclAppCam_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_app_cam));

            cmd = DRV_IOR(IpeAclAppCamResult_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_acl_app_cam_result));

            for (cam_index = 0; cam_index < 8; cam_index++)
            {
                sal_memset(&acl_app_cam_tmp, 0, sizeof(acl_app_cam_tmp));
                sal_memset(&acl_app_cam_result_tmp, 0, sizeof(acl_app_cam_result_tmp));

                switch (cam_index)
                {
                    case 0:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask0;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value0;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid0;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id0;
                        break;
                    case 1:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask1;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value1;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid1;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id1;
                        break;
                    case 2:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask2;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value2;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid2;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id2;
                        break;
                    case 3:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask3;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value3;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid3;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id3;
                        break;
                    case 4:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask4;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value4;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid4;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id4;
                        break;
                    case 5:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask5;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value5;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid5;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id5;
                        break;
                    case 6:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask6;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value6;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid6;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id6;
                        break;
                    case 7:
                        acl_app_cam_tmp.app_data_mask = ipe_acl_app_cam.app_data_mask7;
                        acl_app_cam_tmp.app_data_value = ipe_acl_app_cam.app_data_value7;
                        acl_app_cam_result_tmp.result_valid = ipe_acl_app_cam_result.result_valid7;
                        acl_app_cam_result_tmp.flow_id = ipe_acl_app_cam_result.flow_id7;
                        break;
                    default:
                        break;
                }

                /* use parser1's appdata, had confirmed with peiyu */
                if ((parser_result1->l4_s.app_data & acl_app_cam_tmp.app_data_mask)
                     == (acl_app_cam_tmp.app_data_value & acl_app_cam_tmp.app_data_mask))
                {
                    if (acl_app_cam_result_tmp.result_valid)
                    {
                        pkt_info->flow_id = acl_app_cam_result_tmp.flow_id;
                        p_acl_qos_info->ds_acl_flow_id_valid = TRUE;
                        break;
                    }
                }
            }
        }
    }


    /* VLAN tag editing */
    if (ACLQOS_STAG_ACTION_NONE != acl_data->s_tag_action && !p_acl_qos_info->ds_acl_stag_action_valid)
    {
        p_acl_qos_info->ds_acl_stag_action_valid = TRUE;
        p_acl_qos_info->svlan_id = (acl_data->svlan_id11_4<<4)
                             | (acl_data->svlan_id3_2<<2) | acl_data->svlan_id1_0;
        p_acl_qos_info->scos = (acl_data->scos2<<2)|acl_data->scos1_0;
        p_acl_qos_info->scfi = acl_data->scfi;
        p_acl_qos_info->s_tag_action = acl_data->s_tag_action;
        p_acl_qos_info->s_vlan_id_action = acl_data->s_vlan_id_action;
        p_acl_qos_info->s_cos_action = acl_data->s_cos_action;
        p_acl_qos_info->s_cfi_action = acl_data->s_cfi_action;
    }

    if (ACLQOS_CTAG_ACTION_NONE != acl_data->c_tag_action && !p_acl_qos_info->ds_acl_ctag_action_valid)
    {
        p_acl_qos_info->ds_acl_ctag_action_valid = TRUE;
        p_acl_qos_info->cvlan_id = acl_data->cvlan_id;
        p_acl_qos_info->ccos = acl_data->ccos;
        p_acl_qos_info->ccfi = acl_data->ccfi;
        p_acl_qos_info->c_tag_action = acl_data->c_tag_action;
        p_acl_qos_info->c_vlan_id_action = acl_data->c_vlan_id_action;
        p_acl_qos_info->c_cos_action = acl_data->c_cos_action;
        p_acl_qos_info->c_cfi_action = acl_data->c_cfi_action;
        p_acl_qos_info->ctag_add_mode = acl_data->ctag_add_mode;
    }

    if (acl_data->svlan_tpid_index_en && !p_acl_qos_info->ds_acl_svlan_tpid_index_valid)
    {
        p_acl_qos_info->ds_acl_svlan_tpid_index_valid = TRUE;
        p_acl_qos_info->svlan_tpid_index = acl_data->svlan_tpid_index;
    }

    if (0 != acl_data->outer_vlan_status && !p_acl_qos_info->ds_acl_outer_vlan_status_valid)
    {
        p_acl_qos_info->ds_acl_outer_vlan_status_valid = TRUE;
        p_acl_qos_info->outer_vlan_status = IS_BIT_SET(acl_data->outer_vlan_status,0);
    }

    /* new DSCP */
    if (acl_data->dscp_valid && !p_acl_qos_info->ds_acl_dscp_valid)
    {
        pkt_info->acl_dscp_valid = TRUE;
        pkt_info->acl_dscp = acl_data->acl_dscp;
        p_acl_qos_info->ds_acl_dscp_valid = TRUE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_ipe_acl_qos_process_flow_stats
 * Purpose:    process flow stats
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_acl_qos_process_flow_stats(ipe_in_pkt_t *in_pkt, cm_ipe_acl_qos_info_t* p_acl_qos_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)in_pkt->pkt_info;
    uint8 acl_stats0_valid = FALSE;
    uint8 acl_stats1_valid = FALSE;
    uint16 acl_stats0_ptr = 0;
    uint16 acl_stats1_ptr = 0;

    /* ACL flow stats priority: acl0 > acl1 > acl2 > acl3 */

    if (p_acl_qos_info->acl0_stats_valid)
    {
        acl_stats0_valid = TRUE;
        acl_stats0_ptr = p_acl_qos_info->acl0_stats_ptr;
    }

    if (p_acl_qos_info->acl1_stats_valid)
    {
        if (!acl_stats0_valid)
        {
            acl_stats0_valid = TRUE;
            acl_stats0_ptr = p_acl_qos_info->acl1_stats_ptr;
        }
        else
        {
            acl_stats1_valid = TRUE;
            acl_stats1_ptr = p_acl_qos_info->acl1_stats_ptr;
        }
    }

    if (p_acl_qos_info->acl2_stats_valid)
    {
        if (!acl_stats0_valid)
        {
            acl_stats0_valid = TRUE;
            acl_stats0_ptr = p_acl_qos_info->acl2_stats_ptr;
        }
        else if (!acl_stats1_valid)
        {
            acl_stats1_valid = TRUE;
            acl_stats1_ptr = p_acl_qos_info->acl2_stats_ptr;
        }
    }

    if (p_acl_qos_info->acl3_stats_valid)
    {
        if (!acl_stats0_valid)
        {
            acl_stats0_valid = TRUE;
            acl_stats0_ptr = p_acl_qos_info->acl3_stats_ptr;
        }
        else if (!acl_stats1_valid)
        {
            acl_stats1_valid = TRUE;
            acl_stats1_ptr = p_acl_qos_info->acl3_stats_ptr;
        }
    }

    if (acl_stats0_valid)
    {
        pkt_info->flow_stats0_valid = TRUE;
        pkt_info->flow_stats0_ptr = acl_stats0_ptr;
    }

    if (acl_stats1_valid)
    {
        pkt_info->flow_stats1_valid = TRUE;
        pkt_info->flow_stats1_ptr = acl_stats1_ptr;
    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_ipe_acl_qos_vlan_tag_edit_info
 * Purpose:    vlan tag edit info
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 *             p_acl_qos_info -- merged acl vlan tag info of DsAclQos
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_acl_qos_vlan_tag_edit_info(ipe_in_pkt_t *in_pkt, cm_ipe_acl_qos_info_t* p_acl_qos_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t *)pkt_info->parser_rslt;

    /* svlan tpid index */
    if (p_acl_qos_info->ds_acl_svlan_tpid_index_valid)
    {
        pkt_info->svlan_tpid_index = p_acl_qos_info->svlan_tpid_index;
    }

    /* outer vlan status */
    if (p_acl_qos_info->ds_acl_outer_vlan_status_valid)
    {
        pkt_info->outer_vlan_is_cvlan = p_acl_qos_info->outer_vlan_status;
    }

    /* svlan tag */
    if (p_acl_qos_info->ds_acl_stag_action_valid
        && (parser_result->l2_s.svlan_id_valid
            || ((ACLQOS_STAG_ACTION_ADD == p_acl_qos_info->s_tag_action ) && !parser_result->l2_s.svlan_id_valid)))
    {
        pkt_info->svlan_tag_operation_valid = TRUE;
        pkt_info->stag_action = p_acl_qos_info->s_tag_action;

        if ((ACLQOS_SVLAN_ID_ACTION_SWAP == p_acl_qos_info->s_vlan_id_action)
            && parser_result->l2_s.cvlan_id_valid)
        {
            pkt_info->svlan_id = parser_result->l2_s.cvlan_id;
        }
        else if ((ACLQOS_SVLAN_ID_ACTION_SWAP == p_acl_qos_info->s_vlan_id_action)
                && !parser_result->l2_s.cvlan_id_valid)
        {
            pkt_info->svlan_id = pkt_info->default_vlan_id;
        }
        else if (ACLQOS_SVLAN_ID_ACTION_USER == p_acl_qos_info->s_vlan_id_action)
        {
            pkt_info->svlan_id = p_acl_qos_info->svlan_id;
        }

        if ((ACLQOS_SCOS_ACTION_SWAP == p_acl_qos_info->s_cos_action)
            && parser_result->l2_s.cvlan_id_valid)
        {
            pkt_info->source_cos = parser_result->l2_s.ctag_cos;
        }
        else if (( ACLQOS_SCOS_ACTION_SWAP == p_acl_qos_info->s_cos_action)
                && !parser_result->l2_s.cvlan_id_valid)
        {
            pkt_info->source_cos = pkt_info->default_pcp;
        }
        else if (ACLQOS_SCOS_ACTION_USER == p_acl_qos_info->s_cos_action)
        {
            pkt_info->source_cos = p_acl_qos_info->scos;
        }

        if ((ACLQOS_SCFI_ACTION_SWAP == p_acl_qos_info->s_cfi_action)
            && parser_result->l2_s.cvlan_id_valid)
        {
            pkt_info->source_cfi= parser_result->l2_s.ctag_cfi;
        }
        else if ((ACLQOS_SCFI_ACTION_SWAP == p_acl_qos_info->s_cfi_action)
                && !parser_result->l2_s.cvlan_id_valid)
        {
            pkt_info->source_cfi = pkt_info->default_dei;
        }
        else if (ACLQOS_SCFI_ACTION_USER == p_acl_qos_info->s_cfi_action)
        {
            pkt_info->source_cfi = p_acl_qos_info->scfi;
        }
    }

    /* cvlan tag */
    if (p_acl_qos_info->ds_acl_ctag_action_valid
        && (parser_result->l2_s.cvlan_id_valid
            || ((ACLQOS_CTAG_ACTION_ADD == p_acl_qos_info->c_tag_action) && !parser_result->l2_s.cvlan_id_valid)))
    {
        pkt_info->cvlan_tag_operation_valid = TRUE;
        pkt_info->ctag_action = p_acl_qos_info->c_tag_action;

        if ((ACLQOS_CVLAN_ID_ACTION_SWAP == p_acl_qos_info->c_vlan_id_action)
            && parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->cvlan_id = parser_result->l2_s.svlan_id;
        }
        else if ((ACLQOS_CVLAN_ID_ACTION_SWAP == p_acl_qos_info->c_vlan_id_action)
                && !parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->cvlan_id = pkt_info->default_vlan_id;
        }
        else if (ACLQOS_CVLAN_ID_ACTION_USER == p_acl_qos_info->c_vlan_id_action)
        {
            pkt_info->cvlan_id = p_acl_qos_info->cvlan_id;
        }

        if ((ACLQOS_CCOS_ACTION_SWAP == p_acl_qos_info->c_cos_action)
            && parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->ctag_cos = parser_result->l2_s.stag_cos;
        }
        else if ((ACLQOS_CCOS_ACTION_SWAP == p_acl_qos_info->c_cos_action)
                && !parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->ctag_cos = pkt_info->default_pcp;
        }
        else if (ACLQOS_CCOS_ACTION_USER == p_acl_qos_info->c_cos_action)
        {
            pkt_info->ctag_cos = p_acl_qos_info->ccos;
        }

        if ((ACLQOS_CCFI_ACTION_SWAP == p_acl_qos_info->c_cfi_action)
            && parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->ctag_cfi = parser_result->l2_s.stag_cfi;
        }
        else if ((ACLQOS_CCFI_ACTION_SWAP == p_acl_qos_info->c_cfi_action)
                && !parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->ctag_cfi = pkt_info->default_dei;
        }
        else if (ACLQOS_CCFI_ACTION_USER == p_acl_qos_info->c_cfi_action)
        {
            pkt_info->ctag_cfi = p_acl_qos_info->ccfi;
        }

        pkt_info->src_ctag_offset_type = parser_result->l2_s.svlan_id_valid; /* add ctag after stag */

        if ((ACLQOS_CTAG_ACTION_ADD == p_acl_qos_info->c_tag_action) && parser_result->l2_s.svlan_id_valid && p_acl_qos_info->ctag_add_mode)
        {
            pkt_info->src_ctag_offset_type = 0; /* add ctag after mac */

        }
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:      _cm_ipe_acl_qos_pre_classification
 * Purpose:    PRE_CLASSIFICATION sub-routine
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_acl_qos_pre_classification(ipe_in_pkt_t *in_pkt, cm_ipe_acl_qos_info_t* p_acl_qos_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)in_pkt->pkt_info;
    uint32 table_index = 0xffffffff;
    uint32 table_id = MaxTblId_t;
    ipe_classification_cos_map_t ipe_classification_cos_map_table;
    ipe_classification_dscp_map_t ipe_classification_dscp_map_table;
    ipe_classification_precedence_map_t ipe_classification_precedence_map_table;
    ipe_classification_path_map_t ipe_classification_path_map_table;
    ipe_ipg_ctl_t ipe_ipg_ctl;/* ipg used for policing */
    ipe_acl_qos_ctl_t ipe_acl_qos_ctl;
    uint32 cmd = 0;

    sal_memset(&ipe_classification_cos_map_table, 0, sizeof(ipe_classification_cos_map_table));
    sal_memset(&ipe_classification_dscp_map_table, 0, sizeof(ipe_classification_dscp_map_table));
    sal_memset(&ipe_classification_precedence_map_table, 0, sizeof(ipe_classification_precedence_map_table));
    sal_memset(&ipe_classification_path_map_table, 0, sizeof(ipe_classification_path_map_table));
    sal_memset(&ipe_ipg_ctl, 0, sizeof(ipe_ipg_ctl));

    sal_memset(&ipe_acl_qos_ctl, 0, sizeof(ipe_acl_qos_ctl));
    cmd = DRV_IOR(IpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_acl_qos_ctl));

    switch(pkt_info->qos_policy)
    {
        case QOS_POLICY_TRUST_PORT:
            /* trust port */
            table_index = (pkt_info->qos_domain << 4)
                           | (pkt_info->default_pcp << 1)
                           | pkt_info->default_dei;
            table_id = IpeClassificationCosMap_t;
            break;
        case QOS_POLICY_COPY_OUTER:
            /* trust outer (tunnel) */
            pkt_info->priority  = pkt_info->outer_priority;
            pkt_info->color = pkt_info->outer_color;
            break;
        case QOS_POLICY_TRUST_COS:
            /* trust COS */
            table_index = (pkt_info->qos_domain << 4)
                           | (pkt_info->classify_source_cos << 1)
                           | pkt_info->classify_source_cfi;
            table_id = IpeClassificationCosMap_t;
            break;
        case QOS_POLICY_TRUST_DSCP:
            /* trust DSCP */
            if ((L3_TYPE_IP == pkt_info->classify_layer3_type)
                || (L3_TYPE_IPV4 == pkt_info->classify_layer3_type)
                || (L3_TYPE_IPV6 == pkt_info->classify_layer3_type))
            {
                /* TRUST DSCP */
                table_index = (pkt_info->qos_domain << 8)
                               | (pkt_info->classify_tos & 0xFF);
                table_id = IpeClassificationDscpMap_t;
            }
            else if (!pkt_info->mpls_overwrite_priority)
            {
                /* nonIP MPLS will be done in MPLS processor */
                table_index = (pkt_info->qos_domain << 4)
                               | (pkt_info->classify_source_cos << 1)
                               | pkt_info->classify_source_cfi;
                table_id = IpeClassificationCosMap_t;
            }
            break;
        case QOS_POLICY_TRUST_IP_PRECEDENCE:
            /* trust IP-Precedence */
            if ((L3_TYPE_IP == pkt_info->classify_layer3_type)
                || (L3_TYPE_IPV4 == pkt_info->classify_layer3_type)
                || (L3_TYPE_IPV6 == pkt_info->classify_layer3_type))
            {
                /* trust IP-precedence */
                table_index = (pkt_info->qos_domain << 3)
                               | ((pkt_info->classify_tos >> 5) & 0x7);
                table_id = IpeClassificationPrecedenceMap_t;
            }
            else if (!pkt_info->mpls_overwrite_priority)
            {
                /* non IP */
                table_index = (pkt_info->qos_domain << 4)
                               | (pkt_info->classify_source_cos << 1)
                               | pkt_info->classify_source_cfi;
                table_id  = IpeClassificationCosMap_t;
            }
            break;
        case QOS_POLICY_TRUST_STAG_COS:
            /* trust stag-cos */
            table_index = (pkt_info->qos_domain << 4)
                           | (pkt_info->classify_stag_cos << 1)
                           | (pkt_info->classify_stag_cfi);
            table_id = IpeClassificationCosMap_t;
            break;
         case QOS_POLICY_TRUST_CTAG_COS:
            /* trust ctag-cos */
            table_index = (pkt_info->qos_domain << 4)
                           | (pkt_info->classify_ctag_cos<< 1)
                           | (pkt_info->classify_ctag_cfi);
            table_id = IpeClassificationCosMap_t;
            break;
        default:
            break;
    }

    if (MaxTblId_t != table_id)
    {
        cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);
        switch (table_id)
        {
            case IpeClassificationCosMap_t:
                DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, table_index/4, cmd,
                                                  &ipe_classification_cos_map_table));
                switch (table_index % 4)
                {
                    case 0:
                        pkt_info->priority = ipe_classification_cos_map_table.priority0;
                        pkt_info->color = ipe_classification_cos_map_table.color0;
                        break;
                    case 1:
                        pkt_info->priority = ipe_classification_cos_map_table.priority1;
                        pkt_info->color = ipe_classification_cos_map_table.color1;
                        break;
                    case 2:
                        pkt_info->priority = ipe_classification_cos_map_table.priority2;
                        pkt_info->color = ipe_classification_cos_map_table.color2;
                        break;
                    case 3:
                        pkt_info->priority = ipe_classification_cos_map_table.priority3;
                        pkt_info->color = ipe_classification_cos_map_table.color3;
                        break;
                    default:
                        break;
                }
                break;

            case IpeClassificationDscpMap_t:
                DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, table_index/4, cmd,
                                                  &ipe_classification_dscp_map_table));
                switch (table_index % 4)
                {
                    case 0:
                        pkt_info->priority = ipe_classification_dscp_map_table.priority0;
                        pkt_info->color = ipe_classification_dscp_map_table.color0;
                        break;
                    case 1:
                        pkt_info->priority = ipe_classification_dscp_map_table.priority1;
                        pkt_info->color = ipe_classification_dscp_map_table.color1;
                        break;
                    case 2:
                        pkt_info->priority = ipe_classification_dscp_map_table.priority2;
                        pkt_info->color = ipe_classification_dscp_map_table.color2;
                        break;
                    case 3:
                        pkt_info->priority = ipe_classification_dscp_map_table.priority3;
                        pkt_info->color = ipe_classification_dscp_map_table.color3;
                        break;
                    default:
                        break;
                }
                break;

            case IpeClassificationPrecedenceMap_t:
                DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, table_index / 4, cmd,
                                                  &ipe_classification_precedence_map_table));
                switch (table_index % 4)
                {
                    case 0:
                        pkt_info->priority = ipe_classification_precedence_map_table.priority0;
                        pkt_info->color = ipe_classification_precedence_map_table.color0;
                        break;
                    case 1:
                        pkt_info->priority = ipe_classification_precedence_map_table.priority1;
                        pkt_info->color = ipe_classification_precedence_map_table.color1;
                        break;
                    case 2:
                        pkt_info->priority = ipe_classification_precedence_map_table.priority2;
                        pkt_info->color = ipe_classification_precedence_map_table.color2;
                        break;
                    default:
                        pkt_info->priority = ipe_classification_precedence_map_table.priority3;
                        pkt_info->color = ipe_classification_precedence_map_table.color3;
                        break;
                }
                break;

            default:
                break;
        }
    }

    if (pkt_info->user_priority_valid)
    {
        pkt_info->priority = pkt_info->user_priority;

        if (!ipe_acl_qos_ctl.user_priority_only)
        {
            pkt_info->color = pkt_info->user_color;
        }
    }

    if (p_acl_qos_info->flow_priority_valid)
    {
        pkt_info->priority = p_acl_qos_info->flow_priority;

        if (!ipe_acl_qos_ctl.flow_priority_only)
        {
            pkt_info->color = p_acl_qos_info->flow_color;
        }
    }

    cmd = DRV_IOR(IpeClassificationPathMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, pkt_info->priority / 8, cmd,
                                      &ipe_classification_path_map_table));

    switch (pkt_info->priority % 8)
    {
        case 0:
            pkt_info->priority_path_select = ipe_classification_path_map_table.priority_path_select0;
            break;
        case 1:
            pkt_info->priority_path_select = ipe_classification_path_map_table.priority_path_select1;
            break;
        case 2:
            pkt_info->priority_path_select = ipe_classification_path_map_table.priority_path_select2;
            break;
        case 3:
            pkt_info->priority_path_select = ipe_classification_path_map_table.priority_path_select3;
            break;
        case 4:
            pkt_info->priority_path_select = ipe_classification_path_map_table.priority_path_select4;
            break;
        case 5:
            pkt_info->priority_path_select = ipe_classification_path_map_table.priority_path_select5;
            break;
        case 6:
            pkt_info->priority_path_select = ipe_classification_path_map_table.priority_path_select6;
            break;
        case 7:
            pkt_info->priority_path_select = ipe_classification_path_map_table.priority_path_select7;
            break;
        default:
            break;
    }


    cmd = DRV_IOR(IpeIpgCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_ipg_ctl));

    switch (pkt_info->ipg_index)
    {
        case 0:
            pkt_info->ipg = ipe_ipg_ctl.ipg0;
            break;
        case 1:
            pkt_info->ipg = ipe_ipg_ctl.ipg1;
            break;
        case 2:
            pkt_info->ipg = ipe_ipg_ctl.ipg2;
            break;
        case 3:
            pkt_info->ipg = ipe_ipg_ctl.ipg3;
            break;
       default:
            break;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_ipe_acl_qos_handle
 * Purpose:    IPE ACL & QOS handle process.
 * Parameters:
 * Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Return:     DRV_E_NONE -- success.
 *             Other -- ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_ipe_acl_qos_handle(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    cm_ipe_acl_qos_info_t acl_qos_info;
    uint8 discard = FALSE;
    uint8 acl_result_valid0_hash = FALSE;

    uint8 acl_result_valid0 = FALSE;
    uint8 acl_result_valid1 = FALSE;
    uint8 acl_result_valid2 = FALSE;
    uint8 acl_result_valid3 = FALSE;

    discard = pkt_info->discard;
    sal_memset(&acl_qos_info, 0, sizeof(acl_qos_info));

    if (pkt_info->acl_hash_lookup_en)
    {
        acl_result_valid0_hash = pkt_info->acl_hash_result_valid;
    }

    if (acl_result_valid0_hash)
    {
        acl_result_valid0 = acl_result_valid0_hash;
        sal_memcpy(pkt_info->acl_data0, pkt_info->acl_hash_data, sizeof(ds_acl_t));
    }
    else if (pkt_info->acl_en0)
    {
        acl_result_valid0 = pkt_info->acl_tcam_result_valid0;
    }

    if (pkt_info->acl_en1)
    {
        acl_result_valid1 = pkt_info->acl_tcam_result_valid1;
    }

    if (pkt_info->acl_en2)
    {
        acl_result_valid2 = pkt_info->acl_tcam_result_valid2;
    }

    if (pkt_info->acl_en3)
    {
        acl_result_valid3 = pkt_info->acl_tcam_result_valid3;
    }

    if ((!discard) && acl_result_valid0)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE AclQos Process");
        DRV_IF_ERROR_RETURN(_cm_ipe_acl_qos_process_ds_acl0(in_pkt, &acl_qos_info));
    }

    if ((!discard) && acl_result_valid1)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE AclQos Process");
        DRV_IF_ERROR_RETURN(_cm_ipe_acl_qos_process_ds_acl1(in_pkt, &acl_qos_info));
    }

    if ((!discard) && acl_result_valid2)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE AclQos Process");    
        DRV_IF_ERROR_RETURN(_cm_ipe_acl_qos_process_ds_acl2(in_pkt, &acl_qos_info));
    }

    if ((!discard) && acl_result_valid3)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE AclQos Process");
        DRV_IF_ERROR_RETURN(_cm_ipe_acl_qos_process_ds_acl3(in_pkt, &acl_qos_info));
    }

    DRV_IF_ERROR_RETURN(_cm_ipe_acl_qos_process_flow_stats(in_pkt, &acl_qos_info));

    DRV_IF_ERROR_RETURN(_cm_ipe_acl_qos_vlan_tag_edit_info(in_pkt, &acl_qos_info));

    DRV_IF_ERROR_RETURN(_cm_ipe_acl_qos_pre_classification(in_pkt, &acl_qos_info));


    return DRV_E_NONE;
}

