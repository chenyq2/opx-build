/****************************************************************************
 * cm_ipe_trill.c:  Performs IPE FCoE switch operation.
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Version:        V1.0.
 * Author:         Jiang
 * Date:           2010-10-12.
 * Reason:         First Create.
 *
 * Modify History:
 * Reversion:      V1.01
 * Author:         XuZx
 * Date:           2010-11-15.
 * Reason:         Revise for first formal spec.
 *
 * Reversion:      V1.02
 * Author:         XuZx
 * Date:           2010-11-22.
 * Reason:         Revise for second formal spec.
 *
 * Reversion:      V2.0
 * Author:         Jiangsz
 * Date:           2011-04-08.
 * Reason:         sync spec V2.0.
 *
 * Reversion:      V4.2
 * Author:         Jiangsz
 * Date:           2011-07-04.
 * Reason:         sync spec V4.2.1.
 *
 * Reversion:      V4.29.0
 * Author:         wangcy
 * Date:           2011-10-08.
 * Reason:         sync spec V4.29.0.
 *
 * Reversion:      V5.1.0
 * Author:         Wangcy
 * Date:           2011-12-12.
 * Reason:         sync spec v5.1.0.
 *
 * Reversion:      V5.7.0
 * Author:         Wangcy
 * Date:           2012-1-17.
 * Reason:         sync spec v5.7.0.
 *
 * Reversion:    V5.11.0
 * Author:       ZhouW
 * Date:         2012-03-01.
 * Reason:       sync spec v5.11.0.
 *
 * Reversion:    V5.13.0
 * Author:       Wangcy
 * Date:         2012-03-12.
 * Reason:       sync spec v5.13.0.
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "ctcutil_rand.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/

/****************************************************************************
 * Name:       cm_ipe_trill_handle
 * Purpose:    IPE TRILL handle process.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE -- Success.
 *             Other -- ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 cm_ipe_trill_handle(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;
    uint8 trill_packet = FALSE;
    ds_trill_da_t* ds_trill_da_tcam = NULL;
    ds_trill_da_t* ds_trill_da_fib = NULL;
    ds_trill_da_t* ds_trill_da = NULL;
    ds_trill_da_t* ds_trill_vlan_da_fib = NULL;
    ipe_trill_ctl_t ipe_trill_ctl;

    uint32 cmd = 0;
    uint8 trill_vlan_da_fib_result_valid = FALSE;
    uint8 trill_result_valid  = FALSE;
    uint8 trill_da_tcam_result_valid = FALSE;
    uint8 trill_da_fib_result_valid = FALSE;
    uint8 default_entry_valid = FALSE;

    ipe_ecmp_ctl_t ipe_ecmp_ctl;
    ds_ecmp_state_t ds_ecmp_state;
    ds_ecmp_group_t ds_ecmp_group;
    ipe_ecmp_channel_state_t ipe_ecmp_channel_state;

    uint8 dlb_en = FALSE;
    uint8 ecmp_hash = 0;
    uint8 current_ts = 0;
    uint32 dest_channel[16] = {0};
    uint32 channel_class[16] = {0};
    uint8 equal_cost_path_sel = 0;
    uint8 ecmp_mem_num = 0;
    uint8 index = 0;
    uint8 max_channel_class = 0;
    uint8 max_channel_class_index_array[16] = {0};
    uint8 max_channel_class_count = 0;
    uint32 random = 0;
    uint32 ds_ecmp_ptr = 0;
    uint32 ds_fwd_ptr = 0;

    sal_memset(&ipe_trill_ctl, 0, sizeof(ipe_trill_ctl));
    cmd = DRV_IOR(IpeTrillCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_trill_ctl));

    /* POP_DS */
    if (pkt_info->is_trill_ucast)
    {
        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1))      /* TCAM lookup enabled */
        {
            trill_da_tcam_result_valid = pkt_info->trill_da_tcam_result_valid;
            ds_trill_da_tcam = (ds_trill_da_t* )pkt_info->trill_da_data_tcam;
        }

        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0)) /* FIB lookup enabled */
        {
            trill_da_fib_result_valid = pkt_info->trill_da_fib_result_valid;
            default_entry_valid = pkt_info->trill_da_fib_default_entry_valid;
            ds_trill_da_fib = (ds_trill_da_t* )pkt_info->trill_da_data_fib;
        }

        /* First hash */
        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0) && trill_da_fib_result_valid && !default_entry_valid)
        {
            trill_result_valid = trill_da_fib_result_valid;
            ds_trill_da = ds_trill_da_fib;
        }
        /* Second hash */
        else if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1) && trill_da_tcam_result_valid)
        {
            trill_result_valid = trill_da_tcam_result_valid;
            ds_trill_da = ds_trill_da_tcam;
        }
        /* Third hash */
        else if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0) && trill_da_fib_result_valid)
        {
            trill_result_valid = trill_da_fib_result_valid;
            ds_trill_da = ds_trill_da_fib;
        }
    }
    else if (pkt_info->is_trill_mcast)
    {
        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1)) /* TCAM lookup enabled */
        {
            trill_da_tcam_result_valid = pkt_info->trill_da_tcam_result_valid;
            ds_trill_da_tcam = (ds_trill_da_t* )pkt_info->trill_da_data_tcam;
        }

        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0)) /* FIB lookup enabled */
        {
            trill_da_fib_result_valid = pkt_info->trill_da_fib_result_valid;
            ds_trill_da_fib = (ds_trill_da_t* )pkt_info->trill_da_data_fib;
            default_entry_valid = pkt_info->trill_da_fib_default_entry_valid;

            trill_vlan_da_fib_result_valid = pkt_info->trill_vlan_da_fib_result_valid;
            ds_trill_vlan_da_fib = (ds_trill_da_t* )pkt_info->trill_vlan_da_data_fib;
        }

        /* First hash vlan + mac */
        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0) && trill_vlan_da_fib_result_valid)
        {
            trill_result_valid = trill_vlan_da_fib_result_valid;
            ds_trill_da = ds_trill_vlan_da_fib;
        }
        /* Second hash mac */
        else if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0) && trill_da_fib_result_valid && !default_entry_valid)
        {
            trill_result_valid = trill_da_fib_result_valid;
            ds_trill_da = ds_trill_da_fib;
        }
        /* Third TCAM */
        else if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1) && trill_da_tcam_result_valid)
        {
            trill_result_valid = trill_da_tcam_result_valid;
            ds_trill_da = ds_trill_da_tcam;
        }
        /* Fourth Default */
        else if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0) && trill_da_fib_result_valid)
        {
            trill_result_valid = trill_da_fib_result_valid;
            ds_trill_da = ds_trill_da_fib;
        }
    }

    //RPF check in Tunnel Decap

    trill_packet = (!pkt_info->discard) && trill_result_valid
                   && (pkt_info->is_trill_ucast || pkt_info->is_trill_mcast)
                   && (!pkt_info->deny_route || ipe_trill_ctl.trill_bypass_deny_route);

    if (trill_packet)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Trill Process");

        /* FORWARDING */
        /* All-RBridge MAC address check */
        if (pkt_info->is_trill_mcast
            && ds_trill_da->mcast_check_en
            && (!pkt_info->is_all_rbridge_address))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_TRILL_MCAST_ADDR_CHK_ERR;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Trill mcast and is all bridge address!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        /* TTL check */
        if((0 != ds_trill_da->ttl_limit) && (pkt_info->packet_ttl < ds_trill_da->ttl_limit))
        {
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = FATAL_EXP_TRILL_TTL_CHECK_FAIL;
        }

        if (ipe_trill_ctl.version_check_en && !pkt_info->trill_version_match)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_TRILL_VERSION_CHK_ERR;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Trill version is not correct!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (parser_result->l3_s.ip_options && ds_trill_da->trill_option_escape_en)
        {
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = FATAL_EXP_TRILL_OPTION;
        }

        if (parser_result->l3_s.ip_da.trill.is_trill_channel && ds_trill_da->trill_channel_en
            && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = ipe_trill_ctl.trill_channel_exception_sub_index;
        }

        if (parser_result->l3_s.ip_da.trill.is_esadi && ds_trill_da->esadi_check_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = ds_trill_da->exception_sub_index;
        }

        pkt_info->is_esadi = parser_result->l3_s.ip_da.trill.is_esadi;

        dlb_en = ds_trill_da->dlb_en;
        ecmp_hash = ipe_trill_ctl.trill_ecmp_hash_mode ? (parser_result->l2_s.mac_ecmp_hash) : (parser_result->l3_s.ip_ecmp_hash);

        pkt_info->ds_fwd_ptr_valid = TRUE;

        if (ds_trill_da->next_hop_ptr_valid)
        {
            pkt_info->ds_fwd_ptr_valid = FALSE;
            pkt_info->next_hop_ptr_valid = TRUE;
            pkt_info->ad_next_hop_ptr = ds_trill_da->ds_fwd_ptr;  /* used as ad_next_hop_ptr */
            pkt_info->ad_dest_map = ds_trill_da->ad_dest_map3_0
                                 | (ds_trill_da->ad_dest_map11_4 << 4)
                                 | (ds_trill_da->ad_dest_map14_12 << 12)
                                 | (ds_trill_da->ad_dest_map16_15 << 15)
                                 | (ds_trill_da->ad_dest_map21_17 << 17);
            pkt_info->ad_length_adjust_type = IS_BIT_SET(ds_trill_da->ad_other, 5);/* used as lengthadjusttype */
            pkt_info->ad_critical_packet = IS_BIT_SET(ds_trill_da->ad_other, 4);/* used as criticalpacket */
            pkt_info->ad_next_hop_ext = IS_BIT_SET(ds_trill_da->ad_other, 3);/* used as nexthopext */
            pkt_info->ad_send_local_phy_port = IS_BIT_SET(ds_trill_da->ad_other, 2);/* used as sendLocalPhyPort */
            pkt_info->ad_aps_type = ds_trill_da->ad_other & 0x3;/* used as adApsType */
            pkt_info->ad_speed = ds_trill_da->ad_speed;
        }
        else if (ds_trill_da->priority_path_en)
        {
            pkt_info->ds_fwd_ptr = ds_trill_da->ds_fwd_ptr + pkt_info->priority_path_select;
        }
        else if (dlb_en)
        {

            sal_memset(&ipe_ecmp_ctl, 0, sizeof(ipe_ecmp_ctl_t));
            cmd = DRV_IOR(IpeEcmpCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_ecmp_ctl));
    
        
            switch (ipe_ecmp_ctl.ecmp_flow_num)
            {
               case 0:
                   ds_ecmp_ptr = ((ds_trill_da->equal_cost_path_num & 0x3) << 8) | (ecmp_hash & 0xFF);
                   break;
               case 1:
                   ds_ecmp_ptr = ((ds_trill_da->equal_cost_path_num & 0x7) << 7) | (ecmp_hash & 0x7F);
                   break;
               case 2:
                   ds_ecmp_ptr = ((ds_trill_da->equal_cost_path_num & 0xF) << 6) | (ecmp_hash & 0x3F);
                   break;
               case 3:
                   ds_ecmp_ptr = ((ds_trill_da->equal_cost_path_num & 0xF) << 5) | (ecmp_hash & 0x1F);
                   break;
               default:
                   break;
            }

            sal_memset(&ds_ecmp_state, 0, sizeof(ds_ecmp_state));
            cmd = DRV_IOR(DsEcmpState_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, ds_ecmp_ptr, cmd, &ds_ecmp_state));

            /* ECMP bundle to same ports */
            sal_memset(&ds_ecmp_group, 0, sizeof(ds_ecmp_group));
            cmd = DRV_IOR(DsEcmpGroup_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, ds_trill_da->equal_cost_path_num, cmd, &ds_ecmp_group));

            /* flow active */
            if (ds_ecmp_state.active && ((current_ts - ds_ecmp_state.old_ts) < ipe_ecmp_ctl.ts_threshold))
            {
               pkt_info->ds_fwd_ptr = ds_ecmp_state.ds_fwd_ptr;
               ds_ecmp_state.old_ts = current_ts;
            }
            /* flow inactive */
            else
            {
               sal_memset(&ipe_ecmp_channel_state, 0, sizeof(ipe_ecmp_channel_state));
               cmd = DRV_IOR(IpeEcmpChannelState_t, DRV_ENTRY_FLAG);
               DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_ecmp_channel_state));

               for (index = 0; index < 16; index++)
               {
                   cmd = DRV_IOR(DsEcmpGroup_t,
                            (DsEcmpGroup_DestChannel0_f + index));
                   DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &(dest_channel[index])));

                   cmd = DRV_IOR(IpeEcmpChannelState_t,
                            (IpeEcmpChannelState_ChannelClass0_f + (dest_channel[index] & 0x3F)));
                   DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &(channel_class[index])));
               }

               ecmp_mem_num = ds_ecmp_group.ecmp_mem_num;

               max_channel_class = channel_class[0];/* store current max_channel_class */
               max_channel_class_index_array[0] = 0;/* store index of all max_channel_class item */
               max_channel_class_count = 1;/* max_channel_class item count */

               for (index = 1; index < ecmp_mem_num; index++)
               {
                   if (channel_class[index] == max_channel_class)
                   {
                       max_channel_class_index_array[max_channel_class_count] = index;
                       max_channel_class_count ++;
                   }
                   else if (channel_class[index] > max_channel_class)
                   {
                       max_channel_class_index_array[0] = index;
                       max_channel_class_count = 1;
                   }
               }

               if (1 == max_channel_class_count)
               {
                   index = max_channel_class_index_array[0];
               }
               else
               {
                   ctcutil_rand(0, 0x7FFF, &random); /* software random may be diffrent from ASIC */
                   index = max_channel_class_index_array[random % max_channel_class_count];
               }

               cmd = DRV_IOR(DsEcmpGroup_t, (DsEcmpGroup_DsFwdPtr0_f + (index & 0xF)));
               DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ds_fwd_ptr));

               ds_ecmp_state.ds_fwd_ptr = ds_fwd_ptr;
               pkt_info->ds_fwd_ptr = ds_fwd_ptr;
               ds_ecmp_state.old_ts = current_ts;
               ds_ecmp_state.active = TRUE;
            }

            /* write  ecmpstate back */
            cmd = DRV_IOW(DsEcmpState_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, ds_ecmp_ptr, cmd, &ds_ecmp_state));
        }
        else
        {
            switch (ds_trill_da->equal_cost_path_num)
            {
                case 0:
                    equal_cost_path_sel = 0;
                    break;
                case 1:
                    equal_cost_path_sel = IS_BIT_SET(ecmp_hash, 0);
                    break;
                case 2:
                    equal_cost_path_sel = ecmp_hash % 3;
                    break;
                case 3:
                    equal_cost_path_sel = ecmp_hash & 0x3;
                    break;
                case 4:
                    equal_cost_path_sel = ecmp_hash % 5;
                    break;
                case 5:
                    equal_cost_path_sel = ecmp_hash % 6;
                    break;
                case 6:
                    equal_cost_path_sel = ecmp_hash % 7;
                    break;
                case 7:
                    equal_cost_path_sel = ecmp_hash & 0x7;
                    break;
                default:
                    equal_cost_path_sel = ecmp_hash & 0xF;
                    break;
            }

            pkt_info->ds_fwd_ptr = ds_trill_da->ds_fwd_ptr + equal_cost_path_sel;
        }

        pkt_info->payload_packet_type = pkt_info->packet_type;           /* original packet */
        pkt_info->payload_offset = ds_trill_da->payload_offset;
    }

    return DRV_E_NONE;
}

