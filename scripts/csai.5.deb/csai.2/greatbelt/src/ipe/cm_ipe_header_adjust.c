/****************************************************************************
 * cm_ipe_header_adjust.c: Provides IPE multiplexing/loopback header adjust function.
 *
 * Copyright: (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:      V1.0
 * Author:        XuZx.
 * Date:          2010-10-09.
 * Reason:        Create for GreatBelt.
 *
 * Revision:      V1.0
 * Author:        MengZhw.
 * Date:          2010-11-15.
 * Reason:        SYNC GreatBelt Spec 1.0.
 *
 * Revision:      V2.0
 * Author:        XuZx.
 * Date:          2011-4-6.
 * Reason:        SYNC GreateBelt Spec 2.0.
 *
 * Revision:      V4.29
 * Author:        JiaK.
 * Date:          2011-9-28.
 * Reason:        SYNC GreateBelt Spec 4.28.
 *
 * Reversion:     V5.1.0
 * Author:        Wangcy
 * Date:          2011-12-12.
 * Reason:        sync spec v5.1.0.
 *
 * Reversion:     V5.6.0
 * Author:        Wangcy
 * Date:          2012-01-07.
 * Reason:        sync spec v5.6.0.
 *
 * Reversion:     V5.7.0
 * Author:        Wangcy
 * Date:          2012-01-17.
 * Reason:        sync spec v5.7.0.
 *
 * Reversion:     V5.11.0
 * Author:        ZhouW
 * Date:          2012-02-29.
 * Reason:        sync spec v5.11.0.
 *
 * Reversion:     V5.13.0
 * Author:        Wangcy
 * Date:          2012-03-12.
 * Reason:        sync spec v5.13.0.
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/
struct ipe_header_adjust_info_s
{
    uint8 packet_header_valid;
    uint8 mux_type;
};
typedef struct ipe_header_adjust_info_s ipe_header_adjust_info_t;

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_packet_header_decision
 * Purpose:    ipe header adjust packet header decision.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_packet_header_decision(ipe_in_pkt_t* p_in_pkt,ipe_header_adjust_info_t *ipe_header_adjust_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    uint8 chip_id = p_in_pkt->chip_id;
    uint16 ether_type = 0;
    uint16 udp_src_port = 0,udp_dest_port = 0;
    uint16 ip_protocol = 0;
    uint32 cmd;
    ipe_header_adjust_ctl_t ipe_header_adjust_ctl;
    uint8 is_tpid = FALSE;
    uint8 header_l3_offset = 0;
    uint8 packet_header_min_length = 0;

    sal_memset(&ipe_header_adjust_ctl, 0, sizeof(ipe_header_adjust_ctl));
    cmd = DRV_IOR(IpeHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_header_adjust_ctl));

    /* PACKET_HEADER_DECISION */
    if (MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITHOUT_TUNNEL == ipe_header_adjust_info->mux_type ||
        MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2 == ipe_header_adjust_info->mux_type ||
        MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2_AND_IPV4 == ipe_header_adjust_info->mux_type ||
        MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2_AND_IPV6  == ipe_header_adjust_info->mux_type ||
        MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_IPV4 == ipe_header_adjust_info->mux_type ||
        MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_IPV6 == ipe_header_adjust_info->mux_type)
    {/* With PacketHeader */
        if (MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITHOUT_TUNNEL == ipe_header_adjust_info->mux_type)
        {/* without L2/L3 tunnel header */
            ipe_header_adjust_info->packet_header_valid = TRUE;

            sal_memcpy((uint8 *)pkt_info->ingress_header, p_in_pkt->pkt, GREAT_BELT_HEADER_LEN);
            DRV_IF_ERROR_RETURN(swap32((uint32 *)pkt_info->ingress_header, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));

            packet_header_min_length = 32;
            pkt_info->packet_type = PKT_TYPE_RESERVED;
        }
        else
        {/* with L2/L3 tunnel header */
            if (MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2 == ipe_header_adjust_info->mux_type ||
                MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2_AND_IPV4 == ipe_header_adjust_info->mux_type ||
                MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2_AND_IPV6  == ipe_header_adjust_info->mux_type)
            {/* with L2 Header */

                /* cmodel:in SPEC headerMacDaCheck and headerMacDa[47:0] is not in PacketInfo */
                pkt_info->header_mac_da47_32 = MAKE_UINT16(p_in_pkt->pkt[0], p_in_pkt->pkt[1]);
                pkt_info->header_mac_da31_0
                    = MAKE_UINT32(p_in_pkt->pkt[2], p_in_pkt->pkt[3], p_in_pkt->pkt[4], p_in_pkt->pkt[5]);
                pkt_info->header_mac_da_check  = ipe_header_adjust_ctl.header_mac_da_check_en;

                /* VLAN check */
                is_tpid = MAKE_UINT16(p_in_pkt->pkt[12], p_in_pkt->pkt[13]) == ipe_header_adjust_ctl.header_tpid;
                if (is_tpid)
                {
                    ether_type = MAKE_UINT16(p_in_pkt->pkt[16], p_in_pkt->pkt[17]);
                }
                else
                {
                    ether_type = MAKE_UINT16(p_in_pkt->pkt[12], p_in_pkt->pkt[13]);
                }

                header_l3_offset = 14 + (is_tpid << 2);
                pkt_info->packet_type = PKT_TYPE_ETHERNETV2;
            }
            else
            {/* without L2 Header */
                header_l3_offset = 0;

                if (MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_IPV4 == ipe_header_adjust_info->mux_type)
                {
                    pkt_info->packet_type = PKT_TYPE_IPV4;
                }
                else
                {
                    pkt_info->packet_type = PKT_TYPE_IPV6;
                }
            }

            if (MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2 == ipe_header_adjust_info->mux_type)  /* only L2 Header */
            {
                if (ether_type == ipe_header_adjust_ctl.header_ether_type ||
                        ipe_header_adjust_ctl.header_ether_type_check_disable)
                {
                    ipe_header_adjust_info->packet_header_valid = TRUE;
                    pkt_info->payload_offset = 14 + (is_tpid << 2); /* Not including PacketHeader */
                    pkt_info->packet_length_adjust = pkt_info->payload_offset;

                    sal_memcpy((uint8 *)pkt_info->ingress_header, (p_in_pkt->pkt + header_l3_offset), GREAT_BELT_HEADER_LEN);
                    DRV_IF_ERROR_RETURN(swap32((uint32 *)pkt_info->ingress_header, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));

                    packet_header_min_length = 32 + header_l3_offset + 4; /* 4 Bytes CRC */
                }
            }
            else
            {
                if ((MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2_AND_IPV4 == ipe_header_adjust_info->mux_type && ether_type == 0x0800) ||
                    (MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_IPV4 == ipe_header_adjust_info->mux_type))  /* IPv4 */
                {
                    udp_src_port = ((p_in_pkt->pkt[header_l3_offset + 20]) << 8)
                                   | (p_in_pkt->pkt[header_l3_offset + 21]);
                    udp_dest_port = ((p_in_pkt->pkt[header_l3_offset + 22]) << 8)
                                    | (p_in_pkt->pkt[header_l3_offset + 23]);
                    ip_protocol = p_in_pkt->pkt[header_l3_offset + 9];

                    if (ipe_header_adjust_ctl.header_udp_en && (udp_dest_port == ipe_header_adjust_ctl.udp_dest_port)
                            && (udp_src_port == ipe_header_adjust_ctl.udp_src_port))
                    {
                        ipe_header_adjust_info->packet_header_valid = TRUE;
                        pkt_info->payload_offset = (header_l3_offset & 0x1F) + 20 + 8;
                        pkt_info->packet_length_adjust = pkt_info->payload_offset;

                        sal_memcpy((uint8 *)pkt_info->ingress_header, (p_in_pkt->pkt + header_l3_offset + 20 + 8), GREAT_BELT_HEADER_LEN);
                        DRV_IF_ERROR_RETURN(swap32((uint32 *)pkt_info->ingress_header, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));

                        packet_header_min_length = 60 + header_l3_offset + 4;
                    }
                    else if (ip_protocol == ipe_header_adjust_ctl.header_ip_protocol)
                    {
                        ipe_header_adjust_info->packet_header_valid = TRUE;
                        pkt_info->payload_offset = (header_l3_offset & 0x1F) + 20;
                        pkt_info->packet_length_adjust = pkt_info->payload_offset;

                        sal_memcpy((uint8 *)pkt_info->ingress_header, (p_in_pkt->pkt + (header_l3_offset & 0x1F) + 20), GREAT_BELT_HEADER_LEN);
                        DRV_IF_ERROR_RETURN(swap32((uint32 *)pkt_info->ingress_header, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));

                        packet_header_min_length = 52 + header_l3_offset + 4;
                    }
                }
                else if ((MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2_AND_IPV6 == ipe_header_adjust_info->mux_type && ether_type == 0x86DD) ||
                    (MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_IPV6 == ipe_header_adjust_info->mux_type))
                {
                    udp_src_port = ((p_in_pkt->pkt[header_l3_offset + 40]) << 8)
                                   | (p_in_pkt->pkt[header_l3_offset + 41]);
                    udp_dest_port = ((p_in_pkt->pkt[header_l3_offset + 42]) << 8)
                                    | (p_in_pkt->pkt[header_l3_offset + 43]);
                    ip_protocol = p_in_pkt->pkt[header_l3_offset + 6];

                    if (ipe_header_adjust_ctl.header_udp_en && (udp_dest_port == ipe_header_adjust_ctl.udp_dest_port)
                            && (udp_src_port == ipe_header_adjust_ctl.udp_src_port))
                    {
                        ipe_header_adjust_info->packet_header_valid = TRUE;
                        pkt_info->payload_offset = (header_l3_offset & 0x1F) + 40 + 8;
                        pkt_info->packet_length_adjust = pkt_info->payload_offset;

                        sal_memcpy((uint8 *)pkt_info->ingress_header, (p_in_pkt->pkt + (header_l3_offset & 0x1F) + 40 + 8), GREAT_BELT_HEADER_LEN);
                        DRV_IF_ERROR_RETURN(swap32((uint32 *)pkt_info->ingress_header, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));

                        packet_header_min_length = 80 + header_l3_offset + 4;
                    }
                    else if (ip_protocol == ipe_header_adjust_ctl.header_ip_protocol)
                    {
                        ipe_header_adjust_info->packet_header_valid = TRUE;
                        pkt_info->payload_offset = (header_l3_offset & 0x1F) + 40;
                        pkt_info->packet_length_adjust = pkt_info->payload_offset;

                        sal_memcpy((uint8 *)pkt_info->ingress_header, (p_in_pkt->pkt + (header_l3_offset & 0x1F) + 40), GREAT_BELT_HEADER_LEN);
                        DRV_IF_ERROR_RETURN(swap32((uint32 *)pkt_info->ingress_header, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));

                        packet_header_min_length = 72 + header_l3_offset + 4;
                    }
                }
            }
        }

        if ((!ipe_header_adjust_info->packet_header_valid && ipe_header_adjust_ctl.discard_non_packet_header)
            ||(ipe_header_adjust_info->packet_header_valid && (pkt_info->packet_length < packet_header_min_length)))
        {
            pkt_info->discard_type = IPE_DISCARD_STACKING_NETWORK_HEADER_CHK_ERR;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! packetheader not exist!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_regular_port_adjust
 * Purpose:    handle IPE regular port adjust.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_regular_port_adjust(ipe_in_pkt_t* p_in_pkt)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    uint8 chip_id = p_in_pkt->chip_id;
    uint8 channel_id = p_in_pkt->chan_id & 0x3F;
    uint32 cmd;
    ipe_header_adjust_phy_port_map_t ipe_header_adjust_phy_port_map;

    /*REGULAR PORT*/
    sal_memset(&ipe_header_adjust_phy_port_map, 0, sizeof(ipe_header_adjust_phy_port_map));
    cmd = DRV_IOR(IpeHeaderAdjustPhyPortMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, channel_id, cmd, &ipe_header_adjust_phy_port_map));

    pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;
    pkt_info->outer_priority = 0;
    pkt_info->outer_color = 0;
    pkt_info->mux_length_type = MUX_LENGTH_TYPE0;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_pe_format_adjust
 * Purpose:    handle IPE pe format adjust.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_pe_format_adjust(ipe_in_pkt_t* p_in_pkt)
{
    /* PE_FORMAT_ADJUST */
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    uint8* p_packet = p_in_pkt->pkt;
    uint8 chip_id = p_in_pkt->chip_id;
    uint32 mux_type = 0, mux_type_fieldid = 0;
    uint32 channel_id = p_in_pkt->chan_id & 0x3F;
    uint32 cmd = 0;
    uint32 use_logic_port = 0;
    uint8  chann_offset = 0;
    uint8  is_etag_tpid = FALSE;
    uint16 etag_source_vlan_id = 0;
    uint16 etag_vlan_id = 0;
    uint16 port_vlan_base = 0,symbol = 0;
    uint16 local_phy_port_temp = 0;
    uint8 cosmap_entry_index = (p_packet[14] >> 4) & 0xF;
    ipe_mux_header_adjust_ctl_t ipe_mux_header_adjust_ctl;
    ipe_header_adjust_phy_port_map_t ipe_header_adjust_phy_port_map;
    ipe_mux_header_cos_map_t ipe_mux_header_cos_map;

    mux_type_fieldid = IpePhyPortMuxCtl_MuxType0_f + (p_in_pkt->chan_id & 0x3F);
    cmd = DRV_IOR(IpePhyPortMuxCtl_t, mux_type_fieldid);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &mux_type));

    sal_memset(&ipe_mux_header_adjust_ctl, 0, sizeof(ipe_mux_header_adjust_ctl));
    cmd = DRV_IOR(IpeMuxHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_mux_header_adjust_ctl));

    sal_memset(&ipe_header_adjust_phy_port_map, 0, sizeof(ipe_header_adjust_phy_port_map));
    cmd = DRV_IOR(IpeHeaderAdjustPhyPortMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, channel_id, cmd,  &ipe_header_adjust_phy_port_map));

    sal_memset(&ipe_mux_header_cos_map, 0, sizeof(ipe_mux_header_cos_map));
    cmd = DRV_IOR(IpeMuxHeaderCosMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, cosmap_entry_index/4, cmd, &ipe_mux_header_cos_map));

    pkt_info->source_port_extender = ((MUX_HEADER_ADJUST_TYPE_PE_DOWNLINK_WITH_CASCADE == (mux_type & 0xF))
                || (MUX_HEADER_ADJUST_TYPE_PE_UPLINK == (mux_type & 0xF)));

    /* Port Extender TPID */
    is_etag_tpid = (MAKE_UINT16(p_packet[12], p_packet[13]) == ipe_mux_header_adjust_ctl.etag_tpid);

    if (is_etag_tpid)
    {
        etag_source_vlan_id = MAKE_UINT16((p_packet[14] & 0xF), p_packet[15]);
        etag_vlan_id = MAKE_UINT16((p_packet[16] & 0x3F), p_packet[17]);

        switch (cosmap_entry_index % 4) /* CSO + CFI */
        {
        case 0:
            pkt_info->outer_priority = ipe_mux_header_cos_map.priority0;
            pkt_info->outer_color = ipe_mux_header_cos_map.color0;
            break;
        case 1:
            pkt_info->outer_priority = ipe_mux_header_cos_map.priority1;
            pkt_info->outer_color = ipe_mux_header_cos_map.color1;
            break;
        case 2:
            pkt_info->outer_priority = ipe_mux_header_cos_map.priority2;
            pkt_info->outer_color = ipe_mux_header_cos_map.color2;
            break;
        case 3:
            pkt_info->outer_priority = ipe_mux_header_cos_map.priority3;
            pkt_info->outer_color = ipe_mux_header_cos_map.color3;
            break;
        default:
            break;
        }
    }

    if (IS_BIT_SET(channel_id, 5))
    {
        use_logic_port = ipe_mux_header_adjust_ctl.use_logic_port63_32;
        chann_offset = channel_id - 32;
    }
    else
    {
        use_logic_port = ipe_mux_header_adjust_ctl.use_logic_port31_0;
        chann_offset = channel_id;
    }

    /* Per chip based VLAN allocation (with same base),
       localPhyPort reservation in case of link aggregation like nexthop.*/
    if (MUX_HEADER_ADJUST_TYPE_CB_DOWNLINK == (mux_type & 0xF))  /* CB downlink */
    {
        if (is_etag_tpid && ((etag_vlan_id & 0xFFF) != 0))  /* E-tagged */
        {
            port_vlan_base = ipe_header_adjust_phy_port_map.port_vlan_base;
            symbol = ipe_header_adjust_phy_port_map.symbol;

            /* link aggregation can't use different localPhyPort */
            if (IS_BIT_SET(use_logic_port, chann_offset))
            {
                pkt_info->logic_src_port_valid = TRUE;
                pkt_info->logic_src_port = ((symbol) ? (etag_vlan_id - (port_vlan_base & 0xFFF)) : (etag_vlan_id + (port_vlan_base & 0x3FFF)));
                pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;
            }
            else
            {
                /* link aggregation can't use different localPhyPort */
                local_phy_port_temp = ((symbol) ? (etag_vlan_id - (port_vlan_base & 0xFFF)) : (etag_vlan_id + (port_vlan_base & 0xFFF)));

                if (local_phy_port_temp < MAX_LOCAL_PHY_PORT)
                {
                    pkt_info->local_phy_port = (local_phy_port_temp & 0x7F);
                }
                else
                {
                    if (!pkt_info->discard)
                    {
                        pkt_info->discard_type = IPE_DISCARD_MUX_PORT_ERR;
                        pkt_info->discard = TRUE;

                        CMODEL_DEBUG_OUT_INFO("++++ Discard! mux port error!\n");
                        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                    }
                }
            }
        }
        else        /* untagged */
        {
            pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;
        }
    }
    else if (MUX_HEADER_ADJUST_TYPE_PE_DOWNLINK_WITH_CASCADE == (mux_type & 0xF))  /* PE downlink (cascade port) */
    {
        pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;

        if (!is_etag_tpid)
        {
            pkt_info->source_port_extender = FALSE;
        }

        is_etag_tpid = FALSE;
    }
    else    /* PE uplink, use vlan forwarding,Upstream Port ??? */
    {
        port_vlan_base = ipe_header_adjust_phy_port_map.port_vlan_base;
        symbol = ipe_header_adjust_phy_port_map.symbol;

        /* Source */
        pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;

        if (is_etag_tpid && (((etag_vlan_id >> 12) & 0x3) != 0)) /* multicast */
        {
            if (etag_source_vlan_id == 0)
            {
                pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;
            }
            else if (IS_BIT_SET(use_logic_port, chann_offset))
            {
                pkt_info->logic_src_port_valid = TRUE;
                pkt_info->logic_src_port = ((symbol) ? (etag_source_vlan_id - (port_vlan_base & 0xFFF)) : (etag_source_vlan_id + (port_vlan_base & 0x3FFF)));
                pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;
            }
            else
            {

                local_phy_port_temp = ((symbol) ? (etag_source_vlan_id - (port_vlan_base & 0xFFF)) : (etag_source_vlan_id + (port_vlan_base & 0xFFF)));

                if (local_phy_port_temp < MAX_LOCAL_PHY_PORT)
                {
                    pkt_info->local_phy_port = (local_phy_port_temp & 0x7F);
                }
                else
                {
                    if (!pkt_info->discard)
                    {
                        pkt_info->discard_type = IPE_DISCARD_MUX_PORT_ERR;
                        pkt_info->discard = TRUE;
                        CMODEL_DEBUG_OUT_INFO("++++ Discard! mux port error,mux port is larger than 256!\n");
                        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                    }
                }
            }
        }

        /* Destination */
        if (is_etag_tpid && ((etag_vlan_id >> 12) & 0x3))        /* multicast */
        {
            pkt_info->mux_destination = (ipe_mux_header_adjust_ctl.port_extender_met_base<<6)
                                        + ((etag_vlan_id & 0x3FFF) - 4096);

            pkt_info->mux_destination_type = TRUE;  /* MuxMcastDest */
            pkt_info->mux_destination_valid = TRUE;
        }
        else if (is_etag_tpid && ((etag_vlan_id & 0xFFF) != 0))  /* unicast taggged */
        {
            pkt_info->mux_destination = ((symbol) ? (etag_vlan_id - (port_vlan_base & 0xFFF)) : (etag_vlan_id + (port_vlan_base & 0x3FFF)));
            pkt_info->mux_destination_type = FALSE; /* MuxUcastDest */
            pkt_info->mux_destination_valid = TRUE;
        }
        else                                                     /* unicast untagged */
        {
            pkt_info->mux_destination = ipe_mux_header_adjust_ctl.cpu_local_phy_port;
            pkt_info->mux_destination_type = FALSE;
            pkt_info->mux_destination_valid = TRUE;
        }
    }

    pkt_info->mux_length_type = is_etag_tpid? 2 : 0;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_packet_header_adjust
 * Purpose:
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_packet_header_adjust(ipe_in_pkt_t* p_in_pkt)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    uint32 cmd = 0;
    uint8 chip_id = p_in_pkt->chip_id;
    uint32 channel_id = p_in_pkt->chan_id;
    ipe_header_adjust_phy_port_map_t ipe_header_adjust_phy_port_map;
    ipe_header_adjust_ctl_t ipe_header_adjust_ctl;

    sal_memset(&ipe_header_adjust_ctl, 0, sizeof(ipe_header_adjust_ctl));
    cmd = DRV_IOR(IpeHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_header_adjust_ctl));

    sal_memset(&ipe_header_adjust_phy_port_map, 0, sizeof(ipe_header_adjust_phy_port_map));
    cmd = DRV_IOR(IpeHeaderAdjustPhyPortMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, channel_id, cmd, &ipe_header_adjust_phy_port_map));

    /* PACKET_HEADER_ADJUST */
    pkt_info->mux_length_type = MUX_LENGTH_TYPE0;
    pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;
    pkt_info->ingress_header_valid = TRUE; /* to IPE Fwd */
    pkt_info->bypass_all = ipe_header_adjust_ctl.packet_header_bypass_all;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_mux_fromat_adjust
 * Purpose:    handle IPE mux format adjust.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_mux_format_adjust(ipe_in_pkt_t* p_in_pkt)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    ipe_header_adjust_phy_port_map_t ipe_header_adjust_phy_port_map;
    ipe_mux_header_cos_map_t ipe_mux_header_cos_map;
    uint8  chip_id = p_in_pkt->chip_id;
    uint32 cmd = 0;
    uint32 channel_id = p_in_pkt->chan_id & 0x3F;
    uint8* p_packet = p_in_pkt->pkt;
    uint8 cosmap_entry_index = (p_packet[14] >> 4) & 0xF;

    sal_memset(&ipe_header_adjust_phy_port_map, 0, sizeof(ipe_header_adjust_phy_port_map));
    cmd = DRV_IOR(IpeHeaderAdjustPhyPortMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, channel_id, cmd, &ipe_header_adjust_phy_port_map));

    sal_memset(&ipe_mux_header_cos_map, 0, sizeof(ipe_mux_header_cos_map));
    cmd = DRV_IOR(IpeMuxHeaderCosMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, cosmap_entry_index/4, cmd, &ipe_mux_header_cos_map));

    /* MUX FORMAT ADJUST */
    /* per Channel PORT VLAN base */
    pkt_info->local_phy_port = (ipe_header_adjust_phy_port_map.symbol)?
                               ((((p_packet[14] & 0xF) << 8) | p_packet[15]) - ipe_header_adjust_phy_port_map.port_vlan_base):
                               ((((p_packet[14] & 0xF) << 8) | p_packet[15]) + ipe_header_adjust_phy_port_map.port_vlan_base);

    switch (cosmap_entry_index % 4)   /*  CSO + CFI */
    {
    case 0:
        pkt_info->outer_priority = ipe_mux_header_cos_map.priority0;
        pkt_info->outer_color = ipe_mux_header_cos_map.color0;
        break;
    case 1:
        pkt_info->outer_priority = ipe_mux_header_cos_map.priority1;
        pkt_info->outer_color = ipe_mux_header_cos_map.color1;
        break;
    case 2:
        pkt_info->outer_priority = ipe_mux_header_cos_map.priority2;
        pkt_info->outer_color = ipe_mux_header_cos_map.color2;
        break;
    case 3:
        pkt_info->outer_priority = ipe_mux_header_cos_map.priority3;
        pkt_info->outer_color = ipe_mux_header_cos_map.color3;
        break;
    default:
        break;
    }

    pkt_info->mux_length_type = MUX_LENGTH_TYPE1;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_evb_format_adjust
 * Purpose:    handle IPE evb pe format adjust.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_evb_format_adjust(ipe_in_pkt_t* p_in_pkt)
{
    /* EVB_FORMAT_ADJUST */
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    uint8* p_packet = p_in_pkt->pkt;
    uint8  chip_id = p_in_pkt->chip_id;
    uint32 channel_id = p_in_pkt->chan_id & 0x3F;
    uint32 cmd = 0;
    uint8  is_evb_tpid = 0;
    uint16 evb_vlan_id = 0;
    uint32 use_logic_port = 0;
    uint8  chann_offset = 0;
    uint8 cosmap_entry_index = (p_packet[14] >> 4) & 0xF;
    uint16 port_vlan_base = 0,local_phy_port_temp = 0;
    uint8 symbol = 0;
    ipe_mux_header_adjust_ctl_t ipe_mux_header_adjust_ctl;
    ipe_header_adjust_phy_port_map_t ipe_header_adjust_phy_port_map;
    ipe_mux_header_cos_map_t ipe_mux_header_cos_map;

    sal_memset(&ipe_mux_header_adjust_ctl, 0, sizeof(ipe_mux_header_adjust_ctl));
    cmd = DRV_IOR(IpeMuxHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_mux_header_adjust_ctl));

    sal_memset(&ipe_header_adjust_phy_port_map, 0, sizeof(ipe_header_adjust_phy_port_map));
    cmd = DRV_IOR(IpeHeaderAdjustPhyPortMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, channel_id, cmd, &ipe_header_adjust_phy_port_map));

    sal_memset(&ipe_mux_header_cos_map, 0, sizeof(ipe_mux_header_cos_map));
    cmd = DRV_IOR(IpeMuxHeaderCosMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, cosmap_entry_index/4, cmd, &ipe_mux_header_cos_map));

    /* VEPA,S-CHANNEL */

    is_evb_tpid = (MAKE_UINT16(p_packet[12], p_packet[13]) == ipe_mux_header_adjust_ctl.evb_tpid);

    if (is_evb_tpid)
    {
        evb_vlan_id = MAKE_UINT16((p_packet[14] & 0xF), p_packet[15]);

        switch (cosmap_entry_index % 4) /* CSO + CFI */
        {
        case 0:
            pkt_info->outer_priority = ipe_mux_header_cos_map.priority0;
            pkt_info->outer_color = ipe_mux_header_cos_map.color0;
            break;
        case 1:
            pkt_info->outer_priority = ipe_mux_header_cos_map.priority1;
            pkt_info->outer_color = ipe_mux_header_cos_map.color1;
            break;
        case 2:
            pkt_info->outer_priority = ipe_mux_header_cos_map.priority2;
            pkt_info->outer_color = ipe_mux_header_cos_map.color2;
            break;
        case 3:
            pkt_info->outer_priority = ipe_mux_header_cos_map.priority3;
            pkt_info->outer_color = ipe_mux_header_cos_map.color3;
            break;
        default:
            break;
        }
    }

    if (is_evb_tpid  && ((evb_vlan_id & 0xFFF) != 0)) /* EVB tagged */
    {
        port_vlan_base = ipe_header_adjust_phy_port_map.port_vlan_base;
        symbol = ipe_header_adjust_phy_port_map.symbol;

        if (IS_BIT_SET(channel_id, 5))
        {
            use_logic_port = ipe_mux_header_adjust_ctl.use_logic_port63_32;
            chann_offset = channel_id - 32;
        }
        else
        {
            use_logic_port = ipe_mux_header_adjust_ctl.use_logic_port31_0;
            chann_offset = channel_id;
        }

        if (IS_BIT_SET(use_logic_port, chann_offset))
        {
            pkt_info->logic_src_port_valid = TRUE;
            pkt_info->logic_src_port = ((symbol) ? (evb_vlan_id - (port_vlan_base & 0xFFF)) : (evb_vlan_id + (port_vlan_base & 0x3FFF)));
            pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;
        }
        else
        {
            local_phy_port_temp = ((symbol) ? (evb_vlan_id - (port_vlan_base & 0xFFF)) : (evb_vlan_id + (port_vlan_base & 0xFFF)));

            if (local_phy_port_temp < MAX_LOCAL_PHY_PORT)
            {
                pkt_info->local_phy_port = (local_phy_port_temp & 0x7F);
            }
            else
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = IPE_DISCARD_MUX_PORT_ERR;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! mux port error,mux port is larger than 256!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
        }
    }
    else                                     /* untagged */
    {
        pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;
    }

    pkt_info->mux_length_type = is_evb_tpid ? 1: 0;
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_packet_type
 * Purpose:    handle IPE packet type.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_packet_type(ipe_in_pkt_t* p_in_pkt)
{
    uint16 vlan1 = 0, vlan2 = 0;
    uint8 is_vlan_1 = FALSE, is_vlan_2 = FALSE;
    uint8 is_vlan = 0;
    uint8 vlan_offset_type = 0;
    uint8 chip_id = p_in_pkt->chip_id;
    uint8 *packet = p_in_pkt->pkt;
    uint32 cmd = 0, tag_offset = 0;
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    ipe_mux_header_adjust_ctl_t ipe_mux_header_adjust_ctl;

    sal_memset(&ipe_mux_header_adjust_ctl, 0, sizeof(ipe_mux_header_adjust_ctl));
    cmd = DRV_IOR(IpeMuxHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_mux_header_adjust_ctl));

    if (!pkt_info->ingress_header_valid)
    {
        vlan1 = MAKE_UINT16(packet[12 + (pkt_info->mux_length_type<<2)],
                            packet[13 + (pkt_info->mux_length_type<<2)]);
        is_vlan_1 = ((0x8100 == vlan1) || (vlan1 == ipe_mux_header_adjust_ctl.tpid));

        vlan2 = MAKE_UINT16(packet[16 + (pkt_info->mux_length_type<<2)],
                            packet[17 + (pkt_info->mux_length_type<<2)]);
        is_vlan_2 = ((0x8100 == vlan2) || (vlan2 == ipe_mux_header_adjust_ctl.tpid));

        is_vlan = ((is_vlan_1<<1) | is_vlan_2);

        switch (is_vlan)
        {
            case 3:
                vlan_offset_type = 2;
                break;
            case 2:
                vlan_offset_type = 1;
                break;
            default:
                vlan_offset_type = 0;
                break;
        }

        if (ipe_mux_header_adjust_ctl.cn_tag_tpid ==
            MAKE_UINT16(packet[12 + ((pkt_info->mux_length_type + vlan_offset_type) << 2)],
                        packet[13 + ((pkt_info->mux_length_type + vlan_offset_type) << 2)]))
        {
            tag_offset = (vlan_offset_type + 1 + pkt_info->mux_length_type) << 2;
        }
        else
        {
            tag_offset = (vlan_offset_type + pkt_info->mux_length_type) << 2;
        }

        /* cnmBytes{0..35} to IPE FWD, shared with IngressHeader */

    }

    /* IPE only support Cut-through mode */
    /* Packet length calculated by IPE Header Adjust. 0 indicates packetLength[13:0]
       greate than 256 */
    /* real packet length known in Eop */
    /* so extra message sent to IPE Classification for policing and IPE Forwarding for
       stats in Eop */

    pkt_info->from_cpu_or_oam = FALSE;
    pkt_info->outer_ttl = 0;
    pkt_info->customer_id = 0;
    pkt_info->customer_id_valid = FALSE;
    pkt_info->src_port_isolate_id = 0; /*no port isolation*/

    pkt_info->is_loop = FALSE;
    pkt_info->user_vlan_ptr_valid = FALSE;
    pkt_info->user_vlan_ptr = 0;

    pkt_info->src_dscp_valid = FALSE;
    pkt_info->src_dscp = 0;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_inter_laken_adjust_process
 * Purpose:    handle IPE inter laken adjust.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_inter_laken_adjust_process(ipe_in_pkt_t* p_in_pkt)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    uint8 chip_id = p_in_pkt->chip_id;
    uint32 cmd;
    ipe_mux_header_adjust_ctl_t ipe_mux_header_adjust_ctl;
    ipe_header_adjust_ctl_t ipe_header_adjust_ctl;
    uint32 channel_id = p_in_pkt->chan_id & 0x3F;

    sal_memset(&ipe_mux_header_adjust_ctl, 0, sizeof(ipe_mux_header_adjust_ctl));
    cmd = DRV_IOR(IpeMuxHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_mux_header_adjust_ctl));

    sal_memset(&ipe_header_adjust_ctl, 0, sizeof(ipe_header_adjust_ctl));
    cmd = DRV_IOR(IpeHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_header_adjust_ctl));

    /* Only for Packet Mode, unware of segment mode. use two localPhyPort for interLaken channel,
       PacketHeader.sourcePort to EPE to encode InterLaken Channel. Only send localPhyPort, not linkAgg */
    /* per interLaken channel CRC enable */
    if (channel_id < 32)
    {
         pkt_info->non_crc = !IS_BIT_SET(ipe_mux_header_adjust_ctl.interlaken_crc_valid31_0, channel_id);
    }
    else if (channel_id < MAX_CHANID)
    {
        pkt_info->non_crc = !IS_BIT_SET(ipe_mux_header_adjust_ctl.interlaken_crc_valid63_32, (channel_id-32));
    }

    pkt_info->mux_length_type = MUX_LENGTH_TYPE0;

    pkt_info->local_phy_port = channel_id + ipe_mux_header_adjust_ctl.inter_laken_local_phy_port_base;

    if (ipe_mux_header_adjust_ctl.inter_laken_packet_header_en)
    {
        pkt_info->bypass_all = ipe_header_adjust_ctl.packet_header_bypass_all;
        pkt_info->packet_type = PKT_TYPE_RESERVED; /* unknown, ignore Parser */
        pkt_info->ingress_header_valid = TRUE;

        sal_memcpy((uint8 *)pkt_info->ingress_header, p_in_pkt->pkt, GREAT_BELT_HEADER_LEN);
        DRV_IF_ERROR_RETURN(swap32((uint32 *)pkt_info->ingress_header, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_loopback_header_adjust_process
 * Purpose:    handle IPE loopback header adjust.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_loopback_header_adjust_process(ipe_in_pkt_t* p_in_pkt)
{
    ipe_loopback_header_adjust_ctl_t ipe_loopback_header_adjust_ctl;
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    greatbelt_packet_header_t cm_packet_header;
    ms_packet_header_t temp_bridge_header;
    uint8 *pkt = p_in_pkt->pkt;
    uint8 chip_id = p_in_pkt->chip_id;
    uint8 bytes_to_remove = 0;
    uint8 customer_exp = 0;
    uint8* p_packet = p_in_pkt->pkt;
    uint32 customer_label = 0;
    uint32 next_hop_ptr = 0;
    uint32 color_index = IpeHeaderAdjustExpMap_Color0_f;
    uint32 priority_index = IpeHeaderAdjustExpMap_Priority0_f;
    uint32 color = 0;
    uint32 priority = 0;
    uint32 cmd = 0;
    uint32 new_pkt_crc = 0;
    uint32 packet_offset = 0;

    /* use htonX function, alway keep to host endian */
    sal_memset(&temp_bridge_header, 0, sizeof(temp_bridge_header));
    sal_memcpy(&temp_bridge_header, p_in_pkt->module_bus.packet_header, GREAT_BELT_HEADER_LEN);
    DRV_IF_ERROR_RETURN(swap32((uint32 *)(&temp_bridge_header), GREAT_BELT_HEADER_LEN /4, NETWORK_TO_HOST));
    cm_gen_greatbelt_packet_header(&temp_bridge_header, &cm_packet_header, TRUE);

    /* RECOVER_FIELDS */
    sal_memset(&ipe_loopback_header_adjust_ctl, 0, sizeof(ipe_loopback_header_adjust_ctl));
    cmd = DRV_IOR(IpeLoopbackHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_loopback_header_adjust_ctl));

    pkt_info->packet_length = p_in_pkt->module_bus.pkt_len;/*packet_lenght from bufferRetrieve */
    pkt_info->local_phy_port = (cm_packet_header.next_hop_ptr & 0x7F);
    pkt_info->packet_type = cm_packet_header.packet_type;
    pkt_info->outer_priority = cm_packet_header.priority;
    pkt_info->outer_color = cm_packet_header.color;
    pkt_info->outer_ttl = cm_packet_header.ttl_u.ttl;
    pkt_info->oam_use_fid = cm_packet_header.rxtx_fcl0_u.oam_use_fid;
    pkt_info->is_loop = TRUE;
    packet_offset = cm_packet_header.packet_offset + cm_packet_header.from_fabric ? 32:0;

    if (cm_packet_header.svlan_tpid_index_u.share1.mpls_label_space_valid)
    {
        pkt_info->mpls_label_space_valid = cm_packet_header.svlan_tpid_index_u.share1.mpls_label_space_valid;
        pkt_info->fid = cm_packet_header.fid_u.share1.fid;
    }

    if (OPERATION_TYPE_NORMAL == cm_packet_header.operation_type) /* normal */
    {
        pkt_info->src_port_isolate_id = cm_packet_header.source_port_isolate_id_u.source_port_isolate_id;
    }
    else
    {
        pkt_info->src_port_isolate_id = 0;
    }
    pkt_info->mux_length_type = cm_packet_header.mux_length_type;
    pkt_info->non_crc = cm_packet_header.non_crc;
    pkt_info->from_cpu_or_oam = cm_packet_header.from_cpu_or_oam;
    next_hop_ptr = cm_packet_header.next_hop_ptr;
    pkt_info->src_dscp_valid = TRUE;
    pkt_info->src_dscp = cm_packet_header.ip_sa_u.share1.src_dscp;

    pkt_info->logic_port_type = IS_BIT_SET(cm_packet_header.next_hop_ptr, 10)
        || cm_packet_header.logic_port_type;

    if (ipe_loopback_header_adjust_ctl.always_use_header_logic_port)
    {
        pkt_info->logic_src_port = cm_packet_header.logic_src_port_u.share1.logic_src_port;
        pkt_info->logic_src_port_valid = TRUE;
    }

    if (OPERATION_TYPE_NORMAL == cm_packet_header.operation_type)
    {
        if (cm_packet_header.fid_u.share1.capwap_tunnel_valid)
        {
            pkt_info->capwap_tunnel_valid = TRUE;
            pkt_info->roaming_state = cm_packet_header.rxtx_fcl2_1_u.capwap_state;
            pkt_info->capwap_tunnel_type = cm_packet_header.rxtx_fcl3_u.capwap_tunnel_type;
            pkt_info->logic_src_port = cm_packet_header.logic_src_port_u.share1.logic_src_port;
            pkt_info->logic_src_port_valid = TRUE;

            if (ipe_loopback_header_adjust_ctl.capwap_default_vlan_valid)
            {
                pkt_info->use_default_vlan_tag_valid = TRUE;
                pkt_info->user_default_vlan_id = cm_packet_header.src_vlan_id_u.src_vlan_id;
                pkt_info->user_default_cos = cm_packet_header.source_cos;
                pkt_info->user_default_cfi = cm_packet_header.source_cfi;
            }
        }
    }
    else if (OPERATION_TYPE_OAM == cm_packet_header.operation_type) /* OAM */
    {
        pkt_info->rx_oam_type = cm_packet_header.ip_sa_u.share2.oam_type;
        pkt_info->user_vlan_ptr_valid = !pkt_info->oam_use_fid;
        pkt_info->user_vlan_ptr = cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr;
        pkt_info->tx_dm_en = cm_packet_header.ip_sa_u.share3.dm_en;

        pkt_info->time_stamp31_0 &= 0xFFFFFF00;
        pkt_info->time_stamp31_0 |= 0xFF & (((cm_packet_header.logic_src_port_u.dm_timestamp_17_2 & 0x3F) << 2) |
                                    ((cm_packet_header.rxtx_fcl3_u.dm_timestamp_1_1 & 0x1) << 1) |
                                    (cm_packet_header.rxtx_fcl0_u.dm_timestamp_0_0));
    }

    if (cm_packet_header.loopback_discard_u.loopback_discard
        || (cm_packet_header.from_fabric && (OPERATION_TYPE_OAM != cm_packet_header.operation_type)
        && !ipe_loopback_header_adjust_ctl.loopback_from_fabric_en))
    {
        pkt_info->discard_type = IPE_DISCARD_LOOPBACK_DISCARD;
        pkt_info->discard = TRUE;

        CMODEL_DEBUG_OUT_INFO("++++ Discard! lookback discard!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        pkt_info->bypass_all = TRUE;
    }

    /* CUSTOMER_ID */
    /* PacketHeader is carried in another bus, always stripped */
    packet_offset = cm_packet_header.packet_offset + (cm_packet_header.from_fabric ? GREAT_BELT_HEADER_LEN : 0);

    /* VC label,GRE key, UDP port,etc */
    customer_label = MAKE_UINT32((p_packet[0 + (packet_offset)]),
                                 (p_packet[1 + (packet_offset)]),
                                 (p_packet[2 + (packet_offset)]),
                                 (p_packet[3 + (packet_offset)]));

    if ((packet_offset + 4) >= pkt_info->packet_length)
    {
        pkt_info->discard = TRUE;
        pkt_info->discard_type = IPE_DISCARD_HDR_ADJ_BYTE_RMV_ERR_DISCARD;
        CMODEL_DEBUG_OUT_INFO("++++ Discard! lookback discard!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();

        bytes_to_remove = 0;
    }

    /* Indicate that customer ID is valid */
    if (cm_packet_header.next_hop_ext)
    {
        pkt_info->customer_id_valid = TRUE;
        pkt_info->customer_id = customer_label; /* Only Tcam lookup, not hash */

        customer_exp = (customer_label >> 9) & 0x7;

        if (IS_BIT_SET(next_hop_ptr, 15))
        {
            cmd = DRV_IOR(IpeHeaderAdjustExpMap_t, color_index + (customer_exp & 0x7));
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &color));

            cmd = DRV_IOR(IpeHeaderAdjustExpMap_t, priority_index + (customer_exp & 0x7));
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &priority));

            pkt_info->outer_priority = priority;
            pkt_info->outer_color = color;
        }

        bytes_to_remove = packet_offset + 4 + (((next_hop_ptr >> 8) & 0x3) << 2);
    }
    else
    {
        /* no customer label */
        pkt_info->customer_id = 0;
        pkt_info->customer_id_valid = FALSE;
        bytes_to_remove = packet_offset;
    }

    if (IS_BIT_SET(next_hop_ptr, 11))
    {
        /* overwrite packet type after strip label */
        pkt_info->packet_type = (next_hop_ptr >> 12) & 0x7;
    }

    /* PACKET_ADJUST */
    /* Calculate packet CRC without Packet Header, mark dataError, so BufferStore knowns error in EOP */
    if (bytes_to_remove >= pkt_info->packet_length)
    {
        pkt_info->discard = TRUE;
        pkt_info->discard_type = IPE_DISCARD_HDR_ADJ_BYTE_RMV_ERR_DISCARD;
        bytes_to_remove = 0;
        CMODEL_DEBUG_OUT_INFO("++++ Discard! Removed length is larger than packet length!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }
    else
    {
        /* No cut-through in loopback channel, packetLength is packetHeader.packetLength.
           PacketInfo.payloadOffset[7:0] great than 12 bytes */
        sal_memmove(pkt, pkt + bytes_to_remove, pkt_info->packet_length - bytes_to_remove);
        pkt_info->packet_length = pkt_info->packet_length - bytes_to_remove;
        p_in_pkt->packet_length   = pkt_info->packet_length;
        /* update packet CRC */
        if (pkt_info->packet_length > 4)
        {
            ctcutil_crc32(0xFFFFFFFF, pkt, (pkt_info->packet_length - 4), &new_pkt_crc);
            swap32(&new_pkt_crc, 1, HOST_TO_NETWORK);
            pkt[pkt_info->packet_length - 4] = (new_pkt_crc >> 24) & 0xFF;
            pkt[pkt_info->packet_length - 3] = (new_pkt_crc >> 16) & 0xFF;
            pkt[pkt_info->packet_length - 2] = (new_pkt_crc >> 8) & 0xFF;
            pkt[pkt_info->packet_length - 1] = new_pkt_crc & 0xFF;
        }
    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_sgmac_header_adjust_process
 * Purpose:    handle IPE sgmac header adjust.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_sgmac_header_adjust_process(ipe_in_pkt_t* p_in_pkt)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    uint8* p_packet = p_in_pkt->pkt;
    uint8 chip_id = p_in_pkt->chip_id;
    uint32 channel_id = p_in_pkt->chan_id & 0x3F;
    uint32 cmd = 0;

    ipe_sgmac_header_adjust_ctl_t ipe_sgmac_header_adjust_ctl;
    ipe_header_adjust_phy_port_map_t ipe_header_adjust_phy_port_map;

    cm_sgmac_plus_header_t cm_sgmac_plus_header;
    cm_sgmac2_header_t cm_sgmac2_header;

    sal_memset(&ipe_header_adjust_phy_port_map, 0, sizeof(ipe_header_adjust_phy_port_map));
    cmd = DRV_IOR(IpeHeaderAdjustPhyPortMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, channel_id, cmd, &ipe_header_adjust_phy_port_map));

    sal_memset(&ipe_sgmac_header_adjust_ctl, 0, sizeof(ipe_sgmac_header_adjust_ctl));
    cmd = DRV_IOR(IpeSgmacHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_sgmac_header_adjust_ctl));

    /* RECOVER_FIELDS */
    pkt_info->packet_length = p_in_pkt->packet_length;  /*packet_lenght from NetRx */

    /* SgmacHeader = IpeSgmacHeaderAdjustCtl.version? {Byte0..Byte11}:{Byte0..Byte15} */
    if (ipe_sgmac_header_adjust_ctl.version)
    {
        sal_memset(&cm_sgmac_plus_header, 0, sizeof(cm_sgmac_plus_header));
        sal_memcpy(&cm_sgmac_plus_header, p_packet, CM_SGMAC_PLUS_HEADER_LEN);
        DRV_IF_ERROR_RETURN(swap32((uint32*)(&cm_sgmac_plus_header), CM_SGMAC_PLUS_HEADER_LEN/4, NETWORK_TO_HOST));
    }
    else
    {
        sal_memset(&cm_sgmac2_header, 0, sizeof(cm_sgmac2_header));
        sal_memcpy(&cm_sgmac2_header, p_packet, CM_SGMAC2_HEADER_LEN);
        DRV_IF_ERROR_RETURN(swap32((uint32*)(&cm_sgmac2_header), CM_SGMAC2_HEADER_LEN/4, NETWORK_TO_HOST));
    }

    pkt_info->from_sgmac = TRUE;
    pkt_info->ingress_header_valid = TRUE;

    pkt_info->packet_type = PKT_TYPE_RESERVED;
    pkt_info->bypass_all = ipe_sgmac_header_adjust_ctl.sgmac_packet_header_bypass_all;

    if (ipe_sgmac_header_adjust_ctl.version)
    {
        sal_memcpy(pkt_info->ingress_header, p_in_pkt->pkt + CM_SGMAC_PLUS_HEADER_LEN, GREAT_BELT_HEADER_LEN);
        DRV_IF_ERROR_RETURN(swap32((uint32*)(pkt_info->ingress_header), GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));
    }
    else
    {
        sal_memcpy(pkt_info->ingress_header, p_in_pkt->pkt + CM_SGMAC2_HEADER_LEN, GREAT_BELT_HEADER_LEN);
        DRV_IF_ERROR_RETURN(swap32((uint32*)(pkt_info->ingress_header), GREAT_BELT_HEADER_LEN / 4, NETWORK_TO_HOST));
    }

    pkt_info->local_phy_port = ipe_header_adjust_phy_port_map.local_phy_port;

    /* PACKET_ADJUST */
    if (ipe_sgmac_header_adjust_ctl.version)
    {
        pkt_info->payload_offset = CM_SGMAC_PLUS_HEADER_LEN; /* Remove in EPE (12B) */
    }
    else
    {
         pkt_info->payload_offset = CM_SGMAC2_HEADER_LEN;    /* (16B) */
    }

     pkt_info->packet_length_adjust = pkt_info->payload_offset;

     return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_header_adjust_mux_header_adjust_process
 * Purpose:    handle IPE mux header adjust.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_header_adjust_mux_header_adjust_process(ipe_in_pkt_t* p_in_pkt)
{
    uint32 cmd = 0;
    uint32 mux_type = 0;
    uint32 mux_type_fieldid = 0;
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    ipe_mux_header_adjust_ctl_t muxhdr_adj_ctl;
    uint8 is_port_extender = FALSE;
    ipe_header_adjust_info_t ipe_header_adjust_info;

    /* MUX_TYPE */
    sal_memset(&muxhdr_adj_ctl, 0, sizeof(muxhdr_adj_ctl));
    sal_memset(&ipe_header_adjust_info, 0, sizeof(ipe_header_adjust_info_t));

    cmd = DRV_IOR(IpeMuxHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_in_pkt->chip_id, 0, cmd, &muxhdr_adj_ctl));

    if (p_in_pkt->chan_id < 32)
    {
        pkt_info->non_crc = !IS_BIT_SET(muxhdr_adj_ctl.channel_crc_valid31_0, p_in_pkt->chan_id);
    }
    else if (p_in_pkt->chan_id < MAX_CHANID)
    {
        pkt_info->non_crc = !IS_BIT_SET(muxhdr_adj_ctl.channel_crc_valid63_32, (p_in_pkt->chan_id - 32));
    }

    mux_type_fieldid = IpePhyPortMuxCtl_MuxType0_f + (p_in_pkt->chan_id & 0x3F);
    cmd = DRV_IOR(IpePhyPortMuxCtl_t, mux_type_fieldid);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_in_pkt->chip_id, 0, cmd, &mux_type));

    /* Port Extender and EVB may be enabled on the same channel, but functional independent */
    is_port_extender = ((MUX_HEADER_ADJUST_TYPE_CB_DOWNLINK == mux_type)
                       || (MUX_HEADER_ADJUST_TYPE_PE_UPLINK == mux_type)
                       || (MUX_HEADER_ADJUST_TYPE_PE_DOWNLINK_WITH_CASCADE == mux_type));

    if (MUX_HEADER_ADJUST_TYPE_OLD_VLAN_ENCODE_MULTIPLEXING == mux_type)    /* TYPE_MUX_DEMUX_SWITCH */
    {
        /* MUX_FORMAT_ADJUST */
        DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_mux_format_adjust(p_in_pkt));
    }
    else if (is_port_extender)    /* TYPE_PORT_EXTENDER_SWITCH */
    {
        /* PE_FORMAT_ADJUST */
        DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_pe_format_adjust(p_in_pkt));
    }
    else if (MUX_HEADER_ADJUST_TYPE_EVB == mux_type)    /* TYPE_EVB_SWITCH */
    {
        /* EVB_FORMAT_ADJUST */
        DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_evb_format_adjust(p_in_pkt));
    }
    else
    {
        ipe_header_adjust_info.mux_type = mux_type;
        /* PACKET_HEADER_DECISION */
        DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_packet_header_decision(p_in_pkt,&ipe_header_adjust_info));

        if  (ipe_header_adjust_info.packet_header_valid)
        {
            /* PACKET_HEADER_ADJUST */
            DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_packet_header_adjust(p_in_pkt));
        }
        else
        {
             /* REGULAR_PORT */
            DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_regular_port_adjust(p_in_pkt));
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_ipe_header_adjust_handle
 * Purpose:    handle IPE handle adjustment.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations informations.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 cm_ipe_header_adjust_handle(ipe_in_pkt_t* p_in_pkt)
{
    uint8 channel_id = p_in_pkt->chan_id;
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    ipe_header_adjust_mode_ctl_t ipe_header_adjust_mode_ctl;
    uint32 cmd = 0;

    /* INIT */
    /* packetLength should not include timestamp */
    pkt_info->packet_length = p_in_pkt->packet_length;  /*packet_lenght from NetRx */
    pkt_info->packet_type = PKT_TYPE_ETHERNETV2;
    pkt_info->payload_offset = 0;
    pkt_info->ingress_header_valid = FALSE;
    pkt_info->discard = FALSE;
    pkt_info->logic_src_port_valid = FALSE;
    pkt_info->logic_src_port = 0;

    sal_memset(&ipe_header_adjust_mode_ctl, 0, sizeof(ipe_header_adjust_mode_ctl));
    cmd = DRV_IOR(IpeHeaderAdjustModeCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_in_pkt->chip_id, 0, cmd, &ipe_header_adjust_mode_ctl));

    if (I_LOOPBACK_CHANID == channel_id)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Loopback Header Adjust Process");
        DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_loopback_header_adjust_process(p_in_pkt));
    }
    else
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s----------------------------->>\n", "Start");

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Header Adjust Process");
        if (ipe_header_adjust_mode_ctl.mode
           && ((SGMAC_MIN_CHANID <= channel_id) && (SGMAC_MAX_CHANID >= channel_id)))
        {
            /* do sgmac header adjust */
            DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_sgmac_header_adjust_process(p_in_pkt));
        }
        else
        {
            if (IS_BIT_SET(channel_id, 7)) /* interLaken channel */
            {
                DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_inter_laken_adjust_process(p_in_pkt));
            }
            else
            {
                 DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_mux_header_adjust_process(p_in_pkt));
            }

            /* PACKET_TYPE */
            DRV_IF_ERROR_RETURN(_cm_ipe_header_adjust_packet_type(p_in_pkt));
        }
    }

    return DRV_E_NONE;
}

