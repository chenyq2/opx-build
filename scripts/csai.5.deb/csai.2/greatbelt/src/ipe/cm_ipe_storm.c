/****************************************************************************
 * cm_ipe_storm.c: Provides IPE bridging ds_storm_ctl control function.
 *
 * Copyright (C) 2010 Centec Networks Inc. All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       JiangJf
 * Date:         2010-10-30.
 * Reason:       First Create. JiangJf TODO: need rewrite when spec ready
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "cm_lib.h"
#include "drv_lib.h"

#if ZHOUW_NOTE

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
#if !defined(SDK_IN_KERNEL)
static uint16 chip_port_num[MAX_LOCAL_CHIP_NUM];
static ctckal_timer_t chip_storm_timer[MAX_LOCAL_CHIP_NUM];
#endif
extern uint8 chip_user_para[MAX_LOCAL_CHIP_NUM];


/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
 /****************************************************************************
 * Name:       ipe_policing_timer_handler0
 * Purpose:    IPE policing timer0 major handle process.
 * Parameters:
 * Input:      timer -- timer index.
 *             para -- pointer to chip id.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *	       Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
#if !defined(SDK_IN_KERNEL)
static void
cm_ipe_storm_timer_handler(ctckal_timer_t timer, void *para)
{
    uint8  chip_id = *((uint8 *)para);
    uint32 cmd = 0;
    uint16 port_no = chip_port_num[chip_id];
    ipe_bridge_storm_ctl_t storm_ctl;
    ds_storm_ctl_t ds_storm_ctl;

    return;
    /* timer index check */
    if(timer != chip_storm_timer[chip_id])
    {
        return;
    }

    /* read ds ds_storm_ctl control */
    cmd = DRV_IOR(IOC_TABLE, DS_STORM_CTL, DRV_ENTRY_FLAG);
    if(DRV_E_NONE != DRV_TBL_IOCTL(chip_id, port_no, cmd, &ds_storm_ctl))
    {
        return;
    }

    /* read bridge ds_storm_ctl control register */
    cmd = DRV_IOR(IOC_REG, IPE_BRIDGE_STORM_CTL, DRV_ENTRY_FLAG);
    if(DRV_E_NONE != DRV_REG_IOCTL(chip_id, 0, cmd, &storm_ctl))
    {
        return;
    }

	if (port_no < storm_ctl.max_update_port_num)
	{
	    ds_storm_ctl.running_count = 0;
	    cmd = DRV_IOW(IOC_TABLE, DS_STORM_CTL, DRV_ENTRY_FLAG);
	    if(DRV_E_NONE != DRV_TBL_IOCTL(chip_id, port_no, cmd, &ds_storm_ctl))
	    {
	        return;
	    }
	}
    if(port_no == storm_ctl.max_port_num)
    {
        port_no = 0;
    }
    else
    {
        port_no++;
    }
    chip_port_num[chip_id] = port_no;

    /* reset timers elapsed */
    if(ctckal_timer_set_elapsed(timer, storm_ctl.update_threshold))
    {
        return ;
    }

    return;
}
#endif
#endif
/****************************************************************************
 * Name:       ipe_intialize_storm
 * Purpose:    intialize IPE ds_storm_ctl process.
 * Parameters:
 * Input:      none
 * Output:     none
 * Return:     DRV_E_NONE = success.
 *	       Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32
cm_ipe_storm_intialize(void)
{
#if 0
/* zhouw note */
#if !defined(SDK_IN_KERNEL)
    uint8 chip_id;
    uint8 chipnum = 0;

    DRV_IF_ERROR_RETURN(drv_get_chipnum(&chipnum));
    for(chip_id = 0; chip_id < chipnum; chip_id++)
    {
        chip_user_para[chip_id] = chip_id;
        chip_port_num[chip_id]  = 0;

        /* per-chip create timer */
        if (DRV_E_NONE != ctckal_timer_create(&chip_storm_timer[chip_id], FALSE,
                             1000, /* interval = 1 second */
                             cm_ipe_storm_timer_handler,
                             (void *)(&chip_user_para[chip_id])))
        {
            return DRV_E_CREATE_TIMER;
        }
    }
#else
#endif
#endif
    return DRV_E_NONE;
}



/****************************************************************************
 * Name:       ipe_release_storm
 * Purpose:    release IPE ds_storm_ctl process.
 * Parameters:
 * Input:      none
 * Output:     none
 * Return:     DRV_E_NONE = success.
 *	       Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32
cm_ipe_storm_release(void)
{
#if 0
/* zhouw note */
#if !defined(SDK_IN_KERNEL)
    uint8 chip_id;
    uint8 chipnum = 0;

    DRV_IF_ERROR_RETURN(drv_get_chipnum(&chipnum));
    for (chip_id = 0; chip_id < chipnum; chip_id++)
    {
        ctckal_timer_destroy(chip_storm_timer[chip_id]);
    }
#else
#endif
#endif
    return DRV_E_NONE;
}


