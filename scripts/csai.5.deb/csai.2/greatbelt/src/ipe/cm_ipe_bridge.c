/****************************************************************************
 * cm_ipe_bridge.c: Provides IPE bridging handle function.
 * Copyright (C) 2011 Centec Networks Inc.  All rights reserved.
 *
 * Version:       V1.0
 * Author:        JiangJf
 * Date:          2010-10-09.
 * Reason:        First Create.
 *
 * Modify History:
 * Reversion      V1.01
 * Revisor        XuZx
 * Date           2010-11-15
 *
 * Modify History:
 * Reversion      V4.2
 * Revisor        Jiangsz
 * Date           2011-07-05
 *
 * Modify History:
 * Reversion      V4.29
 * Revisor        JiaK
 * Date           2011-10-08
 *
 * Reversion:     V5.1.0
 * Author:        Wangcy
 * Date:          2011-12-12.
 * Reason:        sync spec v5.1.0.
 *
 * Reversion:     V5.6.0
 * Author:        Wangcy
 * Date:          2012-01-07.
 * Reason:        sync spec v5.6.0.
 *
 * Reversion:     V5.7.0
 * Author:        Wangcy
 * Date:          2012-01-17.
 * Reason:        sync spec v5.7.0.
 *
 * Reversion:    V5.11.0
 * Author:       ZhouW
 * Date:         2012-03-01.
 * Reason:       sync spec v5.11.0.
 *
 * Reversion:    V5.13.0
 * Author:       Wangcy
 * Date:         2012-03-12.
 * Reason:       sync spec v5.13.0.
 *
 * Reversion:    V5.15.0.1
 * Author:       Wangcy
 * Date:         2012-03-23.
 * Reason:       sync spec v5.15.0.1
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "ctcutil_lib.h"
#include "cm_lib.h"
#include "drv_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/


/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/
/****************************************************************************
 * Name:      _cm_ipe_bridge_exception
 * Purpose:   IPE bridging exception.
 * Parameters:
 * Input:     chip_id  -- chip id
 *            pkt_info -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Output:    in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:    DRV_E_NONE -- success.
 *            Other -- ErrorCode, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_ipe_bridge_exception(uint8 chip_id, ipe_packet_info_t *pkt_info,ds_mac_t *p_mac_da)
{
    parsing_result_t *parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    uint8 layer3_type = parser_result->layer3_type;
    ipe_bridge_ctl_t ipe_bridge_ctl;

    uint32 cmd = 0;
    uint32 field_id = 0;
    uint32 field_value = 0;

    sal_memset(&ipe_bridge_ctl, 0, sizeof(ipe_bridge_ctl));
    cmd = DRV_IOR(IpeBridgeCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_bridge_ctl));

    if (p_mac_da->protocol_exception_en && !pkt_info->exception_en)
    {
        if (IS_BIT_SET(ipe_bridge_ctl.protocol_exception, parser_result->layer3_type))
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;

            field_id = IpeBridgeCtl_ProtocolExceptionSubIndex0_f + layer3_type;
            cmd = DRV_IOR(IpeBridgeCtl_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &field_value));
            pkt_info->exception_sub_index = field_value;
        }

        if (pkt_info->layer3_exception)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = pkt_info->layer3_exception_sub_index;
        }
    }
    else if (p_mac_da->mac_da_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = (0xF << 2) | p_mac_da->exception_sub_index;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_ipe_bridge_handle
 * Purpose:    IPE bridging handle.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE -- success.
 *             Other -- ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 cm_ipe_bridge_handle(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;

    ds_storm_ctl_t ds_port_storm_ctl;
    ds_storm_ctl_t ds_vlan_storm_ctl;
    ipe_bridge_ctl_t ipe_bridge_ctl;
    ipe_bridge_storm_ctl_t ipe_bridge_storm_ctl;
    ipe_ecmp_ctl_t ipe_ecmp_ctl;
    ds_ecmp_state_t ds_ecmp_state;
    ds_ecmp_group_t ds_ecmp_group;
    ds_mac_t *p_mac_da = NULL;
    ds_mac_t *hash_ds_mac = NULL;
    ds_mac_t *tcam_ds_mac = NULL;
    ds_mac_t *ip_ds_mac0 = NULL;
    ds_mac_t *ip_ds_mac1 = NULL;
    ds_mac_t *ip_ds_mac = NULL;

    uint8 mac_da_result_valid = FALSE;
    uint8 hash_mac_da_result_valid = FALSE;
    uint8 tcam_mac_da_result_valid = FALSE;
    uint8 default_entry_valid = FALSE;
    uint8 ip_mac_da_result_valid0 = FALSE;
    uint8 ip_mac_da_result_valid1 = FALSE;
    uint8 ip_mac_da_result_valid = FALSE;

    uint8 port_match = FALSE;
    uint8 port_match_discard = FALSE;
    uint8 chip_id = in_pkt->chip_id;
    uint8 bridge_packet = FALSE, stp_discard = FALSE;
    uint8 mcast_discard = FALSE, ucast_discard = FALSE;
    uint8 igmp_snooped_packet = FALSE, bridge_escape = FALSE;
    uint32 cmd = 0;
    uint8 mac_hash = 0;
    uint32 port_storm_ctl_len = 0;
    uint32 vlan_storm_ctl_len = 0;
    uint8 equal_cost_path_num = 0, equal_cost_path_sel = 0;
    uint8 use_ip_hash = FALSE;
    uint8 mcast_key = 0;
    uint16 ds_port_storm_ctl_ptr = 0;
    uint16 ds_vlan_storm_ctl_ptr = 0;
    uint8 port_storm_ctl_en = FALSE;
    uint8 vlan_storm_ctl_en = FALSE;
    uint8 mux_len = 0;
    uint8 port_shift = 0;
    uint8 vlan_shift = 0;
    uint16 ds_ecmp_ptr = 0;
    uint8 current_ts = 0;
    uint8 dest_channel[16] = {0};
    uint32 channel_class[16] = {0};
    uint8 index = 0;
    uint8 max_channel_class = 0;
    uint8 max_channel_class_count = 0;
    uint8 max_channel_class_index_array[16] = {0};
    uint32 random = 0;
    uint32 ds_fwd_ptr = 0;
    uint8 link_oam = FALSE;
    uint8 tunnel_payload_offset = 0;

    sal_memset(&ipe_bridge_ctl, 0, sizeof(ipe_bridge_ctl));
    cmd = DRV_IOR(IpeBridgeCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_bridge_ctl));

    sal_memset(&ipe_ecmp_ctl, 0, sizeof(ipe_ecmp_ctl));
    cmd = DRV_IOR(IpeEcmpCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_ecmp_ctl));

    if (pkt_info->mac_da_lookup_en)
    {
        if (pkt_info->mac_ip_lookup_en)
        {
            ip_mac_da_result_valid1 = pkt_info->ip_mac_da_tcam_result_valid;
            ip_ds_mac1 = (ds_mac_t *)pkt_info->ip_tcam_mac_da_data;             /* POPTcamDs */
            ip_mac_da_result_valid0 = pkt_info->ip_mac_da_hash_result_valid;
            ip_ds_mac0 = (ds_mac_t *)pkt_info->ip_hash_mac_da_data;             /* POPFibDs */

            if ((ipe_bridge_ctl.mac_ip_tcam_first && ip_mac_da_result_valid1) || !ip_mac_da_result_valid0)
            {
                ip_mac_da_result_valid = ip_mac_da_result_valid1;
                ip_ds_mac = ip_ds_mac1;
            }
            else
            {
                ip_mac_da_result_valid = ip_mac_da_result_valid0;
                ip_ds_mac = ip_ds_mac0;
            }
        }

        if (pkt_info->mac_hash_lookup_en)
        {
            hash_mac_da_result_valid = pkt_info->mac_da_hash_result_valid;
            default_entry_valid = pkt_info->mac_da_default_entry_valid;
            hash_ds_mac = (ds_mac_t *)pkt_info->hash_mac_da_data;        /* POPFibDs */
        }

        if (pkt_info->mac_tcam_lookup_en)
        {
            tcam_mac_da_result_valid = pkt_info->mac_da_tcam_result_valid;
            tcam_ds_mac = (ds_mac_t *)pkt_info->tcam_mac_da_data;        /* POPTcamDs */
        }

        /* First IP MAC lookup */
        if (ip_mac_da_result_valid)
        {
            mac_da_result_valid = ip_mac_da_result_valid;
            p_mac_da = ip_ds_mac;
        }
        /* Second Hash */
        else if (hash_mac_da_result_valid && !default_entry_valid)
        {
            mac_da_result_valid = hash_mac_da_result_valid;
            p_mac_da = hash_ds_mac;
        }
        /* Third TCAM */
        else if (tcam_mac_da_result_valid)
        {
            mac_da_result_valid = tcam_mac_da_result_valid;
            p_mac_da = tcam_ds_mac;
        }
        /* Fourth Default */
        else if (hash_mac_da_result_valid)
        {
            mac_da_result_valid = hash_mac_da_result_valid;
            p_mac_da = hash_ds_mac;
        }
    }

    bridge_packet = (!pkt_info->discard) && (!pkt_info->deny_bridge)
                    && pkt_info->bridge_packet && mac_da_result_valid;

    pkt_info->mac_known = TRUE;

    if (!bridge_packet)
    {
        return DRV_E_NONE;
    }

    /* ESCAPE_CHECKING */
    igmp_snooped_packet = pkt_info->igmp_snoop_en && pkt_info->igmp_packet;

    pkt_info->mac_known = p_mac_da->mac_known;
    pkt_info->bridge_aps_select_en = p_mac_da->bridge_aps_select_en;
    pkt_info->is_conversation = p_mac_da->is_conversation;
    pkt_info->self_address = pkt_info->self_address || p_mac_da->self_address;

    if (!p_mac_da->learn_source)
    {
        port_match = (pkt_info->global_src_port == p_mac_da->global_src_port);
    }
    else
    {
        port_match = (pkt_info->logic_src_port == p_mac_da->global_src_port); /* logicSrcPort[13:0] */
    }

    port_match_discard = p_mac_da->source_port_check_en && port_match && pkt_info->port_check_en;

    if (p_mac_da->next_hop_ptr_valid)
    {
        stp_discard = (STP_BLOCKING == pkt_info->stp_state) || (STP_LEARNING == pkt_info->stp_state);
    }
    else
    {
        stp_discard = (!p_mac_da->stp_check_disable)
                            && ((STP_BLOCKING == pkt_info->stp_state) || (STP_LEARNING == pkt_info->stp_state));
    }
    /*=========bug 4773 ECO begin=============*/
    /*mcast_discard = (pkt_info->mcast_mac_address
                    && (!igmp_snooped_packet)
                    && (!pkt_info->force_bridge || ipe_bridge_ctl.discard_force_bridge)
                    && ((!p_mac_da->next_hop_ptr_valid && p_mac_da->mcast_discard) || pkt_info->mcast_discard));*/

    mcast_discard = (pkt_info->mcast_mac_address
                    && (!igmp_snooped_packet)&&(!p_mac_da->mac_known)
                    && (!pkt_info->force_bridge || ipe_bridge_ctl.discard_force_bridge)
                    && ((!p_mac_da->next_hop_ptr_valid && p_mac_da->mcast_discard) || pkt_info->mcast_discard));
    /*=========bug 4773 ECO end=============*/
    /*=========bug 4773 ECO begin=============*/
    /*ucast_discard = ((!pkt_info->mcast_mac_address)
                    && (!pkt_info->bcast_mac_address)
                    && ((!p_mac_da->next_hop_ptr_valid && p_mac_da->ucast_discard) || pkt_info->ucast_discard));*/

    ucast_discard = ((!pkt_info->mcast_mac_address)
                    && (!pkt_info->bcast_mac_address)&&(!p_mac_da->mac_known)
                    && ((!p_mac_da->next_hop_ptr_valid && p_mac_da->ucast_discard) || pkt_info->ucast_discard));
    /*=========bug 4773 ECO end=============*/
    link_oam = pkt_info->link_or_section_OAM && (L3_TYPE_ETHEROAM == parser_result->layer3_type);

    if (stp_discard && !pkt_info->from_cpu_or_oam)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_STP_DISCARD;

            if ((OAM_ETHER != pkt_info->rx_oam_type) && (!link_oam))
            {
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Bridge Stp check discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            else
            {
                pkt_info->ether_oam_discard = TRUE;
            }
        }
    }
    /* unkonown U/M discard except OAM */
    else if (port_match_discard
        || ((mcast_discard || ucast_discard) && ((OAM_ETHER != pkt_info->rx_oam_type)&& !link_oam)))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_BRG_BPDU_ETC_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! Unkonown U/M discard except OAM!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    bridge_escape = pkt_info->discard || igmp_snooped_packet;

    if (!bridge_escape)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Bridge Process");

        /* DESTINATION */
        use_ip_hash = ((L3_TYPE_IPV4 == parser_result->layer3_type) ||(L3_TYPE_IPV6 == parser_result->layer3_type))
                       && ipe_bridge_ctl.use_ip_hash;

        switch (pkt_info->pbb_src_port_type)
        {
            case PBB_PORT_TYPE_PNP:
                if (ipe_bridge_ctl.pnp_use_cmac_hash)
                {
                    mac_hash = pkt_info->cmac_ecmp_hash;
                    pkt_info->header_hash = pkt_info->cmac_header_hash;
                }
                else
                {
                    mac_hash = pkt_info->mac_ecmp_hash;
                }
                break;

            case PBB_PORT_TYPE_CBP:
                if (ipe_bridge_ctl.cbp_use_cmac_hash)
                {
                    mac_hash = pkt_info->cmac_ecmp_hash;
                    pkt_info->header_hash = pkt_info->cmac_header_hash;
                }
                else
                {
                    mac_hash = pkt_info->mac_ecmp_hash;
                }
                break;

            case PBB_PORT_TYPE_PIP:
                if (ipe_bridge_ctl.pbb_mode)
                {
                    mac_hash = pkt_info->cmac_ecmp_hash;
                    pkt_info->header_hash = pkt_info->cmac_header_hash;
                }
                else
                {
                    mac_hash = parser_result->l2_s.mac_ecmp_hash;
                }
                break;

            default:
                mac_hash = (use_ip_hash) ? parser_result->l3_s.ip_ecmp_hash : parser_result->l2_s.mac_ecmp_hash;
                break;
        }

        pkt_info->ds_fwd_ptr_valid = TRUE;

        if (p_mac_da->next_hop_ptr_valid)
        {
            pkt_info->ds_fwd_ptr_valid = FALSE;
            pkt_info->next_hop_ptr_valid = TRUE;
            pkt_info->ad_next_hop_ptr = p_mac_da->ds_fwd_ptr;                       /* used as adNextHopPtr */
            pkt_info->ad_dest_map = (p_mac_da->esp_id10_9 << 20)                    /* used as adDestMap[21:20] */
                                    | (p_mac_da->tunnel_packet_type << 17)          /* used as adDestMap[19:17] */
                                    | (p_mac_da->conversation_check_en << 16)       /* used as adDestMap[16:16] */
                                    | (p_mac_da->is_conversation << 15)             /* used as adDestMap[15:15] */
                                    | (p_mac_da->mcast_discard << 14)       /* used as adDestMap[14:14] */
                                    | (p_mac_da->equal_cost_path_num3_3 << 12)         /* used as adDestMap[12:12] */
                                    | ((p_mac_da->equal_cost_path_num2_0 >>2) << 11)         /* used as adDestMap[11:11] */
                                    | (p_mac_da->ucast_discard << 10)               /* used as adDestMap[10:10] */
                                    | (p_mac_da->aps_select_protecting_path << 9)   /* used as adDestMap[9:9] */
                                    | (p_mac_da->esp_id8_0);                        /* used as adDestMap[8:0] */
            pkt_info->ad_length_adjust_type = p_mac_da->payload_select;             /* used as adLengthAdjustType */
            pkt_info->ad_critical_packet = p_mac_da->stp_check_disable;             /* used as adCriticalPacket */
            pkt_info->ad_next_hop_ext = p_mac_da->bridge_aps_select_en;             /* used as adNextHopExt */
            pkt_info->ad_send_local_phy_port = p_mac_da->src_discard;               /* used as adSendLocalPhyPort */
            pkt_info->ad_aps_type = (p_mac_da->ad_aps_type1 << 1) | p_mac_da->priority_path_en; /* used as adApsType0 */
            pkt_info->ad_speed = p_mac_da->exception_sub_index;                     /* used as adSpeed */

        }
        else if (p_mac_da->priority_path_en)
        {
            pkt_info->ds_fwd_ptr = p_mac_da->ds_fwd_ptr + pkt_info->priority_path_select;
        }
        else if (p_mac_da->dlb_en)
        {
            /* about policer process,cmodel need not realize */
            equal_cost_path_num = (p_mac_da->equal_cost_path_num2_0 ) | (p_mac_da->equal_cost_path_num3_3 << 3);

            switch (ipe_ecmp_ctl.ecmp_flow_num)
            {
                case 0:
                    ds_ecmp_ptr = ((equal_cost_path_num & 0xF) << 8) + mac_hash;
                    break;

                case 1:
                    ds_ecmp_ptr = ((equal_cost_path_num & 0xF) << 7) + mac_hash;
                    break;

                case 2:
                    ds_ecmp_ptr = ((equal_cost_path_num & 0xF) << 6) + mac_hash;
                    break;

                case 3:
                    ds_ecmp_ptr = ((equal_cost_path_num & 0xF) << 5) + mac_hash;
                    break;

                default:
                    break;
            }

            sal_memset(&ds_ecmp_state, 0, sizeof(ds_ecmp_state));
            cmd = DRV_IOR(DsEcmpState_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_ecmp_ptr & 0x3FF, cmd, &ds_ecmp_state));

            sal_memset(&ds_ecmp_group, 0, sizeof(ds_ecmp_group));   /* ECMP bundle to same ports */
            cmd = DRV_IOR(DsEcmpGroup_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, equal_cost_path_num & 0xF, cmd, &ds_ecmp_group));

            if (ds_ecmp_state.active
                && (((current_ts & 0xFF) - ds_ecmp_state.old_ts) < ipe_ecmp_ctl.ts_threshold))  /* flow active */
            {
                pkt_info->ds_fwd_ptr = ds_ecmp_state.ds_fwd_ptr;
                ds_ecmp_state.old_ts = current_ts & 0xFF;
            }
            else    /* flow inactive */
            {
                dest_channel[0] = ds_ecmp_group.dest_channel0;
                dest_channel[1] = ds_ecmp_group.dest_channel1;
                dest_channel[2] = ds_ecmp_group.dest_channel2;
                dest_channel[3] = ds_ecmp_group.dest_channel3;
                dest_channel[4] = ds_ecmp_group.dest_channel4;
                dest_channel[5] = ds_ecmp_group.dest_channel5;
                dest_channel[6] = ds_ecmp_group.dest_channel6;
                dest_channel[7] = ds_ecmp_group.dest_channel7;

                for (index = 0; index < 8; index ++)    /* update by QMgr */
                {
                    cmd = DRV_IOR(IpeEcmpChannelState_t, (IpeEcmpChannelState_ChannelClass0_f + (dest_channel[index] & 0x3F)));
                    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &(channel_class[index])));
                }

                max_channel_class = channel_class[0];       /* store current max_channel_class */
                max_channel_class_index_array[0] = 0;       /* store index of all max_channel_class item */
                max_channel_class_count = 1;                /* max_channel_class item count */

                for (index = 1; index < ds_ecmp_group.ecmp_mem_num; index++)
                {
                    if(channel_class[index] == max_channel_class)
                    {
                        max_channel_class_index_array[max_channel_class_count] = index;
                        max_channel_class_count++;
                    }
                    else if(channel_class[index] > max_channel_class)
                    {
                        max_channel_class_index_array[0] = index;
                        max_channel_class_count = 1;
                    }
                }

                if (1 == max_channel_class_count)
                {
                    index = max_channel_class_index_array[0];
                }
                else
                {
                    ctcutil_rand(0, max_channel_class_count - 1, &random);
                    index = max_channel_class_index_array[random];
                }

                cmd = DRV_IOR(DsEcmpGroup_t, (DsEcmpGroup_DsFwdPtr0_f + (index & 0xF)));
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ds_fwd_ptr));

                ds_ecmp_state.ds_fwd_ptr = ds_fwd_ptr;
                pkt_info->ds_fwd_ptr = ds_fwd_ptr;
                ds_ecmp_state.old_ts = current_ts;
                ds_ecmp_state.active = TRUE;

                cmd = DRV_IOW(DsEcmpState_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_ecmp_ptr & 0x3FF, cmd, &ds_ecmp_state));

            }
        }
        else
        {
            equal_cost_path_num = (p_mac_da->equal_cost_path_num3_3 << 3) | p_mac_da->equal_cost_path_num2_0;

            switch (equal_cost_path_num)
            {
                case 0:
                    equal_cost_path_sel = 0;
                    break;
                case 1:
                    equal_cost_path_sel = IS_BIT_SET(mac_hash, 0);
                    break;
                case 2:
                    equal_cost_path_sel = mac_hash % 3;
                    break;
                case 3:
                    equal_cost_path_sel = mac_hash & 0x3;
                    break;
                case 4:
                    equal_cost_path_sel = mac_hash % 5;
                    break;
                case 5:
                    equal_cost_path_sel = mac_hash % 6;
                    break;
                case 6:
                    equal_cost_path_sel = mac_hash % 7;
                    break;
                case 7:
                    equal_cost_path_sel = mac_hash & 0x7;
                    break;
                default:
                    equal_cost_path_sel = mac_hash & 0xF;
                    break;
            }

            pkt_info->ds_fwd_ptr =  p_mac_da->ds_fwd_ptr + equal_cost_path_sel;
        }

        pkt_info->payload_packet_type = PKT_TYPE_ETHERNETV2; /* ETHERNET */
        pkt_info->payload_offset = parser_result->layer2_offset;

        if ((PBB_PORT_TYPE_PIP == pkt_info->pbb_src_port_type) && ipe_bridge_ctl.pbb_mode)
        {
            pkt_info->payload_offset = parser_result->l2_s.layer3_offset + 4;   /* layer3Offset + 4 byte isid */
        }
        /* ======== bug 4667 ECO begine ========= */
        //else if (p_mac_da->payload_select)
        else if (!p_mac_da->next_hop_ptr_valid && p_mac_da->payload_select)
        /* ======== bug 4667 ECO end ========= */
        {
            tunnel_payload_offset = ((p_mac_da->equal_cost_path_num3_3&0x1) << 3)
                                    | p_mac_da->equal_cost_path_num2_0;
            pkt_info->payload_packet_type = p_mac_da->tunnel_packet_type;
            pkt_info->payload_offset = parser_result->l2_s.layer3_offset
                                       + (tunnel_payload_offset << ipe_bridge_ctl.bridge_offset_byte_shift);
        }


        /* EXCEPTION */
        DRV_IF_ERROR_RETURN(_cm_ipe_bridge_exception(chip_id, pkt_info,p_mac_da));

        /* STORM_CTL */
        if (p_mac_da->storm_ctl_en)
        {
            mcast_key = (pkt_info->mcast_mac_address << 1) | pkt_info->bcast_mac_address;
            switch (mcast_key & 0x3)
            {
                case 2: /* multicast */
                    if (!ipe_bridge_ctl.multicast_storm_control_mode)  /* All multicast */
                    {
                        ds_port_storm_ctl_ptr = (2 << 6) + pkt_info->port_storm_ctl_ptr;
                        ds_vlan_storm_ctl_ptr = (2 << 6) + pkt_info->vlan_storm_ctl_ptr;
                    }
                    else if (p_mac_da->mac_known)                      /* Known multicast */
                    {
                        ds_port_storm_ctl_ptr = (1 << 6) + pkt_info->port_storm_ctl_ptr;
                        ds_vlan_storm_ctl_ptr = (1 << 6) + pkt_info->vlan_storm_ctl_ptr;
                    }
                    else                                               /* Unknown multicast */
                    {
                        ds_port_storm_ctl_ptr = (2 << 6) + pkt_info->port_storm_ctl_ptr;
                        ds_vlan_storm_ctl_ptr = (2 << 6) + pkt_info->vlan_storm_ctl_ptr;
                    }
                    break;

                case 1: /* broadcast */
                    ds_port_storm_ctl_ptr = pkt_info->port_storm_ctl_ptr;
                    ds_vlan_storm_ctl_ptr = pkt_info->vlan_storm_ctl_ptr;
                    break;

                default: /* unicast */
                    if (!ipe_bridge_ctl.unicast_storm_control_mode)    /* All unicast */
                    {
                        ds_port_storm_ctl_ptr = (4 << 6) + pkt_info->port_storm_ctl_ptr;
                        ds_vlan_storm_ctl_ptr = (4 << 6) + pkt_info->vlan_storm_ctl_ptr;
                    }
                    else if (p_mac_da->mac_known)                      /* Known unicast */
                    {
                        ds_port_storm_ctl_ptr = (3 << 6) + pkt_info->port_storm_ctl_ptr;
                        ds_vlan_storm_ctl_ptr = (3 << 6) + pkt_info->vlan_storm_ctl_ptr;
                    }
                    else                                               /* Unknown unicast */
                    {
                        ds_port_storm_ctl_ptr = (4 << 6) + pkt_info->port_storm_ctl_ptr;
                        ds_vlan_storm_ctl_ptr = (4 << 6) + pkt_info->vlan_storm_ctl_ptr;
                    }
                    break;
            }

            sal_memset(&ds_port_storm_ctl, 0, sizeof(ds_port_storm_ctl));
            cmd = DRV_IOR(DsStormCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_port_storm_ctl_ptr & 0x1FF, cmd, &ds_port_storm_ctl));

            sal_memset(&ds_vlan_storm_ctl, 0, sizeof(ds_vlan_storm_ctl));
            cmd = DRV_IOR(DsStormCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_vlan_storm_ctl_ptr & 0x1FF, cmd, &ds_vlan_storm_ctl));

            sal_memset(&ipe_bridge_storm_ctl, 0, sizeof(ipe_bridge_storm_ctl));
            cmd = DRV_IOR(IpeBridgeStormCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_bridge_storm_ctl));

            port_storm_ctl_en = pkt_info->port_storm_ctl_en
                                && ((L3_TYPE_ETHEROAM != parser_result->layer3_type)
                                   || ipe_bridge_storm_ctl.oam_obey_storm_ctl);

            vlan_storm_ctl_en = pkt_info->vlan_storm_ctl_en
                                && ((L3_TYPE_ETHEROAM != parser_result->layer3_type)
                                   || ipe_bridge_storm_ctl.oam_obey_storm_ctl);

            if (MUX_LENGTH_TYPE1 == pkt_info->mux_length_type)
            {
                mux_len = 4;
            }
            else if (MUX_LENGTH_TYPE2 == pkt_info->mux_length_type)
            {
                mux_len = 8;
            }
            else
            {
                mux_len = 0;
            }

            /* Only network channel support stormctl,interLaken/loopback not support */
            /* PacketInfo.packetLength[13:0] is Eop or Sop/Eop real packetLength */
            /* portStormCtlLen[31:0] is zero for Sop,real length for Sop/eop */
            port_storm_ctl_len = ds_port_storm_ctl.running_count + pkt_info->packet_length
                                 - pkt_info->packet_length_adjust - mux_len;

            vlan_storm_ctl_len = ds_vlan_storm_ctl.running_count + pkt_info->packet_length
                                 - pkt_info->packet_length_adjust - mux_len;

            if (ipe_bridge_storm_ctl.ipg_en)
            {
                port_storm_ctl_len += pkt_info->ipg;
                vlan_storm_ctl_len += pkt_info->ipg;
            }

            /* port based storm ctl */
            if (port_storm_ctl_en
                && ((in_pkt->chan_id >= 32) ? IS_BIT_SET(ipe_bridge_storm_ctl.storm_ctl_en63_32,(in_pkt->chan_id-32))
                                                              : IS_BIT_SET(ipe_bridge_storm_ctl.storm_ctl_en31_0,(in_pkt->chan_id)))
                && (ds_port_storm_ctl.threshold != 0xFFFFFF))
            {
                port_shift = ds_port_storm_ctl.use_packet_count?
                             ipe_bridge_storm_ctl.packet_shift : ipe_bridge_storm_ctl.byte_shift;

                if (ds_port_storm_ctl.running_count >= (ds_port_storm_ctl.threshold << port_shift))
                {
                    pkt_info->storm_ctl_drop = TRUE;
                    pkt_info->storm_ctl_exception_en = ds_port_storm_ctl.exception_en;
                }
                else
                {
                    if (ds_port_storm_ctl.use_packet_count)
                    {
                        ds_port_storm_ctl.running_count++;
                    }
                    else
                    {
                       ds_port_storm_ctl.running_count = port_storm_ctl_len;
                    }

                    cmd = DRV_IOW(DsStormCtl_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_port_storm_ctl_ptr & 0x1FF, cmd, &ds_port_storm_ctl));
                }
            }

            /* vlan based strom ctl */
            if (vlan_storm_ctl_en
                && ((in_pkt->chan_id >= 32) ? IS_BIT_SET(ipe_bridge_storm_ctl.storm_ctl_en63_32,(in_pkt->chan_id-32))
                                                              : IS_BIT_SET(ipe_bridge_storm_ctl.storm_ctl_en31_0,(in_pkt->chan_id)))
                && (ds_vlan_storm_ctl.threshold != 0xFFFFFF))
            {
                vlan_shift = ds_vlan_storm_ctl.use_packet_count ?
                             ipe_bridge_storm_ctl.packet_shift : ipe_bridge_storm_ctl.byte_shift;

                if (ds_vlan_storm_ctl.running_count >= (ds_vlan_storm_ctl.threshold << vlan_shift))
                {
                    pkt_info->storm_ctl_drop = TRUE;
                    pkt_info->storm_ctl_exception_en = pkt_info->storm_ctl_exception_en || ds_vlan_storm_ctl.exception_en;
                }
                else
                {
                    if (ds_vlan_storm_ctl.use_packet_count)
                    {
                        ds_vlan_storm_ctl.running_count++;
                    }
                    else
                    {
                        ds_vlan_storm_ctl.running_count = vlan_storm_ctl_len;
                    }

                    cmd = DRV_IOW(DsStormCtl_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_vlan_storm_ctl_ptr & 0x1FF, cmd, &ds_vlan_storm_ctl));
                }
            }
        }
    }
    else
    {
        /* BRIDGE_ESCAPE */
        if (igmp_snooped_packet && (!pkt_info->discard))
        {
            pkt_info->fatal_exception = FATAL_EXP_IGMP_SNOOPED_PACKET;
            pkt_info->fatal_exception_valid = TRUE;
        }
    }

    return DRV_E_NONE;
}

