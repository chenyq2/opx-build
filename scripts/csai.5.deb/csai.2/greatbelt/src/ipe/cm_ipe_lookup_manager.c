/****************************************************************************
 * cm_ipe_lookup_manager.c  Provides IPE lookup handle function.
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Vision:      V1.0.
 * Author       XuZx.
 * Date:        2010-10-28.
 * Reason:      Create for GreatBelt
 *
 * Modify History:
 * Vision:      V4.1.1
 * Author       XuZx.
 * Date:        2011-7-7.
 * Reason:      Sync for GreatBelt 4.2.1
 *
 * Revision:    V4.29.0
 * Reviser      XuZx.
 * Date:        2011-10-10.
 * Reason:      Sync for GreatBelt 4.29.0
 *
 * Revision:    V4.29.3
 * Reviser      XuZx.
 * Date:        2011-10-12.
 * Reason:      Sync for GreatBelt 4.29.3
 *
 * Revision:    V4.33.0
 * Reviser      XuZx.
 * Date:        2011-10-25.
 * Reason:      Sync for GreatBelt 4.33.0
 *
 * Revision:    V5.1.0
 * Author:      Wangcy.
 * Date:        2011-12-12.
 * Reason:      sync spec v5.1.0.
 *
 * Revision:    V5.6.0
 * Author:      Wangcy.
 * Date:        2012-01-07.
 * Reason:      sync spec v5.6.0.
 *
 * Revision:    V5.7.0
 * Author:      Wangcy.
 * Date:        2012-01-17.
 * Reason:      sync spec v5.7.0.
 *
 * Reversion:    V5.11.0
 * Author:       ZhouW
 * Date:         2012-03-01.
 * Reason:       sync spec v5.11.0.
 *
 * Reversion:    V5.13.0
 * Author:       ZhouW
 * Date:         2012-03-12.
 * Reason:       sync spec v5.13.0.
 *
 * Reversion:    V5.15.0.1
 * Author:       Wangcy
 * Date:         2012-03-23.
 * Reason:       sync spec v5.13.0.1
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "ctcutil_lib.h"
#include "cm_com_tcam_engine.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
enum ucast_sa_type_e
{
    UCAST_SA_TYPE_NONE,             /* 0 */
    UCAST_SA_TYPE_RPF,              /* 1 */
    UCAST_SA_TYPE_NAT,              /* 2 */
    UCAST_SA_TYPE_PBR,              /* 3 */
    UCAST_SA_INVALID_TYPE
};
typedef enum ucast_sa_type_e ucast_sa_type_t;

struct acl_qos_key_info_s
{
#define MAC_ADDRESS_LENGTH    6
    uint16 ether_type;
    uint8  stag_cos;
    uint8  stag_cfi;
    uint8  ctag_cos;
    uint8  ctag_cfi;
    uint8  layer3_type;
    uint8  layer4_type;
    uint8  mac_da[MAC_ADDRESS_LENGTH];
    uint8  layer2_type;
    uint8  mac_sa[MAC_ADDRESS_LENGTH];
    uint8  ip_header_error;
    uint8  is_tcp;
    uint8  is_udp;
    uint8  ip_options;
    uint8  frag_info;
    uint8  dscp;
    uint16 l4_info_mapped;
    uint16 l4_dest_port;
    uint16 l4_source_port;
    uint32 ipv6_flow_label;
    uint32 ipv6_da[4];
    uint32 ipv6_sa[4];
    uint32 ipv4_da;
    uint32 ipv4_sa;
    uint32 mpls_label0;
    uint32 mpls_label1;
    uint32 mpls_label2;
    uint32 mpls_label3;
    uint16 cvlan_id;
    uint16 svlan_id;
    uint32 acl_label_high  :24;
    uint32 rsv             :8;
    uint32 acl_label_low   :32;
    uint16 vlan_ptr;
    uint8  is_label;
    uint8  routed_packet;
    uint8  ipv4_key_use_label;
    uint8  ipv6_key_use_label;
    uint8  mac_key_use_label;
    uint8  mpls_key_use_label;
    uint8  sub_tbl_id;
    uint8  ipv4_packet;
    uint8  layer3_header_protocol;
    uint8  udf_byte0;
    uint8  udf_byte1;
    uint8  udf_byte2;
    uint8  udf_byte3;
    uint8  svlan_id_valid    :1;
    uint8  cvlan_id_valid    :1;
    uint8  acl_en            :1;
    uint16 arp_op_code;
    ipe_lookup_ctl_t *ipe_lookup_ctl;
};
typedef struct acl_qos_key_info_s acl_qos_key_info_t;

struct lookup_manager_info_s
{
    uint32 stp_block              :1;
    uint32 ip_routed_packet       :1;
    uint32 force_v4_bridge        :1;
    uint32 force_v6_bridge        :1;
    uint32 ipv4_mcast_mac_address :1;
    uint32 ipv4_mcast_address     :1;
    uint32 ipv6_mcast_mac_address :1;
    uint32 ipv6_mcast_address     :1;
    uint32 trill_inner_vlan       :12;
};
typedef struct lookup_manager_info_s lookup_manager_info_t;

struct label_section_info_s
{
    uint8 lm_lookup_num;
    uint8 type;
    uint8 label_port_ctl;
    uint8 resv;
};
typedef struct label_section_info_s label_section_info_t;

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/
/****************************************************************************
 * Name:       _cm_ipe_lookup_manager_ipv4_martian_addr
 * Purpose:    check if the ip sa is martian address
 * Parameters:
 *  Input:     chip_id
 *             route ctl pointer
 *             ip_sa
 * Output:     ipv4_martian_address  bool
 *
 * Return:     DRV_E_NONE  -- success.
 *             Other       -- Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_lookup_manager_ipv4_martian_addr(uint8 chip_id, uint32 ip_sa,
                                                         uint8 *ipv4_martian_address)
{
    uint8 ipv4_martian_check = 0;
    uint32 cmd = 0;
    ipe_route_martian_addr_t ipe_route_martian_addr;
    ipe_lookup_route_ctl_t ipe_lkp_route_ctl;

    sal_memset(&ipe_lkp_route_ctl, 0, sizeof(ipe_lkp_route_ctl));
    cmd = DRV_IOR(IpeLookupRouteCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_lkp_route_ctl));

    if (IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_low, 0) && (0xe == ((ip_sa >> 28) & 0xf)))
    {
        SET_BIT(ipv4_martian_check, 0);
    }

    if (IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_low, 1) && (0xf == ((ip_sa >> 28) & 0xf)))
    {
        SET_BIT(ipv4_martian_check, 1);
    }

    if (IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_low, 2) && (127 == ((ip_sa >> 24) & 0xff)))
    {
        SET_BIT(ipv4_martian_check, 2);
    }

    if (IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_low, 3) && (0 == ((ip_sa >> 24) & 0xff)))
    {
        SET_BIT(ipv4_martian_check, 3);
    }

    sal_memset(&ipe_route_martian_addr, 0, sizeof(ipe_route_martian_addr));
    cmd = DRV_IOR(IpeRouteMartianAddr_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_route_martian_addr));

    if (IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_low, 4)
       && ((ip_sa & ipe_route_martian_addr.flex0_mask) == ipe_route_martian_addr.flex0_value))
    {
        SET_BIT(ipv4_martian_check, 4);
    }

    if (IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_low, 5)
       && ((ip_sa & ipe_route_martian_addr.flex1_mask) == ipe_route_martian_addr.flex1_value))
    {
        SET_BIT(ipv4_martian_check, 5);
    }

    if (0 != ipv4_martian_check)
    {
        *ipv4_martian_address = TRUE;
    }
    else
    {
        *ipv4_martian_address = FALSE;
    }

    return DRV_E_NONE;
}


/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/
/****************************************************************************
 * Name:      _cm_ipe_lookup_manager_get_acl_qos_key_info
 * Purpose:   IPE lookup management get key info.
 * Parameters:
 * Input:     pkt_info  -- pointer to buffer which store packet info
 * Output:    p_key_info   -- pointer to buffer which save the key info
 * Return:    void.
 * Note:      none.
 ****************************************************************************/
static void
_cm_ipe_lookup_manager_get_acl_qos_key_info(ipe_packet_info_t* pkt_info,
                                                             acl_qos_key_info_t* p_acl_qos_key_info)
{
    parsing_result_t* parser_result = (parsing_result_t *)pkt_info->parser_rslt;

    /* for general packet, ParserResult1 will be used.
       for tunnel decap packet, packetInfo.aclQosUseInnerInfo will decide which ParserResult should be used */
    parser_result = pkt_info->acl_qos_use_outer_info ? pkt_info->parser_rslt1 : pkt_info->parser_rslt;

    p_acl_qos_key_info->ether_type = parser_result->l2_s.layer2_header_protocol;
    p_acl_qos_key_info->stag_cos = parser_result->l2_s.stag_cos;
    p_acl_qos_key_info->stag_cfi = parser_result->l2_s.stag_cfi;
    p_acl_qos_key_info->ctag_cos = parser_result->l2_s.ctag_cos;
    p_acl_qos_key_info->ctag_cfi = parser_result->l2_s.ctag_cfi;
    p_acl_qos_key_info->layer3_type = parser_result->layer3_type;
    p_acl_qos_key_info->mac_da[0] = parser_result->l2_s.mac_da0;
    p_acl_qos_key_info->mac_da[1] = parser_result->l2_s.mac_da1;
    p_acl_qos_key_info->mac_da[2] = parser_result->l2_s.mac_da2;
    p_acl_qos_key_info->mac_da[3] = parser_result->l2_s.mac_da3;
    p_acl_qos_key_info->mac_da[4] = parser_result->l2_s.mac_da4;
    p_acl_qos_key_info->mac_da[5] = parser_result->l2_s.mac_da5;
    p_acl_qos_key_info->layer2_type = parser_result->layer2_type;
    p_acl_qos_key_info->mac_sa[0] = parser_result->l2_s.mac_sa0;
    p_acl_qos_key_info->mac_sa[1] = parser_result->l2_s.mac_sa1;
    p_acl_qos_key_info->mac_sa[2] = parser_result->l2_s.mac_sa2;
    p_acl_qos_key_info->mac_sa[3] = parser_result->l2_s.mac_sa3;
    p_acl_qos_key_info->mac_sa[4] = parser_result->l2_s.mac_sa4;
    p_acl_qos_key_info->mac_sa[5] = parser_result->l2_s.mac_sa5;
    p_acl_qos_key_info->ip_header_error = parser_result->l3_s.ip_header_error;
    p_acl_qos_key_info->is_tcp = parser_result->l4_s.is_tcp;
    p_acl_qos_key_info->is_udp = parser_result->l4_s.is_udp;
    p_acl_qos_key_info->ip_options = parser_result->l3_s.ip_options;
    p_acl_qos_key_info->frag_info = parser_result->l3_s.frag_info;
    p_acl_qos_key_info->dscp = (parser_result->l3_s.tos.ip_tos >> 2) & 0x3F;
    p_acl_qos_key_info->l4_info_mapped = parser_result->l4_s.layer4_info_mapped;
    p_acl_qos_key_info->l4_dest_port = parser_result->l4_s.l4_dst_port.l4_dest_port;
    p_acl_qos_key_info->l4_source_port = parser_result->l4_s.l4_src_port.l4_source_port;
    p_acl_qos_key_info->ipv6_flow_label = parser_result->l3_s.ipv6_flow_label;
    p_acl_qos_key_info->ipv6_da[0] = parser_result->l3_s.ip_da.ipv6.ipda_31_0;
    p_acl_qos_key_info->ipv6_da[1] = parser_result->l3_s.ip_da.ipv6.ipda_63_32;
    p_acl_qos_key_info->ipv6_da[2] = parser_result->l3_s.ip_da.ipv6.ipda_95_64;
    p_acl_qos_key_info->ipv6_da[3] = parser_result->l3_s.ip_da.ipv6.ipda_127_96;
    p_acl_qos_key_info->ipv6_sa[0] = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
    p_acl_qos_key_info->ipv6_sa[1] = parser_result->l3_s.ip_sa.ipv6.ipsa_63_32;
    p_acl_qos_key_info->ipv6_sa[2] = parser_result->l3_s.ip_sa.ipv6.ipsa_95_64;
    p_acl_qos_key_info->ipv6_sa[3] = parser_result->l3_s.ip_sa.ipv6.ipsa_127_96;

    if (parser_result->layer3_type == L3_TYPE_ARP)
    {
        p_acl_qos_key_info->ipv4_da = parser_result->l3_s.ip_da.arp.target_ip;
        p_acl_qos_key_info->ipv4_sa = parser_result->l3_s.ip_sa.arp.sender_ip;
    }
    else
    {
        p_acl_qos_key_info->ipv4_da = parser_result->l3_s.ip_da.ipv4.ipda;
        p_acl_qos_key_info->ipv4_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
    }
    p_acl_qos_key_info->mpls_label0 = parser_result->l3_s.ip_da.mpls.mpls_label0;
    p_acl_qos_key_info->mpls_label1 = parser_result->l3_s.ip_da.mpls.mpls_label1;
    p_acl_qos_key_info->mpls_label2 = parser_result->l3_s.ip_da.mpls.mpls_label2;
    p_acl_qos_key_info->mpls_label3 = parser_result->l3_s.ip_da.mpls.mpls_label3;
    p_acl_qos_key_info->layer3_header_protocol = parser_result->l3_s.layer3_header_protocol;

    p_acl_qos_key_info->arp_op_code = parser_result->l3_s.ip_da.arp.arp_op_code;

    /* different from spec, for cmodel generate key */
    p_acl_qos_key_info->ipv4_key_use_label = pkt_info->ipv4_key_use_label;
    p_acl_qos_key_info->ipv6_key_use_label = pkt_info->ipv6_key_use_label;
    p_acl_qos_key_info->mac_key_use_label = pkt_info->mac_key_use_label;
    p_acl_qos_key_info->mpls_key_use_label = pkt_info->mpls_key_use_label;


}

static void
_cm_ipe_lookup_manager_construct_aclqosipv6_key(ds_acl_qos_ipv6_key_t* p_ds_acl_qos_ipv6_key,
                                                                acl_qos_key_info_t* p_acl_qos_key_info)
{
    p_ds_acl_qos_ipv6_key->is_acl_qos_key0 = TRUE;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key1 = TRUE;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key2 = TRUE;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key3 = TRUE;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key4 = TRUE;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key5 = TRUE;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key6 = TRUE;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key7 = TRUE;

    p_ds_acl_qos_ipv6_key->sub_table_id1 = p_acl_qos_key_info->sub_tbl_id;
    p_ds_acl_qos_ipv6_key->sub_table_id3 = p_acl_qos_key_info->sub_tbl_id;
    p_ds_acl_qos_ipv6_key->sub_table_id5 = p_acl_qos_key_info->sub_tbl_id;
    p_ds_acl_qos_ipv6_key->sub_table_id7 = p_acl_qos_key_info->sub_tbl_id;

    p_ds_acl_qos_ipv6_key->acl_use_label = p_acl_qos_key_info->ipv6_key_use_label;
    p_ds_acl_qos_ipv6_key->direction = TCAM_KEY_DIR_IPE;

    p_ds_acl_qos_ipv6_key->ip_sa31_0 = p_acl_qos_key_info->ipv6_sa[0];
    p_ds_acl_qos_ipv6_key->ip_sa63_32 = p_acl_qos_key_info->ipv6_sa[1];
    p_ds_acl_qos_ipv6_key->ip_sa71_64 = p_acl_qos_key_info->ipv6_sa[2] & 0xFF;
    p_ds_acl_qos_ipv6_key->ip_sa103_72 = ((p_acl_qos_key_info->ipv6_sa[3] & 0xFF) << 24)
                                          | (p_acl_qos_key_info->ipv6_sa[2] >> 8);
    p_ds_acl_qos_ipv6_key->ip_sa127_104 = p_acl_qos_key_info->ipv6_sa[3] >> 8;

    p_ds_acl_qos_ipv6_key->l4_source_port15_12 = (p_acl_qos_key_info->l4_source_port >> 12) & 0xF;
    p_ds_acl_qos_ipv6_key->l4_source_port11_4 = (p_acl_qos_key_info->l4_source_port >> 4) & 0xFF;
    p_ds_acl_qos_ipv6_key->l4_source_port3_0 = p_acl_qos_key_info->l4_source_port & 0xF;

    p_ds_acl_qos_ipv6_key->l4_dest_port15_6 = (p_acl_qos_key_info->l4_dest_port >> 6) & 0x3FF;
    p_ds_acl_qos_ipv6_key->l4_dest_port5_0 = p_acl_qos_key_info->l4_dest_port & 0x3F;

    p_ds_acl_qos_ipv6_key->ip_da31_0 = p_acl_qos_key_info->ipv6_da[0];
    p_ds_acl_qos_ipv6_key->ip_da63_32 = p_acl_qos_key_info->ipv6_da[1];
    p_ds_acl_qos_ipv6_key->ip_da71_64 = p_acl_qos_key_info->ipv6_da[2] & 0xFF;
    p_ds_acl_qos_ipv6_key->ip_da103_72 = ((p_acl_qos_key_info->ipv6_da[3] & 0xFF) << 24)
                                          | (p_acl_qos_key_info->ipv6_da[2] >> 8);
    p_ds_acl_qos_ipv6_key->ip_da127_104 = p_acl_qos_key_info->ipv6_da[3] >> 8;

    p_ds_acl_qos_ipv6_key->is_label = p_acl_qos_key_info->is_label;
    p_ds_acl_qos_ipv6_key->is_udp = p_acl_qos_key_info->is_udp;
    p_ds_acl_qos_ipv6_key->is_tcp = p_acl_qos_key_info->is_tcp;
    p_ds_acl_qos_ipv6_key->routed_packet = p_acl_qos_key_info->routed_packet;

    p_ds_acl_qos_ipv6_key->acl_label0 = p_acl_qos_key_info->acl_label_low & 0x1;
    p_ds_acl_qos_ipv6_key->acl_label6_1 = (p_acl_qos_key_info->acl_label_low >> 1) & 0x3F;
    p_ds_acl_qos_ipv6_key->acl_label9_7 = (p_acl_qos_key_info->acl_label_low >> 7) & 0x7;
    p_ds_acl_qos_ipv6_key->acl_label10 = (p_acl_qos_key_info->acl_label_low >> 10) & 0x1;
    p_ds_acl_qos_ipv6_key->acl_label14_11 = (p_acl_qos_key_info->acl_label_low >> 11) & 0xF;
    p_ds_acl_qos_ipv6_key->acl_label16_15 = (p_acl_qos_key_info->acl_label_low >> 15) & 0x3;
    p_ds_acl_qos_ipv6_key->acl_label19_17 = (p_acl_qos_key_info->acl_label_low >> 17) & 0x7;
    p_ds_acl_qos_ipv6_key->acl_label51_20 = ((p_acl_qos_key_info->acl_label_high & 0xFFFFF) << 12)
                                            | ((p_acl_qos_key_info->acl_label_low >> 20) & 0xFFF);
    p_ds_acl_qos_ipv6_key->acl_label55_52 = (p_acl_qos_key_info->acl_label_high >> 20) & 0xF;

    p_ds_acl_qos_ipv6_key->l4_info_mapped = p_acl_qos_key_info->l4_info_mapped & 0xFFF;
    p_ds_acl_qos_ipv6_key->frag_info = p_acl_qos_key_info->frag_info & 0x3;
    p_ds_acl_qos_ipv6_key->ip_options = p_acl_qos_key_info->ip_options & 0x1;
    p_ds_acl_qos_ipv6_key->ip_header_error = p_acl_qos_key_info->ip_header_error & 0x1;
    p_ds_acl_qos_ipv6_key->layer3_type = p_acl_qos_key_info->layer3_type & 0xF;
    p_ds_acl_qos_ipv6_key->ipv6_flow_label = p_acl_qos_key_info->ipv6_flow_label & 0xFFFFF;
    p_ds_acl_qos_ipv6_key->dscp = p_acl_qos_key_info->dscp & 0x3F;
    p_ds_acl_qos_ipv6_key->ether_type = p_acl_qos_key_info->ether_type;
    p_ds_acl_qos_ipv6_key->svlan_id = p_acl_qos_key_info->svlan_id & 0xFFF;
    p_ds_acl_qos_ipv6_key->cvlan_id = p_acl_qos_key_info->cvlan_id & 0xFFF;
    p_ds_acl_qos_ipv6_key->svlan_id_valid = p_acl_qos_key_info->svlan_id_valid;
    p_ds_acl_qos_ipv6_key->cvlan_id_valid = p_acl_qos_key_info->cvlan_id_valid;
    p_ds_acl_qos_ipv6_key->mac_sa31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_sa[3], p_acl_qos_key_info->mac_sa[2],
                                                    p_acl_qos_key_info->mac_sa[1], p_acl_qos_key_info->mac_sa[0]);
    p_ds_acl_qos_ipv6_key->mac_sa47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_sa[5], p_acl_qos_key_info->mac_sa[4]);
    p_ds_acl_qos_ipv6_key->mac_da31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_da[3], p_acl_qos_key_info->mac_da[2],
                                                    p_acl_qos_key_info->mac_da[1], p_acl_qos_key_info->mac_da[0]);
    p_ds_acl_qos_ipv6_key->mac_da47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_da[5], p_acl_qos_key_info->mac_da[4]);
    p_ds_acl_qos_ipv6_key->vlan_ptr = p_acl_qos_key_info->vlan_ptr & 0x1FFF;
    p_ds_acl_qos_ipv6_key->stag_cos = p_acl_qos_key_info->stag_cos & 0x7;
    p_ds_acl_qos_ipv6_key->stag_cfi = p_acl_qos_key_info->stag_cfi & 0x1;
    p_ds_acl_qos_ipv6_key->ctag_cos = p_acl_qos_key_info->ctag_cos & 0x7;
    p_ds_acl_qos_ipv6_key->ctag_cfi = p_acl_qos_key_info->ctag_cfi & 0x1;
    p_ds_acl_qos_ipv6_key->layer2_type = p_acl_qos_key_info->layer2_type & 0xF;

}

static void
_cm_ipe_lookup_manager_construct_aclqosipv4_key(ds_acl_qos_ipv4_key_t* p_ds_acl_qos_ipv4_key,
                                                                   acl_qos_key_info_t* p_acl_qos_key_info)
{
    p_ds_acl_qos_ipv4_key->is_acl_qos_key0 = TRUE;
    p_ds_acl_qos_ipv4_key->is_acl_qos_key1 = TRUE;
    p_ds_acl_qos_ipv4_key->is_acl_qos_key2 = TRUE;
    p_ds_acl_qos_ipv4_key->is_acl_qos_key3 = TRUE;

    p_ds_acl_qos_ipv4_key->sub_table_id1 = p_acl_qos_key_info->sub_tbl_id;
    p_ds_acl_qos_ipv4_key->sub_table_id3 = p_acl_qos_key_info->sub_tbl_id;

    p_ds_acl_qos_ipv4_key->acl_use_label = p_acl_qos_key_info->ipv4_key_use_label;
    p_ds_acl_qos_ipv4_key->direction = TCAM_KEY_DIR_IPE;

    p_ds_acl_qos_ipv4_key->ip_sa = p_acl_qos_key_info->ipv4_sa;
    p_ds_acl_qos_ipv4_key->ip_da = p_acl_qos_key_info->ipv4_da;
    p_ds_acl_qos_ipv4_key->is_label = p_acl_qos_key_info->is_label & 0x1;
    p_ds_acl_qos_ipv4_key->l4_dest_port = p_acl_qos_key_info->l4_dest_port & 0xFFFF;
    p_ds_acl_qos_ipv4_key->ipv4_packet = p_acl_qos_key_info->ipv4_packet & 0x1;
    p_ds_acl_qos_ipv4_key->l4_info_mapped = p_acl_qos_key_info->l4_info_mapped & 0xFFF;
    p_ds_acl_qos_ipv4_key->dscp = p_acl_qos_key_info->dscp & 0x3F;
    p_ds_acl_qos_ipv4_key->frag_info = p_acl_qos_key_info->frag_info & 0x3;
    p_ds_acl_qos_ipv4_key->ip_options = p_acl_qos_key_info->ip_options & 0x1;
    p_ds_acl_qos_ipv4_key->is_udp = p_acl_qos_key_info->is_udp & 0x1;
    p_ds_acl_qos_ipv4_key->is_tcp = p_acl_qos_key_info->is_tcp & 0x1;
    p_ds_acl_qos_ipv4_key->routed_packet = p_acl_qos_key_info->routed_packet & 0x1;
    p_ds_acl_qos_ipv4_key->ip_header_error = p_acl_qos_key_info->ip_header_error & 0x1;

    p_ds_acl_qos_ipv4_key->mac_sa47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_sa[5], p_acl_qos_key_info->mac_sa[4]);
    p_ds_acl_qos_ipv4_key->mac_sa31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_sa[3], p_acl_qos_key_info->mac_sa[2],
                                                    p_acl_qos_key_info->mac_sa[1], p_acl_qos_key_info->mac_sa[0]);
    p_ds_acl_qos_ipv4_key->svlan_id = p_acl_qos_key_info->svlan_id & 0xFFF;
    p_ds_acl_qos_ipv4_key->ctag_cfi = p_acl_qos_key_info->ctag_cfi & 0x1;
    p_ds_acl_qos_ipv4_key->ctag_cos = p_acl_qos_key_info->ctag_cos & 0x7;
    p_ds_acl_qos_ipv4_key->mac_da47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_da[5], p_acl_qos_key_info->mac_da[4]);
    p_ds_acl_qos_ipv4_key->mac_da31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_da[3], p_acl_qos_key_info->mac_da[2],
                                                    p_acl_qos_key_info->mac_da[1], p_acl_qos_key_info->mac_da[0]);
    p_ds_acl_qos_ipv4_key->stag_cfi = p_acl_qos_key_info->stag_cfi & 0x1;
    p_ds_acl_qos_ipv4_key->stag_cos = p_acl_qos_key_info->stag_cos & 0x7;
    p_ds_acl_qos_ipv4_key->cvlan_id = p_acl_qos_key_info->cvlan_id & 0xFFF;
    p_ds_acl_qos_ipv4_key->cvlan_id_valid = p_acl_qos_key_info->cvlan_id_valid;
    p_ds_acl_qos_ipv4_key->svlan_id_valid = p_acl_qos_key_info->svlan_id_valid;
    p_ds_acl_qos_ipv4_key->acl_label9_0 = (p_acl_qos_key_info->acl_label_low & 0x3FF);
    p_ds_acl_qos_ipv4_key->acl_label19_10 = (p_acl_qos_key_info->acl_label_low >> 10) & 0x3FF;
    p_ds_acl_qos_ipv4_key->acl_label28_20 = (p_acl_qos_key_info->acl_label_low >> 20) & 0x1FF;
    p_ds_acl_qos_ipv4_key->acl_label32_29 = ((p_acl_qos_key_info->acl_label_high & 0x1) << 3)
                                            | ((p_acl_qos_key_info->acl_label_low >> 29) & 0x7);
    p_ds_acl_qos_ipv4_key->acl_label41_33 = (p_acl_qos_key_info->acl_label_high >> 1) & 0x1FF;
    p_ds_acl_qos_ipv4_key->acl_label53_42 = (p_acl_qos_key_info->acl_label_high >> 10) & 0xFFF;
    p_ds_acl_qos_ipv4_key->acl_label55_54 = (p_acl_qos_key_info->acl_label_high >> 22) & 0x3;

#if 0
    if (p_acl_qos_key_info->ipv4_packet)
    {
        p_ds_acl_qos_ipv4_key->ip_sa = p_acl_qos_key_info->ipv4_sa;
    }
    else
    {
        if (L3_TYPE_ARP != p_acl_qos_key_info->layer3_type)
        {
            p_ds_acl_qos_ipv4_key->ip_sa = (p_acl_qos_key_info->layer2_type << 16) | p_acl_qos_key_info->ether_type;
        }
        else if (p_acl_qos_key_info->ipe_lookup_ctl->ip_sa_mode_for_arp)
        {
            p_ds_acl_qos_ipv4_key->ip_sa = p_acl_qos_key_info->ipv4_sa;
        }
        else
        {
            p_ds_acl_qos_ipv4_key->ip_sa = (p_acl_qos_key_info->layer2_type << 16) | (p_acl_qos_key_info->ether_type);
        }
    }
#endif
    p_ds_acl_qos_ipv4_key->is_arp_key = (p_acl_qos_key_info->layer3_type == L3_TYPE_ARP);

    if (L3_TYPE_ARP == p_acl_qos_key_info->layer3_type)
    {
        p_ds_acl_qos_ipv4_key->l4_source_port = p_acl_qos_key_info->arp_op_code;
    }
    else
    {
        p_ds_acl_qos_ipv4_key->l4_source_port = p_acl_qos_key_info->l4_source_port & 0xFFFF;
    }

    if ((L3_TYPE_IPV4 != p_acl_qos_key_info->layer3_type)
        && p_acl_qos_key_info->acl_en
        && p_acl_qos_key_info->ipe_lookup_ctl->l4_dest_port_overwrite)
    {
        /* overwrite l4DestPort use etherType */
        p_ds_acl_qos_ipv4_key->l4_dest_port = p_acl_qos_key_info->ether_type;
        p_ds_acl_qos_ipv4_key->dscp = p_acl_qos_key_info->layer2_type;
    }
}

static void
_cm_ipe_lookup_manager_construct_aclqosmpls_key(ds_acl_qos_mpls_key_t* p_ds_acl_qos_mpls_key,
                                                                    acl_qos_key_info_t* p_acl_qos_key_info)
{
    p_ds_acl_qos_mpls_key->is_acl_qos_key0 = TRUE;
    p_ds_acl_qos_mpls_key->is_acl_qos_key1 = TRUE;
    p_ds_acl_qos_mpls_key->is_acl_qos_key2 = TRUE;
    p_ds_acl_qos_mpls_key->is_acl_qos_key3 = TRUE;

    p_ds_acl_qos_mpls_key->sub_table_id1 = p_acl_qos_key_info->sub_tbl_id;
    p_ds_acl_qos_mpls_key->sub_table_id3 = p_acl_qos_key_info->sub_tbl_id;

    p_ds_acl_qos_mpls_key->acl_use_label = p_acl_qos_key_info->mpls_key_use_label;
    p_ds_acl_qos_mpls_key->direction = TCAM_KEY_DIR_IPE;

    p_ds_acl_qos_mpls_key->mpls_label0 = p_acl_qos_key_info->mpls_label0;
    p_ds_acl_qos_mpls_key->mpls_label1 = p_acl_qos_key_info->mpls_label1;
    p_ds_acl_qos_mpls_key->mpls_label2 = p_acl_qos_key_info->mpls_label2;
    p_ds_acl_qos_mpls_key->mpls_label3 = p_acl_qos_key_info->mpls_label3;

    p_ds_acl_qos_mpls_key->is_label = p_acl_qos_key_info->is_label;
    p_ds_acl_qos_mpls_key->routed_packet = p_acl_qos_key_info->routed_packet;
    p_ds_acl_qos_mpls_key->mac_sa47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_sa[5], p_acl_qos_key_info->mac_sa[4]);
    p_ds_acl_qos_mpls_key->mac_sa31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_sa[3], p_acl_qos_key_info->mac_sa[2],
                                                    p_acl_qos_key_info->mac_sa[1], p_acl_qos_key_info->mac_sa[0]);
    p_ds_acl_qos_mpls_key->svlan_id = p_acl_qos_key_info->svlan_id;
    p_ds_acl_qos_mpls_key->stag_cfi = p_acl_qos_key_info->stag_cfi;
    p_ds_acl_qos_mpls_key->stag_cos = p_acl_qos_key_info->stag_cos;
    p_ds_acl_qos_mpls_key->cvlan_id = p_acl_qos_key_info->cvlan_id;
    p_ds_acl_qos_mpls_key->ctag_cfi = p_acl_qos_key_info->ctag_cfi;
    p_ds_acl_qos_mpls_key->ctag_cos = p_acl_qos_key_info->ctag_cos;
    p_ds_acl_qos_mpls_key->mac_da47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_da[5], p_acl_qos_key_info->mac_da[4]);
    p_ds_acl_qos_mpls_key->mac_da31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_da[3], p_acl_qos_key_info->mac_da[2],
                                                    p_acl_qos_key_info->mac_da[1], p_acl_qos_key_info->mac_da[0]);
    p_ds_acl_qos_mpls_key->acl_label11_0 = p_acl_qos_key_info->acl_label_low & 0xFFF;
    p_ds_acl_qos_mpls_key->acl_label24_12 = (p_acl_qos_key_info->acl_label_low >> 12) & 0x1FFF;
    p_ds_acl_qos_mpls_key->acl_label37_25 = ((p_acl_qos_key_info->acl_label_high & 0x3F) << 7)
                                        | ((p_acl_qos_key_info->acl_label_low >> 25) & 0x7F);
    p_ds_acl_qos_mpls_key->acl_label51_38 = (p_acl_qos_key_info->acl_label_high >> 6) & 0x3FFF;
}

static void
_cm_ipe_lookup_manager_construct_aclqosmac_key(ds_acl_qos_mac_key_t* p_ds_acl_qos_mac_key,
                                                                   acl_qos_key_info_t* p_acl_qos_key_info)
{
    p_ds_acl_qos_mac_key->is_acl_qos_key0 = TRUE;
    p_ds_acl_qos_mac_key->is_acl_qos_key1 = TRUE;
    p_ds_acl_qos_mac_key->is_acl_qos_key2 = TRUE;
    p_ds_acl_qos_mac_key->is_acl_qos_key3 = TRUE;

    p_ds_acl_qos_mac_key->sub_table_id1 = p_acl_qos_key_info->sub_tbl_id;
    p_ds_acl_qos_mac_key->sub_table_id3 = p_acl_qos_key_info->sub_tbl_id;

    p_ds_acl_qos_mac_key->acl_use_label = p_acl_qos_key_info->mac_key_use_label;
    p_ds_acl_qos_mac_key->direction = TCAM_KEY_DIR_IPE;

    p_ds_acl_qos_mac_key->mac_sa47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_sa[5], p_acl_qos_key_info->mac_sa[4]);
    p_ds_acl_qos_mac_key->mac_sa31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_sa[3], p_acl_qos_key_info->mac_sa[2],
                                                   p_acl_qos_key_info->mac_sa[1], p_acl_qos_key_info->mac_sa[0]);
    p_ds_acl_qos_mac_key->svlan_id = p_acl_qos_key_info->svlan_id;
    p_ds_acl_qos_mac_key->layer2_type = p_acl_qos_key_info->layer2_type;
    p_ds_acl_qos_mac_key->is_label = p_acl_qos_key_info->is_label;
    p_ds_acl_qos_mac_key->mac_da47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_da[5], p_acl_qos_key_info->mac_da[4]);
    p_ds_acl_qos_mac_key->mac_da31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_da[3], p_acl_qos_key_info->mac_da[2],
                                                   p_acl_qos_key_info->mac_da[1], p_acl_qos_key_info->mac_da[0]);
    p_ds_acl_qos_mac_key->layer3_type = p_acl_qos_key_info->layer3_type;
    p_ds_acl_qos_mac_key->cvlan_id = p_acl_qos_key_info->cvlan_id & 0xFFF;
    p_ds_acl_qos_mac_key->ctag_cfi = p_acl_qos_key_info->ctag_cfi & 0x1;
    p_ds_acl_qos_mac_key->ctag_cos = p_acl_qos_key_info->ctag_cos & 0x7;
    p_ds_acl_qos_mac_key->stag_cfi = p_acl_qos_key_info->stag_cfi & 0x1;
    p_ds_acl_qos_mac_key->stag_cos = p_acl_qos_key_info->stag_cos & 0x7;
    p_ds_acl_qos_mac_key->ether_type = p_acl_qos_key_info->ether_type;
    p_ds_acl_qos_mac_key->vlan_ptr = p_acl_qos_key_info->vlan_ptr & 0x1FFF;
    p_ds_acl_qos_mac_key->svlan_id_valid = p_acl_qos_key_info->svlan_id_valid;
    p_ds_acl_qos_mac_key->cvlan_id_valid = p_acl_qos_key_info->cvlan_id_valid;
    p_ds_acl_qos_mac_key->acl_label10_0 = p_acl_qos_key_info->acl_label_low & 0x7FF;
    p_ds_acl_qos_mac_key->acl_label19_11 = (p_acl_qos_key_info->acl_label_low >> 11) & 0x1FF;
    p_ds_acl_qos_mac_key->acl_label35_20 = ((p_acl_qos_key_info->acl_label_high & 0xF) << 12)
                                           | ((p_acl_qos_key_info->acl_label_low >> 20) & 0xFFF);
    p_ds_acl_qos_mac_key->acl_label51_36 = (p_acl_qos_key_info->acl_label_high >> 4) & 0xFFFF;
    p_ds_acl_qos_mac_key->acl_label55_52 = (p_acl_qos_key_info->acl_label_high >> 20) & 0xF;

#if 0
    if (((L3_TYPE_ARP == p_acl_qos_key_info->layer3_type) && !p_acl_qos_key_info->ipe_lookup_ctl->ip_sa_mode_for_arp)
        || ((L3_TYPE_TRILL == p_acl_qos_key_info->layer3_type) && !p_acl_qos_key_info->ipe_lookup_ctl->ip_sa_mode_for_trill)
        || ((L3_TYPE_FCOE == p_acl_qos_key_info->layer3_type) && !p_acl_qos_key_info->ipe_lookup_ctl->ip_sa_mode_for_fcoe))
    {
        p_ds_acl_qos_mac_key->ip_sa = (p_acl_qos_key_info->layer2_type<<16 | p_acl_qos_key_info->ether_type);
    }
#endif
    p_ds_acl_qos_mac_key->ip_sa = p_acl_qos_key_info->ipv4_sa;
    p_ds_acl_qos_mac_key->ip_da = p_acl_qos_key_info->ipv4_da;

    if (L3_TYPE_ARP == p_acl_qos_key_info->layer3_type)
    {
        p_ds_acl_qos_mac_key->arp_op_code0_0 = IS_BIT_SET(p_acl_qos_key_info->arp_op_code, 0);
        p_ds_acl_qos_mac_key->arp_op_code15_1 = (p_acl_qos_key_info->arp_op_code >> 1) & 0x7FFF;
    }
    else
    {
        p_ds_acl_qos_mac_key->arp_op_code0_0 = 0;
        p_ds_acl_qos_mac_key->arp_op_code15_1 = 0;
    }
}

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
/****************************************************************************
 * Name:       _cm_ipe_lookup_manager_exception3_cam_lookup
 * Purpose:    IPE lookup management exception3 cam lookup.
 * Parameters:
 * Input:      chip_id                   -- specify the chip id
 *             layer3_header_protocol    -- specify the layer3 header protocol
 * Output:     exception_escape_cam_hit  -- store hit or not result
 *             exception_sub_index       -- store the exception sub index
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_lookup_manager_exception3_cam_lookup(uint8 chip_id,
                                                             uint8 layer3_header_protocol,
                                                             uint8* exception_escape_cam_hit,
                                                             uint8* exception_sub_index)
{
    uint32 cmd = 0;
    ipe_exception3_cam_t ipe_exception3_cam;

    sal_memset(&ipe_exception3_cam, 0, sizeof(ipe_exception3_cam));

    cmd = DRV_IOR(IpeException3Cam_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_exception3_cam));

    if (ipe_exception3_cam.l3_header_protocol0 == layer3_header_protocol)
    {
        if (ipe_exception3_cam.cam_entry_valid0)
        {
            *exception_escape_cam_hit = TRUE;
            *exception_sub_index = ipe_exception3_cam.cam_exception_sub_index0;
        }
    }
    else if (ipe_exception3_cam.l3_header_protocol1 == layer3_header_protocol)
    {
        if (ipe_exception3_cam.cam_entry_valid1)
        {
            *exception_escape_cam_hit = TRUE;
            *exception_sub_index = ipe_exception3_cam.cam_exception_sub_index1;
        }
    }
    else if (ipe_exception3_cam.l3_header_protocol2 == layer3_header_protocol)
    {
        if (ipe_exception3_cam.cam_entry_valid2)
        {
            *exception_escape_cam_hit = TRUE;
            *exception_sub_index = ipe_exception3_cam.cam_exception_sub_index2;
        }
    }
    else if (ipe_exception3_cam.l3_header_protocol3 == layer3_header_protocol)
    {
        if (ipe_exception3_cam.cam_entry_valid3)
        {
            *exception_escape_cam_hit = TRUE;
            *exception_sub_index = ipe_exception3_cam.cam_exception_sub_index3;
        }
    }
    else if (ipe_exception3_cam.l3_header_protocol4 == layer3_header_protocol)
    {
        if (ipe_exception3_cam.cam_entry_valid4)
        {
            *exception_escape_cam_hit = TRUE;
            *exception_sub_index = ipe_exception3_cam.cam_exception_sub_index4;
        }
    }
    else if (ipe_exception3_cam.l3_header_protocol5 == layer3_header_protocol)
    {
        if (ipe_exception3_cam.cam_entry_valid5)
        {
            *exception_escape_cam_hit = TRUE;
            *exception_sub_index = ipe_exception3_cam.cam_exception_sub_index5;
        }
    }
    else if (ipe_exception3_cam.l3_header_protocol6 == layer3_header_protocol)
    {
        if (ipe_exception3_cam.cam_entry_valid6)
        {
            *exception_escape_cam_hit = TRUE;
            *exception_sub_index = ipe_exception3_cam.cam_exception_sub_index6;
        }
    }
    else if (ipe_exception3_cam.l3_header_protocol7 == layer3_header_protocol)
    {
        if (ipe_exception3_cam.cam_entry_valid7)
        {
            *exception_escape_cam_hit = TRUE;
            *exception_sub_index = ipe_exception3_cam.cam_exception_sub_index7;
        }
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_ipe_lookup_manager_exception3_cam_lookup2
 * Purpose:    IPE lookup management exception3 cam lookup.
 * Parameters:
 * Input:      chip_id         -- specify the chip id
 *             is_udp          -- is upd or not
 *             is_tcp          -- is tcp or not
 *             l4_dest_port    -- specify the layer4 dest port
 * Output:     exception_escape_cam_hit2  -- store hit or not result
 *             exception_sub_index2       -- store the exception sub index
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_lookup_manager_exception3_cam_lookup2(uint8 chip_id,
                                                               uint8 is_udp,
                                                               uint8 is_tcp,
                                                               uint16 l4_dest_port,
                                                               uint8* exception_escape_cam_hit2,
                                                               uint8* exception_sub_index2)
{
    uint32 cmd = 0;
    ipe_exception3_cam2_t ipe_exception3_cam2;

    sal_memset(&ipe_exception3_cam2, 0, sizeof(ipe_exception3_cam2));

    cmd = DRV_IOR(IpeException3Cam2_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_exception3_cam2));

    if ((ipe_exception3_cam2.is_udp_value0 == (is_udp & ipe_exception3_cam2.is_udp_mask0))
        && (ipe_exception3_cam2.is_tcp_value0 == (is_tcp & ipe_exception3_cam2.is_tcp_mask0))
        && (ipe_exception3_cam2.dest_port0 == l4_dest_port))
    {
        if (ipe_exception3_cam2.cam2_entry_valid0)
        {
            *exception_escape_cam_hit2 = TRUE;
            *exception_sub_index2 = ipe_exception3_cam2.cam2_exception_sub_index0;
        }
    }
    else if ((ipe_exception3_cam2.is_udp_value1 == (is_udp & ipe_exception3_cam2.is_udp_mask1))
        && (ipe_exception3_cam2.is_tcp_value1 == (is_tcp & ipe_exception3_cam2.is_tcp_mask1))
        && (ipe_exception3_cam2.dest_port1 == l4_dest_port))
    {
        if (ipe_exception3_cam2.cam2_entry_valid1)
        {
            *exception_escape_cam_hit2 = TRUE;
            *exception_sub_index2 = ipe_exception3_cam2.cam2_exception_sub_index1;
        }
    }
    else if ((ipe_exception3_cam2.is_udp_value2 == (is_udp & ipe_exception3_cam2.is_udp_mask2))
        && (ipe_exception3_cam2.is_tcp_value2 == (is_tcp & ipe_exception3_cam2.is_tcp_mask2))
        && (ipe_exception3_cam2.dest_port2 == l4_dest_port))
    {
        if (ipe_exception3_cam2.cam2_entry_valid2)
        {
            *exception_escape_cam_hit2 = TRUE;
            *exception_sub_index2 = ipe_exception3_cam2.cam2_exception_sub_index2;
        }
    }
    else if ((ipe_exception3_cam2.is_udp_value3 == (is_udp & ipe_exception3_cam2.is_udp_mask3))
        && (ipe_exception3_cam2.is_tcp_value3 == (is_tcp & ipe_exception3_cam2.is_tcp_mask3))
        && (ipe_exception3_cam2.dest_port3 == l4_dest_port))
    {
        if (ipe_exception3_cam2.cam2_entry_valid3)
        {
            *exception_escape_cam_hit2 = TRUE;
            *exception_sub_index2 = ipe_exception3_cam2.cam2_exception_sub_index3;
        }
    }
    else if ((ipe_exception3_cam2.is_udp_value4 == (is_udp & ipe_exception3_cam2.is_udp_mask4))
        && (ipe_exception3_cam2.is_tcp_value4 == (is_tcp & ipe_exception3_cam2.is_tcp_mask4))
        && (ipe_exception3_cam2.dest_port4 == l4_dest_port))
    {
        if (ipe_exception3_cam2.cam2_entry_valid4)
        {
            *exception_escape_cam_hit2 = TRUE;
            *exception_sub_index2 = ipe_exception3_cam2.cam2_exception_sub_index4;
        }
    }
    else if ((ipe_exception3_cam2.is_udp_value5 == (is_udp & ipe_exception3_cam2.is_udp_mask5))
        && (ipe_exception3_cam2.is_tcp_value5 == (is_tcp & ipe_exception3_cam2.is_tcp_mask5))
        && (ipe_exception3_cam2.dest_port5 == l4_dest_port))
    {
        if (ipe_exception3_cam2.cam2_entry_valid5)
        {
            *exception_escape_cam_hit2 = TRUE;
            *exception_sub_index2 = ipe_exception3_cam2.cam2_exception_sub_index5;
        }
    }
    else if ((ipe_exception3_cam2.is_udp_value6 == (is_udp & ipe_exception3_cam2.is_udp_mask6))
        && (ipe_exception3_cam2.is_tcp_value6 == (is_tcp & ipe_exception3_cam2.is_tcp_mask6))
        && (ipe_exception3_cam2.dest_port6 == l4_dest_port))
    {
        if (ipe_exception3_cam2.cam2_entry_valid6)
        {
            *exception_escape_cam_hit2 = TRUE;
            *exception_sub_index2 = ipe_exception3_cam2.cam2_exception_sub_index6;
        }
    }
    else if ((ipe_exception3_cam2.is_udp_value7 == (is_udp & ipe_exception3_cam2.is_udp_mask7))
        && (ipe_exception3_cam2.is_tcp_value7 == (is_tcp & ipe_exception3_cam2.is_tcp_mask7))
        && (ipe_exception3_cam2.dest_port7 == l4_dest_port))
    {
        if (ipe_exception3_cam2.cam2_entry_valid7)
        {
            *exception_escape_cam_hit2 = TRUE;
            *exception_sub_index2 = ipe_exception3_cam2.cam2_exception_sub_index7;
        }
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_ipe_lookup_manager_decide_routed_packet
 * Purpose:    IPE lookup management decide routed packet handle.
 * Parameters:
 *  Input:     in_pkt  -- pointer to buffer which save input packet and packet
 *                               header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                                header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_lookup_manager_decide_routed_packet(ipe_in_pkt_t *in_pkt, lookup_manager_info_t* p_lookup_manager_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;
    uint8 chip_id = in_pkt->chip_id;

    ipe_ipv4_mcast_force_route_t ipv4_mcast_force_route;
    ipe_ipv6_mcast_force_route_t ipv6_mcast_force_route;
    ipe_lookup_ctl_t ipe_lookup_ctl;
    ipe_lookup_pbr_ctl_t ipe_lookup_pbr_ctl;

    uint32 cmd = 0;
    uint8 force_v4_ucast = FALSE, force_v4_bridge = FALSE;
    uint8 force_v6_ucast = FALSE, force_v6_bridge = FALSE;
    uint8 ipv4_mcast_address = FALSE, ipv4_ucast_address = FALSE;
    uint8 ipv4_mcast_mac_address = FALSE, ipv6_mcast_mac_address = FALSE;
    uint8 ipv6_mcast_address = FALSE, ipv6_ucast_address = FALSE;
    uint8 ipda_range_match = FALSE;
    uint8 ipda_range0 = 0, ipda_range1 = 0;
    uint8 route_stp_block = 0, stp_block = FALSE;
    uint8 ip_routed_packet = FALSE;
    uint8 route_after_decap_v4 = FALSE, route_after_decap_v6 = FALSE;
    uint32 mac_da_31_0 = 0, mac_da_high = 0;
    uint16 mac_da_47_32 = 0, mac_da_low = 0;
    uint8 is_ipv4_ucast = FALSE, is_ipv4_mcast = FALSE;
    uint8 is_ipv6_ucast = FALSE, is_ipv6_mcast = FALSE;
    uint8 is_ipv4_ucast_nat = FALSE, is_ipv4_ucast_rpf = FALSE, is_ipv4_pbr = FALSE;
    uint8 is_ipv6_ucast_nat = FALSE, is_ipv6_ucast_rpf = FALSE, is_ipv6_pbr = FALSE;
    uint8 is_fcoe = FALSE, is_fcoe_rpf = FALSE;
    uint8 is_trill_ucast = FALSE, is_trill_mcast = FALSE;

    /* blocking or learning */
    stp_block = p_lookup_manager_info->stp_block;

    sal_memset(&ipe_lookup_pbr_ctl, 0, sizeof(ipe_lookup_pbr_ctl));
    cmd = DRV_IOR(IpeLookupPbrCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_lookup_pbr_ctl));

    sal_memset(&ipe_lookup_ctl, 0, sizeof(ipe_lookup_ctl));
    cmd = DRV_IOR(IpeLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_lookup_ctl));

    sal_memset(&ipv4_mcast_force_route, 0, sizeof(ipv4_mcast_force_route));
    cmd = DRV_IOR(IpeIpv4McastForceRoute_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipv4_mcast_force_route));

    ipda_range_match |= ((ipv4_mcast_force_route.addr0_value & ipv4_mcast_force_route.addr0_mask)
                        == (parser_result->l3_s.ip_da.ipv4.ipda & ipv4_mcast_force_route.addr0_mask));
    ipda_range_match |= ((ipv4_mcast_force_route.addr1_value & ipv4_mcast_force_route.addr1_mask)
                        == (parser_result->l3_s.ip_da.ipv4.ipda & ipv4_mcast_force_route.addr1_mask));

    force_v4_bridge = (L3_TYPE_IPV4 == parser_result->layer3_type)
                    && ipda_range_match
                    && ipe_lookup_ctl.ipv4_mcast_force_bridge_en
                    && (L2_TYPE_ETHV2 == parser_result->layer2_type
                            || L2_TYPE_ETHSAP == parser_result->layer2_type
                            || L2_TYPE_ETHSNAP == parser_result->layer2_type)
                    && pkt_info->bridge_en;

    force_v4_ucast = (L3_TYPE_IPV4 == parser_result->layer3_type)
                    && ipda_range_match
                    && ipe_lookup_ctl.ipv4_mcast_force_unicast_en
                    && !force_v4_bridge;

    ipda_range_match = FALSE;

    sal_memset(&ipv6_mcast_force_route, 0, sizeof(ipv6_mcast_force_route));
    cmd = DRV_IOR(IpeIpv6McastForceRoute_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipv6_mcast_force_route));

    ipda_range0 = ((ipv6_mcast_force_route.addr0_value3 & ipv6_mcast_force_route.addr0_mask3)
                   == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 & ipv6_mcast_force_route.addr0_mask3));

    ipda_range0 &= ((ipv6_mcast_force_route.addr0_value2 & ipv6_mcast_force_route.addr0_mask2)
                    == (parser_result->l3_s.ip_da.ipv6.ipda_95_64 & ipv6_mcast_force_route.addr0_mask2));

    ipda_range0 &= ((ipv6_mcast_force_route.addr0_value1 & ipv6_mcast_force_route.addr0_mask1)
                    == (parser_result->l3_s.ip_da.ipv6.ipda_63_32 & ipv6_mcast_force_route.addr0_mask1));

    ipda_range0 &= ((ipv6_mcast_force_route.addr0_value0 & ipv6_mcast_force_route.addr0_mask0)
                    == (parser_result->l3_s.ip_da.ipv6.ipda_31_0 & ipv6_mcast_force_route.addr0_mask0));

    ipda_range_match |= ipda_range0;

    ipda_range1 = ((ipv6_mcast_force_route.addr1_value3 & ipv6_mcast_force_route.addr1_mask3)
                    == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 & ipv6_mcast_force_route.addr1_mask3));

    ipda_range1 &= ((ipv6_mcast_force_route.addr1_value2 & ipv6_mcast_force_route.addr1_mask2)
                    == (parser_result->l3_s.ip_da.ipv6.ipda_95_64 & ipv6_mcast_force_route.addr1_mask2));

    ipda_range1 &= ((ipv6_mcast_force_route.addr1_value1 & ipv6_mcast_force_route.addr1_mask1)
                    == (parser_result->l3_s.ip_da.ipv6.ipda_63_32 & ipv6_mcast_force_route.addr1_mask1));

    ipda_range1 &= ((ipv6_mcast_force_route.addr1_value0 & ipv6_mcast_force_route.addr1_mask0)
                    == (parser_result->l3_s.ip_da.ipv6.ipda_31_0 & ipv6_mcast_force_route.addr1_mask0));

    ipda_range_match |= ipda_range1;

    force_v6_bridge = (L3_TYPE_IPV6 == parser_result->layer3_type)
                      && ipda_range_match
                      && ipe_lookup_ctl.ipv6_mcast_force_bridge_en
                      && (L2_TYPE_ETHV2 == parser_result->layer2_type
                        || L2_TYPE_ETHSAP == parser_result->layer2_type
                        || L2_TYPE_ETHSNAP == parser_result->layer2_type)
                      && pkt_info->bridge_en;

    force_v6_ucast = (L3_TYPE_IPV6 == parser_result->layer3_type)
                      && ipda_range_match
                      && ipe_lookup_ctl.ipv6_mcast_force_unicast_en
                      && !force_v6_bridge;

    pkt_info->force_bridge = force_v4_bridge | force_v6_bridge;

    mac_da_31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                              parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);

    mac_da_47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);

    /* decide if the packet will lend on the routed interface */
    /* for ipv4 */
    ipv4_mcast_address = (L3_TYPE_IPV4 == parser_result->layer3_type)
                        && (0xE == (parser_result->l3_s.ip_da.ipv4.ipda >> 28));

    p_lookup_manager_info->ipv4_mcast_address = ipv4_mcast_address;

    /* ipda if FFFFFFF not need routing, no check for it */
    ipv4_ucast_address = (L3_TYPE_IPV4 == parser_result->layer3_type)
                        && (0xE != (parser_result->l3_s.ip_da.ipv4.ipda >> 28));

    ipv4_mcast_mac_address = (0x01 == parser_result->l2_s.mac_da5)
                             && (!parser_result->l2_s.mac_da4)
                             && (0x5E == parser_result->l2_s.mac_da3)
                             && (!IS_BIT_SET(parser_result->l2_s.mac_da2, 7));

    p_lookup_manager_info->ipv4_mcast_mac_address = ipv4_mcast_mac_address;

    route_after_decap_v4 = ipe_lookup_ctl.system_route_mac_en
                        && (PKT_TYPE_ETHERNETV2 == pkt_info->payload_packet_type)
                        && !pkt_info->fid_type
                        && (((mac_da_47_32 == ipe_lookup_ctl.system_route_mac47_32)
                                && (mac_da_31_0 == ipe_lookup_ctl.system_route_mac31_0))
                            ||((ipv4_mcast_address) && (ipv4_mcast_mac_address)
                                && ipe_lookup_ctl.route_after_decap_mcast_en));

    route_stp_block = stp_block & ipe_lookup_ctl.route_obey_stp;

    if (!pkt_info->is_decap && !pkt_info->is_mpls_switched)
    {
        is_ipv4_ucast = ((ipv4_ucast_address && pkt_info->is_router_mac)
                          || (force_v4_ucast
                             && (pkt_info->is_router_mac || pkt_info->bcast_mac_address || ipv4_mcast_mac_address)))
                         && pkt_info->v4_ucast_en
                         && !route_stp_block
                         && !pkt_info->route_disable;

        is_ipv4_mcast = ipv4_mcast_address
                        && (!force_v4_bridge)
                        && (!force_v4_ucast)
                        && pkt_info->v4_mcast_en
                        && (!route_stp_block)
                        && (!pkt_info->route_disable)
                        && (pkt_info->is_router_mac || pkt_info->bcast_mac_address || ipv4_mcast_mac_address);
    }
    else
    {
        is_ipv4_ucast = ipv4_ucast_address && pkt_info->inner_packet_lookup
                        && ((PKT_TYPE_IPV4 == pkt_info->payload_packet_type) || route_after_decap_v4);

        is_ipv4_mcast = ipv4_mcast_address && pkt_info->inner_packet_lookup
                        && ((PKT_TYPE_IPV4 == pkt_info->payload_packet_type) || route_after_decap_v4);
    }

    is_ipv4_ucast_nat = (!pkt_info->is_decap)
                        && (!pkt_info->is_mpls_switched)
                        && is_ipv4_ucast
                        && (UCAST_SA_TYPE_NAT == pkt_info->v4_ucast_sa_type)
                        && !is_ipv4_mcast; /* NAT not supported in Tunnel */

    is_ipv4_ucast_rpf = (!pkt_info->is_decap)
                        && (!pkt_info->is_mpls_switched)
                        && is_ipv4_ucast
                        && (UCAST_SA_TYPE_RPF == pkt_info->v4_ucast_sa_type)
                        && !is_ipv4_mcast;

    /* fix bug according to spec 2012-05-30, zhouw fix */
    #if 0
    is_ipv4_pbr = (!pkt_info->is_decap) && (!pkt_info->is_mpls_switched)
                  && is_ipv4_ucast && (UCAST_SA_TYPE_PBR == pkt_info->v4_ucast_sa_type)
                  && !is_ipv4_mcast;
    #else
    is_ipv4_pbr = (!pkt_info->is_decap) && (!pkt_info->is_mpls_switched)
                  && (is_ipv4_ucast || (is_ipv4_mcast && ipe_lookup_pbr_ctl.force_ipv4_mcast_pbr))
                  && (UCAST_SA_TYPE_PBR == pkt_info->v4_ucast_sa_type);
    #endif

    /* for IPv6 */
    ipv6_mcast_address = (L3_TYPE_IPV6 == parser_result->layer3_type)
                         && (0xFF == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24));/* ipda[127:120] */

    p_lookup_manager_info->ipv6_mcast_address = ipv6_mcast_address;

    ipv6_ucast_address = (L3_TYPE_IPV6 == parser_result->layer3_type)
                         && (0xFF != (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24));

    ipv6_mcast_mac_address = (0x33 == parser_result->l2_s.mac_da5) && (0x33 == parser_result->l2_s.mac_da4);

    p_lookup_manager_info->ipv6_mcast_mac_address = ipv6_mcast_mac_address;

    route_after_decap_v6 = ipe_lookup_ctl.system_route_mac_en
                        && (PKT_TYPE_ETHERNETV2 == pkt_info->payload_packet_type)
                        && !pkt_info->fid_type
                        && (((mac_da_47_32 == ipe_lookup_ctl.system_route_mac47_32)
                                && (mac_da_31_0 == ipe_lookup_ctl.system_route_mac31_0))
                            ||((ipv6_mcast_address) && (ipv6_mcast_mac_address)
                                && ipe_lookup_ctl.route_after_decap_mcast_en));

    if (!pkt_info->is_decap && !pkt_info->is_mpls_switched)
    {
        is_ipv6_ucast = ((ipv6_ucast_address && pkt_info->is_router_mac)
                          || (force_v6_ucast
                              && (pkt_info->is_router_mac || pkt_info->bcast_mac_address || ipv6_mcast_mac_address)))
                        && pkt_info->v6_ucast_en
                        && (!route_stp_block)
                        && (!pkt_info->route_disable);

        is_ipv6_mcast = ipv6_mcast_address
                        && (!force_v6_bridge)
                        && (!force_v6_ucast)
                        && pkt_info->v6_mcast_en
                        && (!route_stp_block)
                        && (pkt_info->is_router_mac || pkt_info->bcast_mac_address || ipv6_mcast_mac_address)
                        && !pkt_info->route_disable;
    }
    else
    {
        is_ipv6_ucast = ipv6_ucast_address && pkt_info->inner_packet_lookup
                        && ((PKT_TYPE_IPV6 == pkt_info->payload_packet_type) || route_after_decap_v6);

        is_ipv6_mcast = ipv6_mcast_address && pkt_info->inner_packet_lookup
                        && ((PKT_TYPE_IPV6 == pkt_info->payload_packet_type) || route_after_decap_v6);
    }

    is_ipv6_ucast_nat = (!pkt_info->is_decap) && (!pkt_info->is_mpls_switched)
                        && is_ipv6_ucast && (UCAST_SA_TYPE_NAT == pkt_info->v6_ucast_sa_type)
                        && !is_ipv6_mcast;

    is_ipv6_ucast_rpf = (!pkt_info->is_decap) && (!pkt_info->is_mpls_switched)
                        && is_ipv6_ucast && (UCAST_SA_TYPE_RPF == pkt_info->v6_ucast_sa_type)
                        && !is_ipv6_mcast;

    /* fix bug according to spec 2012-05-30, zhouw fix */
    #if 0
    is_ipv6_pbr = (!pkt_info->is_decap) && (!pkt_info->is_mpls_switched)
                  && is_ipv6_ucast && (UCAST_SA_TYPE_PBR == pkt_info->v6_ucast_sa_type)
                  && !is_ipv6_mcast;
    #else
    is_ipv6_pbr = (!pkt_info->is_decap) && (!pkt_info->is_mpls_switched)
                  && (is_ipv6_ucast || (is_ipv6_mcast && ipe_lookup_pbr_ctl.force_ipv6_mcast_pbr))
                  && (UCAST_SA_TYPE_PBR == pkt_info->v6_ucast_sa_type);
    #endif

    ip_routed_packet = is_ipv4_ucast || is_ipv4_mcast || is_ipv6_ucast || is_ipv6_mcast;
    p_lookup_manager_info->ip_routed_packet = ip_routed_packet;

    if (!pkt_info->is_decap && !pkt_info->is_mpls_switched)
    {
        is_fcoe =(pkt_info->is_port_mac
                 || ((parser_result->l2_s.mac_da4 == 0xFC)
                    && (parser_result->l2_s.mac_da5 == 0x0E) && ipe_lookup_ctl.fpma_check_en))
              && (L3_TYPE_FCOE == parser_result->layer3_type)
              && pkt_info->fcoe_en
              && (!route_stp_block);

        is_fcoe_rpf = is_fcoe && pkt_info->fcoe_rpf_en && !route_stp_block;
    }
    else
    {
        is_fcoe = (((parser_result->l2_s.mac_da4 == 0xFC)
                    && (parser_result->l2_s.mac_da5 == 0x0E) && ipe_lookup_ctl.fpma_check_en) ||
                    ((ipe_lookup_ctl.system_port_mac47_32 == MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4))
                    && (ipe_lookup_ctl.system_port_mac31_0 == MAKE_UINT32(parser_result->l2_s.mac_da3,
                        parser_result->l2_s.mac_da2, parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0))))
              && (L3_TYPE_FCOE == parser_result->layer3_type)
              && pkt_info->fcoe_en;

        is_fcoe_rpf = is_fcoe && pkt_info->fcoe_rpf_en;
    }

    is_trill_ucast = (!pkt_info->is_decap)
                     && pkt_info->is_port_mac
                     && (L3_TYPE_TRILL == parser_result->layer3_type)
                     && (!parser_result->l3_s.ip_da.trill.trill_multicast)
                     && pkt_info->trill_en && !route_stp_block;

    mac_da_low = MAKE_UINT16(parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);

    mac_da_high = MAKE_UINT32(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4,
                              parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2);

    is_trill_mcast = (!pkt_info->is_decap)
                     && (pkt_info->is_port_mac
                        || (pkt_info->mcast_mac_address && ipe_lookup_ctl.trill_mcast_mac)
                        || ((mac_da_high == 0x0180c200) && (mac_da_low == 0x40))) /* MacDa = 48'h0180c2000040 */
                     && (L3_TYPE_TRILL == parser_result->layer3_type)
                     && parser_result->l3_s.ip_da.trill.trill_multicast
                     && pkt_info->trill_en
                     && !route_stp_block;

    pkt_info->is_ipv4_ucast = is_ipv4_ucast;
    pkt_info->is_ipv4_ucast_nat = is_ipv4_ucast_nat;
    pkt_info->is_ipv4_mcast = is_ipv4_mcast;
    pkt_info->is_ipv4_ucast_rpf = is_ipv4_ucast_rpf;
    pkt_info->is_ipv4_pbr = is_ipv4_pbr;
    pkt_info->is_ipv6_ucast = is_ipv6_ucast;
    pkt_info->is_ipv6_ucast_nat = is_ipv6_ucast_nat;
    pkt_info->is_ipv6_mcast = is_ipv6_mcast;
    pkt_info->is_ipv6_ucast_rpf = is_ipv6_ucast_rpf;
    pkt_info->is_ipv6_pbr = is_ipv6_pbr;
    pkt_info->is_fcoe = is_fcoe;
    pkt_info->is_trill_ucast = is_trill_ucast;
    pkt_info->is_trill_mcast = is_trill_mcast;
    pkt_info->is_fcoe_rpf = is_fcoe_rpf;

    if (!pkt_info->is_decap && !pkt_info->is_mpls_switched)
    {
        pkt_info->bridge_packet = !ip_routed_packet && !is_fcoe && !is_trill_ucast
                                  && !is_trill_mcast && !pkt_info->is_mpls_switched;
    }
    else
    {
        pkt_info->bridge_packet = !ip_routed_packet && pkt_info->inner_packet_lookup;
    }

    if (pkt_info->fatal_exception_valid && ipe_lookup_ctl.fatal_exception_lookup_en)
    {
        pkt_info->is_ipv4_ucast = 0;
        pkt_info->is_ipv4_ucast_nat = 0;
        pkt_info->is_ipv4_mcast = 0;
        pkt_info->is_ipv4_ucast_rpf = 0;
        pkt_info->is_ipv4_pbr = 0;
        pkt_info->is_ipv6_ucast = 0;
        pkt_info->is_ipv6_ucast_nat = 0;
        pkt_info->is_ipv6_mcast = 0;
        pkt_info->is_ipv6_ucast_rpf = 0;
        pkt_info->is_ipv6_pbr = 0;
        pkt_info->is_fcoe = 0;
        pkt_info->is_trill_ucast = 0;
        pkt_info->is_trill_mcast = 0;
        pkt_info->is_fcoe_rpf = 0;
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_ipe_lookup_manager_lookup_route
 * Purpose:    IPE lookup management route lookup handle.
 * Parameters:
 *  Input:     in_pkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *                 Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_lookup_manager_lookup_route(ipe_in_pkt_t *in_pkt, lookup_manager_info_t* p_lkp_mgr_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t *parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;

    ipe_lookup_ctl_t ipe_lookup_ctl;

    ds_ipv4_route_key_t ds_ipv4_route_key;
    ds_ipv6_route_key_t ds_ipv6_route_key;

    ds_ipv4_rpf_key_t ds_ipv4_rpf_key;
    ds_ipv6_rpf_key_t ds_ipv6_rpf_key;

    ds_ipv4_nat_key_t ds_ipv4_nat_key;
    ds_ipv6_nat_key_t ds_ipv6_nat_key;

    ds_ipv4_pbr_key_t ds_ipv4_pbr_key;
    ds_ipv6_pbr_key_t ds_ipv6_pbr_key;

    ds_fcoe_route_key_t ds_fcoe_route_key;
    ds_fcoe_rpf_key_t ds_fcoe_rpf_key;
    ds_trill_route_key_t ds_trill_route_key;

    tcam_lkp_outputs_t tcam_lookup_result;
    tcam_lkp_inputs_t tcam_lookup_info;

    lookup_result_t fib_result;
    fib_key_t fib_key;
    uint32 cmd = 0;
    uint16 vrfid = 0;
    uint8 fib_lookup_key_type = 0;
    uint8 route_lookup_da_type = 0;
    uint8 route_lookup_sa_type = 0;
    uint8 trill_da_lookup_ctl1_look_mode = 0;
    push_info_t push_info;

    uint32 ip_da = parser_result->l3_s.ip_da.ipv4.ipda;
    uint32 ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
    uint32 ip_da31_0 = parser_result->l3_s.ip_da.ipv6.ipda_31_0;
    uint32 ip_da63_32 = parser_result->l3_s.ip_da.ipv6.ipda_63_32;
    uint32 ip_da95_64 = parser_result->l3_s.ip_da.ipv6.ipda_95_64;
    uint32 ip_da127_96 = parser_result->l3_s.ip_da.ipv6.ipda_127_96;
    uint32 ip_sa31_0 = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
    uint32 ip_sa63_32 = parser_result->l3_s.ip_sa.ipv6.ipsa_63_32;
    uint32 ip_sa95_64 = parser_result->l3_s.ip_sa.ipv6.ipsa_95_64;
    uint32 ip_sa127_96 = parser_result->l3_s.ip_sa.ipv6.ipsa_127_96;
    uint16 layer4_type = parser_result->layer4_type;
    uint8  frag_info = parser_result->l3_s.frag_info;
    uint8  ip_options = parser_result->l3_s.ip_options;
    uint8  is_udp = parser_result->l4_s.is_udp;
    uint8  is_tcp = parser_result->l4_s.is_tcp;
    uint16 l4_source_port = parser_result->l4_s.l4_src_port.l4_source_port;
    uint16 l4_dest_port = parser_result->l4_s.l4_dst_port.l4_dest_port;
    uint16 ip_header_error = parser_result->l3_s.ip_header_error;
    uint16 l4_info_mapped = parser_result->l4_s.layer4_info_mapped;
    uint8  dscp = (parser_result->l3_s.tos.ip_tos >> 2) & 0x3F;
    uint32 gre_key = parser_result->l4_s.gre_bfd_ptp.gre_key;
    uint32 ipv6_flow_label = parser_result->l3_s.ipv6_flow_label;
    uint8 route_lookup_mode = pkt_info->route_lookup_mode;
    uint8 pbr_label = pkt_info->pbr_label;

    /* ROUTE_LOOKUP_INIT */
    sal_memset(&ipe_lookup_ctl, 0, sizeof(ipe_lookup_ctl));
    cmd = DRV_IOR(IpeLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_lookup_ctl));

    if (!route_lookup_mode && ipe_lookup_ctl.global_vrf_id_lookup_en)
    {
        vrfid = 0;
    }
    else
    {
        vrfid = pkt_info->vrf_id;
    }

    if ((L4_TYPE_GRE == parser_result->layer4_type))
    {
        l4_dest_port = (gre_key >> 16);
        l4_source_port = (gre_key & 0xFFFF);
    }

    if (parser_result1->l3_s.ip_da.trill.trill_inner_vlan_valid && (L3_TYPE_TRILL == parser_result1->layer3_type))
    {
        p_lkp_mgr_info->trill_inner_vlan = parser_result1->l3_s.ip_da.trill.trill_inner_vlan_id;
    }
    else
    {
        p_lkp_mgr_info->trill_inner_vlan = pkt_info->vsi_id & 0xFFF;
    }

    if ((L3_TYPE_TRILL == parser_result1->layer3_type) && (L3_TYPE_FCOE == parser_result->layer3_type))
    {
        if (parser_result->l2_s.svlan_id_valid && ipe_lookup_ctl.fcoe_over_trill_use_inner_vlan)
        {
            pkt_info->vsi_id = parser_result->l2_s.svlan_id;
        }
    }

    /* ROUTE_LOOKUP_DA */
    route_lookup_da_type = (pkt_info->is_ipv4_ucast << 6) | (pkt_info->is_ipv4_mcast << 5)
                           | (pkt_info->is_ipv6_ucast << 4) | (pkt_info->is_ipv6_mcast << 3)
                           | (pkt_info->is_fcoe << 2) | (pkt_info->is_trill_ucast << 1)
                           | pkt_info->is_trill_mcast;

    sal_memset(&fib_key, 0, sizeof(fib_key));
    sal_memset(&fib_result, 0, sizeof(fib_result));
    sal_memset(&push_info, 0, sizeof(push_info_t));
    fib_result.extra = &push_info;

    switch (route_lookup_da_type & 0x7F)
    {
        case 0x40: /* IPV4 UCAST */
            pkt_info->layer3_da_lookup_mode = (ipe_lookup_ctl.ip_da_lookup_ctl0 >> 7) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1)) /* IPV4 UNICAST TCAM LOOKUP */
            {
                sal_memset(&ds_ipv4_route_key, 0, sizeof(ds_ipv4_route_key));
                ds_ipv4_route_key.is_acl_qos_key0 = FALSE;
                ds_ipv4_route_key.is_acl_qos_key1 = FALSE;
                ds_ipv4_route_key.table_id0 = (ipe_lookup_ctl.ip_da_lookup_ctl0 >> 2) & 0x7;
                ds_ipv4_route_key.table_id1 = (ipe_lookup_ctl.ip_da_lookup_ctl0 >> 2) & 0x7;
                ds_ipv4_route_key.sub_table_id0 = ipe_lookup_ctl.ip_da_lookup_ctl0 & 0x3;
                ds_ipv4_route_key.sub_table_id1 = ipe_lookup_ctl.ip_da_lookup_ctl0 & 0x3;
                ds_ipv4_route_key.ip_da = ip_da;
                ds_ipv4_route_key.layer4_type = layer4_type;
                ds_ipv4_route_key.frag_info = frag_info;
                ds_ipv4_route_key.ip_options = ip_options;
                ds_ipv4_route_key.is_udp = is_udp;
                ds_ipv4_route_key.is_tcp = is_tcp;
                ds_ipv4_route_key.route_lookup_mode = route_lookup_mode;
                ds_ipv4_route_key.l4_source_port = l4_source_port;
                ds_ipv4_route_key.l4_dest_port = l4_dest_port;
                ds_ipv4_route_key.l4_info_mapped = l4_info_mapped;
                ds_ipv4_route_key.dscp = dscp;
                ds_ipv4_route_key.pbr_label = pbr_label;
                ds_ipv4_route_key.vrf_id13_10 = (vrfid >> 10) & 0xF;
                ds_ipv4_route_key.vrf_id9_0 = vrfid & 0x3FF;

                if (parser_result1->l4_s.app_data_valid1)
                {
                    ds_ipv4_route_key.vrf_id9_0 = parser_result1->l4_s.app_data>>22;
                    ds_ipv4_route_key.app_data21_18 = (parser_result1->l4_s.app_data>>18)&0xF;
                    ds_ipv4_route_key.dscp = (parser_result1->l4_s.app_data>>12)&0x3F;
                    ds_ipv4_route_key.l4_info_mapped = parser_result1->l4_s.app_data&0xFFF;
                }

                if (ipe_lookup_ctl.ipv4_ucast_route_key_sa_en)
                {
                    ds_ipv4_route_key.ip_sa = ip_sa;
                }
                else if (pkt_info->route_lookup_mode)
                {
                    ds_ipv4_route_key.ip_sa = (l4_dest_port << 16) | (vrfid & 0x3FFF);
                }
                else if (L4_TYPE_GRE == parser_result->layer4_type)
                {
                    ds_ipv4_route_key.ip_sa = gre_key;
                }
                else
                {
                    ds_ipv4_route_key.ip_sa = (l4_dest_port << 16) | l4_source_port;
                }

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV4_UCAST;
                tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.ip_da_lookup_ctl0 >> 5) & 0x3;
                tcam_lookup_info.tcam_key = &ds_ipv4_route_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ipda_tcam_data;
                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->ipda_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0))    /*IPV4 UNICAST LPM LOOKUP */
            {
                fib_key.layer4_type = layer4_type;
                fib_key.id.vrf_id = vrfid & 0x3FFF;
                fib_key.key.ipv4_ucast.ip_da = ip_da;
                fib_key.key.ipv4_ucast.ip_sa = ip_sa;
                fib_key.key.ipv4_ucast.l4_source_port = l4_source_port;
                fib_key.key.ipv4_ucast.l4_dest_port = l4_dest_port;
                /* FIB_KEY_TYPE_IPV4_UCAST or FIB_KEY_TYPE_IPV4_NAT_DA */
                fib_lookup_key_type = pkt_info->l3_if_type;
                push_info.data = pkt_info->ipda_fib_data;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->ipda_fib_result_valid = push_info.valid;
                pkt_info->ipda_fib_default_entry_valid = push_info.default_entry_valid;
            }
            break;
        case 0x20:  /* IPV4 MCAST */
            pkt_info->layer3_da_lookup_mode = (ipe_lookup_ctl.ip_da_lookup_ctl1 >> 7) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1)) /* IPV4 MCAST TCAM LOOKUP */
            {
                sal_memset(&ds_ipv4_route_key, 0, sizeof(ds_ipv4_route_key));
                ds_ipv4_route_key.is_acl_qos_key0 = FALSE;
                ds_ipv4_route_key.is_acl_qos_key1 = FALSE;
                ds_ipv4_route_key.table_id0 = (ipe_lookup_ctl.ip_da_lookup_ctl1 >> 2) & 0x7;
                ds_ipv4_route_key.table_id1 = (ipe_lookup_ctl.ip_da_lookup_ctl1 >> 2) & 0x7;
                ds_ipv4_route_key.sub_table_id0 = ipe_lookup_ctl.ip_da_lookup_ctl1 & 0x3;
                ds_ipv4_route_key.sub_table_id1 = ipe_lookup_ctl.ip_da_lookup_ctl1 & 0x3;
                ds_ipv4_route_key.ip_da = ip_da;
                ds_ipv4_route_key.ip_sa = ip_sa;
                ds_ipv4_route_key.layer4_type = layer4_type;
                ds_ipv4_route_key.frag_info = frag_info;
                ds_ipv4_route_key.ip_options = ip_options;
                ds_ipv4_route_key.is_udp = is_udp;
                ds_ipv4_route_key.is_tcp = is_tcp;
                ds_ipv4_route_key.route_lookup_mode = route_lookup_mode;
                ds_ipv4_route_key.l4_source_port = l4_source_port;
                ds_ipv4_route_key.l4_dest_port = l4_dest_port;
                ds_ipv4_route_key.l4_info_mapped = l4_info_mapped;
                ds_ipv4_route_key.dscp = dscp;
                ds_ipv4_route_key.pbr_label = pbr_label;
                ds_ipv4_route_key.vrf_id13_10 = (vrfid >> 10) & 0xF;
                ds_ipv4_route_key.vrf_id9_0 = vrfid & 0x3FF;
                if (parser_result1->l4_s.app_data_valid1)
                {
                    ds_ipv4_route_key.vrf_id9_0 = parser_result1->l4_s.app_data>>22;
                    ds_ipv4_route_key.app_data21_18 = (parser_result1->l4_s.app_data>>18)&0xF;
                    ds_ipv4_route_key.dscp = (parser_result1->l4_s.app_data>>12)&0x3F;
                    ds_ipv4_route_key.l4_info_mapped = parser_result1->l4_s.app_data&0xFFF;
                }

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV4_MCAST;
                tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.ip_da_lookup_ctl1 >> 5) & 0x3;
                tcam_lookup_info.tcam_key = &ds_ipv4_route_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ipda_tcam_data;
                tcam_lookup_result.ds_ipmc_sa = pkt_info->ipsa_tcam_data;
                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->ipda_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
                pkt_info->ipsa_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0))  /* IPV4 MCAST LPM LOOKUP */
            {
                fib_key.layer4_type = layer4_type;
                fib_key.key.ipv4_mcast.ip_da = ip_da;
                fib_key.key.ipv4_mcast.ip_sa = ip_sa;
                fib_key.key.ipv4_mcast.l4_source_port= l4_source_port;
                fib_key.key.ipv4_mcast.l4_dest_port= l4_dest_port;
                fib_key.id.vrf_id = vrfid & 0x3FFF;
                /* FIB_KEY_TYPE_IPV4_MCAST */
                fib_lookup_key_type = FIB_KEY_TYPE_IPV4_MCAST;
                push_info.data = pkt_info->ipda_fib_data;
                  DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->ipda_fib_result_valid = push_info.valid;
                pkt_info->ipda_fib_default_entry_valid = push_info.default_entry_valid;
            }
            break;
        case 0x10:  /* IPV6 UNICAST */
            pkt_info->layer3_da_lookup_mode = (ipe_lookup_ctl.ip_da_lookup_ctl2 >> 7) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1))  /* IPV6 UNICAST TCAM LOOKUP */
            {
                sal_memset(&ds_ipv6_route_key, 0, sizeof(ds_ipv6_route_key));
                ds_ipv6_route_key.is_acl_qos_key0 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key1 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key2 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key3 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key4 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key5 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key6 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key7 = FALSE;
                ds_ipv6_route_key.table_id0 = (ipe_lookup_ctl.ip_da_lookup_ctl2 >> 2) & 0x7;
                ds_ipv6_route_key.table_id1 = (ipe_lookup_ctl.ip_da_lookup_ctl2 >> 2) & 0x7;
                ds_ipv6_route_key.table_id2 = (ipe_lookup_ctl.ip_da_lookup_ctl2 >> 2) & 0x7;
                ds_ipv6_route_key.table_id3 = (ipe_lookup_ctl.ip_da_lookup_ctl2 >> 2) & 0x7;
                ds_ipv6_route_key.table_id4 = (ipe_lookup_ctl.ip_da_lookup_ctl2 >> 2) & 0x7;
                ds_ipv6_route_key.table_id5 = (ipe_lookup_ctl.ip_da_lookup_ctl2 >> 2) & 0x7;
                ds_ipv6_route_key.table_id6 = (ipe_lookup_ctl.ip_da_lookup_ctl2 >> 2) & 0x7;
                ds_ipv6_route_key.table_id7 = (ipe_lookup_ctl.ip_da_lookup_ctl2 >> 2) & 0x7;
                ds_ipv6_route_key.sub_table_id1 = ipe_lookup_ctl.ip_da_lookup_ctl2 & 0x3;
                ds_ipv6_route_key.sub_table_id3 = ipe_lookup_ctl.ip_da_lookup_ctl2 & 0x3;
                ds_ipv6_route_key.sub_table_id5 = ipe_lookup_ctl.ip_da_lookup_ctl2 & 0x3;
                ds_ipv6_route_key.sub_table_id7 = ipe_lookup_ctl.ip_da_lookup_ctl2 & 0x3;
                ds_ipv6_route_key.ip_da31_0 = ip_da31_0;
                ds_ipv6_route_key.ip_da63_32 = ip_da63_32;
                ds_ipv6_route_key.ip_da71_64 = ip_da95_64 & 0xFF;
                ds_ipv6_route_key.ip_da103_72 = (ip_da127_96 << 24) | (ip_da95_64 >> 8);
                ds_ipv6_route_key.ip_da127_104 = ip_da127_96 >> 8;
                ds_ipv6_route_key.l4_dest_port = l4_dest_port ;
                ds_ipv6_route_key.layer4_type = layer4_type;
                ds_ipv6_route_key.vrf_id3_0 = vrfid & 0xF;
                ds_ipv6_route_key.vrf_id13_4 = (vrfid >> 4) & 0x3FF;
                ds_ipv6_route_key.ip_sa31_0 = ip_sa31_0;
                ds_ipv6_route_key.ip_sa63_32 = ip_sa63_32;
                ds_ipv6_route_key.ip_sa71_64 = ip_sa95_64 & 0xFF;
                ds_ipv6_route_key.ip_sa103_72 = (ip_sa127_96 << 24) | (ip_sa95_64 >> 8);
                ds_ipv6_route_key.ip_sa127_104 = ip_sa127_96 >> 8;
                ds_ipv6_route_key.l4_source_port = l4_source_port ;
                ds_ipv6_route_key.frag_info = frag_info;
                ds_ipv6_route_key.ip_options = ip_options;
                ds_ipv6_route_key.ip_header_error = ip_header_error;
                ds_ipv6_route_key.is_udp = is_udp;
                ds_ipv6_route_key.is_tcp = is_tcp;
                ds_ipv6_route_key.ipv6_flow_label7_0 = parser_result->l3_s.ipv6_flow_label & 0xFF;
                ds_ipv6_route_key.ipv6_flow_label19_8 = (parser_result->l3_s.ipv6_flow_label >> 8) & 0xFFF;
                ds_ipv6_route_key.l4_info_mapped = l4_info_mapped;
                ds_ipv6_route_key.dscp = dscp;
                ds_ipv6_route_key.svlan_id = parser_result->l2_s.svlan_id;
                ds_ipv6_route_key.layer3_type = parser_result->layer3_type;
                ds_ipv6_route_key.mac_sa31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                                           parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
                ds_ipv6_route_key.mac_sa47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
                ds_ipv6_route_key.ether_type7_0 = parser_result->l2_s.layer2_header_protocol & 0xFF;
                ds_ipv6_route_key.ether_type15_8 = (parser_result->l2_s.layer2_header_protocol >> 8) & 0xFF;
                ds_ipv6_route_key.ctag_cfi = parser_result->l2_s.ctag_cfi;
                ds_ipv6_route_key.ctag_cos = parser_result->l2_s.ctag_cos;
                ds_ipv6_route_key.mac_da31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                                           parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
                ds_ipv6_route_key.mac_da47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);
                ds_ipv6_route_key.layer2_type = parser_result->layer2_type;
                ds_ipv6_route_key.stag_cfi = parser_result->l2_s.stag_cfi;
                ds_ipv6_route_key.stag_cos = parser_result->l2_s.stag_cos;
                ds_ipv6_route_key.cvlan_id = parser_result->l2_s.cvlan_id;
                ds_ipv6_route_key.pbr_label = pkt_info->pbr_label;
                ds_ipv6_route_key.vlan_ptr = pkt_info->vlan_ptr;
                ds_ipv6_route_key.app_data = parser_result1->l4_s.app_data;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV6_UCAST;
                tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.ip_da_lookup_ctl2 >> 5) & 0x3;
                tcam_lookup_info.tcam_key = &ds_ipv6_route_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ipda_tcam_data;
                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->ipda_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0))  /* IPV6 UNICAST LPM LOOKUP */
            {
                fib_key.layer4_type = layer4_type;
                fib_key.key.ipv6_ucast.ip_da31_0 = ip_da31_0;
                fib_key.key.ipv6_ucast.ip_da63_32 = ip_da63_32;
                fib_key.key.ipv6_ucast.ip_da95_64 = ip_da95_64;
                fib_key.key.ipv6_ucast.ip_da127_96 = ip_da127_96;
                fib_key.key.ipv6_ucast.l4_dest_port = l4_dest_port;
                fib_key.id.vrf_id = vrfid & 0x3FFF;
                /* FIB_KEY_TYPE_IPV6_UCAST or FIB_KEY_TYPE_IPV6_NAT_DA */
                fib_lookup_key_type = ((2 << 1) | pkt_info->l3_if_type) & 0x1F;
                push_info.data = pkt_info->ipda_fib_data;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->ipda_fib_result_valid = push_info.valid;
                pkt_info->ipda_fib_default_entry_valid = push_info.default_entry_valid;
            }
            break;
        case 0x8:   /* IPV6 MCAST */
            sal_memset(&ds_ipv6_route_key, 0, sizeof(ds_ipv6_route_key));
            pkt_info->layer3_da_lookup_mode = (ipe_lookup_ctl.ip_da_lookup_ctl3>> 7) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1))  /* IPV6 MULTICAST TCAM LOOKUP */
            {
                ds_ipv6_route_key.is_acl_qos_key0 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key1 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key2 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key3 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key4 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key5 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key6 = FALSE;
                ds_ipv6_route_key.is_acl_qos_key7 = FALSE;
                ds_ipv6_route_key.table_id0 = (ipe_lookup_ctl.ip_da_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_route_key.table_id1 = (ipe_lookup_ctl.ip_da_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_route_key.table_id2 = (ipe_lookup_ctl.ip_da_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_route_key.table_id3 = (ipe_lookup_ctl.ip_da_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_route_key.table_id4 = (ipe_lookup_ctl.ip_da_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_route_key.table_id5 = (ipe_lookup_ctl.ip_da_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_route_key.table_id6 = (ipe_lookup_ctl.ip_da_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_route_key.table_id7 = (ipe_lookup_ctl.ip_da_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_route_key.sub_table_id1 = ipe_lookup_ctl.ip_da_lookup_ctl3  & 0x3;
                ds_ipv6_route_key.sub_table_id3 = ipe_lookup_ctl.ip_da_lookup_ctl3  & 0x3;
                ds_ipv6_route_key.sub_table_id5 = ipe_lookup_ctl.ip_da_lookup_ctl3  & 0x3;
                ds_ipv6_route_key.sub_table_id7 = ipe_lookup_ctl.ip_da_lookup_ctl3  & 0x3;
                ds_ipv6_route_key.ip_da31_0 = ip_da31_0;
                ds_ipv6_route_key.ip_da63_32 = ip_da63_32;
                ds_ipv6_route_key.ip_da71_64 = ip_da95_64 & 0xFF;
                ds_ipv6_route_key.ip_da103_72 = ((ip_da127_96 & 0xFF) << 24) | (ip_da95_64 >> 8);
                ds_ipv6_route_key.ip_da127_104 = ip_da127_96 >> 8;
                ds_ipv6_route_key.l4_dest_port = l4_dest_port;
                ds_ipv6_route_key.layer4_type = layer4_type;
                ds_ipv6_route_key.vrf_id3_0 = vrfid & 0xF;
                ds_ipv6_route_key.vrf_id13_4 = (vrfid>>4) & 0x3FF;
                ds_ipv6_route_key.ip_sa31_0 = ip_sa31_0;
                ds_ipv6_route_key.ip_sa63_32 = ip_sa63_32;
                ds_ipv6_route_key.ip_sa71_64 = ip_sa95_64 & 0xFF;
                ds_ipv6_route_key.ip_sa103_72 = (ip_sa127_96 << 24) | (ip_sa95_64 >> 8);
                ds_ipv6_route_key.ip_sa127_104 = ip_sa127_96 >> 8;
                ds_ipv6_route_key.l4_source_port = l4_source_port;
                ds_ipv6_route_key.frag_info = frag_info;
                ds_ipv6_route_key.ip_options = ip_options;
                ds_ipv6_route_key.is_udp = is_udp;
                ds_ipv6_route_key.is_tcp = is_tcp;
                ds_ipv6_route_key.l4_info_mapped = l4_info_mapped;
                ds_ipv6_route_key.dscp = dscp;
                ds_ipv6_route_key.ip_header_error = ip_header_error;
                ds_ipv6_route_key.ipv6_flow_label7_0 = parser_result->l3_s.ipv6_flow_label & 0xFF;
                ds_ipv6_route_key.ipv6_flow_label19_8 = (parser_result->l3_s.ipv6_flow_label >> 8) & 0xFFF;
                ds_ipv6_route_key.svlan_id = parser_result->l2_s.svlan_id;
                ds_ipv6_route_key.layer3_type = parser_result->layer3_type;
                ds_ipv6_route_key.mac_sa31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                                           parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
                ds_ipv6_route_key.mac_sa47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
                ds_ipv6_route_key.ether_type7_0 = parser_result->l2_s.layer2_header_protocol & 0xFF;
                ds_ipv6_route_key.ether_type15_8 = (parser_result->l2_s.layer2_header_protocol >> 8) & 0xFF;
                ds_ipv6_route_key.ctag_cfi = parser_result->l2_s.ctag_cfi;
                ds_ipv6_route_key.ctag_cos = parser_result->l2_s.ctag_cos;
                ds_ipv6_route_key.mac_da31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                                           parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
                ds_ipv6_route_key.mac_da47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);
                ds_ipv6_route_key.layer2_type = parser_result->layer2_type;
                ds_ipv6_route_key.stag_cfi = parser_result->l2_s.stag_cfi;
                ds_ipv6_route_key.stag_cos = parser_result->l2_s.stag_cos;
                ds_ipv6_route_key.cvlan_id = parser_result->l2_s.cvlan_id;
                ds_ipv6_route_key.layer4_type = parser_result->layer4_type;
                ds_ipv6_route_key.pbr_label = pkt_info->pbr_label;
                ds_ipv6_route_key.vlan_ptr = pkt_info->vlan_ptr;
                ds_ipv6_route_key.app_data = parser_result1->l4_s.app_data;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV6_MCAST;
                tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.ip_da_lookup_ctl3 >> 5) & 0x3;
                tcam_lookup_info.tcam_key = &ds_ipv6_route_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ipda_tcam_data;
                tcam_lookup_result.ds_ipmc_sa = pkt_info->ipsa_tcam_data;
                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->ipda_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
                pkt_info->ipsa_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0))  /* IPV6 MULTICASE HASH LOOKUP */
            {
                fib_key.key.ipv6_mcast.ip_da31_0 = ip_da31_0;
                fib_key.key.ipv6_mcast.ip_da63_32 = ip_da63_32;
                fib_key.key.ipv6_mcast.ip_da95_64 = ip_da95_64;
                fib_key.key.ipv6_mcast.ip_da127_96 = ip_da127_96;

                fib_key.key.ipv6_mcast.ip_sa31_0 = ip_sa31_0;
                fib_key.key.ipv6_mcast.ip_sa63_32 = ip_sa63_32;
                fib_key.key.ipv6_mcast.ip_sa95_64 = ip_sa95_64;
                fib_key.key.ipv6_mcast.ip_sa127_96 = ip_sa127_96;

                fib_key.id.vrf_id = vrfid & 0x3FFF;

                fib_lookup_key_type = FIB_KEY_TYPE_IPV6_MCAST;  /* !PacketInfo.l3IfType ??? */
                push_info.data = pkt_info->ipda_fib_data;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->ipda_fib_result_valid = push_info.valid;
                pkt_info->ipda_fib_default_entry_valid = push_info.default_entry_valid;
            }
            break;
        case 0x4:   /* FCOE */
            pkt_info->layer3_da_lookup_mode = (ipe_lookup_ctl.fcoe_lookup_ctl0 >> 5) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1))
            {
                sal_memset(&ds_fcoe_route_key, 0, sizeof(ds_fcoe_route_key_t));
                ds_fcoe_route_key.is_acl_qos_key = FALSE;
                ds_fcoe_route_key.table_id = (ipe_lookup_ctl.fcoe_lookup_ctl0 >> 2) & 0x7;
                ds_fcoe_route_key.sub_table_id = ipe_lookup_ctl.fcoe_lookup_ctl0 & 0x3;
                ds_fcoe_route_key.vsi_id13_8 = (pkt_info->vsi_id >> 8) & 0x3F;
                ds_fcoe_route_key.vsi_id7_0 = pkt_info->vsi_id & 0xFF;
                ds_fcoe_route_key.fcoe_did = parser_result->l3_s.ip_da.fcoe.fcoe_did;
                ds_fcoe_route_key.fcoe_sid = parser_result->l3_s.ip_sa.fcoe.fcoe_sid;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_FCOE_DA;
                tcam_lookup_info.tcam_key_size = 0;  /* 80 bits */
                tcam_lookup_info.tcam_key = &ds_fcoe_route_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->fcoe_da_data_tcam;
                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->fcoe_da_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0))
            {
                fib_key.id.vsi_id = pkt_info->vsi_id;
                fib_key.key.fcoe.fcoe_did = parser_result->l3_s.ip_da.fcoe.fcoe_did;
                fib_lookup_key_type = FIB_KEY_TYPE_FCOE;
                push_info.data = pkt_info->fcoe_da_data_fib;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->fcoe_da_fib_default_entry_valid = push_info.default_entry_valid;
                pkt_info->fcoe_da_fib_result_valid = push_info.valid;
            }
            break;
        case 0x2:   /* TRILL UNICAST */
            pkt_info->layer3_da_lookup_mode = (ipe_lookup_ctl.trill_da_lookup_ctl0 >> 5) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1))
            {
                sal_memset(&ds_trill_route_key, 0, sizeof(ds_trill_route_key_t));
                ds_trill_route_key.is_acl_qos_key = FALSE;
                ds_trill_route_key.table_id = (ipe_lookup_ctl.trill_da_lookup_ctl0 >> 2) & 0x7;
                ds_trill_route_key.sub_table_id = ipe_lookup_ctl.trill_da_lookup_ctl0 & 0x3;
                ds_trill_route_key.egress_nickname = parser_result->l3_s.ip_da.trill.egress_nick_name;
                ds_trill_route_key.ingress_nickname = parser_result->l3_s.ip_sa.trill.ingress_nick_name;
                ds_trill_route_key.inner_vlan_id = p_lkp_mgr_info->trill_inner_vlan & 0xFFF;
                ds_trill_route_key.outer_vlan_id = parser_result->l2_s.svlan_id;
                ds_trill_route_key.ip_options = parser_result->l3_s.ip_options;
                ds_trill_route_key.ttl = parser_result->l3_s.ttl;
                ds_trill_route_key.trill_multicast = parser_result->l3_s.ip_da.trill.trill_multicast;
                ds_trill_route_key.trill_version = parser_result->l3_s.ip_da.trill.trill_version;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_TRILl_UCAST_DA;
                tcam_lookup_info.tcam_key_size = 0; /* 80 bits */
                tcam_lookup_info.tcam_key = &ds_trill_route_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->trill_da_data_tcam;
                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->trill_da_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0))
            {
                fib_lookup_key_type = FIB_KEY_TYPE_TRILL_UCAST;
                fib_key.key.trill_ucast.egress_nickname = parser_result->l3_s.ip_da.trill.egress_nick_name;
                push_info.data = pkt_info->trill_da_data_fib;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->trill_da_fib_default_entry_valid = push_info.default_entry_valid;
                pkt_info->trill_da_fib_result_valid = push_info.valid;
            }
            break;
        case 0x1:   /* TRILL MCAST */
            pkt_info->layer3_da_lookup_mode = (ipe_lookup_ctl.trill_da_lookup_ctl1 >> 5) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1))
            {
                sal_memset(&ds_trill_route_key, 0, sizeof(ds_trill_route_key_t));
                ds_trill_route_key.is_acl_qos_key = FALSE;
                ds_trill_route_key.table_id = (ipe_lookup_ctl.trill_da_lookup_ctl1 >> 2) & 0x7;
                ds_trill_route_key.sub_table_id = ipe_lookup_ctl.trill_da_lookup_ctl1 & 0x3;
                ds_trill_route_key.egress_nickname = parser_result->l3_s.ip_da.trill.egress_nick_name;
                ds_trill_route_key.ingress_nickname = parser_result->l3_s.ip_sa.trill.ingress_nick_name;
                ds_trill_route_key.ip_options = parser_result->l3_s.ip_options;
                ds_trill_route_key.ttl = parser_result->l3_s.ttl;
                ds_trill_route_key.trill_multicast = parser_result->l3_s.ip_da.trill.trill_multicast;
                ds_trill_route_key.trill_version = parser_result->l3_s.ip_da.trill.trill_version;
                ds_trill_route_key.inner_vlan_id = p_lkp_mgr_info->trill_inner_vlan & 0xFFF;
                ds_trill_route_key.outer_vlan_id = parser_result->l2_s.svlan_id;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_TRILl_MCAST_DA;
                tcam_lookup_info.tcam_key_size = 0; /* 80 bits */
                tcam_lookup_info.tcam_key = &ds_trill_route_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->trill_da_data_tcam;
                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->trill_da_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }
            if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0))
            {
                fib_lookup_key_type = FIB_KEY_TYPE_TRILL_MCAST;
                fib_key.key.trill_ucast.egress_nickname = parser_result->l3_s.ip_da.trill.egress_nick_name;
                push_info.data = pkt_info->trill_da_data_fib;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));

                pkt_info->trill_da_fib_default_entry_valid = push_info.default_entry_valid;
                pkt_info->trill_da_fib_result_valid = push_info.valid;
            }
            break;
        default:    /* no lookup */
            break;
    }

    /* ROUTE_LOOKUP_SA */
    route_lookup_sa_type = (pkt_info->is_trill_mcast << 7) | (pkt_info->is_ipv4_ucast_rpf << 6)
                           | (pkt_info->is_ipv6_ucast_rpf << 5) | (pkt_info->is_ipv4_ucast_nat << 4)
                           | (pkt_info->is_ipv6_ucast_nat << 3) | (pkt_info->is_ipv4_pbr << 2)
                           | (pkt_info->is_ipv6_pbr << 1) | pkt_info->is_fcoe_rpf;

    sal_memset(&fib_key, 0, sizeof(fib_key_t));
    sal_memset(&fib_result, 0, sizeof(lookup_result_t));
    sal_memset(&push_info, 0, sizeof(push_info_t));
    fib_result.extra = &push_info;

    switch(route_lookup_sa_type)
    {
        case 0x80:  /* TRILL Mcast,only Mcast hash lookup need two lookup, TCAM not need. */
             trill_da_lookup_ctl1_look_mode = (ipe_lookup_ctl.trill_da_lookup_ctl1 >> 5) & 0x3;
            if (IS_BIT_SET(trill_da_lookup_ctl1_look_mode, 0))
            {
                fib_key.key.trill_mcast_vlan.egress_nickname = parser_result->l3_s.ip_da.trill.egress_nick_name;
                fib_key.key.trill_mcast_vlan.vlan_id = p_lkp_mgr_info->trill_inner_vlan;

                fib_lookup_key_type = FIB_KEY_TYPE_TRILL_MCAST_VLAN;
                push_info.data = pkt_info->trill_vlan_da_data_fib;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->trill_vlan_da_fib_result_valid = push_info.valid;
            }
            break;
        case 0x40:  /* IPv4 RPF */
            pkt_info->layer3_sa_lookup_mode = (ipe_lookup_ctl.ip_sa_lookup_ctl0 >> 7) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 1))
            {
                /* IPv4 RPF TCAM lookup */
                sal_memset(&ds_ipv4_rpf_key, 0, sizeof(ds_ipv4_rpf_key_t));
                ds_ipv4_rpf_key.is_acl_qos_key0 = FALSE;
                ds_ipv4_rpf_key.is_acl_qos_key1 = FALSE;
                ds_ipv4_rpf_key.table_id0 = (ipe_lookup_ctl.ip_sa_lookup_ctl0 >> 2) & 0x7;
                ds_ipv4_rpf_key.table_id1 = (ipe_lookup_ctl.ip_sa_lookup_ctl0 >> 2) & 0x7;
                ds_ipv4_rpf_key.sub_table_id0 = ipe_lookup_ctl.ip_sa_lookup_ctl0 & 0x3;
                ds_ipv4_rpf_key.sub_table_id1 = ipe_lookup_ctl.ip_sa_lookup_ctl0 & 0x3;
                ds_ipv4_rpf_key.ip_sa = ip_sa;
                ds_ipv4_rpf_key.layer4_type = layer4_type;
                ds_ipv4_rpf_key.frag_info = frag_info;
                ds_ipv4_rpf_key.ip_options = ip_options;
                ds_ipv4_rpf_key.is_udp = is_udp;
                ds_ipv4_rpf_key.is_tcp = is_tcp;
                ds_ipv4_rpf_key.route_lookup_mode = route_lookup_mode;
                ds_ipv4_rpf_key.l4_source_port = l4_source_port;
                ds_ipv4_rpf_key.l4_dest_port = l4_dest_port;
                ds_ipv4_rpf_key.l4_info_mapped = l4_info_mapped;
                ds_ipv4_rpf_key.dscp = dscp;
                ds_ipv4_rpf_key.pbr_label = pbr_label;
                ds_ipv4_rpf_key.vrf_id11_0 = vrfid & 0xFFF;
                ds_ipv4_rpf_key.vrf_id13_12 = (vrfid >> 12) & 0x3;

                if (ipe_lookup_ctl.ipv4_ucast_rpf_key_da_en)
                {
                    ds_ipv4_rpf_key.ip_da = ip_da;
                }
                else if (route_lookup_mode)
                {
                    ds_ipv4_rpf_key.ip_da = (l4_source_port<<16) | (vrfid & 0x3FFF);
                }
                else if (L4_TYPE_GRE == layer4_type)
                {
                    ds_ipv4_rpf_key.ip_da = gre_key;
                }
                else
                {
                    ds_ipv4_rpf_key.ip_da = (l4_dest_port << 16) | l4_source_port;
                }

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV4_RPF;
                tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.ip_sa_lookup_ctl0 >> 5) & 0x3;
                tcam_lookup_info.tcam_key = &ds_ipv4_rpf_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ipsa_tcam_data;

                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->ipsa_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0))
            {
                /* IPv4 RPF LPM lookup */
                fib_key.layer4_type = layer4_type;
                fib_key.id.vrf_id = vrfid & 0x3FFF;
                fib_key.key.ipv4_rpf.ip_sa = ip_sa;
                fib_key.key.ipv4_rpf.ip_da = ip_da;
                fib_key.key.ipv4_rpf.l4_source_port= l4_source_port;
                fib_key.key.ipv4_rpf.l4_dest_port= l4_dest_port;
                fib_lookup_key_type = FIB_KEY_TYPE_IPV4_RPF;
                push_info.data = pkt_info->ipsa_fib_data;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->ipsa_fib_result_valid = push_info.valid;
                pkt_info->ipsa_fib_default_entry_valid = push_info.default_entry_valid;
            }
            break;
        case 0x20:  /* IPv6 RPF */
            pkt_info->layer3_sa_lookup_mode = (ipe_lookup_ctl.ip_sa_lookup_ctl1 >> 7) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 1))
            {
                /* IPv6 RPF TCAM lookup */
                sal_memset(&ds_ipv6_rpf_key, 0, sizeof(ds_ipv6_rpf_key));
                ds_ipv6_rpf_key.is_acl_qos_key0 = FALSE;
                ds_ipv6_rpf_key.is_acl_qos_key1 = FALSE;
                ds_ipv6_rpf_key.is_acl_qos_key2 = FALSE;
                ds_ipv6_rpf_key.is_acl_qos_key3 = FALSE;
                ds_ipv6_rpf_key.is_acl_qos_key4 = FALSE;
                ds_ipv6_rpf_key.is_acl_qos_key5 = FALSE;
                ds_ipv6_rpf_key.is_acl_qos_key6 = FALSE;
                ds_ipv6_rpf_key.is_acl_qos_key7 = FALSE;
                ds_ipv6_rpf_key.table_id0 = (ipe_lookup_ctl.ip_sa_lookup_ctl1 >> 2) & 0x7;
                ds_ipv6_rpf_key.table_id1 = (ipe_lookup_ctl.ip_sa_lookup_ctl1 >> 2) & 0x7;
                ds_ipv6_rpf_key.table_id2 = (ipe_lookup_ctl.ip_sa_lookup_ctl1 >> 2) & 0x7;
                ds_ipv6_rpf_key.table_id3 = (ipe_lookup_ctl.ip_sa_lookup_ctl1 >> 2) & 0x7;
                ds_ipv6_rpf_key.table_id4 = (ipe_lookup_ctl.ip_sa_lookup_ctl1 >> 2) & 0x7;
                ds_ipv6_rpf_key.table_id5 = (ipe_lookup_ctl.ip_sa_lookup_ctl1 >> 2) & 0x7;
                ds_ipv6_rpf_key.table_id6 = (ipe_lookup_ctl.ip_sa_lookup_ctl1 >> 2) & 0x7;
                ds_ipv6_rpf_key.table_id7 = (ipe_lookup_ctl.ip_sa_lookup_ctl1 >> 2) & 0x7;
                ds_ipv6_rpf_key.sub_table_id1 = ipe_lookup_ctl.ip_sa_lookup_ctl1 & 0x3;
                ds_ipv6_rpf_key.sub_table_id3 = ipe_lookup_ctl.ip_sa_lookup_ctl1 & 0x3;
                ds_ipv6_rpf_key.sub_table_id5 = ipe_lookup_ctl.ip_sa_lookup_ctl1 & 0x3;
                ds_ipv6_rpf_key.sub_table_id7 = ipe_lookup_ctl.ip_sa_lookup_ctl1 & 0x3;
                ds_ipv6_rpf_key.ip_da31_0 = ip_da31_0;
                ds_ipv6_rpf_key.ip_da63_32 = ip_da63_32;
                ds_ipv6_rpf_key.ip_da71_64 = ip_da95_64 & 0xFF;
                ds_ipv6_rpf_key.ip_da103_72 = ((ip_da127_96 & 0xFF) << 24) | (ip_da95_64 >> 8);
                ds_ipv6_rpf_key.ip_da127_104 = ip_da127_96 >> 8;
                ds_ipv6_rpf_key.l4_dest_port = l4_dest_port;
                ds_ipv6_rpf_key.layer4_type = layer4_type;
                ds_ipv6_rpf_key.vrf_id3_0 = vrfid & 0xF;
                ds_ipv6_rpf_key.vrf_id13_4 = (vrfid >> 4) & 0x3FF;
                ds_ipv6_rpf_key.ip_sa31_0 = ip_sa31_0;
                ds_ipv6_rpf_key.ip_sa63_32 = ip_sa63_32;
                ds_ipv6_rpf_key.ip_sa71_64 = ip_sa95_64 & 0xFF;
                ds_ipv6_rpf_key.ip_sa103_72 = (ip_sa127_96 << 24) | (ip_sa95_64 >> 8);
                ds_ipv6_rpf_key.ip_sa127_104 = ip_sa127_96 >> 8;
                ds_ipv6_rpf_key.l4_source_port = l4_source_port;
                ds_ipv6_rpf_key.vlan_ptr = pkt_info->vlan_ptr;
                ds_ipv6_rpf_key.pbr_label = pkt_info->pbr_label;
                ds_ipv6_rpf_key.ip_header_error = pkt_info->ip_header_error;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV6_RPF;
                tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.ip_sa_lookup_ctl1 >> 5) & 0x3;
                tcam_lookup_info.tcam_key = &ds_ipv6_rpf_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ipsa_tcam_data;

                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->ipsa_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0))
            {
                /* IPv6 RPF LPM lookup */
                fib_key.layer4_type = layer4_type;
                fib_key.id.vrf_id = vrfid & 0x3FFF;
                fib_key.key.ipv6_rpf.ip_sa31_0 = ip_sa31_0;
                fib_key.key.ipv6_rpf.ip_sa63_32 = ip_sa63_32;
                fib_key.key.ipv6_rpf.ip_sa95_64 = ip_sa95_64;
                fib_key.key.ipv6_rpf.ip_sa127_96 = ip_sa127_96;
                fib_key.key.ipv6_rpf.l4_source_port = l4_source_port;
                fib_lookup_key_type = FIB_KEY_TYPE_IPV6_RPF;
                push_info.data = pkt_info->ipsa_fib_data;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->ipsa_fib_result_valid = push_info.valid;
                pkt_info->ipsa_fib_default_entry_valid = push_info.default_entry_valid;
            }
            break;
        case 0x10:
            pkt_info->layer3_sa_lookup_mode = (ipe_lookup_ctl.ip_sa_lookup_ctl2 >> 7) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 1))
            {
                sal_memset(&ds_ipv4_nat_key, 0, sizeof(ds_ipv4_nat_key));
                ds_ipv4_nat_key.is_acl_qos_key0 = FALSE;
                ds_ipv4_nat_key.is_acl_qos_key1 = FALSE;
                ds_ipv4_nat_key.table_id0 = (ipe_lookup_ctl.ip_sa_lookup_ctl2 >> 2) & 0x7;
                ds_ipv4_nat_key.table_id1 = (ipe_lookup_ctl.ip_sa_lookup_ctl2 >> 2) & 0x7;
                ds_ipv4_nat_key.sub_table_id0 = ipe_lookup_ctl.ip_sa_lookup_ctl2 & 0x3;
                ds_ipv4_nat_key.sub_table_id1 = ipe_lookup_ctl.ip_sa_lookup_ctl2 & 0x3;
                ds_ipv4_nat_key.ip_sa = ip_sa;
                ds_ipv4_nat_key.layer4_type = layer4_type;
                ds_ipv4_nat_key.frag_info = frag_info;
                ds_ipv4_nat_key.ip_options = ip_options;
                ds_ipv4_nat_key.is_udp = is_udp;
                ds_ipv4_nat_key.is_tcp = is_tcp;
                ds_ipv4_nat_key.route_lookup_mode = route_lookup_mode;
                ds_ipv4_nat_key.l4_source_port = l4_source_port;
                ds_ipv4_nat_key.l4_dest_port = l4_dest_port;
                ds_ipv4_nat_key.l4_info_mapped = l4_info_mapped;
                ds_ipv4_nat_key.dscp = dscp;
                ds_ipv4_nat_key.pbr_label = pbr_label;
                ds_ipv4_nat_key.vrf_id11_0 = vrfid & 0xFFF;
                ds_ipv4_nat_key.vrf_id13_12 = (vrfid >> 12) & 0x3;

                if (ipe_lookup_ctl.ipv4_ucast_rpf_key_da_en)
                {
                    ds_ipv4_nat_key.ip_da = ip_da;
                }
                else if (route_lookup_mode)
                {
                    ds_ipv4_nat_key.ip_da = (l4_source_port<<16) | (vrfid & 0x3FFF);
                }
                else if (L4_TYPE_GRE == layer4_type)
                {
                    ds_ipv4_nat_key.ip_da = gre_key;
                }
                else
                {
                    ds_ipv4_nat_key.ip_da = (l4_dest_port << 16) | l4_source_port;
                }

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV4_NAT;
                tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.ip_sa_lookup_ctl2 >> 5) & 0x3;
                tcam_lookup_info.tcam_key = &ds_ipv4_nat_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ipsa_tcam_data;

                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->ipsa_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0))
            {
                /* IPv6 RPF LPM lookup */
                fib_key.layer4_type = layer4_type;
                fib_key.id.vrf_id = vrfid & 0x3FFF;
                fib_key.key.ipv4_nat_sa_port.ip_sa = ip_sa;
                fib_key.key.ipv4_nat_sa_port.l4_source_port = l4_source_port;
                fib_key.key.ipv4_nat_sa_port.l4_dest_port = l4_dest_port;
                fib_key.key.ipv4_nat_sa_port.ip_da = ip_da;
                fib_lookup_key_type = FIB_KEY_TYPE_IPV4_NAT_SA;
                push_info.data = pkt_info->ipsa_fib_data;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->ipsa_fib_result_valid = push_info.valid;
                pkt_info->ipsa_fib_default_entry_valid = push_info.default_entry_valid;
            }
            break;
        case 0x8:
            pkt_info->layer3_sa_lookup_mode = (ipe_lookup_ctl.ip_sa_lookup_ctl3 >> 7) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 1))
            {
                sal_memset(&ds_ipv6_nat_key, 0, sizeof(ds_ipv6_nat_key));
                ds_ipv6_nat_key.is_acl_qos_key0 = FALSE;
                ds_ipv6_nat_key.is_acl_qos_key1 = FALSE;
                ds_ipv6_nat_key.is_acl_qos_key2 = FALSE;
                ds_ipv6_nat_key.is_acl_qos_key3 = FALSE;
                ds_ipv6_nat_key.is_acl_qos_key4 = FALSE;
                ds_ipv6_nat_key.is_acl_qos_key5 = FALSE;
                ds_ipv6_nat_key.is_acl_qos_key6 = FALSE;
                ds_ipv6_nat_key.is_acl_qos_key7 = FALSE;
                ds_ipv6_nat_key.table_id0 = (ipe_lookup_ctl.ip_sa_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_nat_key.table_id1 = (ipe_lookup_ctl.ip_sa_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_nat_key.table_id2 = (ipe_lookup_ctl.ip_sa_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_nat_key.table_id3 = (ipe_lookup_ctl.ip_sa_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_nat_key.table_id4 = (ipe_lookup_ctl.ip_sa_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_nat_key.table_id5 = (ipe_lookup_ctl.ip_sa_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_nat_key.table_id6 = (ipe_lookup_ctl.ip_sa_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_nat_key.table_id7 = (ipe_lookup_ctl.ip_sa_lookup_ctl3 >> 2) & 0x7;
                ds_ipv6_nat_key.sub_table_id1 = ipe_lookup_ctl.ip_sa_lookup_ctl3 & 0x3;
                ds_ipv6_nat_key.sub_table_id3 = ipe_lookup_ctl.ip_sa_lookup_ctl3 & 0x3;
                ds_ipv6_nat_key.sub_table_id5 = ipe_lookup_ctl.ip_sa_lookup_ctl3 & 0x3;
                ds_ipv6_nat_key.sub_table_id7 = ipe_lookup_ctl.ip_sa_lookup_ctl3 & 0x3;
                ds_ipv6_nat_key.ip_da31_0 = ip_da31_0;
                ds_ipv6_nat_key.ip_da63_32 = ip_da63_32;
                ds_ipv6_nat_key.ip_da71_64 = ip_da95_64 & 0xFF;
                ds_ipv6_nat_key.ip_da103_72 = ((ip_da127_96 & 0xFF) << 24) | (ip_da95_64 >> 8);
                ds_ipv6_nat_key.ip_da127_104 = ip_da127_96 >> 8;
                ds_ipv6_nat_key.l4_dest_port = l4_dest_port;
                ds_ipv6_nat_key.layer4_type = layer4_type;
                ds_ipv6_nat_key.vrf_id3_0 = vrfid & 0xF;
                ds_ipv6_nat_key.vrf_id13_4 = (vrfid>>4) & 0x3FF;
                ds_ipv6_nat_key.ip_sa31_0 = ip_sa31_0;
                ds_ipv6_nat_key.ip_sa63_32 = ip_sa63_32;
                ds_ipv6_nat_key.ip_sa71_64 = ip_sa95_64 & 0xFF;
                ds_ipv6_nat_key.ip_sa103_72 = (ip_sa127_96 << 24) | (ip_sa95_64 >> 8);
                ds_ipv6_nat_key.ip_sa127_104 = ip_sa127_96 >> 8;
                ds_ipv6_nat_key.l4_source_port = l4_source_port;
                ds_ipv6_nat_key.frag_info = frag_info;
                ds_ipv6_nat_key.ip_options = ip_options;
                ds_ipv6_nat_key.ip_header_error = ip_header_error;
                ds_ipv6_nat_key.is_udp = is_udp;
                ds_ipv6_nat_key.is_tcp = is_tcp;
                ds_ipv6_nat_key.ipv6_flow_label7_0 = ipv6_flow_label & 0xFF;
                ds_ipv6_nat_key.ipv6_flow_label19_8 = (ipv6_flow_label >> 8) & 0xFFF;
                ds_ipv6_nat_key.dscp = dscp;
                ds_ipv6_nat_key.svlan_id = parser_result->l2_s.svlan_id;
                ds_ipv6_nat_key.layer3_type = parser_result->layer3_type;
                ds_ipv6_nat_key.mac_sa31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                             parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
                ds_ipv6_nat_key.mac_sa47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
                ds_ipv6_nat_key.ether_type7_0 = parser_result->l2_s.layer2_header_protocol & 0xFF;
                ds_ipv6_nat_key.ether_type15_8 = (parser_result->l2_s.layer2_header_protocol >> 8) & 0xFF;
                ds_ipv6_nat_key.ctag_cfi = parser_result->l2_s.ctag_cfi;
                ds_ipv6_nat_key.ctag_cos = parser_result->l2_s.ctag_cos;
                ds_ipv6_nat_key.mac_da31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                                           parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
                ds_ipv6_nat_key.mac_da47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);
                ds_ipv6_nat_key.layer2_type = parser_result->layer2_type;
                ds_ipv6_nat_key.stag_cfi = parser_result->l2_s.stag_cfi;
                ds_ipv6_nat_key.stag_cos = parser_result->l2_s.stag_cos;
                ds_ipv6_nat_key.cvlan_id = parser_result->l2_s.cvlan_id;

                ds_ipv6_nat_key.vlan_ptr = pkt_info->vlan_ptr;
                ds_ipv6_nat_key.pbr_label = pkt_info->pbr_label;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV6_NAT;
                tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.ip_sa_lookup_ctl3 >> 5) & 0x3;
                tcam_lookup_info.tcam_key = &ds_ipv6_nat_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ipsa_tcam_data;

                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->ipsa_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0))
            {
                /* IPv6 RPF LPM lookup */
                fib_key.layer4_type = layer4_type;
                fib_key.id.vrf_id = vrfid & 0x3FFF;
                fib_key.key.ipv6_nat_sa_port.ip_sa31_0 = ip_sa31_0;
                fib_key.key.ipv6_nat_sa_port.ip_sa63_32 = ip_sa63_32;
                fib_key.key.ipv6_nat_sa_port.ip_sa95_64 = ip_sa95_64;
                fib_key.key.ipv6_nat_sa_port.ip_sa127_96 = ip_sa127_96;
                fib_key.key.ipv6_nat_sa_port.l4_source_port = l4_source_port;
                fib_lookup_key_type = FIB_KEY_TYPE_IPV6_NAT_SA;
                push_info.data = pkt_info->ipsa_fib_data;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->ipsa_fib_result_valid = push_info.valid;
                pkt_info->ipsa_fib_default_entry_valid = push_info.default_entry_valid;
            }
            break;
        case 0x4:
            sal_memset(&ds_ipv4_pbr_key, 0, sizeof(ds_ipv4_pbr_key));

            ds_ipv4_pbr_key.is_acl_qos_key0 = FALSE;
            ds_ipv4_pbr_key.is_acl_qos_key1 = FALSE;
            ds_ipv4_pbr_key.table_id0 = (ipe_lookup_ctl.ip_sa_lookup_ctl4 >> 2) & 0x7;
            ds_ipv4_pbr_key.table_id1 = (ipe_lookup_ctl.ip_sa_lookup_ctl4 >> 2) & 0x7;
            ds_ipv4_pbr_key.sub_table_id0 = ipe_lookup_ctl.ip_sa_lookup_ctl4 & 0x3;
            ds_ipv4_pbr_key.sub_table_id1 = ipe_lookup_ctl.ip_sa_lookup_ctl4 & 0x3;
            ds_ipv4_pbr_key.ip_da = ip_da;
            ds_ipv4_pbr_key.ip_sa = ip_sa;
            ds_ipv4_pbr_key.layer4_type = layer4_type;
            ds_ipv4_pbr_key.frag_info = frag_info;
            ds_ipv4_pbr_key.ip_options = ip_options;
            ds_ipv4_pbr_key.is_udp = is_udp;
            ds_ipv4_pbr_key.is_tcp = is_tcp;
            ds_ipv4_pbr_key.route_lookup_mode = route_lookup_mode;
            ds_ipv4_pbr_key.l4_source_port = l4_source_port;
            ds_ipv4_pbr_key.l4_dest_port = l4_dest_port;
            ds_ipv4_pbr_key.l4_info_mapped = l4_info_mapped;
            ds_ipv4_pbr_key.dscp = dscp;
            ds_ipv4_pbr_key.pbr_label = pbr_label;
            ds_ipv4_pbr_key.vrf_id11_0 = vrfid & 0xFFF;
            ds_ipv4_pbr_key.vrf_id13_12 = (vrfid >> 12) & 0x3;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV4_PBR;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.ip_sa_lookup_ctl4 >> 5) & 0x3;
            tcam_lookup_info.tcam_key = &ds_ipv4_pbr_key;
            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ipsa_tcam_data;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

            pkt_info->ipsa_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            break;
        case 0x2:   /* IPv6 PBR, only TCAM lookup */
            sal_memset(&ds_ipv6_pbr_key, 0, sizeof(ds_ipv6_pbr_key));
            ds_ipv6_pbr_key.is_acl_qos_key0 = FALSE;
            ds_ipv6_pbr_key.is_acl_qos_key1 = FALSE;
            ds_ipv6_pbr_key.is_acl_qos_key2 = FALSE;
            ds_ipv6_pbr_key.is_acl_qos_key3 = FALSE;
            ds_ipv6_pbr_key.is_acl_qos_key4 = FALSE;
            ds_ipv6_pbr_key.is_acl_qos_key5 = FALSE;
            ds_ipv6_pbr_key.is_acl_qos_key6 = FALSE;
            ds_ipv6_pbr_key.is_acl_qos_key7 = FALSE;
            ds_ipv6_pbr_key.table_id0 = (ipe_lookup_ctl.ip_sa_lookup_ctl5 >> 2) & 0x7;
            ds_ipv6_pbr_key.table_id1 = (ipe_lookup_ctl.ip_sa_lookup_ctl5 >> 2) & 0x7;
            ds_ipv6_pbr_key.table_id2 = (ipe_lookup_ctl.ip_sa_lookup_ctl5 >> 2) & 0x7;
            ds_ipv6_pbr_key.table_id3 = (ipe_lookup_ctl.ip_sa_lookup_ctl5 >> 2) & 0x7;
            ds_ipv6_pbr_key.table_id4 = (ipe_lookup_ctl.ip_sa_lookup_ctl5 >> 2) & 0x7;
            ds_ipv6_pbr_key.table_id5 = (ipe_lookup_ctl.ip_sa_lookup_ctl5 >> 2) & 0x7;
            ds_ipv6_pbr_key.table_id6 = (ipe_lookup_ctl.ip_sa_lookup_ctl5 >> 2) & 0x7;
            ds_ipv6_pbr_key.table_id7 = (ipe_lookup_ctl.ip_sa_lookup_ctl5 >> 2) & 0x7;
            ds_ipv6_pbr_key.sub_table_id1 = ipe_lookup_ctl.ip_sa_lookup_ctl5 & 0x3;
            ds_ipv6_pbr_key.sub_table_id3 = ipe_lookup_ctl.ip_sa_lookup_ctl5 & 0x3;
            ds_ipv6_pbr_key.sub_table_id5 = ipe_lookup_ctl.ip_sa_lookup_ctl5 & 0x3;
            ds_ipv6_pbr_key.sub_table_id7 = ipe_lookup_ctl.ip_sa_lookup_ctl5 & 0x3;
            ds_ipv6_pbr_key.ip_da31_0 = ip_da31_0;
            ds_ipv6_pbr_key.ip_da63_32 = ip_da63_32;
            ds_ipv6_pbr_key.ip_da71_64 = ip_da95_64 & 0xFF;
            ds_ipv6_pbr_key.ip_da103_72 = (ip_da127_96 << 24) | (ip_da95_64 >> 8);
            ds_ipv6_pbr_key.ip_da127_104 = ip_da127_96 >> 8;
            ds_ipv6_pbr_key.l4_dest_port = l4_dest_port;
            ds_ipv6_pbr_key.layer4_type = layer4_type;
            ds_ipv6_pbr_key.vrf_id3_0 = vrfid & 0xF;
            ds_ipv6_pbr_key.vrf_id13_4 = (vrfid >> 4) & 0x3FF;
            ds_ipv6_pbr_key.ip_sa31_0 = ip_sa31_0;
            ds_ipv6_pbr_key.ip_sa63_32 = ip_sa63_32;
            ds_ipv6_pbr_key.ip_sa71_64 = ip_sa95_64 & 0xFF;
            ds_ipv6_pbr_key.ip_sa103_72 = (ip_sa127_96 << 24) | (ip_sa95_64 >> 8);
            ds_ipv6_pbr_key.ip_sa127_104 = ip_sa127_96 >> 8;
            ds_ipv6_pbr_key.l4_source_port = l4_source_port;
            ds_ipv6_pbr_key.frag_info = frag_info;
            ds_ipv6_pbr_key.ip_options = ip_options;
            ds_ipv6_pbr_key.ip_header_error = parser_result->l3_s.ip_header_error;
            ds_ipv6_pbr_key.is_udp = is_udp;
            ds_ipv6_pbr_key.is_tcp = is_tcp;
            ds_ipv6_pbr_key.ipv6_flow_label7_0 = ipv6_flow_label & 0xFF;
            ds_ipv6_pbr_key.ipv6_flow_label19_8 = (ipv6_flow_label >> 8) & 0xFFF;
            ds_ipv6_pbr_key.l4_info_mapped = l4_info_mapped;
            ds_ipv6_pbr_key.dscp = dscp;
            ds_ipv6_pbr_key.svlan_id = parser_result->l2_s.svlan_id;
            ds_ipv6_pbr_key.layer3_type = parser_result->layer3_type;
            ds_ipv6_pbr_key.mac_sa31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                                       parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
            ds_ipv6_pbr_key.mac_sa47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
            ds_ipv6_pbr_key.ether_type7_0 = parser_result->l2_s.layer2_header_protocol & 0xFF;
            ds_ipv6_pbr_key.ether_type15_8 = (parser_result->l2_s.layer2_header_protocol >> 8) & 0xFF;
            ds_ipv6_pbr_key.ctag_cfi = parser_result->l2_s.ctag_cfi;
            ds_ipv6_pbr_key.ctag_cos = parser_result->l2_s.ctag_cos;
            ds_ipv6_pbr_key.mac_da31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                                       parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
            ds_ipv6_pbr_key.mac_da47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);
            ds_ipv6_pbr_key.layer2_type = parser_result->layer2_type;
            ds_ipv6_pbr_key.stag_cfi = parser_result->l2_s.stag_cfi;
            ds_ipv6_pbr_key.stag_cos = parser_result->l2_s.stag_cos;
            ds_ipv6_pbr_key.cvlan_id = parser_result->l2_s.cvlan_id;
            ds_ipv6_pbr_key.pbr_label = pbr_label;
            ds_ipv6_pbr_key.vlan_ptr = pkt_info->vlan_ptr;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV6_PBR;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.ip_sa_lookup_ctl5 >> 5) & 0x3;
            tcam_lookup_info.tcam_key = &ds_ipv6_pbr_key;
            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ipsa_tcam_data;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

            pkt_info->ipsa_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            break;
        case 0x1:   /* FCoE RPF */
            pkt_info->layer3_sa_lookup_mode = (ipe_lookup_ctl.fcoe_lookup_ctl1 >> 5) & 0x3;

            if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 1))
            {
                sal_memset(&ds_fcoe_rpf_key, 0, sizeof(ds_fcoe_rpf_key));
                ds_fcoe_rpf_key.is_acl_qos_key = FALSE;
                ds_fcoe_rpf_key.table_id = (ipe_lookup_ctl.fcoe_lookup_ctl1 >> 2) & 0x7;
                ds_fcoe_rpf_key.sub_table_id = ipe_lookup_ctl.fcoe_lookup_ctl1 & 0x3;
                ds_fcoe_rpf_key.vsi_id13_8 = (pkt_info->vsi_id >> 8) & 0x3F;
                ds_fcoe_rpf_key.vsi_id7_0 = pkt_info->vsi_id & 0xFF;
                ds_fcoe_rpf_key.fcoe_did = parser_result->l3_s.ip_da.fcoe.fcoe_did;
                ds_fcoe_rpf_key.fcoe_sid = parser_result->l3_s.ip_sa.fcoe.fcoe_sid;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
                sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
                tcam_lookup_info.chip_id = in_pkt->chip_id;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_FCOE_SA;
                tcam_lookup_info.tcam_key_size = 0;
                tcam_lookup_info.tcam_key = &ds_fcoe_rpf_key;
                tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->fcoe_sa_data_tcam;

                DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

                pkt_info->fcoe_sa_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
            }

            if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0))
            {
                fib_key.id.vsi_id = pkt_info->vsi_id;
                fib_key.key.fcoe_rpf.fcoe_sid = parser_result->l3_s.ip_sa.fcoe.fcoe_sid;
                fib_lookup_key_type = FIB_KEY_TYPE_FCOE_RPF;
                push_info.data = pkt_info->fcoe_sa_data_fib;
                DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                           fib_lookup_key_type, &fib_result));
                pkt_info->fcoe_sa_fib_result_valid = push_info.valid;
                pkt_info->fcoe_sa_fib_default_entry_valid = push_info.default_entry_valid;
            }
            break;
        default:
            break;  /* no lookup */
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_ipe_lookup_manager_lookup_mac
 * Purpose:    IPE lookup management MAC lookup handle.
 * Parameters:
 *  Input:     in_pkt  -- pointer to buffer which save input packet and packet
 *                               header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                               header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_lookup_manager_lookup_mac(ipe_in_pkt_t* in_pkt, lookup_manager_info_t* p_lkp_mgr_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t *parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;

    ipe_lookup_ctl_t ipe_lookup_ctl;
    fib_key_t fib_key;
    lookup_result_t fib_result;
    tcam_lkp_outputs_t tcam_lookup_result;
    tcam_lkp_inputs_t tcam_lookup_info;
    ds_mac_bridge_key_t ds_mac_bridge_key;
    ds_mac_ipv4_key_t ds_mac_ipv4_key;
    ds_mac_ipv6_key_t ds_mac_ipv6_key;

    uint32 cmd = 0;
    uint8 stp_block_layer3 = 0, stp_block_bridge_disable = 0, stp_learn_en = FALSE;
    uint8 no_mac_lookup = 0;
    uint8 fib_key_type = 0;
    uint32 mapped_mac_da31_0 = 0, mapped_mac_da47_32 = 0;
    uint32 mapped_mac_sa31_0 = 0, mapped_mac_sa47_32 = 0;
    uint8 trill_m_bit_check_fail = FALSE;
    uint8 fdb_flush_learning_disable = FALSE;
    push_info_t push_info;

    sal_memset(&ipe_lookup_ctl, 0, sizeof(ipe_lookup_ctl));
    cmd = DRV_IOR(IpeLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_lookup_ctl));

    /* MAC_LOOKUPS */

    /* No MAC DA lookup if layer3 switched or certain configuration of IP Mcast routed */
    stp_block_layer3 = p_lkp_mgr_info->stp_block
                       && (L3_TYPE_IPV4 == parser_result->layer3_type
                           || (L3_TYPE_IPV6 == parser_result->layer3_type)
                           || (L3_TYPE_FCOE == parser_result->layer3_type)
                           || (L3_TYPE_TRILL == parser_result->layer3_type)
                           || (L3_TYPE_MPLS == parser_result->layer3_type)
                           || (L3_TYPE_MPLSMCAST == parser_result->layer3_type))
                       && ipe_lookup_ctl.stp_block_layer3;

    no_mac_lookup = pkt_info->is_ipv4_ucast
                  || pkt_info->is_ipv6_ucast
                  || ((pkt_info->is_ipv4_mcast || pkt_info->is_ipv6_mcast)
                      && ipe_lookup_ctl.no_ip_mcast_mac_lookup)
                  || stp_block_layer3
                  || pkt_info->is_fcoe
                  || pkt_info->is_trill_ucast
                  || pkt_info->is_trill_mcast;

    /* blocking/learning */
    stp_block_bridge_disable = p_lkp_mgr_info->stp_block && ipe_lookup_ctl.stp_block_bridge_disable;

    if (pkt_info->from_cpu_or_oam)
    {
        pkt_info->mac_da_lookup_en = (OAM_ETHER == pkt_info->rx_oam_type);
    }

    else if (!pkt_info->is_decap && !pkt_info->is_mpls_switched)
    {
        pkt_info->mac_da_lookup_en = ((L2_TYPE_ETHV2 == parser_result->layer2_type)
                                     || (L2_TYPE_ETHSAP == parser_result->layer2_type)
                                     || (L2_TYPE_ETHSNAP == parser_result->layer2_type))
                                     && !no_mac_lookup && !stp_block_bridge_disable && !pkt_info->deny_bridge
                                     && (pkt_info->bridge_en
                                     || (pkt_info->bcast_mac_address && pkt_info->routed_port
                                     && !ipe_lookup_ctl.routed_port_disable_bcast_bridge))
                                     && (!(pkt_info->is_ipv4_ucast || pkt_info->is_ipv6_ucast)
                                     || !ipe_lookup_ctl.skip_mac_da_lookup);
    }
    else
    {
        trill_m_bit_check_fail = !parser_result1->l3_s.ip_da.trill.trill_multicast
                                 && (L3_TYPE_TRILL == parser_result1->layer3_type)
                                 && IS_BIT_SET(parser_result->l2_s.mac_da5, 0)
                                 && !ipe_lookup_ctl.trill_mbit_check_disable;

        pkt_info->mac_da_lookup_en = (PKT_TYPE_ETHERNETV2 == pkt_info->payload_packet_type)
                                     && pkt_info->inner_packet_lookup && !trill_m_bit_check_fail
                                     && (!(pkt_info->is_ipv4_ucast || pkt_info->is_ipv6_ucast||pkt_info->is_fcoe)
                                     || !ipe_lookup_ctl.skip_mac_da_lookup);
    }

    if ((PBB_PORT_TYPE_PIP == pkt_info->pbb_src_port_type) && (L3_TYPE_CMAC == parser_result->layer3_type) && ipe_lookup_ctl.pbb_mode)
    {
        mapped_mac_da31_0 = parser_result->l3_s.ip_da.cmac.cmac_da_31_0;
        mapped_mac_da47_32 = parser_result->l3_s.ip_da.cmac.cmac_da_47_32;

        mapped_mac_sa31_0 = parser_result->l3_s.ip_sa.cmac.cmac_sa_31_0;
        mapped_mac_sa47_32 = parser_result->l3_s.ip_sa.cmac.cmac_sa_47_32;

        parser_result->l2_s.mac_sa5 = (parser_result->l3_s.ip_sa.cmac.cmac_sa_47_32>>8)&0xFF;
        parser_result->l2_s.mac_sa4 = parser_result->l3_s.ip_sa.cmac.cmac_sa_47_32&0xFF;
        parser_result->l2_s.mac_sa3 = (parser_result->l3_s.ip_sa.cmac.cmac_sa_31_0>>24)&0xFF;
        parser_result->l2_s.mac_sa2 = (parser_result->l3_s.ip_sa.cmac.cmac_sa_31_0>>16)&0xFF;
        parser_result->l2_s.mac_sa1 = (parser_result->l3_s.ip_sa.cmac.cmac_sa_31_0>>8)&0xFF;
        parser_result->l2_s.mac_sa0 = parser_result->l3_s.ip_sa.cmac.cmac_sa_31_0&0xFF;
    }
    else
    {
        mapped_mac_da31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                        parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);

        mapped_mac_da47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);

        mapped_mac_sa31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                        parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);

        mapped_mac_sa47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
    }

    if (pkt_info->is_decap && (L3_TYPE_TRILL == parser_result1->layer3_type)
        && parser_result1->l3_s.ip_da.trill.trill_inner_vlan_valid)
    {
        pkt_info->vsi_id = (ipe_lookup_ctl.trill_inner_vsi_base << 6)
                           + parser_result1->l3_s.ip_da.trill.trill_inner_vlan_id;
    }

    if (pkt_info->fatal_exception_valid && ipe_lookup_ctl.fatal_exception_lookup_en)
    {
        pkt_info->mac_da_lookup_en = FALSE;
    }

    /* MAC DA LOOKUP */
    if (pkt_info->mac_da_lookup_en)
    {
        if (pkt_info->force_ipv4_lookup
           && p_lkp_mgr_info->ipv4_mcast_address && p_lkp_mgr_info->ipv4_mcast_mac_address
           && !parser_result->l3_s.ip_header_error)
        {
            pkt_info->mac_ip_lookup_en = TRUE;
            sal_memset(&ds_mac_ipv4_key, 0, sizeof(ds_mac_ipv4_key_t));

            ds_mac_ipv4_key.table_id0 = (ipe_lookup_ctl.mac_ipv4_lookup_ctl >> 2) & 0x7;
            ds_mac_ipv4_key.table_id1 = (ipe_lookup_ctl.mac_ipv4_lookup_ctl >> 2) & 0x7;
            ds_mac_ipv4_key.sub_table_id0 = ipe_lookup_ctl.mac_ipv4_lookup_ctl & 0x3;
            ds_mac_ipv4_key.sub_table_id1 = ipe_lookup_ctl.mac_ipv4_lookup_ctl & 0x3;
            ds_mac_ipv4_key.vrf_id3_0 = pkt_info->vsi_id & 0xF;  /* not PacketInfo.vrfId[13:0] */
            ds_mac_ipv4_key.vrf_id13_4 = (pkt_info->vsi_id >> 4) & 0x3FF;
            ds_mac_ipv4_key.ip_da = parser_result->l3_s.ip_da.ipv4.ipda;
            ds_mac_ipv4_key.ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_type = TCAM_TYPE_MAC_IPV4_MCAST;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.mac_ipv4_lookup_ctl >> 5) & 0x3;
            tcam_lookup_info.tcam_key = &ds_mac_ipv4_key;
            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ip_tcam_mac_da_data;
            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
            pkt_info->ip_mac_da_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;

            sal_memset(&fib_result, 0, sizeof(lookup_result_t));
            sal_memset(&fib_key, 0, sizeof(fib_key_t));
            sal_memset(&push_info, 0, sizeof(push_info_t));
            fib_result.extra = &push_info;

            fib_key.key.ipv4_mcast.ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
            fib_key.key.ipv4_mcast.ip_da = parser_result->l3_s.ip_da.ipv4.ipda;
            fib_key.id.vsi_id = pkt_info->vsi_id;
            fib_key_type = FIB_KEY_TYPE_MAC_IPV4_MULTICAST;
            push_info.data = pkt_info->ip_hash_mac_da_data;
            DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key, fib_key_type, &fib_result));
            pkt_info->ip_mac_da_hash_result_valid = push_info.valid;
            pkt_info->ip_mac_da_default_entry_valid = push_info.default_entry_valid;
        }
        else if (pkt_info->force_ipv6_lookup && p_lkp_mgr_info->ipv6_mcast_address
                 && p_lkp_mgr_info->ipv6_mcast_mac_address && !parser_result->l3_s.ip_header_error)
        {
            pkt_info->mac_ip_lookup_en = TRUE;
            sal_memset(&ds_mac_ipv6_key, 0, sizeof(ds_mac_ipv6_key_t));

            ds_mac_ipv6_key.ip_da127_96 = parser_result->l3_s.ip_da.ipv6.ipda_127_96;
            ds_mac_ipv6_key.ip_da95_64 = parser_result->l3_s.ip_da.ipv6.ipda_95_64;
            ds_mac_ipv6_key.ip_da63_32 = parser_result->l3_s.ip_da.ipv6.ipda_63_32;
            ds_mac_ipv6_key.ip_da31_0 = parser_result->l3_s.ip_da.ipv6.ipda_31_0;

            ds_mac_ipv6_key.ip_sa127_96 = parser_result->l3_s.ip_sa.ipv6.ipsa_127_96;
            ds_mac_ipv6_key.ip_sa95_64 = parser_result->l3_s.ip_sa.ipv6.ipsa_95_64;
            ds_mac_ipv6_key.ip_sa63_32 = parser_result->l3_s.ip_sa.ipv6.ipsa_63_32;
            ds_mac_ipv6_key.ip_sa31_0 = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;

            ds_mac_ipv6_key.sub_table_id0 = ipe_lookup_ctl.mac_ipv6_lookup_ctl & 0x3;
            ds_mac_ipv6_key.sub_table_id1 = ipe_lookup_ctl.mac_ipv6_lookup_ctl & 0x3;
            ds_mac_ipv6_key.sub_table_id2 = ipe_lookup_ctl.mac_ipv6_lookup_ctl & 0x3;
            ds_mac_ipv6_key.sub_table_id3 = ipe_lookup_ctl.mac_ipv6_lookup_ctl & 0x3;
            ds_mac_ipv6_key.table_id0 = (ipe_lookup_ctl.mac_ipv6_lookup_ctl >> 2) & 0x7;
            ds_mac_ipv6_key.table_id1 = (ipe_lookup_ctl.mac_ipv6_lookup_ctl >> 2) & 0x7;
            ds_mac_ipv6_key.table_id2 = (ipe_lookup_ctl.mac_ipv6_lookup_ctl >> 2) & 0x7;
            ds_mac_ipv6_key.table_id3 = (ipe_lookup_ctl.mac_ipv6_lookup_ctl >> 2) & 0x7;
            ds_mac_ipv6_key.vrf_id3_0 = pkt_info->vsi_id & 0xF;   /* not PacketInfo.vrfId[13:0] */
            ds_mac_ipv6_key.vrf_id13_4 = (pkt_info->vsi_id >> 4) & 0x3FF;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_type = TCAM_TYPE_MAC_IPV6_MCAST;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.mac_ipv6_lookup_ctl >> 5) & 0x3;
            tcam_lookup_info.tcam_key = &ds_mac_ipv6_key;
            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->ip_tcam_mac_da_data;
            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
            pkt_info->ip_mac_da_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;

            sal_memset(&fib_result, 0, sizeof(lookup_result_t));
            sal_memset(&fib_key, 0, sizeof(fib_key_t));
            sal_memset(&push_info, 0, sizeof(push_info_t));
            fib_result.extra = &push_info;

            fib_key.id.vsi_id = pkt_info->vsi_id;

            fib_key.key.ipv6_mcast.ip_da31_0 = parser_result->l3_s.ip_da.ipv6.ipda_31_0;
            fib_key.key.ipv6_mcast.ip_da63_32 = parser_result->l3_s.ip_da.ipv6.ipda_63_32;
            fib_key.key.ipv6_mcast.ip_da95_64 = parser_result->l3_s.ip_da.ipv6.ipda_95_64;
            fib_key.key.ipv6_mcast.ip_da127_96 = parser_result->l3_s.ip_da.ipv6.ipda_127_96;

            fib_key.key.ipv6_mcast.ip_sa31_0 = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
            fib_key.key.ipv6_mcast.ip_sa63_32 = parser_result->l3_s.ip_sa.ipv6.ipsa_63_32;
            fib_key.key.ipv6_mcast.ip_sa95_64 = parser_result->l3_s.ip_sa.ipv6.ipsa_95_64;
            fib_key.key.ipv6_mcast.ip_sa127_96 = parser_result->l3_s.ip_sa.ipv6.ipsa_127_96;
            fib_key_type = FIB_KEY_TYPE_MAC_IPV6_MULTICAST;

            push_info.data = pkt_info->ip_hash_mac_da_data;
            DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key, fib_key_type, &fib_result));
            pkt_info->ip_mac_da_hash_result_valid = push_info.valid;
            pkt_info->ip_mac_da_default_entry_valid = push_info.default_entry_valid;
        }
        else
        {
            pkt_info->mac_ip_lookup_en = FALSE;
        }

        if (ipe_lookup_ctl.mac_hash_lookup_en)
        {
            sal_memset(&fib_result, 0, sizeof(lookup_result_t));
            sal_memset(&fib_key, 0, sizeof(fib_key_t));
            sal_memset(&push_info, 0, sizeof(push_info_t));
            fib_result.extra = &push_info;

            fib_key.id.vsi_id = pkt_info->vsi_id;
            fib_key.key.mac.mapped_mac31_0 = mapped_mac_da31_0;
            fib_key.key.mac.mapped_mac47_32 = mapped_mac_da47_32 & 0xFFFF;

            fib_key_type = FIB_KEY_TYPE_MAC_DA;
            push_info.data = pkt_info->hash_mac_da_data;
            DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key, fib_key_type, &fib_result));
            pkt_info->mac_da_hash_result_valid = push_info.valid;
            pkt_info->mac_da_default_entry_valid = push_info.default_entry_valid;
        }

        if (ipe_lookup_ctl.mac_tcam_lookup_en)   /* TCAM lookup */
        {
            sal_memset(&ds_mac_bridge_key, 0, sizeof(ds_mac_bridge_key));
            ds_mac_bridge_key.is_acl_qos_key0 = FALSE;
            ds_mac_bridge_key.is_acl_qos_key1 = FALSE;
            ds_mac_bridge_key.table_id0 = (ipe_lookup_ctl.mac_da_lookup_ctl >> 2) & 0x7;
            ds_mac_bridge_key.table_id1 = (ipe_lookup_ctl.mac_da_lookup_ctl >> 2) & 0x7;
            ds_mac_bridge_key.sub_table_id0 = ipe_lookup_ctl.mac_da_lookup_ctl & 0x3;
            ds_mac_bridge_key.sub_table_id1 = ipe_lookup_ctl.mac_da_lookup_ctl & 0x3;
            ds_mac_bridge_key.mapped_mac_da47_32 = mapped_mac_da47_32 & 0xFFFF;
            ds_mac_bridge_key.mapped_mac_da31_0 = mapped_mac_da31_0;
            ds_mac_bridge_key.vsi_id = pkt_info->vsi_id;
            ds_mac_bridge_key.vlan_id1_11_2 = (pkt_info->svlan_id >> 2) & 0x3FF;
            ds_mac_bridge_key.vlan_id1_1_0 = pkt_info->svlan_id & 0x3;
            ds_mac_bridge_key.vlan_id2 = pkt_info->cvlan_id;
            ds_mac_bridge_key.vlan_ptr13_4 = (pkt_info->vlan_ptr >> 4) & 0x1FF;
            ds_mac_bridge_key.vlan_ptr3_0 = pkt_info->vlan_ptr & 0xF;
            ds_mac_bridge_key.cos = pkt_info->source_cos;
            ds_mac_bridge_key.cfi = pkt_info->source_cfi;
            ds_mac_bridge_key.global_src_port = pkt_info->global_src_port;
            ds_mac_bridge_key.layer2_header_protocol = parser_result->l2_s.layer2_header_protocol;
            ds_mac_bridge_key.layer3_type = parser_result->layer3_type;
            ds_mac_bridge_key.layer2_type = parser_result->layer2_type;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_type = TCAM_TYPE_MAC_DA;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.mac_da_lookup_ctl >> 5) & 0x3;
            tcam_lookup_info.tcam_key = &ds_mac_bridge_key;
            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->tcam_mac_da_data;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

            pkt_info->mac_da_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
        }
    }

    fdb_flush_learning_disable = ipe_lookup_ctl.fdb_flush_learning_disable || ((!ipe_lookup_ctl.fdb_flush_vsi_learning_disable)
                                        && (ipe_lookup_ctl.fdb_flush_vsi == pkt_info->vsi_id));
    stp_learn_en = (STP_BLOCKING != pkt_info->stp_state) && !pkt_info->learning_disable
                   && !pkt_info->from_cpu_or_oam;

    /* always perform MAC learning when enabled */
    if (!pkt_info->is_decap && !pkt_info->is_mpls_switched)
    {
        pkt_info->mac_sa_lookup_en = stp_learn_en
                                     && ((L2_TYPE_ETHV2 == parser_result->layer2_type)
                                        || (L2_TYPE_ETHSAP == parser_result->layer2_type)
                                        || (L2_TYPE_ETHSNAP == parser_result->layer2_type))
                                     && !pkt_info->deny_bridge && !fdb_flush_learning_disable;
    }
    else
    {
        pkt_info->mac_sa_lookup_en = (PKT_TYPE_ETHERNETV2 == pkt_info->payload_packet_type)
                                     && pkt_info->inner_packet_lookup
                                     && !pkt_info->vsi_learning_disable;
    }

    if ((pkt_info->fatal_exception_valid && ipe_lookup_ctl.fatal_exception_lookup_en)
        || ipe_lookup_ctl.learning_disable)
    {
        pkt_info->mac_sa_lookup_en = FALSE;
    }

    if (pkt_info->mac_sa_lookup_en) /* MAC SA LOOKUP */
    {
        if (ipe_lookup_ctl.mac_hash_lookup_en)
        {
            sal_memset(&fib_result, 0, sizeof(lookup_result_t));
            sal_memset(&fib_key, 0, sizeof(fib_key_t));
            sal_memset(&push_info, 0, sizeof(push_info_t));
            fib_result.extra = &push_info;

            fib_key.id.vsi_id = pkt_info->vsi_id;
            fib_key.key.mac.mapped_mac31_0 = mapped_mac_sa31_0;
            fib_key.key.mac.mapped_mac47_32 = mapped_mac_sa47_32 & 0xFFFF;
            fib_key_type = FIB_KEY_TYPE_MAC_SA;
            push_info.data = pkt_info->hash_mac_sa_data;
            DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key, fib_key_type, &fib_result));
            pkt_info->mac_sa_hash_result_valid = push_info.valid;
            pkt_info->mac_sa_default_entry_valid = push_info.default_entry_valid;
            pkt_info->mac_sa_hash_conflict = push_info.conflict;
        }

        if (ipe_lookup_ctl.mac_tcam_lookup_en)
        {
            sal_memset(&ds_mac_bridge_key, 0, sizeof(ds_mac_bridge_key));
            ds_mac_bridge_key.is_acl_qos_key0 = FALSE;
            ds_mac_bridge_key.is_acl_qos_key1 = FALSE;
            ds_mac_bridge_key.table_id0 = (ipe_lookup_ctl.mac_sa_lookup_ctl >> 2) & 0x7;
            ds_mac_bridge_key.table_id1 = (ipe_lookup_ctl.mac_sa_lookup_ctl >> 2) & 0x7;
            ds_mac_bridge_key.sub_table_id0 = ipe_lookup_ctl.mac_sa_lookup_ctl & 0x3;
            ds_mac_bridge_key.sub_table_id1 = ipe_lookup_ctl.mac_sa_lookup_ctl & 0x3;
            ds_mac_bridge_key.mapped_mac_da47_32 = mapped_mac_sa47_32 & 0xFFFF;
            ds_mac_bridge_key.mapped_mac_da31_0 = mapped_mac_sa31_0;
            ds_mac_bridge_key.vsi_id = pkt_info->vsi_id;
            ds_mac_bridge_key.vlan_id1_11_2 = (pkt_info->svlan_id >> 2) & 0x3FF;
            ds_mac_bridge_key.vlan_id1_1_0 = pkt_info->svlan_id & 0x3;
            ds_mac_bridge_key.vlan_id2 = pkt_info->cvlan_id;
            ds_mac_bridge_key.vlan_ptr13_4 = (pkt_info->vlan_ptr >> 4) & 0x3FF;
            ds_mac_bridge_key.vlan_ptr3_0 = pkt_info->vlan_ptr & 0xF;
            ds_mac_bridge_key.cos = pkt_info->source_cos;
            ds_mac_bridge_key.cfi = pkt_info->source_cfi;
            ds_mac_bridge_key.global_src_port = pkt_info->global_src_port;
            ds_mac_bridge_key.layer2_header_protocol = parser_result->l2_s.layer2_header_protocol;
            ds_mac_bridge_key.layer3_type = parser_result->layer3_type;
            ds_mac_bridge_key.layer2_type = parser_result->layer2_type;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_type = TCAM_TYPE_MAC_SA;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.mac_sa_lookup_ctl >> 5) & 0x3;
            tcam_lookup_info.tcam_key = &ds_mac_bridge_key;
            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->tcam_mac_sa_data;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));

            pkt_info->mac_sa_tcam_result_valid = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
        }
    }

    if (pkt_info->mac_da_lookup_en || pkt_info->mac_sa_lookup_en)
    {
        pkt_info->fid = pkt_info->vsi_id;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_lookup_manager_lookup_oam
 * Purpose:    IPE lookup management MAC lookup handle.
 * Parameters:
 *  Input:     in_pkt  -- pointer to buffer which save input packet and packet
 *                        header, and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                        header, and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_lookup_manager_lookup_oam(ipe_in_pkt_t* in_pkt, lookup_manager_info_t* p_lookup_manager_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t *parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;

    oam_extra_result_t oam_extra_result;
    ipe_lookup_ctl_t ipe_lookup_ctl;
    lookup_result_t lookup_result;
    label_section_info_t label_section_info;

    userid_key_t oam_hash_key;
    userid_key_type_t userid_key_type = USERID_KEY_TYPE_DISABLE;

    uint8 oam_lookup_type = 0;
    uint8 oam_lookup_type_tmp = 0;
    uint8 ipv4_local_address = FALSE, ipv6_local_address = FALSE;
    uint32 cmd = 0;

    sal_memset(&oam_hash_key, 0, sizeof(userid_key_t));
    sal_memset(&label_section_info, 0, sizeof(label_section_info_t));
    sal_memset(&ipe_lookup_ctl, 0, sizeof(ipe_lookup_ctl));

    cmd = DRV_IOR(IpeLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_lookup_ctl));

    ipv4_local_address = (L3_TYPE_IPV4 == parser_result->layer3_type)
                         && (0x7F == ((parser_result->l3_s.ip_da.ipv4.ipda >> 24) & 0xFF));
    ipv6_local_address = (L3_TYPE_IPV6 == parser_result->layer3_type)
                         && ((0xFFFF == (parser_result->l3_s.ip_da.ipv6.ipda_63_32 & 0xFFFF))
                         && (0x7F == ((parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 24) & 0xFF)));

    if (OAM_TRILL_BFD == pkt_info->rx_oam_type)
    {
        oam_lookup_type = OAM_LOOKUP_TYPE_BFD_OAM;
        pkt_info->payload_offset = parser_result1->l2_s.layer3_offset + ((parser_result1->l3_s.ip_da.trill.trill_inner_vlan_valid) ? 28 : 24 );  /* to BFD */
    }
    else if ((L4_TYPE_UDP == parser_result->layer4_type)
             && (L4_USER_TYPE_UDP_BFD == parser_result->l4_s.layer4_user_type))
    {
        if (pkt_info->is_mpls_switched)
        {
            //ECO bug4886 start
            //if (pkt_info->mpls_mep_check && (1 == parser_result->l3_s.ttl)
            //           && (ipv4_local_address || ipv6_local_address)) {
            if (pkt_info->mpls_mep_check && (1 == parser_result->l3_s.ttl
                  || IS_BIT_SET(ipe_lookup_ctl.fcoe_lookup_ctl1, 6))
                  && (ipv4_local_address || ipv6_local_address))
            {
            //ECO bug4886 end

                pkt_info->rx_oam_type = OAM_MPLS_BFD;
                oam_lookup_type = OAM_LOOKUP_TYPE_BFD_OAM;
                pkt_info->payload_offset = parser_result->l3_s.layer4_offset + 8; /* point to BFD */
            }
        }
        else if (!pkt_info->is_decap && p_lookup_manager_info->ip_routed_packet)
        {
            pkt_info->rx_oam_type = OAM_IP_BFD;
            oam_lookup_type = OAM_LOOKUP_TYPE_BFD_OAM;
        }
    }
    else if (OAM_ACH == pkt_info->rx_oam_type)
    {
        switch (parser_result->l4_s.layer4_user_type & 0xF)
        {
            case L4_USER_TYPE_ACHOAM_ACH_BFD:
                oam_lookup_type_tmp = pkt_info->link_or_section_OAM ? OAM_LOOKUP_TYPE_MPLS_SECTION : OAM_LOOKUP_TYPE_NONE;
                oam_lookup_type = ipe_lookup_ctl.mpls_bfd_use_label ? (oam_lookup_type_tmp) : OAM_LOOKUP_TYPE_BFD_OAM;
                break;
            case L4_USER_TYPE_ACHOAM_ACH_CC:
                oam_lookup_type_tmp = pkt_info->link_or_section_OAM ? OAM_LOOKUP_TYPE_MPLS_SECTION : OAM_LOOKUP_TYPE_NONE;
                oam_lookup_type = ipe_lookup_ctl.ach_cc_use_label ? (oam_lookup_type_tmp) : OAM_LOOKUP_TYPE_BFD_OAM;
                break;
            case L4_USER_TYPE_ACHOAM_ACH_CV:
                oam_lookup_type_tmp = pkt_info->link_or_section_OAM ? OAM_LOOKUP_TYPE_MPLS_SECTION : OAM_LOOKUP_TYPE_NONE;
                oam_lookup_type = ipe_lookup_ctl.ach_cv_use_label ? (oam_lookup_type_tmp) : OAM_LOOKUP_TYPE_BFD_OAM;
                break;
            default:
                oam_lookup_type = pkt_info->link_or_section_OAM ? OAM_LOOKUP_TYPE_MPLS_SECTION : OAM_LOOKUP_TYPE_NONE;
                break;
        }
    }
    /* merge LM and CCM lookup */
    else if (OAM_ETHER == pkt_info->rx_oam_type)
    {
        oam_lookup_type = OAM_LOOKUP_TYPE_ETHER_OAM;
    }
    else if (OAM_PBT == pkt_info->rx_oam_type)
    {
        oam_lookup_type = OAM_LOOKUP_TYPE_PBT_OAM;
    }
    else
    {
        oam_lookup_type = OAM_LOOKUP_TYPE_NONE;
    }

    pkt_info->oam_lookup_en = (OAM_LOOKUP_TYPE_NONE != oam_lookup_type);

    if (pkt_info->ether_lm_valid)
    {
        pkt_info->lm_lookup_type = LM_ETHER;
        pkt_info->lm_lookup_en0 = TRUE;

        if (parser_result->l2_s.svlan_id_valid)
        {
             pkt_info->packet_cos0 = parser_result->l2_s.stag_cos;
        }
        else
        {
            pkt_info->packet_cos0 = pkt_info->default_pcp;
        }
    }

    if (pkt_info->mpls_section_lm_en) /* MPLS Section LM */
    {
        pkt_info->lm_lookup_type = LM_MPLS;
        pkt_info->lm_lookup_en0 = (L3_TYPE_MPLSMCAST == parser_result1->layer3_type)
                                  || (L3_TYPE_MPLS == parser_result1->layer3_type);

        pkt_info->packet_cos0 = (parser_result1->l3_s.ip_da.mpls.mpls_label0 >> 9) & 0x7;
    }

    if ((LM_TYPE_NONE != pkt_info->lm_type0) || (LM_TYPE_NONE != pkt_info->lm_type1)
        || (LM_TYPE_NONE != pkt_info->lm_type2) )
    {
        pkt_info->lm_lookup_type = LM_MPLS;
    }
    sal_memset(&lookup_result, 0, sizeof(lookup_result));

    if (pkt_info->ether_lm_valid || (OAM_LOOKUP_TYPE_ETHER_OAM == oam_lookup_type))
    {
        if (pkt_info->oam_use_fid)
        {
            userid_key_type = USERID_KEY_TYPE_ETHER_FID_OAM;
            oam_hash_key.key.ether_fid_oam.is_fid = pkt_info->oam_use_fid;
        }
        else
        {
            userid_key_type = USERID_KEY_TYPE_ETHER_VLAN_OAM;
            oam_hash_key.key.ether_vlan_oam.is_fid = pkt_info->oam_use_fid;
        }
        oam_hash_key.xport.global.src = pkt_info->global_src_port;

        if (pkt_info->oam_use_fid)
        {
            oam_hash_key.key.ether_fid_oam.vlan_id = pkt_info->fid;
        }
        else
        {
            if (!ipe_lookup_ctl.oam_lookup_user_vlan_id)
            {
                oam_hash_key.key.ether_vlan_oam.vlan_id = pkt_info->vlan_ptr & 0xFFF;
            }
            else
            {
                if (pkt_info->svlan_id_valid)
                {
                    oam_hash_key.key.ether_vlan_oam.vlan_id = pkt_info->svlan_id;
                }
                else
                {
                    oam_hash_key.key.ether_vlan_oam.vlan_id = pkt_info->cvlan_id;
                }
            }
        }

        sal_memset(&oam_extra_result, 0, sizeof(oam_extra_result_t));

        oam_extra_result.chan = pkt_info->lm_chan_data0;
        oam_extra_result.info = pkt_info->lm_info0;
        lookup_result.extra = &oam_extra_result;

        DRV_IF_ERROR_RETURN(cm_com_userid_hash_lookup_request(in_pkt->chip_id, pkt_info->local_phy_port, &oam_hash_key,
                                                              userid_key_type, USERID_DIRECTION_OTHER, &lookup_result));
        /*store for pop*/
        pkt_info->lm_result_valid0 = lookup_result.valid;
        pkt_info->hash_conflict0 = lookup_result.conflict;
    }
    else if (OAM_LOOKUP_TYPE_BFD_OAM == oam_lookup_type)
    {
        sal_memset(&oam_extra_result, 0, sizeof(oam_extra_result_t));

        oam_hash_key.key.bfd_oam.my_discriminator = parser_result->l4_s.gre_bfd_ptp.bfd_my_discriminator;

        if (L3_TYPE_TRILL == parser_result1->layer3_type)
        {
            oam_hash_key.key.bfd_oam.my_discriminator = parser_result1->l3_s.ip_da.trill.trill_bfd_my_discriminator31_13<<13
                            | parser_result1->l3_s.ip_da.trill.trill_bfd_my_discriminator12_0;
        }

        userid_key_type = USERID_KEY_TYPE_BFD_OAM;

        oam_extra_result.chan = pkt_info->lm_chan_data0;
        oam_extra_result.info = pkt_info->lm_info0;
        lookup_result.extra   = &oam_extra_result;

        DRV_IF_ERROR_RETURN(cm_com_userid_hash_lookup_request(in_pkt->chip_id, pkt_info->local_phy_port, &oam_hash_key,
                                                              userid_key_type, USERID_DIRECTION_OTHER, &lookup_result));
        /*store for pop*/
        pkt_info->lm_result_valid0 = lookup_result.valid;
        pkt_info->hash_conflict0 = lookup_result.conflict;
    }
    else if (OAM_LOOKUP_TYPE_PBT_OAM == oam_lookup_type)
    {
        sal_memset(&oam_extra_result, 0, sizeof(oam_extra_result_t));

        oam_hash_key.key.pbt_oam.mac_sa_31_0 = MAKE_UINT32(parser_result1->l2_s.mac_sa3, parser_result1->l2_s.mac_sa2,
                                                     parser_result1->l2_s.mac_sa1, parser_result1->l2_s.mac_sa0);
        oam_hash_key.key.pbt_oam.mac_sa_47_32 = MAKE_UINT16(parser_result1->l2_s.mac_sa5, parser_result1->l2_s.mac_sa4);
        oam_hash_key.key.pbt_oam.vrf_id = pkt_info->outer_vsi_id;

        userid_key_type = USERID_KEY_TYPE_PBT_OAM;

        oam_extra_result.chan = pkt_info->lm_chan_data0;
        oam_extra_result.info = pkt_info->lm_info0;
        lookup_result.extra   = &oam_extra_result;

        /* //======bug 4609 ECO begine ====== */
        /* //if (UserIdHashLookupCtl.ingressUserIdTcamEn){ */
        /* if (UserIdHashLookupCtl.otherTcamEn) */
        /* //======bug 4609 ECO end ====== */
        DRV_IF_ERROR_RETURN(cm_com_userid_hash_lookup_request(in_pkt->chip_id, pkt_info->local_phy_port, &oam_hash_key,
                                                              userid_key_type, USERID_DIRECTION_OTHER, &lookup_result));

        /*store for pop*/
        pkt_info->lm_result_valid0 = lookup_result.valid;
        pkt_info->hash_conflict0 = lookup_result.conflict;
    }
    else if ((pkt_info->mpls_section_lm_en && ((L3_TYPE_MPLSMCAST == parser_result1->layer3_type)
                                  || (L3_TYPE_MPLS == parser_result1->layer3_type)))
               || (OAM_LOOKUP_TYPE_MPLS_SECTION == oam_lookup_type))
    {
        sal_memset(&oam_extra_result, 0, sizeof(oam_extra_result_t));

        userid_key_type = USERID_KEY_TYPE_MPLS_SECTION_OAM;

        if (ipe_lookup_ctl.mpls_section_oam_use_port)
        {
            oam_hash_key.key.mpls_section_oam.interface_id = pkt_info->local_phy_port;
        }
        else
        {
            oam_hash_key.key.mpls_section_oam.interface_id = pkt_info->interface_id;
        }

        oam_extra_result.chan = pkt_info->lm_chan_data0;
        oam_extra_result.info = pkt_info->lm_info0;
        lookup_result.extra   = &oam_extra_result;

        DRV_IF_ERROR_RETURN(cm_com_userid_hash_lookup_request(in_pkt->chip_id, pkt_info->local_phy_port, &oam_hash_key,
                                                              userid_key_type, USERID_DIRECTION_OTHER, &lookup_result));
        /*store for pop*/
        pkt_info->lm_result_valid0 = lookup_result.valid;
        pkt_info->hash_conflict0 = lookup_result.conflict;
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_ipe_lookup_manager_lookup_aclqos
 * Purpose:    IPE lookup management QoS and ACL lookup information handle.
 * Parameters:
 *  Input:       in_pkt  -- pointer to buffer which save input packet and packet
 *                               header ,and processing informations
 * Output:      in_pkt  -- pointer to buffer which save input packet and packet
 *                                 header ,and processing informations
 * Return:      DRV_E_NONE = success.
 *                  Other = Error, please refer to DRV_E_XXX.
 * Note:         none.
 ****************************************************************************/
static int32
_cm_ipe_lookup_manager_lookup_aclqos(ipe_in_pkt_t *in_pkt, lookup_manager_info_t* p_lookup_manager_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t* parser_result = pkt_info->parser_rslt;
    parsing_result_t* parser_result1 = pkt_info->parser_rslt1;

    ipe_lookup_ctl_t ipe_lookup_ctl;
    tcam_lkp_outputs_t tcam_lookup_result;
    tcam_lkp_inputs_t tcam_lookup_info;
    ds_acl_qos_mac_key_t ds_acl_qos_mac_key;
    ds_acl_qos_ipv4_key_t ds_acl_qos_ipv4_key;
    ds_acl_qos_mpls_key_t ds_acl_qos_mpls_key;
    ds_acl_qos_ipv6_key_t ds_acl_qos_ipv6_key;
    acl_qos_key_info_t acl_qos_key_info;
    push_info_t push_info;

    uint8 l2_acl_en0 = FALSE, l2_acl_en1 = FALSE, l2_acl_en2 = FALSE, l2_acl_en3 = FALSE;
    uint8 l2_ipv6_acl_en0 = FALSE, l2_ipv6_acl_en1 = FALSE;
    uint8 l3_acl_en0 = FALSE, l3_acl_en1 = FALSE, l3_acl_en2 = FALSE, l3_acl_en3 = FALSE;
    uint8 l3_ipv6_acl_en0 = FALSE, l3_ipv6_acl_en1 = FALSE;
    uint8 acl_en = FALSE, ipv6_acl_en = FALSE;
    uint8 is_ipv4_or_mpls = FALSE, is_ipv6 = FALSE;
    uint32 cmd = 0;
    uint8 route_stp_block = 0;
    uint8 obey_acl_qos = FALSE;
    uint8 ip_routed_packet = 0;
    uint8 chip_id = in_pkt->chip_id;
    uint8 tcam_key_type = 0;
    uint8 err_free = FALSE;
    uint8 stp_block = p_lookup_manager_info->stp_block;

    fib_key_t fib_key;
    fib_key_type_t fib_key_type = FIB_KEY_TYPE_ACL;
    lookup_result_t fib_result;

    sal_memset(&acl_qos_key_info, 0, sizeof(acl_qos_key_info));
    sal_memset(&ds_acl_qos_mac_key, 0, sizeof(ds_acl_qos_mac_key));
    sal_memset(&ds_acl_qos_ipv4_key, 0, sizeof(ds_acl_qos_ipv4_key));
    sal_memset(&ds_acl_qos_mpls_key, 0, sizeof(ds_acl_qos_mpls_key));
    sal_memset(&ds_acl_qos_ipv6_key, 0, sizeof(ds_acl_qos_ipv6_key));

    sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
    sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));

    /* ACL_QOS_LOOKUP_PREPARE */
    sal_memset(&ipe_lookup_ctl, 0, sizeof(ipe_lookup_ctl));
    cmd = DRV_IOR(IpeLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_lookup_ctl));
    acl_qos_key_info.ipe_lookup_ctl = &ipe_lookup_ctl;

    route_stp_block = stp_block && ipe_lookup_ctl.route_obey_stp;
    ip_routed_packet = p_lookup_manager_info->ip_routed_packet;

    if (!pkt_info->from_cpu_or_oam && ((OAM_NONE == pkt_info->rx_oam_type) || ipe_lookup_ctl.oam_obey_acl_qos))
    {
        obey_acl_qos = TRUE;
    }
    else
    {
        obey_acl_qos = FALSE;
    }

    l2_acl_en0 = pkt_info->l2_acl_en0 && (!stp_block) && obey_acl_qos;
    l2_acl_en1 = pkt_info->l2_acl_en1 && (!stp_block) && obey_acl_qos;
    l2_acl_en2 = pkt_info->l2_acl_en2 && (!stp_block) && obey_acl_qos;
    l2_acl_en3 = pkt_info->l2_acl_en3 && (!stp_block) && obey_acl_qos;

    l2_ipv6_acl_en0 = pkt_info->l2_ipv6_acl_en0 && (!stp_block) && obey_acl_qos;
    l2_ipv6_acl_en1 = pkt_info->l2_ipv6_acl_en1 && (!stp_block) && obey_acl_qos;

    l3_acl_en0 = pkt_info->l3_acl_en0
                 && (!route_stp_block)
                 && ((!pkt_info->l3_acl_routed_only) || ip_routed_packet)
                 && obey_acl_qos;

    l3_acl_en1 = pkt_info->l3_acl_en1
                 && (!route_stp_block)
                 && ((!pkt_info->l3_acl_routed_only) || ip_routed_packet)
                 && obey_acl_qos;

    l3_acl_en2 = pkt_info->l3_acl_en2
                 && (!route_stp_block)
                 && ((!pkt_info->l3_acl_routed_only) || ip_routed_packet)
                 && obey_acl_qos;

    l3_acl_en3 = pkt_info->l3_acl_en3
                 && (!route_stp_block)
                 && ((!pkt_info->l3_acl_routed_only) || ip_routed_packet)
                 && obey_acl_qos;

    l3_ipv6_acl_en0 = pkt_info->l3_ipv6_acl_en0 && !route_stp_block
                      && ((!pkt_info->l3_acl_routed_only) || ip_routed_packet) && obey_acl_qos;

    l3_ipv6_acl_en1 = pkt_info->l3_ipv6_acl_en1 && !route_stp_block
                      && ((!pkt_info->l3_acl_routed_only) || ip_routed_packet) && obey_acl_qos;

    if (pkt_info->service_acl_qos_en)
    {
        l2_acl_en0 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,0);
        l2_acl_en1 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,1);
        l2_acl_en2 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,2);
        l2_acl_en3 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,3);
        l2_ipv6_acl_en0 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,4);
        l2_ipv6_acl_en1 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,5);
        l3_acl_en0 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,6);
        l3_acl_en1 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,7);
        l3_acl_en2 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,8);
        l3_acl_en3 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,9);
        l3_ipv6_acl_en0 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,10);
        l3_ipv6_acl_en1 = pkt_info->service_acl_qos_en && obey_acl_qos && IS_BIT_SET(ipe_lookup_ctl.service_acl_qos_en,11);
        acl_qos_key_info.is_label = FALSE;
    }
    else
    {
        acl_qos_key_info.is_label = TRUE;
    }

    /* up to 56 MAC is supported in GreatBelt using channelId from 0 to 63. */
    /* acl only support 56 port bitmap for without enough field */
    acl_qos_key_info.acl_label_high = 0;
    acl_qos_key_info.acl_label_low = 0;

    if (!pkt_info->service_acl_qos_en)
    {
        /* port bitmap */
        if (pkt_info->acl_port_num >= 32)
        {
            SET_BIT(acl_qos_key_info.acl_label_high, (pkt_info->acl_port_num - 32));
        }
        else
        {
            SET_BIT(acl_qos_key_info.acl_label_low, pkt_info->acl_port_num);
        }
    }
    else
    {
        acl_qos_key_info.acl_label_low = pkt_info->logic_src_port;
        acl_qos_key_info.acl_label_high = 0;
    }

    /* For general packet, ParserResult1 will be used.
       For tunnel decap packet, PacketInfo.aclQosUseInnerInfo will decide which ParserResult should be used. */
    _cm_ipe_lookup_manager_get_acl_qos_key_info(pkt_info, &acl_qos_key_info);

    if (ipe_lookup_ctl.acl_use_packet_vlan)
    {
        if (pkt_info->acl_qos_use_outer_info)
        {
            acl_qos_key_info.svlan_id = parser_result1->l2_s.svlan_id;
            acl_qos_key_info.cvlan_id = parser_result1->l2_s.cvlan_id;
            acl_qos_key_info.svlan_id_valid = parser_result1->l2_s.svlan_id_valid;
            acl_qos_key_info.cvlan_id_valid = parser_result1->l2_s.cvlan_id_valid;
        }
        else
        {
            acl_qos_key_info.svlan_id = parser_result->l2_s.svlan_id;
            acl_qos_key_info.cvlan_id = parser_result->l2_s.cvlan_id;
            acl_qos_key_info.svlan_id_valid = parser_result->l2_s.svlan_id_valid;
            acl_qos_key_info.cvlan_id_valid = parser_result->l2_s.cvlan_id_valid;
        }
    }
    else
    {
        acl_qos_key_info.svlan_id = pkt_info->svlan_id;
        acl_qos_key_info.cvlan_id = pkt_info->cvlan_id;
        acl_qos_key_info.svlan_id_valid = pkt_info->svlan_id_valid;
        acl_qos_key_info.cvlan_id_valid = pkt_info->cvlan_id_valid;
    }

    acl_qos_key_info.routed_packet = ip_routed_packet;
    acl_qos_key_info.vlan_ptr = pkt_info->vlan_ptr;

    if (L3_TYPE_IPV6 == acl_qos_key_info.layer3_type && !acl_qos_key_info.is_tcp && !acl_qos_key_info.is_udp)
    {
        acl_qos_key_info.l4_dest_port = acl_qos_key_info.l4_info_mapped & 0xFFF;
    }

    if (L3_TYPE_IPV4 == acl_qos_key_info.layer3_type)
    {
        acl_qos_key_info.ipv4_packet = TRUE;
    }

    /* ACL_QOS_LOOKUP */
    acl_en = (l2_acl_en0 || l3_acl_en0) || (l2_acl_en1 || l3_acl_en1)
             || (l2_acl_en2 || l3_acl_en2) || (l2_acl_en3 || l3_acl_en3);

    acl_qos_key_info.acl_en = acl_en;

    ipv6_acl_en = (l2_ipv6_acl_en0 || l3_ipv6_acl_en0) || (l2_ipv6_acl_en1 || l3_ipv6_acl_en1);

    /* All acl information use temp information */
    is_ipv4_or_mpls = (L3_TYPE_IPV4 == acl_qos_key_info.layer3_type)
                      || (L3_TYPE_MPLS == acl_qos_key_info.layer3_type)
                      || (L3_TYPE_MPLSMCAST == acl_qos_key_info.layer3_type);

    is_ipv6 = (L3_TYPE_IPV6 == acl_qos_key_info.layer3_type);

    err_free = ((!acl_qos_key_info.ip_header_error)
                    && ((L3_TYPE_IPV4 == acl_qos_key_info.layer3_type) || (L3_TYPE_IPV6 == acl_qos_key_info.layer3_type)))
                || (L3_TYPE_MPLS == acl_qos_key_info.layer3_type)
                || (L3_TYPE_MPLSMCAST== acl_qos_key_info.layer3_type);

    /* ACL TCAM lookup */
    if ((is_ipv4_or_mpls
        && (!pkt_info->force_acl_qos_ipv4_to_mac_key || ipe_lookup_ctl.merge_mac_ip_acl_key)
        && acl_en && err_free)
        || (is_ipv6
        && (!pkt_info->force_acl_qos_ipv6_to_mac_key || ipe_lookup_ctl.merge_mac_ip_acl_key)
        && ipv6_acl_en && err_free)
        || (!is_ipv4_or_mpls && !is_ipv6 && ipe_lookup_ctl.merge_mac_ip_acl_key && (acl_en || ipv6_acl_en)))
    {
        /* use IP key */
        if (ipv6_acl_en &&
            (((L3_TYPE_IPV6 == acl_qos_key_info.layer3_type) || pkt_info->force_ipv6_key) ||
            ((L3_TYPE_TRILL == acl_qos_key_info.layer3_type) && ipe_lookup_ctl.trill_use_ipv6_key) ||
            ((L3_TYPE_ARP == acl_qos_key_info.layer3_type) && ipe_lookup_ctl.arp_use_ipv6_key) ||
            ((L3_TYPE_IPV4 != acl_qos_key_info.layer3_type) && (L3_TYPE_MPLS != acl_qos_key_info.layer3_type)
            && (L3_TYPE_MPLSMCAST != acl_qos_key_info.layer3_type) && ipe_lookup_ctl.non_ip_mpls_use_ipv6_key)))
        {
            /* ACL IPv6 key */
            pkt_info->acl_en0 = l2_ipv6_acl_en0 || l3_ipv6_acl_en0;
            pkt_info->acl_en1 = l2_ipv6_acl_en1 || l3_ipv6_acl_en1;

            if (!pkt_info->service_acl_qos_en && pkt_info->ipv6_key_use_label)
            {
                acl_qos_key_info.acl_label_low = ((pkt_info->l3_acl_label & 0x3FF) << 10)
                                                 | (pkt_info->l2_acl_label & 0x3FF);
                acl_qos_key_info.acl_label_high = 0;
            }

            tcam_key_type = (1 << 6) | (pkt_info->acl_en0 << 5) | (pkt_info->acl_en1 << 4)
                            | (pkt_info->acl_en2 << 3) | (pkt_info->acl_en3 << 2);

            acl_qos_key_info.sub_tbl_id = (ipe_lookup_ctl.acl_qos_lookup_ctl0 & 0x3);
            _cm_ipe_lookup_manager_construct_aclqosipv6_key(&ds_acl_qos_ipv6_key, &acl_qos_key_info);

            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
            /* do search */
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.acl_qos_lookup_ctl0 >> 2) & 0x3;   /* keySize */
            tcam_lookup_info.tcam_key_type = tcam_key_type & 0x7F;
            tcam_lookup_info.tcam_key = &ds_acl_qos_ipv6_key;

            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->acl_data0;
            tcam_lookup_result.tcam_lkp_output[1].ds_ad = pkt_info->acl_data1;
            tcam_lookup_result.tcam_lkp_output[2].ds_ad = pkt_info->acl_data2;
            tcam_lookup_result.tcam_lkp_output[3].ds_ad = pkt_info->acl_data3;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
        }
        else if (L3_TYPE_IPV4 == acl_qos_key_info.layer3_type)
        {
            /* ACL IPv4 key */
            pkt_info->acl_en0 = l2_acl_en0 || l3_acl_en0;
            pkt_info->acl_en1 = l2_acl_en1 || l3_acl_en1;
            pkt_info->acl_en2 = l2_acl_en2 || l3_acl_en2;
            pkt_info->acl_en3 = l2_acl_en3 || l3_acl_en3;

            if (!pkt_info->service_acl_qos_en && pkt_info->ipv4_key_use_label)
            {
                acl_qos_key_info.acl_label_low = (pkt_info->l3_acl_label << 10) | pkt_info->l2_acl_label;
                acl_qos_key_info.acl_label_high = 0;
            }

            tcam_key_type = (1 << 6) | (pkt_info->acl_en0 << 5) | (pkt_info->acl_en1 << 4)
                            | (pkt_info->acl_en2 << 3) | (pkt_info->acl_en3 << 2) | 1;

            acl_qos_key_info.sub_tbl_id = ipe_lookup_ctl.acl_qos_lookup_ctl1 & 0x3;
            _cm_ipe_lookup_manager_construct_aclqosipv4_key(&ds_acl_qos_ipv4_key, &acl_qos_key_info);

            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
            /* do search */
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.acl_qos_lookup_ctl1 >> 2) & 0x3;   /* keySize */
            tcam_lookup_info.tcam_key_type = tcam_key_type & 0x7F;
            tcam_lookup_info.tcam_key = &ds_acl_qos_ipv4_key;

            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->acl_data0;
            tcam_lookup_result.tcam_lkp_output[1].ds_ad = pkt_info->acl_data1;
            tcam_lookup_result.tcam_lkp_output[2].ds_ad = pkt_info->acl_data2;
            tcam_lookup_result.tcam_lkp_output[3].ds_ad = pkt_info->acl_data3;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
        }
        else if ((L3_TYPE_MPLS == acl_qos_key_info.layer3_type) || (L3_TYPE_MPLSMCAST == acl_qos_key_info.layer3_type))
        {
            /* MPLS key, shared with IPv4 */
            pkt_info->acl_en0 = l2_acl_en0 || l3_acl_en0;
            pkt_info->acl_en1 = l2_acl_en1 || l3_acl_en1;
            pkt_info->acl_en2 = l2_acl_en2 || l3_acl_en2;
            pkt_info->acl_en3 = l2_acl_en3 || l3_acl_en3;

            if (!pkt_info->service_acl_qos_en && pkt_info->mpls_key_use_label)
            {
                acl_qos_key_info.acl_label_low = ((pkt_info->l3_acl_label & 0x3FF) << 10)
                                                 | (pkt_info->l2_acl_label & 0x3FF);

                acl_qos_key_info.acl_label_high = 0;
            }

            tcam_key_type = (1 << 6) | (pkt_info->acl_en0 << 5) | (pkt_info->acl_en1 << 4)
                            | (pkt_info->acl_en2 << 3) | (pkt_info->acl_en3 << 2) | 1;

            acl_qos_key_info.sub_tbl_id = ipe_lookup_ctl.acl_qos_lookup_ctl3 & 0x3;
            _cm_ipe_lookup_manager_construct_aclqosmpls_key(&ds_acl_qos_mpls_key, &acl_qos_key_info);

            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
            /* do search */
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.acl_qos_lookup_ctl3 >> 2) & 0x3;   /* keySize */
            tcam_lookup_info.tcam_key_type = tcam_key_type & 0x7F;
            tcam_lookup_info.tcam_key = &ds_acl_qos_mpls_key;

            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->acl_data0;
            tcam_lookup_result.tcam_lkp_output[1].ds_ad = pkt_info->acl_data1;
            tcam_lookup_result.tcam_lkp_output[2].ds_ad = pkt_info->acl_data2;
            tcam_lookup_result.tcam_lkp_output[3].ds_ad = pkt_info->acl_data3;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
        }
        else if (acl_en)
        {
            /* IPV4 key, fix humber merge IP/MAC key bug */
            pkt_info->acl_en0 = l2_acl_en0 || l3_acl_en0;
            pkt_info->acl_en1 = l2_acl_en1 || l3_acl_en1;
            pkt_info->acl_en2 = l2_acl_en2 || l3_acl_en2;
            pkt_info->acl_en3 = l2_acl_en3 || l3_acl_en3;

            if (!pkt_info->service_acl_qos_en && pkt_info->ipv4_key_use_label)
            {
                acl_qos_key_info.acl_label_low = (pkt_info->l3_acl_label << 10) | pkt_info->l2_acl_label;
                acl_qos_key_info.acl_label_high = 0;
            }

            tcam_key_type = (1 << 6) | (pkt_info->acl_en0 << 5) | (pkt_info->acl_en1 << 4)
                            | (pkt_info->acl_en2 << 3) | (pkt_info->acl_en3 << 2) | 1;

            acl_qos_key_info.sub_tbl_id = ipe_lookup_ctl.acl_qos_lookup_ctl1 & 0x3;
            _cm_ipe_lookup_manager_construct_aclqosipv4_key(&ds_acl_qos_ipv4_key, &acl_qos_key_info);

            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));

            /* do search */
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.acl_qos_lookup_ctl1 >> 2) & 0x3;   /* keySize */
            tcam_lookup_info.tcam_key_type = tcam_key_type & 0x7F;
            tcam_lookup_info.tcam_key = &ds_acl_qos_ipv4_key;

            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->acl_data0;
            tcam_lookup_result.tcam_lkp_output[1].ds_ad = pkt_info->acl_data1;
            tcam_lookup_result.tcam_lkp_output[2].ds_ad = pkt_info->acl_data2;
            tcam_lookup_result.tcam_lkp_output[3].ds_ad = pkt_info->acl_data3;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
        }
        else
        {
            /* do nothing */
        }
    }
    else if (acl_en)
    {
        /* ACL Mac key */
        pkt_info->acl_en0 = l2_acl_en0 || l3_acl_en0;
        pkt_info->acl_en1 = l2_acl_en1 || l3_acl_en1;
        pkt_info->acl_en2 = l2_acl_en2 || l3_acl_en2;
        pkt_info->acl_en3 = l2_acl_en3 || l3_acl_en3;

        if (!pkt_info->service_acl_qos_en && pkt_info->mac_key_use_label)
        {
            acl_qos_key_info.acl_label_low = (pkt_info->l3_acl_label << 10) | pkt_info->l2_acl_label;
            acl_qos_key_info.acl_label_high = 0;
        }

        tcam_key_type = (1 << 6) | (pkt_info->acl_en0 << 5) | (pkt_info->acl_en1 << 4)
                        | (pkt_info->acl_en2 << 3) | (pkt_info->acl_en3 << 2) | 2;

        acl_qos_key_info.sub_tbl_id = ipe_lookup_ctl.acl_qos_lookup_ctl2 & 0x3;
        _cm_ipe_lookup_manager_construct_aclqosmac_key(&ds_acl_qos_mac_key, &acl_qos_key_info);

        sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
        sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
        /* do search */
        tcam_lookup_info.chip_id = in_pkt->chip_id;
        tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.acl_qos_lookup_ctl2 >> 2) & 0x3;   /* keySize */
        tcam_lookup_info.tcam_key_type = tcam_key_type & 0x7F;
        tcam_lookup_info.tcam_key = &ds_acl_qos_mac_key;

        tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->acl_data0;
        tcam_lookup_result.tcam_lkp_output[1].ds_ad = pkt_info->acl_data1;
        tcam_lookup_result.tcam_lkp_output[2].ds_ad = pkt_info->acl_data2;
        tcam_lookup_result.tcam_lkp_output[3].ds_ad = pkt_info->acl_data3;

        DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
    }

    /* ACL hash lookup */
    if ((l2_acl_en0 || l3_acl_en0) && ipe_lookup_ctl.acl_hash_lookup_en)
    {
        pkt_info->acl_hash_lookup_en = TRUE;

        sal_memset(&fib_key, 0, sizeof(fib_key_t));
        sal_memset(&fib_result, 0, sizeof(lookup_result_t));
        sal_memset(&push_info, 0, sizeof(push_info_t));

        push_info.data = pkt_info->acl_hash_data;
        fib_result.extra = &push_info;

        fib_key.key.acl.is_logic_port = pkt_info->service_acl_qos_en;
        if (L3_TYPE_IPV4 == acl_qos_key_info.layer3_type)
        {
            fib_key.key.acl.ip_da = acl_qos_key_info.ipv4_da;
            fib_key.key.acl.ip_sa = acl_qos_key_info.ipv4_sa;
            fib_key.key.acl.dscp = acl_qos_key_info.dscp;
            fib_key.key.acl.l4_dest_port = acl_qos_key_info.l4_dest_port;
            fib_key.key.acl.l4_source_port = acl_qos_key_info.l4_source_port;
            fib_key.key.acl.layer3_header_protocol = acl_qos_key_info.layer3_header_protocol;
            if (pkt_info->service_acl_qos_en)
            {
                fib_key.key.acl.global_src_port = pkt_info->logic_src_port;
            }
            else
            {
                fib_key.key.acl.global_src_port = pkt_info->global_src_port;
            }
            fib_key.key.acl.is_ipv4_key = TRUE;
            fib_key.key.acl.is_arp_key = FALSE;
        }
        else if (L3_TYPE_ARP == acl_qos_key_info.layer3_type)
        {
            fib_key.key.acl.ip_da = acl_qos_key_info.ipv4_da;
            fib_key.key.acl.ip_sa = acl_qos_key_info.ipv4_sa;
            if (pkt_info->service_acl_qos_en)
            {
                fib_key.key.acl.global_src_port = pkt_info->logic_src_port;
            }
            else
            {
                fib_key.key.acl.global_src_port = pkt_info->global_src_port;
            }
            fib_key.key.acl.dscp = 0;
            fib_key.key.acl.l4_dest_port = 0;
            fib_key.key.acl.layer3_header_protocol = 0;
            fib_key.key.acl.l4_source_port = acl_qos_key_info.arp_op_code;
            fib_key.key.acl.is_ipv4_key = TRUE;
            fib_key.key.acl.is_arp_key = TRUE;
        }
        else
        {
            fib_key.key.acl.is_ipv4_key = FALSE;
            fib_key.key.acl.mapped_mac31_0 = MAKE_UINT32(acl_qos_key_info.mac_da[3],
                                                         acl_qos_key_info.mac_da[2],
                                                         acl_qos_key_info.mac_da[1],
                                                         acl_qos_key_info.mac_da[0]);

            fib_key.key.acl.mapped_mac47_32 = MAKE_UINT16(acl_qos_key_info.mac_da[5],
                                                          acl_qos_key_info.mac_da[4]);

            fib_key.key.acl.ether_type = acl_qos_key_info.ether_type;
            fib_key.key.acl.vlan_id = (acl_qos_key_info.svlan_id_valid)?(acl_qos_key_info.svlan_id):(acl_qos_key_info.cvlan_id);

            if (pkt_info->service_acl_qos_en)
            {
                fib_key.key.acl.global_src_port = pkt_info->logic_src_port;
            }
            else
            {
                fib_key.key.acl.global_src_port = pkt_info->global_src_port;
            }
            fib_key.key.acl.is_arp_key = FALSE;

            if (acl_qos_key_info.svlan_id_valid)
            {
                fib_key.key.acl.cos = acl_qos_key_info.stag_cos;
            }
            else
            {
                fib_key.key.acl.cos = acl_qos_key_info.ctag_cos;
            }
        }

        DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key,
                                                                   fib_key_type, &fib_result));
    }

    pkt_info->acl_tcam_result_valid0 = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
    pkt_info->acl_tcam_result_valid1 = tcam_lookup_result.tcam_lkp_output[1].tcam_lkp_result_valid;
    pkt_info->acl_tcam_result_valid2 = tcam_lookup_result.tcam_lkp_output[2].tcam_lkp_result_valid;
    pkt_info->acl_tcam_result_valid3 = tcam_lookup_result.tcam_lkp_output[3].tcam_lkp_result_valid;
    pkt_info->acl_hash_result_valid = push_info.valid;

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_ipe_lookup_manager_parser_result_info
 * Purpose:    IPE lookup management get MAC lookup resutl handle.
 * Parameters:
 *  Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                               header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                                header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *                Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_lookup_manager_parser_result_info(ipe_in_pkt_t *in_pkt, lookup_manager_info_t* p_lkp_mgr_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t*  parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t*  parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;
    uint8 chip_id = in_pkt->chip_id;
    ipe_route_ctl_t ipe_route_ctl;
    ipe_lookup_route_ctl_t ipe_lkp_route_ctl;
    ipe_lookup_ctl_t ipe_lookup_ctl;
    ipe_exception3_ctl_t ipe_exception3_ctl;

    uint32 cmd = 0;
    uint8 exception_escape_cam_hit = 0, exception_escape_cam_hit2 = 0;
    uint8 exception_sub_index = 0, exception_sub_index2 = 0;
    uint8 is_ipv4_martian_address = FALSE, ipv4_rule_martian_address = FALSE;
    uint8 is_6_to_4 = FALSE;
    uint8 is_sa_v4_mapped = FALSE;
    uint8 is_sa_v4_compatible = FALSE;
    uint8 martian_check_en = FALSE;
    uint8 is_sa_mcast = FALSE;
    uint8 is_sa_loop_back = FALSE;
    uint8 is_martian_address_11 = FALSE;
    uint8 is_martian_address_12 = FALSE;
    uint8 is_martian_address_13 = FALSE;
    uint8 is_martian_address_14 = FALSE;
    uint8 is_martian_address_15 = FALSE;
    uint8 is_martian_address_16 = FALSE;
    uint8 is_icmp = FALSE;
    uint32 mac_da = 0;
    uint32 v4_ip_sa = 0;
    uint16 gre_protocol = 0;

    sal_memset(&ipe_route_ctl, 0, sizeof(ipe_route_ctl));
    cmd = DRV_IOR(IpeRouteCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_route_ctl));

    sal_memset(&ipe_lkp_route_ctl, 0, sizeof(ipe_lkp_route_ctl));
    cmd = DRV_IOR(IpeLookupRouteCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_lkp_route_ctl));

    sal_memset(&ipe_lookup_ctl, 0, sizeof(ipe_lookup_ctl));
    cmd = DRV_IOR(IpeLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_lookup_ctl));

    if (!pkt_info->inner_packet_lookup)
    {
        pkt_info->classify_tos = parser_result->l3_s.tos.ip_tos;
        pkt_info->classify_layer3_type = parser_result->layer3_type;

        pkt_info->classify_source_cos = pkt_info->source_cos;
        pkt_info->classify_source_cfi = pkt_info->source_cfi;
    }
    else if (pkt_info->inner_packet_lookup && (!pkt_info->acl_qos_use_outer_info))
    {
        pkt_info->classify_tos = parser_result->l3_s.tos.ip_tos;
        pkt_info->classify_layer3_type = parser_result->layer3_type;
        if (parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->classify_source_cos = parser_result->l2_s.stag_cos;
            pkt_info->classify_source_cfi = parser_result->l2_s.stag_cfi;
        }
        else if (parser_result->l2_s.cvlan_id_valid)
        {
            pkt_info->classify_source_cos = parser_result->l2_s.ctag_cos;
            pkt_info->classify_source_cfi = parser_result->l2_s.ctag_cfi;
        }
        else
        {
            pkt_info->classify_source_cos = pkt_info->default_pcp;
            pkt_info->classify_source_cfi = pkt_info->default_dei;
        }

        if (parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->classify_stag_cos = parser_result->l2_s.stag_cos;
            pkt_info->classify_stag_cfi = parser_result->l2_s.stag_cfi;
        }
        else
        {
            pkt_info->classify_stag_cos = pkt_info->default_pcp;
            pkt_info->classify_stag_cfi = pkt_info->default_dei;
        }

        if (parser_result->l2_s.cvlan_id_valid)
        {
            pkt_info->classify_ctag_cos = parser_result->l2_s.ctag_cos;
            pkt_info->classify_ctag_cfi = parser_result->l2_s.ctag_cfi;
        }
        else
        {
            pkt_info->classify_ctag_cos = pkt_info->default_pcp;
            pkt_info->classify_ctag_cfi = pkt_info->default_dei;
        }
    }
    else
    {
        pkt_info->classify_tos = parser_result1->l3_s.tos.ip_tos;
        pkt_info->classify_layer3_type = parser_result1->layer3_type;

        pkt_info->classify_source_cos = pkt_info->source_cos;
        pkt_info->classify_source_cfi = pkt_info->source_cfi;
    }

    if (pkt_info->use_default_vlan_tag)
    {
        pkt_info->svlan_id = pkt_info->user_default_vlan_id;
        pkt_info->source_cos = pkt_info->user_default_cos;
        pkt_info->source_cfi = pkt_info->user_default_cfi;
    }

    if ((L3_TYPE_TRILL == parser_result1->layer3_type) && pkt_info->is_decap
        && pkt_info->inner_packet_lookup)
    {
        if (ipe_lookup_ctl.trill_use_inner_vlan)
        {
            pkt_info->svlan_id = p_lkp_mgr_info->trill_inner_vlan;
        }

        if (parser_result1->l3_s.ip_da.trill.trill_inner_vlan_valid)
        {
            pkt_info->vlan_ptr = p_lkp_mgr_info->trill_inner_vlan;
        }
        else
        {
            pkt_info->vlan_ptr = pkt_info->vsi_id;
        }
    }

    pkt_info->app_data_valid = parser_result1->l4_s.app_data_valid0 || parser_result1->l4_s.app_data_valid1;
    pkt_info->isatap_check_ok = (parser_result->l3_s.ip_sa.ipv4.ipsa ==
                                ((parser_result->l4_s.l4_src_port.l4_source_port << 16)
                                  | parser_result->l4_s.l4_dst_port.l4_dest_port));

    pkt_info->ip_header_error = parser_result->l3_s.ip_header_error;
    pkt_info->igmp_packet = (L4_TYPE_IGMP == parser_result->layer4_type)
               || ((parser_result->l3_s.layer3_header_protocol == 103)
                   && (((parser_result->l4_s.l4_src_port.l4_source_port>>8)&0xF)== 0)
                   && ipe_lookup_ctl.pim_snooping_en);
    pkt_info->ipv4_mcast_address = ((0xE == (parser_result->l3_s.ip_da.ipv4.ipda >> 28)) && (L3_TYPE_IPV4 == parser_result->layer3_type));
    pkt_info->ipv6_mcast_address = ((0xFF == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24)) && (L3_TYPE_IPV6 == parser_result->layer3_type));

    pkt_info->cmac_ecmp_hash = parser_result1->l3_s.ip_sa.cmac.cmac_ecmp_hash;
    pkt_info->cmac_header_hash = parser_result1->l3_s.ip_sa.cmac.cmac_header_hash;
    pkt_info->mac_ecmp_hash = parser_result1->l2_s.mac_ecmp_hash;

    pkt_info->ecn_en = (((L3_TYPE_IPV4 == parser_result->layer3_type)
                            || (L3_TYPE_IPV6 == parser_result->layer3_type))
                       && ((parser_result->l3_s.tos.ip_tos & 0x3)));
    pkt_info->ecn_priority_en = ((L3_TYPE_IPV4 == parser_result->layer3_type)
                                    || (L3_TYPE_IPV6 == parser_result->layer3_type))
                                && ((3 == (parser_result->l3_s.tos.ip_tos & 0x3))
                                    || (parser_result->l4_s.is_tcp &&
                                      (parser_result->l4_s.rid_ptp_bfd.tcp_ecn.tcp_ecn != 0)));
    pkt_info->ecn_aware = (((L3_TYPE_IPV4 == parser_result->layer3_type)
                                || (L3_TYPE_IPV6 == parser_result->layer3_type)))
                          && IS_BIT_SET(ipe_lookup_ctl.ecn_aware, parser_result->layer4_type);

    pkt_info->bfd_single_hop_ttl_match = (parser_result->l3_s.ttl == ipe_lookup_ctl.bfd_single_hop_ttl);
    pkt_info->is_mpls_packet = (parser_result1->layer3_type == L3_TYPE_MPLS)
                               || (parser_result1->layer3_type == L3_TYPE_MPLSMCAST);
    pkt_info->trill_version_match = (ipe_lookup_ctl.trill_version == parser_result->l3_s.ip_da.trill.trill_version);

    if (parser_result->layer3_type == L3_TYPE_IPV4)
    {
        DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_ipv4_martian_addr(chip_id, parser_result->l3_s.ip_sa.ipv4.ipsa,
                                                    &is_ipv4_martian_address));

        pkt_info->ip_martian_address = is_ipv4_martian_address;
    }

    /*
     * 6to4 IPv6 address hash the form of 2002:V4ADDR::/48,IpSa[127:112] == 0x2002;
     * v4Mapped IPv6 address hash the form of 0:0:0:0:0:FFFF:/w.x.y.z/ or ::FFFF:/w.x.y.z/,
     * IpSa[127:48] == 80'b0, IpSa[47:32] == 0xFFFF;
     * v4 Compatible IPv6 address hash the form of 0:0:0:0:0:0:0:/w.x.y.z/ or ::/w.x.y.z/, IpSa[127:32] == 0;
     */

    is_6_to_4 = (0x2002 == (parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 >> 16));

    if (is_6_to_4)
    {
        v4_ip_sa = ((parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 & 0xFFFF) << 16)
                    | (parser_result->l3_s.ip_sa.ipv6.ipsa_95_64 >> 16);
    }
    else
    {
        v4_ip_sa = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
    }

    DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_ipv4_martian_addr(chip_id, v4_ip_sa, &is_ipv4_martian_address));

    is_sa_v4_mapped = (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96)
                      && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_95_64)
                      && (0xFFFF == parser_result->l3_s.ip_sa.ipv6.ipsa_63_32);

    is_sa_v4_compatible = (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96)
                          && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_95_64)
                          && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_63_32);

    martian_check_en = (ipe_lkp_route_ctl.martian_check_en_high << 6) | ipe_lkp_route_ctl.martian_check_en_low;

    is_sa_mcast = (0xFF == (parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 >> 24));

    is_sa_loop_back = (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96)
                       && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_95_64)
                       && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_63_32)
                       && (1 == parser_result->l3_s.ip_sa.ipv6.ipsa_31_0);

    /* 64:ff9b:: */
    is_martian_address_11 = ((0x64FF9B == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96)
                             && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_95_64)
                             && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_63_32))
                             || ((0x64FF9B == parser_result->l3_s.ip_da.ipv6.ipda_127_96)
                             && (0 == parser_result->l3_s.ip_da.ipv6.ipda_95_64)
                             && (0 == parser_result->l3_s.ip_da.ipv6.ipda_63_32));

    is_martian_address_12 = (0x3FFE == (parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 >> 16))
                             || (0x3FFE == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 16));

    is_martian_address_13 = (0x5F == (parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 >> 24))
                             || (0x5F == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24));

    /* 2001:10:: */
    is_martian_address_14 = (0x2001001 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 >> 4)
                             || (0x2001001 == parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 4);

    /* 2001:db8 */
    is_martian_address_15 = (0x20010DB8 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96)
                             || (0x20010DB8 == parser_result->l3_s.ip_da.ipv6.ipda_127_96);

    is_martian_address_16 = (0x7E == (parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 >> 25))
                             || (0x7E == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 25));

    ipv4_rule_martian_address
        = ((is_6_to_4 && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 0))
            || (is_sa_v4_mapped && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 1))
            || (is_sa_v4_compatible && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 2)))
          && is_ipv4_martian_address;

    if (L3_TYPE_IPV6 == parser_result->layer3_type)
    {
        /*
         * ipSa is multicast: ipSa[127:120] == 8'hFF;
         * ipSa is loopback: ipSa[127:0] == {127'h0, 1'b1};
         */
        pkt_info->ip_martian_address = (!ipe_lkp_route_ctl.martian_address_check_disable)
                                   && ((is_sa_mcast && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 3))
                                   || (is_sa_loop_back && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 4))
                                   || (is_martian_address_11 && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 5))
                                   || (is_martian_address_12 && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 6))
                                   || (is_martian_address_13 && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 7))
                                   || (is_martian_address_14 && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 8))
                                   || (is_martian_address_15 && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 9))
                                   || (is_martian_address_16 && IS_BIT_SET(ipe_lkp_route_ctl.martian_check_en_high, 10))
                                   || ipv4_rule_martian_address);
    }

    /* link scope ipSa/ipDa[127:118] == 10'b1111111010;*/
    pkt_info->ip_link_scope_address = (parser_result->layer3_type == L3_TYPE_IPV6)
                        &&((0x3FA == (parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 >> 22))
                            || (0x3FA == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 22))
                            || ((0x0 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96)
                                 && (0x0 == parser_result->l3_s.ip_sa.ipv6.ipsa_95_64)
                                 && (0x0 == parser_result->l3_s.ip_sa.ipv6.ipsa_63_32)
                                 && (0x0 == parser_result->l3_s.ip_sa.ipv6.ipsa_31_0)));/* only unicast link scope */

    pkt_info->is_all_rbridge_address = ((parser_result->l2_s.mac_da5 == 0x01)
                                     && (parser_result->l2_s.mac_da4 == 0x80)
                                     && (parser_result->l2_s.mac_da3 == 0xC2)
                                     && (parser_result->l2_s.mac_da2 == 0x00)
                                     && (parser_result->l2_s.mac_da1 == 0x00)
                                     && (parser_result->l2_s.mac_da0 == 0x40));

    is_icmp = (L4_TYPE_ICMP == parser_result->layer4_type);
    pkt_info->is_icmp = is_icmp;

    pkt_info->is_ipv4_icmp_err_msg = is_icmp && ((3 == (parser_result->l4_s.l4_src_port.l4_source_port >> 8))
                                     || (4 == (parser_result->l4_s.l4_src_port.l4_source_port >> 8))
                                     || (11 == (parser_result->l4_s.l4_src_port.l4_source_port >> 8))
                                     || (12 == (parser_result->l4_s.l4_src_port.l4_source_port >> 8)));

    pkt_info->is_ipv6_icmp_err_msg = is_icmp && !IS_BIT_SET(parser_result->l4_s.l4_src_port.l4_source_port, 15);

    if (!pkt_info->is_decap && !pkt_info->is_mpls_switched)
    {
        mac_da = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                             parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);

        pkt_info->ipv4_mcast_address_check_failure
                = IS_BIT_SET(parser_result->l2_s.mac_da5, 0)
                  && (((mac_da & 0x7FFFFF) != (parser_result->l3_s.ip_da.ipv4.ipda & 0x7FFFFF))
                      || IS_BIT_SET(parser_result->l2_s.mac_da2, 7)
                      || (!((0x5E == parser_result->l2_s.mac_da3)
                          && (0 == parser_result->l2_s.mac_da4)
                          && (0x1 == parser_result->l2_s.mac_da5))));

        pkt_info->ipv6_mcast_address_check_failure
                = IS_BIT_SET(parser_result->l2_s.mac_da5, 0)
                  && ((mac_da != parser_result->l3_s.ip_da.ipv6.ipda_31_0)
                     || (0x3333 != MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4)));
    }
    else
    {
        pkt_info->ipv4_mcast_address_check_failure = FALSE;
        pkt_info->ipv6_mcast_address_check_failure = FALSE;
    }

    gre_protocol = parser_result->l4_s.l4_dst_port.gre_protocol_type;

    pkt_info->unknown_gre_protocol = ((0x0800 != gre_protocol) && (0x6558 != gre_protocol)
                                     && (0x86DD != gre_protocol) && (0x8847 != gre_protocol)
                                     && (ipe_lookup_ctl.gre_flex_protocol != gre_protocol)
                                     && (0x8848 != gre_protocol));

    switch (gre_protocol)
    {
        case 0x0800:
          pkt_info->gre_payload_packet_type = PKT_TYPE_IPV4;    /* ipv4 */
          break;
        case 0x86DD:
          pkt_info->gre_payload_packet_type = PKT_TYPE_IPV6;    /* ipv6 */
          break;
        case 0x6558:
          pkt_info->gre_payload_packet_type = PKT_TYPE_ETHERNETV2;  /* ethernet */
          break;
        case 0x8847:
          pkt_info->gre_payload_packet_type = PKT_TYPE_MPLS;    /* mpls unicast */
          break;
        case 0x8848:
          pkt_info->gre_payload_packet_type = PKT_TYPE_MCAST_MPLS;  /* mpls multicast */
          break;
        default:
          pkt_info->gre_payload_packet_type = ipe_lookup_ctl.gre_flex_payload_packet_type;
          break;
    }

    sal_memset(&ipe_exception3_ctl, 0, sizeof(ipe_exception3_ctl));
    cmd = DRV_IOR(IpeException3Ctl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_exception3_ctl));

    if (L3_TYPE_IPV4 == parser_result->layer3_type || L3_TYPE_IPV6 == parser_result->layer3_type)
    {
        DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_exception3_cam_lookup(chip_id,
                                    parser_result->l3_s.layer3_header_protocol,
                                    &exception_escape_cam_hit, &exception_sub_index));

        DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_exception3_cam_lookup2(chip_id, parser_result->l4_s.is_udp,
                                    parser_result->l4_s.is_tcp, parser_result->l4_s.l4_dst_port.l4_dest_port,
                                    &exception_escape_cam_hit2, &exception_sub_index2));

        if (parser_result->l4_s.is_udp
            && ((520 == parser_result->l4_s.l4_dst_port.l4_dest_port)
                || (521 == parser_result->l4_s.l4_dst_port.l4_dest_port))
            && ipe_exception3_ctl.rip_exception_en)
        {
            /* RIP */
            pkt_info->layer3_exception = TRUE;
            pkt_info->layer3_exception_sub_index = ipe_exception3_ctl.rip_exception_sub_index;
        }
        else if ((89 == parser_result->l3_s.layer3_header_protocol) && ipe_exception3_ctl.ospf_exception_en)
        {
            /* OSPF */
            pkt_info->layer3_exception = TRUE;
            pkt_info->layer3_exception_sub_index = ipe_exception3_ctl.ospf_exception_sub_index;
        }
        else if (parser_result->l4_s.is_tcp
                 && (179 == parser_result->l4_s.l4_dst_port.l4_dest_port)
                 && ipe_exception3_ctl.bgp_exception_en)
        {
            /* BGP */
            pkt_info->layer3_exception = TRUE;
            pkt_info->layer3_exception_sub_index = ipe_exception3_ctl.bgp_exception_sub_index;
        }
        else if ((103 == parser_result->l3_s.layer3_header_protocol) && ipe_exception3_ctl.pim_exception_en)
        {
            /* PIM */
            pkt_info->layer3_exception = TRUE;
            pkt_info->layer3_exception_sub_index = ipe_exception3_ctl.pim_exception_sub_index;
        }
        else if ((112 == parser_result->l3_s.layer3_header_protocol) && ipe_exception3_ctl.vrrp_exception_en)
        {
            /* VRRP */
            pkt_info->layer3_exception = TRUE;
            pkt_info->layer3_exception_sub_index = ipe_exception3_ctl.vrrp_exception_sub_index;
        }
        else if ((46 == parser_result->l3_s.layer3_header_protocol) && ipe_exception3_ctl.rsvp_exception_en)
        {
            /* RSVP */
            pkt_info->layer3_exception = TRUE;
            pkt_info->layer3_exception_sub_index = ipe_exception3_ctl.rsvp_exception_sub_index;
        }
        else if (parser_result->l4_s.is_tcp
                && (639 == parser_result->l4_s.l4_dst_port.l4_dest_port)
                && ipe_exception3_ctl.msdp_exception_en)
        {
            /* MSDP */
            pkt_info->layer3_exception = TRUE;
            pkt_info->layer3_exception_sub_index = ipe_exception3_ctl.msdp_exception_sub_index;
        }
        else if ((parser_result->l4_s.is_udp || parser_result->l4_s.is_tcp)
                 && (646 == parser_result->l4_s.l4_dst_port.l4_dest_port)
                 && ipe_exception3_ctl.ldp_exception_en)
        {
            /* LDP */
            pkt_info->layer3_exception = TRUE;
            pkt_info->layer3_exception_sub_index = ipe_exception3_ctl.ldp_exception_sub_index;
        }
        else if (exception_escape_cam_hit && ipe_exception3_ctl.exception_cam_en)
        {
            pkt_info->layer3_exception = TRUE;
            pkt_info->layer3_exception_sub_index = exception_sub_index;
        }
        else if (exception_escape_cam_hit2 && ipe_exception3_ctl.exception_cam_en2)
        {
            pkt_info->layer3_exception = TRUE;
            pkt_info->layer3_exception_sub_index = exception_sub_index2;
        }
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:      _cm_ipe_lookup_manager_default
 * Purpose:   IPE lookup management set default lookup info.
 * Parameters:
 *  Input:    in_pkt  -- pointer to buffer which save input packet and packet
 *                         header ,and processing informations
 *            p_lkp_mgr_info -- used to store lookup manager local parameter
 * Output:    in_pkt  -- pointer to buffer which save input packet and packet
 *                         header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
 ****************************************************************************/
int32
_cm_ipe_lookup_manager_default(ipe_in_pkt_t *in_pkt, lookup_manager_info_t* p_lkp_mgr_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t* parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;
    uint8 trill_inner_vlan_invalid = FALSE;
    ipe_lookup_ctl_t ipe_lookup_ctl;
    uint32 cmd = 0;

    sal_memset(&ipe_lookup_ctl, 0, sizeof(ipe_lookup_ctl_t));
    cmd = DRV_IOR(IpeLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_lookup_ctl));

    /* DEFAULT */
    pkt_info->mac_da_lookup_en = FALSE;
    pkt_info->mac_sa_lookup_en = FALSE;

    p_lkp_mgr_info->stp_block
        = (STP_BLOCKING == pkt_info->stp_state) || (STP_LEARNING == pkt_info->stp_state);
    p_lkp_mgr_info->force_v4_bridge = FALSE;
    p_lkp_mgr_info->force_v6_bridge = FALSE;

    pkt_info->fid = pkt_info->vrf_id;

    if (pkt_info->tunnel_ptp_en
        && ((L3_TYPE_PTP == parser_result->layer3_type) || (L4_USER_TYPE_UDP_PTP == parser_result->l4_s.layer4_user_type)))
    {
        pkt_info->ptp_en = TRUE;
        pkt_info->self_address = TRUE;
    }

    trill_inner_vlan_invalid = (L3_TYPE_TRILL == parser_result1->layer3_type) &&
        ((parser_result1->l3_s.ip_da.trill.trill_inner_vlan_valid && (0xFFF == parser_result1->l3_s.ip_da.trill.trill_inner_vlan_id))
         || (parser_result1->l3_s.ip_da.trill.trill_inner_vlan_valid && (0 == parser_result1->l3_s.ip_da.trill.trill_inner_vlan_id))
          ||(!parser_result1->l3_s.ip_da.trill.trill_inner_vlan_valid && (ipe_lookup_ctl.trill_inner_vlan_absent_discard)));

    if (ipe_lookup_ctl.trill_inner_vlan_check && (pkt_info->is_decap || ipe_lookup_ctl.trill_lookup_check_inner)
        && trill_inner_vlan_invalid)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_TRILL_VERSION_CHK_ERR;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! trill version check error discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_ipe_lookup_manager_outer_learning_lookup
 * Purpose:   IPE lookup management lookup outer learning.
 * Parameters:
 *  Input:    in_pkt  -- pointer to buffer which save input packet and packet
 *                         header ,and processing informations
 *            p_lkp_mgr_info -- used to store lookup manager local parameter
 * Output:    in_pkt  -- pointer to buffer which save input packet and packet
 *                         header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
 ****************************************************************************/
static int32
_cm_ipe_lookup_manager_outer_learning_lookup(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t*  parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;
    parsing_result_t*  parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    ipe_lookup_ctl_t ipe_lookup_ctl;
    uint32 cmd = 0;
    fib_key_t fib_key;
    lookup_result_t fib_result;
    fib_key_type_t fib_key_type = FIB_KEY_TYPE_NUM;
    push_info_t push_info;
    tcam_key_type_t tcam_key_type = TCAM_TYPE_NUM;
    ds_mac_learning_key_t ds_mac_learning_key;
    tcam_lkp_outputs_t tcam_lookup_result;
    tcam_lkp_inputs_t tcam_lookup_info;

    uint8 outer_stp_learn_en = FALSE;
    uint8 fdb_flush_outer_learning_disable = FALSE;


    sal_memset(&ipe_lookup_ctl, 0, sizeof(ipe_lookup_ctl));
    cmd = DRV_IOR(IpeLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_lookup_ctl));

    /* Only for RTL */
    if (pkt_info->second_parser)
    {
        /* ParserResult1.{} = Parser from IPEHeaderAdjust (tunnelTerminate has done) */
        /* update each header's offset in parser */
        parser_result->layer2_offset = pkt_info->payload_offset;
        parser_result->l2_s.layer3_offset = pkt_info->payload_offset + parser_result->l2_s.layer3_offset;
        parser_result->l3_s.layer4_offset = pkt_info->payload_offset + parser_result->l3_s.layer4_offset;

        /* ParserReuslt.{...} = Parser from Tunnel(tunnelTerminate has done)  */

        if (pkt_info->ttl_update)
        {
            pkt_info->packet_ttl = parser_result->l3_s.ttl;
        }
    }
    else
    {
        /* ParserResult11.{...} = Parser from IPEHeaderAdjust;
           ParserResult.{...} = Parser from IPEHeaderAdjust(tunnelTerminate has done) */
    }

    if (parser_result->parser_length_error)
    {
        if (!IS_BIT_SET(ipe_lookup_ctl.parser_length_error_mode,1))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_PSR_LEN_ERR;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! lookupmanager:Parser length error discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if ((0 == ipe_lookup_ctl.parser_length_error_mode) && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PARSER_LEN_ERR;
        }
    }

    sal_memset(&ipe_lookup_ctl, 0, sizeof(ipe_lookup_ctl_t));
    cmd = DRV_IOR(IpeLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_lookup_ctl));
    pkt_info->mac_tcam_lookup_en = ipe_lookup_ctl.mac_tcam_lookup_en;
    pkt_info->mac_hash_lookup_en = ipe_lookup_ctl.mac_hash_lookup_en;

    fdb_flush_outer_learning_disable = ipe_lookup_ctl.fdb_flush_outer_learning_disable ||
            (!ipe_lookup_ctl.fdb_flush_vsi_learning_disable && (ipe_lookup_ctl.fdb_flush_vsi == pkt_info->vsi_id));

    outer_stp_learn_en = (STP_BLOCKING != pkt_info->stp_state)
                && (!pkt_info->learning_disable); /* not in blocking state*/
    pkt_info->outer_mac_sa_lookup_en = !ipe_lookup_ctl.learning_disable && outer_stp_learn_en
                                          && !fdb_flush_outer_learning_disable
                                          && ((L2_TYPE_ETHV2 == parser_result1->layer2_type)
                                             || (L2_TYPE_ETHSNAP == parser_result1->layer2_type)
                                             || (L2_TYPE_ETHSAP == parser_result1->layer2_type))
                                          && !pkt_info->pip_bypass_learning
                                          && (pkt_info->is_decap || pkt_info->is_mpls_switched)
                                          && (!pkt_info->discard);

    pkt_info->outer_vsi_id = pkt_info->vsi_id; /* Fix bug 2461, sync-up with RTL */

    if (pkt_info->outer_mac_sa_lookup_en)
    {
        if (ipe_lookup_ctl.mac_hash_lookup_en)
        {
            sal_memset(&fib_key, 0, sizeof(fib_key_t));
            sal_memset(&fib_result, 0, sizeof(lookup_result_t));
            sal_memset(&push_info, 0, sizeof(push_info_t));

            fib_key.key.mac.mapped_mac31_0 = MAKE_UINT32(parser_result1->l2_s.mac_sa3,
                                                         parser_result1->l2_s.mac_sa2,
                                                         parser_result1->l2_s.mac_sa1,
                                                         parser_result1->l2_s.mac_sa0);
            fib_key.key.mac.mapped_mac47_32 = MAKE_UINT16(parser_result1->l2_s.mac_sa5,
                                                          parser_result1->l2_s.mac_sa4);
            fib_key.id.vsi_id = pkt_info->vsi_id;
            fib_key_type = FIB_KEY_TYPE_MAC_SA;
            push_info.data = pkt_info->hash_outer_mac_sa_data;
            fib_result.extra = &push_info;
            DRV_IF_ERROR_RETURN(cm_com_fib_lookup_engine_lookup_handle(in_pkt->chip_id, &fib_key, fib_key_type, &fib_result));
            pkt_info->outer_mac_sa_hash_result_valid = push_info.valid;
            pkt_info->outer_mac_sa_default_entry_valid = push_info.default_entry_valid;
            pkt_info->outer_mac_sa_hash_conflict = push_info.conflict;
        }

        if (ipe_lookup_ctl.mac_tcam_lookup_en)
        {
            /* TCAM lookup */
            tcam_key_type = TCAM_TYPE_MAC_SA;
            sal_memset(&ds_mac_learning_key, 0, sizeof(ds_mac_learning_key_t));
            ds_mac_learning_key.is_acl_qos_key0 = FALSE;
            ds_mac_learning_key.is_acl_qos_key1 = FALSE;
            ds_mac_learning_key.table_id0 = (ipe_lookup_ctl.mac_sa_lookup_ctl >> 2) & 0x7;
            ds_mac_learning_key.table_id1 = (ipe_lookup_ctl.mac_sa_lookup_ctl >> 2) & 0x7;
            ds_mac_learning_key.sub_table_id0 = ipe_lookup_ctl.mac_sa_lookup_ctl & 0x3;
            ds_mac_learning_key.sub_table_id1 = ipe_lookup_ctl.mac_sa_lookup_ctl & 0x3;
            ds_mac_learning_key.mapped_mac_sa31_0 = MAKE_UINT32(parser_result1->l2_s.mac_sa3,
                                                                parser_result1->l2_s.mac_sa2,
                                                                parser_result1->l2_s.mac_sa1,
                                                                parser_result1->l2_s.mac_sa0);
            ds_mac_learning_key.mapped_mac_sa47_32 = MAKE_UINT16(parser_result1->l2_s.mac_sa5,
                                                              parser_result1->l2_s.mac_sa4);
            ds_mac_learning_key.vsi_id = pkt_info->vsi_id;
            ds_mac_learning_key.vlan_id1_1_0 = pkt_info->svlan_id & 0x3;
            ds_mac_learning_key.vlan_id1_11_2 = (pkt_info->svlan_id >> 2) & 0x3FF;
            ds_mac_learning_key.vlan_id2 = pkt_info->cvlan_id;
            ds_mac_learning_key.vlan_ptr3_0 = pkt_info->vlan_ptr & 0xF;
            ds_mac_learning_key.vlan_ptr13_4 = (pkt_info->vlan_ptr >> 4) & 0x3FF;
            ds_mac_learning_key.cos = pkt_info->source_cos;
            ds_mac_learning_key.cfi = pkt_info->source_cfi;
            ds_mac_learning_key.global_src_port = pkt_info->global_src_port;
            ds_mac_learning_key.layer2_header_protocol = parser_result1->l2_s.layer2_header_protocol;
            ds_mac_learning_key.layer3_type = parser_result1->layer3_type;
            ds_mac_learning_key.layer2_type = parser_result1->layer2_type;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
            sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));
            tcam_lookup_info.chip_id = in_pkt->chip_id;
            tcam_lookup_info.tcam_key_type = tcam_key_type;
            tcam_lookup_info.tcam_key_size = (ipe_lookup_ctl.mac_sa_lookup_ctl >> 5) & 0x3;
            tcam_lookup_info.tcam_key = &ds_mac_learning_key;
            tcam_lookup_result.tcam_lkp_output[DRV_TCAM_LOOKUP1].ds_ad = pkt_info->tcam_outer_mac_sa_data;
            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
            pkt_info->tcam_outer_mac_sa_result_valid
                = tcam_lookup_result.tcam_lkp_output[DRV_TCAM_LOOKUP1].tcam_lkp_result_valid;
        }
    }

    if (pkt_info->inner_vsi_id_valid)
    {
        pkt_info->vsi_id = pkt_info->inner_vsi_id;
    }

    pkt_info->outer_learning_logic_src_port = pkt_info->logic_src_port;

    if (pkt_info->inner_logic_src_port_valid)
    {
        pkt_info->logic_src_port = pkt_info->inner_logic_src_port;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_ipe_lookup_manager_lookup_handle
 * Purpose:    IPE lookup management handle.
 * Parameters:
 *  Input:       in_pkt  -- pointer to buffer which save input packet and packet
 *                               header ,and processing informations
 * Output:      in_pkt  -- pointer to buffer which save input packet and packet
 *                                header ,and processing informations
 * Return:      DRV_E_NONE = success.
 *                  Other = Error, please refer to DRV_E_XXX.
 * Note:         none.
 ****************************************************************************/
int32
cm_ipe_lookup_manager_lookup_handle(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    lookup_manager_info_t lookup_manager_info;

    sal_memset(&lookup_manager_info, 0, sizeof(lookup_manager_info));

    /* TCAM_LOOKUP_CONFIG (bypass) */

    DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_outer_learning_lookup(in_pkt));

    DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_default(in_pkt, &lookup_manager_info));

    if (!(pkt_info->discard || pkt_info->ether_oam_discard))
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE lookup Process");

        /* decide routed packet */
        DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_decide_routed_packet(in_pkt, &lookup_manager_info));

        /* get ACL QoS lookup info and lookup */
        DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_lookup_aclqos(in_pkt, &lookup_manager_info));

        /* route lookup */
        DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_lookup_route(in_pkt, &lookup_manager_info));

        /* No MAC DA lookup if layer3 switched or certain configuration of IP Mcast routed */
        DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_lookup_mac(in_pkt, &lookup_manager_info));
    }

    /* OAM lookup */
    DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_lookup_oam(in_pkt, &lookup_manager_info));

    /* parser result info */
    DRV_IF_ERROR_RETURN(_cm_ipe_lookup_manager_parser_result_info(in_pkt, &lookup_manager_info));

    return DRV_E_NONE;
}


