/****************************************************************************
 * cm_ipe_fwd.c: Provides IPE forwarding handle function.
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Version:      V1.0
 * Author:       JiangJf
 * Date:         2010-10-18.
 * Reason:       First Create.
 *
 * Modify History:
 * Reversion:    V1.01
 * Author:       XuZx
 * Date:         2010-11-15.
 * Reason:       Revise for first formal spec.
 *
 * Reversion:    V1.02
 * Author:       XuZx
 * Date:         2010-11-24.
 * Reason:       Revise for second formal spec.
 *
 * Reversion:    V4.29
 * Author:       JiaK
 * Date:         2011-10-09.
 * Reason:       Revise for second formal spec.
 *
 * Reversion:    V5.1.0
 * Author:       Wangcy
 * Date:         2011-12-12.
 * Reason:       sync spec v5.1.0.
 *
 * Reversion:    V5.6.0
 * Author:       Wangcy
 * Date:         2012-01-07.
 * Reason:       sync spec v5.6.0.
 *
 * Reversion:    V5.7.0
 * Author:       Wangcy
 * Date:         2012-01-17.
 * Reason:       sync spec v5.7.0.
 *
 * Reversion:    V5.15.0.1
 * Author:       Wangcy
 * Date:         2012-03-23.
 * Reason:       sync spec v5.15.0.1
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
/****************************************************************************
 * Name:       cm_ipe_forwarding_handle
 * Purpose:    IPE forwarding handle.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_forwarding_get_exception_id (greatbelt_exception_info_t *p_exception, uint8 *exception_id)
{
    uint8 exception_num = 0;
    uint8 exception_sub_index = 0;

    exception_num = p_exception->exception_number;
    exception_sub_index = p_exception->exception_sub_index;

        /* exceptions */
        /* exception                   exceptionId                         */
        /* exceptionNumber7:        128 + (0-63) exceptionSubIndex[5:0]    */
        /* exceptionNumber6:        196                                    */
        /* exceptionNumber5:        195                                    */
        /* exceptionNumber4:        194                                    */
        /* exceptionNumber3:        64 + (0-63) exceptionSubIndex[5:0]     */
        /* exceptionNumber2:        (0-63) exceptionSubIndex[5:0]          */
        /* exceptionNumber1:        193                                    */
        /* exceptionNumber0:        192                                    */

    switch (exception_num)
    {
        case 0:
            *exception_id = 192;
            break;
        case 1:
            *exception_id = 193;
            break;
        case 2:
            *exception_id = exception_sub_index;
            break;
        case 3:
            *exception_id = 64 + exception_sub_index;
            break;
        case 4:
            *exception_id = 194;
            break;
        case 5:
            *exception_id = 195;
            break;
        case 6:
            *exception_id = 196;
            break;
        case 7:
            *exception_id = 128 + exception_sub_index;
            break;
        default:
            CMODEL_DEBUG_OUT_INFO("$$ERROR!INVALID exception num in ipe forwarding!");
            break;

    }

    return DRV_E_NONE;
}

int32
cm_ipe_forwarding_handle(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;
    ms_packet_header_t *p_packet_header = pkt_info->bheader;
    packet_header_outer_t *p_packet_header_outer = pkt_info->ingress_header;
    cm_greatbelt_packet_header_outer_t cm_packet_header_outer;
    greatbelt_packet_header_t cm_packet_header;
    greatbelt_exception_info_t *bexception = (greatbelt_exception_info_t *)pkt_info->bexception;
    ipe_ds_fwd_ctl_t ipe_ds_fwd_ctl;
    ipe_fwd_ctl_t ipe_fwd_ctl;
    ds_aps_bridge_t ds_aps_bridge0;
    ds_aps_bridge_t ds_aps_bridge1;
    ds_aps_bridge_t ds_aps_bridge2;
    ds_fwd_t ds_fwd;
    ds_qcn_t ds_qcn;
    ipe_fwd_qcn_map_table_t ipe_fwd_qcn_map_table;

    uint8 chip_id = in_pkt->chip_id;
    uint8 *greatbelt_header = NULL;
    uint8 mark_drop = FALSE;
    uint8 discard = FALSE;
    uint8 qcn_hard_error = FALSE;
    uint8 no_fwd_ptr = FALSE, ds_fwd_ptr_discard = FALSE;
    uint8 fatal_exception_discard = FALSE;
    uint8 next_hop_ext = FALSE;
    uint8 asic_hard_error = FALSE; /* CModel can not simulate the ASIC hard Error */
    uint8 header_hash = 0;
    uint32 cmd = 0;
    uint16 aps_group_id0 = 0, aps_group_id1 = 0, aps_group_id2 = 0;
    uint16 aps_bridge_index0 = 0, aps_bridge_index1 = 0, aps_bridge_index2 = 0;
    uint16 ds_fwd_ptr = 0;
    uint8 ds_fwd_entry_discard = FALSE;
    uint32 field_value = 0, field_id = 0;
    uint16 stats_length = 0;
    uint8 phb_stats_offset = 0, cos_stats_offset = 0;
    uint32 dest_map = 0, dest_map_tmp = 0;
    uint16 ds_fwd_ptr_base = 0;
    uint32 next_hop_index = 0;
    uint8 mux_len = 0;
    uint16 qcn_queue_id = 0;
    uint8 crc = 0;
    uint8 dest_id_discard = 0;
    uint8 link_oam = 0;
    uint32 priority_field_id = 0, priority_field_value = 0;
    uint8 aps_protecting_en1 = FALSE, aps_protecting_en2 = FALSE;
    uint8 next_aps_bridge_en1 = FALSE, next_aps_bridge_en2 = FALSE;
    uint32 next_aps_group_id1 = 0 , next_aps_group_id2 = 0;
    uint8 aps0_discard = FALSE, aps1_discard = FALSE, aps2_discard = FALSE;
    uint8 mac_isolated_discard = FALSE;
    uint8 storm_ctl_drop = FALSE;
    uint8 aps_discard = FALSE;
    uint16 queue_num = 0;
    uint32 cos_temp = 0;
    uint32 critical_packet_en = 0;
    uint8 exception_id = 0;
    uint32 critical_packet_en_field = 0;
    uint32 critical_packet_en_id = 0;
    uint8 from_cpu_en = FALSE;

    sal_memset(&ds_fwd, 0, sizeof(ds_fwd));

    sal_memset(&ipe_fwd_ctl, 0, sizeof(ipe_fwd_ctl));
    cmd = DRV_IOR(IpeFwdCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_fwd_ctl));

    sal_memset(&ipe_ds_fwd_ctl, 0, sizeof(ipe_ds_fwd_ctl));
    cmd = DRV_IOR(IpeDsFwdCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_ds_fwd_ctl));

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Forwarding Process");

    if (pkt_info->ingress_header_valid)
    {
        /* PACKET_HEADER_PROC */
        discard = pkt_info->discard;
        sal_memset(bexception, 0, sizeof(greatbelt_exception_info_t));

        bexception->exception_from_sgmac = TRUE;
        bexception->exception_sub_index = pkt_info->exception_sub_index;
        bexception->exception_packet_type = pkt_info->packet_type;

        bexception->exception_vector = ((pkt_info->port_log_en && !asic_hard_error) << 7)
                                      |((pkt_info->l2_span_en && !asic_hard_error) << 1);

        if (discard)
        {
            bexception->exception_vector &= (((ipe_fwd_ctl.log_on_discard & 0x7F) << 1) | 1);
        }

        bexception->l2_span_id = pkt_info->l2_span_id;
        bexception->l3_span_id = pkt_info->l3_span_id;

        bexception->acl_log_id3 = pkt_info->acl_log_id3;
        bexception->acl_log_id2 = pkt_info->acl_log_id2;
        bexception->acl_log_id1 = pkt_info->acl_log_id1;
        bexception->acl_log_id0 = pkt_info->acl_log_id0;

        bexception->egress_exception = 0;
        bexception->exception_number = pkt_info->exception_index;

        bexception->dest_id_discard = discard | asic_hard_error;

        /* DISCARD_STATS */
        if (discard)
        {
            DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, CM_INGRESS_DISCARD,
                                                        pkt_info->discard_type,
                                                        pkt_info->packet_length));
        }

#if 0
        /* rtl' pktHdr pktLen is zero when actual len > 256B (do not include ILOOP)!! ZhiXin cosim find the problem! */
        if ((pkt_info->packet_length > 256) && !pkt_info->is_loop)
        {
            in_pkt->module_bus.pkt_len = 0;
        }
        else
        {
            in_pkt->module_bus.pkt_len = pkt_info->packet_length;
        }
#else
        in_pkt->module_bus.pkt_len = pkt_info->packet_length; /* PI.pktLen may be is pseudo */
#endif

        if (in_pkt->chan_id < 32)
        {
            from_cpu_en = IS_BIT_SET(ipe_fwd_ctl.from_cpu_en31_0,in_pkt->chan_id);
        }
        else if (in_pkt->chan_id < 64)
        {
            from_cpu_en = IS_BIT_SET(ipe_fwd_ctl.from_cpu_en63_32,(in_pkt->chan_id - 32));
        }

        if (from_cpu_en)
        {
            /* copy bit by bit except headerCRC[3:0]. IngressHeader format is MsPacketHeader */
            sal_memcpy((void*)p_packet_header ,(void*)pkt_info->ingress_header, GREAT_BELT_HEADER_LEN);
        }
        else
        {
            /* PacketHeader sideband to BufferStore */
            /* IngressHeader formart is PacketHeaderOuter.PacketHeader formart is MsPacketHeader */

            sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));
            cm_gen_greatbelt_packet_header(p_packet_header, &cm_packet_header, TRUE);
            cm_gen_greatbelt_packet_header_outer(p_packet_header_outer, &cm_packet_header_outer, TRUE);
            /* ======== bug 4978 metal fix ECO begin ========= */
            cm_packet_header.src_vlan_id_u.src_vlan_id = pkt_info->local_phy_port;
            /* ======== bug 4978 metal fix ECO end ========= */
            cm_packet_header.packet_offset = pkt_info->payload_offset;

            cm_packet_header.mcast = cm_packet_header_outer.mcast;
            cm_packet_header.dest_chip_id = cm_packet_header_outer.dest_chip_id;
            cm_packet_header.dest_id = cm_packet_header_outer.dest_id;
            cm_packet_header.priority = cm_packet_header_outer.priority;
            cm_packet_header.packet_type = cm_packet_header_outer.packet_type;
            cm_packet_header.header_hash2_0 = cm_packet_header_outer.header_hash & 0x7;
            cm_packet_header.header_hash7_3 = cm_packet_header_outer.header_hash >> 3;

            cm_packet_header.source_port = cm_packet_header_outer.source_port & 0x3FFF;
            cm_packet_header.source_port15_14 = (cm_packet_header_outer.source_port >> 14);
            cm_packet_header.color = cm_packet_header_outer.color;
            cm_packet_header.critical_packet = cm_packet_header_outer.critical_packet;
            cm_packet_header.ttl_u.ttl = cm_packet_header_outer.ttl;
            cm_packet_header.logic_port_type = cm_packet_header_outer.logic_port_type;

            cm_packet_header.from_fabric = TRUE;
            cm_packet_header.loopback_discard_u.ds_next_hop_dot_bypass_all = cm_packet_header_outer.bypass_all;
            cm_packet_header.flow_u.share1.from_cpu_lm_up_disable = cm_packet_header_outer.from_cpu_lm_up_disable;
            cm_packet_header.src_vlan_ptr_t.share1.from_cpu_lm_down_disable = cm_packet_header_outer.from_cpu_lm_down_disable;
            cm_packet_header.from_cpu_or_oam = cm_packet_header_outer.timestamp107_96_u.share1.from_cpu_or_oam;
            cm_packet_header.source_port_extender = cm_packet_header_outer.source_port_extender;
            cm_packet_header.source_port_isolate_id_u.source_port_isolate_id = cm_packet_header_outer.source_port_isolate_id;

            cm_packet_header.svlan_tpid_index_u.svlan_tpid_index = cm_packet_header_outer.svlan_tpid_index;
            cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr = cm_packet_header_outer.src_vlan_ptr;

            cm_packet_header.src_vlan_ptr_t.share1.outer_vlan_is_cvlan = cm_packet_header_outer.outer_vlan_is_c_vlan;

            cm_packet_header.logic_src_port_u.share1.logic_src_port = cm_packet_header_outer.logic_src_port;
            cm_packet_header.oam_tunnel_en = cm_packet_header_outer.oam_tunnel_en_u.oam_tunnel_en;
            cm_packet_header.flow_u.share1.port_mac_sa_en = cm_packet_header_outer.port_mac_sa_en;
            cm_packet_header.bridge_operation = cm_packet_header_outer.bridge_operation;
            cm_packet_header.flow_u.share1.is_leaf = cm_packet_header_outer.is_leaf;
            cm_packet_header.src_vlan_ptr_t.share1.ingress_edit_en = !cm_packet_header_outer.header_type;

            if (cm_packet_header_outer.header_type)
            {
                cm_packet_header.next_hop_ptr = cm_packet_header_outer.next_hop_ptr;
                cm_packet_header.next_hop_ext = cm_packet_header_outer.next_hop_ext;
            }
            else
            {
                if (!cm_packet_header_outer.mirrored_packet)
                {
                    cm_packet_header.next_hop_ptr = ipe_fwd_ctl.ingress_edit_nexthop_ptr;
                    cm_packet_header.next_hop_ext = ipe_fwd_ctl.ingress_edit_nexthop_ext;
                }
                else
                {
                    cm_packet_header.next_hop_ptr = ipe_fwd_ctl.ingress_edit_mirror_nexthop_ptr;
                    cm_packet_header.next_hop_ext = ipe_fwd_ctl.ingress_edit_mirror_nexthop_ext;
                }
            }

            if (OPERATION_TYPE_NAT == cm_packet_header_outer.operation_type)
            {
                cm_packet_header.operation_type = OPERATION_TYPE_NAT;
                cm_packet_header.pbb_src_port_type_u.share1.l4_source_port_valid
                                 = cm_packet_header_outer.timestamp107_96_u.share5.l4_source_port_valid;
                cm_packet_header.pbb_src_port_type_u.share1.ip_sa_valid
                                 = cm_packet_header_outer.timestamp107_96_u.share5.ip_sa_valid;
                cm_packet_header.fid_u.share2.src_address_mode
                                 = cm_packet_header_outer.timestamp107_96_u.share5.src_address_mode;
                cm_packet_header.fid_u.share2.ipv4_src_embeded_mode
                                 = cm_packet_header_outer.timestamp107_96_u.share5.ipv4_src_embeded_mode;
                cm_packet_header.pbb_src_port_type_u.share1.pt_enable
                                 = cm_packet_header_outer.timestamp107_96_u.share5.pt_enable;
                cm_packet_header.fid_u.share2.ip_sa_prefix_length
                                 = cm_packet_header_outer.timestamp107_96_u.share5.ip_sa_prefix_length;
                cm_packet_header.fid_u.share2.ip_sa_mode
                                 = cm_packet_header_outer.timestamp107_96_u.share5.ip_sa_mode;
                cm_packet_header.logic_src_port_u.l4_source_port
                                 = cm_packet_header_outer.timestamp63_32_u.share1.l4_source_port;
                cm_packet_header.ip_sa_u.ip_sa = cm_packet_header_outer.timestamp31_0_u.ip_sa_31_0;
                cm_packet_header.fid_u.share2.ip_sa_39_32
                                 = cm_packet_header_outer.timestamp63_32_u.share1.ip_sa_39_32;


            }
            else if (OPERATION_TYPE_DM_TX == cm_packet_header_outer.operation_type)
            {
                cm_packet_header.operation_type = OPERATION_TYPE_DM_TX;

                cm_packet_header.logic_src_port_u.dm_timestamp_17_2 &= 0xFFC0;
                cm_packet_header.logic_src_port_u.dm_timestamp_17_2 |= (cm_packet_header_outer.timestamp107_96_u.share4.dm_offset >> 2);
                cm_packet_header.rxtx_fcl3_u.dm_timestamp_1_1 = IS_BIT_SET(cm_packet_header_outer.timestamp107_96_u.share4.dm_offset,1);
                cm_packet_header.rxtx_fcl0_u.dm_timestamp_0_0 = IS_BIT_SET(cm_packet_header_outer.timestamp107_96_u.share4.dm_offset,0);
                cm_set_dm_tx_timestamp_in_header(&cm_packet_header,
                                                cm_packet_header_outer.timestamp63_32_u.share2.timestamp_61_32,
                                                cm_packet_header_outer.timestamp31_0_u.timestamp_31_0);
            }
            else if (OPERATION_TYPE_PTP == cm_packet_header_outer.operation_type)
            {
                cm_packet_header.operation_type = OPERATION_TYPE_PTP;

                cm_packet_header.source_port_isolate_id_u.share1.ptp_sequence_id
                                              = cm_packet_header_outer.timestamp107_96_u.share2.ptp_sequence_id;
                cm_packet_header.source_port_isolate_id_u.share1.ptp_edit_type
                                              = cm_packet_header_outer.timestamp107_96_u.share2.ptp_edit_type;
                cm_set_ptp_timestamp_in_header(&cm_packet_header,
                                                cm_packet_header_outer.timestamp63_32_u.share2.timestamp_61_32,
                                                cm_packet_header_outer.timestamp31_0_u.timestamp_31_0);

                if (!cm_packet_header_outer.header_type)
                {
                    cm_packet_header.ttl_u.ptp_offset = cm_packet_header_outer.timestamp95_64_u.share4.ptp_offset;
                    cm_packet_header.pbb_src_port_type_u.share3.ptp_extra_offset = 0;
                }
                else
                {
                    cm_packet_header.pbb_src_port_type_u.share3.ptp_extra_offset = cm_packet_header_outer.timestamp107_96_u.share2.ptp_extra_offset;
                }
            }
            else if (OPERATION_TYPE_OAM == cm_packet_header_outer.operation_type)
            {
                cm_packet_header.operation_type = OPERATION_TYPE_OAM;

                if ((OAM_ETHER == cm_packet_header_outer.timestamp107_96_u.share1.oam_type)
                    && cm_packet_header_outer.timestamp107_96_u.share1.link_oam)
                {
                    cm_packet_header.dest_chip_id = ipe_fwd_ctl.chip_id;
                    cm_packet_header.source_port_isolate_id_u.share2.oam_dest_chip_id = ipe_fwd_ctl.chip_id;
                    cm_packet_header.ip_sa_u.share2.rx_oam = TRUE;
                    cm_packet_header.oam_tunnel_en = FALSE;
                    cm_packet_header.ip_sa_u.share2.mip_en_or_cw_added = FALSE;
                    cm_packet_header.source_port_isolate_id_u.share2.is_up = FALSE;
                    cm_packet_header.ip_sa_u.share2.dm_en = FALSE;

                    cm_packet_header.ip_sa_u.share2.local_phy_port = pkt_info->local_phy_port;
                    cm_packet_header.source_port = (ipe_fwd_ctl.chip_id << 9) | pkt_info->local_phy_port;

                    cm_packet_header.ip_sa_u.share2.link_oam = TRUE;
                    cm_packet_header.ip_sa_u.share2.mep_index = pkt_info->link_oam_mep_index;
                    cm_packet_header.ip_sa_u.share2.oam_type = cm_packet_header_outer.timestamp107_96_u.share1.oam_type;
                }
                else
                {
                    cm_packet_header.ip_sa_u.share2.rx_oam = cm_packet_header_outer.timestamp107_96_u.share1.rx_oam;
                    cm_packet_header.from_cpu_or_oam = cm_packet_header_outer.timestamp107_96_u.share1.from_cpu_or_oam;
                    cm_packet_header.ip_sa_u.share3.oam_type = cm_packet_header_outer.timestamp107_96_u.share1.oam_type;
                    cm_packet_header.source_port_isolate_id_u.share2.is_up
                                                     = cm_packet_header_outer.timestamp107_96_u.share1.is_up;
                    cm_packet_header.ip_sa_u.share2.link_oam
                                                     = cm_packet_header_outer.timestamp107_96_u.share1.link_oam;
                    cm_packet_header.ip_sa_u.share2.gal_exist
                                                     = cm_packet_header_outer.timestamp107_96_u.share1.gal_exist;
                    cm_packet_header.ip_sa_u.share2.dm_en
                                                     = cm_packet_header_outer.timestamp107_96_u.share1.dm_en;

                    cm_packet_header.ip_sa_u.share2.entropy_label_exist
                                                     = cm_packet_header_outer.timestamp107_96_u.share1.entropy_label_exist;
                    cm_packet_header.ip_sa_u.share2.mip_en_or_cw_added
                                                     = cm_packet_header_outer.timestamp107_96_u.share1.mip_en_or_cw_added;
                    cm_packet_header.source_port_isolate_id_u.share2.oam_dest_chip_id
                                                     = cm_packet_header_outer.timestamp95_64_u.share1.oam_dest_chip;
                    cm_packet_header.ip_sa_u.share2.local_phy_port
                                                     = cm_packet_header_outer.timestamp95_64_u.share1.local_phy_port;
                    cm_packet_header.ip_sa_u.share2.mep_index
                                                     = cm_packet_header_outer.timestamp95_64_u.share1.mep_index;

                    if (cm_packet_header_outer.timestamp107_96_u.share1.dm_en)
                    {
                        cm_set_dm_rx_timestamp_in_header(&cm_packet_header,cm_packet_header_outer.timestamp63_32_u.share2.timestamp_61_32,
                                                                        cm_packet_header_outer.timestamp31_0_u.timestamp_31_0);
                    }
                    if (cm_packet_header_outer.timestamp95_64_u.share1.oam_dest_chip == ipe_fwd_ctl.chip_id)
                    {
                        cm_packet_header.packet_offset += ((cm_packet_header_outer.timestamp95_64_u.share1.oam_packet_offset7_5 << 5)
                                                        | (cm_packet_header_outer.timestamp95_64_u.share1.oam_packet_offset4 << 4)
                                                        | (cm_packet_header_outer.timestamp95_64_u.share1.oam_packet_offset3_2 << 2)
                                                        | (cm_packet_header_outer.timestamp63_32_u.share2.oam_packet_offset1_0));
                    }
                }
            }
            else if (OPERATION_TYPE_C2C == cm_packet_header_outer.operation_type)
            {
                cm_packet_header.operation_type = OPERATION_TYPE_C2C;
                cm_packet_header.rxtx_fcl0_u.c2c_check_disable = cm_packet_header_outer.oam_tunnel_en_u.c2c_disable;
            }
            else
            {
                cm_packet_header.operation_type = OPERATION_TYPE_NORMAL;
                cm_packet_header.flow_u.share1.flow_id = cm_packet_header_outer.timestamp107_96_u.share3.flow_id;
                cm_packet_header.ip_sa_u.share1.mac_known = cm_packet_header_outer.mac_known;
                cm_packet_header.rxtx_fcl2_1_u.capwap_state
                                                     = cm_packet_header_outer.timestamp107_96_u.share3.capwap_state;
                cm_packet_header.logic_src_port_u.share1.pbb_check_discard
                                                     = cm_packet_header_outer.timestamp107_96_u.share3.pbb_check_discard;
                cm_packet_header.ip_sa_u.share4.src_dscp = cm_packet_header_outer.timestamp95_64_u.share3.src_dscp;

             }

            cm_gen_greatbelt_packet_header(p_packet_header, &cm_packet_header, FALSE);

        }
    }
    else
    {
        /* retrieve DsFwd */

        if (pkt_info->fatal_exception_valid)    /* fatal exception */
        {
            ds_fwd_ptr = (ipe_ds_fwd_ctl.ds_fwd_index_base_fatal << 4) | pkt_info->fatal_exception;
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n", "DsFwd_t", ds_fwd_ptr);    
            cmd = DRV_IOR(DsFwd_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_fwd_ptr, cmd, &ds_fwd));

            ds_fwd_entry_discard = ds_fwd.is_met || ds_fwd.is_nexthop || (DS_TYPE_FWD != ds_fwd.ds_type);
            pkt_info->ds_fwd_ptr_valid = FALSE;
        }
        else if (pkt_info->mux_destination_valid)   /* Port Extender */
        {
            ds_fwd_ptr_base = pkt_info->mux_destination_type ? (ipe_ds_fwd_ctl.port_extender_mc_fwd_ptr_base)
                                                             : (ipe_ds_fwd_ctl.port_extender_uc_fwd_ptr_base);

            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n", "DsFwd_t", 
                                                                ((pkt_info->mux_destination) + (ds_fwd_ptr_base << 6)));    
            cmd = DRV_IOR(DsFwd_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ((pkt_info->mux_destination) + (ds_fwd_ptr_base << 6)), cmd, &ds_fwd));

            ds_fwd_entry_discard = ds_fwd.is_met || ds_fwd.is_nexthop || (DS_TYPE_FWD != ds_fwd.ds_type);
        }
        else if (pkt_info->ds_fwd_ptr_valid && (0xFFFF != pkt_info->ds_fwd_ptr))    /* noraml forward */
        {
            ds_fwd_ptr = pkt_info->ds_fwd_ptr;
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n", "DsFwd_t", ds_fwd_ptr);    
            cmd = DRV_IOR(DsFwd_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_fwd_ptr, cmd, &ds_fwd));

            ds_fwd_entry_discard = ds_fwd.is_met || ds_fwd.is_nexthop || (DS_TYPE_FWD != ds_fwd.ds_type);
        }

        /* ======== bug 4659 ECO begine ========= */
        //if (pkt_info->next_hop_ptr_valid)   /*  other DsFwd.{...} to be considered when DsFwd change */
        if (pkt_info->next_hop_ptr_valid && !pkt_info->fatal_exception_valid)
        /* ======== bug 4659 ECO end ========= */
        {
            sal_memset(&ds_fwd, 0, sizeof(ds_fwd));
            ds_fwd_entry_discard = FALSE;
            /* not writeable to DsFwd */
            ds_fwd.aps_type = pkt_info->ad_aps_type;
            ds_fwd.critical_packet = pkt_info->ad_critical_packet;
            ds_fwd.dest_map = pkt_info->ad_dest_map;
            ds_fwd.length_adjust_type = pkt_info->ad_length_adjust_type;
            ds_fwd.next_hop_ext = pkt_info->ad_next_hop_ext;
            ds_fwd.next_hop_ptr = pkt_info->ad_next_hop_ptr;
            ds_fwd.send_local_phy_port = pkt_info->ad_send_local_phy_port;
            ds_fwd.speed = pkt_info->ad_speed;
        }

        next_hop_ext = ds_fwd.next_hop_ext;
        next_hop_index = ds_fwd.next_hop_ptr;
        dest_map_tmp = (((pkt_info->global_src_port >> 9) & 0x1F) << 16) | ((ds_fwd.dest_map >> 9 & 0x7F) << 9) | ((pkt_info->global_src_port) & 0x1FF);
        dest_map = ds_fwd.force_back_en ? dest_map_tmp : ds_fwd.dest_map;

        /* retrieve APS Bridge/select */
        if (3 == ds_fwd.aps_type) /* APS Bridge */
        {
            /* APS level 0 */
            aps_bridge_index0 = ds_fwd.dest_map & 0xFFF;

            sal_memset(&ds_aps_bridge0, 0, sizeof(ds_aps_bridge_t));
            cmd = DRV_IOR(DsApsBridge_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, aps_bridge_index0, cmd, &ds_aps_bridge0));

            if (ds_aps_bridge0.protecting_en && !ds_aps_bridge0.protecting_next_aps_bridge_en)
            {
                next_aps_bridge_en1 = FALSE;
                dest_map = ds_aps_bridge0.protecting_dest_map;
            }
            else if (!ds_aps_bridge0.protecting_en && !ds_aps_bridge0.working_next_aps_bridge_en)
            {
                next_aps_bridge_en1 = FALSE;
                dest_map = ds_aps_bridge0.working_dest_map;
            }
            else if (ds_aps_bridge0.protecting_en && ds_aps_bridge0.protecting_next_aps_bridge_en)
            {
                next_aps_bridge_en1 = TRUE;
                next_aps_group_id1 = ds_aps_bridge0.protecting_dest_map & 0x3FF;
            }
            else
            {
                next_aps_bridge_en1 = TRUE;
                next_aps_group_id1 = ds_aps_bridge0.working_dest_map & 0x3FF;
            }
   
            if (ds_aps_bridge0.protecting_en)
            {
                //==============bug4716 ECO begin ====================
                //next_hop_index = ds_aps_bridge0.protecting_next_hop_ptr; /* nexthopExt ??? */
                //next_hop_ext = ds_aps_bridge0.protecting_next_hop_ext;
                if (!IS_BIT_SET(ds_aps_bridge0.protecting_next_hop_ptr, 0))
                {
                    next_hop_index = next_hop_index + (next_hop_ext?2:1);
                }
                //==============bug4716 ECO end ====================
            }

            /* APS level 1 */
            if (next_aps_bridge_en1)
            {
                aps_bridge_index1 = next_aps_group_id1 & 0x3FF;

                sal_memset(&ds_aps_bridge1, 0, sizeof(ds_aps_bridge_t));
                cmd = DRV_IOR(DsApsBridge_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, aps_bridge_index1, cmd, &ds_aps_bridge1));

                aps_protecting_en1 = ds_aps_bridge1.protecting_en;

                if (ds_aps_bridge1.protecting_en && !ds_aps_bridge1.protecting_next_aps_bridge_en)
                {
                    next_aps_bridge_en2 = FALSE;
                    dest_map = ds_aps_bridge1.protecting_dest_map;
                }
                else if (!ds_aps_bridge1.protecting_en && !ds_aps_bridge1.working_next_aps_bridge_en)
                {
                    next_aps_bridge_en2 = FALSE;
                    dest_map = ds_aps_bridge1.working_dest_map;
                }
                else if (ds_aps_bridge1.protecting_en && ds_aps_bridge1.protecting_next_aps_bridge_en)
                {
                    next_aps_bridge_en2 = TRUE;
                    next_aps_group_id2 = ds_aps_bridge1.protecting_dest_map & 0x3FF;
                }
                else
                {
                    next_aps_bridge_en2 = TRUE;
                    next_aps_group_id2 = ds_aps_bridge1.working_dest_map & 0x3FF;
                }
            }

            /* APS level 2 */
            if (next_aps_bridge_en2)
            {
                aps_bridge_index2 = next_aps_group_id2 & 0x3FF;

                sal_memset(&ds_aps_bridge2, 0, sizeof(ds_aps_bridge_t));
                cmd = DRV_IOR(DsApsBridge_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, aps_bridge_index2, cmd, &ds_aps_bridge2));

                aps_protecting_en2 = ds_aps_bridge2.protecting_en;

                if (ds_aps_bridge2.protecting_en)
                {
                    dest_map = ds_aps_bridge2.protecting_dest_map;
                }
                else if (!ds_aps_bridge2.protecting_en)
                {
                    dest_map = ds_aps_bridge2.working_dest_map;
                }
            }
        }
        else
        {
            if (pkt_info->aps_select_valid0)  /* APS select 0 */
            {
                aps_group_id0 = pkt_info->aps_select_group_id0;

                field_id = DsApsSelect_ProtectingEn0_f + (aps_group_id0 & 0x1F);
                cmd = DRV_IOR(DsApsSelect_t, field_id);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, (aps_group_id0 >> 5) & 0x1F, cmd, &field_value));

                CMODEL_DEBUG_OUT_INFO("select path:%d ,protect_en : 0x%x \n",
                                  pkt_info->aps_select_protecting_path0, field_value);

                if ((field_value & 0x1) ^ pkt_info->aps_select_protecting_path0)
                {
                    aps0_discard = TRUE;
                }
            }

            if (pkt_info->aps_select_valid1)  /* APS select 1 */
            {
                aps_group_id1 = pkt_info->aps_select_group_id1;

                field_id = DsApsSelect_ProtectingEn0_f + (aps_group_id1 & 0x1F);
                cmd = DRV_IOR(DsApsSelect_t, field_id);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, (aps_group_id1 >> 5) & 0x1F, cmd, &field_value));

                CMODEL_DEBUG_OUT_INFO("select path:%d ,protect_en : 0x%x \n",
                                      pkt_info->aps_select_protecting_path1, field_value);

                if ((field_value & 0x1) ^ pkt_info->aps_select_protecting_path1)
                {
                    aps1_discard = TRUE;
                }
            }

            if (pkt_info->aps_select_valid2)  /* APS select 2 */
            {
                aps_group_id2 = pkt_info->aps_select_group_id2;

                field_id = DsApsSelect_ProtectingEn0_f + (aps_group_id2 & 0x1F);
                cmd = DRV_IOR(DsApsSelect_t, field_id);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, (aps_group_id2 >> 5) & 0x1F, cmd, &field_value));

                CMODEL_DEBUG_OUT_INFO("select path:%d ,protect_en : 0x%x \n",
                                      pkt_info->aps_select_protecting_path2, field_value);

                if ((field_value & 0x1) ^ pkt_info->aps_select_protecting_path2)
                {
                    aps2_discard = TRUE;
                }
            }

        }

        /* OAM fatalException
        if (pkt_info->fatal_exception_valid && (pkt_info->fatal_exception == FATAL_EXP_MPLS_TTL_CHECK_FAIL))
        {
            pkt_info->ds_fwd_ptr_valid = FALSE;
        } */
        mac_isolated_discard = ds_fwd.mac_isolated_group_en
                        && (0 != pkt_info->mac_isolated_groupid)
                        && (pkt_info->mac_isolated_groupid == ((ds_fwd.mac_isolated_group_id5_1 << 1) | ds_fwd.mac_isolated_group_id0));

        no_fwd_ptr = !pkt_info->next_hop_ptr_valid && !pkt_info->ds_fwd_ptr_valid
                        && !pkt_info->fatal_exception_valid
                        && !pkt_info->mux_destination_valid
                        && !pkt_info->ingress_header_valid
                        && (pkt_info->share_type != SHARE_TYPE_OAM);  /* only for etherOamDiscard */

        ds_fwd_ptr_discard = (!pkt_info->next_hop_ptr_valid && pkt_info->ds_fwd_ptr_valid)
                             && (0xFFFF == pkt_info->ds_fwd_ptr)
                             && (SHARE_TYPE_OAM != pkt_info->share_type);
        fatal_exception_discard = pkt_info->fatal_exception_valid
                                  && IS_BIT_SET(ipe_fwd_ctl.discard_fatal, pkt_info->fatal_exception);

        if (pkt_info->fatal_exception_valid)
        {
            CMODEL_DEBUG_OUT_INFO("\n================ FATAL EXCEPTION ================ \n");
            CMODEL_DEBUG_OUT_INFO("********** fatal_exception =  0x%x\n", pkt_info->fatal_exception);
            CMODEL_DEBUG_OUT_INFO("================================================= \n");
        }

        storm_ctl_drop = pkt_info->storm_ctl_drop
                        && ((pkt_info->share_type != SHARE_TYPE_OAM)
                        || !ipe_fwd_ctl.oam_bypass_storm_ctl_discard);
        mark_drop = pkt_info->mark_drop
                        && ((SHARE_TYPE_OAM != pkt_info->share_type)
                        || (!ipe_fwd_ctl.oam_bypass_policing_discard));

        aps_discard =  (aps0_discard && ((SHARE_TYPE_OAM != pkt_info->share_type) || (0 != pkt_info->aps_level_for_oam )))
                    || (aps1_discard && ((SHARE_TYPE_OAM != pkt_info->share_type) || (1 != pkt_info->aps_level_for_oam )))
                    || (aps2_discard && ((SHARE_TYPE_OAM != pkt_info->share_type) || (2 != pkt_info->aps_level_for_oam )));

        if (storm_ctl_drop)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_STORM_CTL_DISCARD;
            }

            if (pkt_info->storm_ctl_exception_en && !pkt_info->exception_en)
            {
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
                pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_STORM_CTL;
            }
        }
        else if (mark_drop)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_POLICING_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Policing Discard (mark drop)!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (no_fwd_ptr)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_NO_FWD_PTR_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! dsFwdPtr not valid!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (mac_isolated_discard)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_MAC_ISOLATED_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! mac isolated discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (ds_fwd_ptr_discard)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_FWD_PTR_ALL_F_OR_VALID_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! discard dsfwdptr!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
           }
        }
        else if (fatal_exception_discard)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_FATAL_EXCEPTION_DSCD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Fatal exception discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (aps_discard)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_APS_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! aps discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        /* asicHardError is parity/ECC(memory)erro,BridgeHeader erro, MAC error(fragment,jumbo frame,etc??) */
        discard = (mac_isolated_discard || storm_ctl_drop || mark_drop || no_fwd_ptr || ds_fwd_ptr_discard
                  || fatal_exception_discard || aps_discard || pkt_info->discard) || asic_hard_error || ds_fwd_entry_discard;

        /* ======== bug 4660 ECO begine ========= */
        //if ((0 != ((ds_fwd.stats_ptr_high << 12) | ds_fwd.stats_ptr_low)) && (!pkt_info->flow_stats1_valid))
        if ((0 != ((ds_fwd.stats_ptr_high << 12) | ds_fwd.stats_ptr_low)) 
            && (!pkt_info->flow_stats1_valid)
            && !ds_fwd_entry_discard)
        /* ======== bug 4660 ECO end ========= */
        {
            pkt_info->flow_stats1_valid = TRUE;
            pkt_info->flow_stats1_ptr = ((ds_fwd.stats_ptr_high << 12) | ds_fwd.stats_ptr_low);
        }

        /* either (payloadOffset != 0) or (muxLengType != 0) */
        if (0 != pkt_info->payload_offset)
        {
            pkt_info->mux_length_type = MUX_LENGTH_TYPE0;

            if (!ipe_fwd_ctl.vlan_edit_select)
            {
                pkt_info->svlan_tag_operation_valid = FALSE;
                pkt_info->cvlan_tag_operation_valid = FALSE;
                pkt_info->isid_translate_en = FALSE;
            }
        }

        /* HASH SELECTION */
        if ((0xFFFE == (ds_fwd.dest_map & 0xFFFF))
            && (!pkt_info->from_cpu_or_oam)
            && (MUX_LENGTH_TYPE2 != pkt_info->mux_length_type))
        {
            if (!discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_FWD_DEST_ID_DISCARD;
            }
            discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DestIdDiscard is set!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }

        /* STATS_OPERATION */
        if (MUX_LENGTH_TYPE1 == pkt_info->mux_length_type)
        {
            mux_len = 4;
        }
        else if (MUX_LENGTH_TYPE2 == pkt_info->mux_length_type)
        {
            mux_len = 8;
        }
        else
        {
            mux_len = 0;
        }

        /* only netework channel and interLaken support stats,loopback not support */
        /* PacketInfo.packetLength[13:0] is Eop or Sop/Eop real packetLength */
        /* Here packetLength should be from real pkt */
        stats_length = in_pkt->packet_length - pkt_info->packet_length_adjust - mux_len; /* EOP */

        /* Random log */
        if (pkt_info->random_log_en && ((!discard) || ipe_fwd_ctl.log_port_discard))   /* globalStats */
        {
            DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, CM_STATS_DEFAULT,
                     ((ipe_fwd_ctl.port_log_stats_base << 6) + pkt_info->local_phy_port), stats_length));
        }

        /*flowStats0: aclFlowStats0*/
        /*flowStats1: aclFlowStats1,tunnelId,MPLS-LSP,DsFwd*/
        /*flowStats2: userId,VLAN,MPLS-PW*/
        if (COLOR_GREEN == pkt_info->color)
        {
            phb_stats_offset = 0; /*in-profile stats offset*/
        }
        else
        {
            phb_stats_offset = 1; /*out-of-profile stats offset*/
        }

        cmd = DRV_IOR(IpePriorityToStatsCos_t, (EpePriorityToStatsCos_Cos0_f + pkt_info->priority));
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &cos_temp));

        cos_stats_offset = cos_temp & 0x7; /* per-cos stats offset */

        switch (ipe_fwd_ctl.stats_mode)
        {
            /* in/out profile stats */
            case 1:
                pkt_info->flow_stats0_ptr = (pkt_info->flow_stats0_ptr + phb_stats_offset) & 0xFFFF;
                pkt_info->flow_stats1_ptr = (pkt_info->flow_stats1_ptr + phb_stats_offset) & 0xFFFF;
                pkt_info->flow_stats2_ptr = (pkt_info->flow_stats2_ptr + phb_stats_offset) & 0xFFFF;
                break;
            /* per-cos stats */
            case 2:
                pkt_info->flow_stats0_ptr = (pkt_info->flow_stats0_ptr + cos_stats_offset) & 0xFFFF;
                pkt_info->flow_stats1_ptr = (pkt_info->flow_stats1_ptr + cos_stats_offset) & 0xFFFF;
                pkt_info->flow_stats2_ptr = (pkt_info->flow_stats2_ptr + cos_stats_offset) & 0xFFFF;
                break;
            /* in/out profile and per-cos stats */
            case 3:
                pkt_info->flow_stats0_ptr = (pkt_info->flow_stats0_ptr + (cos_stats_offset << 1)
                                             + phb_stats_offset)& 0xFFFF;
                pkt_info->flow_stats1_ptr = (pkt_info->flow_stats1_ptr + (cos_stats_offset << 1)
                                             + phb_stats_offset)& 0xFFFF;
                pkt_info->flow_stats2_ptr = (pkt_info->flow_stats2_ptr + (cos_stats_offset << 1)
                                             + phb_stats_offset)& 0xFFFF;
                break;
            default:   /* stats pointer no change */
                break;
        }

        if (pkt_info->flow_stats0_valid && ((!discard)||ipe_fwd_ctl.flow_stats0_discard_stats_en))
        {
            DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, CM_STATS_DEFAULT,
                                                        pkt_info->flow_stats0_ptr, stats_length));
        }

        if (pkt_info->flow_stats1_valid && ((!discard)||ipe_fwd_ctl.flow_stats1_discard_stats_en))
        {
            DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, CM_STATS_DEFAULT,
                                                        pkt_info->flow_stats1_ptr, stats_length));
        }

        if (pkt_info->flow_stats2_valid && ((!discard)||ipe_fwd_ctl.flow_stats2_discard_stats_en))
        {
            DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, CM_STATS_DEFAULT,
                                                        pkt_info->flow_stats2_ptr, stats_length));
        }

        /* QCN */
        header_hash = (!ipe_fwd_ctl.header_hash_mode)? pkt_info->header_hash
                                                     : pkt_info->ecmp_hash;
        /* Receive QMgr QCN information {queueid[6:0],qcnFb[5:0],qcnQoffset[13:0],qcnDelta[13:0],Update DsQcn}
           DsQcnTable[queueId[6:0]].{..}={qcnFb[5:0],qcnQoffset[15:0],qcnDelta[15:0]};DsQcn.qcnEn = 1b'1;DsQcn.qcnCount = 1 */
        /* only sampling loacl destined unicasst non-linkagg packet to notify(NetTx send QCN message to
           source chip or local MAC, source is linkagg) */
        sal_memset(&ipe_fwd_qcn_map_table, 0, sizeof(ipe_fwd_qcn_map_table));
        cmd = DRV_IOR(IpeFwdQcnMapTable_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, dest_map&0x3F, cmd, &ipe_fwd_qcn_map_table));

        if (ipe_fwd_ctl.qcn_en && (!GET_MCAST_IN_DESTMAP(dest_map))
            && (((dest_map >> 16) & 0x1F) == ipe_fwd_ctl.chip_id)
            && !pkt_info->from_cpu_or_oam && (0xF != ipe_fwd_qcn_map_table.qcn_port_id))
        {
            queue_num = (ipe_fwd_qcn_map_table.qcn_port_id << 3) | ((pkt_info->priority >> 3) & 0x7);

            sal_memset(&ds_qcn, 0, sizeof(ds_qcn_t));
            cmd = DRV_IOR(DsQcn_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, qcn_queue_id, cmd, &ds_qcn));

            if (ds_qcn.qcn_en)
            {
                /* send QCN to NetTx ??? */
                pkt_info->new_color = 2;
                ds_qcn.qcn_en = FALSE;
                cmd = DRV_IOW(DsQcn_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, qcn_queue_id, cmd, &ds_qcn));
            }
        }
        discard = discard || qcn_hard_error;

        /* PROCESS_DESTINATION */
        /* fields for PacketInfo.fromCpuOrOam, such as srcVlanIdValid. etc */
        sal_memset(&cm_packet_header, 0, sizeof(greatbelt_packet_header_t));

        link_oam = pkt_info->link_or_section_OAM && (SHARE_TYPE_OAM == pkt_info->share_type)
                    && (OAM_ACH != pkt_info->rx_oam_type);

        if ((SHARE_TYPE_OAM == pkt_info->share_type) && discard && !asic_hard_error)
        {
            if (!IS_BIT_SET(pkt_info->discard_type, 5))
            {
                dest_id_discard = IS_BIT_SET(ipe_fwd_ctl.oam_discard_bitmap31_0, pkt_info->discard_type)
                                  && !link_oam;
            }
            else
            {
                dest_id_discard = IS_BIT_SET(ipe_fwd_ctl.oam_discard_bitmap63_32, (pkt_info->discard_type - 32))
                                  && !link_oam;
            }
        }
        else
        {
            dest_id_discard = discard;
        }

        in_pkt->module_bus.dest_id_discard = dest_id_discard;
        cm_packet_header.packet_offset = pkt_info->payload_offset;
        cm_packet_header.mcast = GET_MCAST_IN_DESTMAP(dest_map);
        cm_packet_header.dest_chip_id = GET_DESTCHIPID_IN_DESTMAP(dest_map);
        cm_packet_header.dest_id = GET_DESTID_IN_DESTMAP(dest_map);

        if (pkt_info->exception_en
            && (EXCEPTION_TYPE_LAYER2 == pkt_info->exception_index)
            && ipe_fwd_ctl.exception2_priority_en
            && !IS_BIT_SET(pkt_info->exception_sub_index, 5))
        {
            priority_field_id = IpeFwdCtl_Exception2Priority0_f + (pkt_info->exception_sub_index & 0x1F);
            cmd = DRV_IOR(IpeFwdCtl_t, priority_field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &priority_field_value));
            cm_packet_header.priority = priority_field_value;
        }
        else
        {
            cm_packet_header.priority = pkt_info->priority;
        }

        cm_packet_header.packet_type = pkt_info->payload_packet_type;
        cm_packet_header.source_cos = pkt_info->source_cos;
        cm_packet_header.src_queue_select = pkt_info->src_queue_select;
        cm_packet_header.from_cpu_or_oam = pkt_info->from_cpu_or_oam;
        cm_packet_header.non_crc = pkt_info->non_crc;
        cm_packet_header.source_port_extender = pkt_info->source_port_extender;

        /* ESADI packet should be discard after loopback,use destIdDiscard ??? */
        cm_packet_header.loopback_discard_u.loopback_discard = pkt_info->is_esadi;
        cm_packet_header.bypass_ingress_edit = ds_fwd.bypass_ingress_edit;

        cm_packet_header.header_hash2_0 = header_hash & 0x7;
        cm_packet_header.header_hash7_3 = (header_hash >> 3) & 0x1F;

        cm_packet_header.logic_port_type = pkt_info->logic_port_type;
        cm_packet_header.flow_u.share1.is_leaf = pkt_info->is_leaf;

        /* rtl' pktHdr pktLen is zero when actual len > 256B (do not include ILOOP)!! ZhiXin cosim find the problem! */
        if ((pkt_info->packet_length > 256) && !pkt_info->is_loop)
        {
            in_pkt->module_bus.pkt_len = 0;
        }
        else
        {
            in_pkt->module_bus.pkt_len = pkt_info->packet_length;
            in_pkt->packet_length = pkt_info->packet_length;
        }

        if (ds_fwd.send_local_phy_port
           || (dest_id_discard && ipe_fwd_ctl.force_except_local_phy_port))
        {
            cm_packet_header.source_port = ((ipe_fwd_ctl.chip_id & 0x1F) << 9) | pkt_info->local_phy_port;
        }
        else
        {
            cm_packet_header.source_port = pkt_info->global_src_port;

            if (ipe_fwd_ctl.stacking_en && (0x1F == ((pkt_info->global_src_port >> 9)&0x1F)))
                /* intenal always use 5'b1_1111,Header use encoded format */
            {
                cm_packet_header.source_port &= 0x3E3F;/*clear [8:6]*/
                cm_packet_header.source_port |= ((ipe_fwd_ctl.chip_id & 0x7)<< 6);
                cm_packet_header.source_port15_14 = (ipe_fwd_ctl.chip_id>>3);
            }
        }

        cm_packet_header.color = pkt_info->new_color;
        cm_packet_header.next_hop_ptr = next_hop_index & 0xFFFF;
        cm_packet_header.length_adjust_type = ds_fwd.length_adjust_type;

        cm_packet_header.source_port_isolate_id_u.source_port_isolate_id = pkt_info->src_port_isolate_id;
        cm_packet_header.source_cfi = pkt_info->source_cfi;
        cm_packet_header.mux_length_type = pkt_info->mux_length_type;

        cm_packet_header.svlan_tpid_index_u.svlan_tpid_index = pkt_info->svlan_tpid_index;

        cm_packet_header.oam_tunnel_en = pkt_info->oam_tunnel_en;
        cm_packet_header.src_vlan_ptr_t.share1.outer_vlan_is_cvlan = pkt_info->outer_vlan_is_cvlan;
        cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr = pkt_info->vlan_ptr;
        cm_packet_header.rxtx_fcl0_u.oam_use_fid = pkt_info->egress_oam_use_fid;  /* delete ??? */
        cm_packet_header.next_hop_ext = next_hop_ext;

        if (pkt_info->mpls_label_space_valid)
        {
            cm_packet_header.svlan_tpid_index_u.share1.mpls_label_space_valid = pkt_info->mpls_label_space_valid;
            pkt_info->fid &= 0x3F00;
            pkt_info->fid |= (pkt_info->mpls_label_space & 0xFF);
        }

        cm_packet_header.fid_u.share1.fid = (ipe_fwd_ctl.port_extender_mcast_en & GET_MCAST_IN_DESTMAP(dest_map))
                                            ? (dest_map & 0x3FFF) : pkt_info->fid;
        cm_packet_header.ip_sa_u.share1.isid_valid = pkt_info->isid_translate_en;

        cm_packet_header.src_vlan_id_u.src_vlan_id = pkt_info->svlan_id;
        cm_packet_header.ttl_u.ttl = pkt_info->packet_ttl;
        cm_packet_header.src_svlan_id_valid = pkt_info->svlan_id_valid;
        cm_packet_header.src_cvlan_id_valid_u.src_cvlanid_valid = pkt_info->cvlan_id_valid;
        cm_packet_header.src_cvlan_id_u.src_cvlan_id = pkt_info->cvlan_id;

        if (pkt_info->isid_translate_en)
        {
            cm_packet_header.src_vlan_id_u.isid_23_12 = (pkt_info->new_isid >> 12);
            cm_packet_header.src_cvlan_id_u.isid_11_0 = pkt_info->new_isid & 0xFFF;
        }

        if (pkt_info->svlan_tag_operation_valid)
        {
            cm_packet_header.svlan_tag_operation_valid = pkt_info->svlan_tag_operation_valid;
            cm_packet_header.stag_action = pkt_info->stag_action;
        }

        if (pkt_info->cvlan_tag_operation_valid)
        {
            cm_packet_header.ip_sa_u.share1.cvlan_tag_operation_valid = pkt_info->cvlan_tag_operation_valid;
            cm_packet_header.ttl_u.share1.ctag_action = pkt_info->ctag_action;
            cm_packet_header.src_ctag_offset_type_u.src_ctag_offset_type = pkt_info->src_ctag_offset_type;
            cm_packet_header.ttl_u.share1.src_ctag_cos = pkt_info->ctag_cos;
            cm_packet_header.ttl_u.share1.src_ctag_cfi = pkt_info->ctag_cfi;
        }

        if (SHARE_TYPE_NAT == pkt_info->share_type) /* NAT */
        {
            cm_packet_header.operation_type = OPERATION_TYPE_NAT;
            cm_packet_header.logic_src_port_u.l4_source_port = pkt_info->share_fields_u.nat.new_l4_source_port;
            cm_packet_header.pbb_src_port_type_u.share1.l4_source_port_valid = pkt_info->share_fields_u.nat.new_l4_source_port_valid;
            cm_packet_header.fid_u.share2.ip_sa_39_32 = pkt_info->share_fields_u.nat.new_ip_sa_39_32;
            cm_packet_header.ip_sa_u.ip_sa = pkt_info->share_fields_u.nat.new_ip_sa_31_0;
            cm_packet_header.pbb_src_port_type_u.share1.ip_sa_valid = pkt_info->share_fields_u.nat.new_ip_sa_valid;
            cm_packet_header.fid_u.share2.src_address_mode = pkt_info->share_fields_u.nat.src_address_mode;
            cm_packet_header.fid_u.share2.ipv4_src_embeded_mode = pkt_info->share_fields_u.nat.ipv4_src_embeded_mode;
            cm_packet_header.pbb_src_port_type_u.share1.pt_enable = pkt_info->share_fields_u.nat.pt_enable;
            cm_packet_header.fid_u.share2.ip_sa_mode = pkt_info->share_fields_u.nat.ip_sa_mode;
            cm_packet_header.fid_u.share2.ip_sa_prefix_length = pkt_info->share_fields_u.nat.ip_sa_prefix_length;
        }
        else if (SHARE_TYPE_OAM == pkt_info->share_type) /* OAM */
        {
            cm_packet_header.operation_type = OPERATION_TYPE_OAM;
            cm_packet_header.ip_sa_u.share2.rx_oam = TRUE;
            cm_packet_header.source_port_isolate_id_u.share2.oam_dest_chip_id = pkt_info->share_fields_u.oam.oam_dest_chip_id;
            cm_packet_header.ip_sa_u.share2.mip_en_or_cw_added = pkt_info->share_fields_u.oam.mip_en;
            cm_packet_header.ip_sa_u.share2.mep_index = pkt_info->share_fields_u.oam.mep_index & 0x1FFF;
            cm_packet_header.ip_sa_u.share2.oam_type = pkt_info->share_fields_u.oam.rx_oam_type;
            cm_packet_header.ip_sa_u.share2.link_oam = pkt_info->share_fields_u.oam.link_or_section_oam;
            cm_packet_header.ip_sa_u.share2.local_phy_port = pkt_info->local_phy_port;
            cm_packet_header.ip_sa_u.share2.gal_exist = pkt_info->share_fields_u.oam.gal_exist;
            cm_packet_header.ip_sa_u.share2.entropy_label_exist = pkt_info->share_fields_u.oam.entropy_label_exist;
            cm_packet_header.source_port_isolate_id_u.share2.is_up = FALSE;

            if (pkt_info->share_fields_u.oam.link_or_section_oam && (OAM_ACH == pkt_info->share_fields_u.oam.rx_oam_type))
            {
                cm_packet_header.priority = ipe_fwd_ctl.link_oam_priority;
                cm_packet_header.color = ipe_fwd_ctl.link_oam_color;
            }

            if (pkt_info->share_fields_u.oam.dm_en)
            {
                cm_set_dm_rx_timestamp_in_header(&cm_packet_header,pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32,
                                                                pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0);
                cm_packet_header.ip_sa_u.share2.dm_en = pkt_info->share_fields_u.oam.dm_en;
            }
            else if (pkt_info->share_fields_u.oam.lm_received_packet)
            {
                cm_packet_header.fid_u.rx_fcb_31_16 = (pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32 >> 16) & 0xFFFF;
                cm_packet_header.logic_src_port_u.rx_fcb_15_0 = pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32 & 0xFFFF;

                cm_packet_header.src_ctag_offset_type_u.rxtx_fcl_31 = IS_BIT_SET(pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0, 31);
                cm_packet_header.ttl_u.rxtx_fcl_30_23 = (pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 23) & 0xFF;
                cm_packet_header.rxtx_fcl_22_17_u.rxtx_fcl_22_17 = (pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 17) & 0x3F;
                cm_packet_header.src_cvlan_id_valid_u.rxtx_fcl_16 = IS_BIT_SET(pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0, 16);
                cm_packet_header.src_cvlan_id_u.rxtx_fcl_15_4 = (pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 4) & 0xFFF;
                cm_packet_header.rxtx_fcl3_u.rxtx_fcl_3 = IS_BIT_SET(pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0, 3);
                cm_packet_header.rxtx_fcl2_1_u.rxtx_fcl_2_1 = (pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 1) & 0x3;
                cm_packet_header.rxtx_fcl0_u.rxtx_fcl_0 = IS_BIT_SET(pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0, 0);

                cm_packet_header.pbb_src_port_type_u.share2.lm_received_packet = pkt_info->share_fields_u.oam.lm_received_packet;
            }
        }
        else if (SHARE_TYPE_DMTX == pkt_info->share_type)
        {
            cm_packet_header.operation_type = OPERATION_TYPE_DM_TX;
            cm_packet_header.logic_src_port_u.dm_timestamp_17_2 &= 0xFFC0;
            cm_packet_header.logic_src_port_u.dm_timestamp_17_2 |= ((pkt_info->share_fields_u.dmtx.dm_offset >> 2) & 0x3F);
            cm_packet_header.rxtx_fcl3_u.dm_timestamp_1_1 = IS_BIT_SET(pkt_info->share_fields_u.dmtx.dm_offset,1);
            cm_packet_header.rxtx_fcl0_u.dm_timestamp_0_0 = IS_BIT_SET(pkt_info->share_fields_u.dmtx.dm_offset,0);
            cm_set_dm_tx_timestamp_in_header(&cm_packet_header,
                                            pkt_info->share_fields_u.dmtx.time_stamp_61_32,
                                            pkt_info->share_fields_u.dmtx.time_stamp_31_0);

        }
        else if (SHARE_TYPE_PTP == pkt_info->share_type)
        {
            /* PTP */
            cm_packet_header.operation_type = OPERATION_TYPE_PTP;
            cm_set_ptp_timestamp_in_header(&cm_packet_header,pkt_info->share_fields_u.ptp.time_stamp_61_32,
                                                             pkt_info->share_fields_u.ptp.time_stamp_31_0);

            if (ipe_fwd_ctl.ptp_priority_en)
            {
                cm_packet_header.priority = ipe_fwd_ctl.ptp_priority;
            }

            cm_packet_header.pbb_src_port_type_u.share3.ptp_extra_offset = pkt_info->share_fields_u.ptp.ptp_extra_offset;

            /* Transparent clock residence time correction */
            cm_packet_header.source_port_isolate_id_u.share1.ptp_edit_type
                            = (pkt_info->ptp_transparent_clock_en ? PTP_CORRECTION : PTP_NULL_OPERATION);

            cm_packet_header.ip_sa_u.share4.mac_known = pkt_info->mac_known;
            cm_packet_header.ip_sa_u.share4.src_dscp = pkt_info->src_dscp;
        }
        else
        {
            /* normal */
            cm_packet_header.operation_type = OPERATION_TYPE_NORMAL;
            cm_packet_header.flow_u.share1.flow_id = pkt_info->flow_id;
            cm_packet_header.ip_sa_u.share1.layer3_offset = parser_result->l2_s.layer3_offset & 0x7F;
            cm_packet_header.fid_u.share1.acl_dscp_valid = pkt_info->acl_dscp_valid;
            cm_packet_header.ip_sa_u.share1.is_ipv4 = pkt_info->is_ipv4;
            cm_packet_header.ip_sa_u.share1.mac_known = pkt_info->mac_known;

            cm_packet_header.ip_sa_u.share1.src_dscp = pkt_info->src_dscp;
            cm_packet_header.logic_src_port_u.share1.logic_src_port = pkt_info->logic_src_port;
            cm_packet_header.ip_sa_u.share1.acl_dscp = pkt_info->acl_dscp;
            cm_packet_header.ip_sa_u.share1.ecn_aware = pkt_info->ecn_aware;
            cm_packet_header.ip_sa_u.share1.ecn_en = pkt_info->ecn_en;
            cm_packet_header.logic_src_port_u.share1.pbb_check_discard = pkt_info->pbb_check_discard;

            if ((parser_result->l2_s.layer3_offset > 127) &&  cm_packet_header.fid_u.share1.acl_dscp_valid)
            {
                cm_packet_header.fid_u.share1.acl_dscp_valid = FALSE;
            }

            if (SHARE_TYPE_LMTX == pkt_info->share_type)
            {
                cm_packet_header.operation_type = OPERATION_TYPE_LM_TX;

                cm_packet_header.logic_src_port_u.rx_fcb_15_0 = (pkt_info->share_fields_u.lmtx.rx_fcb & 0xFFFF);
                cm_packet_header.fid_u.rx_fcb_31_16 = (pkt_info->share_fields_u.lmtx.rx_fcb >> 16);

                cm_packet_header.ip_sa_u.tx_fcb_31_0 = pkt_info->share_fields_u.lmtx.tx_fcb;
                cm_packet_header.pbb_src_port_type_u.share2.lm_packet_type = pkt_info->share_fields_u.lmtx.lm_packet_type & 0x3;

                cm_packet_header.rxtx_fcl0_u.rxtx_fcl_0 = IS_BIT_SET(pkt_info->share_fields_u.lmtx.rxtx_fcl, 0);
                cm_packet_header.rxtx_fcl2_1_u.rxtx_fcl_2_1 = ((pkt_info->share_fields_u.lmtx.rxtx_fcl >> 1) & 0x3);
                cm_packet_header.rxtx_fcl3_u.rxtx_fcl_3 = IS_BIT_SET(pkt_info->share_fields_u.lmtx.rxtx_fcl, 3);
                cm_packet_header.src_cvlan_id_u.rxtx_fcl_15_4 = ((pkt_info->share_fields_u.lmtx.rxtx_fcl >> 4) & 0xfff);
                cm_packet_header.src_cvlan_id_valid_u.rxtx_fcl_16 = IS_BIT_SET(pkt_info->share_fields_u.lmtx.rxtx_fcl, 16);
                cm_packet_header.rxtx_fcl_22_17_u.rxtx_fcl_22_17 = ((pkt_info->share_fields_u.lmtx.rxtx_fcl >> 17) & 0x3F);
                cm_packet_header.ttl_u.rxtx_fcl_30_23 = ((pkt_info->share_fields_u.lmtx.rxtx_fcl >> 23) & 0xFF);
                cm_packet_header.src_ctag_offset_type_u.rxtx_fcl_31 = IS_BIT_SET(pkt_info->share_fields_u.lmtx.rxtx_fcl, 31);

            }
            else if (pkt_info->capwap_tunnel_valid)
            {
                cm_packet_header.fid_u.share1.capwap_tunnel_valid = TRUE;
                cm_packet_header.rxtx_fcl2_1_u.capwap_state = pkt_info->roaming_state;
                cm_packet_header.rxtx_fcl3_u.capwap_tunnel_type = pkt_info->capwap_tunnel_type;
            }
        }

        sal_memset(bexception, 0, sizeof(greatbelt_exception_info_t));

        if (!asic_hard_error)
        {
            bexception->dest_id_discard = dest_id_discard;
            bexception->exception_sub_index = pkt_info->exception_sub_index;
            bexception->exception_packet_type = pkt_info->packet_type;

            bexception->exception_vector = (pkt_info->port_log_en << 7) | (pkt_info->acl_log_en3 << 6)
                                           | (pkt_info->acl_log_en2 << 5) | (pkt_info->acl_log_en1 << 4)
                                           | (pkt_info->acl_log_en0 << 3) | (pkt_info->l3_span_en << 2)
                                           | (pkt_info->l2_span_en << 1) | pkt_info->exception_en;

            if (discard)
            {
                bexception->exception_vector &= (((ipe_fwd_ctl.log_on_discard & 0x7F) << 1) | 1);
            }

            bexception->l2_span_id = pkt_info->l2_span_id;
            bexception->l3_span_id = pkt_info->l3_span_id;

            bexception->acl_log_id3 = pkt_info->acl_log_id3;
            bexception->acl_log_id2 = pkt_info->acl_log_id2;
            bexception->acl_log_id1 = pkt_info->acl_log_id1;
            bexception->acl_log_id0 = pkt_info->acl_log_id0;

            bexception->egress_exception = 0;

            bexception->exception_number = pkt_info->exception_index;

            if (pkt_info->discard && bexception->exception_vector)
            {
                CMODEL_DEBUG_OUT_INFO("================ IPE Discard and exception ====== START\n");
                CMODEL_DEBUG_OUT_INFO("********** pkt_info->bypass_all = 0x%x\n", pkt_info->bypass_all);
                CMODEL_DEBUG_OUT_INFO("********** exceptionVector = 0x%x\n", bexception->exception_vector);
                CMODEL_DEBUG_OUT_INFO("********** pkt_info->exception_sub_index = 0x%x\n", pkt_info->exception_sub_index);
                CMODEL_DEBUG_OUT_INFO("********** pkt_info->discard_type = %d\n", pkt_info->discard_type);
                CMODEL_DEBUG_OUT_INFO("================ IPE Discard and exception ======= END\n");
            }
            else if (pkt_info->discard)
            {
                CMODEL_DEBUG_OUT_INFO("================ IPE Discard No exception ====== START\n");
                CMODEL_DEBUG_OUT_INFO("********** pkt_info->bypass_all = 0x%x\n", pkt_info->bypass_all);
                CMODEL_DEBUG_OUT_INFO("********** pkt_info->discard_type = %d\n", pkt_info->discard_type);
                CMODEL_DEBUG_OUT_INFO("================ IPE Discard No exception ======= END\n");
            }

            _cm_ipe_forwarding_get_exception_id(bexception,&exception_id);

            critical_packet_en_id = IpeFwdCtl1_CriticalPacketEn31_0_f + (exception_id/32);

            cmd = DRV_IOR(IpeFwdCtl1_t,critical_packet_en_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &critical_packet_en_field));
            critical_packet_en = IS_BIT_SET(critical_packet_en_field,(exception_id - (exception_id/32)*32));

            cm_packet_header.critical_packet = ds_fwd.critical_packet
                                               || ((SHARE_TYPE_OAM == pkt_info->share_type) && ipe_fwd_ctl.rx_ether_oam_critical)
                                               || (pkt_info->exception_en && critical_packet_en)
                                               || (ipe_fwd_ctl.ecn_priority_critical && pkt_info->ecn_priority_en);

            cm_packet_header.cut_through = ((0!= pkt_info->speed) && (0 != ds_fwd.speed) && (pkt_info->speed >= ds_fwd.speed)
                                            && (0 == bexception->exception_vector))
                                            && (I_LOOPBACK_CHANID != in_pkt->chan_id)
                                            && (SHARE_TYPE_OAM != pkt_info->share_type)
                                            && ipe_fwd_ctl.cut_through_en;
        }

        /* ======== bug 4661 ECO begine ========= */
        bexception->dest_id_discard |= asic_hard_error;
        /* ======== bug 4661 ECO end ========= */

        /* DISCARD_STATS */
        if (discard)
        {
            /* just temp for stats, will modify later?? add by zhouw! */
            DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, CM_INGRESS_DISCARD,
                                                        pkt_info->discard_type,
                                                        pkt_info->packet_length));
        }

        cm_gen_greatbelt_packet_header(p_packet_header, &cm_packet_header, FALSE);
    }

    greatbelt_header = (uint8 *)p_packet_header;

    DRV_IF_ERROR_RETURN(swap32((uint32 *)p_packet_header, GREAT_BELT_HEADER_LEN / 4, HOST_TO_NETWORK));
    crc = calculate_crc4((uint8 *)p_packet_header, GREAT_BELT_HEADER_LEN, 0);
    greatbelt_header[GREATBELT_HDR_CRC_OFFSET] &= 0xF0;
    greatbelt_header[GREATBELT_HDR_CRC_OFFSET] |= crc & 0xF;

    DRV_IF_ERROR_RETURN(swap32((uint32 *)p_packet_header, GREAT_BELT_HEADER_LEN / 4, NETWORK_TO_HOST));

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_discard_type)
    {
        cosim_db.store_discard_type(pkt_info->discard, pkt_info->discard_type);
    }

    if (cosim_db.store_bheader)
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_bheader(((void *)p_packet_header), SIM_MODULE_IPE));
    }

#endif

    DRV_IF_ERROR_RETURN(swap32((uint32 *)p_packet_header, GREAT_BELT_HEADER_LEN / 4, HOST_TO_NETWORK));

    /* debug information */
    if(pkt_info->discard)
    {
        sim_cmodel_debug_show_discard(CTC_CMODEL_DEBUG_IPE, pkt_info->discard_type);
    }
    return DRV_E_NONE;
}
