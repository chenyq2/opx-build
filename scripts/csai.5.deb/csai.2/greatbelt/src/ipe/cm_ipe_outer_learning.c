/****************************************************************************
 * cm_ipe_outer_learning.c  Provides IPE lookup handle function.
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Revision:    V4.29.0.
 * Author       XuZx.
 * Date:        2011-10-09.
 * Reason:      Create for GreatBelt v4.29.0
 *
 * Revision:    V4.29.3.
 * Revisor      XuZx.
 * Date:        2011-10-12.
 * Reason:      Sync for GreatBelt v4.29.3
 *
 * Revision:    V5.1.0
 * Author:      Wangcy.
 * Date:        2011-12-12.
 * Reason:      sync spec v5.1.0.
 *
 * Revision:    V5.7.0
 * Author:      Wangcy.
 * Date:        2012-1-17.
 * Reason:      sync spec v5.7.0.
 *
 * Reversion:    V5.11.0
 * Author:       ZhouW
 * Date:         2012-03-01.
 * Reason:       sync spec v5.11.0.
 *
 * Reversion:    V5.13.0
 * Author:       ZhouW
 * Date:         2012-03-12.
 * Reason:       sync spec v5.13.0.
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "ctcutil_lib.h"

/****************************************************************************
* Name:       cm_ipe_outer_learning_handle
* Purpose:    IPE Outer Learning operation.
* Parameters:
* Input:      p_inpkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
* Output:     p_inpkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
int32
cm_ipe_outer_learning_handle(ipe_in_pkt_t *p_inpkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)p_inpkt->pkt_info;
    parsing_result_t *parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;

    ds_mac_t ds_mac;
    ipe_learn_proc_input_info_t learning_info;
    ipe_outer_learning_ctl_t ipe_outer_learning_ctl;

    uint32 cmd = 0;
    uint8 src_mismatch_discard = FALSE;
    uint8 src_port_mismatch = FALSE;
    uint8 need_to_learn = FALSE;
    uint8 port_security_discard = FALSE;
    uint8 vlan_security_discard = FALSE;
    uint8 system_security_discard = FALSE;
    uint8 mac_security_discard = FALSE;
    uint32 mac_sa_31_0 = 0;
    uint16 mac_sa_47_32 = 0;
    uint8 learning_en = FALSE;
    uint16 learning_src_port = 0;
    uint8 is_global_src_port = FALSE;

    uint8 hash_outer_mac_sa_result_valid = FALSE;
    uint8 tcam_outer_mac_sa_result_valid = FALSE;
    uint8 default_entry_valid = FALSE;

    uint8 mac_outer_sa_result_valid = FALSE;
    uint8 outer_mac_sa_hash_conflict = FALSE;

    sal_memset(&ipe_outer_learning_ctl, 0, sizeof(ipe_outer_learning_ctl_t));
    cmd = DRV_IOR(IpeOuterLearningCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_inpkt->chip_id, 0, cmd, &ipe_outer_learning_ctl));

    sal_memset(&ds_mac, 0, sizeof(ds_mac_t));

    /* MAC_SA_HASH_LOOKUP */
    pkt_info->egress_oam_use_fid = pkt_info->is_decap || pkt_info->is_mpls_switched;

    if (pkt_info->outer_mac_sa_lookup_en)
    {
        if (pkt_info->mac_hash_lookup_en)
        {
            hash_outer_mac_sa_result_valid = pkt_info->outer_mac_sa_hash_result_valid;
            default_entry_valid = pkt_info->outer_mac_sa_default_entry_valid;
            outer_mac_sa_hash_conflict = pkt_info->outer_mac_sa_hash_conflict;

        }
        if (pkt_info->mac_tcam_lookup_en)
        {
            tcam_outer_mac_sa_result_valid = pkt_info->tcam_outer_mac_sa_result_valid;
        }

        if (hash_outer_mac_sa_result_valid && !default_entry_valid)
        {
            /* First hash */
            mac_outer_sa_result_valid = hash_outer_mac_sa_result_valid;
            sal_memcpy(&ds_mac, pkt_info->hash_outer_mac_sa_data, sizeof(ds_mac_t));
        }
        else if (tcam_outer_mac_sa_result_valid)
        {
            /* second TCMA */
            mac_outer_sa_result_valid = tcam_outer_mac_sa_result_valid;
            sal_memcpy(&ds_mac, pkt_info->tcam_outer_mac_sa_data, sizeof(ds_mac_t));
            outer_mac_sa_hash_conflict = FALSE;
        }
        else if (hash_outer_mac_sa_result_valid)
        {
            /* Third Default */
            mac_outer_sa_result_valid = hash_outer_mac_sa_result_valid;
            sal_memcpy(&ds_mac, pkt_info->hash_outer_mac_sa_data, sizeof(ds_mac_t));
        }
    }


    /* RESULT_INVALID_SWITCH */
    if (mac_outer_sa_result_valid)
    {
        /* DS_MAC_SA */
        pkt_info->esp_id = (ds_mac.esp_id10_9 << 9) | ds_mac.esp_id8_0;

        if (ds_mac.bridge_aps_select_en)  /* used as bridgeApsSelectValid */
        {
            if (!pkt_info->aps_select_valid0)
            {
                pkt_info->aps_select_valid0 = ds_mac.bridge_aps_select_en; /* apsSelectValid */
                pkt_info->aps_select_protecting_path0 = ds_mac.aps_select_protecting_path;
                pkt_info->aps_select_group_id0 = (ds_mac.esp_id10_9 << 9) | ds_mac.esp_id8_0;
            }
            else if (!pkt_info->aps_select_valid1)
            {
                pkt_info->aps_select_valid1 = ds_mac.bridge_aps_select_en; /* apsSelectValid */
                pkt_info->aps_select_protecting_path1 = ds_mac.aps_select_protecting_path;
                pkt_info->aps_select_group_id1 = (ds_mac.esp_id10_9 << 9) | ds_mac.esp_id8_0;
            }
            else
            {
                pkt_info->aps_select_valid2 = ds_mac.bridge_aps_select_en; /* apsSelectValid */
                pkt_info->aps_select_protecting_path2 = ds_mac.aps_select_protecting_path;
                pkt_info->aps_select_group_id2 = (ds_mac.esp_id10_9 << 9) | ds_mac.esp_id8_0;
            }
        }

        learning_src_port = !ds_mac.learn_source ? pkt_info->global_src_port : pkt_info->outer_learning_logic_src_port;
        is_global_src_port = !ds_mac.learn_source ? 1 : 0;

        src_port_mismatch = !ds_mac.learn_source ? (pkt_info->global_src_port != ds_mac.global_src_port)
                                                 : (pkt_info->outer_learning_logic_src_port != ds_mac.global_src_port);

        need_to_learn = ((ds_mac.learn_en && !ipe_outer_learning_ctl.outer_mac_table_full)
                        || (src_port_mismatch && ds_mac.src_mismatch_learn_en))
                        && (!outer_mac_sa_hash_conflict
                        || !ipe_outer_learning_ctl.outer_mac_hash_conflict_learning_disable);

        /* Security discard */
        src_mismatch_discard = src_port_mismatch
                               && ds_mac.src_mismatch_discard
                               && pkt_info->port_security_en;

        port_security_discard = need_to_learn && pkt_info->mac_security_discard;
        vlan_security_discard = need_to_learn && pkt_info->mac_security_vlan_discard;
        system_security_discard = need_to_learn && ipe_outer_learning_ctl.outer_system_mac_security_discard;

        /* Security exception */
        if (ds_mac.mac_sa_exception_en && ds_mac.src_discard && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_MAC_SA;
        }
        else if (src_mismatch_discard && pkt_info->port_security_exception_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_SRC_MISMATCH;
        }
        else if (port_security_discard && pkt_info->port_security_exception_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PORT_SECURITY;
        }
        else if (vlan_security_discard && ipe_outer_learning_ctl.outer_vlan_security_exception_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_VLAN_SECURITY;
        }
        else if (system_security_discard && ipe_outer_learning_ctl.outer_system_security_exception_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_SYS_SECURITY;
        }

        mac_security_discard = ds_mac.src_discard || src_mismatch_discard
                               || port_security_discard || vlan_security_discard || system_security_discard;

        if (mac_security_discard && (!pkt_info->discard))
        {
            pkt_info->discard_type = IPE_DISCARD_LEARNING_DISCARD;
            pkt_info->discard = TRUE;

            if (ds_mac.src_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! DsMacSa srcDiscard is set!(tunnel terminate)\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }

            if (src_mismatch_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Source port mismatch discard(tunnel terminate)!\n");
                CMODEL_DEBUG_OUT_INFO("++++ PacketInfo.globalSrcPort = %d; DsMacSa.globalSrcPort = %d!\n",
                                       pkt_info->global_src_port, ds_mac.global_src_port);
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }

            if (port_security_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Port security discard!(tunnel terminate)\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }

            if (vlan_security_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Vlan security discard!(tunnel terminate)\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }

            if (system_security_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! System security discard!(tunnel terminate)\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (pkt_info->is_decap && pkt_info->pbb_outer_learning_enable)
        {
            pkt_info->logic_src_port = pkt_info->esp_id;
        }
        else if (pkt_info->is_decap && pkt_info->pbb_outer_learning_disable)
        {
            pkt_info->logic_src_port = pkt_info->esp_id;
            need_to_learn = FALSE;
        }

        /* LEARNING_EN */
        learning_en = need_to_learn && (!mac_security_discard);

        /* LEARNING_DISABLE_SWITCH */
        if (learning_en)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Outer Learning Process");

            /* LEARNING */
            mac_sa_31_0 = MAKE_UINT32(parser_result1->l2_s.mac_sa3, parser_result1->l2_s.mac_sa2,
                                      parser_result1->l2_s.mac_sa1, parser_result1->l2_s.mac_sa0);
            mac_sa_47_32 = MAKE_UINT16(parser_result1->l2_s.mac_sa5, parser_result1->l2_s.mac_sa4);

            sal_memset(&learning_info, 0, sizeof(learning_info));
            learning_info.is_outer_learning = TRUE;
            learning_info.learning_source_port = learning_src_port;
            learning_info.is_global_src_port = is_global_src_port;
            learning_info.vsi_id = pkt_info->outer_vsi_id;
            learning_info.mac_sa_31_0 = mac_sa_31_0;
            learning_info.mac_sa_47_32 = mac_sa_47_32;
            learning_info.is_ether_oam = FALSE;
            learning_info.old_svlan_id = parser_result1->l2_s.svlan_id;
            learning_info.old_cvlan_id = parser_result1->l2_s.cvlan_id;
            learning_info.new_svlan_id = pkt_info->svlan_id;
            learning_info.new_cvlan_id = pkt_info->cvlan_id;

            if (pkt_info->fast_learning_en && ds_mac.fast_learning_en && !outer_mac_sa_hash_conflict)
            {
                learning_info.fast_learning_en = TRUE;
            }
            else
            {
                learning_info.fast_learning_en = FALSE;
            }

            DRV_IF_ERROR_RETURN(cm_ipe_learning_learn_mac_sa(p_inpkt, &learning_info));
        }
    }

    /* UPDATE_INNER_INFO */
    if (pkt_info->inner_packet_lookup)
    {
        /* inner learning, port and vlan based security will be disable */
        pkt_info->mac_security_discard = FALSE;
        pkt_info->mac_security_vlan_discard = FALSE;
        pkt_info->port_security_en = FALSE;

    }

    return DRV_E_NONE;
}

