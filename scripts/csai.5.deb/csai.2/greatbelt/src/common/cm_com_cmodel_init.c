/****************************************************************************
 * cm_com_comdel_init.c: Useful untilities for all modules.
 * Copyright:     (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Revision:      V1.0.
 * Author:       ZhouW.
 * Date:         2010-09-20.
 * Reason:       First Create.
 *
 * Modify History:
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/
bool cmodel_initialized[MAX_LOCAL_CHIP_NUM] = {FALSE};
uint8 hg_plus_version = 1;   /* means hg version plus */

extern int32 sim_ios_set_enable(uint8 enable);

enum ip_lookup_mode_e
{
    IP_LKP_MODE_RESERVED,
    IP_LKP_MODE_LPM,
    IP_LKP_MODE_TCAM,
    IP_LKP_MODE_LPM_AND_TCAM,
};
typedef enum ip_lookup_mode_e ip_lookup_mode_t;

enum fcoe_lookup_mode_e
{
    FCOE_LKP_MODE_RESERVED,
    FCOE_LKP_MODE_HASH,
    FCOE_LKP_MODE_TCAM,
    FCOE_LKP_MODE_LPM_AND_TCAM,
};
typedef enum fcoe_lookup_mode_e fcoe_lookup_mode_e;

enum trill_lookup_mode_e
{
    TRILL_LKP_MODE_RESERVED,
    TRILL_LKP_MODE_HASH,
    TRILL_LKP_MODE_TCAM,
    TRILL_LKP_MODE_LPM_AND_TCAM,
};
typedef enum trill_lookup_mode_e trill_lookup_mode_e;

/* need to flush these table on emulation */
#if (SDK_WORK_PLATFORM == 1)

#else
static tbls_id_t _emulation_flush_table_list_on_board[] = {
DsPhyPort_t,
IpeIntfMapperClaPathMap_t,
IpeBpduProtocolEscapeCam3_t,
IpeBpduProtocolEscapeCamResult3_t,
IpeBpduProtocolEscapeCamResult4_t,
IpeLearningCache_t,
DsDestChannel_t,
DsDestInterface_t,
DsDestPort_t,
DsEgressVlanRangeProfile_t,
EpeNextHopInternal_t,
EpeEditPriorityMap_t,
DsIpv6NatPrefix_t,
DsL3TunnelV4IpSa_t,
DsL3TunnelV6IpSa_t,
DsPortLinkAgg_t,
EpeHdrProcPhyPortMap_t,
DsBufRetrvColorMap_t,
DsApsBridge_t,
DsApsChannelMap_t,
DsMetFifoExcp_t,
AutoGenPktPktCfg_t,
AutoGenPktPktHdr_t,
AutoGenPktRxPktStats_t,
AutoGenPktTxPktStats_t,
DsOamDefectStatus_t,
DsPortProperty_t,
DsPriorityMap_t,
OamDefectCache_t,
DsOamExcp_t,
};
#endif

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/

/*******************************************************************************
 * Name:     _sim_model_ctckal_enable
 * Purpose:  enable / disable simualtion functrions.
 * Input:    enable -- TRUE = enable, and FALSE = disable.
 * Output:   N/A.
 * Return:   SUCCESS
 *           Other = ErrCode
 * Note:     N/A
*******************************************************************************/
static int32
_sim_model_ctckal_enable(uint8 enable)
{
    if (enable)
    {
        /*initialize ctckal */
        DRV_IF_ERROR_RETURN(ctckal_event_init());
        DRV_IF_ERROR_RETURN(ctckal_mutex_init());
        DRV_IF_ERROR_RETURN(ctckal_thread_init());
        DRV_IF_ERROR_RETURN(ctckal_timer_init());
        DRV_IF_ERROR_RETURN(ctckal_queue_init());
    }
    else
    {
        /*release ctckal */
        ctckal_timer_exit();
        ctckal_thread_exit();
        ctckal_event_exit();
        ctckal_mutex_exit();
        ctckal_queue_exit();
    }

    return DRV_E_NONE;
}

#if (SDK_WORK_PLATFORM == 1)

#else
static int32 _emulation_flush_table(uint8 chip_id)
{
    uint32 table_id = 0;
    uint32 tbl_list_num = sizeof(_emulation_flush_table_list_on_board)/sizeof(_emulation_flush_table_list_on_board[0]);
    uint32 tbl_list_index = 0, tbl_index = 0;
    uint32 clear_data[20] = {0};
    uint32 cmd = 0;

    for (tbl_list_index = 0; tbl_list_index < tbl_list_num; tbl_list_index++)
    {
        table_id = _emulation_flush_table_list_on_board[tbl_list_index];
        cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);

        if (TABLE_MAX_INDEX(table_id) != 0)
        {
            //sal_printf("Flush Table %d\n", table_id);
            for (tbl_index = 0; tbl_index < TABLE_MAX_INDEX(table_id); tbl_index++)
            {
                DRV_IF_ERROR_RETURN(drv_ioctl(chip_id, tbl_index, cmd, clear_data));
            }
        }
    }
#if 0
/* unit-test code */
{
    uint32 word_offset = 0;
    FILE *fp = NULL;
    fp = fopen("dump_flush_mem.txt", "w+");
    if (fp == NULL)
    {
        return DRV_E_FILE_OPEN_FAILED;
    }

    for (tbl_list_index = 0; tbl_list_index < tbl_list_num; tbl_list_index++)
    {
        table_id = _emulation_flush_table_list_on_board[tbl_list_index];
        cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);

        if (TABLE_MAX_INDEX(table_id) != 0)
        {
            for (tbl_index = 0; tbl_index < TABLE_MAX_INDEX(table_id); tbl_index++)
            {
                DRV_IF_ERROR_RETURN(drv_ioctl(chip_id, tbl_index, cmd, clear_data));

                for(word_offset = 0; word_offset < TABLE_ENTRY_SIZE(table_id)/4; word_offset++)
                {
                    if (clear_data[word_offset] != 0)
                    {
                        sal_fprintf(fp, "%s [index = %x], [wordOffset = %x], [value = 0x%08x]\n",
                            TABLE_NAME(table_id), tbl_index, word_offset, clear_data[word_offset]);
                    }
                }

                sal_memset(clear_data, 0, sizeof(clear_data));
            }
        }
    }

    fclose(fp);
    fp = NULL;
}
#endif

    return DRV_E_NONE;
}
#endif

extern int32
cm_feature_timer_init(void);

/*******************************************************************************
 * Name   : sim_model_init
 * Purpose:  initialize simulate Cmodel
 * Input  :  void
 * Output :  N/A
 * Return :  SUCCESS
 *          Other   = ErrCode
 * Note   :  N/A
*******************************************************************************/
int32 sim_model_init(um_emu_mode_t um_emu_mode)
{
    uint8 chipid = 0;
    uint8 chip_num = 0;
    uint8 chip_id_base = 0;
    uint8 chip_id_offset = 0;

    DRV_IF_ERROR_RETURN(drv_get_chipnum(&chip_num));
    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chip_id_base));

    for (chipid = chip_id_base; chipid < chip_id_base + chip_num; chipid++)
    {
        chip_id_offset = chipid - chip_id_base;

        if (cmodel_initialized[chip_id_offset])
        {
            if (chipid == chip_id_base + chip_num - 1)
            {
                return DRV_E_NONE;
            }
            else
            {
               continue;
            }
        }
        else
        {
            /* Initialize driver */
            DRV_IF_ERROR_RETURN(sim_model_component_install(chip_id_offset));
            cmodel_initialized[chip_id_offset] = TRUE;
        }
    }


#if (SDK_WORK_PLATFORM == 1)
    /* Initialize simulation test environment */
    DRV_IF_ERROR_RETURN(swemu_socket_init());

    /* Initialize ctckal */
    DRV_IF_ERROR_RETURN(_sim_model_ctckal_enable(TRUE));

    /* Initialize ios */
    DRV_IF_ERROR_RETURN(sim_ios_set_enable(TRUE));

    /* Initialize um emu mode */
    swemu_set_um_emu_mode(um_emu_mode);
#else
    /* flush table */
    for (chip_id_offset = 0; chip_id_offset < chip_num; chip_id_offset++)
    {
        DRV_IF_ERROR_RETURN(_emulation_flush_table(chip_id_offset+chip_id_base));
    }
#endif

    DRV_IF_ERROR_RETURN(cm_feature_timer_init());

    return DRV_E_NONE;
}


/*******************************************************************************
 * Name   :  sim_model_release
 * Purpose:  release simulate Cmodel
 * Input  :  void
 * Output :  N/A
 * Return :  SUCCESS
 *           Other = ErrCode
 * Note   :  N/A
*******************************************************************************/
int32 sim_model_release(void)
{
    uint8 chipid = 0;
    uint8 chip_num = 0;
    uint8 chip_id_base = 0;
    uint8 chip_id_offset = 0;

    DRV_IF_ERROR_RETURN(drv_get_chipnum(&chip_num));
    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chip_id_base));

    for (chipid = chip_id_base; chipid < chip_id_base + chip_num; chipid++)
    {
        chip_id_offset = chipid - chip_id_base;

        if (FALSE == cmodel_initialized[chip_id_offset])
        {
            if (chipid == chip_id_base + chip_num - 1)
            {
                return DRV_E_NONE;
            }
            else
            {
               continue;
            }
        }
        else
        {
            cmodel_initialized[chip_id_offset] = FALSE;
        }
    }

    /* temp code */
//    _sim_interface_all_linklist_operation(1);

    /* Release ctckal */
    DRV_IF_ERROR_RETURN(_sim_model_ctckal_enable(FALSE));

    /* Release ios */
    DRV_IF_ERROR_RETURN(sim_ios_set_enable(FALSE));

    return DRV_E_NONE;
}



#if (SDK_WORK_PLATFORM == 1)


static int32
_sim_model_get_tblid_and_idx_accord_to_hwaddr(uint32 hw_addr, tbls_id_t *tbl_id, uint32 *index)
{
    uint32 max_hw_addr = 0, hw_addr_size_per_idx = 0;
    uint32 temp_index = 0;
    uint32* share_table_list_ptr = NULL;
    tbls_id_t temp_tbl_id = MaxTblId_t;
    uint32 offset = 0;
    uint8 blk_id = 0;
    uint32 start_hw_addr = 0, end_hw_addr = 0;
#if 0
    tbls_id_t exception_tbl_id[] = {DsStats_t, DsOamLmStats0_t,DsOamLmStats1_t,DsOamLmStats2_t,DsOamLmStats_t};
#endif

    /* so lower efficiency interface, only use in CoSim dump file!!! */
    if (DRV_ADDR_IN_DYNAMIC_SRAM_4W_RANGE(hw_addr))
    {
        /* is share dynic table */
        for(temp_index=0; temp_index<MAX_SRAM_SHARE_MEM_ID; temp_index++)
        {
            share_table_list_ptr = sram_share_mem_info[temp_index].p_share_mem_table_list;
            temp_tbl_id = share_table_list_ptr[0];

            if (TABLE_EXT_INFO_PTR(temp_tbl_id) == NULL)
            {
                //sal_printf("%% ERROR! There must be some memory allocation error. dynamic table %s has no ext info\n",
                //    TABLE_NAME(temp_tbl_id));
                //return DRV_E_INVALID_DYNIC_TBL_ALLOC;
                continue;
            }

            if (DYNAMIC_EXT_INFO_PTR(temp_tbl_id) == NULL)
            {
                /* dynamic share list is empty, this share list is not allocated */
                continue;
            }

            for (blk_id = 0; blk_id < MAX_MEMORY_BLOCK_NUM; blk_id ++)
            {
                if (!IS_BIT_SET(DYNAMIC_BITMAP(temp_tbl_id), blk_id))
                {
                    continue;
                }

                if (TABLE_ENTRY_SIZE(temp_tbl_id) == DRV_BYTES_PER_ENTRY)
                {
                    offset = 0;
                }
                else
                {
                    offset = DRV_MEMORY0_BASE_8W-DRV_MEMORY0_BASE_4W;
                }

                start_hw_addr = DYNAMIC_DATA_BASE(temp_tbl_id, blk_id) - offset;
                end_hw_addr = start_hw_addr + DYNAMIC_ENTRY_NUM(temp_tbl_id, blk_id)*DRV_ADDR_BYTES_PER_ENTRY;

                if ((hw_addr >= start_hw_addr) && (hw_addr < end_hw_addr))
                {
                    *tbl_id = temp_tbl_id;  /* find tableId according HWaddress */
                    if (DYNAMIC_ACCESS_MODE(temp_tbl_id) == DYNAMIC_8W_MODE)
                    {
                        *index = DYNAMIC_START_INDEX(temp_tbl_id, blk_id) + (hw_addr - start_hw_addr)/DRV_ADDR_BYTES_PER_ENTRY;
                    }
                    else
                    {
                        *index = DYNAMIC_START_INDEX(temp_tbl_id, blk_id) +
                                (hw_addr - start_hw_addr)/DRV_ADDR_BYTES_PER_ENTRY/(TABLE_ENTRY_SIZE(temp_tbl_id)/DRV_BYTES_PER_ENTRY);
                    }
                    return DRV_E_NONE;
                }

            }
        }


        /* is userId/TunnelId default table */
        for(temp_index=0; temp_index<mem_extern_userid_dft_list.tbl_num; temp_index++)
        {
            temp_tbl_id = mem_extern_userid_dft_list.tbl_list[temp_index];

            if (TABLE_EXT_INFO_PTR(temp_tbl_id) == NULL)
            {
                sal_printf("%% ERROR! There must be some memory allocation error. dynamic table %s has no ext info\n",
                    TABLE_NAME(temp_tbl_id));
                //return DRV_E_INVALID_DYNIC_TBL_ALLOC;
                continue;
            }

            if (DYNAMIC_EXT_INFO_PTR(temp_tbl_id) == NULL)
            {
                /* dynamic share list is empty, not allocated this share list */
                continue;
            }

            /* blk_id < (MAX_MEMORY_BLOCK_NUM - 2), because DsStats and DsOamLmStats is not dump */
            for (blk_id = 0; blk_id < (MAX_MEMORY_BLOCK_NUM); blk_id ++)
            {
                if (!IS_BIT_SET(DYNAMIC_BITMAP(temp_tbl_id), blk_id))
                {
                    continue;
                }

                if (TABLE_ENTRY_SIZE(temp_tbl_id) == DRV_BYTES_PER_ENTRY)
                {
                    offset = 0;
                }
                else
                {
                    offset = DRV_MEMORY0_BASE_8W-DRV_MEMORY0_BASE_4W;
                }

                start_hw_addr = DYNAMIC_DATA_BASE(temp_tbl_id, blk_id) - offset;
                end_hw_addr = start_hw_addr + DYNAMIC_ENTRY_NUM(temp_tbl_id, blk_id)*DRV_ADDR_BYTES_PER_ENTRY;

                if ((hw_addr >= start_hw_addr) && (hw_addr < end_hw_addr))
                {
                    *tbl_id = temp_tbl_id;  /* find tableId according HWaddress */
                    if (DYNAMIC_ACCESS_MODE(temp_tbl_id) == DYNAMIC_8W_MODE)
                    {
                        *index = (hw_addr - start_hw_addr)/DRV_ADDR_BYTES_PER_ENTRY;
                    }
                    else
                    {
                        *index = (hw_addr - start_hw_addr)/DRV_ADDR_BYTES_PER_ENTRY/(TABLE_ENTRY_SIZE(temp_tbl_id)/DRV_BYTES_PER_ENTRY);
                    }
                    return DRV_E_NONE;
                }

            }
        }

        sal_printf("%% ERROR! invalid dynimic address = 0x%8x\n", hw_addr);
        return DRV_E_INVALID_ADDR;
    }
#if 0
    else if (DRV_ADDR_IN_DYNAMIC_SRAM_8W_RANGE(hw_addr))
    {/* no use, logic has problem */
        for(temp_index=0; temp_index<=OAM_MEP_SHARE_TABLE; temp_index++)
        {
            share_table_list_ptr = sram_share_mem_info[temp_index].p_share_mem_table_list;
            drv_table_get_hw_addr(share_table_list_ptr[0], TABLE_MAX_INDEX(share_table_list_ptr[0]), &max_hw_addr);
            if((hw_addr >= TABLE_DATA_BASE(share_table_list_ptr[0]))
                && (hw_addr <= max_hw_addr+TABLE_ENTRY_SIZE(share_table_list_ptr[0])))
            {
                *tbl_id = share_table_list_ptr[0];  /* find tableId according HWaddress */
                if (DRV_IS_SPECIAL_8WORD_TABLE(*tbl_id))
                {
                    *index = (hw_addr - TABLE_DATA_BASE((*tbl_id)))/DRV_ADDR_BYTES_PER_ENTRY;
                }
                else
                {
                    *index = (hw_addr - TABLE_DATA_BASE((*tbl_id)))/(TABLE_ENTRY_SIZE(*tbl_id)/DRV_BYTES_PER_WORD*DRV_ADDR_BYTES_PER_ENTRY);
                }

                return DRV_E_NONE;
            }
        }

        sal_printf("%% ERROR! invalid dynimic address = 0x%8x\n", hw_addr);
        return DRV_E_INVALID_ADDR;
    }
#endif
    else if (DRV_ADDR_IN_TCAMAD_SRAM_4W_RANGE(hw_addr))
    {
        for(temp_index=0; temp_index<mem_extern_tcam_ad_list.tbl_num; temp_index++)
        {
            temp_tbl_id = mem_extern_tcam_ad_list.tbl_list[temp_index];

            if (0 == TABLE_MAX_INDEX(temp_tbl_id))
            {
                continue;
            }

            drv_table_get_hw_addr(temp_tbl_id, TABLE_MAX_INDEX(temp_tbl_id)-1, &max_hw_addr);
            if (DRV_ADDR_IN_TCAMAD_SRAM_8W_RANGE(TABLE_DATA_BASE(temp_tbl_id)))
            {
                offset = DRV_INT_TCAM_AD_MEM_8W_BASE-DRV_INT_TCAM_AD_MEM_4W_BASE;
            }
            else
            {
                offset = 0;
            }
            if((hw_addr >= (TABLE_DATA_BASE(temp_tbl_id)-offset))
                && (hw_addr <= max_hw_addr-offset+TABLE_ENTRY_SIZE(temp_tbl_id)))
            {
                *tbl_id = temp_tbl_id;  /* find tableId according HWaddress */
                *index = (hw_addr - (TABLE_DATA_BASE((*tbl_id))-offset))/(TABLE_ENTRY_SIZE(*tbl_id)/DRV_BYTES_PER_ENTRY*DRV_ADDR_BYTES_PER_ENTRY);
                return DRV_E_NONE;
            }
        }

        sal_printf("%% ERROR! invalid tcamAd address = 0x%8x\n", hw_addr);
        return DRV_E_INVALID_ADDR;
    }
    else if (DRV_ADDR_IN_LPM_TCAM_AD_RANGE(hw_addr))
    {
        if (mem_extern_lpm_tcam_ad_list.tbl_num != 0)
        {
            /* use name of first table in share list to dump info */
            temp_tbl_id = mem_extern_lpm_tcam_ad_list.tbl_list[0];
            drv_table_get_hw_addr(temp_tbl_id, TABLE_MAX_INDEX(temp_tbl_id)-1, &max_hw_addr);
            if (DRV_ADDR_IN_TCAMAD_SRAM_8W_RANGE(TABLE_DATA_BASE(temp_tbl_id)))
            {
                offset = DRV_INT_TCAM_AD_MEM_8W_BASE-DRV_INT_TCAM_AD_MEM_4W_BASE;
            }
            else
            {
                offset = 0;
            }
            if((hw_addr >= (TABLE_DATA_BASE(temp_tbl_id)-offset))
                && (hw_addr <= max_hw_addr-offset+TABLE_ENTRY_SIZE(temp_tbl_id)))
            {
                *tbl_id = temp_tbl_id;  /* find tableId according HWaddress */
                *index = (hw_addr - (TABLE_DATA_BASE((*tbl_id))-offset))/(TABLE_ENTRY_SIZE(*tbl_id)/DRV_BYTES_PER_ENTRY*DRV_ADDR_BYTES_PER_ENTRY);
                return DRV_E_NONE;
            }
        }

        sal_printf("%% ERROR! invalid tcamAd address = 0x%8x\n", hw_addr);
        return DRV_E_INVALID_ADDR;
    }


#if 0
    else if (DRV_ADDR_IN_TCAMAD_SRAM_8W_RANGE(hw_addr))
    {/* no use, logic has problem */
        for(temp_index=0; temp_index<sizeof(tcam_ad_list)/sizeof(uint32); temp_index++)
        {
            temp_tbl_id = tcam_ad_list[temp_index];
            drv_table_get_hw_addr(temp_tbl_id, TABLE_MAX_INDEX(temp_tbl_id), &max_hw_addr);
            if((hw_addr >= TABLE_DATA_BASE(temp_tbl_id))
                && (hw_addr <= max_hw_addr+TABLE_ENTRY_SIZE(temp_tbl_id)))
            {
                *tbl_id = temp_tbl_id;  /* find tableId according HWaddress */
                *index = (hw_addr - TABLE_DATA_BASE((*tbl_id)))/(TABLE_ENTRY_SIZE(*tbl_id)/DRV_BYTES_PER_WORD*DRV_ADDR_BYTES_PER_ENTRY);
                return DRV_E_NONE;
            }
        }

        sal_printf("%% ERROR! invalid tcamAd address = 0x%8x\n", hw_addr);
        return DRV_E_INVALID_ADDR;
    }
#endif
    else if ((DRV_ADDR_IN_TCAM_DATA_RANGE(hw_addr)) || (DRV_ADDR_IN_LPM_TCAM_DATA_RANGE(hw_addr)))
    {
        for (temp_index = 0; temp_index <mem_extern_tcam_key_list.tbl_num; temp_index++)
        {
            temp_tbl_id = mem_extern_tcam_key_list.tbl_list[temp_index];
            drv_tcam_key_get_hw_addr(temp_tbl_id, TABLE_MAX_INDEX(temp_tbl_id)-1, TRUE, &max_hw_addr);
            if((hw_addr >= TABLE_DATA_BASE(temp_tbl_id))
                && (hw_addr <= max_hw_addr+TCAM_KEY_SIZE(temp_tbl_id)))
            {
                *tbl_id = temp_tbl_id;  /* find tableId according HWaddress */
                *index = (hw_addr - TABLE_DATA_BASE((*tbl_id)))/(TCAM_KEY_SIZE(*tbl_id));
                return DRV_E_NONE;
            }
        }

        sal_printf("%% ERROR! invalid TcamKeyData address = 0x%8x\n", hw_addr);
        return DRV_E_INVALID_ADDR;
    }
    else if ((DRV_ADDR_IN_TCAM_MASK_RANGE(hw_addr)) || (DRV_ADDR_IN_LPM_TCAM_MASK_RANGE(hw_addr)))
    {
        for (temp_index = 0; temp_index <mem_extern_tcam_key_list.tbl_num; temp_index++)
        {
            temp_tbl_id = mem_extern_tcam_key_list.tbl_list[temp_index];
            drv_tcam_key_get_hw_addr(temp_tbl_id, TABLE_MAX_INDEX(temp_tbl_id)-1, FALSE, &max_hw_addr);
            if((hw_addr >= TCAM_MASK_BASE(temp_tbl_id))
                && (hw_addr <= max_hw_addr+TCAM_KEY_SIZE(temp_tbl_id)))
            {
                *tbl_id = temp_tbl_id;  /* find tableId according HWaddress */
                *index = (hw_addr - TCAM_MASK_BASE((*tbl_id)))/(TCAM_KEY_SIZE(*tbl_id));
                return DRV_E_NONE;
            }
        }

        sal_printf("%% ERROR! invalid TcamKeyMask address = 0x%8x\n", hw_addr);
        return DRV_E_INVALID_ADDR;
    }
    else /* !dynicTable & !TcamAD & !TcamKey */
    {
        for (temp_tbl_id = 0; temp_tbl_id <MaxTblId_t; temp_tbl_id++)
        {
            drv_table_get_hw_addr(temp_tbl_id, TABLE_MAX_INDEX(temp_tbl_id)-1, &max_hw_addr);
            if((hw_addr >= TABLE_DATA_BASE(temp_tbl_id))
                && (hw_addr <= max_hw_addr+TABLE_ENTRY_SIZE(temp_tbl_id)))
            {
                *tbl_id = temp_tbl_id;  /* find tableId according HWaddress */
                DRV_IF_ERROR_RETURN(drv_table_consum_hw_addr_size_per_index(*tbl_id, &hw_addr_size_per_idx));
                *index = (hw_addr - TABLE_DATA_BASE((*tbl_id)))/(DRV_BYTES_PER_WORD*hw_addr_size_per_idx);
                return DRV_E_NONE;
            }
        }

        sal_printf("%% ERROR! invalid normal table address = 0x%8x\n", hw_addr);
        return DRV_E_INVALID_ADDR;
    }
}

/****************************************************************************
 * Name:    sim_model_sram_mem_dump
 * Purpose: The function dump chip Sram in GreatBelt to a file
            only written items are dumped.
 * Input:   filename - dump sram configuration file name's pointer.
 * Output:  N/A
 * Return:  SUCCESS
 *          Other = ErrCode
 * Note:    N/A
****************************************************************************/
int32
sim_model_sram_mem_dump(char *filename)
{
    FILE *fp = NULL;
    char comment[128] = {0};
    char table_name[128] = {0};
    char tempBuf[128] = {0};
    int32 ret = DRV_E_NONE;
    uint32 tbl_id = 0;
    uint32 idx_tmp = 0, word_offset = 0, index = 0;
    uint32 data = 0;
    uint8 chip_id_base = 0, chip_num = 0;
    uint8 chip_id= 0, chip_id_offset = 0;
    char error_buffer[128] = {0};

    uint32 rtl_addr = 0;
    uintptr cmodel_addr = 0;
    /*****************************************************************/
    if (!filename)
    {
        ret = DRV_E_INVALID_PTR;
        goto RELEASE;
    }

    ret = drv_get_chipnum(&chip_num);
    if (ret != DRV_E_NONE)
    {
        goto RELEASE;
    }

    ret = (drv_get_chipid_base(&chip_id_base));
    if (ret != DRV_E_NONE)
    {
        goto RELEASE;
    }

    fp = fopen(filename, "w");
    if (NULL == fp)
    {
        perror(error_buffer);
        CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! No such Sram dump cfg file <%s>\n", filename);
        ret = DRV_E_FILE_OPEN_FAILED;
        goto RELEASE;
    }

    for (chip_id_offset = 0; chip_id_offset < chip_num; chip_id_offset++)
    {
        chip_id = chip_id_base + chip_id_offset;

        /*---- Dump other staic tables (per-table) ----*/
        for (tbl_id = 0; tbl_id < MaxTblId_t; tbl_id++)
        {
            /* Do not dump all share table key configuration */
            /* if table is tcam key , dynamic table, tcam ad, dump in other processer */
            if (drv_table_is_tcam_key(tbl_id) || drv_table_is_dynamic_table(tbl_id)
                || sram_model_is_tcam_ad_table(chip_id_offset,tbl_id))
            {
                continue;
            }

            /* don't dump the stats and lmstats table info */
            if ((tbl_id == DsStats_t) || (tbl_id == DsOamLmStats0_t)
                || (tbl_id == DsOamLmStats1_t) || (tbl_id == DsOamLmStats_t))
            {
                continue;
            }

           // tbl_cmodel_baseaddr = cmodel_tbls_info[chip_id_offset][tbl_id].sw_data_base;
            sal_memset(comment, 0, sizeof(comment));
            sal_memset(tempBuf, 0, sizeof(tempBuf));

            for (idx_tmp = 0; idx_tmp < TABLE_MAX_INDEX(tbl_id); idx_tmp++)
            {
                rtl_addr = 0;
                cmodel_addr = 0;

                /* check write bit */
                if (!drv_model_sram_tbl_get_wbit(chip_id_offset, tbl_id, idx_tmp))
                {
                    continue;
                }

                sram_model_get_sw_address_by_tbl_id_and_index(chip_id_offset, tbl_id, idx_tmp, &cmodel_addr);

                drv_table_get_hw_addr(tbl_id, idx_tmp, &rtl_addr);

                for (word_offset = 0; word_offset < TABLE_ENTRY_SIZE(tbl_id)/DRV_BYTES_PER_WORD; word_offset++)
                {
                    /* get vaule from the address */
                    if (drv_io_api.drv_sram_read_entry)
                    {
                        ret = drv_io_api.drv_sram_read_entry(chip_id_offset,
                                                    cmodel_addr + word_offset * DRV_BYTES_PER_WORD,
                                                    &data, DRV_BYTES_PER_WORD);
                        if (ret)
                        {
                            CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! TableID %d Static Sram read error!\n", tbl_id);
                            goto RELEASE;
                        }
                    }
                    else
                    {
                        CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! drv_io_api.drv_sram_read_entry is NULL!! Line = %d\n", __LINE__);
                        goto RELEASE;
                    }

                    /* get the register's name */
                    if (drv_get_tbl_string_by_id(tbl_id, comment) < 0)
                    {
                        CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! Get TableName by TblId error! TblId: %d, Line = %d\n",
                                              tbl_id, __LINE__);
                        goto RELEASE;
                    }
                    else
                    {
                        /* format: <chipid> <RTL_Addr> <Value> #<TableName> index%d */
                        sal_sprintf(tempBuf, " [%d/0x%x]", idx_tmp, idx_tmp);
                        sal_strcat(comment, tempBuf);
                        sal_fprintf(fp, "%02d %08x %08x #%s\n", chip_id,
                                    rtl_addr + word_offset*DRV_BYTES_PER_WORD,
                                    data, comment);
                        sal_memset(tempBuf, 0, sizeof(tempBuf));
                        sal_memset(comment, 0, sizeof(comment));
                    }
                }
            }
        }

        /*---- Dump dynic EDram (per-80bits cfg dump) ----*/
        for (idx_tmp = 0; idx_tmp < DRV_DYNAMIC_SRAM_MAX_ENTRY_NUM; idx_tmp++)
        {
            if (sram_info[chip_id_offset].dynamic_mem_wbit[idx_tmp] == FALSE)
            {
                continue;
            }

            tbl_id = MaxTblId_t;
            index = 0;
            sal_memset(comment, 0, sizeof(comment));
            sal_memset(tempBuf, 0, sizeof(tempBuf));
            sal_memset(table_name, 0, sizeof(table_name));

            cmodel_addr = sram_info[chip_id_offset].dynamic_mem_base + DRV_BYTES_PER_ENTRY*idx_tmp;
            rtl_addr = DRV_MEMORY0_BASE_4W + DRV_ADDR_BYTES_PER_ENTRY*idx_tmp;

            DRV_IF_ERROR_RETURN(_sim_model_get_tblid_and_idx_accord_to_hwaddr(rtl_addr, &tbl_id, &index));

            /* don't dump the stats and lmstats table info */
            if ((tbl_id == DsStats_t) || (tbl_id == DsOamLmStats0_t)
                || (tbl_id == DsOamLmStats1_t) || (tbl_id == DsOamLmStats_t))
            {
                continue;
            }

            if (drv_get_tbl_string_by_id(tbl_id, table_name) < 0)
            {
                CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! Get TableName by TblId error! TblId: %d, Line = %d\n",
                                      tbl_id, __LINE__);
                goto RELEASE;
            }

            for (word_offset = 0; word_offset < DRV_WORDS_PER_ENTRY; word_offset++)
            {
                /* get vaule from the address */
                if (drv_io_api.drv_sram_read_entry)
                {
                    ret = drv_io_api.drv_sram_read_entry(chip_id_offset, cmodel_addr + word_offset * DRV_BYTES_PER_WORD,
                                                &data, DRV_BYTES_PER_WORD);
                    if (ret)
                    {
                        CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! TableID %d DynimicMem read error!\n", tbl_id);
                        goto RELEASE;
                    }
                }
                else
                {
                    CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! drv_io_api.drv_sram_read_entry is NULL!! Line = %d\n", __LINE__);
                    goto RELEASE;
                }

                /* format: <chipid> <RTL_Addr> <Value> #DynimicTable index 0x%x DetailTableName[index]*/
                sal_sprintf(tempBuf, " [%d/0x%x] %s [%d/0x%x]", idx_tmp, idx_tmp, table_name, index, index);
                sal_strcat(comment, "DynamicMem");
                sal_strcat(comment, tempBuf);
                sal_fprintf(fp, "%02d %08x %08x #%s\n", chip_id,
                            rtl_addr + word_offset*DRV_BYTES_PER_WORD,
                            data, comment);
                sal_memset(tempBuf, 0, sizeof(tempBuf));
                sal_memset(comment, 0, sizeof(comment));


            }
        }

        /*---- Dump TcamAD Ram (per-80bits) ----*/
        for (idx_tmp = 0; idx_tmp < DRV_INT_TCAM_AD_MAX_ENTRY_NUM; idx_tmp++)
        {
            if (sram_info[chip_id_offset].tcam_ad_mem_wbit[idx_tmp] == FALSE)
            {
                continue;
            }

            tbl_id = MaxTblId_t;
            index = 0;
            sal_memset(comment, 0, sizeof(comment));
            sal_memset(tempBuf, 0, sizeof(tempBuf));
            sal_memset(table_name, 0, sizeof(table_name));

            cmodel_addr = sram_info[chip_id_offset].tcam_ad_mem_base + DRV_BYTES_PER_ENTRY*idx_tmp;
            rtl_addr = DRV_INT_TCAM_AD_MEM_4W_BASE + DRV_ADDR_BYTES_PER_ENTRY*idx_tmp;

            for (word_offset = 0; word_offset < DRV_WORDS_PER_ENTRY; word_offset++)
            {
                /* get vaule from the address */
                if (drv_io_api.drv_sram_read_entry)
                {
                    ret = drv_io_api.drv_sram_read_entry(chip_id_offset, cmodel_addr + word_offset * DRV_BYTES_PER_WORD,
                                                &data, DRV_BYTES_PER_WORD);
                    if (ret)
                    {
                        CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! TableID %d TcamADMem read error!\n", tbl_id);
                        goto RELEASE;
                    }
                }
                else
                {
                    CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! drv_io_api.drv_sram_read_entry is NULL!! Line = %d\n", __LINE__);
                    goto RELEASE;
                }

                _sim_model_get_tblid_and_idx_accord_to_hwaddr(rtl_addr, &tbl_id, &index);
                if (drv_get_tbl_string_by_id(tbl_id, table_name) < 0)
                {
                    CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! Get TableName by TblId error! TblId: %d, Line = %d\n",
                                          tbl_id, __LINE__);
                    goto RELEASE;
                }
                else
                {
                    /* format: <chipid> <RTL_Addr> <Value> #TcamAdMem index%d */
                    sal_sprintf(tempBuf, " [%d/0x%x] %s [%d/0x%x]", idx_tmp, idx_tmp, table_name, index, index);
                    sal_strcat(comment, "TcamAdMem");
                    sal_strcat(comment, tempBuf);
                    sal_fprintf(fp, "%02d %08x %08x #%s\n", chip_id,
                                rtl_addr + word_offset*DRV_BYTES_PER_WORD,
                                data, comment);
                    sal_memset(tempBuf, 0, sizeof(tempBuf));
                    sal_memset(comment, 0, sizeof(comment));
                }
            }
        }

        /*---- Dump Lpm TcamAD Ram (per-160bits) ----*/
        /* total 256*160bit memory space */
        for (idx_tmp = 0; idx_tmp < (DRV_INT_LPM_TCAM_AD_MAX_ENTRY_NUM/2); idx_tmp++)
        {
            if (sram_info[chip_id_offset].lpm_tcam_ad_mem_wbit[idx_tmp*2] == FALSE)
            {
                continue;
            }

            tbl_id = MaxTblId_t;
            index = 0;
            sal_memset(comment, 0, sizeof(comment));
            sal_memset(tempBuf, 0, sizeof(tempBuf));
            sal_memset(table_name, 0, sizeof(table_name));

            cmodel_addr = sram_info[chip_id_offset].lpm_tcam_ad_mem_base + (2*DRV_BYTES_PER_ENTRY)*idx_tmp;
            rtl_addr = DRV_INT_LPM_TCAM_AD_ASIC_BASE + (2*DRV_ADDR_BYTES_PER_ENTRY)*idx_tmp;

            for (word_offset = 0; word_offset < DRV_WORDS_PER_ENTRY*2; word_offset++)
            {
                /* get vaule from the address */
                if (drv_io_api.drv_sram_read_entry)
                {
                    ret = drv_io_api.drv_sram_read_entry(chip_id_offset, cmodel_addr + word_offset * DRV_BYTES_PER_WORD,
                                                &data, DRV_BYTES_PER_WORD);
                    if (ret)
                    {
                        CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! TableID %d TcamADMem read error!\n", tbl_id);
                        goto RELEASE;
                    }
                }
                else
                {
                    CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! drv_io_api.drv_sram_read_entry is NULL!! Line = %d\n", __LINE__);
                    goto RELEASE;
                }

                _sim_model_get_tblid_and_idx_accord_to_hwaddr(rtl_addr, &tbl_id, &index);
                if (drv_get_tbl_string_by_id(tbl_id, table_name) < 0)
                {
                    CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! Get TableName by TblId error! TblId: %d, Line = %d\n",
                                          tbl_id, __LINE__);
                    goto RELEASE;
                }
                else
                {
                    /* format: <chipid> <RTL_Addr> <Value> #TcamAdMem index%d */
                    sal_sprintf(tempBuf, " [%d/0x%x] %s [%d/0x%x]", idx_tmp, idx_tmp, table_name, index, index);
                    sal_strcat(comment, "TcamAdMem");
                    sal_strcat(comment, tempBuf);
                    sal_fprintf(fp, "%02d %08x %08x #%s\n", chip_id,
                                rtl_addr + word_offset*DRV_BYTES_PER_WORD,
                                data, comment);
                    sal_memset(tempBuf, 0, sizeof(tempBuf));
                    sal_memset(comment, 0, sizeof(comment));
                }
            }
        }

    }

RELEASE:
    if (fp != NULL)
    {
        fclose(fp);
        fp = NULL;
    }

    return ret;
}

/****************************************************************************
 * Name:   sim_model_tcam_mem_dump
 * Purpose: The function dump chip Tcam in GreatBelt to a file
           only written items are dumped.
 * Input:   filename - dump tcam configuration file name's pointer.
 * Output:  N/A
 * Return:  SUCCESS
 *         Other   = ErrCode
 * Note:    N/A
****************************************************************************/
int32
sim_model_tcam_mem_dump(char *filename)
{
    FILE *fp = NULL;
    uint8 chip_id = 0, chip_num = 0, chip_id_base = 0, chip_id_offset = 0;
    int32 ret = DRV_E_NONE;
    uint32 table_id= MaxTblId_t;
    uint32 rtl_data_addr = 0, cmodel_data_addr = 0, rtl_mask_addr = 0, cmodel_mask_addr = 0, tcam_entry_num = 0;
    uint32 rtl_database_addr = 0, rtl_maskbase_addr = 0;
    uintptr cmodel_database_addr = 0;
    uintptr cmodel_maskbase_addr = 0;
    uint32 *tcam_model_wbit_base = NULL;
    uint32 table_index = 0, entry_index = 0, word_offset = 0;
    uint32 data_entry[MAX_ENTRY_WORD] = {0}, mask_entry[MAX_ENTRY_WORD] = {0};

    char comment[128] = {0}, table_name[128] = {0};
    char error_buffer[128] = {0};
    bool tcam_chip_cnt_flag = FALSE;

    if (!filename)
    {
        ret = DRV_E_INVALID_PTR;
        goto RELEASE;
    }

    ret = drv_get_chipnum(&chip_num);
    if (ret != DRV_E_NONE)
    {
        goto RELEASE;
    }

    ret = (drv_get_chipid_base(&chip_id_base));
    if (ret != DRV_E_NONE)
    {
        goto RELEASE;
    }

    fp = fopen (filename, "w");
    if (NULL == fp)
    {
        perror(error_buffer);
        CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! No such Tcam dump cfg file <%s>\n", filename);
        ret = DRV_E_FILE_OPEN_FAILED;
        goto RELEASE;
    }

    for (chip_id_offset = 0; chip_id_offset < chip_num; chip_id_offset++)
    {
        chip_id = chip_id_base + chip_id_offset;

#if 1
        /* TCAM (8K*80bits & 256*80bits) Dump */
LOOP_FLAG:
        if (!tcam_chip_cnt_flag)  /* Firstly dump 8k * 80bits Tcam cfg */
        {
            tcam_model_wbit_base = tcam_info.int_tcam_wbit[chip_id_offset];
            cmodel_database_addr = (uintptr)tcam_info.int_tcam_data_base[chip_id_offset];
            cmodel_maskbase_addr = (uintptr)tcam_info.int_tcam_mask_base[chip_id_offset];
            rtl_database_addr = DRV_INT_TCAM_KEY_DATA_ASIC_BASE;
            rtl_maskbase_addr = DRV_INT_TCAM_KEY_MASK_ASIC_BASE;
            tcam_entry_num = DRV_INT_TCAM_KEY_MAX_ENTRY_NUM;
            tcam_chip_cnt_flag = TRUE;
        }
        else
        {
            tcam_model_wbit_base = tcam_info.int_lpm_tcam_wbit[chip_id_offset];
            cmodel_database_addr = (uintptr)tcam_info.int_lpm_tcam_data_base[chip_id_offset];
            cmodel_maskbase_addr = (uintptr)tcam_info.int_lpm_tcam_mask_base[chip_id_offset];
            rtl_database_addr = DRV_INT_LPM_TCAM_DATA_ASIC_BASE;
            rtl_maskbase_addr = DRV_INT_LPM_TCAM_MASK_ASIC_BASE;
            tcam_entry_num = DRV_INT_LPM_TCAM_MAX_ENTRY_NUM;
            tcam_chip_cnt_flag = FALSE;
        }

        for (entry_index = 0; entry_index < tcam_entry_num; entry_index++)
        {
            if (!IS_BIT_SET(tcam_model_wbit_base[entry_index/DRV_BITS_PER_WORD], entry_index%DRV_BITS_PER_WORD))
            {
                continue;
            }

            cmodel_data_addr = cmodel_database_addr + entry_index * DRV_BYTES_PER_ENTRY;
            cmodel_mask_addr = cmodel_maskbase_addr + entry_index * DRV_BYTES_PER_ENTRY;
            rtl_data_addr = rtl_database_addr + entry_index * DRV_BYTES_PER_ENTRY;
            rtl_mask_addr = rtl_maskbase_addr + entry_index * DRV_BYTES_PER_ENTRY;

            /* Get TcamKey name and index according to HwDataAddr */
            table_id = MaxTblId_t;
            table_index = 0;
            _sim_model_get_tblid_and_idx_accord_to_hwaddr(rtl_data_addr, &table_id, &table_index);
            sal_memset(table_name, 0, sizeof(table_name));
            if (drv_get_tbl_string_by_id(table_id, table_name) < 0)
            {
                CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! Fail to get TcamTableName by TcamTblId ! TcamTblId: %d, Line = %d\n",
                                        table_id, __LINE__);
                goto RELEASE;
            }

            rtl_data_addr = rtl_database_addr + entry_index * DRV_ADDR_BYTES_PER_ENTRY;
            rtl_mask_addr = rtl_maskbase_addr + entry_index * DRV_ADDR_BYTES_PER_ENTRY;

            /* Get Data from the address */
            sal_memset(data_entry, 0, sizeof(data_entry));
            sal_memset(mask_entry, 0, sizeof(mask_entry));
            ret = tcam_model_read(chip_id_offset, cmodel_data_addr, data_entry, DRV_BYTES_PER_ENTRY);
            if (ret<0)
            {
                CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! Fail to read TcamModel data! %s[%d] RTLDataAddr = 0x%8x, Line = %d\n",
                                     table_name, table_index, rtl_data_addr, __LINE__);
                goto RELEASE;
            }

            /* Get Mask from the address */
            ret = tcam_model_read(chip_id_offset, cmodel_mask_addr, mask_entry, DRV_BYTES_PER_ENTRY);
            if (ret<0)
            {
                CMODEL_DEBUG_OUT_INFO("CModelDumpCfg ERROR! Fail to read TcamModel mask! %s[%d] RTLMaskAddr = 0x%8x, Line = %d\n",
                                     table_name, table_index, rtl_mask_addr, __LINE__);
                goto RELEASE;
            }

            /* per-addr(word) dump */
            for (word_offset = 0; word_offset < DRV_WORDS_PER_ENTRY; word_offset++)
            {
                /* format: <chipid> <RTL_Addr> <Value> #TcamKeyData index 0x%x DetailTableName[index]*/
                /* Dump TcamKey Data */
                sal_memset(comment, 0, sizeof(comment));
                sal_memcpy(comment, table_name, sizeof(table_name));
                sal_sprintf(comment, " [%d/0x%x] %s [%d/0x%x]",
                            entry_index, entry_index, table_name, table_index, table_index);

                if (DRV_INT_TCAM_KEY_DATA_ASIC_BASE == rtl_database_addr)
                {
                    sal_fprintf(fp, "%02d %08x %08x #TcamKeyData%s\n", chip_id, rtl_data_addr,
                                data_entry[word_offset], comment);
                }
                else if (DRV_INT_LPM_TCAM_DATA_ASIC_BASE == rtl_database_addr)
                {
                    sal_fprintf(fp, "%02d %08x %08x #LpmTcamKeyData%s\n", chip_id, rtl_data_addr,
                                data_entry[word_offset], comment);
                }
                rtl_data_addr += DRV_BYTES_PER_WORD;
            }

            for (word_offset = 0; word_offset < DRV_WORDS_PER_ENTRY; word_offset++)
            {
                /* format: <chipid> <RTL_Addr> <Value> #TcamKeyMask index 0x%x DetailTableName[index]*/
                /* Dump TcamKey Data */
                sal_memset(comment, 0, sizeof(comment));
                sal_memcpy(comment, table_name, sizeof(table_name));
                sal_sprintf(comment, " [%d/0x%x] %s [%d/0x%x]",
                            entry_index, entry_index, table_name, table_index, table_index);
                /* Dump TcamKey Mask */
                if (DRV_INT_TCAM_KEY_MASK_ASIC_BASE == rtl_maskbase_addr)
                {
                    sal_fprintf(fp, "%02d %08x %08x #TcamKeyMask%s\n", chip_id, rtl_mask_addr,
                                mask_entry[word_offset], comment);
                }
                else if (DRV_INT_LPM_TCAM_MASK_ASIC_BASE == rtl_maskbase_addr)
                {
                    sal_fprintf(fp, "%02d %08x %08x #LpmTcamKeyMask%s\n", chip_id, rtl_mask_addr,
                                mask_entry[word_offset], comment);
                }
                rtl_mask_addr += DRV_BYTES_PER_WORD;
            }
        }

        if (tcam_chip_cnt_flag)
        {
            goto LOOP_FLAG;
        }
#else
        /* Dump each tcam key cfg process */
        for (id_tmp = 0; id_tmp < key_num; id_tmp++)
        {
            sal_memset(comment, 0, sizeof(comment));
            key_id = keyid_list[id_tmp];

            if (TABLE_MAX_INDEX(key_id) == 0)
            {
                continue;
            }

            if (drv_get_tbl_string_by_id(key_id, comment) < 0)
            {
                CMODEL_DEBUG_OUT_INFO("%% Get Table Name by TblId error! TblId: 0x%x, line = %d\n", key_id, __LINE__);
                goto RELEASE;
            }

            if (((TABLE_DATA_BASE(key_id) >= DRV_INT_TCAM_KEY_DATA_ASIC_BASE)
                 && (TABLE_DATA_BASE(key_id) < tcam_info.max_int_tcam_data_base))
                && ((TCAM_MASK_BASE(key_id) >= DRV_INT_TCAM_KEY_MASK_ASIC_BASE)
                 && (TCAM_MASK_BASE(key_id) < tcam_info.max_int_tcam_mask_base)))
            {
                tcam_real_data_base = DRV_INT_TCAM_KEY_DATA_ASIC_BASE;
                tcam_real_mask_base = DRV_INT_TCAM_KEY_MASK_ASIC_BASE;
                tcam_model_wbit_base = tcam_info.int_tcam_wbit[chip_id_offset];
            }
            else if (((TABLE_DATA_BASE(key_id) >= DRV_EXT_TCAM_KEY_DATA_ASIC_BASE)
                 && (TABLE_DATA_BASE(key_id) < tcam_info.max_ext_tcam_data_base))
                && ((TCAM_MASK_BASE(key_id) >= DRV_EXT_TCAM_KEY_MASK_ASIC_BASE)
                 && (TCAM_MASK_BASE(key_id) < tcam_info.max_ext_tcam_mask_base)))
            {
                tcam_real_data_base = DRV_EXT_TCAM_KEY_DATA_ASIC_BASE;
                tcam_real_mask_base = DRV_EXT_TCAM_KEY_MASK_ASIC_BASE;
                tcam_model_wbit_base = tcam_info.ext_tcam_wbit[chip_id_offset];
            }
            else if (((TABLE_DATA_BASE(key_id) >= DRV_INT_LPM_TCAM_DATA_ASIC_BASE)
                 && (TABLE_DATA_BASE(key_id) < tcam_info.max_int_lpm_tcam_data_base))
                && ((TCAM_MASK_BASE(key_id) >= DRV_INT_LPM_TCAM_MASK_ASIC_BASE)
                 && (TCAM_MASK_BASE(key_id) < tcam_info.max_int_lpm_tcam_mask_base)))
            {
                tcam_real_data_base = DRV_INT_LPM_TCAM_DATA_ASIC_BASE;
                tcam_real_mask_base = DRV_INT_LPM_TCAM_MASK_ASIC_BASE;
                tcam_model_wbit_base = tcam_info.int_lpm_tcam_wbit[chip_id_offset];
            }
            else
            {
                CMODEL_DEBUG_OUT_INFO("%% Invalid Tcam Key address! TblId: 0x%x; TblName: %s, Line = %d\n",
                                       key_id, comment, __LINE__);
                ret = DRV_E_TCAM_KEY_DATA_ADDRESS;
                goto RELEASE;
            }

            offset = (TABLE_ENTRY_SIZE(key_id) - TCAM_KEY_SIZE(key_id))/DRV_BYTES_PER_WORD; /* word offset */

            for (index = 0; index < TABLE_MAX_INDEX(key_id); index++)
            {
                asic_data_address = TABLE_DATA_BASE(key_id) + index * TCAM_KEY_SIZE(key_id);

                asic_mask_address = TCAM_MASK_BASE(key_id) + index * TCAM_KEY_SIZE(key_id);

                /* Check the index's each wbits */
                bool index_valid = TRUE;
                entry_num_each_idx = TCAM_KEY_SIZE(key_id)/DRV_BYTES_PER_ENTRY;
                for (i = 0; i < entry_num_each_idx; ++i)
                {
                    entry_num_offset = ((TABLE_DATA_BASE(key_id) - tcam_real_data_base)/DRV_BYTES_PER_ENTRY
                          + index * entry_num_each_idx + i);

                    if (IS_BIT_SET(tcam_model_wbit_base[entry_num_offset/DRV_BITS_PER_WORD],
                                   entry_num_offset%DRV_BITS_PER_WORD))
                    {
                        index_valid &= TRUE;
                        continue;
                    }
                    else
                    {
                        index_valid &= FALSE;
                    }
                }

                if (index_valid)
                {
                    if (chip_id_offset >= MAX_LOCAL_CHIP_NUM)
                    {
                        CMODEL_DEBUG_OUT_INFO("%% Out of chip_id number when reading tcam. chipid_offset = %d\n",
                                               chip_id_offset);
                        ret = DRV_E_INVALID_CHIP;
                        goto RELEASE;
                    }

                    /* read one index's tcam key data and mask value */
                    if (!drv_io_api.drv_tcam_tbl_read)
                    {
                        CMODEL_DEBUG_OUT_INFO("%% drv_io_api.drv_tcam_tbl_read is NULL!! Line = %d\n", __LINE__);
                        goto RELEASE;
                    }

                    ret = drv_io_api.drv_tcam_tbl_read(chip_id_offset, key_id, index, &entry);
                    if (ret < 0)
                    {
                        CMODEL_DEBUG_OUT_INFO("%% Get DATA&MASK comment error, Line = %d\n", __LINE__);
                        CMODEL_DEBUG_OUT_INFO("%% tbl_name: %s; tbl_id: 0x%x, index: 0x%x\n", comment, key_id, index);
                        goto RELEASE;
                    }
                    else
                    {
                        uint8 comment_data[128] = {0};
                        uint8 comment_mask[128] = {0};

                        /* CMODEL_DEBUG_OUT_INFO the index's data & mask value according to each word format */
                        for (i = 0; i < TCAM_KEY_SIZE(key_id)/DRV_BYTES_PER_WORD; ++i) /* i unit: word */
                        {
                            /* dump tcam key data */
                            sal_memset(tempBuf, 0, sizeof(tempBuf));
                            sal_memset(comment_data, 0, sizeof(comment_data));
                            sal_memcpy(comment_data, comment, sizeof(comment));
                            sal_sprintf(tempBuf, "[%d/0x%x] Data", index, index);
                            sal_strcat(comment_data, tempBuf);

                            /* Tcam key data output */
                            sal_fprintf(fp, "%02d %08x %08x #%s\n",
                                        chip_id,
                                        asic_data_address + i*DRV_BYTES_PER_WORD,
                                        *(entry.data_entry + offset + i),
                                        comment_data);

                            /* dump tcam key mask */
                            sal_memset(tempBuf, 0, sizeof(tempBuf));
                            sal_memset(comment_mask, 0, sizeof(comment_mask));
                            sal_memcpy(comment_mask, comment, sizeof(comment));
                            sal_sprintf(tempBuf, "[%d/0x%x] Mask", index, index);
                            sal_strcat(comment_mask, tempBuf);

                            /* Tcam key mask output */
                            sal_fprintf(fp, "%02d %08x %08x #%s\n",
                                        chip_id,
                                        asic_mask_address + i*DRV_BYTES_PER_WORD,
                                        *(entry.mask_entry + offset + i),
                                        comment_mask);
                        }
                    }
                }
            }
        }
#endif
    }

RELEASE:
    if (fp != NULL)
    {
        fclose(fp);
        fp = NULL;
    }
    return ret;
}

















#endif

