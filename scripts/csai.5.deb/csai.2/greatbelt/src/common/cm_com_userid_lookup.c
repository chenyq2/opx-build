/****************************************************************************
 * cm_com_userid_lookup.c  cmodel userid hash lookup
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V2.0.
 * Author:       XuZx
 * Date:         2011-4-12.
 * Reason:       Create for GreatBelt v2.0.
 *
 * Revision:     V4.5.1
 * Revisor:      XuZx
 * Date:         2011-07-22
 * Reason:       Revise for GreatBelt v4.5.1
 *
 * Revision:     V5.1.0
 * Revisor:      XuZx
 * Date:         2011-07-22
 * Reason:       Revise for GreatBelt v5.1.0
 *
 * Revision:     V5.6.0
 * Revisor:      XuZx
 * Date:         2012-01-07
 * Reason:       Revise for GreatBelt v5.6.0
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

static uint32 key_type_2_hash_type[USERID_KEY_TYPE_NUM][USERID_DIRECTION_NUM] =
{
    {},
    {USERID_HASH_TYPE_TWO_VLAN,         USERID_HASH_TYPE_TWO_VLAN},
    {USERID_HASH_TYPE_SVLAN,            USERID_HASH_TYPE_SVLAN},
    {USERID_HASH_TYPE_CVLAN,            USERID_HASH_TYPE_CVLAN},
    {USERID_HASH_TYPE_SVLAN_COS,        USERID_HASH_TYPE_SVLAN_COS},
    {USERID_HASH_TYPE_CVLAN_COS,        USERID_HASH_TYPE_CVLAN_COS},
    {USERID_HASH_TYPE_MAC_SA,           USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_PORT_MAC_SA,      USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_IPV4_SA,          USERID_HASH_TYPE_PORT_VLAN_CROSS},
    {USERID_HASH_TYPE_PORT_IPV4_SA,     USERID_HASH_TYPE_PORT_CROSS},
    {USERID_HASH_TYPE_PORT,             USERID_HASH_TYPE_PORT},
    {USERID_HASH_TYPE_L2,               USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_IPV6_SA,          USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_PBB,              USERID_HASH_TYPE_PBB},
    {USERID_HASH_TYPE_IPV4_TUNNEL,      USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_IPV4_GRE_KEY,     USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_IPV4_UDP,         USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_CAPWAP,           USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_TRILL_UC_RPF,     USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_TRILL_MC_RPF,     USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_TRILL_MC_ADJ,     USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_TRILL_UC,         USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_TRILL_MC,         USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_IPV4_RPF,         USERID_HASH_TYPE_INVALID},
    {USERID_HASH_TYPE_INVALID,          USERID_HASH_TYPE_MPLS_SECTION_OAM},
    {USERID_HASH_TYPE_INVALID,          USERID_HASH_TYPE_PBT_OAM},
    {USERID_HASH_TYPE_INVALID,          USERID_HASH_TYPE_MPLS_LABEL_OAM},
    {USERID_HASH_TYPE_INVALID,          USERID_HASH_TYPE_BFD_OAM},
    {USERID_HASH_TYPE_INVALID,          USERID_HASH_TYPE_ETHER_FID_OAM},
    {USERID_HASH_TYPE_INVALID,          USERID_HASH_TYPE_ETHER_VLAN_OAM},
    {USERID_HASH_TYPE_INVALID,          USERID_HASH_TYPE_ETHER_RMEP},

};

static int32
_cm_com_userid_lookup_tcam(uint8 chip_id,
                           userid_key_t* p_userid_key,
                           userid_key_type_t key_type,
                           userid_direction_t direction,
                           tcam_lookup_result_t* p_tcam_lookup_result)
{
    ds_fib_user_id80_key_t ds_fib_user_id80_key;
    ds_fib_user_id160_key_t ds_fib_user_id160_key;
    fib_userid_ip_sa_t fib_userid_ip_sa;
    fib_userid_rid_t fib_userid_rid;
    fib_userid_radio_mac_47_32_t fib_userid_radio_mac_47_32;
    fib_userid_udp_dest_port_t fib_userid_udp_dest_port;
    fib_userid_global_src_port_t fib_userid_global_src_port;
    user_id_hash_lookup_ctl_t user_id_hash_lookup_ctl;
    tcam_lookup_info_t tcam_lookup_info;
    tbls_id_t tbls_id = MaxTblId_t;
    uint32 cmd = 0;

    sal_memset(&ds_fib_user_id80_key, 0, sizeof(ds_fib_user_id80_key_t));
    sal_memset(&ds_fib_user_id160_key, 0, sizeof(ds_fib_user_id160_key_t));
    sal_memset(&fib_userid_ip_sa, 0, sizeof(fib_userid_ip_sa_t));
    sal_memset(&fib_userid_rid, 0, sizeof(fib_userid_rid_t));
    sal_memset(&fib_userid_radio_mac_47_32, 0, sizeof(fib_userid_radio_mac_47_32_t));
    sal_memset(&fib_userid_udp_dest_port, 0, sizeof(fib_userid_udp_dest_port_t));
    sal_memset(&fib_userid_global_src_port, 0, sizeof(fib_userid_global_src_port_t));
    sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));

    sal_memset(&user_id_hash_lookup_ctl, 0, sizeof(user_id_hash_lookup_ctl_t));
    cmd = DRV_IOR(UserIdHashLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &user_id_hash_lookup_ctl));

    /* //======bug 4609 ECO begine ====== */
    /* //if (UserIdHashLookupCtl.ingressUserIdTcamEn){ */
    /* if (UserIdHashLookupCtl.otherTcamEn) */
    /* //======bug 4609 ECO end ====== */
    if (!((user_id_hash_lookup_ctl.ingress_user_id_tcam_en && (USERID_DIRECTION_IPE_USERID == direction))
        || (user_id_hash_lookup_ctl.other_tcam_en && (USERID_DIRECTION_OTHER == direction))))
    {
        return DRV_E_NONE;
    }

    tbls_id = drv_hash_lookup_get_key_table_id(HASH_MODULE_USERID, key_type_2_hash_type[key_type][direction]);

    if (MaxTblId_t == tbls_id)
    {
        return DRV_E_INVALID_TBL;
    }

    switch (key_type)
    {
        case USERID_KEY_TYPE_TWO_VLAN:
            ds_fib_user_id80_key.is_label = p_userid_key->key.two_vlan.is_label;
            ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.src;
            fib_userid_ip_sa.u8.svlan_id = p_userid_key->key.two_vlan.svlan_id;
            fib_userid_ip_sa.u8.cvlan_id = p_userid_key->key.two_vlan.cvlan_id;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            ds_fib_user_id80_key.direction = direction;
            break;
        case USERID_KEY_TYPE_SVLAN:
            ds_fib_user_id80_key.is_label = p_userid_key->key.svlan.is_label;
            ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.src;
            fib_userid_ip_sa.u8.svlan_id = p_userid_key->key.svlan.svlan_id;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            ds_fib_user_id80_key.direction = direction;
            break;
        case USERID_KEY_TYPE_CVLAN:
            ds_fib_user_id80_key.is_label = p_userid_key->key.cvlan.is_label;
            ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.src;
            fib_userid_ip_sa.u8.cvlan_id = p_userid_key->key.cvlan.cvlan_id;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            ds_fib_user_id80_key.direction = direction;
            break;
        case USERID_KEY_TYPE_SVLAN_COS:
            ds_fib_user_id80_key.is_label = p_userid_key->key.svlan_cos.is_label;
            ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.src;
            fib_userid_ip_sa.u8.svlan_id = p_userid_key->key.svlan_cos.svlan_id;
            fib_userid_ip_sa.u8.stag_cos = p_userid_key->key.svlan_cos.stag_cos;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            ds_fib_user_id80_key.direction = direction;
            break;
        case USERID_KEY_TYPE_CVLAN_COS:
            ds_fib_user_id80_key.is_label = p_userid_key->key.cvlan_cos.is_label;
            ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.src;
            fib_userid_ip_sa.u8.cvlan_id = p_userid_key->key.cvlan_cos.cvlan_id;
            fib_userid_ip_sa.u8.ctag_cos = p_userid_key->key.cvlan_cos.ctag_cos;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            ds_fib_user_id80_key.direction = direction;
            break;
        case USERID_KEY_TYPE_MAC_SA:
            fib_userid_rid.u2.is_mac_da = p_userid_key->key.mac_sa.is_mac_da;
            ds_fib_user_id80_key.rid = fib_userid_rid.rid;
            ds_fib_user_id80_key.radio_mac47_32 = p_userid_key->key.mac_sa.mac_sa_47_32;
            fib_userid_ip_sa.mac_sa = p_userid_key->key.mac_sa.mac_sa_31_0;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            break;
        case USERID_KEY_TYPE_PORT_MAC_SA:
            ds_fib_user_id160_key.is_label = p_userid_key->key.port_mac_sa.is_label;
            ds_fib_user_id160_key.global_src_port = p_userid_key->xport.global.src;
            ds_fib_user_id160_key.mac_sa47_32 = p_userid_key->key.port_mac_sa.mac_sa_47_32;
            ds_fib_user_id160_key.ip_sa = p_userid_key->key.port_mac_sa.mac_sa_31_0;
            break;
        case USERID_KEY_TYPE_IPV4_SA:
            if (USERID_DIRECTION_IPE_USERID == direction)
            {
                ds_fib_user_id80_key.ip_sa = p_userid_key->key.ipv4_sa.ip_sa;
            }
            else if (USERID_DIRECTION_OTHER == direction)
            {
                ds_fib_user_id80_key.is_label = p_userid_key->key.ipv4_sa.is_label;
                fib_userid_ip_sa.u9.vlan_id = p_userid_key->key.ipv4_sa.vlan_id;
                ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.dest;
                fib_userid_radio_mac_47_32.u1.global_src_port = p_userid_key->xport.global.src;
                ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
                ds_fib_user_id80_key.radio_mac47_32 = fib_userid_radio_mac_47_32.radio_mac47_32;
            }
            ds_fib_user_id80_key.direction = direction;
            break;
        case USERID_KEY_TYPE_PORT_IPV4_SA:
            if (USERID_DIRECTION_IPE_USERID == direction)
            {
                ds_fib_user_id80_key.is_label = p_userid_key->key.port_ipv4_sa.is_label;
                ds_fib_user_id80_key.ip_sa = p_userid_key->key.port_ipv4_sa.ip_sa;
                ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.src;
            }
            else if (USERID_DIRECTION_OTHER == direction)
            {
                ds_fib_user_id80_key.is_label = p_userid_key->key.port_ipv4_sa.is_label;
                ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.dest;
                fib_userid_radio_mac_47_32.u1.global_src_port = p_userid_key->xport.global.src;
                ds_fib_user_id80_key.radio_mac47_32 = fib_userid_radio_mac_47_32.radio_mac47_32;
                ds_fib_user_id80_key.ip_sa = p_userid_key->key.port_ipv4_sa.ip_sa;
            }
            ds_fib_user_id80_key.direction = direction;
            break;
        case USERID_KEY_TYPE_PORT:
            ds_fib_user_id80_key.is_label = p_userid_key->key.port.is_label;
            ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.src;
            ds_fib_user_id80_key.direction = direction;
            break;
        case USERID_KEY_TYPE_L2:
            ds_fib_user_id160_key.global_src_port = p_userid_key->xport.global.src;
            fib_userid_udp_dest_port.u1.vlan_id = p_userid_key->key.L2.vlan_id;
            fib_userid_udp_dest_port.u1.cos = p_userid_key->key.L2.cos;
            ds_fib_user_id160_key.udp_dest_port15_10 = (fib_userid_udp_dest_port.udp_dest_port >> 10) & 0x3F;
            ds_fib_user_id160_key.udp_dest_port9_0 = fib_userid_udp_dest_port.udp_dest_port & 0x3FF;
            ds_fib_user_id160_key.ip_da = p_userid_key->key.L2.mac_da_31_0;
            ds_fib_user_id160_key.udp_src_port = p_userid_key->key.L2.mac_da_47_32;
            ds_fib_user_id160_key.ip_sa = p_userid_key->key.L2.mac_sa_31_0;
            ds_fib_user_id160_key.mac_sa47_32 = p_userid_key->key.L2.mac_sa_47_32;
            break;
        case USERID_KEY_TYPE_IPV6_SA:
            ds_fib_user_id160_key.ip_sa = p_userid_key->key.ipv6_sa.ip_sa_31_0;
            ds_fib_user_id160_key.mac_sa47_32 = p_userid_key->key.ipv6_sa.ip_sa_63_32 & 0xFFFF;
            ds_fib_user_id160_key.rid = (p_userid_key->key.ipv6_sa.ip_sa_63_32 >> 16) & 0x1F;
            fib_userid_global_src_port.u2.ip_sa_63_53 = p_userid_key->key.ipv6_sa.ip_sa_63_32 >> 21;
            ds_fib_user_id160_key.global_src_port = fib_userid_global_src_port.u1.global_src_port;
            ds_fib_user_id160_key.ip_da = p_userid_key->key.ipv6_sa.ip_sa_95_64;
            ds_fib_user_id160_key.udp_src_port = p_userid_key->key.ipv6_sa.ip_sa_127_96 & 0xFFFF;
            ds_fib_user_id160_key.udp_dest_port15_10 = ((p_userid_key->key.ipv6_sa.ip_sa_127_96 >> 16) >> 10) & 0x3F;
            ds_fib_user_id160_key.udp_dest_port9_0 = (p_userid_key->key.ipv6_sa.ip_sa_127_96 >> 16) & 0x3FF;
            break;
        case USERID_KEY_TYPE_PBB:
            ds_fib_user_id80_key.is_label = p_userid_key->key.pbb.is_label;
            ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.src;
            fib_userid_ip_sa.u1.isid = p_userid_key->key.pbb.is_id;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            ds_fib_user_id80_key.direction = direction;
            break;
        case USERID_KEY_TYPE_IPV4_TUNNEL:
            ds_fib_user_id160_key.ip_sa = p_userid_key->key.ipv4_tunnel.ip_sa;
            ds_fib_user_id160_key.ip_da = p_userid_key->key.ipv4_tunnel.ip_da;
            ds_fib_user_id160_key.layer4_type = p_userid_key->key.ipv4_tunnel.layer4_type;
            break;
        case USERID_KEY_TYPE_IPV4_GRE_KEY:
            ds_fib_user_id160_key.ip_sa = p_userid_key->key.ipv4_gre.ip_sa;
            ds_fib_user_id160_key.ip_da = p_userid_key->key.ipv4_gre.ip_da;
            ds_fib_user_id160_key.layer4_type = p_userid_key->key.ipv4_gre.layer4_type;
            ds_fib_user_id160_key.udp_dest_port15_10 = (p_userid_key->xport.udp.dest >> 10) & 0x3F;
            ds_fib_user_id160_key.udp_dest_port9_0 = p_userid_key->xport.udp.dest & 0x3FF;
            ds_fib_user_id160_key.udp_src_port = p_userid_key->xport.udp.src;
            break;
        case USERID_KEY_TYPE_IPV4_UDP:
            ds_fib_user_id160_key.ip_sa = p_userid_key->key.ipv4_udp.ip_sa;
            ds_fib_user_id160_key.ip_da = p_userid_key->key.ipv4_udp.ip_da;
            ds_fib_user_id160_key.layer4_type = p_userid_key->key.ipv4_udp.layer4_type;
            ds_fib_user_id160_key.udp_dest_port15_10 = (p_userid_key->xport.udp.dest >> 10) & 0x3F;
            ds_fib_user_id160_key.udp_dest_port9_0 = p_userid_key->xport.udp.dest & 0x3FF;
            ds_fib_user_id160_key.udp_src_port = p_userid_key->xport.udp.src;
            break;
        case USERID_KEY_TYPE_CAPWAP:
            ds_fib_user_id80_key.rid = p_userid_key->key.capwap.rid;
            ds_fib_user_id80_key.radio_mac47_32 = p_userid_key->key.capwap.radio_mac_47_32;
            fib_userid_ip_sa.mac_sa = p_userid_key->key.capwap.radio_mac_31_0;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            break;
        case USERID_KEY_TYPE_TRILL_UC_RPF:
            fib_userid_ip_sa.u2.ingress_nick_name = p_userid_key->key.trill_uc_rpf.ingress_nick_name;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            break;
        case USERID_KEY_TYPE_TRILL_MC_RPF:
            fib_userid_ip_sa.u2.ingress_nick_name = p_userid_key->key.trill_mc_rpf.ingress_nick_name;
            fib_userid_ip_sa.u2.egress_nick_name = p_userid_key->key.trill_mc_rpf.egress_nick_name;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            break;
        case USERID_KEY_TYPE_TRILL_MC_ADJ:
            ds_fib_user_id80_key.is_label = p_userid_key->key.trill_mc_adj.is_label;
            fib_userid_ip_sa.u2.egress_nick_name = p_userid_key->key.trill_mc_adj.egress_nick_name;
            ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.src;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            break;
        case USERID_KEY_TYPE_TRILL_UC:
            fib_userid_ip_sa.u2.ingress_nick_name = p_userid_key->key.trill_uc.ingress_nick_name;
            fib_userid_ip_sa.u2.egress_nick_name = p_userid_key->key.trill_uc.egress_nick_name;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            break;
        case USERID_KEY_TYPE_TRILL_MC:
            fib_userid_ip_sa.u2.ingress_nick_name = p_userid_key->key.trill_mc.ingress_nick_name;
            fib_userid_ip_sa.u2.egress_nick_name = p_userid_key->key.trill_mc.egress_nick_name;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            break;
        case USERID_KEY_TYPE_IPV4_RPF:
            ds_fib_user_id80_key.ip_sa = p_userid_key->key.ipv4_rpf.ip_sa;
            break;
        case USERID_KEY_TYPE_MPLS_SECTION_OAM:
            fib_userid_ip_sa.u3.interface_id = p_userid_key->key.mpls_section_oam.interface_id;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            break;
        case USERID_KEY_TYPE_PBT_OAM:
            ds_fib_user_id80_key.ip_sa = p_userid_key->key.pbt_oam.mac_sa_31_0;
            ds_fib_user_id80_key.radio_mac47_32 = p_userid_key->key.pbt_oam.mac_sa_47_32;
            ds_fib_user_id80_key.global_src_port = p_userid_key->key.pbt_oam.vrf_id;
            break;
        case USERID_KEY_TYPE_MPLS_LABEL_OAM:
            fib_userid_ip_sa.u5.mpls_label = p_userid_key->key.mpls_label_oam.mpls_label;
            fib_userid_ip_sa.u5.mpls_label_space = p_userid_key->key.mpls_label_oam.mpls_label_space;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            break;
        case USERID_KEY_TYPE_BFD_OAM:
            ds_fib_user_id80_key.ip_sa = p_userid_key->key.bfd_oam.my_discriminator;
            break;
        case USERID_KEY_TYPE_ETHER_FID_OAM:
        case USERID_KEY_TYPE_ETHER_VLAN_OAM:
            fib_userid_ip_sa.u6.vlan_id = p_userid_key->key.ether_fid_oam.vlan_id;
            fib_userid_ip_sa.u6.is_fid = p_userid_key->key.ether_fid_oam.is_fid;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            ds_fib_user_id80_key.global_src_port = p_userid_key->xport.global.src;
            break;
        case USERID_KEY_TYPE_ETHER_RMEP:
            fib_userid_ip_sa.u7.mep_index = p_userid_key->key.ether_rmep_oam.mep_index;
            fib_userid_ip_sa.u7.rmep_id = p_userid_key->key.ether_rmep_oam.rmep_id;
            ds_fib_user_id80_key.ip_sa = fib_userid_ip_sa.ip_sa;
            break;
        default:
            break;
    }

    if (((TABLE_ENTRY_SIZE(tbls_id) / DRV_BYTES_PER_ENTRY))
        == ((TABLE_ENTRY_SIZE(DsFibUserId80Key_t) / DRV_BYTES_PER_ENTRY)))
    {
        ds_fib_user_id80_key.table_id = 0;
        ds_fib_user_id80_key.user_id_hash_type = key_type;
        ds_fib_user_id80_key.is_user_id = TRUE;
        tcam_lookup_info.tcam_key = &ds_fib_user_id80_key;
        tcam_lookup_info.chip_id = chip_id;
        tcam_lookup_info.tcam_key_type = 0;
        /*Stroe hash key for cosim*/
#if (SDK_WORK_PLATFORM == 1)
        if (cosim_db.store_key)
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_key(&ds_fib_user_id80_key, DsFibUserId80Key_t));
        }
#endif
    }
    else
    {
        ds_fib_user_id160_key.table_id0 = 0;
        ds_fib_user_id160_key.table_id1 = 0;
        ds_fib_user_id160_key.user_id_hash_type0 = key_type;
        ds_fib_user_id160_key.user_id_hash_type1 = key_type;
        ds_fib_user_id160_key.is_user_id0 = TRUE;
        ds_fib_user_id160_key.is_user_id1 = TRUE;
        tcam_lookup_info.tcam_key = &ds_fib_user_id160_key;
        tcam_lookup_info.chip_id = chip_id;
        tcam_lookup_info.tcam_key_type = 1;
#if (SDK_WORK_PLATFORM == 1)
        if (cosim_db.store_key)
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_key(&ds_fib_user_id160_key, DsFibUserId160Key_t));
        }
#endif
    }

    DRV_IF_ERROR_RETURN(cm_com_tcam_conflict_resolve(&tcam_lookup_info, p_tcam_lookup_result));
    return DRV_E_NONE;
}

static int32
_cm_com_userid_lookup_hash(uint8 chip_id,
                           userid_key_t* p_userid_key,
                           userid_key_type_t userid_key_type,
                           userid_direction_t direction,
                           lookup_result_t* p_userid_result)
{
    lookup_info_t lookup_info;

    ds_user_id_double_vlan_hash_key_t ds_user_id_double_vlan_hash_key;
    ds_user_id_svlan_hash_key_t ds_user_id_svlan_hash_key;
    ds_user_id_cvlan_hash_key_t ds_user_id_cvlan_hash_key;
    ds_user_id_svlan_cos_hash_key_t ds_user_id_svlan_cos_hash_key;
    ds_user_id_cvlan_cos_hash_key_t ds_user_id_cvlan_cos_hash_key;
    ds_user_id_mac_hash_key_t ds_user_id_mac_hash_key;
    ds_user_id_mac_port_hash_key_t ds_user_id_mac_port_hash_key;
    ds_user_id_ipv4_hash_key_t ds_user_id_ipv4_hash_key;
    ds_user_id_port_vlan_cross_hash_key_t ds_user_id_port_vlan_cross_hash_key;
    ds_user_id_ipv4_port_hash_key_t ds_user_id_ipv4_port_hash_key;
    ds_user_id_port_cross_hash_key_t ds_user_id_port_cross_hash_key;
    ds_user_id_port_hash_key_t ds_user_id_port_hash_key;
    ds_user_id_l2_hash_key_t ds_user_id_l2_hash_key;
    ds_user_id_ipv6_hash_key_t ds_user_id_ipv6_hash_key;
    ds_tunnel_id_ipv4_hash_key_t ds_tunnel_id_ipv4_hash_key;
    ds_tunnel_id_pbb_hash_key_t ds_tunnel_id_pbb_hash_key;
    ds_tunnel_id_capwap_hash_key_t ds_tunnel_id_capwap_hash_key;
    ds_tunnel_id_trill_uc_rpf_hash_key_t ds_tunnel_id_trill_uc_rpf_hash_key;
    ds_tunnel_id_trill_mc_rpf_hash_key_t ds_tunnel_id_trill_mc_rpf_hash_key;
    ds_tunnel_id_trill_mc_adj_check_hash_key_t ds_tunnel_id_trill_mc_adj_check_hash_key;
    ds_tunnel_id_trill_uc_decap_hash_key_t ds_tunnel_id_trill_uc_decap_hash_key;
    ds_tunnel_id_trill_mc_decap_hash_key_t ds_tunnel_id_trill_mc_decap_hash_key;
    ds_tunnel_id_ipv4_rpf_hash_key_t ds_tunnel_id_ipv4_rpf_hash_key;
    ds_mpls_oam_label_hash_key_t ds_mpls_oam_label_hash_key;
    ds_pbt_oam_hash_key_t ds_pbt_oam_hash_key;
    ds_bfd_oam_hash_key_t ds_bfd_oam_hash_key;
    ds_eth_oam_hash_key_t ds_eth_oam_hash_key;
    ds_eth_oam_rmep_hash_key_t ds_eth_oam_rmep_hash_key;
    user_id_hash_lookup_ctl_t user_id_hash_lookup_ctl;
    uint32 cmd = 0;

    sal_memset(&lookup_info, 0, sizeof(lookup_info_t));
    lookup_info.chip_id = chip_id;
    lookup_info.hash_module = HASH_MODULE_USERID;
    lookup_info.hash_type = key_type_2_hash_type[userid_key_type][direction];

    sal_memset(&user_id_hash_lookup_ctl, 0, sizeof(user_id_hash_lookup_ctl));
    cmd = DRV_IOR(UserIdHashLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &user_id_hash_lookup_ctl));

    if (USERID_KEY_TYPE_TWO_VLAN == userid_key_type)
    {
        sal_memset(&ds_user_id_double_vlan_hash_key, 0, sizeof(ds_user_id_double_vlan_hash_key_t));
        ds_user_id_double_vlan_hash_key.direction = direction;
        ds_user_id_double_vlan_hash_key.cvlan_id0_0 = p_userid_key->key.two_vlan.cvlan_id & 0x1;
        ds_user_id_double_vlan_hash_key.cvlan_id11_1 = p_userid_key->key.two_vlan.cvlan_id >> 1;
        ds_user_id_double_vlan_hash_key.svlan_id = p_userid_key->key.two_vlan.svlan_id;
        ds_user_id_double_vlan_hash_key.global_src_port12_0 = p_userid_key->xport.global.src & 0x1FFF;
        ds_user_id_double_vlan_hash_key.global_src_port13_13 = (p_userid_key->xport.global.src >> 13) & 0x1;
        ds_user_id_double_vlan_hash_key.is_label = p_userid_key->key.two_vlan.is_label;
        ds_user_id_double_vlan_hash_key.valid = TRUE;
        ds_user_id_double_vlan_hash_key.hash_type = USERID_KEY_TYPE_TWO_VLAN;
        lookup_info.p_ds_key = &ds_user_id_double_vlan_hash_key;
    }
    else if (USERID_KEY_TYPE_SVLAN == userid_key_type)
    {
        sal_memset(&ds_user_id_svlan_hash_key, 0, sizeof(ds_user_id_svlan_hash_key_t));
        ds_user_id_svlan_hash_key.direction = direction;
        ds_user_id_svlan_hash_key.svlan_id = p_userid_key->key.svlan.svlan_id;
        ds_user_id_svlan_hash_key.global_src_port = p_userid_key->xport.global.src & 0x1FFF;
        ds_user_id_svlan_hash_key.global_src_port13 = (p_userid_key->xport.global.src >> 13) & 0x1;
        ds_user_id_svlan_hash_key.is_label = p_userid_key->key.svlan.is_label;
        ds_user_id_svlan_hash_key.valid = TRUE;
        ds_user_id_svlan_hash_key.hash_type = USERID_KEY_TYPE_SVLAN;
        lookup_info.p_ds_key = &ds_user_id_svlan_hash_key;
    }
    else if (USERID_KEY_TYPE_CVLAN == userid_key_type)
    {
        sal_memset(&ds_user_id_cvlan_hash_key, 0, sizeof(ds_user_id_cvlan_hash_key_t));
        ds_user_id_cvlan_hash_key.direction = direction;
        ds_user_id_cvlan_hash_key.cvlan_id0 = p_userid_key->key.cvlan.cvlan_id & 0x1;
        ds_user_id_cvlan_hash_key.cvlan_id11_1 = (p_userid_key->key.cvlan.cvlan_id >> 1) & 0x7FF;
        ds_user_id_cvlan_hash_key.valid = TRUE;
        ds_user_id_cvlan_hash_key.global_src_port = p_userid_key->xport.global.src & 0x1FFF;
        ds_user_id_cvlan_hash_key.global_src_port13 = (p_userid_key->xport.global.src >> 13) & 0x1;
        ds_user_id_cvlan_hash_key.is_label = p_userid_key->key.cvlan.is_label;
        ds_user_id_cvlan_hash_key.hash_type = USERID_KEY_TYPE_CVLAN;
        lookup_info.p_ds_key = &ds_user_id_cvlan_hash_key;
    }
    else if (USERID_KEY_TYPE_SVLAN_COS == userid_key_type)
    {
        sal_memset(&ds_user_id_svlan_cos_hash_key, 0, sizeof(ds_user_id_svlan_cos_hash_key_t));
        ds_user_id_svlan_cos_hash_key.direction = direction;
        ds_user_id_svlan_cos_hash_key.svlan_id = p_userid_key->key.svlan_cos.svlan_id;
        ds_user_id_svlan_cos_hash_key.stag_cos = p_userid_key->key.svlan_cos.stag_cos;
        ds_user_id_svlan_cos_hash_key.global_src_port = p_userid_key->xport.global.src & 0x1FFF;
        ds_user_id_svlan_cos_hash_key.global_src_port13 = (p_userid_key->xport.global.src >> 13) & 0x1;
        ds_user_id_svlan_cos_hash_key.is_label = p_userid_key->key.svlan_cos.is_label;
        ds_user_id_svlan_cos_hash_key.valid = TRUE;
        ds_user_id_svlan_cos_hash_key.hash_type = USERID_KEY_TYPE_SVLAN_COS;
        lookup_info.p_ds_key = &ds_user_id_svlan_cos_hash_key;
    }
    else if (USERID_KEY_TYPE_CVLAN_COS == userid_key_type)
    {
        sal_memset(&ds_user_id_cvlan_cos_hash_key, 0, sizeof(ds_user_id_cvlan_cos_hash_key_t));
        ds_user_id_cvlan_cos_hash_key.direction = direction;
        ds_user_id_cvlan_cos_hash_key.cvlan_id0 = p_userid_key->key.cvlan_cos.cvlan_id & 0x1;
        ds_user_id_cvlan_cos_hash_key.cvlan_id11_1 = (p_userid_key->key.cvlan_cos.cvlan_id >> 1) & 0x7FF;
        ds_user_id_cvlan_cos_hash_key.ctag_cos = p_userid_key->key.cvlan_cos.ctag_cos;
        ds_user_id_cvlan_cos_hash_key.global_src_port = p_userid_key->xport.global.src & 0x1FFF;
        ds_user_id_cvlan_cos_hash_key.global_src_port13 = (p_userid_key->xport.global.src >> 13) & 0x1;
        ds_user_id_cvlan_cos_hash_key.is_label = p_userid_key->key.cvlan_cos.is_label;
        ds_user_id_cvlan_cos_hash_key.valid = TRUE;
        ds_user_id_cvlan_cos_hash_key.hash_type = USERID_KEY_TYPE_CVLAN_COS;
        lookup_info.p_ds_key = &ds_user_id_cvlan_cos_hash_key;
    }
    else if (USERID_KEY_TYPE_MAC_SA == userid_key_type)
    {
        sal_memset(&ds_user_id_mac_hash_key, 0, sizeof(ds_user_id_mac_hash_key_t));
        ds_user_id_mac_hash_key.is_mac_da = p_userid_key->key.mac_sa.is_mac_da;
        ds_user_id_mac_hash_key.mac_sa31_0 = p_userid_key->key.mac_sa.mac_sa_31_0;
        ds_user_id_mac_hash_key.mac_sa42_32 = p_userid_key->key.mac_sa.mac_sa_47_32 & 0x7FF;
        ds_user_id_mac_hash_key.mac_sa43 = (p_userid_key->key.mac_sa.mac_sa_47_32 >> 11) & 0x1;
        ds_user_id_mac_hash_key.mac_sa47_44 = (p_userid_key->key.mac_sa.mac_sa_47_32 >> 12) & 0xF;
        ds_user_id_mac_hash_key.valid = TRUE;
        ds_user_id_mac_hash_key.hash_type = USERID_KEY_TYPE_MAC_SA;
        lookup_info.p_ds_key = &ds_user_id_mac_hash_key;
    }
    else if (USERID_KEY_TYPE_PORT_MAC_SA == userid_key_type)
    {
        sal_memset(&ds_user_id_mac_port_hash_key, 0, sizeof(ds_user_id_mac_port_hash_key_t));
        ds_user_id_mac_port_hash_key.is_label = p_userid_key->key.port_mac_sa.is_label;
        ds_user_id_mac_port_hash_key.is_mac_da = p_userid_key->key.port_mac_sa.is_mac_da;
        ds_user_id_mac_port_hash_key.mac_sa_low = p_userid_key->key.port_mac_sa.mac_sa_31_0;
        ds_user_id_mac_port_hash_key.mac_sa_high = p_userid_key->key.port_mac_sa.mac_sa_47_32;
        ds_user_id_mac_port_hash_key.global_src_port = p_userid_key->xport.global.src & 0x1FFF;
        ds_user_id_mac_port_hash_key.global_src_port13 = p_userid_key->xport.global.src >> 13;
        ds_user_id_mac_port_hash_key.valid = TRUE;
        ds_user_id_mac_port_hash_key.valid1 = TRUE;
        ds_user_id_mac_port_hash_key.hash_type = USERID_KEY_TYPE_PORT_MAC_SA;
        ds_user_id_mac_port_hash_key.hash_type1 = USERID_KEY_TYPE_PORT_MAC_SA;
        lookup_info.p_ds_key = &ds_user_id_mac_port_hash_key;
    }
    else if (USERID_KEY_TYPE_IPV4_SA == userid_key_type)
    {
        if (USERID_DIRECTION_IPE_USERID == direction)
        {
            sal_memset(&ds_user_id_ipv4_hash_key, 0, sizeof(ds_user_id_ipv4_hash_key_t));
            ds_user_id_ipv4_hash_key.direction = direction;
            ds_user_id_ipv4_hash_key.ip_sa = p_userid_key->key.ipv4_sa.ip_sa;
            ds_user_id_ipv4_hash_key.valid = TRUE;
            ds_user_id_ipv4_hash_key.hash_type = USERID_KEY_TYPE_IPV4_SA;
            lookup_info.p_ds_key = &ds_user_id_ipv4_hash_key;
        }
        else if (USERID_DIRECTION_OTHER == direction)
        {
            sal_memset(&ds_user_id_port_vlan_cross_hash_key, 0, sizeof(ds_user_id_port_vlan_cross_hash_key_t));
            ds_user_id_port_vlan_cross_hash_key.direction = direction;
            ds_user_id_port_vlan_cross_hash_key.is_label = p_userid_key->key.ipv4_sa.is_label;
            ds_user_id_port_vlan_cross_hash_key.vlan_id0_0 = p_userid_key->key.ipv4_sa.vlan_id & 0x1;
            ds_user_id_port_vlan_cross_hash_key.vlan_id11_1 = (p_userid_key->key.ipv4_sa.vlan_id >> 1) & 0x7FF;
            ds_user_id_port_vlan_cross_hash_key.global_src_port12_0 = p_userid_key->xport.global.src & 0x1FFF;
            ds_user_id_port_vlan_cross_hash_key.global_src_port13_13 = (p_userid_key->xport.global.src >> 13) & 0x1;
            ds_user_id_port_vlan_cross_hash_key.global_dest_port = p_userid_key->xport.global.dest;
            ds_user_id_port_vlan_cross_hash_key.valid = TRUE;
            ds_user_id_port_vlan_cross_hash_key.hash_type = USERID_KEY_TYPE_IPV4_SA;
            lookup_info.p_ds_key = &ds_user_id_port_vlan_cross_hash_key;
        }
    }
    else if (USERID_KEY_TYPE_PORT_IPV4_SA == userid_key_type)
    {
        if (USERID_DIRECTION_IPE_USERID == direction)
        {
            sal_memset(&ds_user_id_ipv4_port_hash_key, 0, sizeof(ds_user_id_ipv4_port_hash_key_t));
            ds_user_id_ipv4_port_hash_key.direction = direction;
            ds_user_id_ipv4_port_hash_key.ip_sa = p_userid_key->key.port_ipv4_sa.ip_sa;
            ds_user_id_ipv4_port_hash_key.global_src_port0 = p_userid_key->xport.global.src & 0x1;
            ds_user_id_ipv4_port_hash_key.global_src_port1 = (p_userid_key->xport.global.src >> 1) & 0xFFF;
            ds_user_id_ipv4_port_hash_key.global_src_port13 = (p_userid_key->xport.global.src >> 13) & 0x1;
            ds_user_id_ipv4_port_hash_key.is_label = p_userid_key->key.port_ipv4_sa.is_label;
            ds_user_id_ipv4_port_hash_key.valid = TRUE;
            ds_user_id_ipv4_port_hash_key.hash_type = USERID_KEY_TYPE_PORT_IPV4_SA;
            lookup_info.p_ds_key = &ds_user_id_ipv4_port_hash_key;
        }
        else if (USERID_DIRECTION_OTHER == direction)
        {
            sal_memset(&ds_user_id_port_cross_hash_key, 0, sizeof(ds_user_id_port_cross_hash_key_t));
            ds_user_id_port_cross_hash_key.direction = direction;
            ds_user_id_port_cross_hash_key.global_dest_port = p_userid_key->xport.global.dest;
            ds_user_id_port_cross_hash_key.global_src_port = p_userid_key->xport.global.src;
            ds_user_id_port_cross_hash_key.global_src_port13 = (p_userid_key->xport.global.src >> 13) & 0x1;
            ds_user_id_port_cross_hash_key.is_label = p_userid_key->key.port_ipv4_sa.is_label;
            ds_user_id_port_cross_hash_key.valid = TRUE;
            ds_user_id_port_cross_hash_key.hash_type = USERID_KEY_TYPE_PORT_IPV4_SA;
            lookup_info.p_ds_key = &ds_user_id_port_cross_hash_key;
        }
    }
    else if (USERID_KEY_TYPE_PORT == userid_key_type)
    {
        sal_memset(&ds_user_id_port_hash_key, 0, sizeof(ds_user_id_port_hash_key_t));
        ds_user_id_port_hash_key.direction = direction;
        ds_user_id_port_hash_key.is_label = p_userid_key->key.port.is_label;
        ds_user_id_port_hash_key.global_src_port = p_userid_key->xport.global.src & 0x1FFFF;
        ds_user_id_port_hash_key.global_src_port13 = (p_userid_key->xport.global.src >> 13) & 0x1;
        ds_user_id_port_hash_key.valid = TRUE;
        ds_user_id_port_hash_key.hash_type = USERID_KEY_TYPE_PORT;
        lookup_info.p_ds_key = &ds_user_id_port_hash_key;
    }
    else if (USERID_KEY_TYPE_L2 == userid_key_type)
    {
        sal_memset(&ds_user_id_l2_hash_key, 0, sizeof(ds_user_id_l2_hash_key_t));
        ds_user_id_l2_hash_key.valid0 = TRUE;
        ds_user_id_l2_hash_key.valid1 = TRUE;
        ds_user_id_l2_hash_key.hash_type0 = USERID_KEY_TYPE_L2;
        ds_user_id_l2_hash_key.hash_type1 = USERID_KEY_TYPE_L2;

        ds_user_id_l2_hash_key.cos = user_id_hash_lookup_ctl.l2_cos_en ? p_userid_key->key.L2.cos : 0;

        ds_user_id_l2_hash_key.vlan_id = user_id_hash_lookup_ctl.l2_vlan_id_en ? p_userid_key->key.L2.vlan_id : 0;

        ds_user_id_l2_hash_key.mac_da47_32
            = user_id_hash_lookup_ctl.l2_mac_da_en ? p_userid_key->key.L2.mac_da_47_32 : 0;
        ds_user_id_l2_hash_key.mac_da31_0
            = user_id_hash_lookup_ctl.l2_mac_da_en ? p_userid_key->key.L2.mac_da_31_0 : 0;

        ds_user_id_l2_hash_key.mac_sa47_41
            = user_id_hash_lookup_ctl.l2_mac_sa_en ? ((p_userid_key->key.L2.mac_sa_47_32 >> 9) & 0x7F) : 0;
        ds_user_id_l2_hash_key.mac_sa40_32
            = user_id_hash_lookup_ctl.l2_mac_sa_en ? (p_userid_key->key.L2.mac_sa_47_32 & 0x1FF) : 0;
        ds_user_id_l2_hash_key.mac_sa31_0
            = user_id_hash_lookup_ctl.l2_mac_sa_en ? p_userid_key->key.L2.mac_sa_31_0 : 0;

        ds_user_id_l2_hash_key.global_src_port10_0
                = user_id_hash_lookup_ctl.l2_src_port_en ? (p_userid_key->xport.global.src & 0x7FF) : 0;
        ds_user_id_l2_hash_key.global_src_port13_11
                = user_id_hash_lookup_ctl.l2_src_port_en ? ((p_userid_key->xport.global.src >> 11) & 0x7) : 0;

        lookup_info.p_ds_key = &ds_user_id_l2_hash_key;
    }
    else if (USERID_KEY_TYPE_IPV6_SA == userid_key_type)
    {
        sal_memset(&ds_user_id_ipv6_hash_key, 0, sizeof(ds_user_id_ipv6_hash_key_t));
        ds_user_id_ipv6_hash_key.ip_sa31_0 = p_userid_key->key.ipv6_sa.ip_sa_31_0;
        ds_user_id_ipv6_hash_key.ip_sa32 = p_userid_key->key.ipv6_sa.ip_sa_63_32 & 0x1;
        ds_user_id_ipv6_hash_key.ip_sa43_33 = (p_userid_key->key.ipv6_sa.ip_sa_63_32 >> 1) & 0x7FF;
        ds_user_id_ipv6_hash_key.ip_sa45_44 = (p_userid_key->key.ipv6_sa.ip_sa_63_32 >> 12) & 0x3;
        ds_user_id_ipv6_hash_key.ip_sa57_46 = (p_userid_key->key.ipv6_sa.ip_sa_63_32 >> 14) & 0xFFF;
        ds_user_id_ipv6_hash_key.ip_sa89_58 = ((p_userid_key->key.ipv6_sa.ip_sa_95_64 & 0x3FFFFFF) << 6)
                                              | ((p_userid_key->key.ipv6_sa.ip_sa_63_32 >> 26) & 0x3F);
        ds_user_id_ipv6_hash_key.ip_sa116_90 = ((p_userid_key->key.ipv6_sa.ip_sa_127_96 & 0x1FFFFF) << 6)
                                               | ((p_userid_key->key.ipv6_sa.ip_sa_95_64 >> 26) & 0x3F);
        ds_user_id_ipv6_hash_key.ip_sa127_117 = (p_userid_key->key.ipv6_sa.ip_sa_127_96 >> 21) & 0x7FF;
        ds_user_id_ipv6_hash_key.valid0 = TRUE;
        ds_user_id_ipv6_hash_key.valid1 = TRUE;
        ds_user_id_ipv6_hash_key.hash_type0 = USERID_KEY_TYPE_IPV6_SA;
        ds_user_id_ipv6_hash_key.hash_type1 = USERID_KEY_TYPE_IPV6_SA;
        lookup_info.p_ds_key = &ds_user_id_ipv6_hash_key;
    }
    else if (USERID_KEY_TYPE_PBB == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_pbb_hash_key, 0, sizeof(ds_tunnel_id_pbb_hash_key_t));
        ds_tunnel_id_pbb_hash_key.direction = direction;
        ds_tunnel_id_pbb_hash_key.global_src_port = p_userid_key->xport.global.src & 0x1FFF;
        ds_tunnel_id_pbb_hash_key.global_src_port13 = (p_userid_key->xport.global.src >> 13) & 0x1;
        ds_tunnel_id_pbb_hash_key.isid_low = p_userid_key->key.pbb.is_id & 0x7FFFF;
        ds_tunnel_id_pbb_hash_key.isid_high = (p_userid_key->key.pbb.is_id >> 19) & 0x1F;
        ds_tunnel_id_pbb_hash_key.is_label = p_userid_key->key.pbb.is_label;
        ds_tunnel_id_pbb_hash_key.valid = TRUE;
        ds_tunnel_id_pbb_hash_key.hash_type = USERID_KEY_TYPE_PBB;
        lookup_info.p_ds_key = &ds_tunnel_id_pbb_hash_key;
    }
    else if (USERID_KEY_TYPE_IPV4_TUNNEL == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_ipv4_hash_key, 0, sizeof(ds_tunnel_id_ipv4_hash_key_t));
        ds_tunnel_id_ipv4_hash_key.ip_da = p_userid_key->key.ipv4_udp.ip_da;
        ds_tunnel_id_ipv4_hash_key.ip_sa = p_userid_key->key.ipv4_udp.ip_sa;
        ds_tunnel_id_ipv4_hash_key.layer4_type = p_userid_key->key.ipv4_udp.layer4_type;
        ds_tunnel_id_ipv4_hash_key.valid0 = TRUE;
        ds_tunnel_id_ipv4_hash_key.valid1 = TRUE;
        ds_tunnel_id_ipv4_hash_key.hash_type0 = USERID_KEY_TYPE_IPV4_TUNNEL;
        ds_tunnel_id_ipv4_hash_key.hash_type1 = USERID_KEY_TYPE_IPV4_TUNNEL;
        lookup_info.p_ds_key = &ds_tunnel_id_ipv4_hash_key;
    }
    else if (USERID_KEY_TYPE_IPV4_GRE_KEY == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_ipv4_hash_key, 0, sizeof(ds_tunnel_id_ipv4_hash_key_t));
        ds_tunnel_id_ipv4_hash_key.ip_da = p_userid_key->key.ipv4_udp.ip_da;
        ds_tunnel_id_ipv4_hash_key.ip_sa = p_userid_key->key.ipv4_udp.ip_sa;
        ds_tunnel_id_ipv4_hash_key.layer4_type = p_userid_key->key.ipv4_udp.layer4_type;
        ds_tunnel_id_ipv4_hash_key.udp_dest_port = p_userid_key->xport.udp.dest;
        ds_tunnel_id_ipv4_hash_key.udp_src_port_l = p_userid_key->xport.udp.src & 0x7FF;
        ds_tunnel_id_ipv4_hash_key.udp_src_port_h = (p_userid_key->xport.udp.src >> 11) & 0x1F;
        ds_tunnel_id_ipv4_hash_key.valid0 = TRUE;
        ds_tunnel_id_ipv4_hash_key.valid1 = TRUE;
        ds_tunnel_id_ipv4_hash_key.hash_type0 = USERID_KEY_TYPE_IPV4_GRE_KEY;
        ds_tunnel_id_ipv4_hash_key.hash_type1 = USERID_KEY_TYPE_IPV4_GRE_KEY;
        lookup_info.p_ds_key = &ds_tunnel_id_ipv4_hash_key;
    }
    else if (USERID_KEY_TYPE_IPV4_UDP == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_ipv4_hash_key, 0, sizeof(ds_tunnel_id_ipv4_hash_key_t));
        ds_tunnel_id_ipv4_hash_key.ip_da = p_userid_key->key.ipv4_udp.ip_da;
        ds_tunnel_id_ipv4_hash_key.ip_sa = p_userid_key->key.ipv4_udp.ip_sa;
        ds_tunnel_id_ipv4_hash_key.layer4_type = p_userid_key->key.ipv4_udp.layer4_type;
        ds_tunnel_id_ipv4_hash_key.udp_dest_port = p_userid_key->xport.udp.dest;
        ds_tunnel_id_ipv4_hash_key.udp_src_port_l = p_userid_key->xport.udp.src & 0x7FF;
        ds_tunnel_id_ipv4_hash_key.udp_src_port_h = (p_userid_key->xport.udp.src >> 11) & 0x1F;
        ds_tunnel_id_ipv4_hash_key.valid0 = TRUE;
        ds_tunnel_id_ipv4_hash_key.valid1 = TRUE;
        ds_tunnel_id_ipv4_hash_key.hash_type0 = USERID_KEY_TYPE_IPV4_UDP;
        ds_tunnel_id_ipv4_hash_key.hash_type1 = USERID_KEY_TYPE_IPV4_UDP;
        lookup_info.p_ds_key = &ds_tunnel_id_ipv4_hash_key;
    }
    else if (USERID_KEY_TYPE_CAPWAP == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_capwap_hash_key, 0, sizeof(ds_tunnel_id_capwap_hash_key_t));
        ds_tunnel_id_capwap_hash_key.radio_mac31_0 = p_userid_key->key.capwap.radio_mac_31_0;
        ds_tunnel_id_capwap_hash_key.radio_mac37_32 = p_userid_key->key.capwap.radio_mac_47_32 & 0x3F;
        ds_tunnel_id_capwap_hash_key.radio_mac38 = (p_userid_key->key.capwap.radio_mac_47_32 >> 6) & 0x1;
        ds_tunnel_id_capwap_hash_key.radio_mac47_39 = (p_userid_key->key.capwap.radio_mac_47_32 >> 7) & 0x1FF;
        ds_tunnel_id_capwap_hash_key.rid = p_userid_key->key.capwap.rid;
        ds_tunnel_id_capwap_hash_key.valid = TRUE;
        ds_tunnel_id_capwap_hash_key.hash_type = USERID_KEY_TYPE_CAPWAP;
        lookup_info.p_ds_key = &ds_tunnel_id_capwap_hash_key;
    }
    else if (USERID_KEY_TYPE_TRILL_UC_RPF == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_trill_uc_rpf_hash_key, 0, sizeof(ds_tunnel_id_trill_uc_rpf_hash_key_t));
        ds_tunnel_id_trill_uc_rpf_hash_key.ingress_nickname_low = p_userid_key->key.trill_uc_rpf.ingress_nick_name & 0x7FF;
        ds_tunnel_id_trill_uc_rpf_hash_key.ingress_nickname_high = p_userid_key->key.trill_uc_rpf.ingress_nick_name >> 11;
        ds_tunnel_id_trill_uc_rpf_hash_key.valid = TRUE;
        ds_tunnel_id_trill_uc_rpf_hash_key.hash_type = USERID_KEY_TYPE_TRILL_UC_RPF;
        lookup_info.p_ds_key = &ds_tunnel_id_trill_uc_rpf_hash_key;
    }
    else if (USERID_KEY_TYPE_TRILL_MC_RPF == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_trill_mc_rpf_hash_key, 0, sizeof(ds_tunnel_id_trill_mc_rpf_hash_key_t));
        ds_tunnel_id_trill_mc_rpf_hash_key.egress_nickname = p_userid_key->key.trill_mc_rpf.egress_nick_name;
        ds_tunnel_id_trill_mc_rpf_hash_key.ingress_nickname_low = p_userid_key->key.trill_mc_rpf.ingress_nick_name & 0x7FF;
        ds_tunnel_id_trill_mc_rpf_hash_key.ingress_nickname_high = p_userid_key->key.trill_mc_rpf.ingress_nick_name >> 11;
        ds_tunnel_id_trill_mc_rpf_hash_key.valid = TRUE;
        ds_tunnel_id_trill_mc_rpf_hash_key.hash_type = USERID_KEY_TYPE_TRILL_MC_RPF;
        lookup_info.p_ds_key = &ds_tunnel_id_trill_mc_rpf_hash_key;
    }
    else if (USERID_KEY_TYPE_TRILL_MC_ADJ == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_trill_mc_adj_check_hash_key, 0, sizeof(ds_tunnel_id_trill_mc_adj_check_hash_key_t));
        ds_tunnel_id_trill_mc_adj_check_hash_key.egress_nickname = p_userid_key->key.trill_mc_adj.egress_nick_name;
        ds_tunnel_id_trill_mc_adj_check_hash_key.is_label = p_userid_key->key.trill_mc_adj.is_label;
        ds_tunnel_id_trill_mc_adj_check_hash_key.valid = TRUE;
        ds_tunnel_id_trill_mc_adj_check_hash_key.global_src_port = p_userid_key->xport.global.src & 0x1FFF;
        ds_tunnel_id_trill_mc_adj_check_hash_key.global_src_port13 = (p_userid_key->xport.global.src >> 13) & 0x1;
        ds_tunnel_id_trill_mc_adj_check_hash_key.hash_type = USERID_KEY_TYPE_TRILL_MC_ADJ;
        lookup_info.p_ds_key = &ds_tunnel_id_trill_mc_adj_check_hash_key;
    }
    else if (USERID_KEY_TYPE_TRILL_UC == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_trill_uc_decap_hash_key, 0, sizeof(ds_tunnel_id_trill_uc_decap_hash_key_t));
        ds_tunnel_id_trill_uc_decap_hash_key.ingress_nickname_low = p_userid_key->key.trill_uc.ingress_nick_name & 0x7FF;
        ds_tunnel_id_trill_uc_decap_hash_key.ingress_nickname_high = p_userid_key->key.trill_uc.ingress_nick_name >> 11;
        ds_tunnel_id_trill_uc_decap_hash_key.egress_nickname = p_userid_key->key.trill_uc.egress_nick_name;
        ds_tunnel_id_trill_uc_decap_hash_key.valid = TRUE;
        ds_tunnel_id_trill_uc_decap_hash_key.hash_type = USERID_KEY_TYPE_TRILL_UC;
        lookup_info.p_ds_key = &ds_tunnel_id_trill_uc_decap_hash_key;
    }
    else if (USERID_KEY_TYPE_TRILL_MC == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_trill_mc_decap_hash_key, 0, sizeof(ds_tunnel_id_trill_mc_decap_hash_key_t));
        ds_tunnel_id_trill_mc_decap_hash_key.egress_nickname = p_userid_key->key.trill_mc.egress_nick_name;
        ds_tunnel_id_trill_mc_decap_hash_key.ingress_nickname_low = p_userid_key->key.trill_mc.ingress_nick_name & 0x7FF;
        ds_tunnel_id_trill_mc_decap_hash_key.ingress_nickname_high = p_userid_key->key.trill_mc.ingress_nick_name >> 11;
        ds_tunnel_id_trill_mc_decap_hash_key.valid = TRUE;
        ds_tunnel_id_trill_mc_decap_hash_key.hash_type = USERID_KEY_TYPE_TRILL_MC;
        lookup_info.p_ds_key = &ds_tunnel_id_trill_mc_decap_hash_key;
    }
    else if (USERID_KEY_TYPE_IPV4_RPF == userid_key_type)
    {
        sal_memset(&ds_tunnel_id_ipv4_rpf_hash_key, 0, sizeof(ds_tunnel_id_ipv4_rpf_hash_key_t));
        ds_tunnel_id_ipv4_rpf_hash_key.ip_sa = p_userid_key->key.ipv4_rpf.ip_sa;
        ds_tunnel_id_ipv4_rpf_hash_key.valid = TRUE;
        ds_tunnel_id_ipv4_rpf_hash_key.hash_type = USERID_KEY_TYPE_IPV4_RPF;
        lookup_info.p_ds_key = &ds_tunnel_id_ipv4_rpf_hash_key;
    }
    else if (USERID_KEY_TYPE_MPLS_SECTION_OAM == userid_key_type)
    {
        sal_memset(&ds_mpls_oam_label_hash_key, 0, sizeof(ds_mpls_oam_label_hash_key_t));
        ds_mpls_oam_label_hash_key.mpls_label = p_userid_key->key.mpls_section_oam.interface_id;
        ds_mpls_oam_label_hash_key.valid = TRUE;
        ds_mpls_oam_label_hash_key.hash_type = USERID_KEY_TYPE_MPLS_SECTION_OAM;
        lookup_info.p_ds_key = &ds_mpls_oam_label_hash_key;
    }
    else if (USERID_KEY_TYPE_PBT_OAM == userid_key_type)
    {
        sal_memset(&ds_pbt_oam_hash_key, 0, sizeof(ds_pbt_oam_hash_key));
        ds_pbt_oam_hash_key.mac_sa31_0 = p_userid_key->key.pbt_oam.mac_sa_31_0;
        ds_pbt_oam_hash_key.mac_sa32 = p_userid_key->key.pbt_oam.mac_sa_47_32 & 0x1;
        ds_pbt_oam_hash_key.mac_sa43_33 = (p_userid_key->key.pbt_oam.mac_sa_47_32 >> 1) & 0x7FF;
        ds_pbt_oam_hash_key.mac_sa45_44 = (p_userid_key->key.pbt_oam.mac_sa_47_32 >> 12) & 0x3;
        ds_pbt_oam_hash_key.mac_sa47_46 = (p_userid_key->key.pbt_oam.mac_sa_47_32 >> 14) & 0x3;
        ds_pbt_oam_hash_key.vrf_id = p_userid_key->key.pbt_oam.vrf_id & 0x1FF;
        ds_pbt_oam_hash_key.valid = TRUE;
        ds_pbt_oam_hash_key.hash_type = USERID_KEY_TYPE_PBT_OAM;
        lookup_info.p_ds_key = &ds_pbt_oam_hash_key;
    }
    else if (USERID_KEY_TYPE_MPLS_LABEL_OAM == userid_key_type)
    {
        sal_memset(&ds_mpls_oam_label_hash_key, 0, sizeof(ds_mpls_oam_label_hash_key_t));
        ds_mpls_oam_label_hash_key.mpls_label = p_userid_key->key.mpls_label_oam.mpls_label;
        ds_mpls_oam_label_hash_key.mpls_label_space = p_userid_key->key.mpls_label_oam.mpls_label_space;
        ds_mpls_oam_label_hash_key.valid = TRUE;
        ds_mpls_oam_label_hash_key.hash_type = USERID_KEY_TYPE_MPLS_LABEL_OAM;
        lookup_info.p_ds_key = &ds_mpls_oam_label_hash_key;
    }
    else if (USERID_KEY_TYPE_BFD_OAM == userid_key_type)
    {
        sal_memset(&ds_bfd_oam_hash_key, 0, sizeof(ds_bfd_oam_hash_key_t));
        ds_bfd_oam_hash_key.my_discriminator = p_userid_key->key.bfd_oam.my_discriminator;
        ds_bfd_oam_hash_key.valid = TRUE;
        ds_bfd_oam_hash_key.hash_type = USERID_KEY_TYPE_BFD_OAM;
        lookup_info.p_ds_key = &ds_bfd_oam_hash_key;
    }
    else if (USERID_KEY_TYPE_ETHER_FID_OAM == userid_key_type)
    {
        sal_memset(&ds_eth_oam_hash_key, 0, sizeof(ds_eth_oam_hash_key_t));
        ds_eth_oam_hash_key.global_src_port = p_userid_key->xport.global.src & 0x1FFF;
        ds_eth_oam_hash_key.global_src_port13 = IS_BIT_SET(p_userid_key->xport.global.src, 13);
        ds_eth_oam_hash_key.is_fid = p_userid_key->key.ether_fid_oam.is_fid;
        ds_eth_oam_hash_key.vlan_id = p_userid_key->key.ether_fid_oam.vlan_id;
        ds_eth_oam_hash_key.valid = TRUE;
        ds_eth_oam_hash_key.hash_type = USERID_KEY_TYPE_ETHER_FID_OAM;
        lookup_info.p_ds_key = &ds_eth_oam_hash_key;
    }
    else if (USERID_KEY_TYPE_ETHER_VLAN_OAM == userid_key_type)
    {
        sal_memset(&ds_eth_oam_hash_key, 0, sizeof(ds_eth_oam_hash_key_t));
        ds_eth_oam_hash_key.global_src_port = p_userid_key->xport.global.src & 0x1FFF;
        ds_eth_oam_hash_key.global_src_port13 = IS_BIT_SET(p_userid_key->xport.global.src, 13);
        ds_eth_oam_hash_key.is_fid = p_userid_key->key.ether_vlan_oam.is_fid;
        ds_eth_oam_hash_key.vlan_id = p_userid_key->key.ether_vlan_oam.vlan_id;
        ds_eth_oam_hash_key.valid = TRUE;
        ds_eth_oam_hash_key.hash_type = USERID_KEY_TYPE_ETHER_VLAN_OAM;
        lookup_info.p_ds_key = &ds_eth_oam_hash_key;
    }
    else if (USERID_KEY_TYPE_ETHER_RMEP == userid_key_type)
    {
        sal_memset(&ds_eth_oam_rmep_hash_key, 0, sizeof(ds_eth_oam_rmep_hash_key_t));
        ds_eth_oam_rmep_hash_key.rmep_id = p_userid_key->key.ether_rmep_oam.rmep_id;
        ds_eth_oam_rmep_hash_key.mep_index = p_userid_key->key.ether_rmep_oam.mep_index;
        ds_eth_oam_rmep_hash_key.valid = TRUE;
        ds_eth_oam_rmep_hash_key.hash_type = USERID_KEY_TYPE_ETHER_RMEP;
        lookup_info.p_ds_key = &ds_eth_oam_rmep_hash_key;
    }

#if (SDK_WORK_PLATFORM == 1)
    /*Stroe userid hash key for cosim*/
    tbls_id_t tbl_id = MaxTblId_t;
    if (cosim_db.store_key)
    {
        tbl_id = drv_hash_lookup_get_key_table_id(lookup_info.hash_module, lookup_info.hash_type);
        DRV_IF_ERROR_RETURN(cosim_db.store_key(lookup_info.p_ds_key, tbl_id));
    }
#endif

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_lookup);
    DRV_IF_ERROR_RETURN(drv_io_api.drv_hash_lookup(&lookup_info, p_userid_result));

    return DRV_E_NONE;
}

static int32
_cm_com_userid_lookup_get_associated_result(uint8 chip_id,
                                            uint8 local_phy_port,
                                            userid_direction_t direction,
                                            userid_key_type_t key_type,
                                            lookup_result_t* p_hash_lookup_result,
                                            tcam_lookup_result_t* p_tcam_lookup_result,
                                            lookup_result_t* p_lookup_result)
{
    userid_lookup_extra_result_t* p_userid_lookup_extra_result = NULL;
    oam_extra_result_t* p_oam_extra_result = NULL;
    ds_eth_rmep_chan_t* p_ds_eth_rmep_chan = NULL;
    ds_eth_oam_tcam_chan_t ds_eth_oam_tcam_chan;
    ds_eth_oam_hash_key_t ds_eth_oam_hash_key;
    ds_6word_hash_key_t ds_6word_hash_key;

    oam_info_t* p_oam_info = NULL;
    user_id_result_ctl_t user_id_result_ctl;
    uint32 cmd = 0;
    uint32 ad_index = 0;
    uint32 table_id = MaxTblId_t;
    uint32 default_table_id = MaxTblId_t;

    sal_memset(&user_id_result_ctl, 0, sizeof(user_id_result_ctl_t));
    cmd = DRV_IOR(UserIdResultCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &user_id_result_ctl));

    if (p_hash_lookup_result->valid)
    {
        p_lookup_result->valid = p_hash_lookup_result->valid;
        p_lookup_result->key_index = p_hash_lookup_result->key_index;
        p_lookup_result->conflict = p_hash_lookup_result->conflict;
        p_lookup_result->ad_index = p_hash_lookup_result->ad_index;

        ad_index = p_hash_lookup_result->ad_index & 0xFFFF;

        if (USERID_KEY_TYPE_ETHER_RMEP == key_type)
        {
            /* Only return DsRmep index to OAM Engine, 80bits */
            p_hash_lookup_result->ad_index &= 0x1FFF;
        }
        /* IPE/EPE OAM */
        else if (key_type >= USERID_KEY_TYPE_MPLS_SECTION_OAM)
        {
            /* OAM need to return oaminfo */
            DRV_PTR_VALID_CHECK(p_lookup_result->extra);
            p_oam_extra_result = (oam_extra_result_t*)p_lookup_result->extra;
            DRV_PTR_VALID_CHECK(p_oam_extra_result->info);
            DRV_PTR_VALID_CHECK(p_oam_extra_result->chan);
            p_oam_info = (oam_info_t*)p_oam_extra_result->info;

            sal_memset(p_oam_extra_result->chan, 0, sizeof(ds_eth_oam_chan_t));
            if ((USERID_KEY_TYPE_MPLS_SECTION_OAM == key_type)
               || (USERID_KEY_TYPE_PBT_OAM == key_type)
               || (USERID_KEY_TYPE_MPLS_LABEL_OAM == key_type)
               || (USERID_KEY_TYPE_BFD_OAM == key_type))
            {
                cmd = DRV_IOR(DsMplsPbtBfdOamChan_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ad_index, cmd, p_oam_extra_result->chan));
            }
            else if ((USERID_KEY_TYPE_ETHER_FID_OAM == key_type)
                    || (USERID_KEY_TYPE_ETHER_VLAN_OAM == key_type))
            {
                sal_memset(&ds_eth_oam_hash_key, 0, sizeof(ds_eth_oam_hash_key_t));
                cmd = DRV_IOR(DsEthOamHashKey_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, p_hash_lookup_result->key_index, cmd, &ds_eth_oam_hash_key));

                p_oam_info->lm_index_base = (ds_eth_oam_hash_key.lm_index_base13_9 << 9)
                                            | (ds_eth_oam_hash_key.lm_index_base8_7 << 7)
                                            | (ds_eth_oam_hash_key.lm_index_base6_5 << 5)
                                            | (ds_eth_oam_hash_key.lm_index_base4_2 << 2)
                                            | ds_eth_oam_hash_key.lm_index_base1_0;
                p_oam_info->lm_bitmap = ds_eth_oam_hash_key.lm_bitmap;
                p_oam_info->mip_bitmap = ds_eth_oam_hash_key.mip_bitmap;

                cmd = DRV_IOR(DsEthOamChan_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ad_index, cmd, p_oam_extra_result->chan));

                /* p_oam_info->oam_dest_chipid = ((ds_eth_oam_chan_t*)p_oam_extra_result->chan)->oam_dest_chip_id; */
            }
        }
        else
        {
            DRV_PTR_VALID_CHECK(p_lookup_result->extra);

            p_userid_lookup_extra_result = (userid_lookup_extra_result_t*)p_lookup_result->extra;

            /* return UserId/TunnelId */
            if ((USERID_KEY_TYPE_PBB == key_type)
                || (USERID_KEY_TYPE_IPV4_TUNNEL == key_type)
                || (USERID_KEY_TYPE_IPV4_GRE_KEY == key_type)
                || (USERID_KEY_TYPE_IPV4_UDP == key_type)
                || (USERID_KEY_TYPE_CAPWAP == key_type)
                || (USERID_KEY_TYPE_TRILL_UC_RPF == key_type)
                || (USERID_KEY_TYPE_TRILL_MC_RPF == key_type)
                || (USERID_KEY_TYPE_TRILL_MC_ADJ == key_type)
                || (USERID_KEY_TYPE_TRILL_UC == key_type)
                || (USERID_KEY_TYPE_TRILL_MC == key_type)
                || (USERID_KEY_TYPE_IPV4_RPF == key_type))
            {
                if (USERID_DIRECTION_OTHER == direction)
                {
                    table_id = DsVlanXlate_t;
                }
                else if (USERID_DIRECTION_IPE_USERID == direction)
                {
                    table_id = DsTunnelId_t;
                }
            }
            else if ((USERID_KEY_TYPE_TWO_VLAN == key_type)
                    || (USERID_KEY_TYPE_SVLAN == key_type)
                    || (USERID_KEY_TYPE_CVLAN == key_type)
                    || (USERID_KEY_TYPE_SVLAN_COS == key_type)
                    || (USERID_KEY_TYPE_CVLAN_COS == key_type)
                    || (USERID_KEY_TYPE_MAC_SA == key_type)
                    || (USERID_KEY_TYPE_PORT_MAC_SA == key_type)
                    || (USERID_KEY_TYPE_IPV4_SA == key_type)
                    || (USERID_KEY_TYPE_PORT_IPV4_SA == key_type)
                    || (USERID_KEY_TYPE_PORT == key_type)
                    || (USERID_KEY_TYPE_L2 == key_type)
                    || (USERID_KEY_TYPE_IPV6_SA == key_type))
            {
                if ((USERID_KEY_TYPE_TWO_VLAN == key_type)
                    || (USERID_KEY_TYPE_SVLAN == key_type)
                    || (USERID_KEY_TYPE_CVLAN == key_type)
                    || (USERID_KEY_TYPE_SVLAN_COS == key_type)
                    || (USERID_KEY_TYPE_CVLAN_COS == key_type)
                    || (USERID_KEY_TYPE_PORT == key_type))
                {
                    if (USERID_DIRECTION_OTHER == direction)
                    {
                        table_id = DsVlanXlate_t;
                    }
                    else if (USERID_DIRECTION_IPE_USERID == direction)
                    {
                        table_id = DsUserId_t;
                    }
                }
                else
                {
                    table_id = DsUserId_t;
                }
            }

            p_userid_lookup_extra_result->default_entry_valid = FALSE;

            cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ad_index, cmd, p_userid_lookup_extra_result->data));
        }

        if ((key_type < USERID_KEY_TYPE_MPLS_SECTION_OAM) && user_id_result_ctl.aging_en)
        {
            /* update_aging_cache(p_hash_lookup_result->key_index + 256, 1) */
        }
    }
    else if (p_tcam_lookup_result->valid)
    {
        p_lookup_result->valid = p_tcam_lookup_result->valid;
        p_lookup_result->ad_index = p_tcam_lookup_result->key_index;

        if (USERID_KEY_TYPE_ETHER_RMEP == key_type)
        {
            p_lookup_result->valid = TRUE;

            sal_memset(&ds_6word_hash_key, 0, sizeof(ds_6word_hash_key_t));
            cmd = DRV_IOR(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, p_tcam_lookup_result->key_index, cmd, &ds_6word_hash_key));
            p_ds_eth_rmep_chan = (ds_eth_rmep_chan_t*)((uint8*)&ds_6word_hash_key + sizeof(ds_3word_hash_key_t));

            p_lookup_result->ad_index = p_ds_eth_rmep_chan->ad_index;
        }
        else if (key_type >= USERID_KEY_TYPE_MPLS_SECTION_OAM)
        {
            /* OAM need to return oaminfo */
            DRV_PTR_VALID_CHECK(p_lookup_result->extra);
            p_oam_extra_result = (oam_extra_result_t*)p_lookup_result->extra;
            DRV_PTR_VALID_CHECK(p_oam_extra_result->info);
            DRV_PTR_VALID_CHECK(p_oam_extra_result->chan);
            p_oam_info = (oam_info_t*)p_oam_extra_result->info;

            sal_memset(&ds_eth_oam_tcam_chan, 0, sizeof(ds_eth_oam_tcam_chan_t));
            cmd = DRV_IOR(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, p_tcam_lookup_result->key_index, cmd, &ds_eth_oam_tcam_chan));

            sal_memcpy(p_oam_extra_result->chan,
                       (uint8*)&ds_eth_oam_tcam_chan + sizeof(ds_3word_hash_key_t),
                       sizeof(ds_3word_hash_key_t));
            if((key_type == USERID_KEY_TYPE_ETHER_FID_OAM) || (key_type == USERID_KEY_TYPE_ETHER_VLAN_OAM))
            {
                p_oam_info->lm_index_base = (ds_eth_oam_tcam_chan.lm_index_base13_9 << 9)
                                            | (ds_eth_oam_tcam_chan.lm_index_base8_7 << 7)
                                            | (ds_eth_oam_tcam_chan.lm_index_base6_5 << 5)
                                            | (ds_eth_oam_tcam_chan.lm_index_base4_2 << 2)
                                            | ds_eth_oam_tcam_chan.lm_index_base1_0;
                p_oam_info->lm_bitmap = ds_eth_oam_tcam_chan.lm_bitmap;
                p_oam_info->mip_bitmap = ds_eth_oam_tcam_chan.mip_bitmap;
            }
        }
        else
        {
            DRV_PTR_VALID_CHECK(p_lookup_result->extra);

            p_userid_lookup_extra_result = (userid_lookup_extra_result_t*)p_lookup_result->extra;

            cmd = DRV_IOR(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id,
                                          p_tcam_lookup_result->key_index,
                                          cmd,
                                          p_userid_lookup_extra_result->data));
            p_userid_lookup_extra_result->default_entry_valid = FALSE;
        }

        if (user_id_result_ctl.aging_en) /* OAM aging disabled by TCAM agingValid bit */
        {
            /* update_aging_cache(p_tcam_lookup_result->key_index, 1) */
        }
    }
    else
    {
        DRV_PTR_VALID_CHECK(p_lookup_result->extra);

        p_lookup_result->valid = p_hash_lookup_result->valid;
        p_lookup_result->key_index = p_hash_lookup_result->key_index;
        p_lookup_result->conflict = p_hash_lookup_result->conflict;
        p_lookup_result->ad_index = p_hash_lookup_result->ad_index;

        p_userid_lookup_extra_result = (userid_lookup_extra_result_t*)p_lookup_result->extra;

       /* default entry */
        if (key_type >= USERID_KEY_TYPE_MPLS_SECTION_OAM)
        {
            /* OAM no default entry */
        }
        else if (key_type <= USERID_KEY_TYPE_IPV6_SA)
        {
            /* UserId per-port default entry */
            if (USERID_DIRECTION_OTHER == direction)
            {
                default_table_id = DsUserIdEgressDefault_t;
            }
            else
            {
                default_table_id = DsUserIdIngressDefault_t;
            }

            p_lookup_result->valid = TRUE;
            p_userid_lookup_extra_result->default_entry_valid = TRUE;

            ad_index = local_phy_port & 0x7F;

            cmd = DRV_IOR(default_table_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ad_index, cmd, p_userid_lookup_extra_result->data));
        }
        else
        {
            /* TunnelId per-type default entry */
            p_lookup_result->valid = TRUE;
            p_userid_lookup_extra_result->default_entry_valid = TRUE;

            cmd = DRV_IOR(DsTunnelIdDefault_t, DRV_ENTRY_FLAG);
            ad_index = key_type - USERID_KEY_TYPE_PBB;

            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ad_index, cmd, p_userid_lookup_extra_result->data));
        }
    }

    return DRV_E_NONE;
}

int32
cm_com_userid_hash_lookup_request(uint8 chip_id,
                                  uint8 local_phy_port,
                                  userid_key_t* p_userid_key,
                                  userid_key_type_t key_type,
                                  userid_direction_t direction,
                                  lookup_result_t* p_userid_result)
{
    lookup_result_t hash_result;
    tcam_lookup_result_t tcam_result;

    DRV_PTR_VALID_CHECK(p_userid_key);
    DRV_PTR_VALID_CHECK(p_userid_result);

    sal_memset(&hash_result, 0, sizeof(lookup_result_t));
    sal_memset(&tcam_result, 0, sizeof(tcam_lookup_result_t));

    if (USERID_HASH_TYPE_INVALID != key_type_2_hash_type[key_type][direction])
    {
        DRV_IF_ERROR_RETURN(_cm_com_userid_lookup_hash(chip_id, p_userid_key, key_type, direction, &hash_result));
        DRV_IF_ERROR_RETURN(_cm_com_userid_lookup_tcam(chip_id, p_userid_key, key_type, direction, &tcam_result));
        DRV_IF_ERROR_RETURN(_cm_com_userid_lookup_get_associated_result(chip_id, local_phy_port, direction, key_type,
                                                                        &hash_result, &tcam_result, p_userid_result));
    }

    return DRV_E_NONE;
}

