/****************************************************************************
 * cm_com_hash.c  All error code Deinfines, include SDK error code.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     v1.0.
 * Author:       XuZx
 * Date:         2011-1-10.
 * Reason:       Create for GreatBelt.
 *
 * Revision:     v2.0.
 * Revisor:      XuZx
 * Date:         2011-4-27.
 * Reason:       Revise for GreatBelt v2.0
 *
 * Revision:     v4.3.0
 * Revisor:      XuZx
 * Date:         2011-7-13.
 * Reason:       Revise for GreatBelt v4.3.0

 * Revision:     v4.7.1
 * Revisor:      XuZx
 * Date:         2011-7-28.
 * Reason:       Revise for GreatBelt v4.7.1
 *
 * Revision:     v5.1.0
 * Revisor:      XuZx
 * Date:         2011-12-28.
 * Reason:       Revise for GreatBelt v5.1.0
 *
 * Revision:     v5.6.0
 * Revisor:      XuZx
 * Date:         2012-01-09.
 * Reason:       Revise for GreatBelt v5.6.0
 *
 * Revision:     v5.7.0
 * Revisor:      XuZx
 * Date:         2012-01-17.
 * Reason:       Revise for GreatBelt v5.7.0
 ****************************************************************************/

#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "ctcutil_lib.h"

#define LPM_TCAM_LOOKUP(lpm_tcam_lookup_info, lpm_tcam_lookup_result) \
        cm_com_tcam_conflict_resolve(lpm_tcam_lookup_info, lpm_tcam_lookup_result);

static uint8
_cm_com_lpm_engine_pipeline_select_bits(uint8 ip, uint8 index_mask)
{
    uint8 bits = 0;
    uint8 next = 0;
    uint8 index;

    for (index = 0; index < 8; index++)
    {
        if (IS_BIT_SET(index_mask, index))
        {
            if (IS_BIT_SET(ip, index))
            {
                SET_BIT(bits, next);
            }
            next++;
        }
    }

    return bits;
}

static int32
_cm_com_lpm_engine_cam_lookup(uint8 chip_id, fib_key_type_t fib_key_type,
                              fib_key_t* p_fib_key, lookup_result_t* p_lookup_result)
{
    uint32 cmd = 0;
    lpm_info_t* p_lpm_info = (lpm_info_t*)(p_lookup_result->extra);
    uint32 ip_da127_96 = 0;
    uint16* p_prefix_length = p_lpm_info->extra;

    p_lookup_result->valid = TRUE;

    lpm_ipv6_hash32_high_key_cam_t lpm_ipv6_hash32_high_key_cam;
    sal_memset(&lpm_ipv6_hash32_high_key_cam, 0, sizeof(lpm_ipv6_hash32_high_key_cam_t));
    cmd = DRV_IOR(LpmIpv6Hash32HighKeyCam_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &lpm_ipv6_hash32_high_key_cam));

    if ((FIB_KEY_TYPE_IPV6_UCAST == fib_key_type) || (FIB_KEY_TYPE_IPV6_NAT_DA == fib_key_type))
    {
        ip_da127_96 = p_fib_key->key.ipv6_ucast.ip_da127_96;
    }
    else if (FIB_KEY_TYPE_IPV6_RPF == fib_key_type)
    {
        ip_da127_96 = p_fib_key->key.ipv6_rpf.ip_sa127_96;
    }

    if (((lpm_ipv6_hash32_high_key_cam.ip_value0 & lpm_ipv6_hash32_high_key_cam.ip_mask0)
       ==(ip_da127_96 & lpm_ipv6_hash32_high_key_cam.ip_mask0))
       && (TRUE == lpm_ipv6_hash32_high_key_cam.valid0))
    {
        p_lpm_info->pointer.value = lpm_ipv6_hash32_high_key_cam.pointer0;
        p_lpm_info->nexthop.value = lpm_ipv6_hash32_high_key_cam.nexthop0;
        p_lpm_info->index_mask = lpm_ipv6_hash32_high_key_cam.index_mask0;
        *p_prefix_length = lpm_ipv6_hash32_high_key_cam.prefix_length0;

    }
    else if (((lpm_ipv6_hash32_high_key_cam.ip_value1 & lpm_ipv6_hash32_high_key_cam.ip_mask1)
             ==(ip_da127_96 & lpm_ipv6_hash32_high_key_cam.ip_mask1))
             && (TRUE == lpm_ipv6_hash32_high_key_cam.valid1))
    {
        p_lpm_info->pointer.value = lpm_ipv6_hash32_high_key_cam.pointer1;
        p_lpm_info->nexthop.value = lpm_ipv6_hash32_high_key_cam.nexthop1;
        p_lpm_info->index_mask = lpm_ipv6_hash32_high_key_cam.index_mask1;
        *p_prefix_length = lpm_ipv6_hash32_high_key_cam.prefix_length1;
    }
    else if (((lpm_ipv6_hash32_high_key_cam.ip_value2 & lpm_ipv6_hash32_high_key_cam.ip_mask2)
             ==(ip_da127_96 & lpm_ipv6_hash32_high_key_cam.ip_mask2))
             && (TRUE == lpm_ipv6_hash32_high_key_cam.valid2))
    {
        p_lpm_info->pointer.value = lpm_ipv6_hash32_high_key_cam.pointer2;
        p_lpm_info->nexthop.value = lpm_ipv6_hash32_high_key_cam.nexthop2;
        p_lpm_info->index_mask = lpm_ipv6_hash32_high_key_cam.index_mask2;
        *p_prefix_length = lpm_ipv6_hash32_high_key_cam.prefix_length2;
    }
    else if (((lpm_ipv6_hash32_high_key_cam.ip_value3 & lpm_ipv6_hash32_high_key_cam.ip_mask3)
             ==(ip_da127_96 & lpm_ipv6_hash32_high_key_cam.ip_mask3))
             && (TRUE == lpm_ipv6_hash32_high_key_cam.valid3))
    {
        p_lpm_info->pointer.value = lpm_ipv6_hash32_high_key_cam.pointer3;
        p_lpm_info->nexthop.value = lpm_ipv6_hash32_high_key_cam.nexthop3;
        p_lpm_info->index_mask = lpm_ipv6_hash32_high_key_cam.index_mask3;
        *p_prefix_length = lpm_ipv6_hash32_high_key_cam.prefix_length3;
    }
    else
    {
        p_lookup_result->valid = FALSE;
    }

    return DRV_E_NONE;
}

static int32
_cm_com_lpm_engine_perform_hash_lookup(uint8 chip_id,
                                       fib_key_type_t fib_key_type,
                                       lpm_hash_type_t lpm_hash_type,
                                       fib_key_t* p_fib_key,
                                       lookup_result_t* p_lookup_result)
{
    lookup_info_t  lookup_info;
    fib_engine_lookup_ctl_t  fib_engine_lookup_ctl;
    ds_lpm_ipv4_hash16_key_t ds_lpm_ipv4_hash16_key;
    ds_lpm_ipv4_mcast_hash64_key_t ds_lpm_ipv4_mcast_hash64_key;
    ds_lpm_ipv6_hash32_low_key_t ds_lpm_ipv6_hash32_low_key;
    ds_lpm_ipv6_hash32_mid_key_t ds_lpm_ipv6_hash32_mid_key;
    ds_lpm_ipv4_hash8_key_t  ds_lpm_ipv4_hash8_key;
    ds_lpm_ipv4_mcast_hash32_key_t ds_lpm_ipv4_mcast_hash32_key;
    ds_lpm_ipv6_hash32_high_key_t ds_lpm_ipv6_hash32_high_key;
    ds_lpm_ipv4_nat_sa_port_hash_key_t ds_lpm_ipv4_nat_sa_port_hash_key;
    ds_lpm_ipv4_nat_sa_hash_key_t ds_lpm_ipv4_nat_sa_hash_key;
    ds_lpm_ipv6_nat_sa_port_hash_key_t ds_lpm_ipv6_nat_sa_port_hash_key;
    ds_lpm_ipv6_nat_sa_hash_key_t ds_lpm_ipv6_nat_sa_hash_key;
    ds_lpm_ipv4_nat_da_port_hash_key_t ds_lpm_ipv4_nat_da_port_hash_key;
    ds_lpm_ipv6_nat_da_port_hash_key_t ds_lpm_ipv6_nat_da_port_hash_key;
    ds_lpm_ipv6_mcast_hash0_key_t ds_lpm_ipv6_mcast_hash0_key;
    ds_lpm_ipv6_mcast_hash1_key_t ds_lpm_ipv6_mcast_hash1_key;
    uint8 l4_port_type = 0;
    uint16 ipv6_sa_prefix = 0;
    uint16 ipv6_da_prefix = 0;
    uint16 l4_source_port = 0;
    uint32 cmd = 0;

    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));
    sal_memset(&ds_lpm_ipv4_hash16_key, 0, sizeof(ds_lpm_ipv4_hash16_key_t));
    sal_memset(&ds_lpm_ipv4_mcast_hash64_key, 0, sizeof(ds_lpm_ipv4_mcast_hash64_key_t));
    sal_memset(&ds_lpm_ipv6_hash32_low_key, 0, sizeof(ds_lpm_ipv6_hash32_low_key_t));
    sal_memset(&ds_lpm_ipv6_hash32_mid_key, 0, sizeof(ds_lpm_ipv6_hash32_mid_key_t));
    sal_memset(&ds_lpm_ipv4_hash16_key, 0, sizeof(ds_lpm_ipv4_hash16_key_t));
    sal_memset(&ds_lpm_ipv4_hash8_key, 0, sizeof(ds_lpm_ipv4_hash8_key_t));
    sal_memset(&ds_lpm_ipv4_mcast_hash32_key, 0, sizeof(ds_lpm_ipv4_mcast_hash32_key_t));
    sal_memset(&ds_lpm_ipv6_hash32_high_key, 0, sizeof(ds_lpm_ipv6_hash32_high_key_t));
    sal_memset(&ds_lpm_ipv4_nat_sa_port_hash_key, 0, sizeof(ds_lpm_ipv4_nat_sa_port_hash_key_t));
    sal_memset(&ds_lpm_ipv4_nat_sa_hash_key, 0, sizeof(ds_lpm_ipv4_nat_sa_hash_key_t));
    sal_memset(&ds_lpm_ipv6_nat_sa_port_hash_key, 0, sizeof(ds_lpm_ipv6_nat_sa_port_hash_key_t));
    sal_memset(&ds_lpm_ipv6_nat_sa_hash_key, 0, sizeof(ds_lpm_ipv6_nat_sa_hash_key_t));
    sal_memset(&ds_lpm_ipv4_nat_da_port_hash_key, 0, sizeof(ds_lpm_ipv4_nat_da_port_hash_key_t));
    sal_memset(&ds_lpm_ipv6_nat_da_port_hash_key, 0, sizeof(ds_lpm_ipv6_nat_da_port_hash_key_t));
    sal_memset(&ds_lpm_ipv6_mcast_hash0_key, 0, sizeof(ds_lpm_ipv6_mcast_hash0_key_t));
    sal_memset(&ds_lpm_ipv6_mcast_hash1_key, 0, sizeof(ds_lpm_ipv6_mcast_hash1_key_t));

    sal_memset(&lookup_info, 0, sizeof(lookup_info_t));
    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl));

    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_ctl));

    lookup_info.chip_id = chip_id;
    lookup_info.hash_module = HASH_MODULE_LPM;
    lookup_info.hash_type = lpm_hash_type;

    if (L4_TYPE_TCP == p_fib_key->layer4_type)
    {
        l4_port_type = 0x3;
    }
    else if (L4_TYPE_UDP == p_fib_key->layer4_type)
    {
        l4_port_type = 0x2;
    }
    else
    {
        l4_port_type = 0;
    }

    switch (lpm_hash_type)
    {
        case LPM_HASH_TYPE_IPV4_16:
            ds_lpm_ipv4_hash16_key.hash_type = lpm_hash_type;
            ds_lpm_ipv4_hash16_key.valid = TRUE;

            if ((FIB_KEY_TYPE_IPV4_UCAST == fib_key_type) || (FIB_KEY_TYPE_IPV4_NAT_DA == fib_key_type))
            {
                ds_lpm_ipv4_hash16_key.ip = p_fib_key->key.ipv4_ucast.ip_da >> 16;
            }
            else if (FIB_KEY_TYPE_IPV4_RPF == fib_key_type)
            {
                ds_lpm_ipv4_hash16_key.ip = p_fib_key->key.ipv4_ucast.ip_sa >> 16;
            }

            ds_lpm_ipv4_hash16_key.vrf_id = p_fib_key->id.vrf_id;
            lookup_info.p_ds_key = &ds_lpm_ipv4_hash16_key;
            break;

        case LPM_HASH_TYPE_IPV4_SG:
            ds_lpm_ipv4_mcast_hash64_key.hash_type0 = lpm_hash_type;
            ds_lpm_ipv4_mcast_hash64_key.hash_type1 = lpm_hash_type;
            ds_lpm_ipv4_mcast_hash64_key.valid0 = TRUE;
            ds_lpm_ipv4_mcast_hash64_key.valid1 = TRUE;
            ds_lpm_ipv4_mcast_hash64_key.ip_sa = p_fib_key->key.ipv4_mcast.ip_sa;
            ds_lpm_ipv4_mcast_hash64_key.ip_da = p_fib_key->key.ipv4_mcast.ip_da;
            ds_lpm_ipv4_mcast_hash64_key.vrf_id = p_fib_key->id.vrf_id;

            if (FIB_KEY_TYPE_MAC_IPV4_MULTICAST == fib_key_type)
            {
                ds_lpm_ipv4_mcast_hash64_key.is_mac = TRUE;
            }
            else
            {
                ds_lpm_ipv4_mcast_hash64_key.is_mac = FALSE;
            }
            lookup_info.p_ds_key = &ds_lpm_ipv4_mcast_hash64_key;
            break;

        case LPM_HASH_TYPE_IPV6_LOW32:
            ds_lpm_ipv6_hash32_low_key.hash_type0 = lpm_hash_type;
            ds_lpm_ipv6_hash32_low_key.valid0 = TRUE;
            ds_lpm_ipv6_hash32_low_key.ip_da31_0 = p_fib_key->key.ipv6_ucast.ip_da31_0;
            ds_lpm_ipv6_hash32_low_key.pointer2_0 = p_fib_key->key.ipv6_ucast.pointer & 0x7;
            ds_lpm_ipv6_hash32_low_key.pointer4_3 = (p_fib_key->key.ipv6_ucast.pointer >> 3) & 0x3;
            ds_lpm_ipv6_hash32_low_key.pointer12_5 = (p_fib_key->key.ipv6_ucast.pointer >> 5) & 0xFF;
            ds_lpm_ipv6_hash32_low_key.mid = p_fib_key->key.ipv6_ucast.ipv6_mid;

            lookup_info.p_ds_key = &ds_lpm_ipv6_hash32_low_key;
            break;

        case LPM_HASH_TYPE_IPV6_MID32:
            ds_lpm_ipv6_hash32_mid_key.valid = TRUE;
            ds_lpm_ipv6_hash32_mid_key.hash_type = lpm_hash_type;
            ds_lpm_ipv6_hash32_mid_key.ip_da = p_fib_key->key.ipv6_ucast.ip_da63_32;

            lookup_info.p_ds_key = &ds_lpm_ipv6_hash32_mid_key;
            break;

        case LPM_HASH_TYPE_IPV4_8:
            ds_lpm_ipv4_hash8_key.hash_type = lpm_hash_type;
            ds_lpm_ipv4_hash8_key.valid = TRUE;

            if ((FIB_KEY_TYPE_IPV4_UCAST == fib_key_type) || (FIB_KEY_TYPE_IPV4_NAT_DA == fib_key_type))
            {
                ds_lpm_ipv4_hash8_key.ip = p_fib_key->key.ipv4_ucast.ip_da >> 24;
            }
            else if (FIB_KEY_TYPE_IPV4_RPF == fib_key_type)
            {
                ds_lpm_ipv4_hash8_key.ip = p_fib_key->key.ipv4_rpf.ip_sa >> 24;
            }

            ds_lpm_ipv4_hash8_key.vrf_id = p_fib_key->id.vrf_id;

            lookup_info.p_ds_key = &ds_lpm_ipv4_hash8_key;
            break;

        case LPM_HASH_TYPE_IPV4_XG:
            ds_lpm_ipv4_mcast_hash32_key.hash_type = lpm_hash_type;
            ds_lpm_ipv4_mcast_hash32_key.valid = TRUE;
            ds_lpm_ipv4_mcast_hash32_key.ip_da = p_fib_key->key.ipv4_mcast.ip_da;
            ds_lpm_ipv4_mcast_hash32_key.vrf_id = p_fib_key->id.vrf_id;

            if (FIB_KEY_TYPE_MAC_IPV4_MULTICAST == fib_key_type)
            {
                ds_lpm_ipv4_mcast_hash32_key.is_mac = TRUE;
            }
            else
            {
                ds_lpm_ipv4_mcast_hash32_key.is_mac = FALSE;
            }
            lookup_info.p_ds_key = &ds_lpm_ipv4_mcast_hash32_key;
            break;

        case LPM_HASH_TYPE_IPV6_HIGH32:
            ds_lpm_ipv6_hash32_high_key.hash_type = lpm_hash_type;
            ds_lpm_ipv6_hash32_high_key.valid = TRUE;

            if ((FIB_KEY_TYPE_IPV6_UCAST == fib_key_type) || (FIB_KEY_TYPE_IPV6_NAT_DA == fib_key_type))
            {
                ds_lpm_ipv6_hash32_high_key.ip = p_fib_key->key.ipv6_ucast.ip_da127_96;
            }
            else if (FIB_KEY_TYPE_IPV6_RPF == fib_key_type)
            {
                ds_lpm_ipv6_hash32_high_key.ip = p_fib_key->key.ipv6_rpf.ip_sa127_96;
            }

            ds_lpm_ipv6_hash32_high_key.vrf_id0 = p_fib_key->id.vrf_id & 0xFF;
            ds_lpm_ipv6_hash32_high_key.vrf_id13_8 = p_fib_key->id.vrf_id >> 8;
            lookup_info.p_ds_key = &ds_lpm_ipv6_hash32_high_key;
            break;

        case LPM_HASH_TYPE_IPV6_SG1:
            ds_lpm_ipv6_mcast_hash1_key.ip_sa31_0 = p_fib_key->key.ipv6_mcast.ip_sa31_0;
            ds_lpm_ipv6_mcast_hash1_key.ip_sa47_32 = p_fib_key->key.ipv6_mcast.ip_sa63_32 & 0xFFFF;
            ds_lpm_ipv6_mcast_hash1_key.ip_sa55_48 = (p_fib_key->key.ipv6_mcast.ip_sa63_32 >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash1_key.ip_sa87_56 = ((p_fib_key->key.ipv6_mcast.ip_sa95_64 & 0xFFFFFF) << 8)
                                                     | ((p_fib_key->key.ipv6_mcast.ip_sa63_32 >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash1_key.ip_sa117_88 = ((p_fib_key->key.ipv6_mcast.ip_sa127_96 & 0x3FFFFF) << 8)
                                                     | ((p_fib_key->key.ipv6_mcast.ip_sa95_64 >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash1_key.hash0_result1_0 = p_fib_key->key.ipv6_mcast.pointer & 0x3;
            ds_lpm_ipv6_mcast_hash1_key.hash0_result2_2 = (p_fib_key->key.ipv6_mcast.pointer >> 2) & 0x1;
            ds_lpm_ipv6_mcast_hash1_key.hash0_result10_3 = (p_fib_key->key.ipv6_mcast.pointer >> 3) & 0xFF;
            ds_lpm_ipv6_mcast_hash1_key.hash_type0 = LPM_HASH_TYPE_IPV6_SG1;
            ds_lpm_ipv6_mcast_hash1_key.hash_type1 = LPM_HASH_TYPE_IPV6_SG1;
            ds_lpm_ipv6_mcast_hash1_key.valid0 = TRUE;
            ds_lpm_ipv6_mcast_hash1_key.valid1 = TRUE;

            ipv6_sa_prefix = p_fib_key->key.ipv6_mcast.ip_sa127_96 >> 22;

            if (fib_engine_lookup_ctl.ipv6_sa1_prefix0 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 0;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix1 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 1;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix2 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 2;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix3 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 3;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix4 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 0;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix5 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 1;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix6 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 2;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }
            else
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 3;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }

            lookup_info.p_ds_key = &ds_lpm_ipv6_mcast_hash1_key;
            break;

        case LPM_HASH_TYPE_IPV6_SG0:
            ds_lpm_ipv6_mcast_hash0_key.ip_da31_0 = p_fib_key->key.ipv6_mcast.ip_da31_0;
            ds_lpm_ipv6_mcast_hash0_key.ip_da47_32 = p_fib_key->key.ipv6_mcast.ip_da63_32 & 0xFFFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da55_48 = (p_fib_key->key.ipv6_mcast.ip_da63_32 >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da87_56 = ((p_fib_key->key.ipv6_mcast.ip_da95_64 & 0xFFFFFF) << 8)
                                                     | ((p_fib_key->key.ipv6_mcast.ip_da63_32 >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da109_88 = ((p_fib_key->key.ipv6_mcast.ip_da127_96 & 0x3FFF) << 8)
                                                     | ((p_fib_key->key.ipv6_mcast.ip_da95_64 >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da111_110 = (p_fib_key->key.ipv6_mcast.ip_da127_96 >> 14) & 0x3;
            ds_lpm_ipv6_mcast_hash0_key.ip_da119_112 = (p_fib_key->key.ipv6_mcast.ip_da127_96 >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id0_0 = p_fib_key->id.vrf_id & 0x1;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id10_1 = (p_fib_key->id.vrf_id >> 1) & 0x3FF;
            ds_lpm_ipv6_mcast_hash0_key.valid0 = TRUE;
            ds_lpm_ipv6_mcast_hash0_key.valid1 = TRUE;
            ds_lpm_ipv6_mcast_hash0_key.hash_type0 = LPM_HASH_TYPE_IPV6_SG0;
            ds_lpm_ipv6_mcast_hash0_key.hash_type1 = LPM_HASH_TYPE_IPV6_SG0;

            if (FIB_KEY_TYPE_MAC_IPV6_MULTICAST == fib_key_type)
            {
                ds_lpm_ipv6_mcast_hash0_key.is_mac = TRUE;
            }
            else
            {
                ds_lpm_ipv6_mcast_hash0_key.is_mac = FALSE;
            }
            lookup_info.p_ds_key = &ds_lpm_ipv6_mcast_hash0_key;
            break;

        case LPM_HASH_TYPE_IPV6_XG:
            ds_lpm_ipv6_mcast_hash0_key.ip_da31_0 = p_fib_key->key.ipv6_mcast.ip_da31_0;
            ds_lpm_ipv6_mcast_hash0_key.ip_da47_32 = p_fib_key->key.ipv6_mcast.ip_da63_32 & 0xFFFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da55_48 = (p_fib_key->key.ipv6_mcast.ip_da63_32 >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da87_56 =((p_fib_key->key.ipv6_mcast.ip_da95_64 & 0xFFFFFF) << 8)
                                                     | ((p_fib_key->key.ipv6_mcast.ip_da63_32 >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da109_88 = ((p_fib_key->key.ipv6_mcast.ip_da127_96 & 0x3FFF) << 8)
                                                     | ((p_fib_key->key.ipv6_mcast.ip_da95_64 >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da111_110 = (p_fib_key->key.ipv6_mcast.ip_da127_96 >> 14) & 0x3;
            ds_lpm_ipv6_mcast_hash0_key.ip_da119_112 = (p_fib_key->key.ipv6_mcast.ip_da127_96 >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id0_0 = p_fib_key->id.vrf_id & 0x1;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id10_1 = (p_fib_key->id.vrf_id >> 1) & 0x3FF;
            ds_lpm_ipv6_mcast_hash0_key.hash_type0 = LPM_HASH_TYPE_IPV6_XG;
            ds_lpm_ipv6_mcast_hash0_key.hash_type1 = LPM_HASH_TYPE_IPV6_XG;
            ds_lpm_ipv6_mcast_hash0_key.valid0 = TRUE;
            ds_lpm_ipv6_mcast_hash0_key.valid1 = TRUE;

            if (FIB_KEY_TYPE_MAC_IPV6_MULTICAST == fib_key_type)
            {
                ds_lpm_ipv6_mcast_hash0_key.is_mac = TRUE;
            }
            else
            {
                ds_lpm_ipv6_mcast_hash0_key.is_mac = FALSE;
            }
            lookup_info.p_ds_key = &ds_lpm_ipv6_mcast_hash0_key;
            break;

        case LPM_HASH_TYPE_IPV4_NAT_SA_PORT:
            ds_lpm_ipv4_nat_sa_port_hash_key.hash_type = lpm_hash_type;
            ds_lpm_ipv4_nat_sa_port_hash_key.valid = TRUE;
            ds_lpm_ipv4_nat_sa_port_hash_key.ip_sa = p_fib_key->key.ipv4_nat_sa_port.ip_sa;
            ds_lpm_ipv4_nat_sa_port_hash_key.vrf_id = p_fib_key->id.vrf_id;
            l4_source_port = p_fib_key->key.ipv4_nat_sa_port.l4_source_port;
            ds_lpm_ipv4_nat_sa_port_hash_key.l4_source_port7_0 = l4_source_port & 0xFF;
            ds_lpm_ipv4_nat_sa_port_hash_key.l4_source_port15_8 = l4_source_port >> 8;
            ds_lpm_ipv4_nat_sa_port_hash_key.l4_port_type = l4_port_type;
            lookup_info.p_ds_key = &ds_lpm_ipv4_nat_sa_port_hash_key;
            break;

        case LPM_HASH_TYPE_IPV4_NAT_SA:
            ds_lpm_ipv4_nat_sa_hash_key.hash_type = lpm_hash_type;
            ds_lpm_ipv4_nat_sa_hash_key.valid = TRUE;
            ds_lpm_ipv4_nat_sa_hash_key.ip_sa = p_fib_key->key.ipv4_nat_sa_port.ip_sa;
            ds_lpm_ipv4_nat_sa_hash_key.vrf_id1 = (p_fib_key->id.vrf_id >> 8) & 0x3F;
            ds_lpm_ipv4_nat_sa_hash_key.vrf_id0 = p_fib_key->id.vrf_id & 0xFF;
            lookup_info.p_ds_key = &ds_lpm_ipv4_nat_sa_hash_key;
            break;

        case LPM_HASH_TYPE_IPV6_NAT_SA_PORT:
            ds_lpm_ipv6_nat_sa_port_hash_key.hash_type0 = lpm_hash_type;
            ds_lpm_ipv6_nat_sa_port_hash_key.hash_type1 =lpm_hash_type;
            ds_lpm_ipv6_nat_sa_port_hash_key.valid0 = TRUE;
            ds_lpm_ipv6_nat_sa_port_hash_key.valid1 = TRUE;
            ds_lpm_ipv6_nat_sa_port_hash_key.l4_source_port7_0 = p_fib_key->key.ipv6_nat_sa_port.l4_source_port & 0xFF;
            ds_lpm_ipv6_nat_sa_port_hash_key.l4_source_port15_8 = p_fib_key->key.ipv6_nat_sa_port.l4_source_port >> 8;
            ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa31_0 = p_fib_key->key.ipv6_nat_sa_port.ip_sa31_0;
            ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa47_32 = p_fib_key->key.ipv6_nat_sa_port.ip_sa63_32 & 0xFFFF;
            ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa79_48 = ((p_fib_key->key.ipv6_nat_sa_port.ip_sa95_64 & 0xFFFF) << 16)
                                                        | (p_fib_key->key.ipv6_nat_sa_port.ip_sa63_32 >> 16);
            ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa111_80 = ((p_fib_key->key.ipv6_nat_sa_port.ip_sa127_96 & 0xFFFF) << 16)
                                                           | (p_fib_key->key.ipv6_nat_sa_port.ip_sa95_64 >> 16);
            ipv6_sa_prefix = p_fib_key->key.ipv6_nat_sa_port.ip_sa127_96 >> 16;

            if (fib_engine_lookup_ctl.ipv6_sa0_prefix0 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa0_prefix1 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 1;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa0_prefix2 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 2;
            }
            else
            {
                ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 3;
            }
            ds_lpm_ipv6_nat_sa_port_hash_key.l4_port_type = l4_port_type;
            lookup_info.p_ds_key = &ds_lpm_ipv6_nat_sa_port_hash_key;
            break;

        case LPM_HASH_TYPE_IPV6_NAT_SA:
            ds_lpm_ipv6_nat_sa_hash_key.hash_type0 = lpm_hash_type;
            ds_lpm_ipv6_nat_sa_hash_key.hash_type1 = lpm_hash_type;
            ds_lpm_ipv6_nat_sa_hash_key.valid0 = TRUE;
            ds_lpm_ipv6_nat_sa_hash_key.valid1 = TRUE;
            ds_lpm_ipv6_nat_sa_hash_key.ip_sa31_0 = p_fib_key->key.ipv6_nat_sa_port.ip_sa31_0;
            ds_lpm_ipv6_nat_sa_hash_key.ip_sa47_32 = p_fib_key->key.ipv6_nat_sa_port.ip_sa63_32 & 0xFFFF;
            ds_lpm_ipv6_nat_sa_hash_key.ip_sa79_48 = ((p_fib_key->key.ipv6_nat_sa_port.ip_sa95_64 & 0xFFFF) << 16)
                                                     | (p_fib_key->key.ipv6_nat_sa_port.ip_sa63_32 >> 16);
            ds_lpm_ipv6_nat_sa_hash_key.ip_sa111_80 = ((p_fib_key->key.ipv6_nat_sa_port.ip_sa127_96 & 0xFFFF) << 16)
                                                      | (p_fib_key->key.ipv6_nat_sa_port.ip_sa95_64 >> 16);
            ds_lpm_ipv6_nat_sa_hash_key.ip_sa119_112 = (p_fib_key->key.ipv6_nat_sa_port.ip_sa127_96 >> 16) & 0xFF;
            ds_lpm_ipv6_nat_sa_hash_key.ip_sa127_120 = (p_fib_key->key.ipv6_nat_sa_port.ip_sa127_96 >> 24) & 0xFF;
            lookup_info.p_ds_key = &ds_lpm_ipv6_nat_sa_hash_key;
            break;

        case LPM_HASH_TYPE_IPV4_NAT_DA_PORT:
            ds_lpm_ipv4_nat_da_port_hash_key.hash_type = lpm_hash_type;
            ds_lpm_ipv4_nat_da_port_hash_key.ip_da = p_fib_key->key.ipv4_ucast.ip_da;
            ds_lpm_ipv4_nat_da_port_hash_key.vrf_id7_0 = p_fib_key->id.vrf_id & 0xFF;
            ds_lpm_ipv4_nat_da_port_hash_key.valid = TRUE ;
            ds_lpm_ipv4_nat_da_port_hash_key.l4_dest_port7_0 = p_fib_key->key.ipv4_ucast.l4_dest_port & 0xFF;
            ds_lpm_ipv4_nat_da_port_hash_key.l4_dest_port15_8 = p_fib_key->key.ipv4_ucast.l4_dest_port >> 8;
            ds_lpm_ipv4_nat_da_port_hash_key.l4_port_type = l4_port_type;
            lookup_info.p_ds_key = &ds_lpm_ipv4_nat_da_port_hash_key;
            break;

        default:
            /* LPM_HASH_TYPE_IPV6_NAT_DA_PORT */
            ds_lpm_ipv6_nat_da_port_hash_key.hash_type0 = lpm_hash_type;
            ds_lpm_ipv6_nat_da_port_hash_key.hash_type1 =lpm_hash_type;
            ds_lpm_ipv6_nat_da_port_hash_key.valid0 = TRUE;
            ds_lpm_ipv6_nat_da_port_hash_key.valid1 = TRUE;
            ds_lpm_ipv6_nat_da_port_hash_key.l4_dest_port7_0 = p_fib_key->key.ipv6_ucast.l4_dest_port & 0xFF;
            ds_lpm_ipv6_nat_da_port_hash_key.l4_dest_port15_8 = (p_fib_key->key.ipv6_ucast.l4_dest_port >> 8) & 0xFF;
            ds_lpm_ipv6_nat_da_port_hash_key.ip_da31_0 = p_fib_key->key.ipv6_ucast.ip_da31_0;
            ds_lpm_ipv6_nat_da_port_hash_key.ip_da47_32 = p_fib_key->key.ipv6_ucast.ip_da63_32 & 0xFFFF;
            ds_lpm_ipv6_nat_da_port_hash_key.ip_da79_48 = ((p_fib_key->key.ipv6_ucast.ip_da95_64 & 0xFFFF) << 16)
                                                         | (p_fib_key->key.ipv6_ucast.ip_da63_32 >> 16);
            ds_lpm_ipv6_nat_da_port_hash_key.ip_da111_80 = ((p_fib_key->key.ipv6_ucast.ip_da127_96 & 0xFFFF) << 16)
                                                           | (p_fib_key->key.ipv6_ucast.ip_da95_64 >> 16);
            ipv6_da_prefix = p_fib_key->key.ipv6_ucast.ip_da127_96 >> 16;

            if (fib_engine_lookup_ctl.ipv6_sa0_prefix0 == ipv6_da_prefix)
            {
                ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa0_prefix1 == ipv6_da_prefix)
            {
                ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 1;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa0_prefix2 == ipv6_da_prefix)
            {
                ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 2;
            }
            else
            {
                ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 3;
            }
            ds_lpm_ipv6_nat_da_port_hash_key.l4_port_type = l4_port_type;
            lookup_info.p_ds_key = &ds_lpm_ipv6_nat_da_port_hash_key;

            break;
    }

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_lookup);
    DRV_IF_ERROR_RETURN(drv_io_api.drv_hash_lookup(&lookup_info, p_lookup_result));

#if (SDK_WORK_PLATFORM == 1)
    /*Stroe LPM hash key for cosim*/
    tbls_id_t tbl_id = MaxTblId_t;
    if (cosim_db.store_key)
    {
        tbl_id = drv_hash_lookup_get_key_table_id(HASH_MODULE_LPM, lpm_hash_type);
        if (MaxTblId_t == tbl_id)
        {
            return DRV_E_INVALID_TBL;
        }
        DRV_IF_ERROR_RETURN(cosim_db.store_key(lookup_info.p_ds_key, tbl_id));
    }
#endif

    return DRV_E_NONE;
}

int32
_cm_com_lpm_engine_pipeline(uint8 chip_id,
                            uint32 ip,
                            uint8 index_mask,
                            lpm_pointer_t* p_pointer,
                            lpm_nexthop_t* p_nexthop)
{
    uint8  bucket = 0;
    uint8  match_key0 = FALSE;
    uint8  match_key1 = FALSE;
    uint8  stage_index = 0;
    uint8  ip8 = 0;
    uint32 cmd = 0;
    uint32 ds_lpm_lookup_key_index = 0;
    ds_lpm_lookup_key_t ds_lpm_lookup_key;
    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;

    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl));
    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_ctl));

    p_nexthop->value = INVALID_NEXTHOP;

    for (stage_index = LPM_PIPE_LINE_STAGE0; stage_index < LPM_PIPE_LINE_STAGE_NUM; stage_index++)
    {
        if (p_pointer->value & POINTER_STAGE_MASK)
        {
            p_pointer->value -= STAGE_OFFSET;
            ip = ip >> 8;
            continue;
        }

        if (INVALID_POINTER_OFFSET == (p_pointer->value & POINTER_OFFSET_MASK))
        {
            break;
        }

        ip8 = (ip >> ((LPM_PIPE_LINE_STAGE_NUM - stage_index - 1) * 8)) &  0xFF;

        bucket = _cm_com_lpm_engine_pipeline_select_bits(ip8, index_mask);

        ds_lpm_lookup_key_index = (p_pointer->value & POINTER_OFFSET_MASK) + bucket;

        sal_memset(&ds_lpm_lookup_key, 0, sizeof(ds_lpm_lookup_key));

        if (LPM_PIPE_LINE_STAGE0 == stage_index)
        {
            cmd = DRV_IOR(DsLpmLookupKey0_t, DRV_ENTRY_FLAG);
        }
        else if (LPM_PIPE_LINE_STAGE1 == stage_index)
        {
            cmd = DRV_IOR(DsLpmLookupKey1_t, DRV_ENTRY_FLAG);
        }
        else if (LPM_PIPE_LINE_STAGE2 == stage_index)
        {
            cmd = DRV_IOR(DsLpmLookupKey2_t, DRV_ENTRY_FLAG);
        }
        else if (LPM_PIPE_LINE_STAGE3 == stage_index)
        {
            cmd = DRV_IOR(DsLpmLookupKey3_t, DRV_ENTRY_FLAG);
        }

        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_lpm_lookup_key_index, cmd, &ds_lpm_lookup_key));

        /* pointer entry */
        if ((LPM_LOOKUP_KEY_TYPE_POINTER == ds_lpm_lookup_key.type0) && (ds_lpm_lookup_key.ip0 == ip8))
        {
            p_pointer->value = (ds_lpm_lookup_key.pointer0_17_16 << 16) | ds_lpm_lookup_key.nexthop0;
            index_mask = ds_lpm_lookup_key.mask0;
        }
        else if ((LPM_LOOKUP_KEY_TYPE_POINTER == ds_lpm_lookup_key.type1) && (ds_lpm_lookup_key.ip1 == ip8))
        {
            p_pointer->value = (ds_lpm_lookup_key.pointer1_17_16 << 16) | ds_lpm_lookup_key.nexthop1;
            index_mask = ds_lpm_lookup_key.mask1;
        }
        else
        {
            p_pointer->value = INVALID_POINTER;
        }

        /* nexthop prefix */
        match_key0 = ((LPM_LOOKUP_KEY_TYPE_NEXTHOP == ds_lpm_lookup_key.type0)
                     && ((ds_lpm_lookup_key.ip0 & ds_lpm_lookup_key.mask0) == (ip8 & ds_lpm_lookup_key.mask0)));

        match_key1 = ((LPM_LOOKUP_KEY_TYPE_NEXTHOP == ds_lpm_lookup_key.type1)
                     && ((ds_lpm_lookup_key.ip1 & ds_lpm_lookup_key.mask1) == (ip8 & ds_lpm_lookup_key.mask1)));

        if (match_key0 && match_key1)
        {
            if (ds_lpm_lookup_key.mask0 > ds_lpm_lookup_key.mask1)
            {
                p_nexthop->value = ds_lpm_lookup_key.nexthop0;
            }
            else
            {
                p_nexthop->value = ds_lpm_lookup_key.nexthop1;
            }
        }
        else if (match_key0)
        {
            p_nexthop->value = ds_lpm_lookup_key.nexthop0;
        }
        else if (match_key1)
        {
            p_nexthop->value = ds_lpm_lookup_key.nexthop1;
        }
    }

    if (INVALID_POINTER_OFFSET == (p_pointer->value & POINTER_OFFSET_MASK))
    {
        p_pointer->value = INVALID_POINTER;
    }

    return DRV_E_NONE;
}

static int32
_cm_com_lpm_engine_hash_step1_result(uint8 chip_id,
                                     fib_key_type_t fib_key_type,
                                     lookup_result_t * p_hash1_lookup_result,
                                     lookup_result_t* p_hash2_lookup_result,
                                     lookup_result_t* p_hash3_lookup_result,
                                     lookup_result_t* p_cam_lookup_result,
                                     tcam_lookup_result_t* p_tcam1_lookup_result,
                                     tcam_lookup_result_t* p_tcam2_lookup_result,
                                     tcam_lookup_result_t* p_tcam3_lookup_result,
                                     lookup_result_t* p_step1_lookup_result)
{
    /* LPM_HASH_LOOKUP_RESULT */
    uint16 ipv6_mid = 0;
    uint32 cmd = 0;
    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;
    lpm_info_t* p_lpm_hash1_info = (lpm_info_t*)p_hash1_lookup_result->extra;
    lpm_info_t* p_lpm_hash2_info = (lpm_info_t*)p_hash2_lookup_result->extra;
    lpm_info_t* p_lpm_hash3_info = (lpm_info_t*)p_hash3_lookup_result->extra;
    lpm_info_t* p_lpm_cam_info = (lpm_info_t*)p_cam_lookup_result->extra;

    lpm_info_t* p_step1_lpm_info = (lpm_info_t*)p_step1_lookup_result->extra;
    lpm_extra_info_t* p_lpm_extra_info = (lpm_extra_info_t*)p_step1_lpm_info->extra;
    lpm_tcam_ad_mem_t lpm_tcam_ad_mem1;
    lpm_tcam_ad_mem_t lpm_tcam_ad_mem2;
    lpm_tcam_ad_mem_t lpm_tcam_ad_mem3;

    uint8 hash1_aging_en = FALSE;
    uint8 hash2_aging_en = FALSE;
    uint8 hash3_aging_en = FALSE;
    uint8 tcam1_aging_en = FALSE;
    uint8 tcam2_aging_en = FALSE;
    uint16 hash1_prefix_length = 0;
    uint16 hash2_prefix_length = 0;
    uint16 hash3_prefix_length = 0;

    uint32 ipv6_mcast128_result = p_hash2_lookup_result->key_index;
    uint32 ipv6_mcast128_nexthop = p_lpm_hash2_info->nexthop.value;

    sal_memset(&lpm_tcam_ad_mem1, 0, sizeof(lpm_tcam_ad_mem1));
    sal_memset(&lpm_tcam_ad_mem2, 0, sizeof(lpm_tcam_ad_mem2));
    sal_memset(&lpm_tcam_ad_mem3, 0, sizeof(lpm_tcam_ad_mem3));

    if (p_tcam1_lookup_result->valid)
    {
        sal_memset(&lpm_tcam_ad_mem1, 0, sizeof(lpm_tcam_ad_mem1));
        cmd = DRV_IOR(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, p_tcam1_lookup_result->key_index, cmd, &lpm_tcam_ad_mem1));
    }

    if (p_tcam2_lookup_result->valid)
    {
        sal_memset(&lpm_tcam_ad_mem2, 0, sizeof(lpm_tcam_ad_mem2));
        cmd = DRV_IOR(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, p_tcam2_lookup_result->key_index, cmd, &lpm_tcam_ad_mem2));
    }

    if (p_tcam3_lookup_result->valid)
    {
        sal_memset(&lpm_tcam_ad_mem3, 0, sizeof(lpm_tcam_ad_mem3));
        cmd = DRV_IOR(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, p_tcam3_lookup_result->key_index, cmd, &lpm_tcam_ad_mem3));
    }

    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));
    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_ctl));

    switch (fib_key_type & 0xF)
    {
        case FIB_KEY_TYPE_IPV4_UCAST:
        case FIB_KEY_TYPE_IPV4_NAT_DA:
            /* IPv4 Ucast */
            if ((!IS_BIT_SET(fib_key_type, 0)) && fib_engine_lookup_ctl.ipv4_nat_da_lookup_en)
            {
                /* IPv4 DA + PORT */
                hash1_prefix_length = 48;
                hash1_aging_en = TRUE;
            }

            /* No aging for Ucast routing */
            if (!fib_engine_lookup_ctl.lpm_ipv4_pipeline3_en)
            {
                hash2_prefix_length = 16;
            }

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV4_UC))
            {
               hash3_prefix_length = 8;
            }

            /* pop tcam result */
            break;

        case FIB_KEY_TYPE_IPV4_MCAST:
            /* IPv4 Mcast */
            hash1_prefix_length = 64;
            hash1_aging_en = TRUE;

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV4_MC))
            {
                hash2_prefix_length = 32;
                hash2_aging_en = TRUE;
            }

            /* pop tcam result */
            break;

        case FIB_KEY_TYPE_IPV6_UCAST:
        case FIB_KEY_TYPE_IPV6_NAT_DA:
            /* IPv6 Ucast */
            if ((!IS_BIT_SET(fib_key_type, 0)) && fib_engine_lookup_ctl.ipv6_nat_da_lookup_en)
            {
                /* IPv6 DA + PORT */
                hash1_prefix_length = 144;
                hash1_aging_en = TRUE;
            }

            if (!p_cam_lookup_result->valid)
            {
                if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV6_UC))
                {
                    hash2_prefix_length = 32;
                }
            }
            else
            {
                sal_memcpy(p_lpm_hash2_info, p_lpm_cam_info, sizeof(lpm_info_t));
                hash2_prefix_length = *((uint16*)(p_lpm_cam_info->extra));
            }

            /* pop hash3 result */

            if ((!IS_BIT_SET(fib_key_type, 0))&& fib_engine_lookup_ctl.ipv6_nat_da_lookup_en)
            {
                /* pop tcam1 result */
            }

            if (!p_cam_lookup_result->valid)
            {
               /* pop tcam2 result */
            }

            /* pop tcam3 result */
            break;

        case FIB_KEY_TYPE_IPV6_MCAST:
            /* IPv6 Mcast first hash lookup. hash1 is (S, G) */
            hash1_prefix_length = 128;
            hash1_aging_en = TRUE;

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV6_MC))
            {
                hash2_prefix_length = 256;
                hash2_aging_en = TRUE;
            }

            /* pop tcam result */
            break;

        case FIB_KEY_TYPE_IPV4_RPF:
            /* pop hash1 result */
            hash1_prefix_length = 16;

            if (!fib_engine_lookup_ctl.lpm_ipv4_pipeline3_en)
            {
                hash1_prefix_length = 16;
            }

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV4_UC))
            {
                hash2_prefix_length = 8;
            }

            /* pop tcam 1 result */
            break;

        case FIB_KEY_TYPE_IPV6_RPF:

            if (!p_cam_lookup_result->valid)
            {
                if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV6_UC))
                {
                    hash1_prefix_length = 32;
                }
            }
            else
            {
                sal_memcpy(p_lpm_hash2_info, p_lpm_cam_info, sizeof(lpm_info_t));
                hash2_prefix_length = *((uint16*)(p_lpm_cam_info->extra));
            }

            if (!p_cam_lookup_result->valid)
            {
                /* pop tcam 1 result */
                ;
            }
            break;

        case FIB_KEY_TYPE_IPV4_NAT_SA:
            /* pop hash1 result */
            hash1_prefix_length = 48;
            hash1_aging_en = TRUE;

            /* pop hash2 result */
            hash2_prefix_length = 32;
            hash2_aging_en = TRUE;

            /* pop tcam1 result */
            break;

         case FIB_KEY_TYPE_IPV6_NAT_SA:
            /* pop hash1 result */
            hash1_prefix_length = 144;
            hash1_aging_en = TRUE;

            /* pop hash2 result */
            hash2_prefix_length = 128;
            hash2_aging_en = TRUE;

            /* pop tcam1 result */
            break;

        case FIB_KEY_TYPE_MAC_IPV4_MULTICAST:
            /* MAC IPv4 Mcast */
            hash1_prefix_length = 64;
            hash1_aging_en = TRUE;

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV4_MC))
            {
                hash2_prefix_length = 32;
                hash2_aging_en = TRUE;
            }

            /* pop tcam1 result */
            break;

        case FIB_KEY_TYPE_MAC_IPV6_MULTICAST:
        default:
            /* MAC IPv6 Mcast */
            hash1_prefix_length = 128;
            hash1_aging_en = TRUE;

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV6_MC))
            {
                hash2_prefix_length = 128;
                hash2_aging_en = TRUE;
            }
            break;
    }

    p_hash1_lookup_result->valid = FALSE;
    p_hash2_lookup_result->valid = FALSE;
    p_hash3_lookup_result->valid = FALSE;

    if ((INVALID_NEXTHOP != p_lpm_hash1_info->nexthop.value) || (INVALID_POINTER != p_lpm_hash1_info->pointer.value))
    {
        p_hash1_lookup_result->valid = TRUE;
    }

    if ((INVALID_NEXTHOP != p_lpm_hash2_info->nexthop.value) || (INVALID_POINTER != p_lpm_hash2_info->pointer.value))
    {
        p_hash2_lookup_result->valid = TRUE;
    }

    if ((FIB_KEY_TYPE_IPV6_UCAST == fib_key_type) || (FIB_KEY_TYPE_IPV6_NAT_DA == fib_key_type))
    {
        if (INVALID_NEXTHOP != p_lpm_hash3_info->nexthop.value)
        {
            ipv6_mid = p_lpm_hash3_info->nexthop.value;
        }
        else if (p_tcam3_lookup_result->valid)
        {
            ipv6_mid = lpm_tcam_ad_mem3.nexthop;
        }
        else
        {
            ipv6_mid = INVALID_NEXTHOP;
        }

        p_hash3_lookup_result->valid = FALSE;
        p_tcam3_lookup_result->valid = FALSE;
    }
    else
    {
        if ((INVALID_NEXTHOP != p_lpm_hash3_info->nexthop.value) || (INVALID_POINTER != p_lpm_hash3_info->pointer.value))
        {
            p_hash3_lookup_result->valid = TRUE;
        }
    }

    /* L2/L3 Ipv6 Mcast */
    if ((FIB_KEY_TYPE_IPV6_MCAST == fib_key_type) || (FIB_KEY_TYPE_MAC_IPV6_MULTICAST == fib_key_type))
    {
        /* nexthop */
        if (p_hash2_lookup_result->valid)
        {
            /* IPv6 (*,G) hash hitted */
            ipv6_mcast128_result = p_hash2_lookup_result->key_index + 0x100;
            ipv6_mcast128_nexthop = p_lpm_hash2_info->nexthop.value;
        }
        else if (p_tcam1_lookup_result->valid)
        {
            ipv6_mcast128_result = p_tcam1_lookup_result->key_index & 0xFF;
            ipv6_mcast128_nexthop = lpm_tcam_ad_mem1.nexthop;
        }
        else
        {
            ipv6_mcast128_nexthop = INVALID_NEXTHOP;
        }

        /* pointer */
        if (p_hash1_lookup_result->valid)
        {
            /* IPv6 (S, G) first hash hitted */
            p_step1_lookup_result->key_index = ipv6_mcast128_result;
            p_step1_lpm_info->pointer.value = p_lpm_hash1_info->nexthop.value & POINTER_OFFSET_MASK;
            p_step1_lpm_info->nexthop.value = ipv6_mcast128_nexthop;
            p_step1_lpm_info->index_mask = 0;
            p_lpm_extra_info->aging_en = TRUE;
            p_lpm_extra_info->ipv6_mid = ipv6_mid;
        }
        else if (p_tcam1_lookup_result->valid)
        {
            p_step1_lookup_result->key_index = ipv6_mcast128_result;
            p_step1_lpm_info->pointer.value = lpm_tcam_ad_mem1.pointer;
            p_step1_lpm_info->nexthop.value = ipv6_mcast128_nexthop;
            p_step1_lpm_info->index_mask = 0;
            p_lpm_extra_info->aging_en = TRUE;
            p_lpm_extra_info->ipv6_mid = ipv6_mid;
        }
        else
        {
            p_step1_lookup_result->key_index = ipv6_mcast128_result;
            p_step1_lpm_info->pointer.value = INVALID_POINTER;
            p_step1_lpm_info->nexthop.value = ipv6_mcast128_nexthop;
            p_step1_lpm_info->index_mask = 0;
            p_lpm_extra_info->aging_en = TRUE;
            p_lpm_extra_info->ipv6_mid = ipv6_mid;
        }
    }
    else if (p_hash1_lookup_result->valid && (!p_tcam1_lookup_result->valid
        || (hash1_prefix_length >= lpm_tcam_ad_mem1.tcam_prefix_length))
        && (!p_tcam2_lookup_result->valid
        || (hash1_prefix_length >= lpm_tcam_ad_mem2.tcam_prefix_length)))
    {
        p_step1_lookup_result->key_index = p_hash1_lookup_result->key_index + 0x100;
        p_step1_lpm_info->pointer.value = p_lpm_hash1_info->pointer.value;
        p_step1_lpm_info->nexthop.value = p_lpm_hash1_info->nexthop.value;
        p_step1_lpm_info->index_mask = p_lpm_hash1_info->index_mask;
        p_lpm_extra_info->aging_en = hash1_aging_en;
        p_lpm_extra_info->ipv6_mid = ipv6_mid;
    }
    else if (p_hash2_lookup_result->valid && (!p_tcam1_lookup_result->valid
        || (hash2_prefix_length >= lpm_tcam_ad_mem1.tcam_prefix_length))
        && (!p_tcam2_lookup_result->valid
        || (hash2_prefix_length >= lpm_tcam_ad_mem2.tcam_prefix_length)))
    {
        p_step1_lookup_result->key_index = p_hash2_lookup_result->key_index + 0x100;
        p_step1_lpm_info->pointer.value = p_lpm_hash2_info->pointer.value;
        p_step1_lpm_info->nexthop.value = p_lpm_hash2_info->nexthop.value;
        p_step1_lpm_info->index_mask = p_lpm_hash2_info->index_mask;
        p_lpm_extra_info->aging_en = hash2_aging_en;
        p_lpm_extra_info->ipv6_mid = ipv6_mid;
    }
    else if (p_hash3_lookup_result->valid && (!p_tcam1_lookup_result->valid
        || (hash3_prefix_length >= lpm_tcam_ad_mem1.tcam_prefix_length))
        && (!p_tcam2_lookup_result->valid
        || (hash3_prefix_length >= lpm_tcam_ad_mem2.tcam_prefix_length)))
    {
        p_step1_lookup_result->key_index = p_hash3_lookup_result->key_index + 0x100;
        p_step1_lpm_info->pointer.value = p_lpm_hash3_info->pointer.value;
        p_step1_lpm_info->nexthop.value = p_lpm_hash3_info->nexthop.value;
        p_step1_lpm_info->index_mask = p_lpm_hash3_info->index_mask;
        p_lpm_extra_info->aging_en = hash3_aging_en;
        p_lpm_extra_info->ipv6_mid = ipv6_mid;
    }
    else if (p_tcam1_lookup_result->valid && (!p_tcam2_lookup_result->valid
             || (lpm_tcam_ad_mem1.tcam_prefix_length >= lpm_tcam_ad_mem2.tcam_prefix_length)))
    {
        p_step1_lookup_result->key_index = p_tcam1_lookup_result->key_index;
        p_step1_lpm_info->pointer.value = lpm_tcam_ad_mem1.pointer;
        p_step1_lpm_info->nexthop.value = lpm_tcam_ad_mem1.nexthop;
        p_step1_lpm_info->index_mask = lpm_tcam_ad_mem1.index_mask;
        p_lpm_extra_info->aging_en = tcam1_aging_en;
        p_lpm_extra_info->ipv6_mid = ipv6_mid;
    }
    else if (p_tcam2_lookup_result->valid)
    {
        p_step1_lookup_result->key_index = p_tcam2_lookup_result->key_index;
        p_step1_lpm_info->pointer.value = lpm_tcam_ad_mem2.pointer;
        p_step1_lpm_info->nexthop.value = lpm_tcam_ad_mem2.nexthop;
        p_step1_lpm_info->index_mask = lpm_tcam_ad_mem2.index_mask;
        p_lpm_extra_info->aging_en = tcam2_aging_en;
        p_lpm_extra_info->ipv6_mid = ipv6_mid;
    }
    else
    {
        p_step1_lookup_result->key_index = 0xFFFF;
        p_step1_lpm_info->pointer.value = INVALID_POINTER;
        p_step1_lpm_info->nexthop.value = INVALID_NEXTHOP;
    }

    return DRV_E_NONE;
}

static int32
_cm_com_lpm_engine_hash_step1_lookup(uint8 chip_id,
                                     fib_key_t* p_fib_key,
                                     fib_key_type_t fib_key_type,
                                     lookup_result_t* p_hash1_lookup_result,
                                     lookup_result_t* p_hash2_lookup_result,
                                     lookup_result_t* p_hash3_lookup_result,
                                     lookup_result_t* p_cam_lookup_result,
                                     tcam_lookup_result_t* p_tcam1_lookup_result,
                                     tcam_lookup_result_t* p_tcam2_lookup_result,
                                     tcam_lookup_result_t* p_tcam3_lookup_result)
{
    uint8 lpm_hash_type = LPM_HASH_TYPE_INVALID;
    uint8 l4_port_type = 0;
    uint32 cmd = 0;
    ds_lpm_tcam80_key_t ds_lpm_tcam80_key;
    ds_lpm_tcam160_key_t ds_lpm_tcam160_key;
    tcam_lookup_info_t tcam_lookup_info;
    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;

    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl));
    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_ctl));

    if (L4_TYPE_TCP == p_fib_key->layer4_type)
    {
        l4_port_type = 3;
    }
    else if (L4_TYPE_UDP == p_fib_key->layer4_type)
    {
        l4_port_type = 2;
    }
    else
    {
        l4_port_type = 0;
    }

    switch (fib_key_type)
    {
        case FIB_KEY_TYPE_IPV4_UCAST:
        case FIB_KEY_TYPE_IPV4_NAT_DA:
            /* IPv4 Ucast (LPM hash 1) */
            sal_memset(&ds_lpm_tcam80_key, 0, sizeof(ds_lpm_tcam80_key_t));
            ds_lpm_tcam80_key.ip = p_fib_key->key.ipv4_ucast.ip_da;
            ds_lpm_tcam80_key.vrf_id = p_fib_key->id.vrf_id;
            ds_lpm_tcam80_key.layer4_port = ((l4_port_type & 0x3) << 19) | p_fib_key->key.ipv4_ucast.l4_dest_port;
            ds_lpm_tcam80_key.table_id = 0;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
            tcam_lookup_info.chip_id = chip_id;
            tcam_lookup_info.tcam_key = &ds_lpm_tcam80_key;
            tcam_lookup_info.tcam_key_type = 0;

            LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam1_lookup_result);
            if ((!IS_BIT_SET(fib_key_type, 0)) && fib_engine_lookup_ctl.ipv4_nat_da_lookup_en)
            {
                lpm_hash_type = LPM_HASH_TYPE_IPV4_NAT_DA_PORT;
                /* NAT DA + PORT */
                DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                           fib_key_type,
                                                                           lpm_hash_type,
                                                                           p_fib_key,
                                                                           p_hash1_lookup_result));
            }

            if (!fib_engine_lookup_ctl.lpm_ipv4_pipeline3_en)
            {
                /* ipDa[23:16] in pipeline lookup */
                lpm_hash_type = LPM_HASH_TYPE_IPV4_16;
                DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                           fib_key_type,
                                                                           lpm_hash_type,
                                                                           p_fib_key,
                                                                           p_hash2_lookup_result));
            }

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV4_UC))
            {
                /* IPv4 8*/
                lpm_hash_type = LPM_HASH_TYPE_IPV4_8;
                DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                           fib_key_type,
                                                                           lpm_hash_type,
                                                                           p_fib_key,
                                                                           p_hash3_lookup_result));
            }
            break;

        case FIB_KEY_TYPE_IPV4_MCAST:
            /* IPv4 Mcast (LPM hash 1), No NAT DA PORT lookup for multicast */
            sal_memset(&ds_lpm_tcam80_key, 0, sizeof(ds_lpm_tcam80_key_t));
            ds_lpm_tcam80_key.ip = p_fib_key->key.ipv4_mcast.ip_da;
            ds_lpm_tcam80_key.layer4_port = p_fib_key->key.ipv4_mcast.ip_sa;
            ds_lpm_tcam80_key.vrf_id = p_fib_key->id.vrf_id;
            ds_lpm_tcam80_key.table_id = 1;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
            tcam_lookup_info.chip_id = chip_id;
            tcam_lookup_info.tcam_key_type = 0;
            tcam_lookup_info.tcam_key = &ds_lpm_tcam80_key;

            LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam1_lookup_result);
            lpm_hash_type = LPM_HASH_TYPE_IPV4_SG;
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                       fib_key_type,
                                                                       lpm_hash_type,
                                                                       p_fib_key,
                                                                       p_hash1_lookup_result));

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV4_MC))
            {
                lpm_hash_type = LPM_HASH_TYPE_IPV4_XG;
                DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                           fib_key_type,
                                                                           lpm_hash_type,
                                                                           p_fib_key,
                                                                           p_hash2_lookup_result));
            }
            break;

        case FIB_KEY_TYPE_IPV6_UCAST:
        case FIB_KEY_TYPE_IPV6_NAT_DA:
            if ((!IS_BIT_SET(fib_key_type, 0)) && fib_engine_lookup_ctl.ipv6_nat_da_lookup_en)
            {
                /* IPv6 Ucast (LPM hash 1), need to add IPv6 24 Key ??? */
                sal_memset(&ds_lpm_tcam160_key, 0, sizeof(ds_lpm_tcam160_key_t));
                ds_lpm_tcam160_key.ip31_0 = p_fib_key->key.ipv6_ucast.ip_da31_0;
                ds_lpm_tcam160_key.ip63_32 = p_fib_key->key.ipv6_ucast.ip_da63_32;
                ds_lpm_tcam160_key.ip95_64 = p_fib_key->key.ipv6_ucast.ip_da95_64;
                ds_lpm_tcam160_key.ip127_96 = p_fib_key->key.ipv6_ucast.ip_da127_96;
                ds_lpm_tcam160_key.ipv6_lookup_type = 1;
                ds_lpm_tcam160_key.vrf_id = p_fib_key->id.vrf_id & 0xFF;
                ds_lpm_tcam160_key.layer4_port1_0 = p_fib_key->key.ipv6_ucast.l4_dest_port & 0x3;
                ds_lpm_tcam160_key.layer4_port15_2 = (p_fib_key->key.ipv6_ucast.l4_dest_port >> 2) & 0x3FFF;
                ds_lpm_tcam160_key.table_id0 = 2;
                ds_lpm_tcam160_key.table_id1 = 2;
                ds_lpm_tcam160_key.l4_port_type = l4_port_type;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
                tcam_lookup_info.chip_id = chip_id;
                tcam_lookup_info.tcam_key_type = 1;
                tcam_lookup_info.tcam_key = &ds_lpm_tcam160_key;

                LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam1_lookup_result);
            }

            lpm_hash_type = LPM_HASH_TYPE_IPV6_NAT_DA_PORT;
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                       fib_key_type,
                                                                       lpm_hash_type,
                                                                       p_fib_key,
                                                                       p_hash1_lookup_result));

            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_cam_lookup(chip_id, fib_key_type, p_fib_key, p_cam_lookup_result));

            if (!p_cam_lookup_result->valid)
            {
                sal_memset(&ds_lpm_tcam80_key, 0, sizeof(ds_lpm_tcam80_key_t));
                ds_lpm_tcam80_key.ip = p_fib_key->key.ipv6_ucast.ip_da127_96;
                ds_lpm_tcam80_key.layer4_port = 4 << 16;
                ds_lpm_tcam80_key.table_id = 0;
                ds_lpm_tcam80_key.vrf_id = p_fib_key->id.vrf_id;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
                tcam_lookup_info.chip_id = chip_id;
                tcam_lookup_info.tcam_key_type = 0;
                tcam_lookup_info.tcam_key = &ds_lpm_tcam80_key;

                LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam2_lookup_result);

                if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV6_UC))
                {
                    lpm_hash_type = LPM_HASH_TYPE_IPV6_HIGH32;
                    DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                               fib_key_type,
                                                                               lpm_hash_type,
                                                                               p_fib_key,
                                                                               p_hash2_lookup_result));
                }
            }

            /* IPv6 32 Mid */
            sal_memset(&ds_lpm_tcam80_key, 0, sizeof(ds_lpm_tcam80_key_t));
            ds_lpm_tcam80_key.ip = p_fib_key->key.ipv6_ucast.ip_da63_32;
            ds_lpm_tcam80_key.layer4_port = 0x60000;
            ds_lpm_tcam80_key.table_id = 0;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
            tcam_lookup_info.chip_id = chip_id;
            tcam_lookup_info.tcam_key_type = 0;
            tcam_lookup_info.tcam_key = &ds_lpm_tcam80_key;

            LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam3_lookup_result);

            lpm_hash_type = LPM_HASH_TYPE_IPV6_MID32;
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                       fib_key_type,
                                                                       lpm_hash_type,
                                                                       p_fib_key,
                                                                       p_hash3_lookup_result));
            break;

        case FIB_KEY_TYPE_IPV6_MCAST:
            /* IPv6 Mcast, No NAT DA PORT lookup for multicast */
            sal_memset(&ds_lpm_tcam160_key, 0, sizeof(ds_lpm_tcam160_key_t));
            ds_lpm_tcam160_key.ip31_0 = p_fib_key->key.ipv6_mcast.ip_da31_0;
            ds_lpm_tcam160_key.ip63_32 = p_fib_key->key.ipv6_mcast.ip_da63_32;
            ds_lpm_tcam160_key.ip95_64 = p_fib_key->key.ipv6_mcast.ip_da95_64;
            ds_lpm_tcam160_key.ip127_96 = p_fib_key->key.ipv6_mcast.ip_da127_96;
            ds_lpm_tcam160_key.vrf_id = p_fib_key->id.vrf_id & 0xFF;
            /* layer4_port[15] = 0 */
            CLEAR_BIT(ds_lpm_tcam160_key.layer4_port15_2, 13);
            ds_lpm_tcam160_key.ipv6_lookup_type = 2;
            ds_lpm_tcam160_key.table_id0 = 2;
            ds_lpm_tcam160_key.table_id1 = 2;

            /* for both (*, G) and (S, G) */
            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
            tcam_lookup_info.chip_id = chip_id;
            tcam_lookup_info.tcam_key_type = 1;
            tcam_lookup_info.tcam_key = &ds_lpm_tcam160_key;

            LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam1_lookup_result);
            lpm_hash_type = LPM_HASH_TYPE_IPV6_SG0;

            /* IPv6 (S, G) */
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                       fib_key_type,
                                                                       lpm_hash_type,
                                                                       p_fib_key,
                                                                       p_hash1_lookup_result));

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV6_MC))
            {
                lpm_hash_type = LPM_HASH_TYPE_IPV6_XG;
                /* IPv6 (X, G) */
                DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                           fib_key_type,
                                                                           lpm_hash_type,
                                                                           p_fib_key,
                                                                           p_hash2_lookup_result));
            }
            break;

        case FIB_KEY_TYPE_IPV4_RPF:
            /* IPv4 RPF (LPM hash 1)*/
            sal_memset(&ds_lpm_tcam80_key, 0, sizeof(ds_lpm_tcam80_key_t));
            ds_lpm_tcam80_key.ip = p_fib_key->key.ipv4_rpf.ip_sa;
            ds_lpm_tcam80_key.vrf_id = p_fib_key->id.vrf_id;
            /* check l4_port_type with jiping */
            ds_lpm_tcam80_key.layer4_port = 0;
            ds_lpm_tcam80_key.table_id = 0;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
            tcam_lookup_info.chip_id = chip_id;
            tcam_lookup_info.tcam_key_type = 0;
            tcam_lookup_info.tcam_key = &ds_lpm_tcam80_key;

            LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam1_lookup_result);

            if (!fib_engine_lookup_ctl.lpm_ipv4_pipeline3_en)
            {
                /* ipSa[23:16] in pipeline lookup */
                lpm_hash_type = LPM_HASH_TYPE_IPV4_16;
                DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id,
                                                                           fib_key_type,
                                                                           lpm_hash_type,
                                                                           p_fib_key,
                                                                           p_hash1_lookup_result));
            }

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV4_UC))
            {
                lpm_hash_type = LPM_HASH_TYPE_IPV4_8;

                /* IPv4 RPF 8*/
                _cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type, p_fib_key, p_hash2_lookup_result);
            }
            break;

        case FIB_KEY_TYPE_IPV6_RPF:
            /* IPv6 RPF (LPM hash 1) */
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_cam_lookup(chip_id, fib_key_type, p_fib_key, p_cam_lookup_result));

            if (!p_cam_lookup_result->valid)
            {
                sal_memset(&ds_lpm_tcam80_key, 0, sizeof(ds_lpm_tcam80_key_t));
                ds_lpm_tcam80_key.ip = p_fib_key->key.ipv6_rpf.ip_sa127_96;
                ds_lpm_tcam80_key.vrf_id = p_fib_key->id.vrf_id;
                SET_BIT(ds_lpm_tcam80_key.layer4_port, 18);
                ds_lpm_tcam80_key.table_id = 0;

                sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
                tcam_lookup_info.chip_id = chip_id;
                tcam_lookup_info.tcam_key_type = 0;
                tcam_lookup_info.tcam_key = &ds_lpm_tcam80_key;

                LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam1_lookup_result);

                if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV6_UC))
                {
                    lpm_hash_type = LPM_HASH_TYPE_IPV6_HIGH32;
                    DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                               p_fib_key, p_hash1_lookup_result));
                }
            }
            break;

        case FIB_KEY_TYPE_IPV4_NAT_SA:
            /* IPv4 SA NAT (LPM hash 1) */
            sal_memset(&ds_lpm_tcam80_key, 0, sizeof(ds_lpm_tcam80_key_t));
            ds_lpm_tcam80_key.ip = p_fib_key->key.ipv4_nat_sa_port.ip_sa;
            ds_lpm_tcam80_key.vrf_id = p_fib_key->id.vrf_id;
            ds_lpm_tcam80_key.layer4_port = ((l4_port_type & 0x3) << 19) | (3 << 16)
                                            | p_fib_key->key.ipv4_nat_sa_port.l4_source_port;
            ds_lpm_tcam80_key.table_id = 0;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
            tcam_lookup_info.chip_id = chip_id;
            tcam_lookup_info.tcam_key_type = 0;
            tcam_lookup_info.tcam_key = &ds_lpm_tcam80_key;

            LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam1_lookup_result);

            lpm_hash_type = LPM_HASH_TYPE_IPV4_NAT_SA_PORT;
            /* IPv4 NAT SA PORT */
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                       p_fib_key, p_hash1_lookup_result));

            lpm_hash_type = LPM_HASH_TYPE_IPV4_NAT_SA;
            /* IPv4 NAT SA */
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                       p_fib_key, p_hash2_lookup_result));
            break;

         case FIB_KEY_TYPE_IPV6_NAT_SA:
            sal_memset(&ds_lpm_tcam160_key, 0, sizeof(ds_lpm_tcam160_key_t));
            /* IPv6 SA NAT (LPM hash 1) */
            ds_lpm_tcam160_key.ip31_0 = p_fib_key->key.ipv6_nat_sa_port.ip_sa31_0;
            ds_lpm_tcam160_key.ip63_32 = p_fib_key->key.ipv6_nat_sa_port.ip_sa63_32;
            ds_lpm_tcam160_key.ip95_64 = p_fib_key->key.ipv6_nat_sa_port.ip_sa95_64;
            ds_lpm_tcam160_key.ip127_96 = p_fib_key->key.ipv6_nat_sa_port.ip_sa127_96;
            ds_lpm_tcam160_key.vrf_id = p_fib_key->id.vrf_id;
            ds_lpm_tcam160_key.layer4_port1_0 = p_fib_key->key.ipv6_nat_sa_port.l4_source_port & 0x3;
            ds_lpm_tcam160_key.layer4_port15_2 = (p_fib_key->key.ipv6_nat_sa_port.l4_source_port >> 2) & 0x3FFF;
            ds_lpm_tcam160_key.ipv6_lookup_type = 0;
            ds_lpm_tcam160_key.table_id0 = 2;
            ds_lpm_tcam160_key.table_id1 = 2;
            ds_lpm_tcam160_key.l4_port_type = l4_port_type;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
            tcam_lookup_info.chip_id = chip_id;
            tcam_lookup_info.tcam_key_type = 1;
            tcam_lookup_info.tcam_key = &ds_lpm_tcam160_key;

            LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam1_lookup_result);

            lpm_hash_type = LPM_HASH_TYPE_IPV6_NAT_SA_PORT;
            /* IPv6 NAT SA PORT */
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                       p_fib_key, p_hash1_lookup_result));

            lpm_hash_type = LPM_HASH_TYPE_IPV6_NAT_SA;
            /* IPv6 NAT SA */
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                       p_fib_key, p_hash2_lookup_result));
            break;

        case FIB_KEY_TYPE_MAC_IPV4_MULTICAST:
            sal_memset(&ds_lpm_tcam80_key, 0, sizeof(ds_lpm_tcam80_key_t));
            /* MAC IPv4 Mcast (LPM hash 1) */
            /* ipDa[31] indicates L2 */
            ds_lpm_tcam80_key.ip = p_fib_key->key.mac_ipv4_mcast.ip_da;
            ds_lpm_tcam80_key.layer4_port = p_fib_key->key.mac_ipv4_mcast.ip_sa;
            ds_lpm_tcam80_key.vrf_id = p_fib_key->id.vrf_id;
            ds_lpm_tcam80_key.table_id = 3;

            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
            tcam_lookup_info.chip_id = chip_id;
            tcam_lookup_info.tcam_key_type = 0;
            tcam_lookup_info.tcam_key = &ds_lpm_tcam80_key;

            LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam1_lookup_result);

            lpm_hash_type = LPM_HASH_TYPE_IPV4_SG;
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                       p_fib_key, p_hash1_lookup_result));

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV4_MC))
            {
                lpm_hash_type = LPM_HASH_TYPE_IPV4_XG;
                DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                           p_fib_key, p_hash2_lookup_result));
            }

            break;

        case FIB_KEY_TYPE_MAC_IPV6_MULTICAST:
            sal_memset(&ds_lpm_tcam160_key, 0, sizeof(ds_lpm_tcam160_key_t));
            /* MAC IPv6 Mcast (LPM hash 1) */
            ds_lpm_tcam160_key.ip31_0 = p_fib_key->key.mac_ipv6_mcast.ip_da31_0;
            ds_lpm_tcam160_key.ip63_32 = p_fib_key->key.mac_ipv6_mcast.ip_da63_32;
            ds_lpm_tcam160_key.ip95_64 = p_fib_key->key.mac_ipv6_mcast.ip_da95_64;
            ds_lpm_tcam160_key.ip127_96 = p_fib_key->key.mac_ipv6_mcast.ip_da127_96;
            SET_BIT(ds_lpm_tcam160_key.layer4_port15_2, 13);
            ds_lpm_tcam160_key.ipv6_lookup_type = 2;
            ds_lpm_tcam160_key.table_id0 = 2;
            ds_lpm_tcam160_key.table_id1 = 2;
            ds_lpm_tcam160_key.vrf_id = p_fib_key->id.vrf_id;
            sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
            tcam_lookup_info.chip_id = chip_id;
            tcam_lookup_info.tcam_key_type = 1;
            tcam_lookup_info.tcam_key = &ds_lpm_tcam160_key;

            LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam1_lookup_result);

            lpm_hash_type = LPM_HASH_TYPE_IPV6_SG0;
            DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                       p_fib_key, p_hash1_lookup_result));

            if (!IS_BIT_SET(fib_engine_lookup_ctl.lpm_hash_mode, LPM_HASH_MODE_IPV6_MC))
            {
                lpm_hash_type = LPM_HASH_TYPE_IPV6_XG;
                DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                           p_fib_key, p_hash2_lookup_result));
            }
            break;

        default:
            break;
    }

    return DRV_E_NONE;
}

static int32
_cm_com_lpm_engine_hash1_request(uint8 chip_id,
                                 fib_key_t* p_fib_key,
                                 fib_key_type_t fib_key_type,
                                 lookup_result_t* p_step1_lookup_result)
{
    uint16 cam_prefix_length = 0;

    lookup_result_t hash_lookup_result1;
    lookup_result_t hash_lookup_result2;
    lookup_result_t hash_lookup_result3;
    lookup_result_t cam_lookup_result;

    lpm_info_t lpm_lookup_hash1_info;
    lpm_info_t lpm_lookup_hash2_info;
    lpm_info_t lpm_lookup_hash3_info;
    lpm_info_t lpm_lookup_cam_info;

    tcam_lookup_result_t tcam_lookup_result1;
    tcam_lookup_result_t tcam_lookup_result2;
    tcam_lookup_result_t tcam_lookup_result3;

    sal_memset(&hash_lookup_result1, 0, sizeof(lookup_result_t));
    sal_memset(&hash_lookup_result2, 0, sizeof(lookup_result_t));
    sal_memset(&hash_lookup_result3, 0, sizeof(lookup_result_t));
    sal_memset(&cam_lookup_result, 0, sizeof(lookup_result_t));

    sal_memset(&lpm_lookup_hash1_info, 0, sizeof(lpm_info_t));
    sal_memset(&lpm_lookup_hash2_info, 0, sizeof(lpm_info_t));
    sal_memset(&lpm_lookup_hash3_info, 0, sizeof(lpm_info_t));
    sal_memset(&lpm_lookup_cam_info, 0, sizeof(lpm_info_t));

    lpm_lookup_hash1_info.nexthop.value = INVALID_NEXTHOP;
    lpm_lookup_hash1_info.pointer.value = INVALID_POINTER;
    lpm_lookup_hash2_info.nexthop.value = INVALID_NEXTHOP;
    lpm_lookup_hash2_info.pointer.value = INVALID_POINTER;
    lpm_lookup_hash3_info.nexthop.value = INVALID_NEXTHOP;
    lpm_lookup_hash3_info.pointer.value = INVALID_POINTER;
    lpm_lookup_cam_info.nexthop.value = INVALID_NEXTHOP;
    lpm_lookup_cam_info.pointer.value = INVALID_POINTER;

    /* All lpm_info's invalid value set in driver LPM hash lookup */
    hash_lookup_result1.extra = &lpm_lookup_hash1_info;
    hash_lookup_result2.extra = &lpm_lookup_hash2_info;
    hash_lookup_result3.extra = &lpm_lookup_hash3_info;
    cam_lookup_result.extra = &lpm_lookup_cam_info;

    lpm_lookup_cam_info.extra = &cam_prefix_length;

    sal_memset(&tcam_lookup_result1, 0, sizeof(tcam_lookup_result_t));
    sal_memset(&tcam_lookup_result2, 0, sizeof(tcam_lookup_result_t));
    sal_memset(&tcam_lookup_result3, 0, sizeof(tcam_lookup_result_t));

    DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_hash_step1_lookup(chip_id,
                                                             p_fib_key,
                                                             fib_key_type,
                                                             &hash_lookup_result1,
                                                             &hash_lookup_result2,
                                                             &hash_lookup_result3,
                                                             &cam_lookup_result,
                                                             &tcam_lookup_result1,
                                                             &tcam_lookup_result2,
                                                             &tcam_lookup_result3));

    DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_hash_step1_result(chip_id,
                                                             fib_key_type,
                                                             &hash_lookup_result1,
                                                             &hash_lookup_result2,
                                                             &hash_lookup_result3,
                                                             &cam_lookup_result,
                                                             &tcam_lookup_result1,
                                                             &tcam_lookup_result2,
                                                             &tcam_lookup_result3,
                                                             p_step1_lookup_result));
    return DRV_E_NONE;
}

static int32
_cm_com_lpm_engine_hash_step2_result(uint8 chip_id,
                                     fib_key_type_t  fib_key_type,
                                     fib_key_t* p_fib_key,
                                     lookup_result_t* p_step_x_lookup_result,
                                     lookup_result_t * p_hash_lookup_result,
                                     tcam_lookup_result_t* p_tcam_lookup_result)
{
    uint32 cmd = 0;
    uint16 hash_prefix_length = 0;
    lpm_info_t* p_step2_lpm_info = (lpm_info_t*)p_step_x_lookup_result[LPM_HASH_LOOKUP_STEP2].extra;
    lpm_info_t* p_step2_hash_lpm_info = (lpm_info_t*)p_hash_lookup_result->extra;
    lpm_tcam_ad_mem_t lpm_tcam_ad_mem;

    if ((FIB_KEY_TYPE_IPV6_UCAST == fib_key_type) || (FIB_KEY_TYPE_IPV6_NAT_DA == fib_key_type))
    {
        hash_prefix_length = 64;
        /* pop hash result */
        /* pop tcam result */
    }
    else if ((FIB_KEY_TYPE_IPV6_MCAST == fib_key_type) || (FIB_KEY_TYPE_MAC_IPV6_MULTICAST == fib_key_type))
    {
        hash_prefix_length = 256;
        /* pop hash result */
        /* pop tcam result */
    }

    if (p_tcam_lookup_result->valid)
    {
        sal_memset(&lpm_tcam_ad_mem, 0, sizeof(lpm_tcam_ad_mem));
        cmd = DRV_IOR(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, p_tcam_lookup_result->key_index, cmd, &lpm_tcam_ad_mem));
    }

    if ((INVALID_NEXTHOP != p_step2_hash_lpm_info->nexthop.value)
        && (!p_tcam_lookup_result->valid || (hash_prefix_length >= lpm_tcam_ad_mem.tcam_prefix_length)))
    {
        p_step_x_lookup_result[LPM_HASH_LOOKUP_STEP2].key_index = p_hash_lookup_result->key_index + 0x100;
        p_step2_lpm_info->nexthop.value = p_step2_hash_lpm_info->nexthop.value;
    }
    else if (p_tcam_lookup_result->valid)
    {
        p_step_x_lookup_result[LPM_HASH_LOOKUP_STEP2].key_index = p_tcam_lookup_result->key_index;
        p_step2_lpm_info->nexthop.value = lpm_tcam_ad_mem.nexthop;
    }
    else
    {
        p_step_x_lookup_result[LPM_HASH_LOOKUP_STEP2].key_index = 0;
        p_step2_lpm_info->nexthop.value = INVALID_NEXTHOP;
    }

    return DRV_E_NONE;
}

static int32
_cm_com_lpm_engine_hash_step2_lookup(uint8 chip_id,
                                     fib_key_t* p_fib_key,
                                     fib_key_type_t fib_key_type,
                                     lookup_result_t* p_step_x_lookup_result,
                                     lookup_result_t* p_hash_lookup_result,
                                     tcam_lookup_result_t* p_tcam_lookup_result)
{
    lpm_info_t* p_lpm_info = (lpm_info_t*)p_step_x_lookup_result[LPM_HASH_LOOKUP_STEP1].extra;
    ds_lpm_tcam80_key_t ds_lpm_tcam80_key;
    ds_lpm_tcam160_key_t ds_lpm_tcam160_key;
    tcam_lookup_info_t tcam_lookup_info;
    uint32 lpm_hash_type = LPM_HASH_TYPE_INVALID;

    sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info_t));
    tcam_lookup_info.chip_id = chip_id;

    if ((FIB_KEY_TYPE_IPV6_UCAST == fib_key_type) || (FIB_KEY_TYPE_IPV6_NAT_DA == fib_key_type))
    {
        /* unicast IPv6 lowest bits hash lookup */
        ds_lpm_tcam80_key.layer4_port = (7 << 16) | (((lpm_extra_info_t*)(p_lpm_info->extra))->ipv6_mid & 0x1FFF);
        ds_lpm_tcam80_key.ip = p_fib_key->key.ipv6_ucast.ip_da31_0;
        ds_lpm_tcam80_key.vrf_id = p_lpm_info->pointer.value & 0x3FFF;
        /* Ipv6 64 Key */
        ds_lpm_tcam80_key.table_id = 0;

        tcam_lookup_info.tcam_key_type = 0;
        tcam_lookup_info.tcam_key = &ds_lpm_tcam80_key;
        LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam_lookup_result);

        p_fib_key->key.ipv6_ucast.pointer = p_lpm_info->pointer.value;
        p_fib_key->key.ipv6_ucast.ipv6_mid = ((lpm_extra_info_t*)(p_lpm_info->extra))->ipv6_mid;
        lpm_hash_type = LPM_HASH_TYPE_IPV6_LOW32;
        DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                   p_fib_key, p_hash_lookup_result));
    }
    else if ((FIB_KEY_TYPE_IPV6_MCAST == fib_key_type) || (FIB_KEY_TYPE_MAC_IPV6_MULTICAST == fib_key_type))
    {
        ds_lpm_tcam160_key.ip31_0 = p_fib_key->key.ipv6_mcast.ip_sa31_0;
        ds_lpm_tcam160_key.ip63_32 = p_fib_key->key.ipv6_mcast.ip_sa63_32;
        ds_lpm_tcam160_key.ip95_64 = p_fib_key->key.ipv6_mcast.ip_sa95_64;
        ds_lpm_tcam160_key.ip127_96 = p_fib_key->key.ipv6_mcast.ip_sa127_96;
        ds_lpm_tcam160_key.layer4_port1_0 = p_lpm_info->pointer.value & 0x3;
        ds_lpm_tcam160_key.layer4_port15_2 = (p_lpm_info->pointer.value >> 2) & 0x1FF;
        /* VRF based */
        CLEAR_BIT(ds_lpm_tcam160_key.layer4_port15_2, 13);
        ds_lpm_tcam160_key.table_id0 = 2;
        ds_lpm_tcam160_key.table_id1 = 2;
        /* IPv6 (S, G) S key */
        ds_lpm_tcam160_key.ipv6_lookup_type = 3;

        tcam_lookup_info.tcam_key_type = 1;
        tcam_lookup_info.tcam_key = &ds_lpm_tcam160_key;
        LPM_TCAM_LOOKUP(&tcam_lookup_info, p_tcam_lookup_result);

        p_fib_key->key.ipv6_mcast.pointer = p_lpm_info->pointer.value;
        lpm_hash_type = LPM_HASH_TYPE_IPV6_SG1;
        DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_perform_hash_lookup(chip_id, fib_key_type, lpm_hash_type,
                                                                   p_fib_key, p_hash_lookup_result));
    }

    return DRV_E_NONE;
}

static int32
_cm_com_lpm_engine_hash2_request(uint8 chip_id,
                                 fib_key_t* p_fib_key,
                                 fib_key_type_t fib_key_type,
                                 lookup_result_t* p_step_x_lookup_result)
{
    lookup_result_t hash_lookup_result;
    lpm_info_t lpm_lookup_info;
    tcam_lookup_result_t tcam_lookup_result;

    sal_memset(&hash_lookup_result, 0, sizeof(lookup_result_t));
    sal_memset(&lpm_lookup_info, 0, sizeof(lpm_info_t));
    sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result_t));
    hash_lookup_result.extra = &lpm_lookup_info;

    DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_hash_step2_lookup(chip_id,
                                                             p_fib_key,
                                                             fib_key_type,
                                                             p_step_x_lookup_result,
                                                             &hash_lookup_result,
                                                             &tcam_lookup_result));

    DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_hash_step2_result(chip_id,
                                                             fib_key_type,
                                                             p_fib_key,
                                                             p_step_x_lookup_result,
                                                             &hash_lookup_result,
                                                             &tcam_lookup_result));

    return DRV_E_NONE;
}

int32
cm_com_lpm_engine_perform_lpm_lookup(uint8 chip_id, fib_key_t* p_fib_key, fib_key_type_t fib_key_type,
                                     lookup_result_t* p_lpm_lookup_result)
{
    uint8* p_aging_en = NULL;
    uint32 ip32 = 0;
    uint32 cmd = 0;
    uint32 step = 0;
    lpm_info_t lpm_info[LPM_HASH_LOOKUP_STEP_NUM];
    lpm_extra_info_t lpm_extra_info[LPM_HASH_LOOKUP_STEP_NUM];
    lookup_result_t step_lookup_result[LPM_HASH_LOOKUP_STEP_NUM];
    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;
    lpm_pointer_t pointer;
    lpm_nexthop_t nexthop;

    sal_memset(&pointer, 0, sizeof(lpm_pointer_t));
    sal_memset(&nexthop, 0, sizeof(lpm_nexthop_t));
    sal_memset(step_lookup_result, 0, sizeof(step_lookup_result));
    sal_memset(lpm_info, 0, sizeof(lpm_info));
    sal_memset(lpm_extra_info, 0, sizeof(lpm_extra_info));
    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));

    p_aging_en = (uint8*)p_lpm_lookup_result->extra;

    for (step = LPM_HASH_LOOKUP_STEP1; step < LPM_HASH_LOOKUP_STEP_NUM; step++)
    {
        step_lookup_result[step].valid = FALSE;
        step_lookup_result[step].extra = &lpm_info[step];
        lpm_info[step].extra = &lpm_extra_info[step];
    }

    DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_hash1_request(chip_id, p_fib_key, fib_key_type, step_lookup_result));

    p_lpm_lookup_result->key_index = step_lookup_result[LPM_HASH_LOOKUP_STEP1].key_index;
    p_lpm_lookup_result->ad_index = lpm_info[LPM_HASH_LOOKUP_STEP1].nexthop.value;

    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_ctl));

    /* popHashLookupResult    */
    /* LPM lookup for unicast */
    if ((FIB_KEY_TYPE_IPV6_UCAST == fib_key_type) || (FIB_KEY_TYPE_IPV6_NAT_DA == fib_key_type))
    {
        ip32 = p_fib_key->key.ipv6_ucast.ip_da95_64;
    }
    /* IPv6 Ucast SA */
    else if (FIB_KEY_TYPE_IPV6_RPF == fib_key_type)
    {
        ip32 = p_fib_key->key.ipv6_rpf.ip_sa95_64;
    }
    else if ((FIB_KEY_TYPE_IPV4_UCAST == fib_key_type) || (FIB_KEY_TYPE_IPV4_NAT_DA == fib_key_type))
    {
        if (!fib_engine_lookup_ctl.lpm_ipv4_pipeline3_en)
        {
            /* IPv4 Ucast DA */
            ip32 = (p_fib_key->key.ipv4_ucast.ip_da & 0x0000FFFF) << 16;
        }
        else
        {
            ip32 = (p_fib_key->key.ipv4_ucast.ip_da & 0x00FFFFFF) << 8;
        }
    }
    /* IPv4 Ucast SA */
    else if (FIB_KEY_TYPE_IPV4_RPF == fib_key_type)
    {
        if (!fib_engine_lookup_ctl.lpm_ipv4_pipeline3_en)
        {
            /* IPv4 Ucast DA */
            ip32 = (p_fib_key->key.ipv4_rpf.ip_sa & 0x0000FFFF) << 16;
        }
        else
        {
            ip32 = (p_fib_key->key.ipv4_rpf.ip_sa & 0x00FFFFFF) << 8;
        }
    }

    /* request LPM pipeline lookup and get result s*/
    if ((INVALID_POINTER_OFFSET != (lpm_info[LPM_HASH_LOOKUP_STEP1].pointer.value & POINTER_OFFSET_MASK))
        && ((FIB_KEY_TYPE_IPV4_UCAST == (fib_key_type & 0x1F))
         || (FIB_KEY_TYPE_IPV4_NAT_DA == (fib_key_type & 0x1F))
         || (FIB_KEY_TYPE_IPV6_UCAST == (fib_key_type & 0x1F))
         || (FIB_KEY_TYPE_IPV6_NAT_DA == (fib_key_type & 0x1F))
         || (FIB_KEY_TYPE_IPV4_RPF == (fib_key_type & 0x1F))
         || (FIB_KEY_TYPE_IPV6_RPF == (fib_key_type & 0x1F))))
    {
        pointer.value = lpm_info[LPM_HASH_LOOKUP_STEP1].pointer.value;
        DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_pipeline(chip_id, ip32, lpm_info[LPM_HASH_LOOKUP_STEP1].index_mask,
                                                        &pointer, &nexthop));

        if (INVALID_NEXTHOP != nexthop.value)
        {
            p_lpm_lookup_result->ad_index = nexthop.value;
        }

        lpm_info[LPM_HASH_LOOKUP_STEP1].pointer.value = pointer.value;
    }

    /* IPv6 Ucast/Mcast */
    if ((INVALID_POINTER != lpm_info[LPM_HASH_LOOKUP_STEP1].pointer.value)
       && (((INVALID_NEXTHOP != lpm_extra_info[LPM_HASH_LOOKUP_STEP1].ipv6_mid)
       && ((FIB_KEY_TYPE_IPV6_UCAST == fib_key_type) || (FIB_KEY_TYPE_IPV6_NAT_DA == fib_key_type)))
       || ((FIB_KEY_TYPE_IPV6_MCAST == fib_key_type) || (FIB_KEY_TYPE_MAC_IPV6_MULTICAST == fib_key_type))))
    {
        DRV_IF_ERROR_RETURN(_cm_com_lpm_engine_hash2_request(chip_id, p_fib_key, fib_key_type, step_lookup_result));

        /* Get LPM Engine hash 2 lookup result */
        if (INVALID_NEXTHOP != lpm_info[LPM_HASH_LOOKUP_STEP2].nexthop.value)
        {
            p_lpm_lookup_result->key_index = step_lookup_result[LPM_HASH_LOOKUP_STEP2].key_index;
            p_lpm_lookup_result->ad_index = lpm_info[LPM_HASH_LOOKUP_STEP2].nexthop.value;
        }
    }

    if (INVALID_NEXTHOP != p_lpm_lookup_result->ad_index)
    {
        p_lpm_lookup_result->valid = TRUE;
    }

    return DRV_E_NONE;
}

