/****************************************************************************
 * cm_com_parser.c: Useful untilities for all modules.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Vision:       V1.0.
 * Author:       XuZx.
 * Date:         2010-10-19.
 * Reason:       Create for GreatBelt.
 *
 * Modify History:
 * Vision:       V2.0.
 * Author:       Jiangsz.
 * Date:         2011-04-06.
 * Reason:       modify for GreatBelt V2.0.
 *
 * Vision:       V2.0.
 * Author:       ZhouW.
 * Date:         2011-04-11.
 * Reason:       V2.0 code review done.
 *
 * Vision:       V4.2.
 * Author:       JiangSZ.
 * Date:         2011-06-30.
 * Reason:       SYNC spec V4.2.1.
 *
 * Revision:     V4.28.0
 * Author:       TaoJ.
 * Date:         2011-9-28.
 * Reason:       Sync spec revision 4.28.0.
 *
 * Revision:     V4.31.0
 * Author:       XuZx.
 * Date:         2011-10-21.
 * Reason:       Sync spec revision 4.31.0.
 *
 * Revision:     V4.33.0
 * Author:       XuZx.
 * Date:         2011-10-25.
 * Reason:       Sync spec revision 4.33.0.
 *
 * Revision:     V5.0.0
 * Author:       XuZx.
 * Date:         2011-11-11.
 * Reason:       Sync spec v5.0.0.
 *
 * Revision:     V5.9.0
 * Author:       XuZx.
 * Date:         2012-02-02.
 * Reason:       Sync spec v5.9.0.
 *
 * Revision:     V5.9.0
 * Author:       XuZx.
 * Date:         2012-02-02.
 * Reason:       Sync spec v5.9.0.
 *
 * Revision:     V5.11.0
 * Author:       XuZx.
 * Date:         2012-02-29.
 * Reason:       Sync spec v5.11.0.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
/* Layer2 cam macros */
#define MAKE_L2PTL_CAM_KEY(eth, ppp, sap, l2type, hdr)\
    (((eth) << 22) | ((ppp) << 21) | ((sap) << 20) | ((l2type) << 16) | (hdr))

#define L3_PROTOCOL_CAM_ENTRY_NUM   4

#define PARSER_ETHER_MAC_LINKAGG_DATA_WIDTH      160 /* StdCrc8D160P2Include.v */
#define PARSER_CMAC_LINKAGG_DATA_WIDTH           128 /* StdCrc8D128P2Include.v */
#define PARSER_IPV4_LINKAGG_DATA_WIDTH            72 /* StdCrc8D72P2Include.v  */
#define PARSER_IPV6_LINKAGG_DATA_WIDTH           288 /* StdCrc8D288P2Include.v */
#define PARSER_FCOE_LINKAGG_DATA_WIDTH            48 /* StdCrc8D48P2Include.v  */
#define PARSER_TRILL_LINKAGG_DATA_WIDTH           32 /* StdCrc8D32P2Include.v  */
#define PARSER_L4_INFO_LINKAGG_DATA_WIDTH         40 /* StdCrc8D40P2Include.v  */
#define PARSER_MPLS_LINKAGG_DATA_WIDTH           160 /* StdCrc8D160P2Include.v */
#define PARSER_IPV4_OVER_MPLS_LINKAGG_DATA_WIDTH 240 /* StdCrc8D240P2Include.v */
#define PARSER_IPV6_OVER_MPLS_LINKAGG_DATA_WIDTH 456 /* StdCrc8D456P2Include.v */

#define PARSER_ETHER_MAC_ECMP_DATA_WIDTH         104 /* StdCrc8D104P1Include.v */
#define PARSER_CMAC_ECMP_DATA_WIDTH              104 /* StdCrc8D104P1Include.v */
#define PARSER_IPV4_ECMP_DATA_WIDTH               80 /* StdCrc8D80P1Include.v  */
#define PARSER_IPV6_ECMP_DATA_WIDTH              296 /* StdCrc8D296P1Include.v */
#define PARSER_FCOE_ECMP_DATA_WIDTH               48 /* StdCrc8D48P1Include.v  */
#define PARSER_TRILL_ECMP_DATA_WIDTH              48 /* StdCrc8D48P1Include.v  */
#define PARSER_L4_INFO_ECMP_DATA_WIDTH            40 /* StdCrc8D40P1Include.v  */
#define PARSER_MPLS_ECMP_DATA_WIDTH              160 /* StdCrc8D160P1Include.v */
#define PARSER_IPV4_OVER_MPLS_ECMP_DATA_WIDTH    240 /* StdCrc8D240P1Include.v */
#define PARSER_IPV6_OVER_MPLS_ECMP_DATA_WIDTH    456 /* StdCrc8D456P1Include.v */

enum parser_key_type_e
{
    PARSER_HASH_KEY_TYPE_ETHER_MAC,
    PARSER_HASH_KEY_TYPE_PBB_MAC,
    PARSER_HASH_KEY_TYPE_IPV4,
    PARSER_HASH_KEY_TYPE_IPV6,
    PARSER_HASH_KEY_TYPE_FCOE,
    PARSER_HASH_KEY_TYPE_TRILL,
    PARSER_HASH_KEY_TYPE_L4_INFO,
    PARSER_HASH_KEY_TYPE_MPLS,
    PARSER_HASH_KEY_TYPE_IPV4_OVER_MPLS,
    PARSER_HASH_KEY_TYPE_IPV6_OVER_MPLS,
    PARSER_HASH_KEY_TYPE_NUM,
};
typedef enum parser_key_type_e parser_key_type_t;

enum parser_usage_type_e
{
    PARSER_USAGE_TYPE_ECMP,
    PARSER_USAGE_TYPE_LINKAGG,
    PARSER_USAGE_TYPE_NUM,
};
typedef enum parser_usage_type_e parser_usage_type_t;

enum parser_crc_type_e
{
    PARSER_CRC_TYPE_HASH,
    PARSER_CRC_TYPE_XOR,
    PARSER_CRC_TYPE_NUM,
};
typedef enum parser_crc_type_e parser_crc_type_t;

struct parse_misc_info_s
{
    uint8 min_length;
    uint8 layer2_basic_offset;
    uint16 cmac_type_or_length;
};
typedef struct parse_misc_info_s parse_misc_info_t;

struct ip_flag
{
    uint32 frag_data;
    uint8 offset_is0;
    uint8 offset_is1;
};
typedef struct ip_flag ip_frag_t;

typedef int32 (*cm_parser_generate_hash_key_t)(parser_info_t*, key_info_t*);

typedef uint32 (*cm_parser_calcaulte_hash_key_t)(uint8*);

static uint16
_ip_chksum (uint16 *p, uint16 length, uint16 init)
{
    uint32 sum = init;
    uint16 len = length >> 1;

    while (len-- > 0)
        sum += ctc_ntoh16(*p++);

    if (length & 1)
        sum += ctc_ntoh16(*p & 0xFF00);

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);

    len = sum & 0xFFFF;
    return(~len);
}

static int32
_cm_com_parser_generate_ether_mac_ecmp_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32 cmd = 0;
    parser_ethernet_ctl_t parser_ethernet_ctl;

    sal_memset(&parser_ethernet_ctl, 0, sizeof(parser_ethernet_ctl_t));
    cmd = DRV_IOR(ParserEthernetCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_ethernet_ctl));

    if (!IS_BIT_SET(parser_ethernet_ctl.mac_hash_disable, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da5, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da4, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da3, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da2, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da1, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 48, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_ethernet_ctl.mac_hash_disable, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa5, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa4, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa3, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa2, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa1, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 48, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ethernet_ctl.cos_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 2, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.stag_cos, 3, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.ctag_cos, 3, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_pbb_mac_ecmp_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32 cmd = 0;
    parser_pbb_ctl_t parser_pbb_ctl;

    sal_memset(&parser_pbb_ctl, 0, sizeof(parser_pbb_ctl_t));
    cmd = DRV_IOR(ParserPbbCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_pbb_ctl));

    if (!IS_BIT_SET(parser_pbb_ctl.c_mac_hash_disable, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.cmac.cmac_da_47_32, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.cmac.cmac_da_31_0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 48, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_pbb_ctl.c_mac_hash_disable, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.cmac.cmac_sa_47_32, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.cmac.cmac_sa_31_0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 48, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_pbb_ctl.pbb_cos_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 2, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.cmac.cmac_stag_cos, 3, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.cmac.cmac_ctag_cos, 3, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}


static int32
_cm_com_parser_generate_mpls_ecmp_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint8  ip_header_offset = 0;
    uint8* l3_header = NULL;
    uint32 cmd = 0;
    parser_mpls_ctl_t parser_mpls_ctl;

    l3_header = p_parser_info->pkt + p_parser_result->l2_s.layer3_offset + p_parser_info->payload_offset;
    ip_header_offset = p_parser_result->l3_s.tos.mpls.label_num * 4;

    sal_memset(&parser_mpls_ctl, 0, sizeof(parser_mpls_ctl_t));
    cmd = DRV_IOR(ParserMplsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_mpls_ctl));

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 7))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label7>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 6))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label6>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 5))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label5>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 4))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label4>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 3))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label3>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label2>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label1>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label0>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_ipv4_over_mpls_ecmp_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint8  ip_header_offset = 0;
    uint8* l3_header = NULL;
    uint32 cmd = 0;
    parser_mpls_ctl_t parser_mpls_ctl;

    l3_header = p_parser_info->pkt + p_parser_result->l2_s.layer3_offset + p_parser_info->payload_offset;
    ip_header_offset = p_parser_result->l3_s.tos.mpls.label_num * 4;

    sal_memset(&parser_mpls_ctl, 0, sizeof(parser_mpls_ctl_t));
    cmd = DRV_IOR(ParserMplsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_mpls_ctl));

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 7))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label7>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 6))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label6>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 5))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label5>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 4))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label4>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 3))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label3>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label2>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label1>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label0>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_mpls_ctl.mpls_ip_hash_disable, 1))
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 16], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 17], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 18], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 19], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_mpls_ctl.mpls_ip_hash_disable, 0))
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 12], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 13], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 14], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 15], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_mpls_ctl.mpls_dscp_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 2, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field((l3_header[ip_header_offset + 1] >> 2)&0x3F, 6, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_mpls_ctl.mpls_protocol_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 9], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_ipv6_over_mpls_ecmp_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint8  ip_header_offset = 0;
    uint8* l3_header = NULL;
    uint32 cmd = 0;
    parser_mpls_ctl_t parser_mpls_ctl;

    l3_header = p_parser_info->pkt + p_parser_result->l2_s.layer3_offset + p_parser_info->payload_offset;
    ip_header_offset = p_parser_result->l3_s.tos.mpls.label_num * 4;

    sal_memset(&parser_mpls_ctl, 0, sizeof(parser_mpls_ctl_t));
    cmd = DRV_IOR(ParserMplsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_mpls_ctl));

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 7))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label7>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 6))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label6>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 5))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label5>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 4))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label4>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 3))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label3>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label2>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label1>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label0>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_mpls_ctl.mpls_ip_hash_disable, 1))
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 24], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 25], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 26], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 27], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 28], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 29], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 30], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 31], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 32], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 33], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 34], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 35], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 36], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 37], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 38], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 39], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_mpls_ctl.mpls_ip_hash_disable, 0))
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 8],  8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 9],  8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 10], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 11], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 12], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 13], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 14], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 15], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 16], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 17], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 18], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 19], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 20], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 21], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 22], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 23], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_mpls_ctl.mpls_dscp_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 2, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset], 4, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 1] >> 6, 2, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_mpls_ctl.mpls_protocol_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 6], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_mpls_ctl.mpls_flow_label_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 4, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 1]&0xF, 4, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 2], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 3], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_ipv4_ecmp_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32 cmd = 0;
    parser_ip_hash_ctl_t parser_ip_hash_ctl;

    sal_memset(&parser_ip_hash_ctl, 0, sizeof(parser_ip_hash_ctl_t));
    cmd = DRV_IOR(ParserIpHashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_ip_hash_ctl));

    if (!IS_BIT_SET(parser_ip_hash_ctl.ip_ip_hash_disable, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.ipv4.ipda, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_ip_hash_ctl.ip_ip_hash_disable, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.ipv4.ipsa, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ip_hash_ctl.ip_dscp_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 2, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.tos.ip_tos >> 2, 6, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ip_hash_ctl.ip_protocol_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.layer3_header_protocol, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_ipv6_ecmp_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32 cmd = 0;
    parser_ip_hash_ctl_t parser_ip_hash_ctl;

    sal_memset(&parser_ip_hash_ctl, 0, sizeof(parser_ip_hash_ctl_t));
    cmd = DRV_IOR(ParserIpHashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_ip_hash_ctl));

    if (!IS_BIT_SET(parser_ip_hash_ctl.ip_ip_hash_disable, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.ipv6.ipda_127_96, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.ipv6.ipda_95_64, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.ipv6.ipda_63_32, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.ipv6.ipda_31_0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_ip_hash_ctl.ip_ip_hash_disable, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.ipv6.ipsa_127_96, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.ipv6.ipsa_95_64, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.ipv6.ipsa_63_32, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.ipv6.ipsa_31_0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ip_hash_ctl.ip_dscp_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 2, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field((p_parser_result->l3_s.tos.ip_tos>>2), 6, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ip_hash_ctl.ip_protocol_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.layer3_header_protocol, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ip_hash_ctl.ip_flow_label_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 4, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ipv6_flow_label, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_fcoe_ecmp_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32 cmd = 0;
    parser_fcoe_ctl_t parser_fcoe_ctl;

    sal_memset(&parser_fcoe_ctl, 0, sizeof(parser_fcoe_ctl_t));
    cmd = DRV_IOR(ParserFcoeCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_fcoe_ctl));

    if (IS_BIT_SET(parser_fcoe_ctl.fcoe_ecmp_hash_en, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.fcoe.fcoe_did, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(parser_fcoe_ctl.fcoe_ecmp_hash_en, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.fcoe.fcoe_sid, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_trill_ecmp_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32 cmd = 0;
    parser_trill_ctl_t parser_trill_ctl;

    sal_memset(&parser_trill_ctl, 0, sizeof(parser_trill_ctl_t));
    cmd = DRV_IOR(ParserTrillCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_trill_ctl));

    if (IS_BIT_SET(parser_trill_ctl.trill_ecmp_hash_en, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.trill.egress_nick_name, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(parser_trill_ctl.trill_ecmp_hash_en, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.trill.ingress_nick_name, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(parser_trill_ctl.trill_ecmp_hash_en, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.trill.trill_inner_vlan_id, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_layer4_info_ecmp_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32 cmd = 0;
    parser_layer4_hash_ctl_t parser_layer4_hash_ctl;

    sal_memset(&parser_layer4_hash_ctl, 0, sizeof(parser_layer4_hash_ctl_t));
    cmd = DRV_IOR(ParserLayer4HashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_layer4_hash_ctl));

    if ((!p_parser_result->l4_s.is_tcp) && (!p_parser_result->l4_s.is_udp))
    {
        if ((L4_TYPE_DCCP == p_parser_result->layer4_type) || (L4_TYPE_SCTP == p_parser_result->layer4_type))
        {
            drv_hash_lookup_add_field(p_parser_result->l3_s.ip_ecmp_hash, 8, &p_key_info->key_length, p_key_info->p_hash_key);

            if (parser_layer4_hash_ctl.source_port_ecmp_hash_en)
            {
                drv_hash_lookup_add_field(p_parser_result->l4_s.l4_src_port.l4_source_port, 16, &p_key_info->key_length, p_key_info->p_hash_key);
            }
            else
            {
                drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
            }

            if (parser_layer4_hash_ctl.dest_port_ecmp_hash_en)
            {
                drv_hash_lookup_add_field(p_parser_result->l4_s.l4_dst_port.l4_dest_port, 16, &p_key_info->key_length, p_key_info->p_hash_key);
            }
            else
            {
                drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
            }
        }
        else if (L4_TYPE_GRE == p_parser_result->layer4_type)
        {
            drv_hash_lookup_add_field(p_parser_result->l3_s.ip_ecmp_hash, 8, &p_key_info->key_length, p_key_info->p_hash_key);

            if (parser_layer4_hash_ctl.gre_key_ecmp_hash_en)
            {
                drv_hash_lookup_add_field(p_parser_result->l4_s.gre_bfd_ptp.gre_key, 32, &p_key_info->key_length, p_key_info->p_hash_key);
            }
            else
            {
                drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
            }
        }
    }
    else if (!IS_BIT_SET(p_parser_result->l3_s.frag_info, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_ecmp_hash, 8, &p_key_info->key_length, p_key_info->p_hash_key);

        if (parser_layer4_hash_ctl.source_port_ecmp_hash_en)
        {
            drv_hash_lookup_add_field(p_parser_result->l4_s.l4_src_port.l4_source_port, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        }
        else
        {
            drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        }

        if (parser_layer4_hash_ctl.dest_port_ecmp_hash_en)
        {
            drv_hash_lookup_add_field(p_parser_result->l4_s.l4_dst_port.l4_dest_port, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        }
        else
        {
            drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        }
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_ether_mac_linkagg_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32 cmd = 0;
    parser_ethernet_ctl_t parser_ethernet_ctl;

    sal_memset(&parser_ethernet_ctl, 0, sizeof(parser_ethernet_ctl_t));
    cmd = DRV_IOR(ParserEthernetCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_ethernet_ctl));

    if (parser_ethernet_ctl.chip_id_hash_en)
    {
        drv_hash_lookup_add_field(0, 3, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(parser_ethernet_ctl.chip_id, 5, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ethernet_ctl.port_hash_en)
    {
        drv_hash_lookup_add_field(p_parser_info->port_id, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_ethernet_ctl.mac_hash_disable, 3))
    {
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da5, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da4, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da3, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da2, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da1, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_da0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 48, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_ethernet_ctl.mac_hash_disable, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa5, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa4, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa3, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa2, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa1, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.mac_sa0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 48, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ethernet_ctl.vlan_hash_en)
    {
        if (!parser_ethernet_ctl.vlan_hash_mode)
        {
            drv_hash_lookup_add_field(p_parser_result->l2_s.svlan_id, 12, &p_key_info->key_length, p_key_info->p_hash_key);
            drv_hash_lookup_add_field(p_parser_result->l2_s.cvlan_id, 12, &p_key_info->key_length, p_key_info->p_hash_key);
        }
        else
        {
            drv_hash_lookup_add_field(0, 12, &p_key_info->key_length, p_key_info->p_hash_key);
            if (p_parser_result->l2_s.svlan_id_valid)
            {
                drv_hash_lookup_add_field(p_parser_result->l2_s.svlan_id, 12, &p_key_info->key_length, p_key_info->p_hash_key);
            }
            else
            {
                drv_hash_lookup_add_field(p_parser_result->l2_s.cvlan_id, 12, &p_key_info->key_length, p_key_info->p_hash_key);
            }
        }
    }
    else
    {
        drv_hash_lookup_add_field(0, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ethernet_ctl.cos_hash_en)
    {
        drv_hash_lookup_add_field(0, 2, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.stag_cos, 3, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l2_s.ctag_cos, 3, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ethernet_ctl.layer2_header_protocol_hash_en)
    {
        drv_hash_lookup_add_field(p_parser_result->l2_s.layer2_header_protocol, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_pbb_mac_linkagg_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32 cmd = 0;
    parser_pbb_ctl_t parser_pbb_ctl;

    sal_memset(&parser_pbb_ctl, 0, sizeof(parser_pbb_ctl_t));
    cmd = DRV_IOR(ParserPbbCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_pbb_ctl));

    if (!IS_BIT_SET(parser_pbb_ctl.c_mac_hash_disable, 3))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.cmac.cmac_da_47_32, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.cmac.cmac_da_31_0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 48, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_pbb_ctl.c_mac_hash_disable, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.cmac.cmac_sa_47_32, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.cmac.cmac_sa_31_0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 48, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_pbb_ctl.pbb_vlan_hash_en)
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.cmac.cmac_svlan_id, 12, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.cmac.cmac_cvlan_id, 12, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 12, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 12, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_pbb_ctl.pbb_cos_hash_en)
    {
        drv_hash_lookup_add_field(0, 2, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.cmac.cmac_stag_cos, 3, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.cmac.cmac_ctag_cos, 3, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_ipv4_linkagg_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32  cmd = 0;
    parser_ip_hash_ctl_t parser_ip_hash_ctl;

    sal_memset(&parser_ip_hash_ctl, 0, sizeof(parser_ip_hash_ctl));
    cmd = DRV_IOR(ParserIpHashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_ip_hash_ctl));

    if (!IS_BIT_SET(parser_ip_hash_ctl.ip_ip_hash_disable, 3))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.ipv4.ipda, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    if (!IS_BIT_SET(parser_ip_hash_ctl.ip_ip_hash_disable, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.ipv4.ipsa, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ip_hash_ctl.ip_protocol_hash_en)
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.layer3_header_protocol, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_ipv6_linkagg_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32  cmd = 0;
    parser_ip_hash_ctl_t parser_ip_hash_ctl;

    sal_memset(&parser_ip_hash_ctl, 0, sizeof(parser_ip_hash_ctl));
    cmd = DRV_IOR(ParserIpHashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_ip_hash_ctl));

    if (!IS_BIT_SET(parser_ip_hash_ctl.ip_ip_hash_disable, 3))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.ipv6.ipda_127_96, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.ipv6.ipda_95_64, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.ipv6.ipda_63_32, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.ipv6.ipda_31_0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_ip_hash_ctl.ip_ip_hash_disable, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.ipv6.ipsa_127_96, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.ipv6.ipsa_95_64, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.ipv6.ipsa_63_32, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.ipv6.ipsa_31_0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ip_hash_ctl.ip_protocol_hash_en)
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.layer3_header_protocol, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_ip_hash_ctl.ip_flow_label_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 4, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(p_parser_result->l3_s.ipv6_flow_label, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_fcoe_linkagg_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32  cmd = 0;
    parser_fcoe_ctl_t parser_fcoe_ctl;

    sal_memset(&parser_fcoe_ctl, 0, sizeof(parser_fcoe_ctl));
    cmd = DRV_IOR(ParserFcoeCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_fcoe_ctl));

    if (IS_BIT_SET(parser_fcoe_ctl.fcoe_agg_hash_en, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.fcoe.fcoe_did, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(parser_fcoe_ctl.fcoe_agg_hash_en, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.fcoe.fcoe_sid, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_trill_linkagg_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32  cmd = 0;
    parser_trill_ctl_t parser_trill_ctl;

    sal_memset(&parser_trill_ctl, 0, sizeof(parser_trill_ctl_t));
    cmd = DRV_IOR(ParserTrillCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_trill_ctl));

    if (IS_BIT_SET(parser_trill_ctl.trill_agg_hash_en, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.trill.egress_nick_name, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(parser_trill_ctl.trill_agg_hash_en, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.trill.ingress_nick_name, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_layer4_info_linkagg_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint32 cmd = 0;
    parser_layer4_hash_ctl_t parser_layer4_hash_ctl;

    sal_memset(&parser_layer4_hash_ctl, 0, sizeof(parser_layer4_hash_ctl));
    cmd = DRV_IOR(ParserLayer4HashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_layer4_hash_ctl));

    if ((!p_parser_result->l4_s.is_tcp) && (!p_parser_result->l4_s.is_udp))
    {
        if ((L4_TYPE_DCCP == p_parser_result->layer4_type) || (L4_TYPE_SCTP == p_parser_result->layer4_type))
        {
            drv_hash_lookup_add_field(p_parser_result->header_hash, 8, &p_key_info->key_length, p_key_info->p_hash_key);

            if (parser_layer4_hash_ctl.source_port_hash_en)
            {
                drv_hash_lookup_add_field(p_parser_result->l4_s.l4_src_port.l4_source_port, 16, &p_key_info->key_length, p_key_info->p_hash_key);
            }
            else
            {
                drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
            }

            if (parser_layer4_hash_ctl.dest_port_hash_en)
            {
                drv_hash_lookup_add_field(p_parser_result->l4_s.l4_dst_port.l4_dest_port, 16, &p_key_info->key_length, p_key_info->p_hash_key);
            }
            else
            {
                drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
            }
        }
        else if (L4_TYPE_GRE == p_parser_result->layer4_type)
        {
            drv_hash_lookup_add_field(p_parser_result->header_hash, 8, &p_key_info->key_length, p_key_info->p_hash_key);

            if (parser_layer4_hash_ctl.gre_key_hash_en)
            {
                drv_hash_lookup_add_field(p_parser_result->l4_s.gre_bfd_ptp.gre_key, 32, &p_key_info->key_length, p_key_info->p_hash_key);
            }
            else
            {
                drv_hash_lookup_add_field(0, 32, &p_key_info->key_length, p_key_info->p_hash_key);
            }
        }
    }
    else if (!IS_BIT_SET(p_parser_result->l3_s.frag_info, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->header_hash, 8, &p_key_info->key_length, p_key_info->p_hash_key);

        if (parser_layer4_hash_ctl.source_port_hash_en)
        {
            drv_hash_lookup_add_field(p_parser_result->l4_s.l4_src_port.l4_source_port, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        }
        else
        {
            drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        }

        if (parser_layer4_hash_ctl.dest_port_hash_en)
        {
            drv_hash_lookup_add_field(p_parser_result->l4_s.l4_dst_port.l4_dest_port, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        }
        else
        {
            drv_hash_lookup_add_field(0, 16, &p_key_info->key_length, p_key_info->p_hash_key);
        }
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_mpls_linkagg_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint8  ip_header_offset = 0;
    uint8* l3_header = NULL;
    uint32 cmd = 0;
    parser_mpls_ctl_t parser_mpls_ctl;

    l3_header = p_parser_info->pkt + p_parser_result->l2_s.layer3_offset + p_parser_info->payload_offset;
    ip_header_offset = p_parser_result->l3_s.tos.mpls.label_num * 4;

    sal_memset(&parser_mpls_ctl, 0, sizeof(parser_mpls_ctl_t));
    cmd = DRV_IOR(ParserMplsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_mpls_ctl));

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 7))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label7>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 6))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label6>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 5))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label5>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 4))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label4>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 3))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label3>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label2>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label1>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label0>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_ipv4_over_mpls_linkagg_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint8  ip_header_offset = 0;
    uint8* l3_header = NULL;
    uint32 cmd = 0;
    parser_mpls_ctl_t parser_mpls_ctl;

    l3_header = p_parser_info->pkt + p_parser_result->l2_s.layer3_offset + p_parser_info->payload_offset;
    ip_header_offset = p_parser_result->l3_s.tos.mpls.label_num * 4;

    sal_memset(&parser_mpls_ctl, 0, sizeof(parser_mpls_ctl_t));
    cmd = DRV_IOR(ParserMplsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_mpls_ctl));

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 7))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label7>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 6))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label6>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 5))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label5>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 4))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label4>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 3))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label3>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label2>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label1>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label0>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_mpls_ctl.mpls_ip_hash_disable, 3))
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 16], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 17], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 18], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 19], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    if (!IS_BIT_SET(parser_mpls_ctl.mpls_ip_hash_disable, 2))
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 12], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 13], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 14], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 15], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_mpls_ctl.mpls_dscp_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 2, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field((l3_header[ip_header_offset + 1] >> 2)&0x3F, 6, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_mpls_ctl.mpls_protocol_hash_en)
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 9], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_generate_ipv6_over_mpls_linkagg_key(parser_info_t* p_parser_info, key_info_t* p_key_info)
{
    parsing_result_t *p_parser_result = p_parser_info->parser_result;
    uint8  ip_header_offset = 0;
    uint8* l3_header = NULL;
    uint32 cmd = 0;
    parser_mpls_ctl_t parser_mpls_ctl;

    l3_header = p_parser_info->pkt + p_parser_result->l2_s.layer3_offset + p_parser_info->payload_offset;
    ip_header_offset = p_parser_result->l3_s.tos.mpls.label_num * 4;

    sal_memset(&parser_mpls_ctl, 0, sizeof(parser_mpls_ctl_t));
    cmd = DRV_IOR(ParserMplsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_parser_info->chip_id, 0, cmd, &parser_mpls_ctl));

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 7))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label7>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 6))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label6>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 5))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label5>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 4))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_sa.mpls.mpls_label4>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 3))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label3>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 2))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label2>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 1))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label1>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (IS_BIT_SET(p_parser_info->mpls_hash_en, 0))
    {
        drv_hash_lookup_add_field(p_parser_result->l3_s.ip_da.mpls.mpls_label0>>12, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 20, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_mpls_ctl.mpls_ip_hash_disable, 3))
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 24], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 25], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 26], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 27], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 28], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 29], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 30], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 31], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 32], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 33], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 34], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 35], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 36], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 37], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 38], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 39], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (!IS_BIT_SET(parser_mpls_ctl.mpls_ip_hash_disable, 2))
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 8],  8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 9],  8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 10], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 11], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 12], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 13], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 14], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 15], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 16], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 17], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 18], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 19], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 20], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 21], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 22], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 23], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_mpls_ctl.mpls_dscp_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 2, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset], 4, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field((l3_header[ip_header_offset + 1] >> 6)&0x3, 4, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_mpls_ctl.mpls_protocol_hash_en)
    {
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 6], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    if (parser_mpls_ctl.mpls_flow_label_ecmp_hash_en)
    {
        drv_hash_lookup_add_field(0, 4, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 1]&0xF, 4, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 2], 8, &p_key_info->key_length, p_key_info->p_hash_key);
        drv_hash_lookup_add_field(l3_header[ip_header_offset + 3], 8, &p_key_info->key_length, p_key_info->p_hash_key);
    }
    else
    {
        drv_hash_lookup_add_field(0, 24, &p_key_info->key_length, p_key_info->p_hash_key);
    }

    return DRV_E_NONE;
}

static cm_parser_generate_hash_key_t cm_parser_generate_hash_key[PARSER_HASH_KEY_TYPE_NUM][PARSER_USAGE_TYPE_NUM] =
{
    {_cm_com_parser_generate_ether_mac_ecmp_key, _cm_com_parser_generate_ether_mac_linkagg_key},
    {_cm_com_parser_generate_pbb_mac_ecmp_key, _cm_com_parser_generate_pbb_mac_linkagg_key},
    {_cm_com_parser_generate_ipv4_ecmp_key, _cm_com_parser_generate_ipv4_linkagg_key},
    {_cm_com_parser_generate_ipv6_ecmp_key, _cm_com_parser_generate_ipv6_linkagg_key},
    {_cm_com_parser_generate_fcoe_ecmp_key, _cm_com_parser_generate_fcoe_linkagg_key},
    {_cm_com_parser_generate_trill_ecmp_key, _cm_com_parser_generate_trill_linkagg_key},
    {_cm_com_parser_generate_layer4_info_ecmp_key, _cm_com_parser_generate_layer4_info_linkagg_key},
    {_cm_com_parser_generate_mpls_ecmp_key, _cm_com_parser_generate_mpls_linkagg_key},
    {_cm_com_parser_generate_ipv4_over_mpls_ecmp_key, _cm_com_parser_generate_ipv4_over_mpls_linkagg_key},
    {_cm_com_parser_generate_ipv6_over_mpls_ecmp_key, _cm_com_parser_generate_ipv6_over_mpls_linkagg_key}
};

/****************************************************************************
 * Name:     _cm_com_parser_generate_hash
 * Purpose:  Generate ECMP/Linkagg hash result in parser result.
 * Parameters:
 * Input:
 * Output:   Header hash result.
 * Return:   DRV_E_NONE = success.
 *           Other = Error, please refer to DRV_E_XXX.
 * Note:     None.
 ****************************************************************************/
static int32
_cm_com_parser_generate_hash(parser_info_t* p_parser_info,
                                           parser_usage_type_t parser_usage_type,
                                           parser_key_type_t parser_key_type,
                                           uint8  is_xor,
                                           uint8* p_crc)
{
    uint32 seed = 0;
    key_info_t key_info;
    uint8 hash_key[MAX_PARSER_DATA_WIDTH/8] = {0};
    uint32 parser_crc_data_width[PARSER_HASH_KEY_TYPE_NUM][PARSER_USAGE_TYPE_NUM] =
    {
        {PARSER_ETHER_MAC_ECMP_DATA_WIDTH,      PARSER_ETHER_MAC_LINKAGG_DATA_WIDTH},
        {PARSER_CMAC_ECMP_DATA_WIDTH,           PARSER_CMAC_LINKAGG_DATA_WIDTH},
        {PARSER_IPV4_ECMP_DATA_WIDTH,           PARSER_IPV4_LINKAGG_DATA_WIDTH},
        {PARSER_IPV6_ECMP_DATA_WIDTH,           PARSER_IPV6_LINKAGG_DATA_WIDTH},
        {PARSER_FCOE_ECMP_DATA_WIDTH,           PARSER_FCOE_LINKAGG_DATA_WIDTH},
        {PARSER_TRILL_ECMP_DATA_WIDTH,          PARSER_TRILL_LINKAGG_DATA_WIDTH},
        {PARSER_L4_INFO_ECMP_DATA_WIDTH,        PARSER_L4_INFO_LINKAGG_DATA_WIDTH},
        {PARSER_MPLS_ECMP_DATA_WIDTH,           PARSER_MPLS_LINKAGG_DATA_WIDTH},
        {PARSER_IPV4_OVER_MPLS_ECMP_DATA_WIDTH, PARSER_IPV4_OVER_MPLS_LINKAGG_DATA_WIDTH},
        {PARSER_IPV6_OVER_MPLS_ECMP_DATA_WIDTH, PARSER_IPV6_OVER_MPLS_LINKAGG_DATA_WIDTH}
    };
    uint32 parser_crc_poly[PARSER_USAGE_TYPE_NUM] = {DRV_POLY_CCITT_CRC8, DRV_POLY_CRC8};

    DRV_PTR_VALID_CHECK(p_parser_info);
    sal_memset(&key_info, 0, sizeof(key_info_t));

    key_info.p_hash_key = hash_key;

    DRV_IF_ERROR_RETURN(cm_parser_generate_hash_key[parser_key_type][parser_usage_type](p_parser_info, &key_info));

    if (!is_xor)
    {
        *p_crc = drv_hash_calculate_poly(&seed,
                                         key_info.p_hash_key,
                                         parser_crc_data_width[parser_key_type][parser_usage_type],
                                         parser_crc_poly[parser_usage_type], 8, 8);
    }
    else
    {
        *p_crc = drv_hash_calculate_xor(key_info.p_hash_key, key_info.key_length, 8, TRUE);
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l2_ppp_parsing
 * Purpose:    Layer2 ppp header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l2_ppp_parsing(parser_info_t *parser_info, parse_misc_info_t *l2_misc_info)
{
    parsing_result_t* parser_result = parser_info->parser_result;
    parser_layer2_flex_ctl_t parsing_l2_flex_ctl;

    uint8 chip_id = parser_info->chip_id;
    uint8* pkt = parser_info->pkt;
    uint8* l2_header = pkt + parser_info->payload_offset;
    uint32 cmd = 0;

    parser_result->l2_s.layer2_header_protocol = MAKE_UINT16(l2_header[0], l2_header[1]);

    sal_memset(&parsing_l2_flex_ctl, 0, sizeof(parsing_l2_flex_ctl));
    cmd = DRV_IOR(ParserLayer2FlexCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parsing_l2_flex_ctl));

    parser_result->l2_s.mac_da5 = l2_header[parsing_l2_flex_ctl.layer2_byte_select0];
    parser_result->l2_s.mac_da4 = l2_header[parsing_l2_flex_ctl.layer2_byte_select1];
    parser_result->l2_s.mac_da3 = l2_header[parsing_l2_flex_ctl.layer2_byte_select2];
    parser_result->l2_s.mac_da2 = l2_header[parsing_l2_flex_ctl.layer2_byte_select3];
    parser_result->l2_s.mac_da1 = l2_header[parsing_l2_flex_ctl.layer2_byte_select4];
    parser_result->l2_s.mac_da0 = l2_header[parsing_l2_flex_ctl.layer2_byte_select5];

    if (L2_TYPE_PPP1B == parser_result->layer2_type)
    {
        l2_misc_info->min_length = PPP1B_MIN_LEN;
        l2_misc_info->layer2_basic_offset = 1;   /* skip 1 byte to layer3 header */
    }
    else
    {
        l2_misc_info->min_length = PPP2B_MIN_LEN;
        l2_misc_info->layer2_basic_offset = 2;   /* skip 2 byte to layer3 header */
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l2_flex_parsing
 * Purpose:    Layer2 flex header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l2_flex_parsing(parser_info_t *parser_info, parse_misc_info_t *l2_misc_info)
{
    parsing_result_t* parser_result = parser_info->parser_result;
    parser_layer2_flex_ctl_t parsing_l2_flex_ctl;

    uint8 chip_id = parser_info->chip_id;
    uint8* pkt = parser_info->pkt;
    uint8* l2_header = pkt + parser_info->payload_offset;
    uint32 cmd = 0;

    sal_memset(&parsing_l2_flex_ctl, 0, sizeof(parsing_l2_flex_ctl));
    cmd = DRV_IOR(ParserLayer2FlexCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parsing_l2_flex_ctl));

    /* layer 2 protocol header fill */
    parser_result->l2_s.layer2_header_protocol = MAKE_UINT16(l2_header[parsing_l2_flex_ctl.layer2_protocol_byte_select0],
                                                             l2_header[parsing_l2_flex_ctl.layer2_protocol_byte_select1]);

    /* mac destination address fill */
    parser_result->l2_s.mac_da5 = l2_header[parsing_l2_flex_ctl.layer2_byte_select0]; /* macDa[47:40] */
    parser_result->l2_s.mac_da4 = l2_header[parsing_l2_flex_ctl.layer2_byte_select1]; /* macDa[39:32] */
    parser_result->l2_s.mac_da3 = l2_header[parsing_l2_flex_ctl.layer2_byte_select2]; /* macDa[31:24] */
    parser_result->l2_s.mac_da2 = l2_header[parsing_l2_flex_ctl.layer2_byte_select3]; /* macDa[23:16] */
    parser_result->l2_s.mac_da1 = l2_header[parsing_l2_flex_ctl.layer2_byte_select4]; /* macDa[15:8] */
    parser_result->l2_s.mac_da0 = l2_header[parsing_l2_flex_ctl.layer2_byte_select5]; /* macDa[7:0] */

    /* layer 2 basic offset */
    l2_misc_info->layer2_basic_offset = parsing_l2_flex_ctl.layer2_basic_offset;
    l2_misc_info->min_length = parsing_l2_flex_ctl.layer2_min_length;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l2_eth_parsing
 * Purpose:    Layer2 Ethernet header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l2_eth_parsing(parser_info_t *parser_info, parse_misc_info_t *l2_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;
    parser_ethernet_ctl_t parser_eth_ctl;

    uint8 isvlan_bitmap = 0;
    uint8 mux_length = 0;
    uint8 sap_ctl = 0;
    uint8 vlan_num = 0;
    uint8 vlan_offset = 0;
    uint8 chip_id = parser_info->chip_id;
    uint8 is_svlan_tpid = FALSE, is_cvlan_tpid = FALSE;
    uint8 isvlan0 = FALSE, isvlan1 = FALSE, isvlan2 = FALSE, isvlan3 = FALSE;
    uint8* pkt = parser_info->pkt;
    uint8* l2_header = pkt + parser_info->payload_offset;
    uint16 sap = 0;
    uint16 cfg_svlan_tpid  = 0;
    uint16 pkt_cn_tpid = 0;
    uint16 tpid_in_pkt = 0;
    uint16 type_or_length = 0;
    uint32 snap_oui = 0;
    uint32 cmd = 0;

    /* NUM_OF_VLANS */
    /* Refer to IEEE802.3, IEEE802.1q, IEEE802.1ad, IEEE802.1au */
    parser_result->l2_s.mac_da5 = l2_header[0];
    parser_result->l2_s.mac_da4 = l2_header[1];
    parser_result->l2_s.mac_da3 = l2_header[2];
    parser_result->l2_s.mac_da2 = l2_header[3];
    parser_result->l2_s.mac_da1 = l2_header[4];
    parser_result->l2_s.mac_da0 = l2_header[5];

    parser_result->l2_s.mac_sa5 = l2_header[6];
    parser_result->l2_s.mac_sa4 = l2_header[7];
    parser_result->l2_s.mac_sa3 = l2_header[8];
    parser_result->l2_s.mac_sa2 = l2_header[9];
    parser_result->l2_s.mac_sa1 = l2_header[10];
    parser_result->l2_s.mac_sa0 = l2_header[11];

    is_cvlan_tpid = FALSE;

    switch (parser_info->mux_length_type)
    {
        case MUX_LENGTH_TYPE1:
            mux_length = 4;
            break;
        case MUX_LENGTH_TYPE2:
            mux_length = 8;
            break;
        default:
            mux_length = 0;
            break;
    }

    sal_memset(&parser_eth_ctl, 0, sizeof(parser_eth_ctl));
    cmd = DRV_IOR(ParserEthernetCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_eth_ctl));

    /* decide number of VLANs */
    switch (parser_info->svlan_tpid_index)
    {
        case 0:
           cfg_svlan_tpid = parser_eth_ctl.svlan_tpid0;
           break;

        case 1:
            cfg_svlan_tpid = parser_eth_ctl.svlan_tpid1;
            break;

        case 2:
            cfg_svlan_tpid = parser_eth_ctl.svlan_tpid2;
            break;

        default:
            cfg_svlan_tpid = parser_eth_ctl.svlan_tpid3;
            break;
    }

    is_svlan_tpid = (MAKE_UINT16(l2_header[12 + mux_length], l2_header[13 + mux_length])
                     == cfg_svlan_tpid);

    if (is_svlan_tpid)
    {
        is_cvlan_tpid = (MAKE_UINT16(l2_header[16 + mux_length], l2_header[17 + mux_length])
                         == parser_eth_ctl.cvlan_tpid);
    }
    else
    {
        is_cvlan_tpid = (MAKE_UINT16(l2_header[12 + mux_length], l2_header[13 + mux_length])
                         == parser_eth_ctl.cvlan_tpid);
    }

    vlan_num = is_svlan_tpid + is_cvlan_tpid;

    if (vlan_num > parser_eth_ctl.vlan_parsing_num)
    {
        vlan_num = parser_eth_ctl.vlan_parsing_num;
    }

    if ((1 == vlan_num)
        && (cfg_svlan_tpid == parser_eth_ctl.cvlan_tpid)
        && (parser_info->outer_vlan_is_cvlan))
    {
        is_svlan_tpid = FALSE;
        is_cvlan_tpid = TRUE;
    }

    if (parser_eth_ctl.parsing_quad_vlan)
    {
        tpid_in_pkt = MAKE_UINT16(l2_header[12 + mux_length], l2_header[13 + mux_length]);
        isvlan0 = ((tpid_in_pkt == parser_eth_ctl.cvlan_tpid) || (tpid_in_pkt == cfg_svlan_tpid));

        tpid_in_pkt = MAKE_UINT16(l2_header[16 + mux_length], l2_header[17 + mux_length]);
        isvlan1 = ((tpid_in_pkt == parser_eth_ctl.cvlan_tpid) || (tpid_in_pkt == cfg_svlan_tpid));

        tpid_in_pkt = MAKE_UINT16(l2_header[20 + mux_length], l2_header[21 + mux_length]);
        isvlan2 = ((tpid_in_pkt == parser_eth_ctl.cvlan_tpid) || (tpid_in_pkt == cfg_svlan_tpid));

        tpid_in_pkt = MAKE_UINT16(l2_header[24 + mux_length], l2_header[25 + mux_length]);
        isvlan3 = ((tpid_in_pkt == parser_eth_ctl.cvlan_tpid) || (tpid_in_pkt == cfg_svlan_tpid));

        isvlan_bitmap  = ((isvlan0 & 0x1) << 3) | ((isvlan1 & 0x1) << 2)
                          | ((isvlan2 & 0x1) << 1) | (isvlan3 & 0x1);

        /* case (isvlan0, isvlan1, isvlan2, isvlan3) */
        if (0xF == isvlan_bitmap)                                    /* 0'b1111 */
        {
            vlan_offset = 16;
        }
        else if (0xE == isvlan_bitmap)                               /* 0'b1110 */
        {
            vlan_offset = 12;
        }
        else if ((isvlan_bitmap >= 0xC) && (isvlan_bitmap <= 0xD))   /* 0'b110x */
        {
            vlan_offset = 8;
        }
        else if ((isvlan_bitmap >= 0x8) && (isvlan_bitmap <= 0xB))   /* 0'b10xx */
        {
            vlan_offset = 4;
        }
        else                                                         /* 0'b0xxx */
        {
            vlan_offset = 0;
        }
    }
    else
    {
        switch (vlan_num & 0x3)
        {
            case 2:
                vlan_offset = 8;
                break;

            case 1:
                vlan_offset = 4;
                break;

            default:
                vlan_offset = 0;
                break;
        }
    }

    pkt_cn_tpid = MAKE_UINT16(l2_header[12 + vlan_offset + mux_length], l2_header[13 + vlan_offset + mux_length]);

    if (parser_eth_ctl.cn_tpid == pkt_cn_tpid)
    {
        parser_result->l2_s.cn_tag_valid = TRUE;
        parser_result->l2_s.cn_flow_id = MAKE_UINT16(l2_header[14 + vlan_offset + mux_length],
                                                     l2_header[15 + vlan_offset + mux_length]);
        vlan_offset += 4;
    }

    /* ASSIGN_VLANS */
    if (vlan_num == 2)
    {
        parser_result->l2_s.svlan_id_valid = TRUE;
        parser_result->l2_s.cvlan_id_valid = TRUE;
        parser_result->l2_s.svlan_id = ((l2_header[14 + mux_length] & 0xF) << 8) | l2_header[15 + mux_length];
        parser_result->l2_s.cvlan_id = ((l2_header[18 + mux_length] & 0xF) << 8) | l2_header[19 + mux_length];
        parser_result->l2_s.stag_cos = (l2_header[14 + mux_length] >> 5) & 0x7;
        parser_result->l2_s.ctag_cos = (l2_header[18 + mux_length] >> 5) & 0x7;
        parser_result->l2_s.stag_cfi = IS_BIT_SET(l2_header[14 + mux_length], 4);
        parser_result->l2_s.ctag_cfi = IS_BIT_SET(l2_header[18 + mux_length], 4);
    }
    else if (vlan_num == 1)
    {
        if (is_svlan_tpid)
        {
            parser_result->l2_s.svlan_id_valid = TRUE;
            parser_result->l2_s.cvlan_id_valid = FALSE;
            parser_result->l2_s.svlan_id = ((l2_header[14 + mux_length] & 0xF) << 8) | l2_header[15 + mux_length];
            parser_result->l2_s.cvlan_id = 0;
            parser_result->l2_s.stag_cos = (l2_header[14 + mux_length] >> 5) & 0x7;
            parser_result->l2_s.ctag_cos = 0;
            parser_result->l2_s.stag_cfi = IS_BIT_SET(l2_header[14 + mux_length], 4);
            parser_result->l2_s.ctag_cfi = 0;
        }
        else
        {
            parser_result->l2_s.cvlan_id_valid = TRUE;
            parser_result->l2_s.svlan_id_valid = FALSE;
            parser_result->l2_s.cvlan_id = ((l2_header[14 + mux_length] & 0xF) << 8) | l2_header[15 + mux_length];
            parser_result->l2_s.svlan_id = 0;
            parser_result->l2_s.ctag_cos = (l2_header[14 + mux_length] >> 5) & 0x7;
            parser_result->l2_s.stag_cos = 0;
            parser_result->l2_s.ctag_cfi = IS_BIT_SET(l2_header[14 + mux_length], 4);
            parser_result->l2_s.stag_cfi = 0;
        }
    }
    else
    {
        parser_result->l2_s.svlan_id_valid = FALSE;
        parser_result->l2_s.cvlan_id_valid = FALSE;
        parser_result->l2_s.svlan_id = 0;
        parser_result->l2_s.cvlan_id = 0;
        parser_result->l2_s.stag_cos = 0;
        parser_result->l2_s.ctag_cos = 0;
        parser_result->l2_s.stag_cfi = 0;
        parser_result->l2_s.ctag_cfi = 0;
    }

    /* DECIDE_ETHER_TYPE */
    type_or_length = MAKE_UINT16(l2_header[12 + vlan_offset + mux_length],
                                 l2_header[13 + vlan_offset + mux_length]);

    sap = MAKE_UINT16(l2_header[14 + vlan_offset + mux_length],
                      l2_header[15 + vlan_offset + mux_length]);

    sap_ctl = l2_header[16 + vlan_offset + mux_length];

    snap_oui = (l2_header[17 + vlan_offset + mux_length] << 16)
               | (l2_header[18 + vlan_offset + mux_length] << 8)
               | (l2_header[19 + vlan_offset + mux_length]);

    if (type_or_length >= parser_eth_ctl.max_length_field)
    {
        l2_misc_info->min_length = ETH_V2_MIN_LEN + vlan_offset + mux_length;
        parser_result->layer2_type = L2_TYPE_ETHV2;
        parser_result->l2_s.layer2_header_protocol = MAKE_UINT16(l2_header[12 + vlan_offset + mux_length],
                                                                 l2_header[13 + vlan_offset + mux_length]);
        l2_misc_info->layer2_basic_offset = ETH_V2_MIN_LEN  + vlan_offset + mux_length;
    }
    else if ((0xAAAA == sap) && (0x03 == sap_ctl)
             && (parser_eth_ctl.allow_non_zero_oui || (0 == snap_oui)))
    {
        l2_misc_info->min_length = ETH_SNAP_MIN_LEN + vlan_offset + mux_length;
        parser_result->layer2_type = L2_TYPE_ETHSNAP;
        parser_result->l2_s.layer2_header_protocol = MAKE_UINT16(l2_header[20 + vlan_offset + mux_length],
                                                                 l2_header[21 + vlan_offset + mux_length]);
        l2_misc_info->layer2_basic_offset = ETH_SNAP_MIN_LEN  + vlan_offset + mux_length;
    }
    else
    {
        l2_misc_info->min_length = ETH_SAP_MIN_LEN + vlan_offset + mux_length;
        parser_result->layer2_type = L2_TYPE_ETHSAP;
        parser_result->l2_s.layer2_header_protocol = MAKE_UINT16(l2_header[14 + vlan_offset + mux_length],
                                                                 l2_header[15 + vlan_offset + mux_length]);
        if (3 == (sap_ctl & 3))
        {
            l2_misc_info->layer2_basic_offset = ETH_SAP_MIN_LEN  + vlan_offset + mux_length;
        }
        else
        {
            l2_misc_info->layer2_basic_offset = ETH_SAP_MIN_LEN + 1 + vlan_offset + mux_length;
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l2_protocol_lookup
 * Purpose:    Layer2 header lookup.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l2_protocol_lookup(parser_info_t *parser_info, parse_misc_info_t *l2_misc_info)
{
    #define LAYER2_PROTOCOL_CAM_MAX_ENTRY 4

    parsing_result_t* parser_result = parser_info->parser_result;
    parser_ethernet_ctl_t parser_eth_ctl;
    parser_layer2_protocol_cam_t parser_l2_pro_cam;
    parser_layer2_protocol_cam_valid_t parser_l2_pro_cam_valid;
    uint8 chip_id = parser_info->chip_id;
    uint8 is_ipv4 = FALSE, is_ipv6 = FALSE, is_mpls = FALSE, is_mpls_mcast = FALSE;
    uint8 is_arp = FALSE, is_fcoe = FALSE, is_trill = FALSE, is_eth_oam = FALSE;
    uint8 is_pbb = FALSE, is_slow_protocol = FALSE, is_1588 = FALSE;
    uint8 is_eth = FALSE, is_ppp = FALSE, is_sap = FALSE, is_eth_v2_or_snap = FALSE;
    uint8 index = 0;
    uint8  is_xor = FALSE;
    uint8  crc = 0;
    uint32 cfg_l2_cam_value = 0, cfg_l2_cam_mask = 0, cfg_l2_cam_l3type = 0, cfg_l2_cam_add_offset = 0;
    uint32 l2_protocol_key = 0;
    uint32 cmd = 0;

    sal_memset(&parser_eth_ctl, 0, sizeof(parser_eth_ctl));
    cmd = DRV_IOR(ParserEthernetCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_eth_ctl));

    /* select CRC_8_1 or ECMP_XOR8 by ParserEthernetCtl.macEcmpHashType */
    is_xor = parser_eth_ctl.mac_ecmp_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_ECMP,
                                                     PARSER_HASH_KEY_TYPE_ETHER_MAC,
                                                     is_xor,
                                                     &crc));
    parser_result->l2_s.mac_ecmp_hash = crc;

    /* select CRC_8_2 or LINKAGG_XOR8 by ParserEthernetCtl.macLinkAggHashType */
    is_xor = parser_eth_ctl.mac_link_agg_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_LINKAGG,
                                                     PARSER_HASH_KEY_TYPE_ETHER_MAC,
                                                     is_xor,
                                                     &crc));
    parser_result->header_hash = crc;

    parser_result->layer3_type = L3_TYPE_NONE;
    parser_result->l2_s.layer3_offset = l2_misc_info->layer2_basic_offset;

    is_eth = ((L2_TYPE_ETHV2 == parser_result->layer2_type) || (L2_TYPE_ETHSAP == parser_result->layer2_type)
               || (L2_TYPE_ETHSNAP == parser_result->layer2_type));

    is_ppp = ((L2_TYPE_PPP1B == parser_result->layer2_type) || (L2_TYPE_PPP2B == parser_result->layer2_type));

    is_sap = (L2_TYPE_ETHSAP == parser_result->layer2_type);

    is_eth_v2_or_snap = ((L2_TYPE_ETHV2 == parser_result->layer2_type)
                         || (L2_TYPE_ETHSNAP == parser_result->layer2_type));

    is_ipv4 = is_eth_v2_or_snap
              && (0x0800 == parser_result->l2_s.layer2_header_protocol)
              && parser_eth_ctl.ipv4_type_en;

    is_ipv6 = is_eth_v2_or_snap
              && (0x86DD == parser_result->l2_s.layer2_header_protocol)
              && parser_eth_ctl.ipv6_type_en;

    is_mpls = is_eth_v2_or_snap
              && (0x8847 == parser_result->l2_s.layer2_header_protocol)
              && parser_eth_ctl.mpls_type_en;

    is_mpls_mcast = is_eth_v2_or_snap
                    && (0x8848 == parser_result->l2_s.layer2_header_protocol)
                    && parser_eth_ctl.mpls_mcast_type_en;

    is_arp = is_eth_v2_or_snap
             && (0x0806 == parser_result->l2_s.layer2_header_protocol)
             && parser_eth_ctl.arp_type_en;

    is_fcoe = is_eth_v2_or_snap
              && (0x8906 == parser_result->l2_s.layer2_header_protocol)
              && parser_eth_ctl.fcoe_type_en;

    is_trill = is_eth_v2_or_snap
               && (0x22F3 == parser_result->l2_s.layer2_header_protocol)
               && parser_eth_ctl.trill_type_en;

    is_eth_oam = is_eth_v2_or_snap
                 && (0x8902 == parser_result->l2_s.layer2_header_protocol)
                 && parser_eth_ctl.eth_oam_type_en;

    is_pbb = is_eth_v2_or_snap
             && (0x88E7 == parser_result->l2_s.layer2_header_protocol)
             && parser_eth_ctl.pbb_type_en;

    is_slow_protocol = is_eth_v2_or_snap
                       && (0x8809 == parser_result->l2_s.layer2_header_protocol)
                       && parser_eth_ctl.slow_protocol_type_en;

    is_1588 = is_eth_v2_or_snap
              && (0x88F7 == parser_result->l2_s.layer2_header_protocol)
              && parser_eth_ctl.ieee1588_type_en;

    if (is_ipv4)
    {
        parser_result->layer3_type = L3_TYPE_IPV4;
    }
    else if (is_ipv6)
    {
        parser_result->layer3_type = L3_TYPE_IPV6;
    }
    else if (is_mpls)
    {
        parser_result->layer3_type = L3_TYPE_MPLS;
    }
    else if (is_mpls_mcast)
    {
        parser_result->layer3_type = L3_TYPE_MPLSMCAST;
    }
    else if (is_arp)
    {
        parser_result->layer3_type = L3_TYPE_ARP;
    }
    else if (is_fcoe)
    {
        parser_result->layer3_type = L3_TYPE_FCOE;
    }
    else if (is_trill)
    {
        parser_result->layer3_type = L3_TYPE_TRILL;
    }
    else if (is_eth_oam)
    {
        parser_result->layer3_type = L3_TYPE_ETHEROAM;
    }
    else if (is_pbb)
    {
        parser_result->layer3_type = L3_TYPE_CMAC;
    }
    else if (is_slow_protocol)
    {
        parser_result->layer3_type = L3_TYPE_SLOWPROTO;
    }
    else if (is_1588)
    {
        parser_result->layer3_type = L3_TYPE_PTP;
    }
    else
    {
        l2_protocol_key = MAKE_L2PTL_CAM_KEY(is_eth, is_ppp, is_sap,
                                             parser_result->layer2_type,
                                             parser_result->l2_s.layer2_header_protocol);
        /* read layer 2 protocol cam valid */
        sal_memset(&parser_l2_pro_cam_valid, 0, sizeof(parser_l2_pro_cam_valid));
        cmd = DRV_IOR(ParserLayer2ProtocolCamValid_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_l2_pro_cam_valid));
        /* search from the match */
        sal_memset(&parser_l2_pro_cam, 0, sizeof(parser_l2_pro_cam));
        cmd = DRV_IOR(ParserLayer2ProtocolCam_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_l2_pro_cam));
        index = 0;

        for (;;)
        {
            if (!IS_BIT_SET(parser_l2_pro_cam_valid.layer2_cam_entry_valid, index))
            {
                index ++;
                CONDITIONAL_BREAK(LAYER2_PROTOCOL_CAM_MAX_ENTRY == index);
                continue;
            }
            switch (index & 0x3)
            {
                case 0:
                    cfg_l2_cam_value = parser_l2_pro_cam.l2_cam_value0;
                    cfg_l2_cam_mask = parser_l2_pro_cam.l2_cam_mask0;
                    cfg_l2_cam_l3type = parser_l2_pro_cam.l2_cam_layer3_type0;
                    cfg_l2_cam_add_offset = parser_l2_pro_cam.l2_cam_additional_offset0;
                    break;
                case 1:
                    cfg_l2_cam_value = parser_l2_pro_cam.l2_cam_value1;
                    cfg_l2_cam_mask = parser_l2_pro_cam.l2_cam_mask1;
                    cfg_l2_cam_l3type = parser_l2_pro_cam.l2_cam_layer3_type1;
                    cfg_l2_cam_add_offset = parser_l2_pro_cam.l2_cam_additional_offset1;
                    break;
                case 2:
                    cfg_l2_cam_value = parser_l2_pro_cam.l2_cam_value2;
                    cfg_l2_cam_mask = parser_l2_pro_cam.l2_cam_mask2;
                    cfg_l2_cam_l3type = parser_l2_pro_cam.l2_cam_layer3_type2;
                    cfg_l2_cam_add_offset = parser_l2_pro_cam.l2_cam_additional_offset2;
                    break;
                case 3:
                    cfg_l2_cam_value = parser_l2_pro_cam.l2_cam_value3;
                    cfg_l2_cam_mask = parser_l2_pro_cam.l2_cam_mask3;
                    cfg_l2_cam_l3type = parser_l2_pro_cam.l2_cam_layer3_type3;
                    cfg_l2_cam_add_offset = parser_l2_pro_cam.l2_cam_additional_offset3;
                    break;
                default:
                    break;
            }

            /* if matched , break for handle */
            CONDITIONAL_BREAK((cfg_l2_cam_value & cfg_l2_cam_mask) == (l2_protocol_key & cfg_l2_cam_mask));

            /* if index equal max number, break */
            index ++;
            CONDITIONAL_BREAK(LAYER2_PROTOCOL_CAM_MAX_ENTRY == index);
        }

        if (LAYER2_PROTOCOL_CAM_MAX_ENTRY == index)
        {
            parser_result->layer3_type = L3_TYPE_NONE;
            parser_result->l2_s.layer3_offset = l2_misc_info->layer2_basic_offset;
        }
        else
        {
            parser_result->layer3_type = cfg_l2_cam_l3type;
            parser_result->l2_s.layer3_offset = l2_misc_info->layer2_basic_offset + cfg_l2_cam_add_offset;
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l2_udf_parser
 * Purpose:    Layer2 header udf parsing process.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l2_udf_parser(parser_info_t *parser_info, parse_misc_info_t *l2_misc_info)
{

    parsing_result_t* parser_result = parser_info->parser_result;

    if (!parser_info->non_crc)
    {
        l2_misc_info->min_length += 4;
    }

    if (parser_info->parser_length < l2_misc_info->min_length)
    {
        parser_result->parser_length_error = TRUE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l2_packet_parsing
 * Purpose:    Layer2 header parsing process.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l2_packet_parsing(parser_info_t *parser_info)
{
    parse_misc_info_t l2_misc_info;
    parsing_result_t* parser_result = parser_info->parser_result;

    /* l2Header = packet data bytes from payloadOffset[7:0] */
    sal_memset(&l2_misc_info, 0, sizeof(parse_misc_info_t));

    if ((L2_TYPE_PPP1B == parser_result->layer2_type) || (L2_TYPE_PPP2B == parser_result->layer2_type))
    {
        /* PPP_PARSING */
        DRV_IF_ERROR_RETURN(_cm_com_parser_l2_ppp_parsing(parser_info, &l2_misc_info));
    }
    else if ((L2_TYPE_ETHV2 == parser_result->layer2_type) || (L2_TYPE_ETHSAP == parser_result->layer2_type)
             || (L2_TYPE_ETHSNAP == parser_result->layer2_type))
    {
        /* ETH_PARSING */
        DRV_IF_ERROR_RETURN(_cm_com_parser_l2_eth_parsing(parser_info, &l2_misc_info));
    }
    else
    {
        /* FLEX_L2_PARSING */
        DRV_IF_ERROR_RETURN(_cm_com_parser_l2_flex_parsing(parser_info, &l2_misc_info));
    }

    /* HASH_AND_L2_PROTOCOL_LOOKUP */
    DRV_IF_ERROR_RETURN(_cm_com_parser_l2_protocol_lookup(parser_info, &l2_misc_info));

    DRV_IF_ERROR_RETURN(_cm_com_parser_l2_udf_parser(parser_info, &l2_misc_info));

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_ipv4_parsing
 * Purpose:    Layer3 IPv4 header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_com_parser_l3_ipv4_parsing(parser_info_t *parser_info, ip_frag_t *frag, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;
    parser_ip_hash_ctl_t parser_ip_hash_ctl;
    parser_layer3_hash_ctl_t parser_layer3_hash_ctl;
    uint8 *l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;
    uint8 chip_id = parser_info->chip_id;
    uint8 ip_header_len = l3_header[0] & 0xF;
    uint8 ip_version = (l3_header[0] >> 4) & 0xF;
    uint8 is_xor = FALSE;
    uint8 crc = 0;
    uint32 cmd = 0;

    /* Refer to RFC791 */
    l3_misc_info->min_length = ip_header_len << 2;

    parser_result->layer3_type = L3_TYPE_IPV4;              /* overwrite layer3Type */
    parser_result->l3_s.ip_options = (ip_header_len > 5);   /* header length more than 5 */
    parser_result->l3_s.ip_header_error = (4 != ip_version) || (ip_header_len < 5)
                                          || ((!parser_result->l3_s.ip_options) && _ip_chksum((uint16 *)l3_header, 20, 0));
    parser_result->l3_s.ip_length = ((l3_header[2] & 0x3F) << 8) | l3_header[3];
    parser_result->l3_s.tos.ip_tos = l3_header[1];
    parser_result->l3_s.ttl = l3_header[8];
    parser_result->l3_s.ip_da.ipv4.ipda = MAKE_UINT32(l3_header[16], l3_header[17], l3_header[18], l3_header[19]);
    parser_result->l3_s.ip_sa.ipv4.ip_check_sum = MAKE_UINT16(l3_header[10], l3_header[11]);   /* IP header checksum */
    parser_result->l3_s.ip_sa.ipv4.ipsa = MAKE_UINT32(l3_header[12], l3_header[13], l3_header[14], l3_header[15]);
    parser_result->l3_s.layer3_header_protocol = l3_header[9];
    parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + (ip_header_len << 2);

    sal_memset(&parser_ip_hash_ctl, 0, sizeof(parser_ip_hash_ctl_t));
    cmd = DRV_IOR(ParserIpHashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_ip_hash_ctl));

    sal_memset(&parser_layer3_hash_ctl, 0, sizeof(parser_layer3_hash_ctl_t));
    cmd = DRV_IOR(ParserLayer3HashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_layer3_hash_ctl));

    parser_result->l3_s.dont_frag = IS_BIT_SET(l3_header[6], 6);
    parser_result->l3_s.more_frag = IS_BIT_SET(l3_header[6], 5);
    parser_result->l3_s.frag_offset = MAKE_UINT16((l3_header[6] & 0x1F), l3_header[7]);

    frag->offset_is0 = (0 == parser_result->l3_s.frag_offset);
    frag->offset_is1 = (0 != parser_result->l3_s.frag_offset)
                       && (parser_result->l3_s.frag_offset <= parser_ip_hash_ctl.small_fragment_offset);

    parser_result->l3_s.ip_identification = MAKE_UINT16(l3_header[4], l3_header[5]);

    /* select CRC8_1 or ECMP XOR8 by ParserLayer3HashCtl.layer3EcmpHashType */
    is_xor = parser_layer3_hash_ctl.layer3_ecmp_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_ECMP,
                                                     PARSER_HASH_KEY_TYPE_IPV4,
                                                     is_xor,
                                                     &crc));
    parser_result->l3_s.ip_ecmp_hash = crc;

    /* select CRC8_2 or LINKAGG XOR8 by ParserLayer3HashCtl.layer3LinkAggHashType */
    is_xor = parser_layer3_hash_ctl.layer3_link_agg_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_LINKAGG,
                                                     PARSER_HASH_KEY_TYPE_IPV4,
                                                     is_xor,
                                                     &crc));

    if (parser_ip_hash_ctl.use_ip_hash)
    {
        parser_result->header_hash = crc;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_ipv6_parsing
 * Purpose:    Layer3 ipv6 header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_ipv6_parsing(parser_info_t *parser_info, ip_frag_t *frag, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;
    parser_ip_hash_ctl_t parser_ip_hash_ctl;
    parser_layer3_hash_ctl_t parser_layer3_hash_ctl;
    uint8 *l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;
    uint8 chip_id = parser_info->chip_id;
    uint8 ip_version = (l3_header[0] >> 4) & 0xF;
    uint8 is_xor = FALSE;
    uint8 crc = 0;
    uint32 cmd = 0;

    /* Refer to RFC2460 */
    l3_misc_info->min_length = IPV6_MIN_LEN;
    parser_result->layer3_type = L3_TYPE_IPV6;                 /* overwrite layer3 type */
    parser_result->l3_s.ip_options = FALSE;
    parser_result->l3_s.ip_header_error = (6 != ip_version);   /* IPv6 version check */
    parser_result->l3_s.tos.ip_tos = ((l3_header[0] & 0xF) << 4) | ((l3_header[1] >> 4) & 0xF);
    parser_result->l3_s.ttl = l3_header[7];
    parser_result->l3_s.ip_length = ((l3_header[4] & 0x3F) << 8) | l3_header[5];

    /* IP destination address fill */
    parser_result->l3_s.ip_da.ipv6.ipda_127_96 = MAKE_UINT32(l3_header[24], l3_header[25], l3_header[26], l3_header[27]);
    parser_result->l3_s.ip_da.ipv6.ipda_95_64 = MAKE_UINT32(l3_header[28], l3_header[29], l3_header[30], l3_header[31]);
    parser_result->l3_s.ip_da.ipv6.ipda_63_32 = MAKE_UINT32(l3_header[32], l3_header[33], l3_header[34], l3_header[35]);
    parser_result->l3_s.ip_da.ipv6.ipda_31_0 = MAKE_UINT32(l3_header[36], l3_header[37], l3_header[38], l3_header[39]);

    /* IP source address fill */
    parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 = MAKE_UINT32(l3_header[8], l3_header[9], l3_header[10], l3_header[11]);
    parser_result->l3_s.ip_sa.ipv6.ipsa_95_64 = MAKE_UINT32(l3_header[12], l3_header[13], l3_header[14], l3_header[15]);
    parser_result->l3_s.ip_sa.ipv6.ipsa_63_32 = MAKE_UINT32(l3_header[16], l3_header[17], l3_header[18], l3_header[19]);
    parser_result->l3_s.ip_sa.ipv6.ipsa_31_0 = MAKE_UINT32(l3_header[20], l3_header[21], l3_header[22], l3_header[23]);

    parser_result->l3_s.layer3_header_protocol = l3_header[6];
    parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + IPV6_HEADER_LEN;
    parser_result->l3_s.ipv6_flow_label = (((l3_header[1] & 0xF) << 16) | (l3_header[2] << 8) | l3_header[3]);

    parser_result->l3_s.more_frag = FALSE;
    frag->offset_is0 = TRUE;
    frag->offset_is1 = FALSE;

    /* IP hash calculate */
    sal_memset(&parser_ip_hash_ctl, 0, sizeof(parser_ip_hash_ctl_t));
    cmd = DRV_IOR(ParserIpHashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_ip_hash_ctl));

    sal_memset(&parser_layer3_hash_ctl, 0, sizeof(parser_layer3_hash_ctl_t));
    cmd = DRV_IOR(ParserLayer3HashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_layer3_hash_ctl));

    /* select CRC8_1 or ECMP XOR8 by ParserLayer3HashCtl.layer3EcmpHashType */
    is_xor = parser_layer3_hash_ctl.layer3_ecmp_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_ECMP,
                                                     PARSER_HASH_KEY_TYPE_IPV6,
                                                     is_xor,
                                                     &crc));
    parser_result->l3_s.ip_ecmp_hash = crc;

    /* select CRC8_2 or LINKAGG XOR8 by ParserLayer3HashCtl.layer3LinkAggHashType */
    is_xor = parser_layer3_hash_ctl.layer3_link_agg_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_LINKAGG,
                                                     PARSER_HASH_KEY_TYPE_IPV6,
                                                     is_xor,
                                                     &crc));

    if (parser_ip_hash_ctl.use_ip_hash)
    {
        parser_result->header_hash = crc;
    }

    /* IPV6_EXT_HEADER_TYPE */
    if (0 == parser_result->l3_s.layer3_header_protocol)         /* Hop-by-Hop Options */
    {
        parser_result->l3_s.ip_options = TRUE;
        l3_misc_info->min_length = IPV6_HOPBYHOP_MIN_LEN;
        parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + IPV6_HOPBYHOP_MIN_LEN ;
    }
    else if (44 == parser_result->l3_s.layer3_header_protocol)   /* Fragment Options */
    {
        frag->frag_data = MAKE_UINT16(l3_header[42], l3_header[43]);
        parser_result->l3_s.more_frag = IS_BIT_SET(frag->frag_data, 0);
        parser_result->l3_s.frag_offset = (frag->frag_data >> 3) & 0x1FFF;
        frag->offset_is0 = (0 == parser_result->l3_s.frag_offset);
        frag->offset_is1 = (0 != parser_result->l3_s.frag_offset)
                           && (parser_result->l3_s.frag_offset <= parser_ip_hash_ctl.small_fragment_offset);
        parser_result->l3_s.layer3_header_protocol = l3_header[40];
        parser_result->l3_s.ip_identification = MAKE_UINT16(l3_header[46], l3_header[47]);
        parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + IPV6_FRAGMENT_MIN_LEN;
        l3_misc_info->min_length = IPV6_FRAGMENT_MIN_LEN;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_arp_parsing
 * Purpose:    Layer3 ARP header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_arp_parsing(parser_info_t *parser_info, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;

    uint8 *l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;

    /* Refer to RFC826 */
    /* put ARP/RARP header senderIP to IPSA, targetIP to IPDA */
    l3_misc_info->min_length = ARP_RARP_MIN_LEN;
    parser_result->l3_s.ip_da.arp.arp_op_code = MAKE_UINT16(l3_header[6], l3_header[7]);
    parser_result->l3_s.ip_sa.arp.sender_ip = MAKE_UINT32(l3_header[14],l3_header[15],l3_header[16],l3_header[17]);
    parser_result->l3_s.ip_sa.arp.sender_mac_47_32 = MAKE_UINT16(l3_header[8], l3_header[9]);
    parser_result->l3_s.ip_sa.arp.sender_mac_31_0 = MAKE_UINT32(l3_header[10], l3_header[11],
                                                                l3_header[12], l3_header[13]);
    parser_result->l3_s.ip_da.arp.target_ip = MAKE_UINT32(l3_header[24],l3_header[25],l3_header[26],l3_header[27]);
    parser_result->l3_s.ip_da.arp.target_mac_47_32 = MAKE_UINT16(l3_header[18], l3_header[19]);
    parser_result->l3_s.ip_da.arp.target_mac_31_0 = MAKE_UINT32(l3_header[20], l3_header[21],
                                                                l3_header[22], l3_header[23]);
    parser_result->l3_s.ip_sa.arp.hardware_type = MAKE_UINT16(l3_header[0], l3_header[1]);
    parser_result->l3_s.ip_sa.arp.protocol_type = MAKE_UINT16(l3_header[2], l3_header[3]);
    parser_result->l3_s.ip_da.arp.hardware_add_len = l3_header[4];
    parser_result->l3_s.ip_da.arp.protocel_add_len = l3_header[5];

    parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + ARP_RARP_MIN_LEN ;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_mpls_parsing
 * Purpose:    Layer3 MPLS header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_mpls_parsing(parser_info_t *parser_info, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;
    parser_mpls_ctl_t parser_mpls_ctl;
    parser_layer3_hash_ctl_t parser_layer3_hash_ctl;

    uint8 chip_id = parser_info->chip_id;
    uint8 ip_header_offset = 0;
    uint8 label_num = 0;
    uint8 is_xor = FALSE;
    uint8 crc = 0;
    uint8 *l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;
    uint16 parser_length = parser_info->parser_length;
    uint32 cmd = 0;

    sal_memset(&parser_mpls_ctl, 0 ,sizeof(parser_mpls_ctl));
    cmd = DRV_IOR(ParserMplsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_mpls_ctl));

    sal_memset(&parser_layer3_hash_ctl, 0, sizeof(parser_layer3_hash_ctl_t));
    cmd = DRV_IOR(ParserLayer3HashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_layer3_hash_ctl));

    parser_result->l3_s.ttl = l3_header[3];

    /* label 0 - label 3 */
    parser_result->l3_s.ip_da.mpls.mpls_label0 = MAKE_UINT32(l3_header[0], l3_header[1], l3_header[2], l3_header[3]);
    parser_result->l3_s.ip_da.mpls.mpls_label1 = MAKE_UINT32(l3_header[4], l3_header[5], l3_header[6], l3_header[7]);
    parser_result->l3_s.ip_da.mpls.mpls_label2 = MAKE_UINT32(l3_header[8], l3_header[9], l3_header[10], l3_header[11]);
    parser_result->l3_s.ip_da.mpls.mpls_label3 = MAKE_UINT32(l3_header[12], l3_header[13], l3_header[14], l3_header[15]);

    /* label 4 - label 7 */
    parser_result->l3_s.ip_sa.mpls.mpls_label4 = MAKE_UINT32(l3_header[16], l3_header[17], l3_header[18], l3_header[19]);
    parser_result->l3_s.ip_sa.mpls.mpls_label5 = MAKE_UINT32(l3_header[20], l3_header[21], l3_header[22], l3_header[23]);
    parser_result->l3_s.ip_sa.mpls.mpls_label6 = MAKE_UINT32(l3_header[24], l3_header[25], l3_header[26], l3_header[27]);
    parser_result->l3_s.ip_sa.mpls.mpls_label7 = MAKE_UINT32(l3_header[28], l3_header[29], l3_header[30], l3_header[31]);

    if (parser_mpls_ctl.mpls_ecmp_use_reserve_label
        || ((parser_result->l3_s.ip_da.mpls.mpls_label0>>12) > parser_mpls_ctl.max_reserve_label))
    {
        SET_BIT(parser_info->mpls_hash_en, 0);
    }

    if ((parser_mpls_ctl.mpls_ecmp_use_reserve_label
        || ((parser_result->l3_s.ip_da.mpls.mpls_label1>>12) > parser_mpls_ctl.max_reserve_label))
        && (!IS_BIT_SET(l3_header[2], 0)))
    {
        SET_BIT(parser_info->mpls_hash_en, 1);
    }

    if ((parser_mpls_ctl.mpls_ecmp_use_reserve_label
        || ((parser_result->l3_s.ip_da.mpls.mpls_label2>>12) > parser_mpls_ctl.max_reserve_label))
        && (!IS_BIT_SET(l3_header[2], 0)) && (!IS_BIT_SET(l3_header[6], 0)))
    {
        SET_BIT(parser_info->mpls_hash_en, 2);
    }

    if ((parser_mpls_ctl.mpls_ecmp_use_reserve_label
        || ((parser_result->l3_s.ip_da.mpls.mpls_label3>>12) > parser_mpls_ctl.max_reserve_label))
        && (!IS_BIT_SET(l3_header[2], 0)) && (!IS_BIT_SET(l3_header[6], 0)) && (!IS_BIT_SET(l3_header[10], 0)))
    {
        SET_BIT(parser_info->mpls_hash_en, 3);
    }

    if ((parser_mpls_ctl.mpls_ecmp_use_reserve_label
        || ((parser_result->l3_s.ip_sa.mpls.mpls_label4>>12) > parser_mpls_ctl.max_reserve_label))
        && (!IS_BIT_SET(l3_header[2], 0)) && (!IS_BIT_SET(l3_header[6], 0))
        && (!IS_BIT_SET(l3_header[10], 0)) && (!IS_BIT_SET(l3_header[14], 0)))
    {
        SET_BIT(parser_info->mpls_hash_en, 4);
    }

    if ((parser_mpls_ctl.mpls_ecmp_use_reserve_label
        || ((parser_result->l3_s.ip_sa.mpls.mpls_label5>>12) > parser_mpls_ctl.max_reserve_label))
        && (!IS_BIT_SET(l3_header[2], 0)) && (!IS_BIT_SET(l3_header[6], 0)) && (!IS_BIT_SET(l3_header[10], 0))
        && (!IS_BIT_SET(l3_header[14], 0)) && (!IS_BIT_SET(l3_header[18], 0)))
    {
        SET_BIT(parser_info->mpls_hash_en, 5);
    }

    if ((parser_mpls_ctl.mpls_ecmp_use_reserve_label
        || ((parser_result->l3_s.ip_sa.mpls.mpls_label6>>12) > parser_mpls_ctl.max_reserve_label))
        && (!IS_BIT_SET(l3_header[2], 0)) && (!IS_BIT_SET(l3_header[6], 0)) && (!IS_BIT_SET(l3_header[10], 0))
        && (!IS_BIT_SET(l3_header[14], 0)) && (!IS_BIT_SET(l3_header[18], 0)) && (!IS_BIT_SET(l3_header[22], 0)))
    {
        SET_BIT(parser_info->mpls_hash_en, 6);
    }

    if ((parser_mpls_ctl.mpls_ecmp_use_reserve_label
        || ((parser_result->l3_s.ip_sa.mpls.mpls_label7>>12) > parser_mpls_ctl.max_reserve_label))
        && (!IS_BIT_SET(l3_header[2], 0)) && (!IS_BIT_SET(l3_header[6], 0)) && (!IS_BIT_SET(l3_header[10], 0))
        && (!IS_BIT_SET(l3_header[14], 0)) && (!IS_BIT_SET(l3_header[18], 0)) && (!IS_BIT_SET(l3_header[22], 0))
        && (!IS_BIT_SET(l3_header[26], 0)))
    {
        SET_BIT(parser_info->mpls_hash_en, 7);
    }

    /* get mpls label total number according to label stack flag(bit 0) */
    label_num = (IS_BIT_SET(l3_header[2], 0) << 7) | (IS_BIT_SET(l3_header[6], 0) << 6)
                | (IS_BIT_SET(l3_header[10], 0) << 5) | (IS_BIT_SET(l3_header[14], 0)<< 4)
                | (IS_BIT_SET(l3_header[18], 0) << 3) | (IS_BIT_SET(l3_header[22], 0)<< 2)
                | (IS_BIT_SET(l3_header[26], 0) << 1) | (IS_BIT_SET(l3_header[30], 0));

    if (0 == label_num)                                  /* 8'b0000_0000 */
    {
        parser_result->l3_s.tos.mpls.label_num = 9;
    }
    else if (1 == label_num)                             /* 8'b0000_0001 */
    {
        parser_result->l3_s.tos.mpls.label_num = 8;
    }
    else if ((label_num >= 2) && (label_num <= 3))       /* 8'b0000_001x */
    {
        parser_result->l3_s.tos.mpls.label_num = 7;
    }
    else if ((label_num >= 4) && (label_num <= 7))       /* 8'b0000_01xx */
    {
        parser_result->l3_s.tos.mpls.label_num = 6;
    }
    else if ((label_num >= 8) && (label_num <= 15))      /* 8'b0000_1xxx */
    {
        parser_result->l3_s.tos.mpls.label_num = 5;
    }
    else if ((label_num >= 16) && (label_num <= 31))     /* 8'b0001_xxxx */
    {
        parser_result->l3_s.tos.mpls.label_num = 4;
    }
    else if ((label_num >= 32) && (label_num <= 63))     /* 8'b001x_xxxx */
    {
        parser_result->l3_s.tos.mpls.label_num = 3;
    }
    else if ((label_num >= 64) && (label_num <= 127))    /* 8'b01xx_xxxx */
    {
        parser_result->l3_s.tos.mpls.label_num = 2;
    }
    else if (label_num >= 128)                           /* 8'b1xxx_xxxx */
    {
        parser_result->l3_s.tos.mpls.label_num = 1;
    }

    parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + (parser_result->l3_s.tos.mpls.label_num << 2);
    ip_header_offset = parser_result->l3_s.tos.mpls.label_num << 2;
    l3_misc_info->min_length = ip_header_offset;

    if ((parser_result->l3_s.tos.mpls.label_num <= 8)
        && (4 == ((l3_header[ip_header_offset] >> 4) & 0xF))
        && ((parser_length - parser_result->l2_s.layer3_offset) >= (ip_header_offset + IPV4_MIN_LEN))
        && (0xF != parser_mpls_ctl.mpls_ip_hash_disable))
    {
        /* IPV4 payload */
        l3_misc_info->min_length = ip_header_offset + IPV4_MIN_LEN;
        parser_result->l3_s.tos.mpls.ip_over_mpls = TRUE;

        /* select CRC8_1 or ECMP XOR8 by ParserLayer3HashCtl.layer3EcmpHashType */
        is_xor = parser_layer3_hash_ctl.layer3_ecmp_hash_type;
        DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                         PARSER_USAGE_TYPE_ECMP,
                                                         PARSER_HASH_KEY_TYPE_IPV4_OVER_MPLS,
                                                         is_xor,
                                                         &crc));
        parser_result->l3_s.ip_ecmp_hash = crc;

        /* select CRC8_2 or LINKAGG XOR8 by ParserLayer3HashCtl.layer3LinkAggHashType */
        is_xor = parser_layer3_hash_ctl.layer3_link_agg_hash_type;
        DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                         PARSER_USAGE_TYPE_LINKAGG,
                                                         PARSER_HASH_KEY_TYPE_IPV4_OVER_MPLS,
                                                         is_xor,
                                                         &crc));

        if (parser_mpls_ctl.use_mpls_hash)
        {
            parser_result->header_hash = crc;
        }
    }
    else if ((parser_result->l3_s.tos.mpls.label_num <= 8)
            && (6 == ((l3_header[ip_header_offset] >> 4) & 0xF))
            && ((parser_length - parser_result->l2_s.layer3_offset) >= (ip_header_offset + IPV6_MIN_LEN + 4))
            && (0xF != parser_mpls_ctl.mpls_ip_hash_disable))
    {
        /* IPV6 payload */
        l3_misc_info->min_length = ip_header_offset + IPV6_MIN_LEN;
        parser_result->l3_s.tos.mpls.ip_over_mpls = TRUE;

        /* select CRC8_1 or ECMP XOR8 by ParserLayer3HashCtl.layer3EcmpHashType */
        is_xor = parser_layer3_hash_ctl.layer3_ecmp_hash_type;
        DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                         PARSER_USAGE_TYPE_ECMP,
                                                         PARSER_HASH_KEY_TYPE_IPV6_OVER_MPLS,
                                                         is_xor,
                                                         &crc));
        parser_result->l3_s.ip_ecmp_hash = crc;

        /* select CRC8_2 or LINKAGG XOR8 by ParserLayer3HashCtl.layer3LinkAggHashType */
        is_xor = parser_layer3_hash_ctl.layer3_link_agg_hash_type;
        DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                         PARSER_USAGE_TYPE_LINKAGG,
                                                         PARSER_HASH_KEY_TYPE_IPV6_OVER_MPLS,
                                                         is_xor,
                                                         &crc));

        if (parser_mpls_ctl.use_mpls_hash)
        {
            parser_result->header_hash = crc;
        }

    }
    else
    {
        parser_result->l3_s.tos.mpls.ip_over_mpls = FALSE;

        /* select CRC8_1 or ECMP XOR8 by ParserLayer3HashCtl.layer3EcmpHashType */
        is_xor = parser_layer3_hash_ctl.layer3_ecmp_hash_type;
        DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                         PARSER_USAGE_TYPE_ECMP,
                                                         PARSER_HASH_KEY_TYPE_MPLS,
                                                         is_xor,
                                                         &crc));
        parser_result->l3_s.ip_ecmp_hash = crc;

        /* select CRC8_2 or LINKAGG XOR8 by ParserLayer3HashCtl.layer3LinkAggHashType */
        is_xor = parser_layer3_hash_ctl.layer3_link_agg_hash_type;
        DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                         PARSER_USAGE_TYPE_LINKAGG,
                                                         PARSER_HASH_KEY_TYPE_MPLS,
                                                         is_xor,
                                                         &crc));

        if (parser_mpls_ctl.use_mpls_hash)
        {
            parser_result->header_hash = crc;
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_pbb_cmac_parsing
 * Purpose:    Layer3 PBB header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_pbb_cmac_parsing(parser_info_t *parser_info, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t* parser_result = parser_info->parser_result;
    parser_ethernet_ctl_t parser_eth_ctl;
    parser_pbb_ctl_t parser_pbb_ctl;
    parser_layer3_hash_ctl_t parser_layer3_hash_ctl;

    uint8 chip_id = parser_info->chip_id;
    uint8 vlan_num = 0;
    uint8 vlan_offset = 0;
    uint8 is_cvlan_tpid = FALSE, is_svlan_tpid = FALSE;
    uint8* pkt = parser_info->pkt;
    uint8* l3_header = pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;
    uint8 is_xor = FALSE;
    uint8 crc = 0;
    uint16 cfg_svlan_tpid = 0;
    uint32 cmd = 0;

    sal_memset(&parser_eth_ctl, 0, sizeof(parser_eth_ctl));
    cmd = DRV_IOR(ParserEthernetCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_eth_ctl));

    sal_memset(&parser_pbb_ctl, 0, sizeof(parser_pbb_ctl));
    cmd = DRV_IOR(ParserPbbCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_pbb_ctl));

    parser_result->l3_s.ip_da.cmac.itag_tci.itag_tci= MAKE_UINT32(l3_header[0], l3_header[1], l3_header[2], l3_header[3]);

    if (parser_pbb_ctl.pbb_oam_ether_type_offset)         /* No CMAC encapsulated PBB CFM */
    {
        l3_misc_info->cmac_type_or_length = MAKE_UINT16(l3_header[4], l3_header[5]);
        l3_misc_info->min_length = PBB_NO_CMAC_MIN_LEN;   /* ISID + TYPE */
        parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + PBB_NO_CMAC_MIN_LEN ;
    }
    else
    {
        parser_result->l3_s.ip_da.cmac.cmac_da_47_32 = MAKE_UINT16(l3_header[4], l3_header[5]);
        parser_result->l3_s.ip_da.cmac.cmac_da_31_0  = MAKE_UINT32(l3_header[6], l3_header[7],
                                                                   l3_header[8], l3_header[9]);

        parser_result->l3_s.ip_sa.cmac.cmac_sa_47_32 = MAKE_UINT16(l3_header[10], l3_header[11]);
        parser_result->l3_s.ip_sa.cmac.cmac_sa_31_0 = MAKE_UINT32(l3_header[12], l3_header[13],
                                                                  l3_header[14], l3_header[15]);

        switch (parser_info->svlan_tpid_index)
        {
            case 0:
               cfg_svlan_tpid = parser_eth_ctl.svlan_tpid0;
               break;

            case 1:
                cfg_svlan_tpid = parser_eth_ctl.svlan_tpid1;
                break;

            case 2:
                cfg_svlan_tpid = parser_eth_ctl.svlan_tpid2;
                break;

            default:
                cfg_svlan_tpid = parser_eth_ctl.svlan_tpid3;
                break;
        }

        /* decide number of VLANs */
        is_svlan_tpid = (MAKE_UINT16(l3_header[16], l3_header[17]) == cfg_svlan_tpid);

        if (is_svlan_tpid)
        {
            is_cvlan_tpid = (MAKE_UINT16(l3_header[20], l3_header[21]) == parser_eth_ctl.cvlan_tpid);
        }
        else
        {
            is_cvlan_tpid = (MAKE_UINT16(l3_header[16], l3_header[17]) == parser_eth_ctl.cvlan_tpid);
        }

        vlan_num = is_cvlan_tpid + is_svlan_tpid;

        if (vlan_num > parser_pbb_ctl.pbb_vlan_parsing_num)
        {
            vlan_num = parser_pbb_ctl.pbb_vlan_parsing_num;
        }

        if ((vlan_num == 1) && (cfg_svlan_tpid == parser_eth_ctl.cvlan_tpid)
            && parser_pbb_ctl.pbb_outer_vlan_is_cvlan)
        {
            is_svlan_tpid = FALSE;
            is_cvlan_tpid = TRUE;
        }

        if (2 == (vlan_num & 0x3))
        {
            vlan_offset = 8;

            parser_result->l3_s.ip_da.cmac.cmac_svlan_valid = TRUE;
            parser_result->l3_s.ip_sa.cmac.cmac_cvlan_valid = TRUE;
            parser_result->l3_s.ip_da.cmac.cmac_svlan_id = ((l3_header[18] & 0xF) << 8) | l3_header[19];
            parser_result->l3_s.ip_sa.cmac.cmac_cvlan_id = ((l3_header[22] & 0xF) << 8) | l3_header[23];

            parser_result->l3_s.ip_da.cmac.cmac_stag_cos = (l3_header[18] >> 5) & 0x7;
            parser_result->l3_s.ip_sa.cmac.cmac_ctag_cos = (l3_header[22] >> 5) & 0x7;
            parser_result->l3_s.ip_da.cmac.cmac_stag_cfi = IS_BIT_SET(l3_header[18], 4);
            parser_result->l3_s.ip_sa.cmac.cmac_ctag_cfi = IS_BIT_SET(l3_header[22], 4);
        }
        else if (1 == (vlan_num & 0x3))
        {
            vlan_offset = 4;

            if (is_svlan_tpid)
            {
                parser_result->l3_s.ip_da.cmac.cmac_svlan_valid = TRUE;
                parser_result->l3_s.ip_sa.cmac.cmac_cvlan_valid = FALSE;
                parser_result->l3_s.ip_da.cmac.cmac_svlan_id = ((l3_header[18] & 0xF) << 8) | l3_header[19];
                parser_result->l3_s.ip_sa.cmac.cmac_cvlan_id = 0;

                parser_result->l3_s.ip_da.cmac.cmac_stag_cos = (l3_header[18] >> 5) & 0x7;
                parser_result->l3_s.ip_sa.cmac.cmac_ctag_cos = 0;
                parser_result->l3_s.ip_da.cmac.cmac_stag_cfi = IS_BIT_SET(l3_header[18], 4);
                parser_result->l3_s.ip_sa.cmac.cmac_ctag_cfi = 0;
            }
            else
            {
                parser_result->l3_s.ip_sa.cmac.cmac_cvlan_valid = TRUE;
                parser_result->l3_s.ip_da.cmac.cmac_svlan_valid = FALSE;
                parser_result->l3_s.ip_sa.cmac.cmac_cvlan_id = ((l3_header[18] & 0xF) << 8) | l3_header[19];
                parser_result->l3_s.ip_da.cmac.cmac_svlan_id = 0;

                parser_result->l3_s.ip_sa.cmac.cmac_ctag_cos = (l3_header[18] >> 5) & 0x7;
                parser_result->l3_s.ip_da.cmac.cmac_stag_cos = 0;
                parser_result->l3_s.ip_sa.cmac.cmac_ctag_cfi = IS_BIT_SET(l3_header[18], 4);
                parser_result->l3_s.ip_da.cmac.cmac_stag_cfi = 0;
            }
        }
        else
        {
            vlan_offset = 0;

            parser_result->l3_s.ip_da.cmac.cmac_svlan_valid = FALSE;
            parser_result->l3_s.ip_sa.cmac.cmac_cvlan_valid = FALSE;
            parser_result->l3_s.ip_da.cmac.cmac_svlan_id = 0;
            parser_result->l3_s.ip_sa.cmac.cmac_cvlan_id = 0;

            parser_result->l3_s.ip_da.cmac.cmac_stag_cos = 0;
            parser_result->l3_s.ip_sa.cmac.cmac_ctag_cos = 0;
            parser_result->l3_s.ip_da.cmac.cmac_stag_cfi = 0;
            parser_result->l3_s.ip_sa.cmac.cmac_ctag_cfi = 0;
        }

        l3_misc_info->cmac_type_or_length = MAKE_UINT16(l3_header[16 + vlan_offset], l3_header[17 + vlan_offset]);
        l3_misc_info->min_length = (vlan_num << 2) + PBB_CMAC_MIN_LEN;               /* ISID + CMAC + TYPE + VLAN  */
        parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + 4;   /* ISID, layer3Offset point to start of CMAC DA */
    }


    sal_memset(&parser_layer3_hash_ctl, 0, sizeof(parser_layer3_hash_ctl_t));
    cmd = DRV_IOR(ParserLayer3HashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_layer3_hash_ctl));

    /* select CRC8_1 or ECMP XOR8 by ParserLayer3HashCtl.layer3EcmpHashType */
    is_xor = parser_layer3_hash_ctl.layer3_ecmp_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_ECMP,
                                                     PARSER_HASH_KEY_TYPE_PBB_MAC,
                                                     is_xor,
                                                     &crc));
    parser_result->l3_s.ip_sa.cmac.cmac_ecmp_hash = crc;

    /* select CRC8_2 or LINKAGG XOR8 by ParserLayer3HashCtl.layer3LinkAggHashType */
    is_xor = parser_layer3_hash_ctl.layer3_link_agg_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_LINKAGG,
                                                     PARSER_HASH_KEY_TYPE_PBB_MAC,
                                                     is_xor,
                                                     &crc));
    parser_result->l3_s.ip_sa.cmac.cmac_header_hash = crc;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_ethernet_oam_parser
 * Purpose:    Ethernet OAM header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_ethernet_oam_parser(parser_info_t *parser_info, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;

    uint8 *l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;

    /* Refer to IEEE802.1ag & ITU Y.1731 */
    l3_misc_info->min_length = 4 ;

    parser_result->l3_s.ip_da.eth_oam.eth_oam_level = (l3_header[0] >> 5) & 0x7;
    parser_result->l3_s.ip_da.eth_oam.ether_oam_version = l3_header[0] & 0x1F;
    parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code = l3_header[1];

    if (OAM_OP_CCM == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code)            /* CCM */
    {
        l3_misc_info->min_length = L3_OAM_CCM_MIN_LEN;
        parser_result->l3_s.ip_sa.eth_oam.tx_fcf = MAKE_UINT32(l3_header[58], l3_header[59], l3_header[60], l3_header[61]);
        parser_result->l3_s.ip_sa.eth_oam.rx_fcb = MAKE_UINT32(l3_header[62], l3_header[63], l3_header[64], l3_header[65]);
        parser_result->l3_s.ip_sa.eth_oam.tx_fcb = MAKE_UINT32(l3_header[66], l3_header[67], l3_header[68], l3_header[69]);
    }
    else if ((OAM_OP_LMM == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code)
             || (OAM_OP_LMR == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code))   /* LMM or LMR */
    {
        l3_misc_info->min_length = L3_OAM_LMM_MIN_LEN;
        parser_result->l3_s.ip_sa.eth_oam.tx_fcf = MAKE_UINT32(l3_header[4], l3_header[5], l3_header[6], l3_header[7]);
        parser_result->l3_s.ip_sa.eth_oam.rx_fcb = MAKE_UINT32(l3_header[8], l3_header[9], l3_header[10], l3_header[11]);
        parser_result->l3_s.ip_sa.eth_oam.tx_fcb = MAKE_UINT32(l3_header[12], l3_header[13], l3_header[14], l3_header[15]);
    }
    parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + l3_misc_info->min_length;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_slow_protocol_parser
 * Purpose:    Layer3 slow protocol header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_slow_protocol_parser(parser_info_t *parser_info, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;

    uint8 *l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;

    /* Refer to IEEE802.3 */
    l3_misc_info->min_length = 4;

    parser_result->l3_s.ip_da.slow_ptl.slow_protocol_sub_type = l3_header[0];                        /* subType */
    parser_result->l3_s.ip_da.slow_ptl.slow_protocol_flags = MAKE_UINT16(l3_header[1], l3_header[2]);   /* Flags */
    parser_result->l3_s.ip_da.slow_ptl.slow_protocol_code = l3_header[3];                            /* Code */

    parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + 4;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_fcoe_parser
 * Purpose:    FCoE header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_fcoe_parser(parser_info_t *parser_info, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;
    parser_fcoe_ctl_t parser_fcoe_ctl;
    parser_layer3_hash_ctl_t parser_layer3_hash_ctl;

    uint8 chip_id = parser_info->chip_id;
    uint8 *l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;
    uint8 is_xor = FALSE;
    uint8 crc = 0;
    uint32 cmd = 0;

    /* Refer to FC-BB-5 */
    sal_memset(&parser_fcoe_ctl, 0, sizeof(parser_fcoe_ctl));
    cmd = DRV_IOR(ParserFcoeCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_fcoe_ctl));

    l3_misc_info->min_length = L3_FCOE_MIN_LEN;

    parser_result->l3_s.ip_da.fcoe.fcoe_did = (l3_header[15] << 16) | (l3_header[16] << 8) | l3_header[17];   /* FC D-ID */
    parser_result->l3_s.ip_sa.fcoe.fcoe_sid = (l3_header[19] << 16) | (l3_header[20] << 8) | l3_header[21];   /* FC S-ID */

    parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + l3_misc_info->min_length;

    sal_memset(&parser_layer3_hash_ctl, 0, sizeof(parser_layer3_hash_ctl_t));
    cmd = DRV_IOR(ParserLayer3HashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_layer3_hash_ctl));

    /* select CRC8_1 or ECMP XOR8 by ParserLayer3HashCtl.layer3EcmpHashType */
    is_xor = parser_layer3_hash_ctl.layer3_ecmp_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_ECMP,
                                                     PARSER_HASH_KEY_TYPE_FCOE,
                                                     is_xor,
                                                     &crc));
    parser_result->l3_s.ip_ecmp_hash = crc;

    /* select CRC8_2 or LINKAGG XOR8 by ParserLayer3HashCtl.layer3LinkAggHashType */
    is_xor = parser_layer3_hash_ctl.layer3_link_agg_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_LINKAGG,
                                                     PARSER_HASH_KEY_TYPE_FCOE,
                                                     is_xor,
                                                     &crc));

    if (parser_fcoe_ctl.use_fcoe_hash)
    {
        parser_result->header_hash = crc;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_trill_parser
 * Purpose:    Trill header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_trill_parser(parser_info_t *parser_info, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;
    parser_trill_ctl_t parser_trill_ctl;
    parser_layer3_hash_ctl_t parser_layer3_hash_ctl;

    uint8 chip_id = parser_info->chip_id;
    uint8 *l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;
    uint8 is_all_egress_rbridge = FALSE;
    uint8 is_xor = FALSE;
    uint8 crc = 0;
    uint16 trill_channel_protocol = 0;
    uint32 trill_bfd_my_discriminator = 0;
    uint32 cmd = 0;

    /* Refer to RFC6325 */
    sal_memset(&parser_trill_ctl, 0, sizeof(parser_trill_ctl));
    cmd = DRV_IOR(ParserTrillCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_trill_ctl));

    l3_misc_info->min_length = L3_TRILL_MIN_LEN;
    parser_result->l3_s.ip_da.trill.trill_version = (l3_header[0] >> 6) & 0x3;
    parser_result->l3_s.ip_da.trill.trill_multicast = IS_BIT_SET(l3_header[0], 3);

    parser_result->l3_s.ttl = l3_header[1] & 0x3F;
    parser_result->l3_s.ip_options = ((((l3_header[0] & 0x7) << 2) | ((l3_header[1] >> 6) & 0x3)) != 0);
    parser_result->l3_s.ip_da.trill.egress_nick_name = MAKE_UINT16(l3_header[2], l3_header[3]);
    parser_result->l3_s.ip_sa.trill.ingress_nick_name = MAKE_UINT16(l3_header[4], l3_header[5]);

    if (!parser_result->l3_s.ip_options)
    {
        if ((parser_trill_ctl.trill_inner_tpid == MAKE_UINT16(l3_header[18], l3_header[19]))
            ||((0x8100 == MAKE_UINT16(l3_header[18], l3_header[19])) && parser_trill_ctl.inner_vlan_tpid_mode))
        {
            parser_result->l3_s.ip_da.trill.trill_inner_vlan_valid = TRUE;
            parser_result->l3_s.ip_da.trill.trill_inner_vlan_id = ((l3_header[20] & 0xF) << 8) | l3_header[21];

            if (0x0800 == MAKE_UINT16(l3_header[22], l3_header[23]))
            {
                parser_result->l3_s.ip_da.trill.trill_length = 24 + (((l3_header[26] & 0x3F) << 8) | l3_header[27]);  /* ip TotalLength */
            }
        }
        else
        {
            if (0x0800 == MAKE_UINT16(l3_header[18], l3_header[19]))
            {
                parser_result->l3_s.ip_da.trill.trill_length = 20 + (((l3_header[22] & 0x3F) << 8) | l3_header[23]);  /* ip TotalLength */
            }
        }

        is_all_egress_rbridge = (l3_header[11] == 0x42) && (l3_header[10] == 0)
                                   && (l3_header[9] == 0) && (l3_header[8] == 0xC2)
                                   && (l3_header[7] == 0x80) && (l3_header[6] == 0x1);

        /* ESADI packet */
        if (parser_result->l3_s.ip_da.trill.trill_inner_vlan_valid)
        {
            parser_result->l3_s.ip_da.trill.is_esadi = is_all_egress_rbridge
                                                      && (parser_trill_ctl.esadi_no_check_ether_type
                                                          || ((l3_header[22] == 0x22)&&(l3_header[23] == 0xF4)));

        }
        else
        {
            parser_result->l3_s.ip_da.trill.is_esadi = is_all_egress_rbridge
                                                      && (parser_trill_ctl.esadi_no_check_ether_type
                                                          || ((l3_header[18] == 0x22)&&(l3_header[19] == 0xF4)));
        }

        /* trill channel */
        if (parser_result->l3_s.ip_da.trill.trill_inner_vlan_valid)
        {
            parser_result->l3_s.ip_da.trill.is_trill_channel =
                (MAKE_UINT16(l3_header[22], l3_header[23]) == parser_trill_ctl.r_bridge_channel_ether_type)
               && (parser_trill_ctl.trill_channel_no_check_inner_mac || is_all_egress_rbridge);
            trill_channel_protocol = ((l3_header[24]&0xF) << 8) | l3_header[25];
            parser_result->l3_s.ip_da.trill.trill_multi_hop = IS_BIT_SET(l3_header[26], 6);
        }
        else
        {
            parser_result->l3_s.ip_da.trill.is_trill_channel =
                (MAKE_UINT16(l3_header[18], l3_header[19]) == parser_trill_ctl.r_bridge_channel_ether_type)
               && (parser_trill_ctl.trill_channel_no_check_inner_mac || is_all_egress_rbridge);
            trill_channel_protocol = ((l3_header[20]&0xF) << 8) | l3_header[21];
            parser_result->l3_s.ip_da.trill.trill_multi_hop = IS_BIT_SET(l3_header[22], 6);
        }

        /* trill BFD */
        parser_result->l3_s.ip_da.trill.is_trill_bfd_echo =
                (trill_channel_protocol == parser_trill_ctl.trill_bfd_echo_channel_protocol);

        if ((trill_channel_protocol == parser_trill_ctl.trill_bfd_oam_channel_protocol0)
           || (trill_channel_protocol == parser_trill_ctl.trill_bfd_oam_channel_protocol1))
        {
            parser_result->l3_s.ip_da.trill.is_trill_bfd = TRUE;
        }
        else
        {
            parser_result->l3_s.ip_da.trill.is_trill_bfd = FALSE;
        }

        if (parser_result->l3_s.ip_da.trill.is_trill_bfd && parser_result->l3_s.ip_da.trill.trill_inner_vlan_valid)
        {
            trill_bfd_my_discriminator = MAKE_UINT32(l3_header[36], l3_header[37],
                                                     l3_header[38], l3_header[39]);
            parser_result->l3_s.ip_da.trill.trill_bfd_my_discriminator12_0 = trill_bfd_my_discriminator & 0x1FFF;
            parser_result->l3_s.ip_da.trill.trill_bfd_my_discriminator31_13 = (trill_bfd_my_discriminator >> 13) & 0x7FFFF;
        }
        else if (parser_result->l3_s.ip_da.trill.is_trill_bfd)
        {
            trill_bfd_my_discriminator = MAKE_UINT32(l3_header[32], l3_header[33],
                                                     l3_header[34], l3_header[35]);
            parser_result->l3_s.ip_da.trill.trill_bfd_my_discriminator12_0 = trill_bfd_my_discriminator & 0x1FFF;
            parser_result->l3_s.ip_da.trill.trill_bfd_my_discriminator31_13 = (trill_bfd_my_discriminator >> 13) & 0x7FFFF;
        }
    }

    parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + l3_misc_info->min_length;

    sal_memset(&parser_layer3_hash_ctl, 0, sizeof(parser_layer3_hash_ctl_t));
    cmd = DRV_IOR(ParserLayer3HashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_layer3_hash_ctl));

    /* select CRC8_1 or ECMP XOR8 by ParserLayer3HashCtl.layer3EcmpHashType */
    is_xor = parser_layer3_hash_ctl.layer3_ecmp_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_ECMP,
                                                     PARSER_HASH_KEY_TYPE_TRILL,
                                                     is_xor,
                                                     &crc));
    parser_result->l3_s.ip_ecmp_hash = crc;

    /* select CRC8_2 or LINKAGG XOR8 by ParserLayer3HashCtl.layer3LinkAggHashType */
    is_xor = parser_layer3_hash_ctl.layer3_link_agg_hash_type;
    DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                     PARSER_USAGE_TYPE_LINKAGG,
                                                     PARSER_HASH_KEY_TYPE_TRILL,
                                                     is_xor,
                                                     &crc));

    if (parser_trill_ctl.usetrill_hash)
    {
        parser_result->header_hash = crc;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_ptp_parser
 * Purpose:    PTP header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_ptp_parser(parser_info_t *parser_info, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;

    uint8 *l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;

    /* Refer to IEEE1588 */
    parser_result->l3_s.ip_da.ptp.ptp_version = ((l3_header[1] & 0xF) > 2) ? 3 : (l3_header[1] & 0x3);

    if (IS_BIT_SET(parser_result->l3_s.ip_da.ptp.ptp_version, 1))   /* version 2 and above */
    {
        parser_result->l3_s.ip_da.ptp.ptp_message_type = l3_header[0] & 0xF;
        parser_result->l3_s.ip_da.ptp.ptp_correction_field_63_32= MAKE_UINT32(l3_header[8], l3_header[9], l3_header[10], l3_header[11]);
        parser_result->l3_s.ip_da.ptp.ptp_correction_field_31_0 = MAKE_UINT32(l3_header[12], l3_header[13], l3_header[14], l3_header[15]);

        parser_result->l3_s.ip_sa.ptp.ptp_timestamp_63_32 = MAKE_UINT32(l3_header[36], l3_header[37], l3_header[38], l3_header[39]);
        parser_result->l3_s.ip_sa.ptp.ptp_timestamp_31_0 = MAKE_UINT32(l3_header[40], l3_header[41], l3_header[42], l3_header[43]);

        l3_misc_info->min_length = L3_PTP_V2_MIN_LEN;
    }
    else
    {
        parser_result->l3_s.ip_sa.ptp.ptp_timestamp_63_32 = MAKE_UINT32(l3_header[40], l3_header[41], l3_header[42], l3_header[43]);
        parser_result->l3_s.ip_sa.ptp.ptp_timestamp_31_0 = MAKE_UINT32(l3_header[44], l3_header[45], l3_header[46], l3_header[47]);

        l3_misc_info->min_length = L3_PTP_V1_MIN_LEN;
    }

    parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + l3_misc_info->min_length;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_flex_parsing
 * Purpose:    Layer3 flexible header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_flex_parsing(parser_info_t *parser_info, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;
    parser_layer3_flex_ctl_t parser_l3_flex_ctl;

    uint8 chip_id = parser_info->chip_id;
    uint8 *l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;
    uint32 cmd = 0;

    sal_memset(&parser_l3_flex_ctl, 0, sizeof(parser_layer3_flex_ctl_t));
    cmd = DRV_IOR(ParserLayer3FlexCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_l3_flex_ctl));

    parser_result->l3_s.layer3_header_protocol = l3_header[parser_l3_flex_ctl.layer3_protocol_byte_select];

    parser_result->l3_s.ip_da.flex_l3.flex_data_63_32
        = MAKE_UINT32(l3_header[parser_l3_flex_ctl.layer3_byte_select0],
                      l3_header[parser_l3_flex_ctl.layer3_byte_select1],
                      l3_header[parser_l3_flex_ctl.layer3_byte_select2],
                      l3_header[parser_l3_flex_ctl.layer3_byte_select3]);
    parser_result->l3_s.ip_da.flex_l3.flex_data_31_0
        = MAKE_UINT32(l3_header[parser_l3_flex_ctl.layer3_byte_select4],
                      l3_header[parser_l3_flex_ctl.layer3_byte_select5],
                      l3_header[parser_l3_flex_ctl.layer3_byte_select6],
                      l3_header[parser_l3_flex_ctl.layer3_byte_select7]);

    parser_result->l3_s.layer4_offset = parser_result->l2_s.layer3_offset + parser_l3_flex_ctl.layer3_basic_offset;
    l3_misc_info->min_length = parser_l3_flex_ctl.layer3_min_length;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_protocol_lookup
 * Purpose:    Layer3 protocol lookup.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_protocol_lookup(parser_info_t *parser_info, ip_frag_t *frag, parse_misc_info_t *l3_misc_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;
    parser_ip_hash_ctl_t parser_ip_hash_ctl;
    parser_layer3_protocol_ctl_t l3_pro_ctl;
    parser_pbb_ctl_t pbb_ctl;
    parser_layer3_protocol_cam_t l3_pro_cam;
    parser_layer3_protocol_cam_valid_t l3_pro_cam_valid;

    uint8 chip_id = parser_info->chip_id;
    uint8 index = 0;
    uint8 frag_key = 0;
    uint8 is_ip = FALSE, is_ipv4 = FALSE, is_ipv6 = FALSE;
    uint8 is_tcp = FALSE, is_udp = FALSE, is_gre = FALSE, is_icmp = FALSE;
    uint8 is_igmp = FALSE, is_ip_in_ip = FALSE, is_v6_in_ip = FALSE;
    uint8 is_ip_in_v6 = FALSE, is_v6_in_v6 = FALSE, is_pbb_itag_oam = FALSE;
    uint8 is_rdp = FALSE, is_sctp = FALSE, is_dccp = FALSE;
    uint32 l3_cam_layer3_type = 0, l3_cam_layer3_type_mask = 0;
    uint32 l3_cam_layer3_header_protocol = 0, l3_cam_layer3_header_protocol_mask = 0;
    uint32 l3_cam_layer4_type = 0, l3_cam_additional_offset = 0;
    uint32 field_id = 0;
    uint32 cmd = 0;

    sal_memset(&l3_pro_ctl, 0, sizeof(parser_layer3_protocol_ctl_t));
    cmd = DRV_IOR(ParserLayer3ProtocolCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l3_pro_ctl));

    sal_memset(&parser_ip_hash_ctl, 0, sizeof(parser_ip_hash_ctl_t));
    cmd = DRV_IOR(ParserIpHashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_ip_hash_ctl));

    sal_memset(&pbb_ctl, 0, sizeof(parser_pbb_ctl_t));
    cmd = DRV_IOR(ParserPbbCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &pbb_ctl));

    is_ip = ((L3_TYPE_IP == parser_result->layer3_type)
             || (L3_TYPE_IPV4 == parser_result->layer3_type)
             || (L3_TYPE_IPV6 == parser_result->layer3_type));
    is_ipv4 = (L3_TYPE_IPV4 == parser_result->layer3_type);
    is_ipv6 = (L3_TYPE_IPV6 == parser_result->layer3_type);
    is_tcp = is_ip && (6 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.tcp_type_en;
    is_udp = is_ip && (17 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.udp_type_en;
    is_gre = is_ip && (47 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.gre_type_en;
    is_icmp = ((is_ipv4 && (1 == parser_result->l3_s.layer3_header_protocol))
               ||(is_ipv6 && (58 == parser_result->l3_s.layer3_header_protocol))) && l3_pro_ctl.icmp_type_en;
    is_igmp = is_ipv4 && (2 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.igmp_type_en;
    is_ip_in_ip = is_ipv4 && (4 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.ipinip_type_en;
    is_v6_in_ip = is_ipv4 && (41 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.v6inip_type_en;
    is_ip_in_v6 = is_ipv6 && (4 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.ipinv6_type_en;
    is_v6_in_v6 = is_ipv6 && (41 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.v6inv6_type_en;
    is_pbb_itag_oam = (L3_TYPE_CMAC == parser_result->layer3_type)
                      && (0x8902 == l3_misc_info->cmac_type_or_length)
                      && (pbb_ctl.nca_value != parser_result->l3_s.ip_da.cmac.itag_tci.share.nca)
                      && l3_pro_ctl.pbb_itag_oam_type_en;
    is_rdp = is_ip && (27 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.rdp_type_en;
    is_sctp = is_ip && (132 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.sctp_type_en;
    is_dccp = is_ip && (33 == parser_result->l3_s.layer3_header_protocol) && l3_pro_ctl.dccp_type_en;

    if (is_dccp)
    {
        parser_result->layer4_type = L4_TYPE_DCCP;
    }
    else if (is_sctp)
    {
        parser_result->layer4_type = L4_TYPE_SCTP;
    }
    else if (is_rdp)
    {
        parser_result->layer4_type = L4_TYPE_RDP;
    }
    else if (is_pbb_itag_oam)
    {
        parser_result->layer4_type = L4_TYPE_PBB_ITAG_OAM;
    }
    else if (is_tcp)
    {
        parser_result->layer4_type  = L4_TYPE_TCP;
    }
    else if (is_udp)
    {
        parser_result->layer4_type  = L4_TYPE_UDP;
    }
    else if (is_gre)
    {
        parser_result->layer4_type  = L4_TYPE_GRE;
    }
    else if (is_icmp)
    {
        parser_result->layer4_type  = L4_TYPE_ICMP;
    }
    else if (is_igmp)
    {
        parser_result->layer4_type  = L4_TYPE_IGMP;
    }
    else if (is_ip_in_ip)
    {
        parser_result->layer4_type  = L4_TYPE_IP_IN_IP;
    }
    else if (is_v6_in_ip)
    {
        parser_result->layer4_type  = L4_TYPE_V6_IN_IP;
    }
    else if (is_ip_in_v6)
    {
        parser_result->layer4_type  = L4_TYPE_IP_IN_V6;
    }
    else if (is_v6_in_v6)
    {
        parser_result->layer4_type  = L4_TYPE_V6_IN_V6;
    }
    else
    {
        cmd = DRV_IOR(ParserLayer3ProtocolCamValid_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l3_pro_cam_valid));

        sal_memset(&l3_pro_cam, 0, sizeof(parser_layer3_protocol_cam_t));
        cmd = DRV_IOR(ParserLayer3ProtocolCam_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l3_pro_cam));

        for (index = 0; index < L3_PROTOCOL_CAM_ENTRY_NUM; index++)
        {
            if (!IS_BIT_SET(l3_pro_cam_valid.layer3_cam_entry_valid, index))
            {
                continue;
            }

            field_id = ParserLayer3ProtocolCam_L3CamLayer3Type0_f + index;
            cmd = DRV_IOR(ParserLayer3ProtocolCam_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l3_cam_layer3_type));

            field_id = ParserLayer3ProtocolCam_L3CamLayer3TypeMask0_f + index;
            cmd = DRV_IOR(ParserLayer3ProtocolCam_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l3_cam_layer3_type_mask));

            field_id = ParserLayer3ProtocolCam_L3CamLayer3HeaderProtocol0_f + index;
            cmd = DRV_IOR(ParserLayer3ProtocolCam_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l3_cam_layer3_header_protocol));

            field_id = ParserLayer3ProtocolCam_L3CamLayer3HeaderProtocolMask0_f +index;
            cmd = DRV_IOR(ParserLayer3ProtocolCam_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l3_cam_layer3_header_protocol_mask));

             field_id = ParserLayer3ProtocolCam_L3CamLayer4Type0_f + index;
            cmd = DRV_IOR(ParserLayer3ProtocolCam_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l3_cam_layer4_type));

            field_id = ParserLayer3ProtocolCam_L3CamAdditionalOffset0_f +index;
            cmd = DRV_IOR(ParserLayer3ProtocolCam_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l3_cam_additional_offset));

            CONDITIONAL_BREAK(((l3_cam_layer3_type & l3_cam_layer3_type_mask)
                               == (parser_result->layer3_type & l3_cam_layer3_type_mask))
                               && ((l3_cam_layer3_header_protocol & l3_cam_layer3_header_protocol_mask)
                               == (parser_result->l3_s.layer3_header_protocol & l3_cam_layer3_header_protocol_mask)));
        }

        if (L3_PROTOCOL_CAM_ENTRY_NUM == index)
        {
            parser_result->layer4_type = L4_TYPE_NONE;
            parser_result->l3_s.layer4_offset = parser_result->l3_s.layer4_offset;
        }
        else
        {
            parser_result->layer4_type = l3_cam_layer4_type;
            parser_result->l3_s.layer4_offset = parser_result->l3_s.layer4_offset + l3_cam_additional_offset;
        }
    }

    /* ======== bug 4949 metal fix ECO begin ========= */
    parser_result->l4_s.layer4_info_mapped = MAKE_UINT16(parser_result->layer4_type,
                                                             parser_result->l3_s.layer3_header_protocol);
    /* ======== bug 4949 metal fix ECO end ========= */

    frag_key = (parser_result->l3_s.more_frag << 2) | (frag->offset_is0 << 1) | frag->offset_is1;

    switch (frag_key)
    {
        case 0:
            parser_result->l3_s.frag_info = 3;   /* last fragmentation */
            break;
        case 1:
            parser_result->l3_s.frag_info = 2;   /* last fragmentation, small fragmentation */
            break;
        case 2:
            parser_result->l3_s.frag_info = 0;   /* no fragmentation */
            break;
        case 3:
            parser_result->l3_s.frag_info = 0;   /* invalid */
            break;
        case 4:
            parser_result->l3_s.frag_info = 3;   /* fragmentation, more to follow */
            break;
        case 5:
            parser_result->l3_s.frag_info = 2;   /* fragmentation, small fragmentation */
            break;
        case 6:
            parser_result->l3_s.frag_info = 1;   /* first fragmentation, more to follow */
            break;
        case 7:
            parser_result->l3_s.frag_info = 0;   /* invalid */
            break;
        default:
            break;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_udf_parser
 * Purpose:    Layer3 header udf parsing process.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_udf_parser(parser_info_t *parser_info, parse_misc_info_t *l3_misc_info)
{

    parsing_result_t* parser_result = parser_info->parser_result;

    if (!parser_info->non_crc)
    {
        l3_misc_info->min_length += 4;
    }

    if ((parser_info->parser_length - parser_result->l2_s.layer3_offset) < l3_misc_info->min_length)
    {
        parser_result->parser_length_error = TRUE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l3_packet_parsing
 * Purpose:    Layer3 header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l3_packet_parsing(parser_info_t *parser_info)
{
    ip_frag_t frag;
    parse_misc_info_t l3_misc_info;
    parsing_result_t* parser_result = parser_info->parser_result;

    uint8* l3_header = parser_info->pkt + parser_result->l2_s.layer3_offset + parser_info->payload_offset;
    uint8 ip_version = (l3_header[0] >> 4) & 0xF;
    uint8 is_ipv4 = ((L3_TYPE_IPV4 == parser_result->layer3_type)
                     || ((L3_TYPE_IP == parser_result->layer3_type) && (6 != ip_version)));
    uint8 is_ipv6 = ((L3_TYPE_IPV6 == parser_result->layer3_type)
                     || ((L3_TYPE_IP == parser_result->layer3_type) && (6 == ip_version)));
    uint8 is_mpls = ((L3_TYPE_MPLS == parser_result->layer3_type)
                     || (L3_TYPE_MPLSMCAST == parser_result->layer3_type));
    uint8 is_arp = (L3_TYPE_ARP == parser_result->layer3_type);
    uint8 is_cmac = (L3_TYPE_CMAC == parser_result->layer3_type);
    uint8 is_ethoam = (L3_TYPE_ETHEROAM == parser_result->layer3_type);
    uint8 is_slow_protocol = (L3_TYPE_SLOWPROTO == parser_result->layer3_type);
    uint8 is_fcoe = (L3_TYPE_FCOE == parser_result->layer3_type);
    uint8 is_trill = (L3_TYPE_TRILL == parser_result->layer3_type);
    uint8 is_ptp = (L3_TYPE_PTP == parser_result->layer3_type);

    /* l3Header = packet data bytes from layer3Offset + payloadOffset[7:0] */
    parser_result->layer4_type = L4_TYPE_NONE;
    parser_result->l3_s.layer4_offset = 0;

    parser_result->l3_s.dont_frag = TRUE;  /* Default no fragmentation for IPV6 */

    sal_memset(&frag, 0, sizeof(frag));
    frag.offset_is0 = 1;
    frag.offset_is1 = 0;

    sal_memset(&l3_misc_info, 0, sizeof(parse_misc_info_t));

    if (is_ipv4)                 /* IPv4 header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_ipv4_parsing(parser_info, &frag, &l3_misc_info));
    }
    else if (is_ipv6)            /* IPv6 header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_ipv6_parsing(parser_info, &frag, &l3_misc_info));
    }
    else if (is_arp)             /* ARP&RARP header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_arp_parsing(parser_info, &l3_misc_info));
    }
    else if (is_mpls)            /* MPLS header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_mpls_parsing(parser_info, &l3_misc_info));
    }
    else if (is_cmac)            /* PBB header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_pbb_cmac_parsing(parser_info, &l3_misc_info));
    }
    else if (is_ethoam)          /* Ethernet OAM header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_ethernet_oam_parser(parser_info, &l3_misc_info));
    }
    else if (is_slow_protocol)   /* Slow protocol header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_slow_protocol_parser(parser_info, &l3_misc_info));
    }
    else if (is_fcoe)            /* FCoE header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_fcoe_parser(parser_info, &l3_misc_info));
    }
    else if (is_trill)           /* Till header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_trill_parser(parser_info, &l3_misc_info));
    }
    else if (is_ptp)             /* PTP header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_ptp_parser(parser_info, &l3_misc_info));
    }
    else                         /* Flexible header parsing */
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_flex_parsing(parser_info, &l3_misc_info));
    }

    DRV_IF_ERROR_RETURN(_cm_com_parser_l3_protocol_lookup(parser_info, &frag, &l3_misc_info));

    DRV_IF_ERROR_RETURN(_cm_com_parser_l3_udf_parser(parser_info, &l3_misc_info));

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l4_op_get
 * Purpose:    Get layer4 info.
 * Parameters:
 * Input:
 * Output:
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l4_op_get(uint8 chip_id, parser_l4_op_type_t type, uint16 seed1, uint16 seed2, uint8 *result)
{
    parser_layer4_port_op_sel_t port_sel;
    parser_layer4_port_op_ctl_t port_ctl;
    parser_layer4_flag_op_ctl_t flag_ctl;

    uint16 port = 0;
    uint32 port_min = 0, port_max = 0, op_and_or = 0, flags_mask = 0;
    uint32 cmd = 0, index = 0;
    uint32 field_id =0;

    *result = 0;

    if (PARSER_L4_OP_PORT == type)
    {
        /* port operation */
        sal_memset(&port_sel, 0, sizeof(port_sel));
        cmd = DRV_IOR(ParserLayer4PortOpSel_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &port_sel));

        sal_memset(&port_ctl, 0, sizeof(port_ctl));
        cmd = DRV_IOR(ParserLayer4PortOpCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &port_ctl));


        for (index = 0; index < 8; index++)
        {
            field_id = ParserLayer4PortOpCtl_PortMax0_f + index;
            cmd = DRV_IOR(ParserLayer4PortOpCtl_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &port_max));

            field_id = ParserLayer4PortOpCtl_PortMin0_f + index;
            cmd = DRV_IOR(ParserLayer4PortOpCtl_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &port_min));

            port = IS_BIT_SET(port_sel.op_dest_port, index) ? seed2 : seed1;

            if ((port >= port_min) && (port <= port_max))
            {
                SET_BIT(*result, index);
            }
        }
    }
    else if (PARSER_L4_OP_TCP_FLAG == type)
    {
        /* tcp flag operation */
        sal_memset(&flag_ctl, 0, sizeof(flag_ctl));
        cmd = DRV_IOR(ParserLayer4FlagOpCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &flag_ctl));

        for (index = 0; index < 4; index++)
        {
            field_id = ParserLayer4FlagOpCtl_OpAndOr0_f + index;
            cmd = DRV_IOR(ParserLayer4FlagOpCtl_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &op_and_or));

            field_id = ParserLayer4FlagOpCtl_FlagsMask0_f + index;
            cmd = DRV_IOR(ParserLayer4FlagOpCtl_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &flags_mask));


            if (op_and_or && (flags_mask & seed1))
            {
                SET_BIT(*result, index);
            }

            if (!op_and_or && (0x3F == (flags_mask | seed1)))
            {
                SET_BIT(*result, index);
            }
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_com_parser_l4_packet_parsing
 * Purpose:    Layer4 header parsing.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_com_parser_l4_packet_parsing(parser_info_t *parser_info)
{

    parsing_result_t *parser_result = parser_info->parser_result;
    parser_layer4_ach_ctl_t l4_ach_ctl;
    parser_layer4_hash_ctl_t parser_layer4_hash_ctl;
    parser_layer4_flex_ctl_t parser_layer4_flex_ctl;
    parser_layer4_app_ctl_t parser_layer4_app_ctl;
    parser_layer4_app_data_ctl_t parser_layer4_app_data_ctl;

    uint8 chip_id = parser_info->chip_id;
    uint8 is_xor = FALSE;
    uint8 crc = 0;
    uint8 result = 0;
    uint8 portbit = 0;
    uint8 min_length = 0;
    uint8 tcp_flag = 0;
    uint8 udp_ptp_version = 0;
    uint8 non_first_fragment = FALSE;
    uint8 is_v6_in_ip = FALSE, is_gre = FALSE, is_ach_oam = FALSE;
    uint8 is_rdp = FALSE, is_sctp = FALSE, is_dccp = FALSE;
    uint8 *l4_header = parser_info->pkt + parser_result->l3_s.layer4_offset + parser_info->payload_offset;
    uint16 ach_type = 0;
    uint16 l4_header_0_1 = 0, l4_header_2_3 = 0;
    uint32 l4_header_4_7 = 0;
    uint32 inner_ipv6sa[4] = {0};
    uint32 y1731_tx_fcf = 0, y1731_rx_fcb = 0, y1731_tx_fcb = 0;
    int32 cmd = 0;
    bool layer4_app_data_hit = FALSE;

    /* l4Header = packet data bytes from layer4Offset + payloadOffset[7:0] */
    parser_result->l4_s.is_tcp = (L4_TYPE_TCP == parser_result->layer4_type);
    parser_result->l4_s.is_udp = (L4_TYPE_UDP == parser_result->layer4_type);
    is_v6_in_ip = (L4_TYPE_V6_IN_IP == parser_result->layer4_type);
    is_gre = (L4_TYPE_GRE == parser_result->layer4_type);
    is_ach_oam = (L4_TYPE_ACH_OAM == parser_result->layer4_type);
    is_rdp = (L4_TYPE_RDP == parser_result->layer4_type);
    is_sctp = (L4_TYPE_SCTP == parser_result->layer4_type);
    is_dccp = (L4_TYPE_DCCP == parser_result->layer4_type);
    non_first_fragment = IS_BIT_SET(parser_result->l3_s.frag_info, 1);

    sal_memset(&parser_layer4_hash_ctl, 0, sizeof(parser_layer4_hash_ctl_t));
    cmd = DRV_IOR(ParserLayer4HashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_layer4_hash_ctl));

    sal_memset(&parser_layer4_app_data_ctl, 0, sizeof(parser_layer4_app_data_ctl));
    cmd = DRV_IOR(ParserLayer4AppDataCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_layer4_app_data_ctl));

    if (!non_first_fragment)
    {
        if (parser_result->l4_s.is_tcp)
        {
            /* TCP_PARSING */
            /* Refer to RFC793 */
            min_length = TCP_MIN_LEN;

            parser_result->l4_s.l4_src_port.l4_source_port = MAKE_UINT16(l4_header[0], l4_header[1]);
            parser_result->l4_s.l4_dst_port.l4_dest_port = MAKE_UINT16(l4_header[2], l4_header[3]);
            tcp_flag = l4_header[13] & 0x3F;
            parser_result->l4_s.rid_ptp_bfd.tcp_ecn.tcp_ecn = ((l4_header[12]& 0x1) << 2)|((l4_header[13] >> 6)& 0x3);
            parser_result->l4_s.layer4_check_sum = MAKE_UINT16(l4_header[16], l4_header[17]);

            /* syn = 0 */
            if (!IS_BIT_SET(l4_header[13], 1))
            {
                SET_BIT(parser_result->l4_error_bits, 0);
            }
            /* control flags = 0, and sequence number = 0 */
            l4_header_4_7 = MAKE_UINT32(l4_header[4], l4_header[5], l4_header[6], l4_header[7]);

            if ((0 == (l4_header[13] & 0x3F)) & (0 == l4_header_4_7))
            {
                SET_BIT(parser_result->l4_error_bits, 1);
            }
            /* fin = 1, urg = 1, psh = 1 and sequence number = 0 */
            if (IS_BIT_SET(l4_header[13], 0) && IS_BIT_SET(l4_header[13], 3) && IS_BIT_SET(l4_header[13], 5)
                && (0 == l4_header_4_7))
            {
                SET_BIT(parser_result->l4_error_bits, 2);
            }
            /* syn = 1 and fin = 1 */
            if (IS_BIT_SET(l4_header[13], 0) && IS_BIT_SET(l4_header[13], 1))
            {
                SET_BIT(parser_result->l4_error_bits, 3);
            }
            /* source port = dest port */
            l4_header_0_1 = MAKE_UINT16(l4_header[0], l4_header[1]);
            l4_header_2_3 = MAKE_UINT16(l4_header[2], l4_header[3]);

            if (l4_header_0_1 == l4_header_2_3)
            {
                SET_BIT(parser_result->l4_error_bits, 4);
            }

            if ((((parser_layer4_app_data_ctl.is_tcp_mask0 & parser_layer4_app_data_ctl.is_tcp_value0)
                  == (parser_layer4_app_data_ctl.is_tcp_mask0 & parser_result->l4_s.is_tcp))
                && ((parser_layer4_app_data_ctl.is_udp_mask0 & parser_layer4_app_data_ctl.is_udp_value0)
                  == (parser_layer4_app_data_ctl.is_udp_mask0 & parser_result->l4_s.is_udp))
                && ((parser_layer4_app_data_ctl.l4_dest_port_mask0 & parser_layer4_app_data_ctl.l4_dest_port_value0)
                  == (parser_layer4_app_data_ctl.l4_dest_port_mask0 & parser_result->l4_s.l4_dst_port.l4_dest_port)))
             || (((parser_layer4_app_data_ctl.is_tcp_mask1 & parser_layer4_app_data_ctl.is_tcp_value1)
                  == (parser_layer4_app_data_ctl.is_tcp_mask1 & parser_result->l4_s.is_tcp))
                && ((parser_layer4_app_data_ctl.is_udp_mask1 & parser_layer4_app_data_ctl.is_udp_value1)
                  == (parser_layer4_app_data_ctl.is_udp_mask1 & parser_result->l4_s.is_udp))
                && ((parser_layer4_app_data_ctl.l4_dest_port_mask1 & parser_layer4_app_data_ctl.l4_dest_port_value1)
                  == (parser_layer4_app_data_ctl.l4_dest_port_mask1 & parser_result->l4_s.l4_dst_port.l4_dest_port)))
             || (((parser_layer4_app_data_ctl.is_tcp_mask2 & parser_layer4_app_data_ctl.is_tcp_value2)
                  == (parser_layer4_app_data_ctl.is_tcp_mask2 & parser_result->l4_s.is_tcp))
                && ((parser_layer4_app_data_ctl.is_udp_mask2 & parser_layer4_app_data_ctl.is_udp_value2)
                  == (parser_layer4_app_data_ctl.is_udp_mask2 & parser_result->l4_s.is_udp))
                && ((parser_layer4_app_data_ctl.l4_dest_port_mask2 & parser_layer4_app_data_ctl.l4_dest_port_value2)
                  == (parser_layer4_app_data_ctl.l4_dest_port_mask2 & parser_result->l4_s.l4_dst_port.l4_dest_port)))
             || (((parser_layer4_app_data_ctl.is_tcp_mask3 & parser_layer4_app_data_ctl.is_tcp_value3)
                  == (parser_layer4_app_data_ctl.is_tcp_mask3 & parser_result->l4_s.is_tcp))
                && ((parser_layer4_app_data_ctl.is_udp_mask3 & parser_layer4_app_data_ctl.is_udp_value3)
                  == (parser_layer4_app_data_ctl.is_udp_mask3 & parser_result->l4_s.is_udp))
                && ((parser_layer4_app_data_ctl.l4_dest_port_mask3 & parser_layer4_app_data_ctl.l4_dest_port_value3)
                  == (parser_layer4_app_data_ctl.l4_dest_port_mask3 & parser_result->l4_s.l4_dst_port.l4_dest_port))))
            {
                layer4_app_data_hit = TRUE;
            }

            /* tcp does not have the full header(less than 20 bytes) */
            /* ParserResutl.parserLengthError */
            /* min tcp header */
            if (((parser_info->parser_length - parser_result->l3_s.layer4_offset) >= (20 + 8 + (parser_info->non_crc ? 0 :4)))
                && (0 == ((l4_header[12] >> 4) & 0xF)) && layer4_app_data_hit)
            {
                parser_result->l4_s.app_data_valid1 = TRUE;
                parser_result->l4_s.app_data = MAKE_UINT32(l4_header[24], l4_header[25], l4_header[26], l4_header[27]);
            }
            else if ((parser_info->parser_length - parser_result->l3_s.layer4_offset) >= (20 + 4 + (parser_info->non_crc ? 0 :4)))
            {
                parser_result->l4_s.app_data_valid0 = TRUE;
                parser_result->l4_s.app_data = MAKE_UINT32(l4_header[20], l4_header[21], l4_header[22], l4_header[23]);
            }
        }
        else if (parser_result->l4_s.is_udp)
        {
            /* UDP_PARSING */
            /* Refer to RFC768 */
            min_length = UDP_MIN_LEN;

            sal_memset(&parser_layer4_app_ctl, 0, sizeof(parser_layer4_app_ctl_t));
            cmd = DRV_IOR(ParserLayer4AppCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_layer4_app_ctl));

            parser_result->l4_s.l4_src_port.l4_source_port = MAKE_UINT16(l4_header[0], l4_header[1]);
            parser_result->l4_s.l4_dst_port.l4_dest_port = MAKE_UINT16(l4_header[2], l4_header[3]);
            parser_result->l4_s.layer4_check_sum = MAKE_UINT16(l4_header[6], l4_header[7]);

            if ((((parser_layer4_app_data_ctl.is_tcp_mask0 & parser_layer4_app_data_ctl.is_tcp_value0)
                  == (parser_layer4_app_data_ctl.is_tcp_mask0 & parser_result->l4_s.is_tcp))
                && ((parser_layer4_app_data_ctl.is_udp_mask0 & parser_layer4_app_data_ctl.is_udp_value0)
                  == (parser_layer4_app_data_ctl.is_udp_mask0 & parser_result->l4_s.is_udp))
                && ((parser_layer4_app_data_ctl.l4_dest_port_mask0 & parser_layer4_app_data_ctl.l4_dest_port_value0)
                  == (parser_layer4_app_data_ctl.l4_dest_port_mask0 & parser_result->l4_s.l4_dst_port.l4_dest_port)))
             || (((parser_layer4_app_data_ctl.is_tcp_mask1 & parser_layer4_app_data_ctl.is_tcp_value1)
                  == (parser_layer4_app_data_ctl.is_tcp_mask1 & parser_result->l4_s.is_tcp))
                && ((parser_layer4_app_data_ctl.is_udp_mask1 & parser_layer4_app_data_ctl.is_udp_value1)
                  == (parser_layer4_app_data_ctl.is_udp_mask1 & parser_result->l4_s.is_udp))
                && ((parser_layer4_app_data_ctl.l4_dest_port_mask1 & parser_layer4_app_data_ctl.l4_dest_port_value1)
                  == (parser_layer4_app_data_ctl.l4_dest_port_mask1 & parser_result->l4_s.l4_dst_port.l4_dest_port)))
             || (((parser_layer4_app_data_ctl.is_tcp_mask2 & parser_layer4_app_data_ctl.is_tcp_value2)
                  == (parser_layer4_app_data_ctl.is_tcp_mask2 & parser_result->l4_s.is_tcp))
                && ((parser_layer4_app_data_ctl.is_udp_mask2 & parser_layer4_app_data_ctl.is_udp_value2)
                  == (parser_layer4_app_data_ctl.is_udp_mask2 & parser_result->l4_s.is_udp))
                && ((parser_layer4_app_data_ctl.l4_dest_port_mask2 & parser_layer4_app_data_ctl.l4_dest_port_value2)
                  == (parser_layer4_app_data_ctl.l4_dest_port_mask2 & parser_result->l4_s.l4_dst_port.l4_dest_port)))
             || (((parser_layer4_app_data_ctl.is_tcp_mask3 & parser_layer4_app_data_ctl.is_tcp_value3)
                  == (parser_layer4_app_data_ctl.is_tcp_mask3 & parser_result->l4_s.is_tcp))
                && ((parser_layer4_app_data_ctl.is_udp_mask3 & parser_layer4_app_data_ctl.is_udp_value3)
                  == (parser_layer4_app_data_ctl.is_udp_mask3 & parser_result->l4_s.is_udp))
                && ((parser_layer4_app_data_ctl.l4_dest_port_mask3 & parser_layer4_app_data_ctl.l4_dest_port_value3)
                  == (parser_layer4_app_data_ctl.l4_dest_port_mask3 & parser_result->l4_s.l4_dst_port.l4_dest_port))))
            {
                layer4_app_data_hit = TRUE;
            }

            if ((parser_info->parser_length - parser_result->l3_s.layer4_offset)>= (UDP_MIN_LEN + 8 + (parser_info->non_crc ? 0 : 4))
                && layer4_app_data_hit)
            {
                parser_result->l4_s.app_data_valid1 = TRUE;
                parser_result->l4_s.app_data = MAKE_UINT32(l4_header[12], l4_header[13], l4_header[14], l4_header[15]);
            }
            else if ((parser_info->parser_length - parser_result->l3_s.layer4_offset) >= (UDP_MIN_LEN + 4 + (parser_info->non_crc ? 0 : 4)))
            {
                parser_result->l4_s.app_data_valid0 = TRUE;
                parser_result->l4_s.app_data = MAKE_UINT32(l4_header[8], l4_header[9], l4_header[10], l4_header[11]);
            }

            /* source port = dest port */
            l4_header_0_1 = MAKE_UINT16(l4_header[0], l4_header[1]);
            l4_header_2_3 = MAKE_UINT16(l4_header[2], l4_header[3]);

            if (l4_header_0_1 == l4_header_2_3)
            {
                SET_BIT(parser_result->l4_error_bits, 4);
            }

            /* UDP encapsulated application parser */
            if ((parser_result->l4_s.l4_dst_port.l4_dest_port == parser_layer4_app_ctl.ntp_port)
                && parser_layer4_app_ctl.ntp_en)
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_UDP_NTP;
                parser_result->l4_s.rid_ptp_bfd.ntp_version.ntp_version = (l4_header[8] >> 3) & 0x7;

                min_length = UDP_MIN_LEN + 48;
            }
            else if (((parser_result->l4_s.l4_dst_port.l4_dest_port == parser_layer4_app_ctl.ptp_port0)
                     || (parser_result->l4_s.l4_dst_port.l4_dest_port == parser_layer4_app_ctl.ptp_port1))
                     && parser_layer4_app_ctl.ptp_en)
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_UDP_PTP;
                udp_ptp_version = ((l4_header[9] & 0xF) > 2) ? 3 : (l4_header[9] & 0x3);
                parser_result->l4_s.isatap_ptp_ver.udp_ptp_version1 = IS_BIT_SET(udp_ptp_version, 1);
                parser_result->l4_s.rid_ptp_bfd.ptp_msg_type.udp_ptp_version0 = IS_BIT_SET(udp_ptp_version, 0);

                if (IS_BIT_SET(udp_ptp_version, 1))   /* version 2 and above */
                {
                    parser_result->l4_s.rid_ptp_bfd.ptp_msg_type.udp_ptp_message_type = l4_header[8] & 0xF;
                    parser_result->l4_s.gre_bfd_ptp.udp_ptp_correction_field_31_0
                                        = MAKE_UINT32(l4_header[20], l4_header[21], l4_header[22], l4_header[23]);
                    parser_result->l4_s.ptp_oam_ach.udp_ptp_correction_field_63_32
                                        = MAKE_UINT32(l4_header[16], l4_header[17], l4_header[18], l4_header[19]);
                    parser_result->l4_s.udp_ptp_timestamp_31_to_0
                                        = MAKE_UINT32(l4_header[48], l4_header[49], l4_header[50], l4_header[51]);
                    parser_result->l4_s.udp_ptp_timestamp_63_to_32
                                        = MAKE_UINT32(l4_header[44], l4_header[45], l4_header[46], l4_header[47]);

                    min_length = L4_UDP_PTP_V2_MIN_LEN;
                }
                else
                {
                    parser_result->l4_s.udp_ptp_timestamp_63_to_32
                                  = MAKE_UINT32(l4_header[48], l4_header[49], l4_header[50], l4_header[51]);
                    parser_result->l4_s.udp_ptp_timestamp_31_to_0
                                  = MAKE_UINT32(l4_header[52], l4_header[53], l4_header[54], l4_header[55]);
                    min_length = L4_UDP_PTP_V1_MIN_LEN;
                }
            }
            else if (((parser_result->l4_s.l4_dst_port.l4_dest_port == parser_layer4_app_ctl.bfd_port0)
                     || (parser_result->l4_s.l4_dst_port.l4_dest_port == parser_layer4_app_ctl.bfd_port1))
                     && parser_layer4_app_ctl.bfd_en)
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_UDP_BFD;
                parser_result->l4_s.gre_bfd_ptp.bfd_my_discriminator = MAKE_UINT32(l4_header[16], l4_header[17],
                                                                                   l4_header[18], l4_header[19]);
                min_length = L4_OAM_BFD_MIN_LEN;
            }
            else if (((parser_result->l4_s.l4_dst_port.l4_dest_port == parser_layer4_app_ctl.capwap_port0)
                     || (parser_result->l4_s.l4_dst_port.l4_dest_port == parser_layer4_app_ctl.capwap_port1))
                     && parser_layer4_app_ctl.capwap_en)   /*only CAPWAP Header*/
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_UDP_CAPWAP;
                parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_dtls = (1 == (l4_header[8] & 0xF));
                parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_header_length = (l4_header[9] >> 3) & 0x1F;
                parser_result->l4_s.rid_ptp_bfd.rid_t.rid = ((l4_header[9] & 0x7) << 2) | ((l4_header[10] >> 6) & 0x3);
                parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_flags = ((IS_BIT_SET(l4_header[10], 0) << 7)
                                                                                | (((l4_header[11] >> 3) & 0x1F) << 2));

                min_length = 8 + (parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_header_length << 2);

                switch (parser_layer4_app_ctl.state_bits)
                {
                    case 0:
                        parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_flags |= ((l4_header[11] >> 1) & 0x3);
                        break;
                    case 1:
                        parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_flags |= (l4_header[11] & 0x3);
                        break;
                    case 2:
                        parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_flags |= ((l4_header[15] >> 1) & 0x3);
                        break;
                    case 3:
                        parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_flags |= (l4_header[15] & 0x3);
                        break;
                    default:
                        break;
                }

                if (IS_BIT_SET(parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_flags, 3) && (6 == l4_header[16]))
                {
                    parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.radio_mac_47_32 = MAKE_UINT16(l4_header[17], l4_header[18]);
                    parser_result->l4_s.gre_bfd_ptp.radio_mac_31_0 = MAKE_UINT32(l4_header[19],l4_header[20],
                                                                                l4_header[21],l4_header[22]);
                }
                else if (IS_BIT_SET(parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_flags, 3) && (8 == l4_header[16]))
                {
                    parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.radio_mac_47_32 = MAKE_UINT16(l4_header[17], l4_header[18]);
                    parser_result->l4_s.gre_bfd_ptp.radio_mac_31_0 = MAKE_UINT32(l4_header[19],l4_header[22],
                                                                                l4_header[23],l4_header[24]);
                }
            }
        }
        else if (is_v6_in_ip)
        {
            /* ISATAP_PARSING */
            /* Refer to RFC2529, RFC5214 */
            min_length = IPV6_IN_IP_MIN_LEN;

            inner_ipv6sa[3] = MAKE_UINT32(l4_header[8], l4_header[9], l4_header[10], l4_header[11]);
            inner_ipv6sa[2] = MAKE_UINT32(l4_header[12], l4_header[13], l4_header[14], l4_header[15]);
            inner_ipv6sa[1] = MAKE_UINT32(l4_header[16], l4_header[17], l4_header[18], l4_header[19]);
            inner_ipv6sa[0] = MAKE_UINT32(l4_header[20], l4_header[21], l4_header[22], l4_header[23]);

            parser_result->l4_s.l4_src_port.l4_source_port = (inner_ipv6sa[0] >> 16) & 0xFFFF;
            parser_result->l4_s.l4_dst_port.l4_dest_port = inner_ipv6sa[0] & 0xFFFF;
            parser_result->l4_s.layer4_check_sum = MAKE_UINT16(l4_header[6], l4_header[7]);
            parser_result->l4_s.isatap_ptp_ver.is_isatap_interface = (0x00005EFE == (inner_ipv6sa[1] & 0xFCFFFFFF));
        }
        else if (is_gre)
        {
            /* GRE_PARSING */
            /* Refer to RFC1701, RFC2784 */
            parser_result->l4_s.l4_src_port.gre_flags = MAKE_UINT16(l4_header[0], l4_header[1]);   /* only support C/K/S flags */
            parser_result->l4_s.l4_dst_port.gre_protocol_type = MAKE_UINT16(l4_header[2], l4_header[3]);

            if (IS_BIT_SET(parser_result->l4_s.l4_src_port.gre_flags, 15))                /* Checksum exist */
            {
                parser_result->l4_s.layer4_check_sum = MAKE_UINT16(l4_header[4], l4_header[5]);

                if (IS_BIT_SET(parser_result->l4_s.l4_src_port.gre_flags, 13))            /* key exsits */
                {
                    parser_result->l4_s.gre_bfd_ptp.gre_key  = MAKE_UINT32(l4_header[8], l4_header[9], l4_header[10], l4_header[11]);
                }
            }
            else if (IS_BIT_SET(parser_result->l4_s.l4_src_port.gre_flags, 13))
            {
                parser_result->l4_s.gre_bfd_ptp.gre_key = MAKE_UINT32(l4_header[4], l4_header[5], l4_header[6], l4_header[7]);
            }

            portbit = ((IS_BIT_SET(parser_result->l4_s.l4_src_port.gre_flags, 15) << 2)
                       | (IS_BIT_SET(parser_result->l4_s.l4_src_port.gre_flags, 13) << 1)
                       | IS_BIT_SET(parser_result->l4_s.l4_src_port.gre_flags, 12));

            switch (portbit)
            {
                case 7:
                    min_length= 16;
                    break;
                case 6:
                case 5:
                case 3:
                    min_length= 12;
                    break;
                case 4:
                case 2:
                case 1:
                    min_length= 8;
                    break;
                default:
                    min_length= 4;
                    break;
            }
        }
        else if (is_ach_oam)
        {
            /* ACH_OAM_PARSING */
            /* Refer to draft-bhh-mpls-tp-oam-y1731, RFC5885, RFC5586, RFC6428 */
            sal_memset(&l4_ach_ctl, 0, sizeof(parser_layer4_ach_ctl_t));
            cmd = DRV_IOR(ParserLayer4AchCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l4_ach_ctl));

            ach_type = MAKE_UINT16(l4_header[2], l4_header[3]);    /* channel type */

            if (ach_type == l4_ach_ctl.ach_y1731_type)       /* ACH Y.1731 */
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_ACHOAM_ACH_Y1731;
                min_length = L4_OAM_ACH_MIN_LEN;

                parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_level = (l4_header[4] >> 5) & 0x7;       /* MD level */
                parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_version = l4_header[4] & 0x1F;           /* version */
                parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code = l4_header[5];                  /* Opcode */

                if (OAM_OP_CCM == parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code)            /* CCM */
                {
                    y1731_tx_fcf = MAKE_UINT32(l4_header[62], l4_header[63], l4_header[64], l4_header[65]);
                    y1731_rx_fcb = MAKE_UINT32(l4_header[66], l4_header[67], l4_header[68], l4_header[69]);
                    y1731_tx_fcb = MAKE_UINT32(l4_header[70], l4_header[71], l4_header[72], l4_header[73]);
                    min_length = L4_OAM_CCM_MIN_LEN;
                }
                else if ((OAM_OP_LMM == parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code)
                         ||(OAM_OP_LMR == parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code))   /* LMM or LMR */
                {
                    y1731_tx_fcf = MAKE_UINT32(l4_header[8], l4_header[9], l4_header[10], l4_header[11]);
                    y1731_rx_fcb = MAKE_UINT32(l4_header[12], l4_header[13], l4_header[14], l4_header[15]);
                    y1731_tx_fcb = MAKE_UINT32(l4_header[16], l4_header[17], l4_header[18], l4_header[19]);
                    min_length = L4_OAM_LMM_LMR_MIN_LEN;
                }
            }
            else if (0x7 == ach_type)                        /* ACH BFD */
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_ACHOAM_ACH_BFD;
                min_length = L4_OAM_ACH_BFD_MIN_LEN;

                parser_result->l4_s.gre_bfd_ptp.bfd_my_discriminator = MAKE_UINT32(l4_header[12], l4_header[13],
                                                                                   l4_header[14], l4_header[15]);
            }
            else if (ach_type == l4_ach_ctl.ach_bfd_cc_type) /* ACH CC using BFD */
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_ACHOAM_ACH_CC;
                min_length = L4_OAM_ACH_BFD_CC_MIN_LEN;

                parser_result->l4_s.gre_bfd_ptp.bfd_my_discriminator = MAKE_UINT32(l4_header[12], l4_header[13],
                                                                                   l4_header[14], l4_header[15]);
            }
            else if (ach_type == l4_ach_ctl.ach_bfd_cv_type) /* ACH CV using BFD */
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_ACHOAM_ACH_CV;
                min_length = 4 + 24;

                parser_result->l4_s.gre_bfd_ptp.bfd_my_discriminator = MAKE_UINT32(l4_header[12], l4_header[13],
                                                                                   l4_header[14], l4_header[15]);
            }
            else if (ach_type == l4_ach_ctl.ach_dlm_type)    /* ACH DLM */
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_ACHOAM_ACH_DLM;
                min_length = L4_OAM_ACH_DLM_MIN_LEN;

                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_version = (l4_header[4] >> 4) & 0xF;
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_flag = ((l4_header[4] & 0xF) << 4) | (l4_header[8] >> 4);
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_dscp = l4_header[15] & 0x3F;
            }
            else if (ach_type == l4_ach_ctl.ach_dm_type)     /* ACH DM */
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_ACHOAM_ACH_DM;
                min_length = L4_OAM_ACH_DM_MIN_LEN;
            }
            else if (ach_type == l4_ach_ctl.ach_ilm_type)    /* ACH ILM */
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_ACHOAM_ACH_ILM;
                min_length = L4_OAM_ACH_ILM_MIN_LEN;
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_version = (l4_header[4] >> 4) & 0xF;
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_flag = ((l4_header[4] & 0xF) << 4) | (l4_header[8] >> 4);
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_dscp = l4_header[15] & 0x3F;
            }
            else if (ach_type == l4_ach_ctl.ach_dlm_dm_type) /* ACH DLM + DM */
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_ACHOAM_ACH_DLMDM;
                min_length = L4_OAM_ACH_DLMDM_MIN_LEN;
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_version = (l4_header[4] >> 4) & 0xF;
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_flag = ((l4_header[4] & 0xF) << 4) | (l4_header[8] >> 4);
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_dscp = l4_header[15] & 0x3F;
            }
            else if (ach_type == l4_ach_ctl.ach_ilm_dm_type) /* ACH ILM + DM */
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_ACHOAM_ACH_ILMDM;
                min_length = L4_OAM_ACH_ILMDM_MIN_LEN;
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_version = (l4_header[4] >> 4) & 0xF;
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_flag = ((l4_header[4] & 0xF) << 4) | (l4_header[8] >> 4);
                parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_dscp = l4_header[15] & 0x3F;
            }
            else
            {
                parser_result->l4_s.layer4_user_type = L4_USER_TYPE_ACHOAM_NONE;
                min_length = 4 ;
            }
        }
        else if (is_rdp)
        {
            /* RDP_PARSING */
            /* Refer to RFC1151 */
            min_length = L4_RDP_MIN_LEN;
            parser_result->l4_s.l4_src_port.l4_source_port = MAKE_UINT16(l4_header[2], l4_header[3]);
            parser_result->l4_s.l4_dst_port.l4_dest_port = MAKE_UINT16(l4_header[4], l4_header[5]);
            parser_result->l4_s.layer4_check_sum = MAKE_UINT16(l4_header[16], l4_header[17]);
        }
        else if (is_sctp)
        {
            /* SCTP_PARSING */
            /* Refer to RFC4960 */
            min_length = L4_SCTP_MIN_LEN;
            parser_result->l4_s.l4_src_port.l4_source_port = MAKE_UINT16(l4_header[0], l4_header[1]);
            parser_result->l4_s.l4_dst_port.l4_dest_port = MAKE_UINT16(l4_header[2], l4_header[3]);
        }
        else if (is_dccp)
        {
            /* DCCP_PARSING */
            /* Refer to RFC4340 */
            min_length = L4_DCCP_MIN_LEN;
            parser_result->l4_s.l4_src_port.l4_source_port = MAKE_UINT16(l4_header[0], l4_header[1]);
            parser_result->l4_s.l4_dst_port.l4_dest_port = MAKE_UINT16(l4_header[2], l4_header[3]);
        }
        else
        {
            /* L4_FLEX_PARSING */
            /* Refer to RFC792, RFC4443 */
            sal_memset(&parser_layer4_flex_ctl, 0, sizeof(parser_layer4_flex_ctl));
            cmd = DRV_IOR(ParserLayer4FlexCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &parser_layer4_flex_ctl));

            if ((L4_TYPE_ICMP == parser_result->layer4_type) || (L4_TYPE_IGMP == parser_result->layer4_type))
            {
                min_length = IGMP_MIN_LEN;
            }
            else
            {
                min_length= parser_layer4_flex_ctl.layer4_min_length;
            }

            parser_result->l4_s.l4_src_port.l4_source_port = MAKE_UINT16(l4_header[0], l4_header[1]);
            parser_result->l4_s.l4_dst_port.l4_dest_port = MAKE_UINT16(l4_header[parser_layer4_flex_ctl.layer4_byte_select0],
                                                                       l4_header[parser_layer4_flex_ctl.layer4_byte_select1]);
            parser_result->l4_s.layer4_check_sum = MAKE_UINT16(l4_header[2], l4_header[3]);

            if ((L4_TYPE_ICMP == parser_result->layer4_type) && (L3_TYPE_IPV6 == parser_result->layer3_type)
                && ((130 == l4_header[0]) || (131 == l4_header[0]) || (132 == l4_header[0]) || (143 == l4_header[0])))
            {
                parser_result->layer4_type = L4_TYPE_IGMP;   /* IPv6 IGMP */
            }
        }
    }

    /* GEN_L4_INFO_MAPPED */
    /* ecmp or header hash function */
    if ((!parser_result->l4_s.is_tcp) && (!parser_result->l4_s.is_udp))
    {
        parser_result->l4_s.layer4_info_mapped = MAKE_UINT16(parser_result->layer4_type,
                                                             parser_result->l3_s.layer3_header_protocol);
        /* sctp or dccp port based hash */
        if ((is_sctp || is_dccp) && (!non_first_fragment))
        {
            /* select CRC8_1 or ECMP XOR8 by ParserLayer4HashCtl.layer4EcmpHashType */
            is_xor = parser_layer4_hash_ctl.layer4_ecmp_hash_type;
            DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                             PARSER_USAGE_TYPE_ECMP,
                                                             PARSER_HASH_KEY_TYPE_L4_INFO,
                                                             is_xor,
                                                             &crc));
            parser_result->l3_s.ip_ecmp_hash = crc;

            /* select CRC8_2 or LINKAGG XOR8 by ParserLayer4HashCtl.layer4LinkAggHashType */
            if (parser_layer4_hash_ctl.use_layer4_hash)
            {
                is_xor = parser_layer4_hash_ctl.layer4_link_agg_hash_type;
                DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                                 PARSER_USAGE_TYPE_LINKAGG,
                                                                 PARSER_HASH_KEY_TYPE_L4_INFO,
                                                                 is_xor,
                                                                 &crc));
                parser_result->header_hash = crc;
            }
        }
        else if (is_gre && (!non_first_fragment))
        {
            /* select CRC8_1 or ECMP XOR8 by ParserLayer4HashCtl.layer4EcmpHashType */
            is_xor = parser_layer4_hash_ctl.layer4_ecmp_hash_type;
            DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                             PARSER_USAGE_TYPE_ECMP,
                                                             PARSER_HASH_KEY_TYPE_L4_INFO,
                                                             is_xor,
                                                             &crc));
            parser_result->l3_s.ip_ecmp_hash = crc;

            /* select CRC8_2 or LINKAGG XOR8 by ParserLayer4HashCtl.layer4LinkAggHashType */
            if (parser_layer4_hash_ctl.use_layer4_hash)
            {
                is_xor = parser_layer4_hash_ctl.layer4_link_agg_hash_type;
                DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                                 PARSER_USAGE_TYPE_LINKAGG,
                                                                 PARSER_HASH_KEY_TYPE_L4_INFO,
                                                                 is_xor,
                                                                 &crc));
                parser_result->header_hash = crc;
            }
        }
    }
    else if (!non_first_fragment)
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l4_op_get(chip_id, PARSER_L4_OP_PORT,
                                                     parser_result->l4_s.l4_src_port.l4_source_port,
                                                     parser_result->l4_s.l4_dst_port.l4_dest_port, &result));

        parser_result->l4_s.layer4_info_mapped = result & 0xFF;

        if (parser_result->l4_s.is_tcp)
        {
            DRV_IF_ERROR_RETURN(_cm_com_parser_l4_op_get(chip_id, PARSER_L4_OP_TCP_FLAG, tcp_flag, 0, &result));

            parser_result->l4_s.layer4_info_mapped |= ((result & 0xF) << 8);
        }

        /* select CRC8_1 or ECMP XOR8 by ParserLayer4HashCtl.layer4EcmpHashType */
        is_xor = parser_layer4_hash_ctl.layer4_ecmp_hash_type;
        DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                         PARSER_USAGE_TYPE_ECMP,
                                                         PARSER_HASH_KEY_TYPE_L4_INFO,
                                                         is_xor,
                                                         &crc));
        parser_result->l3_s.ip_ecmp_hash = crc;

        /* select CRC8_2 or LINKAGG XOR8 by ParserLayer4HashCtl.layer4LinkAggHashType */
        if (parser_layer4_hash_ctl.use_layer4_hash)
        {
            is_xor = parser_layer4_hash_ctl.layer4_link_agg_hash_type;
            DRV_IF_ERROR_RETURN(_cm_com_parser_generate_hash(parser_info,
                                                             PARSER_USAGE_TYPE_LINKAGG,
                                                             PARSER_HASH_KEY_TYPE_L4_INFO,
                                                             is_xor,
                                                             &crc));
            parser_result->header_hash = crc;
        }
    }

    if ((L4_TYPE_ACH_OAM == parser_result->layer4_type)
       && (L4_USER_TYPE_ACHOAM_ACH_Y1731 == parser_result->l4_s.layer4_user_type))
    {
        parser_result->l3_s.ip_sa.eth_oam.tx_fcf = y1731_tx_fcf;
        parser_result->l3_s.ip_sa.eth_oam.rx_fcb = y1731_rx_fcb;
        parser_result->l3_s.ip_sa.eth_oam.tx_fcb = y1731_tx_fcb;
    }

    if (!parser_info->non_crc)
    {
        min_length += 4;
    }

    if ((parser_info->parser_length - parser_result->l3_s.layer4_offset) < min_length)
    {
        parser_result->parser_length_error = TRUE;
    }

    return DRV_E_NONE;
}

static int32
_cm_com_parser_debug_parser_info(parser_info_t *parser_info)
{
    parsing_result_t *parser_result = parser_info->parser_result;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "\n[Debug Parser Info]: \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "--------------------------------------------------------- \n");

    if(L2_TYPE_ETHV2 == parser_result->layer2_type)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer2 Type: ETH V2 \n");
    }
    else if(L2_TYPE_ETHSAP == parser_result->layer2_type)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer2 Type: ETH SAP \n");
    }
    else if(L2_TYPE_ETHSNAP == parser_result->layer2_type)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer2 Type: ETH SNAP \n");
    }
    else
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer2 Type: NOT ETH !!\n");
    }

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "   MacDa: %.2x%.2x.%.2x%.2x.%.2x%.2x \n",
                                parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4, parser_result->l2_s.mac_da3,
                                parser_result->l2_s.mac_da2, parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "   MacSa: %.2x%.2x.%.2x%.2x.%.2x%.2x \n",
                                parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4, parser_result->l2_s.mac_sa3,
                                parser_result->l2_s.mac_sa2, parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO,
                                "   S-VLAN Info: svlan id valid: %d, svlan id: 0x%-.3x, stag cos: %d, stag cfi: %d \n",
                                parser_result->l2_s.svlan_id_valid, parser_result->l2_s.svlan_id,
                                parser_result->l2_s.stag_cos, parser_result->l2_s.stag_cfi);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO,
                                "   C-VLAN Info: cvlan id valid: %d, cvlan id: 0x%-.3x, ctag cos: %d, ctag cfi: %d \n",
                                parser_result->l2_s.cvlan_id_valid, parser_result->l2_s.cvlan_id,
                                parser_result->l2_s.ctag_cos, parser_result->l2_s.ctag_cfi);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "   Ether Type: 0x%.4X \n", parser_result->l2_s.layer2_header_protocol);

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "--------------------------------------------------------- \n");

    if( (L3_TYPE_IPV4 == parser_result->layer3_type)||(L3_TYPE_IPV6 == parser_result->layer3_type))
    {
        if (L3_TYPE_IPV4 == parser_result->layer3_type)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer3 Type: IPV4 \n");
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "   IPV4 Info: ipsa: %d.%d.%d.%d, ",
                                    (parser_result->l3_s.ip_sa.ipv4.ipsa >> 24) & 0xFF, (parser_result->l3_s.ip_sa.ipv4.ipsa >> 16) & 0xFF,
                                    (parser_result->l3_s.ip_sa.ipv4.ipsa >> 8) & 0xFF, parser_result->l3_s.ip_sa.ipv4.ipsa& 0xFF);
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "ipda: %d.%d.%d.%d, ",
                                       (parser_result->l3_s.ip_da.ipv4.ipda >> 24) & 0xFF, (parser_result->l3_s.ip_da.ipv4.ipda >> 16) & 0xFF,
                                    (parser_result->l3_s.ip_da.ipv4.ipda >> 8) & 0xFF, parser_result->l3_s.ip_da.ipv4.ipda& 0xFF);
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "ip option: %d \n", parser_result->l3_s.ip_options);
        }
        if (L3_TYPE_IPV6 == parser_result->layer3_type)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer3 Type: IPV6 \n");
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "   IPV6 Info: ipsa: 0x%.8x:%.8x:%.8x:%.8x \n",
                                    parser_result->l3_s.ip_sa.ipv6.ipsa_127_96, parser_result->l3_s.ip_sa.ipv6.ipsa_95_64,
                                    parser_result->l3_s.ip_sa.ipv6.ipsa_63_32, parser_result->l3_s.ip_sa.ipv6.ipsa_31_0);
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "   ipda: 0x%.8x:%.8x:%.8x:%.8x \n",
                                    parser_result->l3_s.ip_da.ipv6.ipda_127_96, parser_result->l3_s.ip_da.ipv6.ipda_95_64,
                                    parser_result->l3_s.ip_da.ipv6.ipda_63_32, parser_result->l3_s.ip_da.ipv6.ipda_31_0);
        }

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "   ttl: %d, ip length: %d, ip tos: 0x%x, header protocol: 0x%x\n",
                                    parser_result->l3_s.ttl, parser_result->l3_s.ip_length, parser_result->l3_s.tos.ip_tos, parser_result->l3_s.layer3_header_protocol);
    }
    else if (L3_TYPE_ARP == parser_result->layer3_type)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer3 Type: ARP \n");
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "ARP Info: op code: 0x%x,  sender ip: 0x%x, sender mac: %4x%6x\n",
            parser_result->l3_s.ip_da.arp.arp_op_code, parser_result->l3_s.ip_sa.arp.sender_ip,
            parser_result->l3_s.ip_sa.arp.sender_mac_47_32, parser_result->l3_s.ip_sa.arp.sender_mac_31_0);
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "   target ip: 0x%x, target mac: %4x%6x\n",
            parser_result->l3_s.ip_da.arp.target_ip, parser_result->l3_s.ip_da.arp.target_mac_47_32, parser_result->l3_s.ip_da.arp.target_mac_31_0);
    }
    else if (L3_TYPE_MPLS== parser_result->layer3_type)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer3 Type: MPLS \n");
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "MPLS Info: ttl: %d, ", parser_result->l3_s.ttl);
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "label0: 0x%x, ", parser_result->l3_s.ip_da.mpls.mpls_label0);
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "label num: %d, ", parser_result->l3_s.tos.mpls.label_num);
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "label num: %d, ", parser_result->l3_s.tos.mpls.ip_over_mpls);

    }
    else if (L3_TYPE_ETHEROAM == parser_result->layer3_type)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer3 Type: ETH OAM \n");
    }
    else
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer3 Type: %d \n", parser_result->layer3_type);
    }

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "--------------------------------------------------------- \n");

    if (L4_TYPE_TCP == parser_result->layer4_type)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer4 Type: TCP \n");
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "TCP Info: source port: %d, ", parser_result->l4_s.l4_src_port.l4_source_port);
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "dest port: %d \n", parser_result->l4_s.l4_dst_port.l4_dest_port);
    }
    else if (L4_TYPE_UDP == parser_result->layer4_type)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer4 Type: UDP \n");
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "UDP Info: source port: %d, ", parser_result->l4_s.l4_src_port.l4_source_port);
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "dest port: %d \n", parser_result->l4_s.l4_dst_port.l4_dest_port);
    }
    else if(L4_TYPE_GRE == parser_result->layer4_type)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer4 Type: GRE \n");
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "GRE Info: gre flags: 0x%x, ", parser_result->l4_s.l4_src_port.gre_flags);
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "gre protocol type: 0x%x, ", parser_result->l4_s.l4_dst_port.gre_protocol_type);
    }
    else if(L4_TYPE_ICMP == parser_result->layer4_type)
    {
         CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer4 Type: ICMP \n");
    }
    else if(L4_TYPE_IGMP == parser_result->layer4_type)
    {
         CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer4 Type: IGMP \n");
    }
    else if(L4_TYPE_NONE== parser_result->layer4_type)
    {
         CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer4 Type: NONE \n");
    }
    else
    {
         CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "Layer4 Type: %d \n", parser_result->layer4_type);
    }

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_PARSER_INFO, "--------------------------------------------------------- \n");

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_com_parser_packet_parsing
 * Purpose:    Packet parsing process.
 * Parameters:
 * Input:      parser_info -- parser input informations.
 * Output:     parser_result -- parser output informations.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
int32
cm_com_parser_packet_parsing(parser_info_t *parser_info)
{
    uint32 cmd = 0;
    parsing_result_t *parser_result = NULL;
    parser_packet_type_map_t packet_type_map_table;
    parser_result = parser_info->parser_result;

    sal_memset(&packet_type_map_table, 0, sizeof(parser_packet_type_map_t));
    cmd = DRV_IOR(ParserPacketTypeMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(parser_info->chip_id, 0, cmd, &packet_type_map_table));

    parser_result->parser_length_error = FALSE;

    parser_result->layer2_type = L2_TYPE_NONE;
    parser_result->layer3_type = L3_TYPE_NONE;
    parser_result->layer4_type = L4_TYPE_NONE;

    if (parser_info->parser_layer4_type != L4_TYPE_NONE)
    {
        parser_result->layer2_type = L2_TYPE_NONE;
        parser_result->layer3_type = L3_TYPE_NONE;
        parser_result->layer4_type = parser_info->parser_layer4_type;
    }
    else
    {
        switch (parser_info->packet_type)
        {
            /* ETHERNET */
            case PKT_TYPE_ETHERNETV2:
                parser_result->layer2_type = L2_TYPE_ETHV2;
                parser_result->layer3_type = L3_TYPE_NONE;
                parser_result->layer4_type = L4_TYPE_NONE;
                break;
            /* IPv4 */
            case PKT_TYPE_IPV4:
                parser_result->layer2_type = L2_TYPE_NONE;
                parser_result->layer3_type = L3_TYPE_IPV4;
                parser_result->layer4_type = L4_TYPE_NONE;
                break;
            /* MPLS Unicast */
            case PKT_TYPE_MPLS:
                parser_result->layer2_type = L2_TYPE_NONE;
                parser_result->layer3_type = L3_TYPE_MPLS;
                parser_result->layer4_type = L4_TYPE_NONE;
                break;
            /* IPv6 */
            case PKT_TYPE_IPV6:
                parser_result->layer2_type = L2_TYPE_NONE;
                parser_result->layer3_type = L3_TYPE_IPV6;
                parser_result->layer4_type = L4_TYPE_NONE;
                break;
            /* MPLS Multicast */
            case PKT_TYPE_MCAST_MPLS:
                parser_result->layer2_type = L2_TYPE_NONE;
                parser_result->layer3_type = L3_TYPE_MPLSMCAST;
                parser_result->layer4_type = L4_TYPE_NONE;
                break;
            /* TRILL */
            case PKT_TYPE_TRILL:
                parser_result->layer2_type = L2_TYPE_NONE;
                parser_result->layer3_type = L3_TYPE_TRILL;
                parser_result->layer4_type = L4_TYPE_NONE;
                break;
            /* first 6 packetType is known, last 2 in mapping table */
            default:
                if (PKT_TYPE_FLEXIBLE == parser_info->packet_type)
                {
                    parser_result->layer2_type = packet_type_map_table.layer2_type0;
                    parser_result->layer3_type = packet_type_map_table.layer3_type0;
                }
                else
                {
                    parser_result->layer2_type = packet_type_map_table.layer2_type1;
                    parser_result->layer3_type = packet_type_map_table.layer3_type1;
                }
                break;
        }
    }

    sal_memset(&parser_result->l2_s, 0, sizeof(parser_result->l2_s));
    sal_memset(&parser_result->l3_s, 0, sizeof(parser_result->l3_s));
    sal_memset(&parser_result->l4_s, 0, sizeof(parser_result->l4_s));

    parser_result->l3_s.ip_header_error = FALSE;

    /* layer 2 parsing process */
    if (L2_TYPE_NONE != parser_result->layer2_type)
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l2_packet_parsing(parser_info));
        if (parser_result->parser_length_error)
        {
            return DRV_E_NONE;
        }
    }

    /* layer 3 parsing process */
    if (L3_TYPE_NONE != parser_result->layer3_type)
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l3_packet_parsing(parser_info));
        if (parser_result->parser_length_error)
        {
            return DRV_E_NONE;
        }
    }

    /* layer 4 to7 parsing process */
    if (L4_TYPE_NONE != parser_result->layer4_type)
    {
        DRV_IF_ERROR_RETURN(_cm_com_parser_l4_packet_parsing(parser_info));
        if (parser_result->parser_length_error)
        {
            return DRV_E_NONE;
        }
    }

    DRV_IF_ERROR_RETURN(_cm_com_parser_debug_parser_info(parser_info));

    return DRV_E_NONE;
}

