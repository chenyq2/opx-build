/****************************************************************************
 * cm_com_dma.c  cmodel DMA simulation
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:
 * Author:
 * Date:         2012-12-08
 * Reason:
 *
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/
extern uint32 chip_agent_get_mode();

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
typedef struct
{
    uint32 rx_chan_en;
    uint32 tx_chan_en;
} cm_dma_chip_t;

#define CM_DMA_CHAN_NUM     8

typedef struct
{
    pci_exp_desc_mem_t  pci_exp_desc;
    uint32              padding;
} cm_dma_desc_t;

typedef struct
{
    cm_dma_chip_t chip[CM_MAX_CHIP_NUM];
    uint8 chip_num;
} cm_dma_ctl_t;

cm_dma_ctl_t g_cm_dma;

uint32 cm_dma_debug_flag = 0;

#define CM_DMA_DBG(fmt, args...) \
do \
{ \
    if (cm_dma_debug_flag) \
        sal_printf(fmt, ##args); \
} while (0)

extern int32
swemu_received_packet_process(uint8 *packet,
                                        uint32 len,
                                        uint32 chipid_offset,
                                        uint32 mac_num);

static int32
_cm_sim_dma_engine_chip_get_rx_pkt_desc(uint8 chip_id, uint32 chan, cm_dma_desc_t* p_desc_base, uint32 depth)
{
    pci_exp_desc_mem_t* p_desc = NULL;
    uintptr phy_addr = 0;
    uint32 index = 0;
    uint32 pkt_len = 0;
    uint8* packet = NULL;
    uint32 cmd = 0;
    desc_rx_vld_num_t rx_vld_num;
    sys_mem_base_tab_t sys_mem_base_tab;
    uint32 high_addr = 0;
    
    cmd = DRV_IOR(SysMemBaseTab_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &sys_mem_base_tab));
    high_addr = sys_mem_base_tab.data;
    
    for (index = 0; index < depth; index++)
    {
        p_desc = &(p_desc_base[index].pci_exp_desc);

        CM_COMBINE_64BITS_DATA(high_addr, (p_desc->desc_mem_addr_low << 4), phy_addr);

        CM_DMA_DBG("[DMA Engine RX] index %d mem_addr %p len %d sop %d eop %d \n",
            index, phy_addr, p_desc->desc_len, p_desc->desc_sop, p_desc->desc_eop);

        cmd = DRV_IOR(DescRxVldNum_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, chan, cmd, &rx_vld_num));

        if (0 == rx_vld_num.data)
        {
            break;
        }

        if (p_desc->desc_len && !p_desc->desc_done)
        {
            /* can only handle one desc */
            packet = (uint8*)sal_malloc(MTU);
            sal_memcpy(packet + GREAT_BELT_CPUMAC_HDR_LEN, (uint8*)phy_addr, p_desc->desc_len);
            pkt_len = GREAT_BELT_CPUMAC_HDR_LEN + p_desc->desc_len - GREAT_BELT_DMA_PKT_CRC_LEN;
            swemu_received_packet_process(packet, pkt_len, chip_id, CPU_MACNUM);
            p_desc->desc_done = TRUE;
            p_desc->desc_len = 0;
            p_desc->desc_sop = 0;
            p_desc->desc_eop = 0;

            rx_vld_num.data--;
            cmd = DRV_IOW(DescRxVldNum_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, chan, cmd, &rx_vld_num));
        }
    }

    return 0;
}

static int32
_cm_sim_dma_engine_chip_set_tx_pkt_desc(uint8 chip_id, uint32 chan, cm_dma_desc_t* p_desc_base, uint32 depth,
    uint8* p_pkt, uint32 pkt_len)
{
    pci_exp_desc_mem_t* p_desc = NULL;
    uintptr phy_addr = 0;
    uint8* p_mem = NULL;
    uint8* p = NULL;
    uint32 left = 0;
    uint32 copy_len = 0;
    uint32 is_sop = TRUE;
    uint32 sub_intr = 0;
    uint32 cmd = 0;
    dma_tx_ptr_tab_t tx_ptr;
    desc_tx_vld_num_t tx_vld_num;
    pcie_intr_cfg_t pcie_intr_cfg;
    sys_mem_base_tab_t sys_mem_base_tab;
    uint32 high_addr = 0;
    
    cmd = DRV_IOR(SysMemBaseTab_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &sys_mem_base_tab));
    high_addr = sys_mem_base_tab.data;
    
    p = p_pkt;
    left = pkt_len;

    cmd = DRV_IOR(DmaTxPtrTab_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, chan, cmd, &tx_ptr));
    cmd = DRV_IOR(DescTxVldNum_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, chan, cmd, &tx_vld_num));

    while (tx_vld_num.data > 0)
    {
        p_desc = &(p_desc_base[tx_ptr.ptr].pci_exp_desc);
        if (is_sop)
        {
            p_desc->desc_sop = TRUE;
            is_sop = FALSE;
        }

        // not check tx_vld_num for cmodel cannot simulate chip's write 1 means plus 1 action
        // tx_vld_num.data--;
        tx_ptr.ptr++;
        if (tx_ptr.ptr >= depth)
        {
            tx_ptr.ptr = 0;
        }
        cmd = DRV_IOW(DmaTxPtrTab_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, chan, cmd, &tx_ptr));
        cmd = DRV_IOW(DescTxVldNum_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, chan, cmd, &tx_vld_num));

        CM_COMBINE_64BITS_DATA(high_addr, (p_desc->desc_mem_addr_low << 4), phy_addr);

        p_desc->desc_done = TRUE;
        p_mem = (uint8*)phy_addr;
        if (left <= p_desc->desc_len)
        {
            copy_len = left;
            sal_memcpy(p_mem, p, copy_len);
            p_desc->desc_len = copy_len;
            p_desc->desc_eop = TRUE;
            break;
        }
        else
        {
            copy_len = p_desc->desc_len;
            sal_memcpy(p_mem, p, copy_len);
            p_desc->desc_len = copy_len;
            p += copy_len;
            left -= copy_len;
        }
    }

    if (p_desc && p_desc->desc_eop)
    {
        /* check EOP to trigger interrupt */
        cmd = DRV_IOR(PcieIntrCfg_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &pcie_intr_cfg));
        if (CM_BIT_ISSET(pcie_intr_cfg.cfg_pkt_eop_intr_en, chan))
        {
            sub_intr = chan + CM_INTR_GB_SUB_DMA_FUNC_TX_CHAN_0;
            DRV_IF_ERROR_RETURN(cm_com_interrupt_set(chip_id, TRUE, CM_INTR_GB_DMA_FUNC, sub_intr));
            CM_DMA_DBG("[DMA Engine TX] trigger DMA Func Interrupt with sub_intr %d \n", sub_intr);
        }
    }
    else
    {
        sal_printf("[DMA Engine TX] chip %d chan %d packet RX fail!!! \n", chip_id, chan);
    }

    return 0;
}

static int32
_cm_sim_dma_engine_chip_process(uint8 chip_id)
{
    cm_dma_desc_t* p_desc_base = NULL;
    cm_dma_chip_t* p_dma_chip = NULL;
    p_dma_chip = &(g_cm_dma.chip[chip_id]);
    uint32 chan = 0;
    uint32 cmd = 0;
    uint32 high_addr = 0;
    uintptr phy_addr = 0;

    desc_rx_mem_base_t  rx_mem_base;
    desc_rx_mem_depth_t rx_mem_depth;
    desc_rx_vld_num_t   rx_vld_num;
    sys_mem_base_tab_t sys_mem_base_tab;

    sal_memset(&sys_mem_base_tab, 0, sizeof(sys_mem_base_tab_t));

    cmd = DRV_IOR(SysMemBaseTab_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &sys_mem_base_tab));
    high_addr = sys_mem_base_tab.data;
            
    /* process RX (CPU -> GB) */
    for (chan = 0; chan < CM_DMA_CHAN_NUM; chan++)
    {
        if (CM_BIT_ISSET(p_dma_chip->rx_chan_en, chan))
        {
            sal_memset(&rx_mem_base, 0, sizeof(rx_mem_base));
            sal_memset(&rx_mem_depth, 0, sizeof(rx_mem_depth));
            sal_memset(&rx_vld_num, 0, sizeof(rx_vld_num));

            cmd = DRV_IOR(DescRxMemBase_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, chan, cmd, &rx_mem_base));
            cmd = DRV_IOR(DescRxMemDepth_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, chan, cmd, &rx_mem_depth));
            cmd = DRV_IOR(DescRxVldNum_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, chan, cmd, &rx_vld_num));

            CM_COMBINE_64BITS_DATA(high_addr, (rx_mem_base.data << 4), phy_addr);
            p_desc_base = (cm_dma_desc_t*)phy_addr;

            if (rx_vld_num.data)
            {
                /* RX data */
                //CM_DMA_DBG("[DMA Engine RX] chip %d chan %d desc_base %p depth %d valid %d \n", chip_id,
                //    chan, p_desc_base, rx_mem_depth.data, rx_vld_num.data);
                _cm_sim_dma_engine_chip_get_rx_pkt_desc(chip_id, chan, p_desc_base, rx_mem_depth.data);
            }
        }
    }

    /* process TX (GB -> CPU) */


    return 0;
}

static int32
_cm_sim_dma_engine_loop()
{
    cm_dma_ctl_t* p_dma = &g_cm_dma;
    dma_misc_ctl_t dma_misc_ctl;
    uint8 chip_id = 0;
    uint32 cmd = 0;

    sal_memset(p_dma, 0, sizeof(cm_dma_ctl_t));
    p_dma->chip_num = 1;

    for (;;)
    {
        for (chip_id = 0; chip_id < p_dma->chip_num; chip_id++)
        {
            sal_memset(&dma_misc_ctl, 0, sizeof(dma_misc_ctl));
            cmd = DRV_IOR(DmaMiscCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &dma_misc_ctl));
            if (dma_misc_ctl.cfg_dma_en)
            {
                p_dma->chip[chip_id].rx_chan_en = dma_misc_ctl.dma_rx_chan_en;
                p_dma->chip[chip_id].tx_chan_en = dma_misc_ctl.dma_tx_chan_en;
                _cm_sim_dma_engine_chip_process(chip_id);
            }

        }

        sal_task_sleep(50);
    }

    return 0;
}

int32
cm_sim_dma_rx_pkt(uint8 chip_id, uint32 chan, void* p_desc_base, uint32 depth)
{
    return _cm_sim_dma_engine_chip_get_rx_pkt_desc(chip_id, chan, (cm_dma_desc_t*)p_desc_base, depth);
}

int32
cm_sim_dma_tx_pkt(out_pkt_t* p_pkt)
{
    dma_chan_map_t   dma_chan_map;
    ms_packet_header_t bheader;
    ms_packet_header_t* p_bheader = &bheader;
    cm_dma_desc_t* p_desc_base = NULL;
    uint32 dma_tx_chan_en = 0;
    uint32 chan = 0;
    uint32 cmd = 0;
    uintptr phy_addr = 0;
    uint8* p_pkt_data = NULL;
    uint32 pkt_len = 0;

    dma_misc_ctl_t dma_misc_ctl;
    desc_tx_mem_base_t  tx_mem_base;
    desc_tx_mem_depth_t tx_mem_depth;
    desc_tx_vld_num_t   tx_vld_num;
    sys_mem_base_tab_t sys_mem_base_tab;
    uint32 high_addr = 0;
    
    cmd = DRV_IOR(SysMemBaseTab_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(0, 0, cmd, &sys_mem_base_tab));
    high_addr = sys_mem_base_tab.data;
    
    /* get DMA channel */
    sal_memcpy(&bheader, p_pkt->pkt, sizeof(ms_packet_header_t));
    DRV_IF_ERROR_RETURN(swap32((uint32*)p_bheader, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));
    cmd = DRV_IOR(DmaChanMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_pkt->chip_id, p_bheader->priority, cmd, &dma_chan_map));
    chan = dma_chan_map.cos;

    /* strip 20 Bytes CPUMAC header */
    p_pkt_data = p_pkt->pkt + 20;
    pkt_len = p_pkt->packet_length - 20;
    CM_DMA_DBG("[DMA Engine TX] priority %d chan %d length %d \n", p_bheader->priority,
                chan, pkt_len);

    sal_memset(&dma_misc_ctl, 0, sizeof(dma_misc_ctl));
    cmd = DRV_IOR(DmaMiscCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_pkt->chip_id, 0, cmd, &dma_misc_ctl));
    if (dma_misc_ctl.cfg_dma_en)
    {
        dma_tx_chan_en = dma_misc_ctl.dma_tx_chan_en;
        if (CM_BIT_ISSET(dma_tx_chan_en, chan))
        {
            sal_memset(&tx_mem_base, 0, sizeof(tx_mem_base));
            sal_memset(&tx_mem_depth, 0, sizeof(tx_mem_depth));
            sal_memset(&tx_vld_num, 0, sizeof(tx_vld_num));

            cmd = DRV_IOR(DescTxMemBase_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_pkt->chip_id, chan, cmd, &tx_mem_base));
            cmd = DRV_IOR(DescTxMemDepth_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_pkt->chip_id, chan, cmd, &tx_mem_depth));
            cmd = DRV_IOR(DescTxVldNum_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_pkt->chip_id, chan, cmd, &tx_vld_num));

            CM_COMBINE_64BITS_DATA(high_addr, (tx_mem_base.data << 4), phy_addr);

            p_desc_base = (cm_dma_desc_t*)phy_addr;

            CM_DMA_DBG("[DMA Engine TX] desc_base %p depth %d valid %d \n", p_desc_base,
                tx_mem_depth.data, tx_vld_num.data);
            _cm_sim_dma_engine_chip_set_tx_pkt_desc(p_pkt->chip_id, chan,
                p_desc_base, tx_mem_depth.data, p_pkt_data, pkt_len);
        }
    }

    return 0;
}

void
cm_sim_dma_engine()
{
#ifdef CMODEL_WITH_AGENT
    uint32 chip_agent_mode = chip_agent_get_mode();

    if (1 == chip_agent_mode)
    {
        /* CHIP_AGT_MODE_CLIENT : need not SWEMU */
        _cm_sim_dma_engine_loop();
    }
    else if (2 == chip_agent_mode)
    {
        /* CHIP_AGT_MODE_SERVER : SWEMU on Board */
    }
    else
    {
        /* CHIP_AGT_MODE_NONE : SWEMU on UML/for CTP */
        _cm_sim_dma_engine_loop();
    }
#else
        /* CHIP_AGT_MODE_NONE : SWEMU on UML/for CTP */
        _cm_sim_dma_engine_loop();
#endif
}

