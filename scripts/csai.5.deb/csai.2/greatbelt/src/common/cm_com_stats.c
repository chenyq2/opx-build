/****************************************************************************
 * cm_com_stats.c  Useful untilities for statisitcs.
 * Copyright:      (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Revision:       V1.0.
 * Author:        Zhouw
 * Date:          2010-10-18.
 * Reason:        First Create.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "ctcutil_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/


/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
int32
sim_increase_statistics(uint8 chip, uint8 type, uint32 index, uint32 packet_length)
{
    drv_work_platform_type_t platform_type = MAX_WORK_PLATFORM;
    uint32 cmd = 0, tbl_id = 0;
    uint32 val_byte_count_upper = 0;
    uint32 val_pkt_count_upper = 0;
    int32 ret = DRV_E_NONE;

    ds_stats_t ds_stats;
    ipe_fwd_discard_type_stats_t ipe_fwd_discard_type_stats;
    epe_hdr_edit_discard_type_stats_t epe_hdr_edit_discard_type_stats;
    epe_hdr_edit_debug_stats_t epe_hdr_edit_debug_stats;

    tbls_id_t table_id = MaxTblId_t;

    sal_memset(&ds_stats, 0, sizeof(ds_stats_t));
    sal_memset(&ipe_fwd_discard_type_stats, 0, sizeof(ipe_fwd_discard_type_stats));
    sal_memset(&epe_hdr_edit_discard_type_stats, 0, sizeof(epe_hdr_edit_discard_type_stats_t));
    sal_memset(&epe_hdr_edit_debug_stats, 0, sizeof(epe_hdr_edit_debug_stats_t));

    ret = drv_get_platform_type(&platform_type);
    if (ret != DRV_E_NONE)
    {
        CMODEL_DEBUG_OUT_INFO("Get platform type error!\n");
        return ret;
    }

    if (platform_type == HW_PLATFORM)
    {
        return DRV_E_NONE;
    }

#if 0
    if(sim_check_stats_store_bus_flag)
    {
        ret = sim_check_stats_store_info_for_asic(type, packet_length, index);
        if (ret != DRV_E_NONE)
        {
            CMODEL_DEBUG_OUT_INFO("Store hash key right cmp error!\n");
            return ret;
        }
    }
#endif

    switch (type)
    {
        /* 1G mac */
        case CM_STATS_RAM0_1G:
            tbl_id = QuadMacStatsRam0_t;
            break;

        case CM_STATS_RAM1_1G:
            tbl_id = QuadMacStatsRam1_t;
            break;

        case CM_STATS_RAM2_1G:
            tbl_id = QuadMacStatsRam2_t;
            break;

        case CM_STATS_RAM3_1G:
            tbl_id = QuadMacStatsRam3_t;
            break;

        case CM_STATS_RAM4_1G:
            tbl_id = QuadMacStatsRam4_t;
            break;

        case CM_STATS_RAM5_1G:
            tbl_id = QuadMacStatsRam5_t;
            break;

        case CM_STATS_RAM6_1G:
            tbl_id = QuadMacStatsRam6_t;
            break;

        case CM_STATS_RAM7_1G:
            tbl_id = QuadMacStatsRam7_t;
            break;

        case CM_STATS_RAM8_1G:
            tbl_id = QuadMacStatsRam8_t;
            break;

        case CM_STATS_RAM9_1G:
            tbl_id = QuadMacStatsRam9_t;
            break;

        case CM_STATS_RAM10_1G:
            tbl_id = QuadMacStatsRam10_t;
            break;

        case CM_STATS_RAM11_1G:
            tbl_id = QuadMacStatsRam11_t;
            break;

        /* 10G mac */
        case CM_STATS_RAM0_10G:
            tbl_id = SgmacStatsRam0_t;
            break;

        case CM_STATS_RAM1_10G:
            tbl_id = SgmacStatsRam1_t;
            break;

        case CM_STATS_RAM2_10G:
            tbl_id = SgmacStatsRam2_t;
            break;

        case CM_STATS_RAM3_10G:
            tbl_id = SgmacStatsRam3_t;
            break;

        case CM_STATS_RAM4_10G:
            tbl_id = SgmacStatsRam4_t;
            break;

        case CM_STATS_RAM5_10G:
            tbl_id = SgmacStatsRam5_t;
            break;

        case CM_STATS_RAM6_10G:
            tbl_id = SgmacStatsRam6_t;
            break;

        case CM_STATS_RAM7_10G:
            tbl_id = SgmacStatsRam7_t;
            break;

        case CM_STATS_CPU_MAC:
            tbl_id = CpuMacStats_t;
            break;

        case CM_STATS_ELOOP:
        case CM_STATS_EXCEPTION:
        case CM_STATS_COMPLETE_DISCARD:
            tbl_id = EpeHdrEditDebugStats_t;
            break;

        case CM_INGRESS_DISCARD:
            table_id = IpeFwdDiscardTypeStats_t;
            break;

        case CM_EGRESS_DISCARD:
            table_id = EpeHdrEditDiscardTypeStats_t;
            break;

        case CM_STATS_INTERLAKEN_RX_MAC:
            table_id = IntLkRxStatsMem_t;
            break;

        case CM_STATS_INTERLAKEN_TX_MAC:
            table_id = IntLkTxStatsMem_t;
            break;

        default:
            table_id = DsStats_t;
            break;
    }

    if (table_id == DsStats_t)
    {
        cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &ds_stats));

        /* increase packet counter stats */
        if (ds_stats.packet_count != 0xFFFFFFFF)
        {
            ds_stats.packet_count++;
        }
        else
        {
            ds_stats.packet_count = 0;
        }

        /* increase packet bytes stats */
        if ((0xFFFFFFFF - ds_stats.byte_count31_0) > packet_length)
        {
            ds_stats.byte_count31_0 += packet_length;
        }
        else
        {
            ds_stats.byte_count31_0 += packet_length;
            ds_stats.byte_count39_32 += 1;
        }

        cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &ds_stats));
    }
    else if (table_id == IpeFwdDiscardTypeStats_t)
    {
        cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &ipe_fwd_discard_type_stats));

        ipe_fwd_discard_type_stats.discard_pkt_cnt++;

        cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &ipe_fwd_discard_type_stats));
    }
    else if (table_id == EpeHdrEditDiscardTypeStats_t)
    {
        cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &epe_hdr_edit_discard_type_stats));

        epe_hdr_edit_discard_type_stats.discard_pkt_cnt++;

        cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &epe_hdr_edit_discard_type_stats));
    }
    else if (type == CM_STATS_ELOOP)
    {
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, 0, cmd, &epe_hdr_edit_debug_stats));

        epe_hdr_edit_debug_stats.loopback_cnt++;
    }
    else if (type == CM_STATS_EXCEPTION)
    {
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, 0, cmd, &epe_hdr_edit_debug_stats));

        epe_hdr_edit_debug_stats.exception_cnt++;
    }
    else if (type == CM_STATS_COMPLETE_DISCARD)
    {
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, 0, cmd, &epe_hdr_edit_debug_stats));

        epe_hdr_edit_debug_stats.complete_discard_cnt++;
    }
    else if ((type > CM_STATS_RAM11_1G) && (type < CM_STATS_CPU_MAC))   /* 10gmac stats, cnt 40bits */
    {
        sgmac_stats_ram_t sgmac_stats;
        sal_memset(&sgmac_stats, 0, sizeof(sgmac_stats));

        /* read original statistics */
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &sgmac_stats));

        val_byte_count_upper = sgmac_stats.byte_cnt_data_hi;
        val_pkt_count_upper = sgmac_stats.frame_cnt_data_hi;

        /* add new counter */
        sgmac_stats.frame_cnt_data_lo++;
        sgmac_stats.byte_cnt_data_lo = sgmac_stats.byte_cnt_data_lo + packet_length;

        /* over flow handle */
        if (sgmac_stats.frame_cnt_data_lo < 1)
        {
            val_pkt_count_upper++;
        }
        if (sgmac_stats.byte_cnt_data_lo < packet_length)
        {
            val_byte_count_upper++;
        }
        sgmac_stats.frame_cnt_data_hi = val_pkt_count_upper;
        sgmac_stats.byte_cnt_data_hi = val_byte_count_upper;

        /* write back to statistics */
        cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &sgmac_stats));
    }
    else if (type <= CM_STATS_RAM11_1G)                                 /* 1gmac stats cnt:36bits */
    {
        quad_mac_stats_ram_t gmac_stats;
        sal_memset(&gmac_stats, 0, sizeof(gmac_stats));

        /* read original statistics */
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &gmac_stats));

        /* add new counter */
        gmac_stats.frame_cnt_data_lo++;
        gmac_stats.byte_cnt_data_lo = gmac_stats.byte_cnt_data_lo + packet_length;

        /* over flow handle */
        if (gmac_stats.frame_cnt_data_lo < 1)
        {
            gmac_stats.frame_cnt_data_lo++;
        }
        if (gmac_stats.byte_cnt_data_lo < packet_length)
        {
            gmac_stats.byte_cnt_data_hi++;
        }

        /* write back to statistics */
        cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &gmac_stats));
    }

    /* co-simulation address check not include stats table */

    return DRV_E_NONE;
}

int32
sim_clear_statistics(uint8 chip, uint8 type, uint32 index)
{
#if 0
    /* zhouw note */
    quadmacapp0_stats_ram_t g_stats_mac;
    xgmac2_xgmac_stats_ram_t xg_stats_mac;
    ds_forwarding_stats_t fwd_stats;
    discardcount_t cnt;
    uint32 cmd, tbl_id;

    /* add new counter */
    sal_memset(&g_stats_mac, 0, sizeof(g_stats_mac));
    sal_memset(&xg_stats_mac, 0, sizeof(xg_stats_mac));
    sal_memset(&fwd_stats, 0, sizeof(fwd_stats));
    sal_memset(&cnt, 0, sizeof(cnt));

    switch(type)
    {
        /* 1G mac */
        case HUMBER_STATS_RAM0_1G:
            tbl_id = QUADMACAPP0_STATS_RAM;
            break;

        case HUMBER_STATS_RAM1_1G:
            tbl_id = QUADMACAPP1_STATS_RAM;
            break;

        case HUMBER_STATS_RAM2_1G:
            tbl_id = QUADMACAPP2_STATS_RAM;
            break;

        case HUMBER_STATS_RAM3_1G:
            tbl_id = QUADMACAPP3_STATS_RAM;
            break;

        case HUMBER_STATS_RAM4_1G:
            tbl_id = QUADMACAPP4_STATS_RAM;
            break;

        case HUMBER_STATS_RAM5_1G:
            tbl_id = QUADMACAPP5_STATS_RAM;
            break;

        case HUMBER_STATS_RAM6_1G:
            tbl_id = QUADMACAPP6_STATS_RAM;
            break;

        case HUMBER_STATS_RAM7_1G:
            tbl_id = QUADMACAPP7_STATS_RAM;
            break;

        case HUMBER_STATS_RAM8_1G:
            tbl_id = QUADMACAPP8_STATS_RAM;
            break;

        case HUMBER_STATS_RAM9_1G:
            tbl_id = QUADMACAPP9_STATS_RAM;
            break;

        case HUMBER_STATS_RAM10_1G:
            tbl_id = QUADMACAPP10_STATS_RAM;
            break;

        case HUMBER_STATS_RAM11_1G:
            tbl_id = QUADMACAPP11_STATS_RAM;
            break;

        /* 10G mac */
        case HUMBER_STATS_RAM0_10G:
            tbl_id = XGMAC0_XGMAC_STATS_RAM;
            break;

        case HUMBER_STATS_RAM1_10G:
            tbl_id = XGMAC1_XGMAC_STATS_RAM;
            break;

        case HUMBER_STATS_RAM2_10G:
            tbl_id = XGMAC2_XGMAC_STATS_RAM;
            break;

        case HUMBER_STATS_RAM3_10G:
            tbl_id = XGMAC3_XGMAC_STATS_RAM;
            break;

        case HUMBER_STATS_RAM4_10G:
            tbl_id = SGMAC0_SGMAC_STATS_RAM;
            break;

        case HUMBER_STATS_RAM5_10G:
            tbl_id = SGMAC1_SGMAC_STATS_RAM;
            break;

        case HUMBER_STATS_RAM6_10G:
            tbl_id = SGMAC2_SGMAC_STATS_RAM;
            break;

        case HUMBER_STATS_RAM7_10G:
            tbl_id = SGMAC3_SGMAC_STATS_RAM;
            break;

        case HUMBER_STATS_CPU_MAC:
            tbl_id = CPUMAC_STATS_RAM;
            break;

        case HUMBER_INGRESS_PORT:
            tbl_id = IPE_STATSRAMIPEPHBINTF;
            break;

        case HUMBER_EGRESS_PORT:
            tbl_id = EPE_STATSRAMEPEPHBINTF;
            break;

        case HUMBER_INGRESS_GLOBAL_FWD:
            tbl_id = IPE_STATSRAMIPEOVERALLFWD;
            break;

        case HUMBER_EGRESS_GLOBAL_FWD:
            tbl_id = EPE_STATSRAMEPEOVERALLFWD;
            break;

        case HUMBER_INGRESS_PORT_LOG:
            tbl_id = IPE_STATSRAMIPEPORTLOG;
            break;

        case HUMBER_EGRESS_PORT_LOG:
            tbl_id = EPE_STATSRAMEPEPORTLOG;
            break;

        case HUMBER_FLOW_OR_QUEUE:
            tbl_id = DS_FORWARDING_STATS;
            break;

        case HUMBER_COMPLETE_DISCARD:
            tbl_id = DISCARDCOUNT;
            break;

        default:
            return DRV_E_NONE;
    }

    cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
    if (type > HUMBER_FLOW_OR_QUEUE)
    {
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip,  index, cmd, &cnt));
    }
    else if (type > HUMBER_STATS_CPU_MAC)
    {
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip,  index, cmd, &fwd_stats));
    }
    else if (type >HUMBER_STATS_RAM11_1G)
    {
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip,  index, cmd, &xg_stats_mac));
    }
    else
    {
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip,  index, cmd, &g_stats_mac));
    }
#else
    ds_stats_t ds_stats;
    uint32 cmd = 0;
    tbls_id_t table_id = MaxTblId_t;

    table_id = DsStats_t;
    cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &ds_stats));

    /* Clear packet and byte counter stats */
    ds_stats.packet_count = 0;
    ds_stats.byte_count31_0 = 0;
    ds_stats.byte_count39_32 = 0;

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip, index, cmd, &ds_stats));
#endif
    return DRV_E_NONE;
}

