/***************************************************************************
 * emu_sys.c:    provides emulation net rx and tx interface.
 * Copyright (C)  2010 Centec Networks Inc. All rights reserved.
 *
 * Revision:      V1.0.
 * Author:       ZhouW.
 * Date:         2010-09-19.
 * Reason:       GreatBelt Init Version.
 *
 * Modify History:
****************************************************************************/
/***************************************************************************
 *
 * Header Files
 *
***************************************************************************/
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/ethernet.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/***************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/
#define SOCKET_TIME_OUT       1
/* the following functions aim to get ctp&dut test environment */
#define INVALID_CTP_CHIP_ID   -1
#define INVALID_MAC_NUM       -1

/* Resolve some control packets send from CTP into CModel on UML(always happen during do regression),
   macAddr is CTP and DUT telnet port MAC */
static uint8 _ctp_telnet_port_mac[6] = {0x9E, 0x0A, 0x1B, 0x2C, 0x3D, 0x4E};
static uint8 _dut1_telnet_port_mac[6] = {0x5E, 0xA0, 0xB1, 0xC2, 0xD3, 0xE4};
static uint8 _dut2_telnet_port_mac[6] = {0x5E, 0xA0, 0xB1, 0xC2, 0xDB, 0x02};
static uint8 _dut3_telnet_port_mac[6] = {0x5E, 0xA0, 0xB1, 0xC2, 0xDB, 0x03};
static uint8 _dut4_telnet_port_mac[6] = {0x5E, 0xA0, 0xB1, 0xC2, 0xDB, 0x04};
static uint8 _dut5_telnet_port_mac[6] = {0x5E, 0xA0, 0xB1, 0xC2, 0xDB, 0x05};
static uint8 _dut6_telnet_port_mac[6] = {0x5E, 0xA0, 0xB1, 0xC2, 0xDB, 0x06};

#define IS_UML_ENV_FILTERING_MAC(pkt) \
        (((pkt[0] == _ctp_telnet_port_mac[0]) && (pkt[1] == _ctp_telnet_port_mac[1]) &&\
         (pkt[2] == _ctp_telnet_port_mac[2]) && (pkt[3] == _ctp_telnet_port_mac[3]) &&\
         (pkt[4] == _ctp_telnet_port_mac[4]) && (pkt[5] == _ctp_telnet_port_mac[5])) \
        || ((pkt[0] == _dut1_telnet_port_mac[0]) && (pkt[1] == _dut1_telnet_port_mac[1]) &&\
         (pkt[2] == _dut1_telnet_port_mac[2]) && (pkt[3] == _dut1_telnet_port_mac[3]) &&\
         (pkt[4] == _dut1_telnet_port_mac[4]) && (pkt[5] == _dut1_telnet_port_mac[5]))\
        || ((pkt[0] == _dut2_telnet_port_mac[0]) && (pkt[1] == _dut2_telnet_port_mac[1]) &&\
         (pkt[2] == _dut2_telnet_port_mac[2]) && (pkt[3] == _dut2_telnet_port_mac[3]) &&\
         (pkt[4] == _dut2_telnet_port_mac[4]) && (pkt[5] == _dut2_telnet_port_mac[5]))\
        || ((pkt[0] == _dut3_telnet_port_mac[0]) && (pkt[1] == _dut3_telnet_port_mac[1]) &&\
         (pkt[2] == _dut3_telnet_port_mac[2]) && (pkt[3] == _dut3_telnet_port_mac[3]) &&\
         (pkt[4] == _dut3_telnet_port_mac[4]) && (pkt[5] == _dut3_telnet_port_mac[5]))\
        || ((pkt[0] == _dut4_telnet_port_mac[0]) && (pkt[1] == _dut4_telnet_port_mac[1]) &&\
         (pkt[2] == _dut4_telnet_port_mac[2]) && (pkt[3] == _dut4_telnet_port_mac[3]) &&\
         (pkt[4] == _dut4_telnet_port_mac[4]) && (pkt[5] == _dut4_telnet_port_mac[5]))\
        || ((pkt[0] == _dut5_telnet_port_mac[0]) && (pkt[1] == _dut5_telnet_port_mac[1]) &&\
         (pkt[2] == _dut5_telnet_port_mac[2]) && (pkt[3] == _dut5_telnet_port_mac[3]) &&\
         (pkt[4] == _dut5_telnet_port_mac[4]) && (pkt[5] == _dut5_telnet_port_mac[5]))\
        || ((pkt[0] == _dut6_telnet_port_mac[0]) && (pkt[1] == _dut6_telnet_port_mac[1]) &&\
         (pkt[2] == _dut6_telnet_port_mac[2]) && (pkt[3] == _dut6_telnet_port_mac[3]) &&\
         (pkt[4] == _dut6_telnet_port_mac[4]) && (pkt[5] == _dut6_telnet_port_mac[5])))


/***************************************************************************
 *
 * Global and Declarations
 *
***************************************************************************/
extern sim_model_t g_sim_model[];
extern drv_init_chip_info_t drv_init_chip_info;
extern uint32 chip_agent_get_mode();

//uint32 g_cm_pkt_dma_en = FALSE;
uint32 g_cm_pkt_dma_en = TRUE; /*modified by huangxt for support DMA on UML*/
uint32 um_emu_mode = UM_EMU_MODE_SDK;

/* default software emulation environment is a linecard with two humbers */
static mac_descriptor_t swemu_mac[MAX_LOCAL_CHIP_NUM][MAX_MACNUM] =
{
    /* valid   queue_type   eth_if_id   sock  error_sock */
    {{1, SIM_IPE_Q, 0, -1, 0}, {1, SIM_IPE_Q, 1, -1, 0}, {1, SIM_IPE_Q, 2, -1, 0}, {1, SIM_IPE_Q, 3, -1, 0},
     {1, SIM_IPE_Q, 4, -1, 0}, {1, SIM_IPE_Q, 5, -1, 0}, {1, SIM_IPE_Q, 6, -1, 0}, {1, SIM_IPE_Q, 7, -1, 0},
     {1, SIM_IPE_Q, 8, -1, 0}, {1, SIM_IPE_Q, 9, -1, 0}, {1, SIM_IPE_Q, 10, -1, 0}, {1, SIM_IPE_Q, 11, -1, 0},
     {1, SIM_IPE_Q, 12, -1, 0}, {1, SIM_IPE_Q, 13, -1, 0}, {1, SIM_IPE_Q, 14, -1, 0}, {1, SIM_IPE_Q, 15, -1, 0},
     {1, SIM_IPE_Q, 16, -1, 0}, {1, SIM_IPE_Q, 17, -1, 0}, {1, SIM_IPE_Q, 18, -1, 0}, {1, SIM_IPE_Q, 19, -1, 0},
     {1, SIM_IPE_Q, 20, -1, 0}, {1, SIM_IPE_Q, 21, -1, 0}, {1, SIM_IPE_Q, 22, -1, 0}, {1, SIM_IPE_Q, 23, -1, 0},
     {1, SIM_IPE_Q, 24, -1, 0}, {1, SIM_IPE_Q, 25, -1, 0}, {1, SIM_IPE_Q, 26, -1, 0}, {1, SIM_IPE_Q, 27, -1, 0},
     {1, SIM_IPE_Q, 28, -1, 0}, {1, SIM_IPE_Q, 29, -1, 0}, {1, SIM_IPE_Q, 30, -1, 0}, {1, SIM_IPE_Q, 31, -1, 0},
     {1, SIM_IPE_Q, 32, -1, 0}, {1, SIM_IPE_Q, 33, -1, 0}, {1, SIM_IPE_Q, 34, -1, 0}, {1, SIM_IPE_Q, 35, -1, 0},
     {1, SIM_IPE_Q, 36, -1, 0}, {1, SIM_IPE_Q, 37, -1, 0}, {1, SIM_IPE_Q, 38, -1, 0}, {1, SIM_IPE_Q, 39, -1, 0},
     {1, SIM_IPE_Q, 40, -1, 0}, {1, SIM_IPE_Q, 41, -1, 0}, {1, SIM_IPE_Q, 42, -1, 0}, {1, SIM_IPE_Q, 43, -1, 0},
     {1, SIM_IPE_Q, 44, -1, 0}, {1, SIM_IPE_Q, 45, -1, 0}, {1, SIM_IPE_Q, 46, -1, 0}, {1, SIM_IPE_Q, 47, -1, 0},
     {1, SIM_IPE_Q, 48, -1, 0}, {1, SIM_IPE_Q, 49, -1, 0}, {1, SIM_IPE_Q, 50, -1, 0}, {1, SIM_IPE_Q, 51, -1, 0}, /* XGMac 4-7 */
     {1, SIM_IPE_Q, 52, -1, 0}, {1, SIM_IPE_Q, 53, -1, 0}, {1, SIM_IPE_Q, 54, -1, 0}, {1, SIM_IPE_Q, 55, -1, 0}, /* XGMac 8-11 */
     {1, SIM_IPE_Q, 56, -1, 0}, {1, SIM_IPE_Q, 57, -1, 0}, {1, SIM_IPE_Q, 58, -1, 0}, {1, SIM_IPE_Q, 59, -1, 0},
     {1, SIM_FWD_Q, 96, -1, 0}, /* CPU MAC */ /*SYSTEM MODIFY, Added by huangxt. use different CPU MAC, never cover this when merge code!.*/
    },
};


/***************************************************************************
 *
 * Functions
 *
****************************************************************************/

/***************************************************************************
 * Name:     _swemu_set_um_emu_mode
 * Purpose:
 * Parameters:
 * Input:      um_emu_mode
 * Output:     none.
 * Return:     none.
 * Note:       none.
****************************************************************************/
void
swemu_set_um_emu_mode(um_emu_mode_t mode)
{
    um_emu_mode = mode;
}

/***************************************************************************
 * Name:     swemu_get_um_emu_mode
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     um_emu_mode.
 * Note:       none.
****************************************************************************/
um_emu_mode_t
swemu_get_um_emu_mode(void)
{
    return um_emu_mode;
}

/***************************************************************************
 * Name:     _swemu_read_profile_string_atrim
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
swemu_read_profile_string_atrim(char* output, const char* input)
{
    char *p = NULL;

    DRV_PTR_VALID_CHECK(input);
    DRV_PTR_VALID_CHECK(output);

    /*trim left space*/
    while (*input != '\0')
    {
        if (WHITE_SPACE(*input))
        {
            ++input;
        }
        else
        {
            break;
        }
    }

    sal_strcpy(output, input);

    /*trim right space*/
    p = output + sal_strlen(output) - 1;

    while (p >= output)
    {
      /*skip empty line*/
        if (WHITE_SPACE(*p) || ('\r' == (*p)) || ('\n' == (*p)))
        {
            --p;
        }
        else
        {
            break;
        }
    }

    *(++p) = '\0';

    return DRV_E_NONE;
}


/***************************************************************************
 * Name:      swemu_received_packet_process
 * Purpose:    encapsulate the packet received from network port socket, including add crc,
              and all fields in ipe_in_pkt_t structure
 * Parameters:
 * Input:      inpkt pointer, packet pointer, len, idx.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
              Other = Error, please reference DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
swemu_received_packet_process(uint8 *packet,
                                        uint32 len,
                                        uint32 chipid_offset,
                                        uint32 mac_num)
{
    out_pkt_t indication;
    uint32 chanid = 0;
    queue_type_t queue_type;
    bool discard = FALSE;
    int32 ret = DRV_E_NONE;
    uint8 chip_id = chipid_offset + drv_init_chip_info.drv_init_chipid_base;

    DRV_PTR_VALID_CHECK(packet);
    sal_memset(&indication, 0, sizeof(indication));

    queue_type = swemu_mac[chipid_offset][mac_num].queue_type;
    indication.chip_id = chip_id;
    indication.packet_length = len;
    indication.pkt = packet;
    indication.mac_num = mac_num;

    if(!g_sim_model[chipid_offset].macnum2chanid)
    {
        CMODEL_DEBUG_OUT_INFO(" g_sim_model[chipid_offset].macnum2chanid  == 0!!!! chipid_offset %d, mac_num %d\n",chipid_offset,mac_num);
        sal_free(packet);
        packet = NULL;
        return DRV_E_NONE;
    }

    ret = g_sim_model[chipid_offset].macnum2chanid(chip_id, mac_num, &chanid);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Mapping mac number to chanid error!mac number=%d\n", mac_num);
        sal_free(packet);
        packet = NULL;
        return ret;
    }

    indication.chan_id = chanid;

    ret = g_sim_model[chipid_offset].mac_rx[mac_num](&indication, &discard);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Mac entity receives packet error!\n");
        sal_free(packet);
        packet = NULL;
        return ret;
    }

    if (discard)
    {
        sal_free(packet);
        packet = NULL;
        return DRV_E_NONE;
    }

    /* mac receive stats */
    if (g_sim_model[chipid_offset].mac_stats_receive != NULL)
    {
        ret = g_sim_model[chipid_offset].mac_stats_receive(&indication);

        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Mac stats receives error!\n");
            sal_free(packet);
            packet = NULL;
            return ret;
        }
    }

    ret = ctckal_queue_send(sim_queue[queue_type], (void *)&indication, sizeof(indication));
    if(DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Netrx engine send outpkt to queue error ! ret = %d\n", ret);
        sal_free(packet);
        packet = NULL;
        return ret;
    }

    return DRV_E_NONE;
}

/***************************************************************************
 * Name:     _swemu_get_max_fdp
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static uint32
_swemu_get_max_fdp(void)
{
    uint32 chipid_offset, macnum;
    uint32 max_fdp = 0;

    for (chipid_offset = 0; chipid_offset < MAX_LOCAL_CHIP_NUM; chipid_offset ++)
    {
        for (macnum = 0; macnum < MAX_MACNUM; macnum ++)
        {
            if (max_fdp < swemu_mac[chipid_offset][macnum].sock)
            {
                max_fdp = swemu_mac[chipid_offset][macnum].sock;
            }
        }
    }

    max_fdp ++;

    return max_fdp;
}


/***************************************************************************
 * Name:     _swemu_read_profile_get_topo_chip_num_info
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
 int32
_swemu_dump_topo_mac_description_info()
{
    uint8 lchip = 0;
    uint8 mac = 0;
    uint8 hit = 0;
    uint8 lchip_num = MAX_LOCAL_CHIP_NUM;

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        hit  = 0;
        for (mac = 0; mac < MAX_MACNUM; mac++)
        {
            if (swemu_mac[lchip][mac].valid)
            {
                if (0 == hit)
                {
                    sal_printf("---------- dut topo (lchip = %d) ----------\n", lchip);
                    hit = 1;
                }

                sal_printf("mac%02d <----------> eth%02d(queue_type:%d sock:%d error_sock:%d)\n",
                           mac, swemu_mac[lchip][mac].eth_if_id, swemu_mac[lchip][mac].queue_type,
                           swemu_mac[lchip][mac].sock,swemu_mac[lchip][mac].error_sock);
            }
        }
    }

    return DRV_E_NONE;
}



/***************************************************************************
 * Name:     _swemu_receive_packet_from_ctp
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int
_swemu_receive_packet_from_ctp(void)
{
    int32 maxfdp=0, sock_selected = 0;
    uint8 buffer[PKT_BUFFER_SIZE]={0}, *packet = NULL;
    fd_set fds;
    struct timeval timeout={SOCKET_TIME_OUT, 0};
    int32 len, ret = DRV_E_NONE;
    uint32 chipid_offset = 0, macnum = 0;

    maxfdp = _swemu_get_max_fdp();

    for (;;)
    {
        FD_ZERO(&fds);

        for (chipid_offset = 0; chipid_offset < MAX_LOCAL_CHIP_NUM; chipid_offset ++)
        {
            for (macnum = 0; macnum < MAX_MACNUM; macnum ++)
            {
                if (swemu_mac[chipid_offset][macnum].valid && (!swemu_mac[chipid_offset][macnum].error_sock))
                {
                    FD_SET(swemu_mac[chipid_offset][macnum].sock, &fds);
                }
            }
        }

        timeout.tv_sec = SOCKET_TIME_OUT;
        timeout.tv_usec = 0;

        sock_selected = select(maxfdp, &fds, NULL, NULL, &timeout);

        if (-1 == sock_selected)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Selecting socket error!\n");
            continue;
        }

        if (0 == sock_selected)
        {
            continue;
        }


        for (chipid_offset = 0; chipid_offset < MAX_LOCAL_CHIP_NUM; chipid_offset ++)
        {
            for (macnum = 0; macnum < MAX_MACNUM; macnum ++)
            {
                if (swemu_mac[chipid_offset][macnum].error_sock
                    || !FD_ISSET(swemu_mac[chipid_offset][macnum].sock, &fds)
                    || !swemu_mac[chipid_offset][macnum].valid)
                {
                    continue;
                }

                len = recvfrom(swemu_mac[chipid_offset][macnum].sock, buffer, PKT_BUFFER_SIZE, 0, 0, 0);
                if (len < 0)
                {
                    CMODEL_DEBUG_OUT_INFO("Warning:: Failed to receive socket, chipid_offset=%d, macnum=%d \n", chipid_offset, macnum);
                    continue;
                }

                if (IS_UML_ENV_FILTERING_MAC(buffer))
                {
                    CMODEL_DEBUG_OUT_INFO("Attention:: Filtering one packet according to CTP&DUT telnet portMac, macNum = %d\n", macnum);
                    continue;
                }

                /* stats macnum receive pkt num */
                g_pkt_cnt_rx[macnum] ++;

                packet=(uint8 *)sal_malloc(MTU);
                if (!packet)
                {
                    CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Memory is exhausted!\n");
                    continue;
                }

                sal_memset(packet, 0, MTU);
                if (!sal_memcpy(packet, buffer, len))
                {
                    CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Error in sal_memcpy!\n");
                    continue;
                }

                /* store received inpkt  from mac */
                ret = sim_asic_gen_macrx_inpkt(chipid_offset, packet, len, macnum);
                if (ret < DRV_E_NONE)
                {
                    CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Store received packet process error!\n");
                    continue;
                }

                ret = swemu_received_packet_process(packet, len, chipid_offset, macnum);
                if (DRV_E_NONE != ret)
                {
                    CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Received packet process error!\n");
                    continue;
                }
            }
        }


        /* stats receive pkt count */
        ret = sim_asic_gen_rx_pkt_cnt(g_pkt_cnt_rx);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Pkt cnt error on rx direction!\n");
        }
    }

    return 0;
}

/***************************************************************************
 * Name:     _swemu_send_packet_to_ctp
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_swemu_send_packet_to_ctp(void)
{
    out_pkt_t request;
    uint32 size = 0, mac_num = 0;
    bool discard = FALSE;
    int32 ret = DRV_E_NONE;
    uint32 chipid_offset = 0;
    uint8* p_tmp_pkt = NULL;
    uint32 um_emu_mode = swemu_get_um_emu_mode();

    size = sizeof(request);
    sal_memset(&request, 0, sizeof(request));

    for (;;)
    {
        if (CTCKAL_SUCCESS != ctckal_queue_receive(sim_queue[SIM_NETTX_Q], (void *)&request, &size, QUE_TIMEOUT_INFINITE))
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Nettx engine receive input packet error!\n");
            continue;
        }

        chipid_offset = request.chip_id - drv_init_chip_info.drv_init_chipid_base;

        ret = g_sim_model[chipid_offset].chanid2macnum(request.chip_id, request.chan_id, &mac_num);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Mapping chanid to macnum error, chipid=%d, chanid =%d!\n",
                                   request.chip_id, request.chan_id);
            sal_free(request.pkt);
            request.pkt = NULL;
            sal_free(request.exception);
            request.exception = NULL;
            continue;
        }

        request.mac_num = mac_num;

        ret = g_sim_model[chipid_offset].mac_tx[mac_num](&request, &discard);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Mac transmit packet error, chipid=%d, mac num =%d!\n",
                                      request.chip_id, mac_num);
            sal_free(request.pkt);
            request.pkt = NULL;
            sal_free(request.exception);
            request.exception = NULL;
            continue;
        }

        if (discard)
        {
            sal_free(request.pkt);
            request.pkt = NULL;
            sal_free(request.exception);
            request.exception = NULL;
            continue;
        }

        /* store received pkt from mac */
        ret = sim_asic_gen_mactx_outpkt(request.chip_id, request.pkt, request.packet_length, request.chan_id);
        if (ret < DRV_E_NONE)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Store received packet process error!\n");
            continue;
        }

        /* mac transmit stats */
        if (g_sim_model[chipid_offset].mac_stats_transmit != NULL)
        {
            ret = g_sim_model[chipid_offset].mac_stats_transmit(&request);
            if (ret < DRV_E_NONE)
            {
                CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! mac_stats_transmit process error!\n");
            }
        }

        if (UM_EMU_MODE_SDK == um_emu_mode)
        {
            /* append packet to 64 bytes */
            if (request.packet_length < CM_PKT_MIN_SIZE)
            {
                p_tmp_pkt = sal_malloc(CM_PKT_MIN_SIZE);
                sal_memset(p_tmp_pkt, 0, CM_PKT_MIN_SIZE);
                sal_memcpy(p_tmp_pkt, request.pkt, (request.packet_length - CRC_LEN));
                sal_free(request.pkt);
                request.pkt = p_tmp_pkt;
                request.packet_length = CM_PKT_MIN_SIZE;
            }

            if (g_cm_pkt_dma_en && (CPU_MACNUM == mac_num))
            {
                /* send packet to CPU by DMA mode */
                cm_sim_dma_tx_pkt(&request);
            }
            else
            {
                ret = send(swemu_mac[chipid_offset][mac_num].sock, (void *)(request.pkt), request.packet_length - CRC_LEN, 0);
            }
        }
        else
        {
            /* cmodel */
            ret = send(swemu_mac[chipid_offset][mac_num].sock, (void *)(request.pkt), request.packet_length - CRC_LEN, 0);
        }

        if (ret < DRV_E_NONE)
        {
            sal_free(request.pkt);
            request.pkt = NULL;
            sal_free(request.exception);
            request.exception = NULL;
            continue;
        }

        g_pkt_cnt_tx[mac_num]++;
        sal_free(request.pkt);
        request.pkt = NULL;
        sal_free(request.exception);
        request.exception = NULL;

        ret = sim_asic_gen_tx_pkt_cnt(g_pkt_cnt_tx);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Pkt cnt error on tx direction!\n");
        }
    }

    return 0;
}

//#endif





/***************************************************************************
 * Name:     _swemu_read_profile_get_topo_chip_num_info
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_swemu_read_profile_get_topo_chip_num_info(const char *line, int32 *chip_num)
{
    char *ch = NULL;

    DRV_PTR_VALID_CHECK(line);

    ch = sal_strstr(line, "=");
    if (NULL == ch)
    {
        return DRV_E_INVALID_ALLOC_INFO;
    }
    else
    {
        ch++;
    }

    while (sal_isspace(*ch))
    {
        ch++;
    }

    if (*ch != '\0')
    {
        *chip_num = atoi(ch);
#if 0
        if ((*chip_num < drv_init_chip_info.drv_init_chipid_base)
            || (*chip_num >= drv_init_chip_info.drv_init_chipid_base + drv_init_chip_info.drv_init_chip_num))
        {
            *chip_num = INVALID_CTP_CHIP_ID;
            return DRV_E_INVALID_CHIP;
        }
#endif
    }
    else
    {
        return DRV_E_INVALID_ALLOC_INFO;
    }

    return DRV_E_NONE;
}


/***************************************************************************
 * Name:     _swemu_read_profile_get_topo_null_macnum_info
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_swemu_read_profile_get_topo_null_macnum_info(const char *line, int32 *null_mac_num)
{
    char *ch = NULL;

    DRV_PTR_VALID_CHECK(line);

    ch = sal_strstr(line, "=");
    if (NULL == ch)
    {
        return DRV_E_INVALID_ALLOC_INFO;
    }
    else
    {
        ch++;
    }

    while (sal_isspace(*ch))
    {
        ch++;
    }

    if (*ch != '\0')
    {
        *null_mac_num = atoi(ch);
    }
    else
    {
        return DRV_E_INVALID_ALLOC_INFO;
    }

    return DRV_E_NONE;
}


/***************************************************************************
 * Name:     _swemu_read_profile_get_topo_mac_description_info
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_swemu_read_profile_get_topo_mac_description_info(const char *line, int32 *chip_num, int32 *mac_num)
{
    char *ch = NULL;
    char *ch_temp = NULL;
    uint8 chip_id_offset = 0;

    DRV_PTR_VALID_CHECK(line);

    ch = sal_strstr(line, "{");
    if (NULL == ch)
    {
        return DRV_E_INVALID_ALLOC_INFO;
    }
    else
    {
        ch++;
    }

    while (sal_isspace(*ch))
    {
        ch++;
    }

    if (*chip_num == INVALID_CTP_CHIP_ID)
    {
        return DRV_E_NONE;
    }

    chip_id_offset = *chip_num - drv_init_chip_info.drv_init_chipid_base;
    if (chip_id_offset >= MAX_LOCAL_CHIP_NUM)
    {
        return DRV_E_INVALID_ALLOC_INFO;
    }

    while (*ch != '\0')
    {
        if (0 == sal_strncmp(ch, "TRUE", sal_strlen("TRUE")))
        {
            swemu_mac[chip_id_offset][*mac_num].valid = TRUE;
            ch+= sal_strlen("TRUE");
        }
        else if (0 == sal_strncmp(ch, "FALSE", sal_strlen("FALSE")))
        {
            swemu_mac[chip_id_offset][*mac_num].valid = FALSE;
            ch+= sal_strlen("FALSE");
        }
        else
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! INVALID info in topo config file!\n");
            return DRV_E_INVALID_ALLOC_INFO;
        }

        while (sal_isspace(*ch) || (*ch == ','))
        {
            ch++;
        }

        if (0 == sal_strncmp(ch, "SIM_IPE_Q", sal_strlen("SIM_IPE_Q")))
        {
            swemu_mac[chip_id_offset][*mac_num].queue_type = SIM_IPE_Q;
            ch+=sal_strlen("SIM_IPE_Q");
        }
        else if (0 == sal_strncmp(ch, "SIM_FWD_Q", sal_strlen("SIM_FWD_Q")))
        {
             swemu_mac[chip_id_offset][*mac_num].queue_type = SIM_FWD_Q;
             ch+=sal_strlen("SIM_FWD_Q");
        }
        else if (0 == sal_strncmp(ch, "SIM_EPE_Q", sal_strlen("SIM_EPE_Q")))
        {
             swemu_mac[chip_id_offset][*mac_num].queue_type = SIM_EPE_Q;
             ch+=sal_strlen("SIM_EPE_Q");
        }
        else if (0 == sal_strncmp(ch, "SIM_OAM_Q", sal_strlen("SIM_OAM_Q")))
        {
             swemu_mac[chip_id_offset][*mac_num].queue_type = SIM_OAM_Q;
             ch+=sal_strlen("SIM_OAM_Q");
        }
        else if (0 == sal_strncmp(ch, "SIM_NETTX_Q", sal_strlen("SIM_NETTX_Q")))
        {
             swemu_mac[chip_id_offset][*mac_num].queue_type = SIM_NETTX_Q;
             ch+=sal_strlen("SIM_NETTX_Q");
        }
        else
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! QUEUE TYPE in topo config file!\n");
            return DRV_E_INVALID_ALLOC_INFO;
        }

        while (sal_isspace(*ch) || (*ch == ','))
        {
            ch++;
        }

        ch_temp = ch;
        while ( *ch_temp != '}')
        {
            ch_temp++;
        }

        *ch_temp = '\0';

        swemu_mac[chip_id_offset][*mac_num].eth_if_id = atoi(ch);
        swemu_mac[chip_id_offset][*mac_num].sock = 0;
        swemu_mac[chip_id_offset][*mac_num].error_sock = 0;

        *ch = *ch_temp;
    }

    return DRV_E_NONE;
}


/***************************************************************************
 * Name:     _swemu_read_profile_get_environment
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_swemu_read_profile_get_environment(FILE *fp)
{
    char string[LINE_LEN_MAX] = {0};
    char line[LINE_LEN_MAX] = {0};
    int ret = DRV_E_NONE;
    int32 chip_id = INVALID_CTP_CHIP_ID;
    int32 mac_num = INVALID_MAC_NUM;
    int32 null_mac_num = 0;

    /* check file pointer */
    DRV_PTR_VALID_CHECK(fp);

    /* parse software emulation topo profile */
    while (!feof(fp))
    {
        sal_memset(string, 0, sizeof(string));
        fgets(string, LINE_LEN_MAX, fp);

        /* check comment line */
        if ('#' == string[0])
        {
            continue;
        }

        /* trim left and right space */
        sal_memset(line, 0, sizeof(line));

        ret = swemu_read_profile_string_atrim(line, string);
        if (ret < DRV_E_NONE)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Read environment profile!\n");
            return ret;
        }

        /* check NULL line */
        if (EMPTY_LINE(line[0]))
        {
            continue;
        }

        /* parse chip ID info */
        if (0 == sal_strncmp(line, "[CHIP_ID]", sal_strlen("[CHIP_ID]")))
        {
            chip_id = INVALID_CTP_CHIP_ID;
            mac_num = INVALID_MAC_NUM;
            ret = _swemu_read_profile_get_topo_chip_num_info(line, &chip_id);
            if (ret < DRV_E_NONE)
            {
                CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Chip num info in topo config file!\n");
                return ret;
            }
            mac_num = 0;
        }
        /* parse cmodel NULL mac number info */
        else if (0 == sal_strncmp(line, "NULL_MAC_NUM", sal_strlen("NULL_MAC_NUM")))
        {
            ret = _swemu_read_profile_get_topo_null_macnum_info(line, &null_mac_num);
            if (ret <0)
            {
                CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! NULL Mac num info in topo config file!\n");
                return ret;
            }
            mac_num+=null_mac_num;
            /* reset null_mac_num */
            null_mac_num = 0;
        }
        else if  (0 == sal_strncmp(line, "{", sal_strlen("{")))
        {
            ret = _swemu_read_profile_get_topo_mac_description_info(line, &chip_id, &mac_num);
            if (ret < DRV_E_NONE)
            {
                CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Mac num info in topo config file!\n");
                return ret;
            }
            mac_num++;
        }
        /* invalid config info */
        else
        {
            return DRV_E_INVALID_ALLOC_INFO;
        }

    }

    return DRV_E_NONE;
}


/***************************************************************************
 * Name:     swemu_environment_setting
 * Purpose:   Init software emulation environment
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 swemu_environment_setting(char *filename)
{
    /* Init the software emulation environment accroding to the configuration in profile, implement it later  */
    #define INVALID_ETHER_IF_ID 0xFFFF
    #define PROFILE_PATH_MAX  512
    FILE *fp = NULL;
    int32 ret = DRV_E_NONE;;
    char file_path[PROFILE_PATH_MAX] = {0};
    char* p_file_path = NULL;
    uint32 um_emu_mode = swemu_get_um_emu_mode();

    DRV_PTR_VALID_CHECK(filename);

    p_file_path = getcwd(file_path, PROFILE_PATH_MAX);

    if ((UM_EMU_MODE_SDK == um_emu_mode) && (NULL != p_file_path))
    {
        sal_strcat(file_path, "/");
        sal_strcat(file_path, filename);
    }
    else
    {
        sal_strcpy(file_path, filename);
    }

    /* open the config profile */
    fp = fopen(file_path, "r");
    if((NULL == fp) || feof(fp))
    {
        sal_printf("Use Default Topo Setting!\n");
        ret = 0;
        goto RELEASE;
    }
    else
    {
        sal_printf("Use Setting Topo Configuration File: %s\n", file_path);
    }

    /* clear default config */
    sal_memset(&swemu_mac[0][0], 0, sizeof(mac_descriptor_t) * MAX_LOCAL_CHIP_NUM * MAX_MACNUM);

    /* the following will paser the file to get environment */
    ret = _swemu_read_profile_get_environment(fp);

RELEASE:
    /* close file */
    if (NULL != fp)
    {
        fclose(fp);
        fp = NULL;
    }
    return ret ;

}


/***************************************************************************
 * Name:     swemu_ios_netrx_engine
 * Purpose:   Receive packet Process
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
void swemu_ios_netrx_engine()
{
    drv_work_platform_type_t platform_type;
    drv_get_platform_type(&platform_type);
#ifdef CMODEL_WITH_AGENT
    uint32 chip_agent_mode = chip_agent_get_mode();
    if (1 == chip_agent_mode)
    {
        /* CHIP_AGT_MODE_CLIENT : need not SWEMU */
    }
    else if (2 == chip_agent_mode)
    {
        /* CHIP_AGT_MODE_SERVER : SWEMU on Board */
        if(platform_type == HW_PLATFORM)
        {
            swemu_receive_packet_from_board();
        }
        else
        {
            _swemu_receive_packet_from_ctp();
        }
    }
    else
    {
        /* CHIP_AGT_MODE_NONE : SWEMU on UML/for CTP */
        _swemu_receive_packet_from_ctp();
    }
#else
        /* CHIP_AGT_MODE_NONE : SWEMU on UML/for CTP */
        _swemu_receive_packet_from_ctp();
#endif

}

/***************************************************************************
 * Name:     swemu_ios_nettx_engine
 * Purpose:   Transmit packet Process
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
void swemu_ios_nettx_engine()
{
    drv_work_platform_type_t platform_type;
    drv_get_platform_type(&platform_type);
#ifdef CMODEL_WITH_AGENT
    uint32 chip_agent_mode = chip_agent_get_mode();

    if (1 == chip_agent_mode)
    {
        /* CHIP_AGT_MODE_CLIENT : need not SWEMU */
    }
    else if (2 == chip_agent_mode)
    {
        /* CHIP_AGT_MODE_SERVER : SWEMU on Board */
        if(platform_type == HW_PLATFORM)
        {
            swemu_send_packet_to_board();
        }
        else
        {
            _swemu_send_packet_to_ctp();
        }
    }    
    else
    {
        /* CHIP_AGT_MODE_NONE : SWEMU on UML/for CTP */
        _swemu_send_packet_to_ctp();
    }
#else
        /* CHIP_AGT_MODE_NONE : SWEMU on UML/for CTP */
        _swemu_send_packet_to_ctp();
#endif
}

int32 swemu_socket_init_ctp(void)
{
    struct sockaddr_ll me;
    struct ifreq  ifr;
    int32 chipid_offset = 0, macnum = 0;
    char if_name[MAX_ETH_NAME_LEN] = {0};
    mac_descriptor_t *mac = NULL;

    sal_memset(if_name, 0, MAX_ETH_NAME_LEN);

    for (chipid_offset = 0; chipid_offset < MAX_LOCAL_CHIP_NUM; chipid_offset++)
    {
        for (macnum = 0; macnum < MAX_MACNUM; macnum ++)
        {
            mac = &swemu_mac[chipid_offset][macnum];
            if (!mac->valid)
            {
                continue;
            }

            mac->sock = socket(PF_PACKET, SOCK_RAW, sal_htons(ETH_P_ALL));

            if (mac->sock < 0)
            {
                mac->error_sock = TRUE;
                continue;
            }

            sal_snprintf(if_name, MAX_ETH_NAME_LEN, "eth%d", mac->eth_if_id);
            sal_memset(&ifr, 0, sizeof(struct ifreq));
            sal_strncpy(ifr.ifr_name, if_name, MAX_ETH_NAME_LEN);

            if (ioctl(mac->sock, SIOCGIFINDEX, &ifr, sizeof(struct ifreq)) < 0)
            {
                mac->error_sock = TRUE;
                CMODEL_DEBUG_OUT_INFO("Warning:: Failed to get the interface information of <%s>\n",
                	                        if_name);
                continue;
            }

            sal_memset(&me, 0, sizeof(struct sockaddr_ll));
            me.sll_family = AF_PACKET;
            me.sll_ifindex = ifr.ifr_ifindex;
            me.sll_pkttype = PACKET_OTHERHOST;

            if (bind(mac->sock, (struct sockaddr *)&me, sizeof(struct sockaddr_ll))<0)
            {
                CMODEL_DEBUG_OUT_INFO("Warning:: Failed to bind socket for chipid_offset %d mac: %d\n",
                                          chipid_offset, macnum);
                mac->error_sock = TRUE;
                continue;
            }

            mac->error_sock = FALSE;
        }
    }
    return DRV_E_NONE;
}

/***************************************************************************
 * Name:      swemu_socket_init
 * Purpose:    implement socket communication for net rx and tx.
 * Parameters:
 * Input:      none.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
              Other = Error, please reference DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 swemu_socket_init(void)
{
    drv_work_platform_type_t platform_type;
    drv_get_platform_type(&platform_type);
     
#ifdef CMODEL_WITH_AGENT
    uint32 chip_agent_mode = chip_agent_get_mode();

    if (1 == chip_agent_mode)
    {
        /* CHIP_AGT_MODE_CLIENT : need not SWEMU */
    }
    else if (2 == chip_agent_mode)
    {
        /* CHIP_AGT_MODE_SERVER : SWEMU on Board */
        if(platform_type == HW_PLATFORM)
        {
            swemu_socket_init_board();
        }
        else
        {
            swemu_socket_init_ctp();
        }
    }
    else
    {
        /* CHIP_AGT_MODE_NONE : SWEMU on UML/for CTP */
        swemu_socket_init_ctp();
    }
#else
        /* CHIP_AGT_MODE_NONE : SWEMU on UML/for CTP */
        swemu_socket_init_ctp();
#endif
    return DRV_E_NONE;
}
