/****************************************************************************
 * cm_com_tacm_engine.c: Tcam lookup engine handle
 *
 * Copyright: (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V4.2
 * Author:       ZhouW
 * Date:         2011-07-07.
 * Reason:       First Create.

 * Revision:     V4.28.1
 * Author:       XuZx
 * Date:         2011-09-29.
 * Reason:       revise for specs v4.28.1.
 ****************************************************************************/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "drv_lib.h"
#include "cm_lib.h"
#include "cm_com_tcam_engine.h"

#define NAME_SIZE   32

struct tcam_get_rst_inputs_s
{
    uint32 chip_id;
    tcam_key_type_t tcam_key_type;
    uint32 *p_tcam_hit_index;
};
typedef struct tcam_get_rst_inputs_s tcam_get_rst_inputs_t;

static int32
_cm_com_tcam_engine_get_associated(tcam_get_rst_inputs_t *tcam_get_rst_inputs,
                                                  tcam_lkp_outputs_t *p_tcam_lookup_result)
{
    uint8 acl_en[DRV_ACL_LOOKUP_NUM] = {FALSE};
    uint32 cmd = 0;
    uint32 lookup_index = 0;
    uint8 is_160bits_tcam_ds = FALSE;
    uint32 chip_id = tcam_get_rst_inputs->chip_id;
    tcam_key_type_t tcam_key_type = tcam_get_rst_inputs->tcam_key_type;
    uint32 index_base[DRV_TCAM_LOOKUP_NUM] = {0};
    uint32 table_base[DRV_TCAM_LOOKUP_NUM] = {0};
    uint32 index_shift[DRV_TCAM_LOOKUP_NUM] = {0};
    uint32 aging_en[DRV_TCAM_LOOKUP_NUM] = {0};
    tbls_id_t ad_table_id = MaxTblId_t;
    uint32 lookup_result_index = 0;
    char ds_tbl_name[NAME_SIZE] = {0};

    tcam_engine_lookup_result_ctl0_t tcam_engine_lookup_result_ctl0;
    tcam_engine_lookup_result_ctl1_t tcam_engine_lookup_result_ctl1;
    tcam_engine_lookup_result_ctl2_t tcam_engine_lookup_result_ctl2;
    tcam_engine_lookup_result_ctl3_t tcam_engine_lookup_result_ctl3;

    sal_memset(&tcam_engine_lookup_result_ctl0, 0, sizeof(tcam_engine_lookup_result_ctl0));
    cmd = DRV_IOR(TcamEngineLookupResultCtl0_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_engine_lookup_result_ctl0));

    sal_memset(&tcam_engine_lookup_result_ctl1, 0, sizeof(tcam_engine_lookup_result_ctl1));
    cmd = DRV_IOR(TcamEngineLookupResultCtl1_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_engine_lookup_result_ctl1));

    sal_memset(&tcam_engine_lookup_result_ctl2, 0, sizeof(tcam_engine_lookup_result_ctl2));
    cmd = DRV_IOR(TcamEngineLookupResultCtl2_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_engine_lookup_result_ctl2));

    sal_memset(&tcam_engine_lookup_result_ctl3, 0, sizeof(tcam_engine_lookup_result_ctl3));
    cmd = DRV_IOR(TcamEngineLookupResultCtl3_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_engine_lookup_result_ctl3));

    if (IS_BIT_SET(tcam_key_type, 6)
        || ((tcam_key_type >= TCAM_TYPE_MAC_USERID) && (tcam_key_type <= TCAM_TYPE_TRILL_TUNNELID)))
    {
        is_160bits_tcam_ds = TRUE;
    }
    else
    {
        is_160bits_tcam_ds = FALSE;
    }

    if (IS_BIT_SET(tcam_key_type, 6))
    {
        /* IPv6 ACL only use ACL0 and ACL1, not ACL2 and ACL3 */
        for (lookup_index = 0; lookup_index < DRV_ACL_LOOKUP_NUM; lookup_index++)
        {
            acl_en[lookup_index] = IS_BIT_SET(tcam_key_type, (5 - lookup_index));
        }

        switch (tcam_key_type & 0x3)
        {
            case 0:
                /* IPv6 ACL 0 */
                ad_table_id = DsIpv6Acl0Tcam_t;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl0.acl0_index_base0;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl0.acl0_table_base0;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl0.acl0_index_shift0;

                /* IPv6 ACL 1 */
                index_base[DRV_ACL_LOOKUP1] = tcam_engine_lookup_result_ctl0.acl1_index_base0;
                table_base[DRV_ACL_LOOKUP1] = tcam_engine_lookup_result_ctl0.acl1_table_base0;
                index_shift[DRV_ACL_LOOKUP1] = tcam_engine_lookup_result_ctl0.acl1_index_shift0;
                break;
            case 1:
                /* IPv4 ACL 0 */
                ad_table_id = DsIpv4Acl0Tcam_t;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl0.acl0_index_base1;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl0.acl0_table_base1;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl0.acl0_index_shift1;

                /* IPv4 ACL 1 */
                index_base[DRV_ACL_LOOKUP1] = tcam_engine_lookup_result_ctl0.acl1_index_base1;
                table_base[DRV_ACL_LOOKUP1] = tcam_engine_lookup_result_ctl0.acl1_table_base1;
                index_shift[DRV_ACL_LOOKUP1] = tcam_engine_lookup_result_ctl0.acl1_index_shift1;

                /* IPv4 ACL 2 */
                index_base[DRV_ACL_LOOKUP2] = tcam_engine_lookup_result_ctl0.acl2_index_base1;
                table_base[DRV_ACL_LOOKUP2] = tcam_engine_lookup_result_ctl0.acl2_table_base1;
                index_shift[DRV_ACL_LOOKUP2] = tcam_engine_lookup_result_ctl0.acl2_index_shift1;

                /* IPv4 ACL 3 */
                index_base[DRV_ACL_LOOKUP3] = tcam_engine_lookup_result_ctl0.acl3_index_base1;
                table_base[DRV_ACL_LOOKUP3] = tcam_engine_lookup_result_ctl0.acl3_table_base1;
                index_shift[DRV_ACL_LOOKUP3] = tcam_engine_lookup_result_ctl0.acl3_index_shift1;
                break;
            default:
                /* Mac ACL 0 */
                ad_table_id = DsMacAcl0Tcam_t;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl0.acl0_index_base2;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl0.acl0_table_base2;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl0.acl0_index_shift2;

                /* Mac ACL 1 */
                index_base[DRV_ACL_LOOKUP1] = tcam_engine_lookup_result_ctl0.acl1_index_base2;
                table_base[DRV_ACL_LOOKUP1] = tcam_engine_lookup_result_ctl0.acl1_table_base2;
                index_shift[DRV_ACL_LOOKUP1] = tcam_engine_lookup_result_ctl0.acl1_index_shift2;

                /* Mac ACL 2 */
                index_base[DRV_ACL_LOOKUP2] = tcam_engine_lookup_result_ctl0.acl2_index_base2;
                table_base[DRV_ACL_LOOKUP2] = tcam_engine_lookup_result_ctl0.acl2_table_base2;
                index_shift[DRV_ACL_LOOKUP2] = tcam_engine_lookup_result_ctl0.acl2_index_shift2;

                /* Mac ACL 3 */
                index_base[DRV_ACL_LOOKUP3] = tcam_engine_lookup_result_ctl0.acl3_index_base2;
                table_base[DRV_ACL_LOOKUP3] = tcam_engine_lookup_result_ctl0.acl3_table_base2;
                index_shift[DRV_ACL_LOOKUP3] = tcam_engine_lookup_result_ctl0.acl3_index_shift2;
                break;
        }
    }
    else /* is NOT Acl Key */
    {
        switch (tcam_key_type & 0x3F)
        {
            case TCAM_TYPE_IPV4_UCAST: /* 0x10 */
                ad_table_id = DsIpv4UcastDaTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_table_base0;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_index_base0;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_index_shift0;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_aging_en0;
                break;
            case TCAM_TYPE_IPV4_MCAST: /* 0x11 */
                ad_table_id = DsIpv4McastDaTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_table_base1;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_index_base1;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_index_shift1;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_aging_en1;
                break;
            case TCAM_TYPE_IPV6_UCAST: /* 0x12 */
                ad_table_id = DsIpv6UcastDaTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_table_base2;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_index_base2;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_index_shift2;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_aging_en2;
                break;
            case TCAM_TYPE_IPV6_MCAST: /* 0x13 */
                ad_table_id = DsIpv6McastDaTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_table_base3;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_index_base3;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_index_shift3;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_da_aging_en3;
                break;
            case TCAM_TYPE_IPV4_RPF: /* 0x14 */
                ad_table_id = DsIpv4UcastDaTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_table_base0;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_base0;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_shift0;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_aging_en0;
                break;
            case TCAM_TYPE_IPV6_RPF: /* 0x15 */
                ad_table_id = DsIpv6UcastDaTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_table_base1;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_base1;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_shift1;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_aging_en1;
                break;
            case TCAM_TYPE_IPV4_NAT: /* 0x16 */
                ad_table_id = DsIpv4SaNatTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_table_base2;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_base2;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_shift2;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_aging_en2;
                break;
            case TCAM_TYPE_IPV6_NAT: /* 0x17 */
                ad_table_id = DsIpv6SaNatTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_table_base3;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_base3;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_shift3;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_aging_en3;
                break;
            case TCAM_TYPE_IPV4_PBR: /* 0x18 */
                ad_table_id = DsIpv4UcastPbrDualDaTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_table_base4;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_base4;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_shift4;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_aging_en4;
                break;
            case TCAM_TYPE_IPV6_PBR: /* 0x19 */
                ad_table_id = DsIpv6UcastPbrDualDaTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_table_base5;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_base5;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_index_shift5;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.ip_sa_aging_en5;
                break;
            case TCAM_TYPE_MAC_DA: /* 0x1A */
                ad_table_id = DsMacTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.mac_da_table_base;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.mac_da_index_base;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.mac_da_index_shift;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.mac_da_aging_en;
                break;
            case TCAM_TYPE_MAC_SA: /* 0x1B */
                ad_table_id = DsMacTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.mac_sa_table_base;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.mac_sa_index_base;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.mac_sa_index_shift;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl2.mac_sa_aging_en;
                break;
            case TCAM_TYPE_FCOE_DA:
                ad_table_id = DsFcoeDaTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.fcoe_table_base0;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.fcoe_index_base0;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.fcoe_index_shift0;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.fcoe_aging_en0;
                break;
            case TCAM_TYPE_FCOE_SA:
                ad_table_id = DsFcoeSaTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.fcoe_table_base1;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.fcoe_index_base1;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.fcoe_index_shift1;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.fcoe_aging_en1;
                break;
            case TCAM_TYPE_TRILl_UCAST_DA:
                ad_table_id = DsTrillDaUcastTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.trill_table_base0;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.trill_index_base0;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.trill_index_shift0;
                aging_en[0] = tcam_engine_lookup_result_ctl3.trill_aging_en0;
                break;
            case TCAM_TYPE_TRILl_MCAST_DA:
                ad_table_id = DsTrillDaMcastTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.trill_table_base1;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.trill_index_base1;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.trill_index_shift1;
                aging_en[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.trill_aging_en1;
                break;
            /* the following is UserId and TunnelId */
            case TCAM_TYPE_MAC_USERID: /* 0x20 */
                ad_table_id = DsUserIdMacTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_table_base0;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_base0;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_shift0;
                break;
            case TCAM_TYPE_IPV6_USERID:/* 0x21 */
                ad_table_id = DsUserIdIpv6Tcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_table_base1;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_base1;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_shift1;
                break;
            case TCAM_TYPE_IPV4_USERID:/* 0x22 */
                ad_table_id = DsUserIdIpv4Tcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_table_base2;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_base2;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_shift2;
                break;
            case TCAM_TYPE_VLAN_USERID:/* 0x23 */
                ad_table_id = DsUserIdVlanTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_table_base3;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_base3;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_shift3;
                break;
            case TCAM_TYPE_IPV6_TUNNELID:/* 0x24 */
                ad_table_id = DsTunnelIdIpv6Tcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_table_base4;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_base4;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_shift4;
                break;
            case TCAM_TYPE_IPV4_TUNNELID:/* 0x25 */
                ad_table_id = DsTunnelIdIpv4Tcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_table_base5;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_base5;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_shift5;
                break;
            case TCAM_TYPE_PBB_TUNNELID:/* 0x26 */
                ad_table_id = DsTunnelIdPbbTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_table_base6;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_base6;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_shift6;
                break;
            case TCAM_TYPE_CAPWAP_TUNNELID:/* 0x27 */
                ad_table_id = DsTunnelIdCapwapTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_table_base7;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_base7;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_shift7;
                break;
            case TCAM_TYPE_TRILL_TUNNELID:/* 0x28 */
                ad_table_id = DsTunnelIdTrillTcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_table_base8;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_base8;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl1.user_id_index_shift8;
                break;
            case TCAM_TYPE_MAC_IPV6_MCAST:/* 0x30 */
                ad_table_id = DsMacIpv6Tcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.mac_ip_table_base0;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.mac_ip_index_base0;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.mac_ip_index_shift0;
                break;
            case TCAM_TYPE_MAC_IPV4_MCAST:/* 0x31 */
                ad_table_id = DsMacIpv4Tcam_t;
                table_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.mac_ip_table_base1;
                index_base[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.mac_ip_index_base1;
                index_shift[DRV_ACL_LOOKUP0] = tcam_engine_lookup_result_ctl3.mac_ip_index_shift1;
                break;
            default:
                /* no process but push (0, 0) */
                break;
        }
    }

    if (cmodel_debug_on)
    {
        DRV_IF_ERROR_RETURN(drv_get_tbl_string_by_id(ad_table_id, ds_tbl_name));
    }

    for (lookup_index = DRV_ACL_LOOKUP0; lookup_index < DRV_ACL_LOOKUP_NUM; lookup_index++)
    {
        if (((DRV_ACL_LOOKUP0 == lookup_index)
            && (!IS_BIT_SET(tcam_key_type, 6) || acl_en[lookup_index]))
            || ((DRV_ACL_LOOKUP0 != lookup_index) && acl_en[lookup_index]))
        {
            if (p_tcam_lookup_result->tcam_lkp_output[lookup_index].tcam_lkp_result_valid)
            {
                lookup_result_index = ((tcam_get_rst_inputs->p_tcam_hit_index[lookup_index]
                                            - (index_base[lookup_index] << 6)) >> index_shift[lookup_index]);
                //sal_printf("key index is 0x%x \n", tcam_get_rst_inputs->p_tcam_hit_index[lookup_index]);
                //sal_printf("lookup_result_index is 0x%x , 0x%x \n", lookup_result_index, (table_base[lookup_index] << 6));
                if (((DRV_ACL_LOOKUP0 == lookup_index) && is_160bits_tcam_ds) || (DRV_ACL_LOOKUP0 != lookup_index))
                {
                    /* 158 Bits */
                    cmd = DRV_IOR(ad_table_id + lookup_index, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id,
                                                  lookup_result_index,
                                                  cmd,
                                                  p_tcam_lookup_result->tcam_lkp_output[lookup_index].ds_ad));
                    if (cmodel_debug_on)
                    {
                        sal_memset(ds_tbl_name, 0, sizeof(ds_tbl_name));
                        DRV_IF_ERROR_RETURN(drv_get_tbl_string_by_id(ad_table_id + lookup_index, ds_tbl_name));
                    }
                    CMODEL_DEBUG_OUT_INFO("CModelDebug: Tcam Hit, and get AD table %s index = 0x%x!\n",
                                                    ds_tbl_name, lookup_result_index);

                }
                else
                {
                    /* 79 Bits */
                    cmd = DRV_IOR(ad_table_id + lookup_index, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id,
                                                  lookup_result_index,
                                                  cmd,
                                                  p_tcam_lookup_result->tcam_lkp_output[lookup_index].ds_ad));
                    if (cmodel_debug_on)
                    {
                        sal_memset(ds_tbl_name, 0, sizeof(ds_tbl_name));
                        DRV_IF_ERROR_RETURN(drv_get_tbl_string_by_id(ad_table_id + lookup_index, ds_tbl_name));
                    }
                    CMODEL_DEBUG_OUT_INFO("CModelDebug: Tcam Hit, and get AD table %s index = 0x%x!\n",
                                                    ds_tbl_name, lookup_result_index);


                }

                /* aging Ptr: 8K Tcam + (128K MAC + 32K + 16 Mac) / (32K LPM hash + 256 TCAM) */
                if (aging_en[lookup_index])
                {
                    /* UpdateAgingCache(lookupResultIndex0[12:0]) */
                }
            }
        }
        else
        {
            p_tcam_lookup_result->tcam_lkp_output[lookup_index].ds_ad = NULL; /* MayBe memory leak? */
        }
    }

    return DRV_E_NONE;
}

int32 cm_com_tcam_engine_handle(tcam_lkp_inputs_t* p_tcam_lookup_info,
                                            tcam_lkp_outputs_t* p_tcam_lookup_result)
{
    uint32 tcam_lookup_index[DRV_TCAM_LOOKUP_NUM];
    void* tcam_key = NULL;
    tcam_key_type_t tcam_key_type = TCAM_TYPE_NUM;
    uint32 tcam_key_size = 0;
    uint32 chip_id_offset = 0;
    tbls_id_t tcam_key_id = MaxTblId_t;
    uint32 tcam_key_max_size =0;
    uint8 entry[MAX_ENTRY_NUMBER] = {0};
    tcam_get_rst_inputs_t tcam_get_rst_inputs;
    uint32 lookup_index = 0;
    uint32 lookup_count = 0;
    uint8 found_key = 0;

    DRV_PTR_VALID_CHECK(p_tcam_lookup_info);
    DRV_PTR_VALID_CHECK(p_tcam_lookup_info->tcam_key);
    DRV_PTR_VALID_CHECK(p_tcam_lookup_result);

    tcam_key = p_tcam_lookup_info->tcam_key;
    tcam_key_type = p_tcam_lookup_info->tcam_key_type;
    tcam_key_size = p_tcam_lookup_info->tcam_key_size;
    chip_id_offset = p_tcam_lookup_info->chip_id - drv_init_chip_info.drv_init_chipid_base;

    for (lookup_index = 0; lookup_index < DRV_TCAM_LOOKUP_NUM; lookup_index++)
    {
        p_tcam_lookup_result->tcam_lkp_output[lookup_index].tcam_lkp_result_valid = FALSE;
        tcam_lookup_index[lookup_index] = DRV_TCAM_INVALID_INDEX;
    }

    tcam_key_size = (DRV_BYTES_PER_ENTRY << tcam_key_size); /* unit: bytes */

    /* Get tcam key ID according to Tcam key type */
    if (!IS_BIT_SET(tcam_key_type, 6))   /* is not ACL lookup */
    {
        switch(tcam_key_type)
        {
            /* IPE forwarding */
            case TCAM_TYPE_IPV4_UCAST:  /* IPv4Ucast: 0x10 */
            case TCAM_TYPE_IPV4_RPF:    /* IPv4RPF  : 0x14 */
                tcam_key_id = DsIpv4UcastRouteKey_t;
                break;
            case TCAM_TYPE_IPV4_MCAST:  /* IPv4Mcast: 0x11 */
                tcam_key_id = DsIpv4McastRouteKey_t;
                break;
            case TCAM_TYPE_IPV6_UCAST: /* IPv6Ucast : 0x12 */
            case TCAM_TYPE_IPV6_RPF:   /* IPv6RPF   : 0x15 */
                tcam_key_id = DsIpv6UcastRouteKey_t;
                break;
            case TCAM_TYPE_IPV6_MCAST:  /* IPv6Mcast: 0x13 */
                tcam_key_id = DsIpv6McastRouteKey_t;
                break;
            case TCAM_TYPE_IPV4_NAT:    /* IPv4NAT  : 0x16 */
                tcam_key_id = DsIpv4NatKey_t;
                break;
            case TCAM_TYPE_IPV6_NAT:    /* IPv6NAT  : 0x17 */
                tcam_key_id = DsIpv6NatKey_t;
                break;
            case TCAM_TYPE_IPV4_PBR:    /* IPv4PBR  : 0x18 */
                tcam_key_id = DsIpv4PbrKey_t;
                break;
            case TCAM_TYPE_IPV6_PBR:    /* IPv6PBR  : 0x19 */
                tcam_key_id = DsIpv6PbrKey_t;
                break;
            case TCAM_TYPE_MAC_DA:      /* MacDA    : 0x1A */
            case TCAM_TYPE_MAC_SA:      /* MacSA    : 0x1B */
                tcam_key_id = DsMacBridgeKey_t;
                break;
            case TCAM_TYPE_FCOE_DA:     /* FcoeDA   : 0x1C */
                tcam_key_id = DsFcoeRouteKey_t;
                break;
            case TCAM_TYPE_FCOE_SA:     /* FcoeSA   : 0x1D */
                tcam_key_id = DsFcoeRpfKey_t;
                break;
            case TCAM_TYPE_TRILl_UCAST_DA: /* TrillUcastDA   : 0x1E */
                tcam_key_id = DsTrillUcastRouteKey_t;
                break;
            case TCAM_TYPE_TRILl_MCAST_DA: /* TrillMcastDA   : 0x1F */
                tcam_key_id = DsTrillMcastRouteKey_t;
                break;
            case TCAM_TYPE_MAC_USERID:   /* UseridMac:   0x20 */
                tcam_key_id = DsUserIdMacKey_t;
                break;
            case TCAM_TYPE_IPV6_USERID:  /* UseridIPv6:  0x21 */
                tcam_key_id = DsUserIdIpv6Key_t;
                break;
            case TCAM_TYPE_IPV4_USERID:  /* UseridIPv4:  0x22 */
                tcam_key_id = DsUserIdIpv4Key_t;
                break;
            case TCAM_TYPE_VLAN_USERID:  /* UseridVlan:  0x23 */
                tcam_key_id = DsUserIdVlanKey_t;
                break;
            case TCAM_TYPE_IPV6_TUNNELID:/* TunnelIPv6:  0x24 */
                tcam_key_id = DsTunnelIdIpv6Key_t;
                break;
            case TCAM_TYPE_IPV4_TUNNELID:/* TunnelIPv4:  0x25 */
                tcam_key_id = DsTunnelIdIpv4Key_t;
                break;
            case TCAM_TYPE_PBB_TUNNELID: /* TunnelPbb:   0x26 */
                tcam_key_id = DsTunnelIdPbbKey_t;
                break;
            case TCAM_TYPE_CAPWAP_TUNNELID: /* TunnelCapwap:   0x27 */
                tcam_key_id = DsTunnelIdCapwapKey_t;
                break;
            case TCAM_TYPE_TRILL_TUNNELID:  /* TunnelTrill:    0x28 */
                tcam_key_id = DsTunnelIdTrillKey_t;
                break;
            case TCAM_TYPE_MAC_IPV6_MCAST:  /* MacIpv6:    0x30 */
                tcam_key_id = DsMacIpv6Key_t;
                break;
            case TCAM_TYPE_MAC_IPV4_MCAST:  /* MacIpv4:    0x31 */
                tcam_key_id = DsMacIpv4Key_t;
                break;
            default:
                CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! Unknown Tcam key because tcamKeyType = %d\n", tcam_key_type);
                break;
        }
    }
    else                                /* is AclQos Key */
    {
        switch (tcam_key_type & 0x3)
        {
            case TCAM_TYPE_IPV6_ACL_QOS:            /* TcamKeyType[1:0] = 2b'00  ---- AclIpv6 */
                tcam_key_id = DsAclIpv6Key0_t;
                break;
            case TCAM_TYPE_IPV4_ACL_QOS:            /* TcamKeyType[1:0] = 2b'01  ---- AclIpv4 */
                tcam_key_id = DsAclIpv4Key0_t;
                break;
            case TCAM_TYPE_MAC_ACL_QOS:             /* TcamKeyType[1:0] = 2b'10  ---- AclMac  */
                tcam_key_id = DsAclMacKey0_t;
                break;
            default:
                CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! Unknown AclQos key because tcamKeyType = 7'b1XXXX11\n");
                break;
        }
    }

    if (tcam_key_id == MaxTblId_t)
    {
        return DRV_E_INVALID_TBL;
    }

    tcam_key_max_size = TABLE_ENTRY_SIZE(tcam_key_id); /* get from driver,
                                                          Maybe can get from the related control register. */


    DRV_IF_ERROR_RETURN(drv_sram_ds_to_entry(tcam_key_id, (void *)tcam_key, (uint32 *)entry));


    if (0 == TABLE_MAX_INDEX(tcam_key_id))
    {
        tcam_key = entry + (tcam_key_max_size);
    }
    else
    {
        tcam_key = entry + (tcam_key_max_size - TCAM_KEY_SIZE(tcam_key_id));
    }

    if (!IS_BIT_SET(tcam_key_type, 6)) /* is Not AclQos key */
    {
        lookup_count = 1;
    }
    else
    {
        lookup_count = DRV_ACL_LOOKUP_NUM;
    }

    for (lookup_index = 0; lookup_index < lookup_count; lookup_index++)
    {
#if (SDK_WORK_PLATFORM == 1)
        DRV_IF_ERROR_RETURN(tcam_model_lookup(chip_id_offset, (tcam_key_id + lookup_index),
                                              (uint32 *)tcam_key, &tcam_lookup_index[lookup_index]));
#else
        /* TBD, use Chip TCAM lookup??? add by zhouw */
#endif
    }

    sal_memset(&tcam_get_rst_inputs, 0, sizeof(tcam_get_rst_inputs));
    tcam_get_rst_inputs.chip_id = p_tcam_lookup_info->chip_id;
    tcam_get_rst_inputs.tcam_key_type = p_tcam_lookup_info->tcam_key_type;
    tcam_get_rst_inputs.p_tcam_hit_index = tcam_lookup_index;

    for (lookup_index = 0; lookup_index < lookup_count; lookup_index++)
    {
        if (tcam_lookup_index[lookup_index] != DRV_TCAM_INVALID_INDEX)
        {
            p_tcam_lookup_result->tcam_lkp_output[lookup_index].tcam_lkp_result_valid = TRUE;
            found_key = 1;
        }
    }

    /* debug information */
    sim_cmodel_debug_show_tcam_tbl(tcam_key_id, found_key, tcam_lookup_index[lookup_index]);    

#if (SDK_WORK_PLATFORM == 1)
    /*Stroe tcam key for cosim*/
    if (cosim_db.store_key)
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_key(tcam_key, tcam_key_id));
    }
#endif

    DRV_IF_ERROR_RETURN(_cm_com_tcam_engine_get_associated(&tcam_get_rst_inputs, p_tcam_lookup_result));

    return DRV_E_NONE;
}

int32
cm_com_tcam_conflict_resolve(tcam_lookup_info_t* p_tcam_lookup_info,
                                        tcam_lookup_result_t* p_tcam_lookup_result)
{
    uint8 chip_id_offset = 0;
    uint8 chip_id = 0;
    uint32* p_key_index = NULL;
    uint32 table_id = MaxTblId_t;

    DRV_PTR_VALID_CHECK(p_tcam_lookup_info);
    DRV_PTR_VALID_CHECK(p_tcam_lookup_info->tcam_key);
    DRV_PTR_VALID_CHECK(p_tcam_lookup_result);

    p_key_index = &p_tcam_lookup_result->key_index;
    chip_id = p_tcam_lookup_info->chip_id;
    chip_id_offset = (p_tcam_lookup_info->chip_id - drv_init_chip_info.drv_init_chipid_base);

    /* Here maybe DsLpmTcam80Key/DsFibUserId80Key or DsLpmTcam160Key/DsFibUserId160Key,
       the 4 tables share 256*80bits Tcam, and will use to resolve FibUserId Hash and LPM's conflict,
       TcamKeyType means 80bits/160bits Key, and key.isUserId use to divide FibUserIdKey or LPMKey, so
       don't divide FibUserId and LPM tableId, olny flag 80bits/160bits keySize */
    if (0 == p_tcam_lookup_info->tcam_key_type)
    {
        table_id = DsLpmTcam80Key_t;
    }
    else
    {
        table_id = DsLpmTcam160Key_t;
    }

#if (SDK_WORK_PLATFORM == 1)
    DRV_IF_ERROR_RETURN(tcam_model_lookup(chip_id_offset, table_id, p_tcam_lookup_info->tcam_key, p_key_index));
#else
        /* TBD, use Chip TCAM lookup??? add by zhouw */
#endif

    if (DRV_TCAM_INVALID_INDEX != *p_key_index)
    {
        p_tcam_lookup_result->valid = TRUE;
    }

    return DRV_E_NONE;
}

