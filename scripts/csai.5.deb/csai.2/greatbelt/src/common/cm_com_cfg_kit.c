/****************************************************************************
 * cm_sim_cfg_kit.c: Provides cmodel load configuration tools.
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       ZhouW
 * Date:         2010-10-30.
 * Reason:       First Create.
 *
 * Revision:     V1.0.
 * Author:       JiangJf
 * Date:         2010-12-07.
 * Reason:       Add memory allocation functions.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "cm_lib.h"
#include "drv_lib.h"
/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/
#define BIT_NUM_IN_UINT16 16
#define TCAM_EMULATION_MODE 1

#define DS_USER_ID_INGRESS_DEFAULT_INDEX_NUM 256
#define DS_USER_ID_EGRESS_DEFAULT_INDEX_NUM 256
#define DS_TUNNEL_ID_DEFAULT_INDEX_NUM 64

enum cm_chip_mem_id_e
{
    CM_MEMORY0,
    CM_MEMORY1,
    CM_MEMORY2,
    CM_MEMORY3,
    CM_MEMORY4,
    CM_MEMORY5,
    CM_MEMORY6,
    CM_MEMORY7,
    CM_MEMORY8,

    CM_TCAM_KEY,
    CM_TCAM_AD,

    CM_LPM_TCAM_KEY,
    CM_LPM_TCAM_AD,

    CM_MAX_MEM_CHIP_ID,
};
typedef enum cm_chip_mem_id_e cm_chip_mem_id_t;

struct cm_mem_chip_allocation_info_s
{
    char   mem_name[128];
    uint32 allocated_entry_num;            /* entry size is always 72/80 */
    uint32 max_mem_entry_num;
    uint32 hardware_data_base_address;     /* to dynic memory and TcamAd memory, is 4word mode base address */
    uint32 hardware_data_base_address_8w;  /* to dynic memory and TcamAd memory, is 8word mode base address */
};
typedef struct cm_mem_chip_allocation_info_s cm_mem_chip_allocation_info_t;

extern tbls_id_t user_id_hash_key[];

struct cm_block_allocated_record_s
{
    uint32 max_allocated_num;
    uint32 min_allocated_num;
};
typedef struct cm_block_allocated_record_s cm_block_allocated_record_t;


/*
tcam info
*/
#define  TCAM_SUPER_BLOCK_NUM           4
#define  TCAM_BLOCK_PER_SUPRE_BLOCK     4
#define  TCAM_AD_BLOCK_NUM              4

struct cm_tcam_super_block_info_s
{
    uint32 allocated_entry_num;
    uint32 idx_base;
};
typedef struct cm_tcam_super_block_info_s cm_tcam_super_block_info_t;
typedef struct cm_tcam_super_block_info_s cm_tcam_ad_block_info_t;

struct cm_tcam_block_info_s
{
    uint32 allocated_entry_num;
    uint32 max_mem_entry_num;
    uint32 hw_data_base_addr;
    uint32 hw_data_base_addr_8w;

    uint32 acl_160_bit_map  :4;
    uint32 acl_320_bit_map  :4;
    uint32 acl_640_bit_map  :2;
    uint32 resv             :18;

    cm_tcam_super_block_info_t tcam_super_block[TCAM_SUPER_BLOCK_NUM];
};
typedef struct cm_tcam_block_info_s cm_tcam_block_info_t;


struct cm_tcam_ad_info_s
{
    uint32 allocated_entry_num;
    uint32 max_mem_entry_num;
    uint32 hw_data_base_addr;
    uint32 hw_data_base_addr_8w;

    uint32 acl_0_bit_map  :4;
    uint32 acl_1_bit_map  :4;
    uint32 acl_2_bit_map  :4;
    uint32 acl_3_bit_map  :4;
    uint32 resv           :16;

    cm_tcam_ad_block_info_t tcam_ad_block[TCAM_SUPER_BLOCK_NUM];
};
typedef struct cm_tcam_ad_info_s cm_tcam_ad_info_t;


/* create share list malloc info */
#define INITILIZE_MEM_PROFILE_INFO_PTR(mem_id)  \
do {\
    sram_share_mem_info[mem_id].share_mem_profile_info_ptr = \
                                   (share_mem_profile_info_t *)sal_malloc(sizeof(share_mem_profile_info_t)); \
    if (sram_share_mem_info[mem_id].share_mem_profile_info_ptr == NULL) \
    { \
        SAL_LOG_FATAL("%s %d ******** mem allocation, malloc share info  no enough memory!!********\n", __FUNCTION__, __LINE__); \
        exit(1); \
    } \
    sal_memset(sram_share_mem_info[mem_id].share_mem_profile_info_ptr, 0, sizeof(share_mem_profile_info_t));\
}while(0)

/* get the mem profile share list info ptr */
#define MEM_PROFILE_INFO_PTR(mem_id) (sram_share_mem_info[mem_id].share_mem_profile_info_ptr)

#define MEM_PROFILE_BITMAP(mem_id) sram_share_mem_info[mem_id].share_mem_profile_info_ptr->mem_profile_bitmap
#define MEM_PROFILE_HW_OFFSET(mem_id, block_num) \
    sram_share_mem_info[mem_id].share_mem_profile_info_ptr->mem_profile_hw_data_base_offset[block_num]
#define MEM_PROFILE_ENTRY_NUM(mem_id, block_num) \
    sram_share_mem_info[mem_id].share_mem_profile_info_ptr->mem_profile_entry_num[block_num]
#define MEM_PROFILE_CHKED_FLG(mem_id, block_num) \
    sram_share_mem_info[mem_id].share_mem_profile_info_ptr->mem_profile_chked_flg[block_num]
#define MEM_PROFILE_MIN_ENTRY_INDEX(mem_id, block_num) \
    sram_share_mem_info[mem_id].share_mem_profile_info_ptr->mem_profile_hw_data_base_offset[block_num]
#define MEM_PROFILE_MAX_ENTRY_INDEX(mem_id, block_num) \
    (MEM_PROFILE_MIN_ENTRY_INDEX(mem_id,block_num) + MEM_PROFILE_ENTRY_NUM(mem_id, block_num) - 1)
#define MEM_PROFILE_ACCESS_MODE_FLAG(mem_id) \
    (sram_share_mem_info[mem_id].share_mem_profile_info_ptr->access_mode_care_flag)


#define NUM_2K (2*1024)
#define NUM_4K (4*1024)
#define NUM_6K (6*1024)
#define NUM_8K (8*1024)
#define NUM_10K (10*1024)
#define NUM_12K (12*1024)
#define NUM_14K (14*1024)
#define NUM_16K (16*1024)
#define NUM_20K (20*1024)
#define NUM_24K (24*1024)
#define NUM_26K (26*1024)
#define NUM_28K (28*1024)
#define NUM_30K (30*1024)
#define NUM_32K (32*1024)

/* ------------------------- used for RTL register initialize start-------------------------*/
/* table register info start */

/* TCAM lookup configuration recommendation */

/* Differentiate ACL lookup and non-ACL:
       per-80-bits TCAM entry use a bit isAcl */

/* For ACL key to differentate IPv4/IPv6/MPLS/MAC key:
       per-160-bits entry add two bits subTableId[1:0] */

/* For Non-ACL key to differentate 8 table:
       per-80-bits entry add 3 bits tableid[2:0] */

/* For UserId to differentate IPv4/IPv6/VLAN/MAC key:
       per-80-bits entry add two bits subTableId[1:0] */

/* For TunnelID to differentate IPv4/IPv6/PBB/CAPWAP/TRILL/EgressXlate key:
       per-80-bits entry add three bits subTableId[2:0] */

/* For TRILL/FCoE to differentate TRILL Mc/Uc, FCoE Da/Sa:
       per-80-bits entry add two bits subTableId[1:0]  */

/* For IPv4DA/MAC to differentate MAC Da/Sa, IPv4 Mc/Uc:
       per-80-bits entry add two bits subTableId[1:0] */

/* For IPv4SA to differentate IPv4 NAT/PBR/RPF:
       per-80-bits entry add two bits subTableId[1:0] */

/* For IPv6DA to differentate IPv6 Mc/Uc:
       per-160-bits entry add two bits subTableId[1:0] */

/* For IPv6SA to differentate IPv6 NAT/PBR/RPF:
       per-160-bits entry add two bits subTableId[1:0] */

/* For OAM to differentate OAM type:
       per-80-bits entry add three bits subTableId[2:0] */

/*----- UserId Key table ID -----*/
#define USERID_TABLEID               0
/* UserId sub table ID */
#define USERID_VLAN_SUB_TABLEID      0
#define USERID_MAC_SUB_TABLEID       1
#define USERID_IPV4_SUB_TABLEID      2
#define USERID_IPV6_SUB_TABLEID      3

/*----- Tunnel Key table ID -----*/
#define TUNNELID_TABLEID             1
/* TunnelId sub table ID */
#define TUNNELID_IPV4_SUB_TABLEID    0
#define TUNNELID_IPV6_SUB_TABLEID    1
#define TUNNELID_PBB_SUB_TABLEID     2
#define TUNNELID_CAPWAP_SUB_TABLEID  3
#define TUNNELID_TRILL_SUB_TABLEID   4

/*----- TRILL/FCoE Key table ID -----*/
#define TRILL_FCOE_TABLEID           2
/* TRILL/FCoE sub table ID */
#define FCOE_DA_SUB_TABLEID          0
#define FCOE_SA_SUB_TABLEID          1
#define TRILL_DA_UC_SUB_TABLEID      2
#define TRILL_DA_MC_SUB_TABLEID      3

/*----- IPv4DA/MAC Key table ID -----*/
#define IPV4DA_MAC_TABLEID           3
/* IPv4DA/MAC sub table ID */
#define MAC_DA_SUB_TABLEID           0
#define MAC_SA_SUB_TABLEID           0
#define IPV4DA_UCAST_SUB_TABLEID     1
#define IPV4DA_MCAST_SUB_TABLEID     2

/*----- IPv4SA Key table ID -----*/
#define IPV4SA_TABLEID               4
/* IPv4SA sub table ID */
#define IPV4SA_NAT_SUB_TABLEID       0
#define IPV4SA_PBR_SUB_TABLEID       1
#define IPV4SA_RPF_SUB_TABLEID       2

/*----- IPv6DA Key table ID -----*/
#define IPV6DA_TABLEID           5
/* IPv6DA sub table ID */
#define IPV6DA_UCAST_SUB_TABLEID     0
#define IPV6DA_MCAST_SUB_TABLEID     1
#define MAC_IPV4_SUB_TABLEID         2
#define MAC_IPV6_SUB_TABLEID         3

/*----- IPv6SA Key table ID -----*/
#define IPV6SA_TABLEID               6
/* IPv6SA sub table ID */
#define IPV6SA_NAT_SUB_TABLEID       0
#define IPV6SA_PBR_SUB_TABLEID       1
#define IPV6SA_RPF_SUB_TABLEID       2

/*----- OAM Key table ID -----*/
#define OAM_TABLEID                  7
/* OAM sub table ID */
#define OAM_ETHER_SUB_TABLEID        0
#define OAM_MPLS_SUB_TABLEID         1
#define OAM_BFD_SUB_TABLEID          2
#define OAM_PBT_SUB_TABLEID          3
#define OAM_ETHERRMEP_SUB_TABLEID    4

/*----- ACL Key table ID -----*/
/* use field isAcl */
/* ACL sub table ID */
#define ACL_MAC_SUB_TABLEID          0
/* ACL IPv4 key table ID */
#define ACL_IPV4_SUB_TABLEID         1
/* ACL MPLS key table ID */
#define ACL_MPLS_SUB_TABLEID         3
/* ACL IPv6 key table ID */
#define ACL_IPV6_SUB_TABLEID         2

/* set dynamic ds cam shift */
#define DYNAMIC_SHIFT_NUM 10

enum ip_lookup_mode_e
{
    IP_LKP_MODE_RESERVED,
    IP_LKP_MODE_LPM,
    IP_LKP_MODE_TCAM,
    IP_LKP_MODE_LPM_AND_TCAM,
};
typedef enum ip_lookup_mode_e ip_lookup_mode_t;

enum fcoe_lookup_mode_e
{
    FCOE_LKP_MODE_RESERVED,
    FCOE_LKP_MODE_HASH,
    FCOE_LKP_MODE_TCAM,
    FCOE_LKP_MODE_LPM_AND_TCAM,
};
typedef enum fcoe_lookup_mode_e fcoe_lookup_mode_e;

enum trill_lookup_mode_e
{
    TRILL_LKP_MODE_RESERVED,
    TRILL_LKP_MODE_HASH,
    TRILL_LKP_MODE_TCAM,
    TRILL_LKP_MODE_LPM_AND_TCAM,
};
typedef enum trill_lookup_mode_e trill_lookup_mode_e;
/* table register info end */


#if (HOST_IS_LE == 0)
/* BE dynamic ds struct definition */
struct dynamic_ds_five_base_cam_s
{
   uint32 rsv_0                                                           :8;
   uint32 ds_dynamic_base0                                                :8;
   uint32 ds_dynamic_max_index0                                           :8;
   uint32 ds_dynamic_min_index0                                           :8;

   uint32 rsv_1                                                           :8;
   uint32 ds_dynamic_base1                                                :8;
   uint32 ds_dynamic_max_index1                                           :8;
   uint32 ds_dynamic_min_index1                                           :8;

   uint32 rsv_2                                                           :8;
   uint32 ds_dynamic_base2                                                :8;
   uint32 ds_dynamic_max_index2                                           :8;
   uint32 ds_dynamic_min_index2                                           :8;

   uint32 rsv_3                                                           :8;
   uint32 ds_dynamic_base3                                                :8;
   uint32 ds_dynamic_max_index3                                           :8;
   uint32 ds_dynamic_min_index3                                           :8;

   uint32 rsv_4                                                           :8;
   uint32 ds_dynamic_base4                                                :8;
   uint32 ds_dynamic_max_index4                                           :8;
   uint32 ds_dynamic_min_index4                                           :8;
};
typedef struct dynamic_ds_five_base_cam_s dynamic_ds_five_base_cam_t;

struct dynamic_ds_base_cam_unit_s
{
   uint32 rsv_0                                                           :8;
   uint32 ds_dynamic_base                                                :8;
   uint32 ds_dynamic_max_index                                           :8;
   uint32 ds_dynamic_min_index                                           :8;
};
typedef struct dynamic_ds_base_cam_unit_s dynamic_ds_base_cam_unit_t;

#else
/* LE dynamic ds struct definition */
struct dynamic_ds_five_base_cam_s
{
   uint32 ds_dynamic_min_index0                                           :8;
   uint32 ds_dynamic_max_index0                                           :8;
   uint32 ds_dynamic_base0                                                :8;
   uint32 rsv_0                                                           :8;

   uint32 ds_dynamic_min_index1                                           :8;
   uint32 ds_dynamic_max_index1                                           :8;
   uint32 ds_dynamic_base1                                                :8;
   uint32 rsv_1                                                           :8;

   uint32 ds_dynamic_min_index2                                           :8;
   uint32 ds_dynamic_max_index2                                           :8;
   uint32 ds_dynamic_base2                                                :8;
   uint32 rsv_2                                                           :8;

   uint32 ds_dynamic_min_index3                                           :8;
   uint32 ds_dynamic_max_index3                                           :8;
   uint32 ds_dynamic_base3                                                :8;
   uint32 rsv_3                                                           :8;


   uint32 ds_dynamic_min_index4                                           :8;
   uint32 ds_dynamic_max_index4                                           :8;
   uint32 ds_dynamic_base4                                                :8;
   uint32 rsv_4                                                           :8;

};
typedef struct dynamic_ds_five_base_cam_s dynamic_ds_five_base_cam_t;


struct dynamic_ds_base_cam_unit_s
{
   uint32 ds_dynamic_min_index                                           :8;
   uint32 ds_dynamic_max_index                                           :8;
   uint32 ds_dynamic_base                                                :8;
   uint32 rsv_0                                                          :8;
};
typedef struct dynamic_ds_base_cam_unit_s dynamic_ds_base_cam_unit_t;
#endif
/* ------------------------- used for RTL register initialize end-------------------------*/

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/
extern cmodel_tbl_info_t cmodel_tbls_info[MAX_LOCAL_CHIP_NUM][MaxTblId_t];

/* Hardware mem chip information, driver IO may user this to map hardware address for Hash key.
Hash key uses universal addressing, we shall map different index to different hardware address. */
static cm_mem_chip_allocation_info_t mem_chip_info[CM_MAX_MEM_CHIP_ID] =
{
{"Memory0",0, DRV_MEMORY0_MAX_ENTRY_NUM, DRV_MEMORY0_BASE_4W, DRV_MEMORY0_BASE_8W},/*CM_MEMORY0*/
{"Memory1",0, DRV_MEMORY1_MAX_ENTRY_NUM, DRV_MEMORY1_BASE_4W, DRV_MEMORY1_BASE_8W},/*CM_MEMORY1*/
{"Memory2",0, DRV_MEMORY2_MAX_ENTRY_NUM, DRV_MEMORY2_BASE_4W, DRV_MEMORY2_BASE_8W},/*CM_MEMORY2*/
{"Memory3",0, DRV_MEMORY3_MAX_ENTRY_NUM, DRV_MEMORY3_BASE_4W, DRV_MEMORY3_BASE_8W},/*CM_MEMORY3*/
{"Memory4",0, DRV_MEMORY4_MAX_ENTRY_NUM, DRV_MEMORY4_BASE_4W, DRV_MEMORY4_BASE_8W},/*CM_MEMORY4*/
{"Memory5",0, DRV_MEMORY5_MAX_ENTRY_NUM, DRV_MEMORY5_BASE_4W, DRV_MEMORY5_BASE_8W},/*CM_MEMORY5*/
{"Memory6",0, DRV_MEMORY6_MAX_ENTRY_NUM, DRV_MEMORY6_BASE_4W, DRV_MEMORY6_BASE_8W},/*CM_MEMORY6*/
{"Memory7",0, DRV_MEMORY7_MAX_ENTRY_NUM, DRV_MEMORY7_BASE_4W, DRV_MEMORY7_BASE_8W},/*CM_MEMORY7*/
{"Memory8",0, DRV_MEMORY8_MAX_ENTRY_NUM, DRV_MEMORY8_BASE_4W, DRV_MEMORY8_BASE_8W},/*CM_MEMORY8*/

{"Tcam key", 0, DRV_INT_TCAM_KEY_MAX_ENTRY_NUM, DRV_INT_TCAM_KEY_DATA_ASIC_BASE, 0},/*CM_TCAM_KEY*/
{"Tcam AD",  0, DRV_INT_TCAM_AD_MAX_ENTRY_NUM, DRV_INT_TCAM_AD_MEM_4W_BASE, DRV_INT_TCAM_AD_MEM_8W_BASE},/*CM_TCAM_AD*/

{"LPM Tcam key", 0, DRV_INT_LPM_TCAM_MAX_ENTRY_NUM, DRV_INT_LPM_TCAM_DATA_ASIC_BASE, 0},/* LPM TCAM KEY */
{"LPM Tcam Ad", 0, DRV_INT_LPM_TCAM_AD_MAX_ENTRY_NUM, DRV_INT_LPM_TCAM_AD_ASIC_BASE, 0},/* LPM TCAM AD */

}; /*all mem chips' info*/

static cm_tcam_block_info_t tcam_block_info;
static cm_tcam_ad_info_t tcam_ad_info;
/* Share table lists, tables in one list can only do memory allocation once */
uint32 user_id_hash_key_share_table_list[] = /* share table 0*/
{
    /* IPE/EPE: USERID_KEY_TYPE_TWO_VLAN */
    DsUserIdDoubleVlanHashKey_t,
    /* IPE/EPE: USERID_KEY_TYPE_SVLAN */
    DsUserIdSvlanHashKey_t,
    /* IPE/EPE: USERID_KEY_TYPE_CVLAN */
    DsUserIdCvlanHashKey_t,
    /* IPE/EPE: USERID_KEY_TYPE_SVLAN_COS */
    DsUserIdSvlanCosHashKey_t,
    /* IPE/EPE: USERID_KEY_TYPE_CVLAN_COS */
    DsUserIdCvlanCosHashKey_t,
    /* IPE: USERID_KEY_TYPE_MAC_SA*/
    DsUserIdMacHashKey_t,
    /* IPE: USERID_KEY_TYPE_PORT_MAC_SA */
    DsUserIdMacPortHashKey_t,
    /* IPE: USERID_KEY_TYPE_IPV4_SA */
    DsUserIdIpv4HashKey_t,
    /* EPE: USERID_KEY_TYPE_IPV4_SA */
    DsUserIdPortVlanCrossHashKey_t,
    /* IPE: USERID_KEY_TYPE_PORT_IPV4_SA */
    DsUserIdIpv4PortHashKey_t,
    /* EPE: USERID_KEY_TYPE_PORT_IPV4_SA */
    DsUserIdPortCrossHashKey_t,
    /* IPE/EPE: USERID_KEY_TYPE_PORT */
    DsUserIdPortHashKey_t,
    /* IPE: USERID_KEY_TYPE_L2 */
    DsUserIdL2HashKey_t,
    /* IPE: USERID_KEY_TYPE_IPV6_SA */
    DsUserIdIpv6HashKey_t,
    /* IPE/EPE: USERID_KEY_TYPE_PBB */
    DsTunnelIdPbbHashKey_t,
    /* IPE: USERID_KEY_TYPE_IPV4_TUNNEL, USERID_HASH_TYPE_IPV4_GRE_KEY, USERID_KEY_TYPE_IPV4_UDP */
    DsTunnelIdIpv4HashKey_t,
    /* IPE: USERID_KEY_TYPE_CAPWAP */
    DsTunnelIdCapwapHashKey_t,
    /* IPE: USERID_KEY_TYPE_TRILL_UC_RPF */
    DsTunnelIdTrillUcRpfHashKey_t,
    /* IPE: USERID_KEY_TYPE_TRILL_MC_RPF */
    DsTunnelIdTrillMcRpfHashKey_t,
    /* IPE: USERID_KEY_TYPE_TRILL_MC_ADJ */
    DsTunnelIdTrillMcAdjCheckHashKey_t,
    /* IPE: USERID_KEY_TYPE_TRILL_UC */
    DsTunnelIdTrillUcDecapHashKey_t,
    /* IPE: USERID_KEY_TYPE_TRILL_MC */
    DsTunnelIdTrillMcDecapHashKey_t,
    /* IPE: USERID_KEY_TYPE_IPV4_RPF */
    DsTunnelIdIpv4RpfHashKey_t,
    /* IPE: USERID_KEY_TYPE_PBT_OAM */
    DsPbtOamHashKey_t,
    /* IPE/EPE: USERID_HASH_TYPE_MPLS_LABEL_OAM */
    DsMplsOamLabelHashKey_t,
    /* IPE: USERID_KEY_TYPE_BFD_OAM */
    DsBfdOamHashKey_t,
    /* IPE/EPE: USERID_HASH_TYPE_ETHER_FID_OAM, USERID_HASH_TYPE_ETHER_VLAN_OAM */
    DsEthOamHashKey_t,
    /* OAM: USERID_KEY_TYPE_ETHER_RMEP */
    DsEthOamRmepHashKey_t,
}; /*AD: DsUserId/TunnelId/OamChan */

uint32 user_id_hash_ad_share_table_list[] = /* share table 1*/
{
    DsUserId_t,
    DsTunnelId_t,
    DsVlanXlate_t,
};


uint32 oam_hash_chan_share_table_list[] = /* share table 1*/
{
    DsMplsPbtBfdOamChan_t,
    DsEthOamChan_t,
};


uint32 lpm_hash_key_share_table_list[] = /* share table 2*/
{
    DsLpmIpv4Hash16Key_t,
    DsLpmIpv4Hash8Key_t,
    DsLpmIpv4McastHash32Key_t,
    DsLpmIpv4McastHash64Key_t,
    DsLpmIpv6Hash32HighKey_t,
    DsLpmIpv6Hash32MidKey_t,
    DsLpmIpv6Hash32LowKey_t,
    DsLpmIpv4NatDaPortHashKey_t,
    DsLpmIpv4NatSaHashKey_t,
    DsLpmIpv4NatSaPortHashKey_t,
    DsLpmIpv6NatDaPortHashKey_t,
    DsLpmIpv6NatSaHashKey_t,
    DsLpmIpv6NatSaPortHashKey_t,
    DsLpmIpv6McastHash0Key_t,
    DsLpmIpv6McastHash1Key_t,
};

uint32 lpm_lookup_key_share_table0_list[] = /* share table 2*/
{
    DsLpmLookupKey0_t,
};

uint32 lpm_lookup_key_share_table1_list[] = /* share table 2*/
{
    DsLpmLookupKey1_t,
};

uint32 lpm_lookup_key_share_table2_list[] = /* share table 2*/
{
    DsLpmLookupKey2_t,
};

uint32 lpm_lookup_key_share_table3_list[] = /* share table 2*/
{
    DsLpmLookupKey3_t,
};

uint32 fib_hash_key_share_table_list[] = /* share table 2*/
{
    DsMacHashKey_t,
    DsFcoeHashKey_t,
    DsFcoeRpfHashKey_t,
    DsTrillMcastHashKey_t,
    DsTrillMcastVlanHashKey_t,
    DsTrillUcastHashKey_t,
    DsAclQosIpv4HashKey_t,
    DsAclQosMacHashKey_t,
}; /*ad: DS_IP_DA/DS_IP_SA/DS_MAC/DS_TRILL_DA/DS_FCOE..*/

uint32 fib_hash_ad_share_table_list[] = /*Mac+IP share table 3*/
{
    DsMac_t,
    DsIpDa_t,
    DsIpSaNat_t,
    DsFcoeDa_t,
    DsFcoeSa_t,
    DsTrillDa_t,
    DsAcl_t,
};

uint32 nexthop_share_table_list[] = /* share table 4*/
{
    DsNextHop4W_t,
    DsNextHop8W_t,
};

uint32 edit_share_table_list[] = /* share table 5*/
{
    DsL2EditEth4W_t,
    DsL2EditEth8W_t,
    DsL2EditFlex8W_t,
    DsL2EditLoopback_t,
    DsL2EditPbb4W_t,
    DsL2EditPbb8W_t,
#if V5_20_NOTE
    DsL2EditQinQ_t,
#endif
    DsL2EditSwap_t,

    DsL3EditMpls4W_t,
    DsL3EditMpls8W_t,
    DsL3EditFlex_t,
    DsL3EditNat4W_t,
    DsL3EditNat8W_t,
    DsL3EditTunnelV4_t,
    DsL3EditTunnelV6_t,

};

uint32 oam_mep_share_table_list[] = /* share table 7*/
{
    DsEthMep_t,
    DsEthRmep_t,
    DsBfdMep_t,
    DsBfdRmep_t,
};

uint32 fwd_share_table_list[] =
{
    DsFwd_t,
};

uint32 met_entry_share_table_list[] =
{
    DsMetEntry_t,
};

uint32 mpls_share_table_list[] =
{
    DsMpls_t,
};

uint32 ma_share_table_list[] =
{
    DsMa_t,
};

uint32 ma_name_share_table_list[] =
{
    DsMaName_t,
};

uint32 stats_share_table_list[] =
{
    DsStats_t,
};

uint32 oam_lm_stat_table_list[] =
{
    DsOamLmStats_t,
};

share_mem_info_t sram_share_mem_info[] =
{
    /* Hash key and ADs*/
    {sizeof(lpm_hash_key_share_table_list)/sizeof(uint32), lpm_hash_key_share_table_list, 0, NULL},
    {sizeof(lpm_lookup_key_share_table0_list)/sizeof(uint32), lpm_lookup_key_share_table0_list, 0, NULL},
    {sizeof(lpm_lookup_key_share_table1_list)/sizeof(uint32), lpm_lookup_key_share_table1_list, 0, NULL},
    {sizeof(lpm_lookup_key_share_table2_list)/sizeof(uint32), lpm_lookup_key_share_table2_list, 0, NULL},
    {sizeof(lpm_lookup_key_share_table3_list)/sizeof(uint32), lpm_lookup_key_share_table3_list, 0, NULL},
    {sizeof(user_id_hash_key_share_table_list)/sizeof(uint32), user_id_hash_key_share_table_list, 0, NULL},
    {sizeof(user_id_hash_ad_share_table_list)/sizeof(uint32), user_id_hash_ad_share_table_list, 0, NULL},

    {sizeof(oam_hash_chan_share_table_list)/sizeof(uint32), oam_hash_chan_share_table_list, 0, NULL},

    {sizeof(fib_hash_key_share_table_list)/sizeof(uint32), fib_hash_key_share_table_list, 0, NULL},
    {sizeof(fib_hash_ad_share_table_list)/sizeof(uint32), fib_hash_ad_share_table_list, 0, NULL},

    /* other indepencence tables treated as share table */
    {sizeof(fwd_share_table_list)/sizeof(uint32), fwd_share_table_list, 0, NULL},
    {sizeof(met_entry_share_table_list)/sizeof(uint32), met_entry_share_table_list, 0, NULL},
    {sizeof(mpls_share_table_list)/sizeof(uint32), mpls_share_table_list, 0, NULL},
    {sizeof(ma_share_table_list)/sizeof(uint32), ma_share_table_list, 0, NULL},
    {sizeof(ma_name_share_table_list)/sizeof(uint32), ma_name_share_table_list, 0, NULL},

    /*Dynamic tables*/
    {sizeof(nexthop_share_table_list)/sizeof(uint32), nexthop_share_table_list, 0, NULL},
    {sizeof(edit_share_table_list)/sizeof(uint32), edit_share_table_list, 0, NULL},
    {sizeof(oam_mep_share_table_list)/sizeof(uint32), oam_mep_share_table_list, 0, NULL},

    {sizeof(stats_share_table_list)/sizeof(uint32), stats_share_table_list, 0, NULL},

    /* oam lm stats tables */
    {sizeof(oam_lm_stat_table_list)/sizeof(uint32), oam_lm_stat_table_list, 0, NULL},
};

/*In Emulation board, tcam has 16 blocks; each block 512 entries, but only first 32 entries available for each block*/
/* TCAM key share tables*/
#if 0
#if TCAM_EMULATION_MODE/*key size 6 words*/
static uint32 user_id_6w_share_table_list[] =
{
    DsUserIdIpv4Key_t,
    DsUserIdIpv6Key_t,
};

static uint32 tunnel_id_6w_share_table_list[] =
{
    DsTunnelIdIpv4Key_t,
    DsTunnelIdIpv6Key_t,
    DsTunnelIdCapwapKey_t,
    DsTunnelIdPbbKey_t,
    DsTunnelIdTrillKey_t,
};

static uint32 oam_tcam_key_share_table_list[] = /* key size 3 words*/
{
    DsEthOamKey_t,
    DsBfdOamKey_t,
    DsMplsOamLabelKey_t,
    DsPbtOamKey_t,
    DsEthOamRmepKey_t,
};/* only for emulation, oam tcam key should not share in normal operations*/

#endif

static uint32 acl_key0_share_table_list[] =
{
    DsAclIpv4Key0_t,
    DsAclMplsKey0_t,
#if TCAM_EMULATION_MODE/*key size 6 words*/
    DsAclMacKey0_t,

#endif
};

static uint32 acl_key1_share_table_list[] =
{
    DsAclIpv4Key1_t,
    DsAclMplsKey1_t,
#if TCAM_EMULATION_MODE/*key size 6 words*/
    DsAclMacKey1_t,
#endif
};

static uint32 acl_key2_share_table_list[] =
{
    DsAclIpv4Key2_t,
    DsAclMplsKey2_t,
#if TCAM_EMULATION_MODE/*key size 6 words*/
    DsAclMacKey2_t,
#endif
};

static uint32 acl_key3_share_table_list[] =
{
    DsAclIpv4Key3_t,
    DsAclMplsKey3_t,
#if TCAM_EMULATION_MODE/*key size 6 words*/
    DsAclMacKey3_t,
#endif
};

static uint32 ipv4_key_share_table_list[] =
{
    DsIpv4UcastRouteKey_t,
    DsIpv4RpfKey_t,
#if TCAM_EMULATION_MODE/*key size 3 words*/
    DsIpv4McastRouteKey_t,
    DsIpv4NatKey_t,
    DsIpv4PbrKey_t,
    DsUserIdMacKey_t,
    DsUserIdVlanKey_t,
    DsMacIpv4Key_t,     /* add DsMacIpv4Key, maybe improper shenhg 2012-2-14 */
#endif
};

static uint32 ipv6_key_share_table_list[] =
{
    DsIpv6UcastRouteKey_t,
    DsIpv6RpfKey_t,
#if TCAM_EMULATION_MODE/* key size 6 words*/
    DsIpv6McastRouteKey_t,
    DsIpv6NatKey_t,
    DsIpv6PbrKey_t,
    DsMacIpv6Key_t,     /* add DsMacIpv6Key, maybe improper shenhg 2012-2-14 */
#endif
};

static uint32 mac_key_share_table_list[] =
{
    DsMacBridgeKey_t,
    DsMacLearningKey_t,
#if TCAM_EMULATION_MODE/*key size 3 words*/
    DsUserIdMacKey_t,
    DsUserIdVlanKey_t,
#endif
};

static uint32 fcoe_key_share_table_list[] =
{
    DsFcoeRouteKey_t,
    DsFcoeRpfKey_t,
#if TCAM_EMULATION_MODE /*key size 3 words*/
    DsTrillUcastRouteKey_t,
    DsTrillMcastRouteKey_t,
#endif
};

static uint32 lpm_tcam_key_share_table_list[] =
{
    DsLpmTcam160Key_t,
    DsLpmTcam80Key_t,
    DsFibUserId160Key_t,
    DsFibUserId80Key_t,
};

enum tcam_share_mem_id_e
{
    /*Tcam key*/
#if TCAM_EMULATION_MODE
    USER_ID_6W_SHARE_TABLE,
    TUNNEL_ID_6W_SHARE_TABLE,
    OAM_TCAM_KEY_SHARE_TABLE,
#endif
    IPV4_ACL_KEY0_SHARE_TABLE,
    IPV4_ACL_KEY1_SHARE_TABLE,
    IPV4_ACL_KEY2_SHARE_TABLE,
    IPV4_ACL_KEY3_SHARE_TABLE,
    IPV4_KEY_SHARE_TABLE,
    IPV6_KEY_SHARE_TABLE,
    MAC_KEY_SHARE_TABLE,
    FCOE_KEY_SHARE_TABLE,

    /*LPM internal Tcam*/
    LPM_TCAM_KEY_SHARE_TABLE,

    MAX_TCAM_SHARE_MEM_ID
};
typedef enum tcam_share_mem_id_e tcam_share_mem_id_t;


share_mem_info_t tcam_share_mem_info[] =
{
#if TCAM_EMULATION_MODE
    {sizeof(user_id_6w_share_table_list)/sizeof(uint32), user_id_6w_share_table_list, 0},
    {sizeof(tunnel_id_6w_share_table_list)/sizeof(uint32), tunnel_id_6w_share_table_list, 0},
    {sizeof(oam_tcam_key_share_table_list)/sizeof(uint32), oam_tcam_key_share_table_list, 0},
#endif
    {sizeof(acl_key0_share_table_list)/sizeof(uint32), acl_key0_share_table_list, 0},
    {sizeof(acl_key1_share_table_list)/sizeof(uint32), acl_key1_share_table_list, 0},
    {sizeof(acl_key2_share_table_list)/sizeof(uint32), acl_key2_share_table_list, 0},
    {sizeof(acl_key3_share_table_list)/sizeof(uint32), acl_key3_share_table_list, 0},
    {sizeof(ipv4_key_share_table_list)/sizeof(uint32), ipv4_key_share_table_list, 0},
    {sizeof(ipv6_key_share_table_list)/sizeof(uint32), ipv6_key_share_table_list, 0},
    {sizeof(mac_key_share_table_list)/sizeof(uint32), mac_key_share_table_list, 0},
    {sizeof(fcoe_key_share_table_list)/sizeof(uint32), fcoe_key_share_table_list, 0},

    /* LPM&FIB UserId internal resolve conflict Tcam */
    {sizeof(lpm_tcam_key_share_table_list)/sizeof(uint32), lpm_tcam_key_share_table_list, 0},
};
#endif

static uint32 acl_key0_share_table_list[] =
{
    DsAclIpv4Key0_t,
    DsAclMplsKey0_t,
#if TCAM_EMULATION_MODE/*key size 6 words*/
    DsAclMacKey0_t,

#endif
};

static uint32 acl_key1_share_table_list[] =
{
    DsAclIpv4Key1_t,
    DsAclMplsKey1_t,
#if TCAM_EMULATION_MODE/*key size 6 words*/
    DsAclMacKey1_t,
#endif
};

static uint32 acl_key2_share_table_list[] =
{
    DsAclIpv4Key2_t,
    DsAclMplsKey2_t,
#if TCAM_EMULATION_MODE/*key size 6 words*/
    DsAclMacKey2_t,
#endif
};

static uint32 acl_key3_share_table_list[] =
{
    DsAclIpv4Key3_t,
    DsAclMplsKey3_t,
#if TCAM_EMULATION_MODE/*key size 6 words*/
    DsAclMacKey3_t,
#endif
};

static uint32 block_0_tcam_key_share_table_list[] =
{
    DsUserIdIpv4Key_t,
    DsUserIdIpv6Key_t,
    DsUserIdMacKey_t,
    DsUserIdVlanKey_t,
    DsTunnelIdIpv4Key_t,
    DsTunnelIdIpv6Key_t,
    DsTunnelIdCapwapKey_t,
    DsTunnelIdPbbKey_t,
    DsTunnelIdTrillKey_t,
};


static uint32 block_1_tcam_key_share_table_list[] =
{
#if V5_20_NOTE
    DsEthOamKey_t,
    DsBfdOamKey_t,
    DsMplsOamLabelKey_t,
    DsPbtOamKey_t,
    DsEthOamRmepKey_t,
#endif
    DsMacBridgeKey_t,
    DsFcoeRouteKey_t,
    DsFcoeRpfKey_t,
    DsTrillUcastRouteKey_t,
    DsTrillMcastRouteKey_t,
};

static uint32 block_2_tcam_key_share_table_list[] =
{
    DsIpv4UcastRouteKey_t,
    DsIpv4RpfKey_t,
    DsIpv4McastRouteKey_t,
    DsIpv4NatKey_t,
    DsIpv4PbrKey_t,
    DsMacIpv4Key_t,
};

static uint32 block_3_tcam_key_share_table_list[] =
{
    DsIpv6UcastRouteKey_t,
    DsIpv6RpfKey_t,
    DsIpv6McastRouteKey_t,
    DsIpv6NatKey_t,
    DsIpv6PbrKey_t,
    DsMacIpv6Key_t,
};

static uint32 lpm_tcam_key_share_table_list[] =
{
    DsLpmTcam160Key_t,
    DsLpmTcam80Key_t,
    DsFibUserId160Key_t,
    DsFibUserId80Key_t,
};

enum tcam_share_mem_id_e
{
    /*Tcam key*/
    ACL_KEY0_SHARE_TABLE,
    ACL_KEY1_SHARE_TABLE,
    ACL_KEY2_SHARE_TABLE,
    ACL_KEY3_SHARE_TABLE,
    BLOCK_0_TCAM_KEY_SHARE_TABLE,
    BLOCK_1_TCAM_KEY_SHARE_TABLE,
    BLOCK_2_TCAM_KEY_SHARE_TABLE,
    BLOCK_3_TCAM_KEY_SHARE_TABLE,

    /*LPM internal Tcam*/
    LPM_TCAM_KEY_SHARE_TABLE,

    MAX_TCAM_SHARE_MEM_ID,
};
typedef enum tcam_share_mem_id_e tcam_share_mem_id_t;


share_mem_info_t tcam_share_mem_info[] =
{
    {sizeof(acl_key0_share_table_list)/sizeof(uint32), acl_key0_share_table_list, 0},
    {sizeof(acl_key1_share_table_list)/sizeof(uint32), acl_key1_share_table_list, 0},
    {sizeof(acl_key2_share_table_list)/sizeof(uint32), acl_key2_share_table_list, 0},
    {sizeof(acl_key3_share_table_list)/sizeof(uint32), acl_key3_share_table_list, 0},
    {sizeof(block_0_tcam_key_share_table_list)/sizeof(uint32), block_0_tcam_key_share_table_list, 0},
    {sizeof(block_1_tcam_key_share_table_list)/sizeof(uint32), block_1_tcam_key_share_table_list, 0},
    {sizeof(block_2_tcam_key_share_table_list)/sizeof(uint32), block_2_tcam_key_share_table_list, 0},
    {sizeof(block_3_tcam_key_share_table_list)/sizeof(uint32), block_3_tcam_key_share_table_list, 0},

    /* LPM&FIB UserId internal resolve conflict Tcam */
    {sizeof(lpm_tcam_key_share_table_list)/sizeof(uint32), lpm_tcam_key_share_table_list, 0},
};

static uint32 lpm_tcam_ad_share_table_list[] =
{
    LpmTcamAdMem_t,
    DsUserIdConflictTcam_t,
    DsTunnelIdConflictTcam_t,
    DsVlanXlateConflictTcam_t,
};

enum lpm_tcam_ad_share_mem_id_e
{
    /*LPM internal Tcam ad*/
    LPM_TCAM_AD_SHARE_TABLE,

    MAX_LPM_TCAM_SHARE_AD_MEM_ID
};
typedef enum lpm_tcam_ad_share_mem_id_e lpm_tcam_ad_share_mem_id_t;

share_mem_info_t lpm_tcam_share_ad_mem_info[] =
{
    /* LPM&FIB UserId internal resolve conflict Tcam ad*/
    {sizeof(lpm_tcam_ad_share_table_list)/sizeof(uint32), lpm_tcam_ad_share_table_list, 0},
};

/* ------------------- share list info need to used by outer code start ------------------- */
uint32 cm_mem_tcam_ad_list[] =   /* all tcam ad */
{
    DsIpv6Acl0Tcam_t,
    DsIpv6Acl1Tcam_t,
    DsIpv4Acl0Tcam_t,
    DsIpv4Acl1Tcam_t,
    DsIpv4Acl2Tcam_t,
    DsIpv4Acl3Tcam_t,
    DsMacAcl0Tcam_t,
    DsMacAcl1Tcam_t,
    DsMacAcl2Tcam_t,
    DsMacAcl3Tcam_t,
    DsIpv4UcastDaTcam_t,
    DsIpv4McastDaTcam_t,
    DsIpv6UcastDaTcam_t,
    DsIpv6McastDaTcam_t,
    DsIpv4SaNatTcam_t,
    DsIpv6SaNatTcam_t,
    DsIpv4UcastPbrDualDaTcam_t,
    DsIpv6UcastPbrDualDaTcam_t,
    DsMacTcam_t,
    DsFcoeDaTcam_t,
    DsFcoeSaTcam_t,
    /* DsTrillDaTcam_t,*/
    DsTrillDaUcastTcam_t,
    DsTrillDaMcastTcam_t,
    DsUserIdMacTcam_t,
    DsUserIdIpv6Tcam_t,
    DsUserIdIpv4Tcam_t,
    DsUserIdVlanTcam_t,
    DsTunnelIdIpv6Tcam_t,
    DsTunnelIdIpv4Tcam_t,
    DsTunnelIdPbbTcam_t,
    DsTunnelIdCapwapTcam_t,
    DsTunnelIdTrillTcam_t,

    DsEthOamTcamChan_t,
    DsBfdOamChanTcam_t,
    DsMplsOamChanTcam_t,
    DsPbtOamChanTcam_t,
    DsEthRmepChan_t,

    /* DsMacIpv4Tcam and DsMacIpv6Tcam */
    DsMacIpv4Tcam_t,
    DsMacIpv6Tcam_t,
};

uint32 cm_mem_tcam_key_list[] =
{
    DsAclIpv6Key0_t,
    DsAclIpv6Key1_t,
    DsAclIpv4Key0_t,
    DsAclIpv4Key1_t,
    DsAclIpv4Key2_t,
    DsAclIpv4Key3_t,
    DsAclMacKey0_t,
    DsAclMacKey1_t,
    DsAclMacKey2_t,
    DsAclMacKey3_t,
    DsAclMplsKey0_t,
    DsAclMplsKey1_t,
    DsAclMplsKey2_t,
    DsAclMplsKey3_t,
    DsIpv4UcastRouteKey_t,
    DsIpv4McastRouteKey_t,
    DsIpv6McastRouteKey_t,
    DsIpv6UcastRouteKey_t,
    DsMacLearningKey_t,
    DsMacBridgeKey_t,
    DsIpv4NatKey_t,
    DsIpv6NatKey_t,
    DsIpv4PbrKey_t,
    DsIpv6PbrKey_t,
    DsIpv4RpfKey_t,
    DsIpv6RpfKey_t,
    DsFcoeRouteKey_t,
    DsFcoeRpfKey_t,
    DsTrillUcastRouteKey_t,
    DsTrillMcastRouteKey_t,
    /*DsTrillRouteKey_t,*/
    DsUserIdMacKey_t,
    DsUserIdIpv6Key_t,
    DsUserIdIpv4Key_t,
    DsUserIdVlanKey_t,
    DsTunnelIdIpv6Key_t,
    DsTunnelIdIpv4Key_t,
    DsTunnelIdPbbKey_t,
    DsTunnelIdCapwapKey_t,
    DsTunnelIdTrillKey_t,

    /* LPM and Fib userId resolve conflict Tcam Key*/
    DsLpmTcam160Key_t,
    DsLpmTcam80Key_t,
    DsFibUserId80Key_t,
    DsFibUserId160Key_t,

    /* DsMacIpv4Key and DsMacIpv6Key */
    DsMacIpv4Key_t,
    DsMacIpv6Key_t,

};

enum tcam_key_id_e
{
    DsAclIpv6Key0_e,
    DsAclIpv6Key1_e,
    DsAclIpv4Key0_e,
    DsAclIpv4Key1_e,
    DsAclIpv4Key2_e,
    DsAclIpv4Key3_e,
    DsAclMacKey0_e,
    DsAclMacKey1_e,
    DsAclMacKey2_e,
    DsAclMacKey3_e,
    DsAclMplsKey0_e,
    DsAclMplsKey1_e,
    DsAclMplsKey2_e,
    DsAclMplsKey3_e,
    DsIpv4UcastRouteKey_e,
    DsIpv4McastRouteKey_e,
    DsIpv6McastRouteKey_e,
    DsIpv6UcastRouteKey_e,
    DsMacLearningKey_e,
    DsMacBridgeKey_e,
    DsIpv4NatKey_e,
    DsIpv6NatKey_e,
    DsIpv4PbrKey_e,
    DsIpv6PbrKey_e,
    DsIpv4RpfKey_e,
    DsIpv6RpfKey_e,
    DsFcoeRouteKey_e,
    DsFcoeRpfKey_e,
    DsTrillUcastRouteKey_e,
    DsTrillMcastRouteKey_e,
    /*DsTrillRouteKey_e,*/
    DsUserIdMacKey_e,
    DsUserIdIpv6Key_e,
    DsUserIdIpv4Key_e,
    DsUserIdVlanKey_e,
    DsTunnelIdIpv6Key_e,
    DsTunnelIdIpv4Key_e,
    DsTunnelIdPbbKey_e,
    DsTunnelIdCapwapKey_e,
    DsTunnelIdTrillKey_e,
    /*Oam Tcam Key*/
    DsEthOamKey_e,
    DsBfdOamKey_e,
    DsMplsOamLabelKey_e,
    DsPbtOamKey_e,
    DsEthOamRmepKey_e,

    /* LPM and Fib userId resolve conflict Tcam Key*/
    DsLpmTcam160Key_e,
    DsLpmTcam80Key_e,
    DsFibUserId80Key_e,
    DsFibUserId160Key_e,

    /* DsMacIpv4Key and DsMacIpv6Key */
    DsMacIpv4Key_e,
    DsMacIpv6Key_e,

    MAX_TCAM_KEY_ID,
};
typedef enum tcam_key_id_e tcam_key_id_t;

uint32 userid_dft_list[] =
{
    DsUserIdIngressDefault_t,
    DsUserIdEgressDefault_t,
    DsTunnelIdDefault_t,
};

mem_external_declare_tbl_list_t mem_extern_userid_dft_list =
{
    sizeof(userid_dft_list)/sizeof(userid_dft_list[0]),
    userid_dft_list,
};

mem_external_declare_tbl_list_t mem_extern_tcam_ad_list =
{
    sizeof(cm_mem_tcam_ad_list)/sizeof(cm_mem_tcam_ad_list[0]),
    cm_mem_tcam_ad_list,
};

mem_external_declare_tbl_list_t mem_extern_tcam_key_list =
{
    sizeof(cm_mem_tcam_key_list)/sizeof(cm_mem_tcam_key_list[0]),
    cm_mem_tcam_key_list,
};

mem_external_declare_tbl_list_t mem_extern_lpm_tcam_ad_list =
{
    sizeof(lpm_tcam_ad_share_table_list)/sizeof(lpm_tcam_ad_share_table_list[0]),
    lpm_tcam_ad_share_table_list,
};
/* ------------------- share list info need to used by outer code end ------------------- */

/* ------------------------- global variable used for RTL register initialize -------------------------*/
dynamic_ds_five_base_cam_t dynamic_ds_five_base_cam;

tbls_id_t ds_dynamic_all_cam_list[] =
{
        DynamicDsDsEditIndexCam_t,
        DynamicDsDsMacIpIndexCam_t,
        DynamicDsDsMetIndexCam_t,
        DynamicDsDsMplsIndexCam_t,
        DynamicDsDsNextHopIndexCam_t,
        DynamicDsDsStatsIndexCam_t,
        DynamicDsDsUserIdHashIndexCam_t,
        DynamicDsDsUserIdIndexCam_t,
        DynamicDsFwdIndexCam_t,
        DynamicDsLmStatsIndexCam_t,
        DynamicDsLpmIndexCam4_t,
        DynamicDsMacHashIndexCam_t,

        DynamicDsLpmIndexCam0_t,
        DynamicDsLpmIndexCam1_t,
        DynamicDsLpmIndexCam2_t,
        DynamicDsLpmIndexCam3_t,
        DynamicDsOamIndexCam_t,
};

/* the dynamic ds cam list except DynamicDsLpmCam[0~3]_t, DynamicDsOamIndexCam_t */
tbls_id_t ds_dynamic_cam_list[] =
{
        DynamicDsDsEditIndexCam_t,
        DynamicDsDsMacIpIndexCam_t,
        DynamicDsDsMetIndexCam_t,
        DynamicDsDsMplsIndexCam_t,
        DynamicDsDsNextHopIndexCam_t,
        DynamicDsDsStatsIndexCam_t,
        DynamicDsDsUserIdHashIndexCam_t,
        DynamicDsDsUserIdIndexCam_t,
        DynamicDsFwdIndexCam_t,
        DynamicDsLmStatsIndexCam_t,
        DynamicDsLpmIndexCam4_t,
        DynamicDsMacHashIndexCam_t,
};

/* table id list to set the cam info corresponding to ds_dynamic_cam_list */
tbls_id_t ds_dynamic_cam_table_list[] =
{
        DsL2EditEth4W_t,
        DsMac_t,
        DsMetEntry_t,
        DsMpls_t,
        DsNextHop4W_t,
        DsStats_t,
        DsUserIdDoubleVlanHashKey_t,
        DsUserId_t,
        DsFwd_t,
        DsOamLmStats_t,
        DsLpmIpv4Hash8Key_t,
        DsMacHashKey_t,
};

/* ------------------------- global variable used for RTL register initialize -------------------------*/

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/
int32 cm_sim_cfg_kit_add_fib_key(uint8 chip_id, fib_hash_type_t fib_hash_type, void* p_ds_key)
{
    hash_io_by_key_para_t hash_io_para;
    sal_memset(&hash_io_para, 0, sizeof(hash_io_by_key_para_t));

    hash_io_para.chip_id = chip_id;
    hash_io_para.hash_module = HASH_MODULE_FIB;
    hash_io_para.hash_type = fib_hash_type;
    hash_io_para.key = p_ds_key;

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_key_add_by_key);
    drv_io_api.drv_hash_key_add_by_key(&hash_io_para);

    return DRV_E_NONE;
}

int32 cm_sim_cfg_kit_delete_fib_key(uint8 chip_id, fib_hash_type_t fib_hash_type, void* p_ds_key)
{
    hash_io_by_key_para_t hash_io_para;
    sal_memset(&hash_io_para, 0, sizeof(hash_io_by_key_para_t));

    hash_io_para.chip_id = chip_id;
    hash_io_para.hash_module = HASH_MODULE_FIB;
    hash_io_para.hash_type = fib_hash_type;
    hash_io_para.key = p_ds_key;

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_key_del_by_key);
    drv_io_api.drv_hash_key_del_by_key(&hash_io_para);

    return DRV_E_NONE;
}

int32 cm_sim_cfg_kit_add_lpm_hash_key(uint8 chip_id, lpm_hash_type_t lpm_hash_type, void* p_ds_key)
{
    hash_io_by_key_para_t hash_io_para;
    sal_memset(&hash_io_para, 0, sizeof(hash_io_by_key_para_t));

    hash_io_para.chip_id = chip_id;
    hash_io_para.hash_module = HASH_MODULE_LPM;
    hash_io_para.hash_type = lpm_hash_type;
    hash_io_para.key = p_ds_key;

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_key_add_by_key);
    drv_io_api.drv_hash_key_add_by_key(&hash_io_para);

    return DRV_E_NONE;
}

int32 cm_sim_cfg_kit_delete_lpm_hash_key(uint8 chip_id, lpm_hash_type_t lpm_hash_type, void* p_ds_key)
{
    hash_io_by_key_para_t hash_io_para;
    sal_memset(&hash_io_para, 0, sizeof(hash_io_by_key_para_t));

    hash_io_para.chip_id = chip_id;
    hash_io_para.hash_module = HASH_MODULE_LPM;
    hash_io_para.hash_type = lpm_hash_type;
    hash_io_para.key = p_ds_key;

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_key_del_by_key);
    drv_io_api.drv_hash_key_del_by_key(&hash_io_para);

    return DRV_E_NONE;
}

int32 cm_sim_cfg_kit_delete_lpm_lookup_key(uint8 chip_id)
{
    #define ALLOC_LPM_KEY_MAX_INDEX (16*1024)

    ds_lpm_ipv4_hash16_key_t lpm_key;
    ds_lpm_lookup_key0_t lmp_lkp_key0;
    ds_lpm_lookup_key1_t lmp_lkp_key1;
    lpm_ipv6_hash32_high_key_cam_t lpm_ipv6_hash32_high_key_cam;

    uint32 cmd = 0, index = 0;
#if (SDK_WORK_PLATFORM == 1)
    uint8 chipid_base = 0;
#endif

    sal_memset(&lpm_key, 0, sizeof(lpm_key));
    sal_memset(&lmp_lkp_key0, 0, sizeof(lmp_lkp_key0));
    sal_memset(&lmp_lkp_key1, 0, sizeof(lmp_lkp_key1));
    sal_memset(&lpm_ipv6_hash32_high_key_cam, 0, sizeof(lpm_ipv6_hash32_high_key_cam_t));

    cmd = DRV_IOW(DsLpmIpv4Hash16Key_t, DRV_ENTRY_FLAG);
    for (index = 0; index < ALLOC_LPM_KEY_MAX_INDEX; index++)
    {
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, index, cmd, &lpm_key));
#if (SDK_WORK_PLATFORM == 1)
        DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chipid_base));
        drv_model_sram_tbl_clear_wbit(chip_id-chipid_base, DsLpmIpv4Hash16Key_t, index);
#endif
    }

    cmd = DRV_IOW(DsLpmLookupKey0_t, DRV_ENTRY_FLAG);
    for (index = 0; index < TABLE_MAX_INDEX(DsLpmLookupKey0_t); index++)
    {
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, index, cmd, &lmp_lkp_key0));
#if (SDK_WORK_PLATFORM == 1)
        DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chipid_base));
        drv_model_sram_tbl_clear_wbit(chip_id-chipid_base, DsLpmLookupKey0_t, index);
#endif
    }

    cmd = DRV_IOW(DsLpmLookupKey1_t, DRV_ENTRY_FLAG);
    for (index = 0; index < TABLE_MAX_INDEX(DsLpmLookupKey1_t); index++)
    {
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, index, cmd, &lmp_lkp_key1));
#if (SDK_WORK_PLATFORM == 1)
        DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chipid_base));
        drv_model_sram_tbl_clear_wbit(chip_id-chipid_base, DsLpmLookupKey1_t, index);
#endif
    }

    cmd = DRV_IOW(LpmIpv6Hash32HighKeyCam_t, DRV_ENTRY_FLAG);
    for (index = 0; index < TABLE_MAX_INDEX(LpmIpv6Hash32HighKeyCam_t); index++)
    {
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, index, cmd, &lpm_ipv6_hash32_high_key_cam));
#if (SDK_WORK_PLATFORM == 1)
        DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chipid_base));
        drv_model_sram_tbl_clear_wbit(chip_id-chipid_base, LpmIpv6Hash32HighKeyCam_t, index);
#endif
    }

    return DRV_E_NONE;
}

int32
cm_sim_cfg_kit_add_queue_key(uint8 chip_id, void* p_ds_key)
{
    hash_io_by_key_para_t hash_io_para;
    sal_memset(&hash_io_para, 0, sizeof(hash_io_by_key_para_t));

    hash_io_para.chip_id = chip_id;
    hash_io_para.hash_module = HASH_MODULE_QUEUE;
    hash_io_para.key = p_ds_key;

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_key_add_by_key);
    drv_io_api.drv_hash_key_add_by_key(&hash_io_para);

    return DRV_E_NONE;
}

int32
cm_sim_cfg_kit_del_queue_key(uint8 chip_id, void *p_ds_key)
{
    hash_io_by_key_para_t hash_io_para;
    sal_memset(&hash_io_para, 0, sizeof(hash_io_by_key_para_t));

    hash_io_para.chip_id = chip_id;
    hash_io_para.hash_module = HASH_MODULE_QUEUE;
    hash_io_para.key = p_ds_key;

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_key_del_by_key);
    drv_io_api.drv_hash_key_del_by_key(&hash_io_para);

    return DRV_E_NONE;
}

int32 cm_sim_cfg_kit_add_userid_key(uint8 chip_id, userid_hash_type_t hash_type, void* p_ds_key)
{
    hash_io_by_key_para_t hash_io_para;
    sal_memset(&hash_io_para, 0, sizeof(hash_io_by_key_para_t));

    hash_io_para.chip_id = chip_id;
    hash_io_para.hash_module = HASH_MODULE_USERID;
    hash_io_para.hash_type = hash_type;
    hash_io_para.key = p_ds_key;

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_key_add_by_key);
    drv_io_api.drv_hash_key_add_by_key(&hash_io_para);

    return DRV_E_NONE;
}

int32 cm_sim_cfg_kit_delete_userid_key(uint8 chip_id, userid_hash_type_t hash_type, void* p_ds_key)
{
    hash_io_by_key_para_t hash_io_para;
    sal_memset(&hash_io_para, 0, sizeof(hash_io_by_key_para_t));

    hash_io_para.chip_id = chip_id;
    hash_io_para.hash_module = HASH_MODULE_USERID;
    hash_io_para.hash_type = hash_type;
    hash_io_para.key = p_ds_key;

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_key_del_by_key);
    drv_io_api.drv_hash_key_del_by_key(&hash_io_para);

    return DRV_E_NONE;
}

/* TcamKey table's extend info in driver(need) */
void
cm_sim_allocate_tcam_key_extend_info(void)
{
    tbls_id_t tbl_id = 0;
    uint32 index = 0, key_num = 0;
    tbls_ext_info_t* ptr_mem_ext = NULL;
    tcam_mem_ext_content_t* ptr_tcam_ext_content = NULL;
    uint8 block_cnt = 0;
    uint32 entry_per_s_block = 0;

    key_num = mem_extern_tcam_key_list.tbl_num;
    tbl_id = mem_extern_tcam_key_list.tbl_list[index];
    while(index != key_num)
    {
        /* malloc memory to store the Tcam key extend info */
        ptr_mem_ext = (tbls_ext_info_t *)sal_malloc(sizeof(tbls_ext_info_t));
        ptr_tcam_ext_content = (tcam_mem_ext_content_t *)sal_malloc(sizeof(tcam_mem_ext_content_t));

        if ((ptr_mem_ext == NULL) || (ptr_tcam_ext_content == NULL))
        {
            CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Not enough memory for malloc tcam ext info for key_id %d  %s: %d\n",
              tbl_id, __FUNCTION__, __LINE__);
            exit(1);
        }
        sal_memset(ptr_mem_ext, 0, sizeof(tbls_ext_info_t));
        sal_memset(ptr_tcam_ext_content, 0, sizeof(tcam_mem_ext_content_t));

        ptr_mem_ext->ext_content_type = EXT_INFO_TYPE_TCAM;
        ptr_mem_ext->ptr_ext_content = (void *)ptr_tcam_ext_content;
        TABLE_INFO_PTR(tbl_id)->ptr_ext_info = ptr_mem_ext;
        ptr_mem_ext = NULL;
        ptr_tcam_ext_content = NULL;
        index++;
        tbl_id = mem_extern_tcam_key_list.tbl_list[index];
    }

    /*init tcam super block info*/
    sal_memset(&tcam_block_info, 0, sizeof(cm_tcam_block_info_t));
    tcam_block_info.allocated_entry_num = 0;
    tcam_block_info.max_mem_entry_num = DRV_MAX_TCAM_BLOCK_NUM*DRV_ENTRYS_PER_TCAM_BLOCK;
    tcam_block_info.hw_data_base_addr = DRV_INT_TCAM_KEY_DATA_ASIC_BASE;
    entry_per_s_block = (tcam_block_info.max_mem_entry_num/TCAM_SUPER_BLOCK_NUM);

    for (block_cnt = 0; block_cnt < TCAM_SUPER_BLOCK_NUM; block_cnt++)
    {
        tcam_block_info.tcam_super_block[block_cnt].allocated_entry_num = 0;
        tcam_block_info.tcam_super_block[block_cnt].idx_base = block_cnt*entry_per_s_block;
    }

    /*init tcam ad info*/
    sal_memset (&tcam_ad_info, 0, sizeof(cm_tcam_ad_info_t));
    tcam_ad_info.allocated_entry_num    = 0;
    tcam_ad_info.max_mem_entry_num      = DRV_INT_TCAM_AD_MAX_ENTRY_NUM;
    tcam_ad_info.hw_data_base_addr      = DRV_INT_TCAM_AD_MEM_4W_BASE;
    tcam_ad_info.hw_data_base_addr_8w   = DRV_INT_TCAM_AD_MEM_8W_BASE;
    entry_per_s_block = (tcam_ad_info.max_mem_entry_num/TCAM_AD_BLOCK_NUM);

    for (block_cnt = 0; block_cnt < TCAM_AD_BLOCK_NUM; block_cnt++)
    {
        tcam_ad_info.tcam_ad_block[block_cnt].allocated_entry_num = 0;
        tcam_ad_info.tcam_ad_block[block_cnt].idx_base = block_cnt*entry_per_s_block;
    }

}

static int8 _acl_key_type(tbls_id_t tbl_id)
{
    uint8 acl_type = -1;
    switch(tbl_id)
    {
        case DsAclIpv4Key0_t:
        case DsAclMplsKey0_t:
        case DsAclMacKey0_t:

        case DsMacAcl0Tcam_t:
        case DsIpv4Acl0Tcam_t:
        case DsIpv6Acl0Tcam_t:
            acl_type = 0;
            break;
        case DsAclIpv4Key1_t:
        case DsAclMplsKey1_t:
        case DsAclMacKey1_t:

        case DsMacAcl1Tcam_t:
        case DsIpv4Acl1Tcam_t:
        case DsIpv6Acl1Tcam_t:
            acl_type = 1;
            break;
        case DsAclIpv4Key2_t:
        case DsAclMplsKey2_t:
        case DsAclMacKey2_t:

        case DsMacAcl2Tcam_t:
        case DsIpv4Acl2Tcam_t:
            acl_type = 2;
            break;
        case DsAclIpv4Key3_t:
        case DsAclMplsKey3_t:
        case DsAclMacKey3_t:

        case DsMacAcl3Tcam_t:
        case DsIpv4Acl3Tcam_t:
            acl_type = 3;
            break;
        case DsAclIpv6Key0_t:
            acl_type = 4;
            break;
        case DsAclIpv6Key1_t:
            acl_type = 5;
            break;
        default:
            acl_type = -1;
            break;

    }
    return acl_type;
}

/*
*/
int32 cm_sim_cfg_kit_allocate_tcam_key_process(cm_table_allocation_info_t *table_alloc_info)
{
    cm_tcam_block_info_t *p_tcam_info = NULL;

    int8 acl_type = -1;
    uint32 tcam_entry_num = 0;
    uint8 allocation_share = FALSE;
    uint32 share_tbl_num = 0;
    uint32 table_list_index = 0;
    uint32* share_table_list_ptr = NULL;
    uint32 table_id_index = 0;
    uint32 table_share_ids = 0;
    uint32 total_idx_base = 0;

    uint8 block_idx         = 0;
    uint32 req_entry_num    = 0;
    uint8 first_block       = TRUE;
    uint32 entry_per_blocak = 0;

    p_tcam_info = &tcam_block_info;

    tcam_entry_num = table_alloc_info->key_size*table_alloc_info->index_num/DRV_WORDS_PER_ENTRY;

    TCAM_KEY_SIZE(table_alloc_info->table_id) = DRV_BYTES_PER_WORD*(table_alloc_info->key_size);/* table key size are in bytes */

    if (table_alloc_info->table_id == DsIpv4UcastRouteKey_t)
    {
        TCAM_KEY_SIZE(DsIpv4RpfKey_t) = TCAM_KEY_SIZE(DsIpv4UcastRouteKey_t);
    }
    else if (table_alloc_info->table_id == DsIpv6UcastRouteKey_t)
    {
        TCAM_KEY_SIZE(DsIpv6RpfKey_t) = TCAM_KEY_SIZE(DsIpv6UcastRouteKey_t);
    }
    else if (table_alloc_info->table_id == DsFcoeRouteKey_t)
    {
        TCAM_KEY_SIZE(DsFcoeRpfKey_t) = TCAM_KEY_SIZE(DsFcoeRouteKey_t);
    }


    if(TABLE_MAX_INDEX(table_alloc_info->table_id) == 0)
    {

        /* check if this table is one of the share key */
        allocation_share = FALSE;/* indicates if found share table id */
        share_tbl_num = 0;  /* indicates if the found share table need allocation */
        for(table_list_index=0; table_list_index<=BLOCK_3_TCAM_KEY_SHARE_TABLE; table_list_index++)
        {
            share_table_list_ptr = tcam_share_mem_info[table_list_index].p_share_mem_table_list;
            for(table_id_index=0; table_id_index<tcam_share_mem_info[table_list_index].table_num; table_id_index++)
            {
                if(table_alloc_info->table_id == share_table_list_ptr[table_id_index])/* found share table */
                {
                    allocation_share = TRUE;
                    if(!tcam_share_mem_info[table_list_index].is_allocated)/* need allocation */
                    {
                        share_tbl_num = tcam_share_mem_info[table_list_index].table_num;
                        tcam_share_mem_info[table_list_index].is_allocated = TRUE;
                    }
                    break;
                }
            }

            if(allocation_share)
            {
                break;
            }
        }

        if((p_tcam_info->allocated_entry_num + tcam_entry_num) > p_tcam_info->max_mem_entry_num)
        {
            CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Not enough entry in tcam key for key_id %d in line %d\n",
              table_alloc_info->table_id, __LINE__);
            return DRV_E_EXCEED_MAX_SIZE;
        }
        TABLE_MAX_INDEX(table_alloc_info->table_id)= table_alloc_info->index_num;

        acl_type =  _acl_key_type(table_alloc_info->table_id);

        /*allocation acl first*/
        if(-1 != acl_type)
        {
            if(acl_type < 4)
            {
                if(12 == table_alloc_info->key_size)
                {/*check 320bit*/
                    if(!IS_BIT_SET(p_tcam_info->acl_320_bit_map, acl_type))
                    {
                        SET_BIT(p_tcam_info->acl_320_bit_map, acl_type);

                        total_idx_base = (p_tcam_info->tcam_super_block[acl_type].idx_base + p_tcam_info->tcam_super_block[acl_type].allocated_entry_num);
                        TABLE_DATA_BASE(table_alloc_info->table_id) = p_tcam_info->hw_data_base_addr +
                                                                        total_idx_base *DRV_BYTES_PER_ENTRY;
                        TCAM_MASK_BASE(table_alloc_info->table_id) = DRV_INT_TCAM_KEY_MASK_ASIC_BASE +
                                                                        total_idx_base*DRV_BYTES_PER_ENTRY;

                        p_tcam_info->tcam_super_block[acl_type].allocated_entry_num += tcam_entry_num;
                    }
                    else
                    {
                        sal_printf("acl 320 bit key allocation error block %d,tbl_id %d",acl_type, table_alloc_info->table_id);
                        return DRV_E_TCAM_KEY_CONFIG_ERROR;
                    }

                }
                else if(6 == table_alloc_info->key_size)
                {/*check 160bit*/
                    if(!IS_BIT_SET(p_tcam_info->acl_160_bit_map, acl_type))
                    {
                        SET_BIT(p_tcam_info->acl_160_bit_map, acl_type);

                        total_idx_base = (p_tcam_info->tcam_super_block[acl_type].idx_base + p_tcam_info->tcam_super_block[acl_type].allocated_entry_num);
                        TABLE_DATA_BASE(table_alloc_info->table_id) = p_tcam_info->hw_data_base_addr +
                                                                        total_idx_base *DRV_BYTES_PER_ENTRY;
                        TCAM_MASK_BASE(table_alloc_info->table_id) = DRV_INT_TCAM_KEY_MASK_ASIC_BASE +
                                                                        total_idx_base*DRV_BYTES_PER_ENTRY;

                        p_tcam_info->tcam_super_block[acl_type].allocated_entry_num += tcam_entry_num;
                    }
                    else
                    {
                        sal_printf("acl 160 bit key allocation error block %d,tbl_id %d",acl_type, table_alloc_info->table_id);
                        return DRV_E_TCAM_KEY_CONFIG_ERROR;
                    }
                }
            }
            else
            {
                if(!IS_BIT_SET(p_tcam_info->acl_640_bit_map, (acl_type-4)))
                {
                    SET_BIT(p_tcam_info->acl_640_bit_map, (acl_type-4));
                    total_idx_base = (p_tcam_info->tcam_super_block[(acl_type-4)*2].idx_base + p_tcam_info->tcam_super_block[(acl_type-4)*2].allocated_entry_num);
                    TABLE_DATA_BASE(table_alloc_info->table_id) = p_tcam_info->hw_data_base_addr +
                                                                    total_idx_base *DRV_BYTES_PER_ENTRY;
                    TCAM_MASK_BASE(table_alloc_info->table_id) = DRV_INT_TCAM_KEY_MASK_ASIC_BASE +
                                                                    total_idx_base*DRV_BYTES_PER_ENTRY;
                    TABLE_MAX_INDEX(table_alloc_info->table_id)= table_alloc_info->index_num;
                    return DRV_E_NONE;
                }
                else
                {
                    sal_printf("acl 640 bit key allocation error block %d,tbl_id %d",(acl_type-4), table_alloc_info->table_id);
                    return DRV_E_TCAM_KEY_CONFIG_ERROR;
                }
            }
        }
        else
        {

    #if TCAM_EMULATION_MODE
            #define EMU_ENTRYS_PER_TCAM_BLOCK 32
            entry_per_blocak = EMU_ENTRYS_PER_TCAM_BLOCK;
    #else
            entry_per_blocak = DRV_ENTRYS_PER_TCAM_BLOCK;
    #endif
            req_entry_num   = tcam_entry_num;
            first_block     = TRUE;

            if((p_tcam_info->allocated_entry_num + tcam_entry_num) > (entry_per_blocak*DRV_MAX_TCAM_BLOCK_NUM))
            {
                CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Not enough block for key_id %d in line %d\n",
                  table_alloc_info->table_id, __LINE__);
                return DRV_E_EXCEED_MAX_SIZE;
            }

            for(block_idx = 0; block_idx < TCAM_SUPER_BLOCK_NUM; block_idx++)
            {
                if(TCAM_BLOCK_PER_SUPRE_BLOCK*entry_per_blocak == p_tcam_info->tcam_super_block[block_idx].allocated_entry_num)
                {
                    continue;
                }

                if(first_block)
                {
                    total_idx_base = (p_tcam_info->tcam_super_block[block_idx].idx_base + p_tcam_info->tcam_super_block[block_idx].allocated_entry_num);
                    TABLE_DATA_BASE(table_alloc_info->table_id) = p_tcam_info->hw_data_base_addr +
                                                                    total_idx_base *DRV_BYTES_PER_ENTRY;
                    TCAM_MASK_BASE(table_alloc_info->table_id) = DRV_INT_TCAM_KEY_MASK_ASIC_BASE +
                                                                    total_idx_base*DRV_BYTES_PER_ENTRY;
                    first_block = FALSE;
                }

                if(p_tcam_info->tcam_super_block[block_idx].allocated_entry_num + req_entry_num <= TCAM_BLOCK_PER_SUPRE_BLOCK*entry_per_blocak)
                {
                    p_tcam_info->tcam_super_block[block_idx].allocated_entry_num += req_entry_num;
                    break;
                }
                else
                {
                    req_entry_num -= (TCAM_BLOCK_PER_SUPRE_BLOCK*entry_per_blocak - p_tcam_info->tcam_super_block[block_idx].allocated_entry_num);
                    p_tcam_info->tcam_super_block[block_idx].allocated_entry_num = TCAM_BLOCK_PER_SUPRE_BLOCK*entry_per_blocak;
                }
            }
        }

        TABLE_MAX_INDEX(table_alloc_info->table_id)= table_alloc_info->index_num;

        /* copy allocation to share key*/
        if(share_tbl_num != 0)
        {
            for (table_id_index=0; table_id_index<share_tbl_num; table_id_index++)
            {
                table_share_ids = share_table_list_ptr[table_id_index];
                if (table_share_ids != table_alloc_info->table_id)
                {
                    /*tbl_ptr->key_size = DRV_BYTES_PER_WORD*(table_alloc_info->key_size);*//* table key size are in bytes */
                    TABLE_MAX_INDEX(table_share_ids) = table_alloc_info->index_num;
                    TABLE_DATA_BASE(table_share_ids) = TABLE_DATA_BASE(table_alloc_info->table_id);
                    TCAM_MASK_BASE(table_share_ids) = TCAM_MASK_BASE(table_alloc_info->table_id);
                }
            }
        }

        p_tcam_info->allocated_entry_num += tcam_entry_num;


    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       cm_sim_cfg_kit_allocate_tcam_key_process
 * Purpose:    TCAM key allocation function
 * Parameters:
 * Input:      table_alloc_info  -- pointer to table information
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
 #if 0
int32 cm_sim_cfg_kit_allocate_tcam_key_process(cm_table_allocation_info_t *table_alloc_info)
{
    uint32 tcam_entry_num = 0;
    uint32 table_list_index = 0;
    uint32 table_id_index = 0;
    uint32 share_tbl_num = 0;
    uint32 table_share_ids = 0;
    uint32* share_table_list_ptr = NULL;
    uint8 allocation_share = 0;
    cm_mem_chip_allocation_info_t* p_mem_chip_info = NULL;


    /* calculate key size and check if the tcam key has enough space */
    /* 3 words(12bytes) per tcam entry,  table_alloc_info->key_size is in words */
    tcam_entry_num = table_alloc_info->key_size*table_alloc_info->index_num/DRV_WORDS_PER_ENTRY;
    p_mem_chip_info = &mem_chip_info[CM_TCAM_KEY];


    TCAM_KEY_SIZE(table_alloc_info->table_id) = DRV_BYTES_PER_WORD*(table_alloc_info->key_size);/* table key size are in bytes */
    if (table_alloc_info->table_id == DsIpv4UcastRouteKey_t)
    {
        TCAM_KEY_SIZE(DsIpv4RpfKey_t) = TCAM_KEY_SIZE(DsIpv4UcastRouteKey_t);
    }
    else if (table_alloc_info->table_id == DsIpv6UcastRouteKey_t)
    {
        TCAM_KEY_SIZE(DsIpv6RpfKey_t) = TCAM_KEY_SIZE(DsIpv6UcastRouteKey_t);
    }
    else if (table_alloc_info->table_id == DsFcoeRouteKey_t)
    {
        TCAM_KEY_SIZE(DsFcoeRpfKey_t) = TCAM_KEY_SIZE(DsFcoeRouteKey_t);
    }

    if(TABLE_MAX_INDEX(table_alloc_info->table_id) == 0)
    {
        /* check if this table is one of the share key */
        allocation_share = 0;/* indicates if found share table id */
        share_tbl_num = 0;  /* indicates if the found share table need allocation */
        for(table_list_index=0; table_list_index<=FCOE_KEY_SHARE_TABLE; table_list_index++)
        {
            share_table_list_ptr = tcam_share_mem_info[table_list_index].p_share_mem_table_list;
            for(table_id_index=0; table_id_index<tcam_share_mem_info[table_list_index].table_num; table_id_index++)
            {
                if(table_alloc_info->table_id == share_table_list_ptr[table_id_index])/* found share table */
                {
                    allocation_share = 1;
                    if(!tcam_share_mem_info[table_list_index].is_allocated)/* need allocation */
                    {
                        share_tbl_num = tcam_share_mem_info[table_list_index].table_num;
                        tcam_share_mem_info[table_list_index].is_allocated = TRUE;
                    }
                    break;
                }
            }

            if(allocation_share)
            {
                break;
            }
        }

        if((p_mem_chip_info->allocated_entry_num + tcam_entry_num) >p_mem_chip_info->max_mem_entry_num)
        {
            CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Not enough entry in tcam key for key_id %d in line %d\n",
              table_alloc_info->table_id, __LINE__);
            return DRV_E_EXCEED_MAX_SIZE;
        }

        /*tbl_ptr->key_size = DRV_BYTES_PER_WORD*(table_alloc_info->key_size);*//* table key size are in bytes */
        TABLE_MAX_INDEX(table_alloc_info->table_id)= table_alloc_info->index_num;
#if TCAM_EMULATION_MODE
        if(p_mem_chip_info->allocated_entry_num%DRV_ENTRYS_PER_TCAM_BLOCK)/*Not in the the beginning of block, use next block*/
        {
            p_mem_chip_info->allocated_entry_num +=
              (DRV_ENTRYS_PER_TCAM_BLOCK - (p_mem_chip_info->allocated_entry_num%DRV_ENTRYS_PER_TCAM_BLOCK));
        }

        if((p_mem_chip_info->allocated_entry_num/DRV_ENTRYS_PER_TCAM_BLOCK)>=DRV_MAX_TCAM_BLOCK_NUM)
        {
            CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Not enough block for key_id %d in line %d\n",
              table_alloc_info->table_id, __LINE__);
            return DRV_E_EXCEED_MAX_SIZE;
        }
#endif
        TABLE_DATA_BASE(table_alloc_info->table_id) = p_mem_chip_info->hardware_data_base_address +
                    p_mem_chip_info->allocated_entry_num*DRV_BYTES_PER_ENTRY;
        TCAM_MASK_BASE(table_alloc_info->table_id) = DRV_INT_TCAM_KEY_MASK_ASIC_BASE +
                    p_mem_chip_info->allocated_entry_num*DRV_BYTES_PER_ENTRY;

        /* copy allocation to share key*/
        if(share_tbl_num != 0)
        {
            for (table_id_index=0; table_id_index<share_tbl_num; table_id_index++)
            {
                table_share_ids = share_table_list_ptr[table_id_index];
                if (table_share_ids != table_alloc_info->table_id)
                {
                    /*tbl_ptr->key_size = DRV_BYTES_PER_WORD*(table_alloc_info->key_size);*//* table key size are in bytes */
                    TABLE_MAX_INDEX(table_share_ids) = table_alloc_info->index_num;
                    TABLE_DATA_BASE(table_share_ids) = p_mem_chip_info->hardware_data_base_address +
                                p_mem_chip_info->allocated_entry_num*DRV_BYTES_PER_ENTRY;
                    TCAM_MASK_BASE(table_share_ids) = DRV_INT_TCAM_KEY_MASK_ASIC_BASE +
                                p_mem_chip_info->allocated_entry_num*DRV_BYTES_PER_ENTRY;
                }
            }
        }

        p_mem_chip_info->allocated_entry_num += tcam_entry_num;
    }

    return DRV_E_NONE;
}
#endif

/****************************************************************************
 * Name:       cm_sim_cfg_kit_allocate_tcam_ad_process
 * Purpose:    TCAM ad allocation function
 * Parameters:
 * Input:      chip_id           -- chip id
 *             table_alloc_info  -- pointer to table information
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32 cm_sim_cfg_kit_allocate_tcam_ad_process(cm_table_allocation_info_t *table_alloc_info)
{
    uint32 ad_entry_num = 0;
    tbls_id_t tbl_id = table_alloc_info->table_id;
    cm_tcam_ad_info_t* p_mem_chip_info = NULL;
    uint32 hw_data_base = 0;
    int8 acl_type = -1;
    uint8 blk_cnt = 0;
    uint32 idx_offset = 0;

    p_mem_chip_info = &tcam_ad_info;

    if(TABLE_MAX_INDEX(tbl_id) == 0)
    {
        /* calculate key size and check if the tcam ad has enough space */
        /* 3 words per entry, at least 64 entries for one table */
        ad_entry_num = table_alloc_info->index_num; /* key size of AD is fixed to be 3 words */

        if (TABLE_ENTRY_SIZE(tbl_id) == (2 * DRV_BYTES_PER_ENTRY))  /* 8 word TcamAD table */
        {
            hw_data_base = p_mem_chip_info->hw_data_base_addr_8w;
        }
        else
        {
            hw_data_base = p_mem_chip_info->hw_data_base_addr;
        }

        if((p_mem_chip_info->allocated_entry_num + ad_entry_num) > p_mem_chip_info->max_mem_entry_num)
        {
            CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Not enough entry1 in tcam ad for table_id %d\n", table_alloc_info->table_id);
            return DRV_E_EXCEED_MAX_SIZE;
        }

        acl_type = _acl_key_type(table_alloc_info->table_id);
        if(-1 != acl_type)
        {
            if(p_mem_chip_info->tcam_ad_block[acl_type].allocated_entry_num + ad_entry_num > (DRV_INT_TCAM_AD_MAX_ENTRY_NUM/TCAM_AD_BLOCK_NUM))
            {
                CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Not enough entry1 in tcam ad %d for table_id %d\n", acl_type, table_alloc_info->table_id);
                return DRV_E_EXCEED_MAX_SIZE;
            }
            else
            {
                idx_offset = p_mem_chip_info->tcam_ad_block[acl_type].allocated_entry_num + p_mem_chip_info->tcam_ad_block[acl_type].idx_base;
                TABLE_DATA_BASE(tbl_id) = hw_data_base +idx_offset*DRV_ADDR_BYTES_PER_ENTRY;

                p_mem_chip_info->tcam_ad_block[acl_type].allocated_entry_num += ad_entry_num;
            }
        }
        else
        {
            for(blk_cnt = 0; blk_cnt < TCAM_AD_BLOCK_NUM; blk_cnt++)
            {
                if(p_mem_chip_info->tcam_ad_block[blk_cnt].allocated_entry_num + ad_entry_num > (DRV_INT_TCAM_AD_MAX_ENTRY_NUM/TCAM_AD_BLOCK_NUM))
                {
                    continue;
                }
                else
                {
                    idx_offset = p_mem_chip_info->tcam_ad_block[blk_cnt].allocated_entry_num + p_mem_chip_info->tcam_ad_block[blk_cnt].idx_base;
                    TABLE_DATA_BASE(tbl_id) = hw_data_base + idx_offset*DRV_ADDR_BYTES_PER_ENTRY;

                    p_mem_chip_info->tcam_ad_block[blk_cnt].allocated_entry_num += ad_entry_num;
                    break;
                }
            }

            if (TCAM_AD_BLOCK_NUM == blk_cnt)
            {
                CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Not enough entry2 in tcam ad for table_id %d\n", table_alloc_info->table_id);
                return DRV_E_EXCEED_MAX_SIZE;
            }

        }

        /* set AD table information */
        TABLE_MAX_INDEX(tbl_id)= table_alloc_info->index_num / ((TABLE_ENTRY_SIZE(tbl_id) / DRV_BYTES_PER_ENTRY));

        p_mem_chip_info->allocated_entry_num += ad_entry_num;
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       cm_sim_cfg_kit_get_addr_offset_for_index
 * Purpose:    get the memory size according block id
 * Parameters:
 * Input:      void
 * Output:     tbl_ext_info -- tbl ext info
 *             dynamic_mem_ext_content -- dynamic ext content
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static uint32 cm_sim_cfg_kit_get_addr_offset_for_index(uint32 mem_index)
{
    uint32 bitmap_index = 0;
    uint32 mem_size = 0;
    for(bitmap_index=0; bitmap_index<mem_index; bitmap_index++)
    {
        mem_size += mem_chip_info[bitmap_index].max_mem_entry_num;
    }

    return mem_size;
}



inline uint32
_cm_sim_cfg_kit_convert_tcam_key_size_cfg(tbls_id_t tcamkey)
{
    uint32 entry_num = 0;
    uint32 key_size_cfg = 0xF; /* invalid value */

    entry_num = TCAM_KEY_SIZE(tcamkey)/DRV_BYTES_PER_ENTRY;

    switch (entry_num)
    {
        case 1:
            key_size_cfg = 0;
            break;
        case 2:
            key_size_cfg = 1;
            break;
        case 4:
            key_size_cfg = 2;
            break;
        case 8:
            key_size_cfg = 3;
            break;
        default:
            break;
    }

    return key_size_cfg;
}

inline uint32
_cm_sim_cfg_kit_get_tcam_key_index_shift(tbls_id_t tcamkey)
{
    uint32 key_size = 0;

    key_size = TCAM_KEY_SIZE(tcamkey);
    if (!key_size)
    {
        CMODEL_DEBUG_OUT_INFO("Note: Tcam key tableId = %d keysize is zero!\n", tcamkey);
        return key_size;
    }
    key_size = key_size / DRV_BYTES_PER_ENTRY / 2;
    key_size = (key_size == 4)? 2 : (key_size & 0x3);

    return key_size;
}

inline uint32
_cm_sim_cfg_kit_get_tcam_key_index_base(tbls_id_t tcamkey)
{
    uint32 hw_data_base = 0, index_base = 0;

    hw_data_base = TABLE_DATA_BASE(tcamkey);
    index_base = (hw_data_base - DRV_INT_TCAM_KEY_DATA_ASIC_BASE)/ DRV_BYTES_PER_ENTRY;

    return (index_base>>6);
}

inline uint32
_cm_sim_cfg_kit_get_tcam_key_acl_bit_map(tbls_id_t tbl_id)
{
    uint32 hw_data_base = 0, index_base = 0;
    uint32 shift    = 0;

    hw_data_base = TABLE_DATA_BASE(tbl_id);
    index_base = (hw_data_base - DRV_INT_TCAM_KEY_DATA_ASIC_BASE)/ DRV_BYTES_PER_ENTRY;
    if((320 == (TCAM_KEY_SIZE(tbl_id)/DRV_BYTES_PER_ENTRY*80)) || (160 == (TCAM_KEY_SIZE(tbl_id)/DRV_BYTES_PER_ENTRY*80)))
    {
        if(index_base < 2*1024)
        {
            shift = 0;
        }
        else if(index_base < 4*1024)
        {
            shift = 1;
        }
        else if(index_base < 6*1024)
        {
            shift = 2;
        }
        else if(index_base < 8*1024)
        {
            shift = 3;
        }
    }
    else if (640 == (TCAM_KEY_SIZE(tbl_id)/DRV_BYTES_PER_ENTRY*80))
    {
        if(index_base < 2*1024)
        {
            shift = 0;
        }
        else if(index_base < 6*1024)
        {
            shift = 1;
        }
    }
    return (1<<shift);
}

static int32
_cm_sim_cfg_kit_get_entry_num_of_table(tbls_id_t tbl_id, uint32* total_entry_num)
{
    uint32 tbl_total_entry_num = 0;

    if (DYNAMIC_ACCESS_MODE(tbl_id) == DYNAMIC_DEFAULT)
    {
        tbl_total_entry_num = TABLE_MAX_INDEX(tbl_id)*TABLE_ENTRY_SIZE(tbl_id)/DRV_BYTES_PER_ENTRY;
    }
    else
    {
        tbl_total_entry_num = TABLE_MAX_INDEX(tbl_id);
    }

    *total_entry_num = tbl_total_entry_num;

    return DRV_E_NONE;
}

inline uint32
_cm_sim_cfg_kit_get_ad_table_base(tbls_id_t ad_table, uint8 is_tcam_ad)
{
    uint32 hw_data_base = 0, index_base = 0;

    hw_data_base = TABLE_DATA_BASE(ad_table);

    if (!TABLE_MAX_INDEX(ad_table))
    {
        return 0;
    }

    if (is_tcam_ad)
    {
        if (DRV_ADDR_IN_TCAMAD_SRAM_8W_RANGE(hw_data_base))
        {
            index_base = (hw_data_base - DRV_INT_TCAM_AD_MEM_8W_BASE)/DRV_ADDR_BYTES_PER_ENTRY;
        }
        else
        {
            index_base = (hw_data_base - DRV_INT_TCAM_AD_MEM_4W_BASE)/DRV_ADDR_BYTES_PER_ENTRY;
        }

    }
    else
    {
        if (DRV_ADDR_IN_DYNAMIC_SRAM_8W_RANGE(hw_data_base))
        {
            index_base = (hw_data_base - DRV_MEMORY0_BASE_8W)/DRV_ADDR_BYTES_PER_ENTRY;
        }
        else
        {
            index_base = (hw_data_base - DRV_MEMORY0_BASE_4W)/DRV_ADDR_BYTES_PER_ENTRY;
        }
    }

    if (index_base%64)
    {
        CMODEL_DEBUG_OUT_INFO("%% Attention!! TableId = %d, indexBase mod 64 is not integral!\n", ad_table);
    }

    return (index_base>>6);
}


inline uint32
_cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbls_id_t tbl_id, uint8 blk_id, uint8 shift_num )
{

    uint32 dynic_tbl_base = 0;
    uint32 hw_data_basic_base = 0;

    /* check the table is 80 or 160 addressing, record the memory0 base address */
    if (TABLE_ENTRY_SIZE(tbl_id) == DRV_BYTES_PER_ENTRY)
    {
        hw_data_basic_base = DRV_MEMORY0_BASE_4W;
    }
    else
    {
        hw_data_basic_base = DRV_MEMORY0_BASE_8W;
    }

    dynic_tbl_base = ((DYNAMIC_DATA_BASE(tbl_id, blk_id) - hw_data_basic_base)/DRV_ADDR_BYTES_PER_ENTRY);

    if (dynic_tbl_base%(1<<shift_num))
    {
        CMODEL_DEBUG_OUT_INFO("%% Attention!! TableId = %d, indexBase mod %d is not integral!\n", tbl_id, (1<<shift_num));
    }

    return (dynic_tbl_base>>shift_num);
}


static int32
_cm_sim_cfg_kit_init_tcam_userid_ctl_register(uint32 chip_id)
{
    #define GET_USERID_LKPCTL_CFG1(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id) (((tcam_key_size)<<5) | ((tcam_tbl_id)<<2) | (tcam_sub_tbl_id))
    #define GET_USERID_LKPCTL_CFG2(tcam_tbl_id, tcam_sub_tbl_id) (((tcam_tbl_id)<<2) | (tcam_sub_tbl_id))
    #define GET_TUNNELID_LKPCTL_CFG1(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id) (((tcam_key_size)<<6) | ((tcam_tbl_id)<<3) | (tcam_sub_tbl_id))
    #define GET_TUNNELID_LKPCTL_CFG2(tcam_tbl_id, tcam_sub_tbl_id) (((tcam_tbl_id)<<3) | (tcam_sub_tbl_id))

    uint32 cmd = 0;
    ipe_user_id_ctl_t ipe_userid_ctl;
    uint32 tcam_key_size = 0, tcam_tbl_id = 0, tcam_sub_tbl_id = 0;

    sal_memset(&ipe_userid_ctl, 0, sizeof(ipe_userid_ctl));

    /*********** UserID lookup ctl setting ***********/
    tcam_tbl_id = USERID_TABLEID;
    /* UserId Mac Tcam key lookup control */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsUserIdMacKey_t);
    tcam_sub_tbl_id = USERID_MAC_SUB_TABLEID;
    ipe_userid_ctl.lookup_ctl0 = GET_USERID_LKPCTL_CFG1(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* UserId IPv6 Tcam key lookup control */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsUserIdIpv6Key_t);
    tcam_sub_tbl_id = USERID_IPV6_SUB_TABLEID;
    ipe_userid_ctl.lookup_ctl1 = GET_USERID_LKPCTL_CFG1(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* UserId IPv4 Tcam key lookup control */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsUserIdIpv4Key_t);
    tcam_sub_tbl_id = USERID_IPV4_SUB_TABLEID;
    ipe_userid_ctl.lookup_ctl2 = GET_USERID_LKPCTL_CFG1(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* UserId VLAN Tcam key lookup control */
    /* Fixed keysize = 80bits */
    tcam_sub_tbl_id = USERID_VLAN_SUB_TABLEID;
    ipe_userid_ctl.lookup_ctl3 = GET_USERID_LKPCTL_CFG2(tcam_tbl_id, tcam_sub_tbl_id);

    /*********** TunnelID lookup ctl setting ***********/
    tcam_tbl_id = TUNNELID_TABLEID;
    /* TunnelId IPv6 Tcam key lookup control */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsTunnelIdIpv6Key_t);
    tcam_sub_tbl_id = TUNNELID_IPV6_SUB_TABLEID;
    ipe_userid_ctl.lookup_ctl4 = GET_TUNNELID_LKPCTL_CFG1(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* TunnelId IPv4 Tcam key lookup control */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsTunnelIdIpv4Key_t);
    tcam_sub_tbl_id = TUNNELID_IPV4_SUB_TABLEID;
    ipe_userid_ctl.lookup_ctl5 = GET_TUNNELID_LKPCTL_CFG1(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* TunnelId PBB Tcam key lookup control */
    /* Fixed keysize = 80bits */
    tcam_sub_tbl_id = TUNNELID_PBB_SUB_TABLEID;
    ipe_userid_ctl.lookup_ctl6 = GET_TUNNELID_LKPCTL_CFG2(tcam_tbl_id, tcam_sub_tbl_id);
    /* TunnelId CAPWAP Tcam key lookup control */
    /* Fixed keysize = 80bits */
    tcam_sub_tbl_id = TUNNELID_CAPWAP_SUB_TABLEID;
    ipe_userid_ctl.lookup_ctl7 = GET_TUNNELID_LKPCTL_CFG2(tcam_tbl_id, tcam_sub_tbl_id);
    /* TunnelId TRILL Tcam key lookup control */
    /* Fixed keysize = 80bits */
    tcam_sub_tbl_id = TUNNELID_TRILL_SUB_TABLEID;
    ipe_userid_ctl.lookup_ctl8 = GET_TUNNELID_LKPCTL_CFG2(tcam_tbl_id, tcam_sub_tbl_id);

    cmd = DRV_IOW(IpeUserIdCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_userid_ctl));

    return DRV_E_NONE;
}

static int32
_cm_sim_cfg_kit_init_tcam_lookup_ctl_register(uint32 chip_id)
{
    #define GET_ACL_LKPCTL_CFG(tcam_key_size, tcam_sub_tbl_id) (((tcam_key_size)<<2) | (tcam_sub_tbl_id))
    #define GET_IP_LKPCTL_CFG1(lookup_mode, tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id) (((lookup_mode)<<7)|((tcam_key_size)<<5) | ((tcam_tbl_id)<<2) | (tcam_sub_tbl_id))
    #define GET_IP_LKPCTL_CFG2(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id) (((tcam_key_size)<<5) | ((tcam_tbl_id)<<2) | (tcam_sub_tbl_id))
    #define GET_FCOE_TRILL_LKPCTL_CFG(lookup_mode, tcam_tbl_id, tcam_sub_tbl_id) (((lookup_mode)<<5)|((tcam_tbl_id)<<2) | (tcam_sub_tbl_id))
    uint32 cmd = 0;
    ipe_lookup_ctl_t ipe_lookup_ctl;
    epe_acl_qos_ctl_t epe_acl_ctl;
    uint32 tcam_key_size = 0, tcam_tbl_id = 0, tcam_sub_tbl_id = 0;
    uint8 ip_lookup_mode = 0, fcoe_lookup_mode = 0, trill_lookup_mode = 0;

    sal_memset(&epe_acl_ctl, 0, sizeof(epe_acl_ctl));
    sal_memset(&ipe_lookup_ctl, 0, sizeof(ipe_lookup_ctl));

    /*--------- ACL lookup ctl setting --------*/
    /* ACL IPv6 */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsAclIpv6Key0_t);
    tcam_sub_tbl_id = ACL_IPV6_SUB_TABLEID;
    ipe_lookup_ctl.acl_qos_lookup_ctl0 = GET_ACL_LKPCTL_CFG(tcam_key_size, tcam_sub_tbl_id);
    epe_acl_ctl.acl_qos_lookup_ctl0 = GET_ACL_LKPCTL_CFG(tcam_key_size, tcam_sub_tbl_id);
    /* ACL IPv4 */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsAclIpv4Key0_t);
    tcam_sub_tbl_id = ACL_IPV4_SUB_TABLEID;
    ipe_lookup_ctl.acl_qos_lookup_ctl1 = GET_ACL_LKPCTL_CFG(tcam_key_size, tcam_sub_tbl_id);
    epe_acl_ctl.acl_qos_lookup_ctl1 = GET_ACL_LKPCTL_CFG(tcam_key_size, tcam_sub_tbl_id);
    /* ACL MAC */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsAclMacKey0_t);
    tcam_sub_tbl_id = ACL_MAC_SUB_TABLEID;
    ipe_lookup_ctl.acl_qos_lookup_ctl2 = GET_ACL_LKPCTL_CFG(tcam_key_size, tcam_sub_tbl_id);
    epe_acl_ctl.acl_qos_lookup_ctl2 = GET_ACL_LKPCTL_CFG(tcam_key_size, tcam_sub_tbl_id);
    /* ACL MPLS */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsAclMplsKey0_t);
    tcam_sub_tbl_id = ACL_MPLS_SUB_TABLEID;
    ipe_lookup_ctl.acl_qos_lookup_ctl3 = GET_ACL_LKPCTL_CFG(tcam_key_size, tcam_sub_tbl_id);
    epe_acl_ctl.acl_qos_lookup_ctl3 = GET_ACL_LKPCTL_CFG(tcam_key_size, tcam_sub_tbl_id);

    /*--------- IPv4DA & MAC lookup ctl setting --------*/
    tcam_tbl_id = IPV4DA_MAC_TABLEID;
    /* IPv4UcastDa */
    ip_lookup_mode = IP_LKP_MODE_LPM;
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsIpv4UcastRouteKey_t);
    tcam_sub_tbl_id = IPV4DA_UCAST_SUB_TABLEID;
    ipe_lookup_ctl.ip_da_lookup_ctl0 = GET_IP_LKPCTL_CFG1(ip_lookup_mode, tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* IPv4McastDa */
    ip_lookup_mode = IP_LKP_MODE_LPM;
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsIpv4McastRouteKey_t);
    tcam_sub_tbl_id = IPV4DA_MCAST_SUB_TABLEID;
    ipe_lookup_ctl.ip_da_lookup_ctl1 = GET_IP_LKPCTL_CFG1(ip_lookup_mode, tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* MacDa */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsMacBridgeKey_t);
    tcam_sub_tbl_id = MAC_DA_SUB_TABLEID;
    ipe_lookup_ctl.mac_da_lookup_ctl = GET_IP_LKPCTL_CFG2(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* MacSa */
    tcam_sub_tbl_id = MAC_SA_SUB_TABLEID;
    ipe_lookup_ctl.mac_sa_lookup_ctl = GET_IP_LKPCTL_CFG2(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);

    /*--------- IPv6DA lookup ctl setting --------*/
    tcam_tbl_id = IPV6DA_TABLEID;
    /* IPv6UcastDa */
    ip_lookup_mode = IP_LKP_MODE_LPM;
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsIpv6UcastRouteKey_t);
    tcam_sub_tbl_id = IPV6DA_UCAST_SUB_TABLEID;
    ipe_lookup_ctl.ip_da_lookup_ctl2 = GET_IP_LKPCTL_CFG1(ip_lookup_mode, tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* IPv6McastDa */
    ip_lookup_mode = IP_LKP_MODE_LPM;
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsIpv6McastRouteKey_t);
    tcam_sub_tbl_id = IPV6DA_MCAST_SUB_TABLEID;
    ipe_lookup_ctl.ip_da_lookup_ctl3 = GET_IP_LKPCTL_CFG1(ip_lookup_mode, tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* DsMacIpv4Key */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsMacIpv4Key_t);
    tcam_sub_tbl_id = MAC_IPV4_SUB_TABLEID;
    ipe_lookup_ctl.mac_ipv4_lookup_ctl = GET_IP_LKPCTL_CFG2(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* DsMacIpv6Key */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsMacIpv6Key_t);
    tcam_sub_tbl_id = MAC_IPV6_SUB_TABLEID;
    ipe_lookup_ctl.mac_ipv6_lookup_ctl = GET_IP_LKPCTL_CFG2(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);


    /*--------- IPv4SA lookup ctl setting --------*/
    tcam_tbl_id = IPV4SA_TABLEID;
    /* IPv4Sa RPF */
    ip_lookup_mode = IP_LKP_MODE_LPM;
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsIpv4RpfKey_t);
    tcam_sub_tbl_id = IPV4SA_RPF_SUB_TABLEID;
    ipe_lookup_ctl.ip_sa_lookup_ctl0 = GET_IP_LKPCTL_CFG1(ip_lookup_mode, tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* IPv4Sa NAT */
    ip_lookup_mode = IP_LKP_MODE_LPM;
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsIpv4NatKey_t);
    tcam_sub_tbl_id = IPV4SA_NAT_SUB_TABLEID;
    ipe_lookup_ctl.ip_sa_lookup_ctl2 = GET_IP_LKPCTL_CFG1(ip_lookup_mode, tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* IPv4Sa PBR */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsIpv4PbrKey_t);
    tcam_sub_tbl_id = IPV4SA_PBR_SUB_TABLEID;
    ipe_lookup_ctl.ip_sa_lookup_ctl4 = GET_IP_LKPCTL_CFG2(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);

    /*--------- IPv6SA lookup ctl setting --------*/
    tcam_tbl_id = IPV6SA_TABLEID;
    /* IPv6Sa RPF*/
    ip_lookup_mode = IP_LKP_MODE_LPM;
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsIpv6RpfKey_t);
    tcam_sub_tbl_id = IPV6SA_RPF_SUB_TABLEID;
    ipe_lookup_ctl.ip_sa_lookup_ctl1 = GET_IP_LKPCTL_CFG1(ip_lookup_mode, tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* IPv6Sa NAT */
    ip_lookup_mode = IP_LKP_MODE_LPM;
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsIpv6NatKey_t);
    tcam_sub_tbl_id = IPV6SA_NAT_SUB_TABLEID;
    ipe_lookup_ctl.ip_sa_lookup_ctl3 = GET_IP_LKPCTL_CFG1(ip_lookup_mode, tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);
    /* IPv6Sa PBR */
    tcam_key_size = _cm_sim_cfg_kit_convert_tcam_key_size_cfg(DsIpv6PbrKey_t);
    tcam_sub_tbl_id = IPV6SA_PBR_SUB_TABLEID;
    ipe_lookup_ctl.ip_sa_lookup_ctl5 = GET_IP_LKPCTL_CFG2(tcam_key_size, tcam_tbl_id, tcam_sub_tbl_id);

    /*--------- TRILL/FCoE lookup ctl setting --------*/
    tcam_tbl_id = TRILL_FCOE_TABLEID;
    /* FCoE DA */
    /* Fixed keysize: 80 bits */
    fcoe_lookup_mode = FCOE_LKP_MODE_RESERVED;
    tcam_sub_tbl_id = FCOE_DA_SUB_TABLEID;
    ipe_lookup_ctl.fcoe_lookup_ctl0 = GET_FCOE_TRILL_LKPCTL_CFG(fcoe_lookup_mode, tcam_tbl_id, tcam_sub_tbl_id);
    /* FCoE SA */
    /* Fixed keysize: 80 bits */
    tcam_sub_tbl_id = FCOE_SA_SUB_TABLEID;
    ipe_lookup_ctl.fcoe_lookup_ctl1 = GET_FCOE_TRILL_LKPCTL_CFG(fcoe_lookup_mode, tcam_tbl_id, tcam_sub_tbl_id);
    /* Trill DA Uc */
    /* Fixed keysize: 80 bits */
    trill_lookup_mode = TRILL_LKP_MODE_RESERVED;
    tcam_sub_tbl_id = TRILL_DA_UC_SUB_TABLEID;
    ipe_lookup_ctl.trill_da_lookup_ctl0 = GET_FCOE_TRILL_LKPCTL_CFG(trill_lookup_mode, tcam_tbl_id, tcam_sub_tbl_id);
    /* Trill DA Mc */
    /* Fixed keysize: 80 bits */
    trill_lookup_mode = TRILL_LKP_MODE_RESERVED;
    tcam_sub_tbl_id = TRILL_DA_MC_SUB_TABLEID;
    ipe_lookup_ctl.trill_da_lookup_ctl1 = GET_FCOE_TRILL_LKPCTL_CFG(trill_lookup_mode, tcam_tbl_id, tcam_sub_tbl_id);


    cmd = DRV_IOW(IpeLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_lookup_ctl));

    cmd = DRV_IOW(EpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &epe_acl_ctl));

    return DRV_E_NONE;
}

static int32
_cm_sim_cfg_kit_init_tcam_ctl_register(uint32 chip_id)
{

    uint32 cmd      = 0;
    uint32 bitmap   = 0;
    tcam_ctl_int_key_size_cfg_t tcam_ctl_int_key_size_cfg;
    tcam_ctl_int_key_type_cfg_t tcam_ctl_int_key_type_cfg;
    sal_memset(&tcam_ctl_int_key_size_cfg, 0, sizeof(tcam_ctl_int_key_size_cfg_t));
    sal_memset(&tcam_ctl_int_key_type_cfg, 0, sizeof(tcam_ctl_int_key_type_cfg_t));

    /*acl 160 & 320 bit key*/
    bitmap = _cm_sim_cfg_kit_get_tcam_key_acl_bit_map(DsAclIpv4Key0_t);
    tcam_ctl_int_key_type_cfg.key320_acl0_en = bitmap;
    bitmap = _cm_sim_cfg_kit_get_tcam_key_acl_bit_map(DsAclIpv4Key1_t);
    tcam_ctl_int_key_type_cfg.key320_acl1_en = bitmap;
    bitmap = _cm_sim_cfg_kit_get_tcam_key_acl_bit_map(DsAclIpv4Key2_t);
    tcam_ctl_int_key_type_cfg.key320_acl2_en = bitmap;
    bitmap = _cm_sim_cfg_kit_get_tcam_key_acl_bit_map(DsAclIpv4Key3_t);
    tcam_ctl_int_key_type_cfg.key320_acl3_en = bitmap;

    /*acl 640 bit key*/
    bitmap = _cm_sim_cfg_kit_get_tcam_key_acl_bit_map(DsAclIpv6Key0_t);
    tcam_ctl_int_key_type_cfg.key640_acl0_en = bitmap;
    bitmap = _cm_sim_cfg_kit_get_tcam_key_acl_bit_map(DsAclIpv6Key1_t);
    tcam_ctl_int_key_type_cfg.key640_acl1_en = bitmap;
    cmd = DRV_IOW(TcamCtlIntKeyTypeCfg_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_ctl_int_key_type_cfg));


    tcam_ctl_int_key_size_cfg.key80_en  = 0xFFFF;
    tcam_ctl_int_key_size_cfg.key160_en = 0xFF;
    tcam_ctl_int_key_size_cfg.key320_en = 0xF;
    tcam_ctl_int_key_size_cfg.key640_en = 0x3;
    cmd = DRV_IOW(TcamCtlIntKeySizeCfg_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_ctl_int_key_size_cfg));

    return DRV_E_NONE;
}

static int32
_cm_sim_cfg_kit_init_tcam_lookupresult_ctl_register(uint32 chip_id)
{
    uint32 cmd = 0;
    tcam_engine_lookup_result_ctl0_t tcam_lkp_rst_ctl0; /* include ACL lookupResult */
    tcam_engine_lookup_result_ctl1_t tcam_lkp_rst_ctl1; /* include UserId & OAM lookupResult */
    tcam_engine_lookup_result_ctl2_t tcam_lkp_rst_ctl2; /* include IP & MAC lookupResult */
    tcam_engine_lookup_result_ctl3_t tcam_lkp_rst_ctl3; /* include FCoE & Trill lookupResult */

    sal_memset(&tcam_lkp_rst_ctl0, 0, sizeof(tcam_lkp_rst_ctl0));
    sal_memset(&tcam_lkp_rst_ctl1, 0, sizeof(tcam_lkp_rst_ctl1));
    sal_memset(&tcam_lkp_rst_ctl2, 0, sizeof(tcam_lkp_rst_ctl2));
    sal_memset(&tcam_lkp_rst_ctl3, 0, sizeof(tcam_lkp_rst_ctl3));

    /*********** ACL lookupResult control setting ***********/
    /* ACL IPv6 key0-key3 */
    tcam_lkp_rst_ctl0.acl0_index_shift0 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsAclIpv6Key0_t);
    tcam_lkp_rst_ctl0.acl0_index_base0 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsAclIpv6Key0_t);
    tcam_lkp_rst_ctl0.acl0_table_base0 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv6Acl0Tcam_t, TRUE);
    tcam_lkp_rst_ctl0.acl1_index_shift0 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsAclIpv6Key1_t);
    tcam_lkp_rst_ctl0.acl1_index_base0 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsAclIpv6Key1_t);
    tcam_lkp_rst_ctl0.acl1_table_base0 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv6Acl1Tcam_t, TRUE);
    /* ACL IPv4 key0-key3 */
    tcam_lkp_rst_ctl0.acl0_index_shift1 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsAclIpv4Key0_t);
    tcam_lkp_rst_ctl0.acl0_index_base1 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsAclIpv4Key0_t);
    tcam_lkp_rst_ctl0.acl0_table_base1 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv4Acl0Tcam_t, TRUE);
    tcam_lkp_rst_ctl0.acl1_index_shift1 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsAclIpv4Key1_t);
    tcam_lkp_rst_ctl0.acl1_index_base1 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsAclIpv4Key1_t);
    tcam_lkp_rst_ctl0.acl1_table_base1 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv4Acl1Tcam_t, TRUE);
    tcam_lkp_rst_ctl0.acl2_index_shift1 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsAclIpv4Key2_t);
    tcam_lkp_rst_ctl0.acl2_index_base1 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsAclIpv4Key2_t);
    tcam_lkp_rst_ctl0.acl2_table_base1 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv4Acl2Tcam_t, TRUE);
    tcam_lkp_rst_ctl0.acl3_index_shift1 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsAclIpv4Key3_t);
    tcam_lkp_rst_ctl0.acl3_index_base1 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsAclIpv4Key3_t);
    tcam_lkp_rst_ctl0.acl3_table_base1 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv4Acl3Tcam_t, TRUE);
    /* ACL Mac key0-key3 */
    tcam_lkp_rst_ctl0.acl0_index_shift2 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsAclMacKey0_t);
    tcam_lkp_rst_ctl0.acl0_index_base2 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsAclMacKey0_t);
    tcam_lkp_rst_ctl0.acl0_table_base2 = _cm_sim_cfg_kit_get_ad_table_base(DsMacAcl0Tcam_t, TRUE);
    tcam_lkp_rst_ctl0.acl1_index_shift2 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsAclMacKey1_t);
    tcam_lkp_rst_ctl0.acl1_index_base2 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsAclMacKey1_t);
    tcam_lkp_rst_ctl0.acl1_table_base2 = _cm_sim_cfg_kit_get_ad_table_base(DsMacAcl1Tcam_t, TRUE);
    tcam_lkp_rst_ctl0.acl2_index_shift2 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsAclMacKey2_t);
    tcam_lkp_rst_ctl0.acl2_index_base2 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsAclMacKey2_t);
    tcam_lkp_rst_ctl0.acl2_table_base2 = _cm_sim_cfg_kit_get_ad_table_base(DsMacAcl2Tcam_t, TRUE);
    tcam_lkp_rst_ctl0.acl3_index_shift2 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsAclMacKey3_t);
    tcam_lkp_rst_ctl0.acl3_index_base2 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsAclMacKey3_t);
    tcam_lkp_rst_ctl0.acl3_table_base2 = _cm_sim_cfg_kit_get_ad_table_base(DsMacAcl3Tcam_t, TRUE);

    /*********** UserID and OAM ***********/
    /* UserID Mac */
    tcam_lkp_rst_ctl1.user_id_index_shift0 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsUserIdMacKey_t);
    tcam_lkp_rst_ctl1.user_id_index_base0 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsUserIdMacKey_t);
    tcam_lkp_rst_ctl1.user_id_table_base0 = _cm_sim_cfg_kit_get_ad_table_base(DsUserIdMacTcam_t, TRUE);
    /* UserID IPv6 */
    tcam_lkp_rst_ctl1.user_id_index_shift1 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsUserIdIpv6Key_t);
    tcam_lkp_rst_ctl1.user_id_index_base1 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsUserIdIpv6Key_t);
    tcam_lkp_rst_ctl1.user_id_table_base1 = _cm_sim_cfg_kit_get_ad_table_base(DsUserIdIpv6Tcam_t, TRUE);
    /* UserID IPv4 */
    tcam_lkp_rst_ctl1.user_id_index_shift2 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsUserIdIpv4Key_t);
    tcam_lkp_rst_ctl1.user_id_index_base2 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsUserIdIpv4Key_t);
    tcam_lkp_rst_ctl1.user_id_table_base2 = _cm_sim_cfg_kit_get_ad_table_base(DsUserIdIpv4Tcam_t, TRUE);
    /* UserID Vlan */
    tcam_lkp_rst_ctl1.user_id_index_shift3 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsUserIdVlanKey_t);
    tcam_lkp_rst_ctl1.user_id_index_base3 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsUserIdVlanKey_t);
    tcam_lkp_rst_ctl1.user_id_table_base3 = _cm_sim_cfg_kit_get_ad_table_base(DsUserIdVlanTcam_t, TRUE);
    /* TunnleIpv6 */
    tcam_lkp_rst_ctl1.user_id_index_shift4 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsTunnelIdIpv6Key_t);
    tcam_lkp_rst_ctl1.user_id_index_base4 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsTunnelIdIpv6Key_t);
    tcam_lkp_rst_ctl1.user_id_table_base4 = _cm_sim_cfg_kit_get_ad_table_base(DsTunnelIdIpv6Tcam_t, TRUE);
    /* TunnleIpv4 */
    tcam_lkp_rst_ctl1.user_id_index_shift5 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsTunnelIdIpv4Key_t);
    tcam_lkp_rst_ctl1.user_id_index_base5 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsTunnelIdIpv4Key_t);
    tcam_lkp_rst_ctl1.user_id_table_base5 = _cm_sim_cfg_kit_get_ad_table_base(DsTunnelIdIpv4Tcam_t, TRUE);
    /* TunnlePBB */
    tcam_lkp_rst_ctl1.user_id_index_shift6 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsTunnelIdPbbKey_t);
    tcam_lkp_rst_ctl1.user_id_index_base6 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsTunnelIdPbbKey_t);
    tcam_lkp_rst_ctl1.user_id_table_base6 = _cm_sim_cfg_kit_get_ad_table_base(DsTunnelIdPbbTcam_t, TRUE);
    /* TunnleCapwap */
    tcam_lkp_rst_ctl1.user_id_index_shift7 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsTunnelIdCapwapKey_t);
    tcam_lkp_rst_ctl1.user_id_index_base7 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsTunnelIdCapwapKey_t);
    tcam_lkp_rst_ctl1.user_id_table_base7 = _cm_sim_cfg_kit_get_ad_table_base(DsTunnelIdCapwapTcam_t, TRUE);
    /* TunnleTrill */
    tcam_lkp_rst_ctl1.user_id_index_shift8 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsTunnelIdTrillKey_t);
    tcam_lkp_rst_ctl1.user_id_index_base8 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsTunnelIdTrillKey_t);
    tcam_lkp_rst_ctl1.user_id_table_base8 = _cm_sim_cfg_kit_get_ad_table_base(DsTunnelIdTrillTcam_t, TRUE);

    /*********** IP and MAC ***********/
    /* IPv4 Uc */
    tcam_lkp_rst_ctl2.ip_da_index_shift0 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv4UcastRouteKey_t);
    tcam_lkp_rst_ctl2.ip_da_index_base0 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv4UcastRouteKey_t);
    tcam_lkp_rst_ctl2.ip_da_table_base0 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv4UcastDaTcam_t, TRUE);
    /* IPv4 Mc */
    tcam_lkp_rst_ctl2.ip_da_index_shift1 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv4McastRouteKey_t);
    tcam_lkp_rst_ctl2.ip_da_index_base1 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv4McastRouteKey_t);
    tcam_lkp_rst_ctl2.ip_da_table_base1 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv4McastDaTcam_t, TRUE);
    /* IPv4 Uc RPF */
    /*
    tcam_lkp_rst_ctl2.ip_sa_index_shift0 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv4RpfKey_t);
    tcam_lkp_rst_ctl2.ip_sa_index_base0 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv4RpfKey_t);
    */
    tcam_lkp_rst_ctl2.ip_sa_index_shift0 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv4UcastRouteKey_t);
    tcam_lkp_rst_ctl2.ip_sa_index_base0 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv4UcastRouteKey_t);
    tcam_lkp_rst_ctl2.ip_sa_table_base0 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv4UcastDaTcam_t, TRUE);
    /* IPv4 NAT */
    tcam_lkp_rst_ctl2.ip_sa_index_shift2 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv4NatKey_t);
    tcam_lkp_rst_ctl2.ip_sa_index_base2 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv4NatKey_t);
    tcam_lkp_rst_ctl2.ip_sa_table_base2 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv4SaNatTcam_t, TRUE);
    /* IPv4 PBR */
    tcam_lkp_rst_ctl2.ip_sa_index_shift4 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv4PbrKey_t);
    tcam_lkp_rst_ctl2.ip_sa_index_base4 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv4PbrKey_t);
    tcam_lkp_rst_ctl2.ip_sa_table_base4 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv4UcastPbrDualDaTcam_t, TRUE);
    /* IPv6 Uc */
    tcam_lkp_rst_ctl2.ip_da_index_shift2 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv6UcastRouteKey_t);
    tcam_lkp_rst_ctl2.ip_da_index_base2 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv6UcastRouteKey_t);
    tcam_lkp_rst_ctl2.ip_da_table_base2 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv6UcastDaTcam_t, TRUE);
    /* IPv6 Mc */
    tcam_lkp_rst_ctl2.ip_da_index_shift3 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv6McastRouteKey_t);
    tcam_lkp_rst_ctl2.ip_da_index_base3 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv6McastRouteKey_t);
    tcam_lkp_rst_ctl2.ip_da_table_base3 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv6McastDaTcam_t, TRUE);
    /* IPv6 RPF */
    tcam_lkp_rst_ctl2.ip_sa_index_shift1 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv6RpfKey_t);
    tcam_lkp_rst_ctl2.ip_sa_index_base1 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv6RpfKey_t);
    /* IPv6 Mc RPF AD Base */
    // ?? here will refer code, waitting ... ...???
    // tcam_lkp_rst_ctl3.ds_ipv6_mcast_rpf_table_base = _cm_sim_cfg_kit_get_ad_table_base(DsIpv6McastRpf_t, TRUE);
    /* IPv6 NAT */
    tcam_lkp_rst_ctl2.ip_sa_index_shift3 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv6NatKey_t);
    tcam_lkp_rst_ctl2.ip_sa_index_base3 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv6NatKey_t);
    tcam_lkp_rst_ctl2.ip_sa_table_base3 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv6SaNatTcam_t, TRUE);
    /* IPv6 PBR */
    tcam_lkp_rst_ctl2.ip_sa_index_shift5 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsIpv6PbrKey_t);
    tcam_lkp_rst_ctl2.ip_sa_index_base5 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsIpv6PbrKey_t);
    tcam_lkp_rst_ctl2.ip_sa_table_base5 = _cm_sim_cfg_kit_get_ad_table_base(DsIpv6UcastPbrDualDaTcam_t, TRUE);
    /* MacDa */
    tcam_lkp_rst_ctl2.mac_da_index_shift = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsMacBridgeKey_t);
    tcam_lkp_rst_ctl2.mac_da_index_base = _cm_sim_cfg_kit_get_tcam_key_index_base(DsMacBridgeKey_t);
    tcam_lkp_rst_ctl2.mac_da_table_base = _cm_sim_cfg_kit_get_ad_table_base(DsMacTcam_t, TRUE);
    /* MacSa */
    tcam_lkp_rst_ctl2.mac_sa_index_shift = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsMacBridgeKey_t);
    tcam_lkp_rst_ctl2.mac_sa_index_base = _cm_sim_cfg_kit_get_tcam_key_index_base(DsMacBridgeKey_t);
    tcam_lkp_rst_ctl2.mac_sa_table_base = _cm_sim_cfg_kit_get_ad_table_base(DsMacTcam_t, TRUE);

    /*********** FCoE and Trill ***********/
    /* FCoE Da */
    tcam_lkp_rst_ctl3.fcoe_index_shift0 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsFcoeRouteKey_t);
    tcam_lkp_rst_ctl3.fcoe_index_base0 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsFcoeRouteKey_t);
    tcam_lkp_rst_ctl3.fcoe_table_base0 = _cm_sim_cfg_kit_get_ad_table_base(DsFcoeDaTcam_t, TRUE);
    /* FCoE Sa */
    tcam_lkp_rst_ctl3.fcoe_index_shift1 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsFcoeRpfKey_t);
    tcam_lkp_rst_ctl3.fcoe_index_base1 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsFcoeRpfKey_t);
    tcam_lkp_rst_ctl3.fcoe_table_base1 = _cm_sim_cfg_kit_get_ad_table_base(DsFcoeSaTcam_t, TRUE);
    /* Trill Da Uc */
    tcam_lkp_rst_ctl3.trill_index_shift0 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsTrillUcastRouteKey_t);
    tcam_lkp_rst_ctl3.trill_index_base0 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsTrillUcastRouteKey_t);
    tcam_lkp_rst_ctl3.trill_table_base0 = _cm_sim_cfg_kit_get_ad_table_base(DsTrillDaUcastTcam_t, TRUE);
    /* Trill Da Mc */
    tcam_lkp_rst_ctl3.trill_index_shift1 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsTrillMcastRouteKey_t);
    tcam_lkp_rst_ctl3.trill_index_base1 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsTrillMcastRouteKey_t);
    tcam_lkp_rst_ctl3.trill_table_base1 = _cm_sim_cfg_kit_get_ad_table_base(DsTrillDaMcastTcam_t, TRUE);
#if 1
    /* Ipv4Mac */
    tcam_lkp_rst_ctl3.mac_ip_index_shift0 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsMacIpv6Key_t);
    tcam_lkp_rst_ctl3.mac_ip_index_base0 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsMacIpv6Key_t);
    tcam_lkp_rst_ctl3.mac_ip_table_base0 = _cm_sim_cfg_kit_get_ad_table_base(DsMacIpv6Tcam_t, TRUE);
    /* Ipv6Mac */
    tcam_lkp_rst_ctl3.mac_ip_index_shift1 = _cm_sim_cfg_kit_get_tcam_key_index_shift(DsMacIpv4Key_t);
    tcam_lkp_rst_ctl3.mac_ip_index_base1 = _cm_sim_cfg_kit_get_tcam_key_index_base(DsMacIpv4Key_t);
    tcam_lkp_rst_ctl3.mac_ip_table_base1 = _cm_sim_cfg_kit_get_ad_table_base(DsMacIpv4Tcam_t, TRUE);
#endif
    cmd = DRV_IOW(TcamEngineLookupResultCtl0_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_lkp_rst_ctl0));

    cmd = DRV_IOW(TcamEngineLookupResultCtl1_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_lkp_rst_ctl1));

    cmd = DRV_IOW(TcamEngineLookupResultCtl2_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_lkp_rst_ctl2));

    cmd = DRV_IOW(TcamEngineLookupResultCtl3_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_lkp_rst_ctl3));

    return DRV_E_NONE;
}

static int32
_cm_sim_cfg_kit_init_default_entry_base_register(uint32 chip_id)
{
    uint32 cmd = 0;
    uint32 hash_dft_table_base = 0, user_id_table_base = 0,oam_chan_table_base = 0, tmp_base = 0;
    tbls_id_t tbl_id = MaxTblId_t;
    uint8 blk_id = 0;

    /*--- Setting UserId & TunnelId default entry base ---*/
    tbl_id = DsUserId_t;
    blk_id = 5;
    user_id_table_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 6);

    /* UserId Ingress */
    tbl_id = DsUserIdIngressDefault_t;
    blk_id = 5;
    tmp_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 6);
    hash_dft_table_base = tmp_base - user_id_table_base;
    hash_dft_table_base /= 2;
    cmd = DRV_IOW(UserIdResultCtl_t, UserIdResultCtl_UserIdIngressDefaultEntryBase_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &hash_dft_table_base));
    /* UserId Egress */
    tbl_id = DsUserIdEgressDefault_t;
    blk_id = 5;
    tmp_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 6);
    cmd = DRV_IOW(UserIdResultCtl_t, UserIdResultCtl_UserIdEgressDefaultEntryBase_f);
    hash_dft_table_base = tmp_base - user_id_table_base;
    hash_dft_table_base /= 2;
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &hash_dft_table_base));
    /* TunnelId */
    tbl_id = DsUserId_t;
    blk_id = 5;
    user_id_table_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 0);

    tbl_id = DsTunnelIdDefault_t;
    blk_id = 5;
    tmp_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 0);
    hash_dft_table_base = tmp_base - user_id_table_base;
    hash_dft_table_base /= 2;
    cmd = DRV_IOW(UserIdResultCtl_t, UserIdResultCtl_TunnelIdDefaultEntryBase_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &hash_dft_table_base));

    /**/
    tbl_id = DsUserId_t;
    blk_id = 5;
    user_id_table_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 6);

    tmp_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 6);
    tmp_base -= user_id_table_base;
    cmd = DRV_IOW(UserIdResultCtl_t, UserIdResultCtl_UserIdResultBase_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tmp_base));

    tbl_id = DsEthOamChan_t;
    blk_id = 5;
    tmp_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 6);
    oam_chan_table_base = tmp_base - user_id_table_base;
    cmd = DRV_IOW(UserIdResultCtl_t, UserIdResultCtl_OamResultBase_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_chan_table_base));

    /*--- Setting FIB default entry base (Mac & IP & Trill & FCoE) ---*/
    /* cfg in Master.txt because of no sole default entry table name application of driver */

    return DRV_E_NONE;
}



inline uint32
_cm_sim_cfg_kit_get_tcam_ad_table_base(tbls_id_t ad_table, uint8 is_tcam_ad)
{
    uint32 hw_data_base = 0, index_base = 0;

    hw_data_base = TABLE_DATA_BASE(ad_table);

    if (!TABLE_MAX_INDEX(ad_table))
    {
        return 0;
    }

    if (is_tcam_ad)
    {
        if (DRV_ADDR_IN_TCAMAD_SRAM_8W_RANGE(hw_data_base))
        {
            index_base = (hw_data_base - DRV_INT_TCAM_AD_MEM_8W_BASE)/DRV_ADDR_BYTES_PER_ENTRY;
        }
        else
        {
            index_base = (hw_data_base - DRV_INT_TCAM_AD_MEM_4W_BASE)/DRV_ADDR_BYTES_PER_ENTRY;
        }

    }
    else
    {
        if (DRV_ADDR_IN_DYNAMIC_SRAM_8W_RANGE(hw_data_base))
        {
            index_base = (hw_data_base - DRV_MEMORY0_BASE_8W)/DRV_ADDR_BYTES_PER_ENTRY;
        }
        else
        {
            index_base = (hw_data_base - DRV_MEMORY0_BASE_4W)/DRV_ADDR_BYTES_PER_ENTRY;
        }
    }

    if (index_base%64)
    {
        CMODEL_DEBUG_OUT_INFO("%% Attention!! TableId = %d, indexBase mod 64 is not integral!\n", ad_table);
    }

    return (index_base>>6);
}


/*  for use same interface to do set dynamic base register,
    use dynamic_ds_five_base_cam_t to store the data of all dynamic ds base cam info,
    and in code ,must check if the dynamic registre base num is more than the bitmap of dynamic table */
static int32 _cm_sim_cfg_kit_set_dynamic_base_struct(dynamic_ds_five_base_cam_t* dynamic_ds_base_cam_ptr,
                                                                  tbls_id_t tbl_id,
                                                                  uint8 dynamic_ds_base_num)
{
    #define DYNAMIC_DS_REGISTER_MAX_BASE_NUM 5
    uint8 dynamic_table_bitmap_num = 0;
    uint8 blk_id = 0;
    uint8 is_dynamic_tbl_base_set_flg[DYNAMIC_DS_REGISTER_MAX_BASE_NUM] = {0};
    uint32 recorded_entry_num = 0, special_tbl_sub_entry_num = 0;
    uint32 ds_dynamic_base = 0, ds_dynamic_min_index = 0, ds_dynamic_max_index = 0;
    uint8 drv_index_not_per_80_bit_flag = FALSE;
    uint32 hw_data_basic_base = 0;
    uint32 drv_start_entry_num = 0, drv_end_entry_num = 0;
    /*
    uint32 oam_lm_stats_static_total_index_num = 0;
    uint8 oam_lm_stats_static_tbl_index = 0;
    tbls_id_t oam_stats_static_tbl_id = MaxTblId_t;
    */
    tbls_id_t user_id_default_table_id = MaxTblId_t;
    uint32 user_id_default_entry_num = 0;

    /* ??? shenhg special disposal for DsOamLmStats and UserIdHash0*/
    /* the detailed info is in share spec, DynamicDs */
#if 0
    /* speclai disposal for DsStats, memory block 8 */
    /* the base,min index and max index of dynamic cam should sub 16K */
    if (tbl_id == DsStats_t)
    {
        /* if the max index num of DsStats is not more than 16K, DsStats can't use other memory block except block 8 */
        if (TABLE_MAX_INDEX(tbl_id) <= NUM_16K)
        {
            for (blk_id = 0; blk_id < (MAX_MEMORY_BLOCK_NUM - 3); blk_id++)
            {
                if (IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
                {
                    CMODEL_DEBUG_OUT_INFO("max index of DsStats isn't more than 16K, and DsStats use other memory block\n");
                    return DRV_E_INVALID_DYNIC_TBL_ALLOC;
                }

            }
        }
        else
        {
            /* if the DsStats use other block, the base address should subtract 16K */
            special_tbl_sub_entry_num = NUM_16K*TABLE_ENTRY_SIZE(tbl_id)/DRV_BYTES_PER_ENTRY;
        }
    }
#endif

#if 0
    /* speclai disposal for DsOamLmStats, memory block 9 */
    /* the base,min index and max index of dynamic cam should sub N*128*48/12 */
    if (tbl_id == DsOamLmStats_t)
    {
        for (oam_lm_stats_static_tbl_index = 0; oam_lm_stats_static_tbl_index < LM_EXT_BLOCK_NUM; oam_lm_stats_static_tbl_index++)
        {
            switch (oam_lm_stats_static_tbl_index)
            {
                case 0:
                    oam_stats_static_tbl_id = DsOamLmStats0_t;
                    break;

                case 1:
                    oam_stats_static_tbl_id = DsOamLmStats1_t;
                    break;

                default:
                    break;
            }
            oam_lm_stats_static_total_index_num += TABLE_MAX_INDEX(oam_stats_static_tbl_id);

        }

        /* if the max index num of DsOamLmStats_t is not more than 256, DsOamLmStats_t can't use other memory block except block 9 */
        if (TABLE_MAX_INDEX(tbl_id) <= oam_lm_stats_static_total_index_num)
        {
            for (blk_id = 0; blk_id < (MAX_MEMORY_BLOCK_NUM); blk_id++)
            {
                if (IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
                {
                    CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! max index of DsOamLmStats isn't more than %d, and DsOamLmStats use other memory block\n",
                                            oam_lm_stats_static_total_index_num);
                    return DRV_E_INVALID_DYNIC_TBL_ALLOC;
                }
            }
        }
        else
        {
            /* if the DsOamLmStats use other block, the index should subtract N*128*48/12 */
            recorded_entry_num = oam_lm_stats_static_total_index_num*TABLE_ENTRY_SIZE(tbl_id)/DRV_BYTES_PER_ENTRY;
        }
    }
#endif

    /* speclai disposal for userid hash key, memory block 7 */
    /* 16K entry in memory block7 must allocated to DsUserIdHash, so other block, */
    if (tbl_id == DsUserIdDoubleVlanHashKey_t)
    {
        if (TABLE_MAX_INDEX(tbl_id) < DRV_MEMORY7_MAX_ENTRY_NUM)
        {
            CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! The max index of userId hash key can't less than 16k.\n");
            return DRV_E_INVALID_DYNIC_TBL_ALLOC;
        }

        recorded_entry_num = DRV_MEMORY7_MAX_ENTRY_NUM;
    }

    /*  the max and min index of drv is table index, not per 80 bits, and set the dynamic register must use per 80 bit index
        set the flag to indicated that it must do some change when write to dynamic register */
    if ((DYNAMIC_ACCESS_MODE(tbl_id) == DYNAMIC_DEFAULT) && (TABLE_ENTRY_SIZE(tbl_id) != DRV_BYTES_PER_ENTRY))
    {
        drv_index_not_per_80_bit_flag = TRUE;
    }

    /* check the table is 80 or 160 addressing, record the memory0 base address */
    if (TABLE_ENTRY_SIZE(tbl_id) == DRV_BYTES_PER_ENTRY)
    {
        hw_data_basic_base = DRV_MEMORY0_BASE_4W;
    }
    else
    {
        hw_data_basic_base = DRV_MEMORY0_BASE_8W;
    }

    /* ??? shenhg the max block should be 7, because the block 7 is only used by user id hash0, similar to DsStats and lm -- 20120109
       the allocation function also should be changed */
    for (blk_id = 0; blk_id < (MAX_MEMORY_BLOCK_NUM); blk_id++)
    {
        /* block 7 is only used by userId hash0, has counted by previous code */
        if (blk_id == 7)
        {
            continue;
        }

        /* if table is not in block , continue */
        if(!IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
        {
            continue;
        }

        dynamic_table_bitmap_num++;
        ds_dynamic_base = 0;
        ds_dynamic_min_index = 0;
        ds_dynamic_max_index = 0;

        /* if the bitmap of table is more than the record of dynamic register, error */
        if (dynamic_table_bitmap_num > dynamic_ds_base_num)
        {
            CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Bitmap num of table %s %d is more than the record num of register %d\n",
                                    TABLE_NAME(tbl_id), dynamic_table_bitmap_num, dynamic_ds_base_num);
            return DRV_E_INVALID_DYNIC_TBL_ALLOC;
        }


        /* get the dynamic cam info ,include dynamic_base, min_index, max_index -- per 80bits*/
        /* in RTL design, the block base address should del all the previous entry num */
#if 0
        ds_dynamic_base = (DYNAMIC_DATA_BASE(tbl_id, blk_id) - hw_data_basic_base)/DRV_ADDR_BYTES_PER_ENTRY
                            - recorded_entry_num - special_tbl_sub_entry_num;
#else
        ds_dynamic_base = (DYNAMIC_DATA_BASE(tbl_id, blk_id) - hw_data_basic_base)/DRV_ADDR_BYTES_PER_ENTRY;
#endif
        /* the min index is equal to all the previous entry num */
        ds_dynamic_min_index = recorded_entry_num;
        /* add this block entry num to variable recorded_entry_num */
        recorded_entry_num += DYNAMIC_ENTRY_NUM(tbl_id, blk_id);
        /* the real max index is qeual to recorded_entry_num subtract 1 */
        /* for example, recorder entry num is 1K, and min index should be 0, and the max index should be 1023 */
        ds_dynamic_max_index = recorded_entry_num - 1;

        /* special code for DsUserId, because DsUserId in dynamicDs is the total num of
           DsUserId/DsUserIdIngressDefault_t/DsUserIdEgressDefault_t/DsTunnelIdDefault_t 2012-2-16 SpecV5.9 co-sim bug*/
        if (tbl_id == DsUserId_t)
        {
            /* get all the default entry num */
            user_id_default_entry_num = 0;

            user_id_default_table_id = DsUserIdIngressDefault_t;
            if (IS_BIT_SET(DYNAMIC_BITMAP(user_id_default_table_id), blk_id))
            {
                user_id_default_entry_num += DYNAMIC_ENTRY_NUM(user_id_default_table_id, blk_id);
            }

            user_id_default_table_id = DsUserIdEgressDefault_t;
            if (IS_BIT_SET(DYNAMIC_BITMAP(user_id_default_table_id), blk_id))
            {
                user_id_default_entry_num += DYNAMIC_ENTRY_NUM(user_id_default_table_id, blk_id);
            }

            user_id_default_table_id = DsTunnelIdDefault_t;
            if (IS_BIT_SET(DYNAMIC_BITMAP(user_id_default_table_id), blk_id))
            {
                user_id_default_entry_num += DYNAMIC_ENTRY_NUM(user_id_default_table_id, blk_id);
            }

            /* get oam chan entry num*/
            user_id_default_table_id = DsEthOamChan_t;
            if(IS_BIT_SET(DYNAMIC_BITMAP(user_id_default_table_id), blk_id))
            {
                user_id_default_entry_num += DYNAMIC_ENTRY_NUM(user_id_default_table_id, blk_id);
            }

            /* add default entry info to DynamicDs variable */
            recorded_entry_num += user_id_default_entry_num;
            ds_dynamic_max_index += user_id_default_entry_num;
        }

        /*
        if(tbl_id == DsOamLmStats_t)
        {
            ds_dynamic_min_index /= 4;
            ds_dynamic_max_index /= 4;
        }
        */

        /* because DsUserId has default entry, so the actual granularity can't be 1K */
        if ((tbl_id != DsUserId_t) && (tbl_id != DsOamLmStats_t))
        {
            if ((DYNAMIC_ENTRY_NUM(tbl_id, blk_id) % (1<<DYNAMIC_SHIFT_NUM)) != 0)
            {
                CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! The granularity of dynamic table allocation is %x"
                                       "now dynamic entry num of table %s in block %d is %d\n",
                                        (1<<DYNAMIC_SHIFT_NUM), TABLE_NAME(tbl_id), blk_id, DYNAMIC_ENTRY_NUM(tbl_id, blk_id));
                return DRV_E_INVALID_DYNIC_TBL_ALLOC;
            }

            /* check if the dynamic info in dynamic cam is the same to dynamic info in drv */
            if (drv_index_not_per_80_bit_flag)
            {
                drv_start_entry_num = DYNAMIC_START_INDEX(tbl_id, blk_id)*(TABLE_ENTRY_SIZE(tbl_id)/DRV_BYTES_PER_ENTRY);
                drv_end_entry_num = (DYNAMIC_END_INDEX(tbl_id, blk_id) + 1)*(TABLE_ENTRY_SIZE(tbl_id)/DRV_BYTES_PER_ENTRY) - 1;
            }
            else
            {
                drv_start_entry_num = DYNAMIC_START_INDEX(tbl_id, blk_id);
                drv_end_entry_num = DYNAMIC_END_INDEX(tbl_id, blk_id);
            }

            if ((drv_start_entry_num != (ds_dynamic_min_index+special_tbl_sub_entry_num))
                || (drv_end_entry_num != (ds_dynamic_max_index+special_tbl_sub_entry_num)))
            {
                CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Mismatch value between dynamic cam and drv of table %s in memory block %d:\n",
                                        TABLE_NAME(tbl_id), blk_id);
                CMODEL_DEBUG_OUT_INFO("ds_dynamic_min_index = %x, ds_dynamic_max_index = %x:\n",
                                        (ds_dynamic_min_index+special_tbl_sub_entry_num),
                                        (ds_dynamic_max_index+special_tbl_sub_entry_num));
                CMODEL_DEBUG_OUT_INFO("drv_start_entry_num = %x, drv_end_entry_num = %x:\n",drv_start_entry_num, drv_end_entry_num);
                return DRV_E_INVALID_DYNIC_TBL_ALLOC;
            }
        }
        /* check pass, write the dynamic cam info to struct */
        if (!is_dynamic_tbl_base_set_flg[0])
        {
            dynamic_ds_base_cam_ptr->ds_dynamic_base0 = ds_dynamic_base>>DYNAMIC_SHIFT_NUM;
            dynamic_ds_base_cam_ptr->ds_dynamic_min_index0 = ds_dynamic_min_index>>DYNAMIC_SHIFT_NUM;
            dynamic_ds_base_cam_ptr->ds_dynamic_max_index0 = ds_dynamic_max_index>>DYNAMIC_SHIFT_NUM;

            is_dynamic_tbl_base_set_flg[0] = TRUE;
        }
        else if (!is_dynamic_tbl_base_set_flg[1])
        {
            dynamic_ds_base_cam_ptr->ds_dynamic_base1 = ds_dynamic_base>>DYNAMIC_SHIFT_NUM;
            dynamic_ds_base_cam_ptr->ds_dynamic_min_index1 = ds_dynamic_min_index>>DYNAMIC_SHIFT_NUM;
            dynamic_ds_base_cam_ptr->ds_dynamic_max_index1 = ds_dynamic_max_index>>DYNAMIC_SHIFT_NUM;

            is_dynamic_tbl_base_set_flg[1] = TRUE;
        }
        else if (!is_dynamic_tbl_base_set_flg[2])
        {
            dynamic_ds_base_cam_ptr->ds_dynamic_base2 = ds_dynamic_base>>DYNAMIC_SHIFT_NUM;
            dynamic_ds_base_cam_ptr->ds_dynamic_min_index2 = ds_dynamic_min_index>>DYNAMIC_SHIFT_NUM;
            dynamic_ds_base_cam_ptr->ds_dynamic_max_index2 = ds_dynamic_max_index>>DYNAMIC_SHIFT_NUM;

            is_dynamic_tbl_base_set_flg[2] = TRUE;
        }
        else if (!is_dynamic_tbl_base_set_flg[3])
        {
            dynamic_ds_base_cam_ptr->ds_dynamic_base3 = ds_dynamic_base>>DYNAMIC_SHIFT_NUM;
            dynamic_ds_base_cam_ptr->ds_dynamic_min_index3 = ds_dynamic_min_index>>DYNAMIC_SHIFT_NUM;
            dynamic_ds_base_cam_ptr->ds_dynamic_max_index3 = ds_dynamic_max_index>>DYNAMIC_SHIFT_NUM;

            is_dynamic_tbl_base_set_flg[3] = TRUE;
        }
        else if (!is_dynamic_tbl_base_set_flg[4])
        {
            dynamic_ds_base_cam_ptr->ds_dynamic_base4 = ds_dynamic_base>>DYNAMIC_SHIFT_NUM;
            dynamic_ds_base_cam_ptr->ds_dynamic_min_index4 = ds_dynamic_min_index>>DYNAMIC_SHIFT_NUM;
            dynamic_ds_base_cam_ptr->ds_dynamic_max_index4 = ds_dynamic_max_index>>DYNAMIC_SHIFT_NUM;

            is_dynamic_tbl_base_set_flg[4] = TRUE;
        }

    }

    return DRV_E_NONE;
}


static int32 _cm_sim_cfg_kit_get_dynamic_base_info(void **dynamic_ds_base_cam_ptr,
                                                                  tbls_id_t tbl_id,
                                                                  uint8 dynamic_ds_base_num)
{

    /* set the pointer to five base cam */
    sal_memset(&dynamic_ds_five_base_cam, 0, sizeof(dynamic_ds_five_base_cam));
    *dynamic_ds_base_cam_ptr = &dynamic_ds_five_base_cam;

    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_set_dynamic_base_struct((dynamic_ds_five_base_cam_t *)(*dynamic_ds_base_cam_ptr),
                                                                tbl_id, dynamic_ds_base_num));

    return DRV_E_NONE;

}

static int32
_cm_sim_cfg_kit_init_dynamic_table_base_register(uint32 chip_id)
{

    uint32 cmd = 0;
    tbls_id_t tbl_id = MaxTblId_t, dynamic_cam_tbl_id = MaxTblId_t;
    uint32 list_index = 0;
    uint32 entry_index = 0;
    uint8 blk_id = 0;
    dynamic_ds_lpm_index_cam0_t dynamic_ds_lpm_cam0;
    dynamic_ds_lpm_index_cam1_t dynamic_ds_lpm_cam1;
    dynamic_ds_lpm_index_cam2_t dynamic_ds_lpm_cam2;
    dynamic_ds_lpm_index_cam3_t dynamic_ds_lpm_cam3;
    dynamic_ds_oam_index_cam_t dynamic_ds_oam_index_cam;
    uint32 dynic_tbl_base = 0;
    uint32 oam_mep_base = 0, tmp_min_index = 0, tmp_max_index = 0;
    void * dynamic_ds_base_cam_ptr = NULL;

    uint32 mep_base     = 0;
    uint32 ma_base      = 0;
    uint32 maname_base  = 0;


    int32 mep_block_id      = -1;
    int32 ma_block_id       = -1;
    int32 namame_block_id   = -1;
    uint32 field_id = 0;
    int idx = 0;
    uint32 tlbs[3] = {DsEthMep_t, DsMa_t, DsMaName_t};
    uint32 fileds[3] = {OamTblAddrCtl_MpBaseAddr_f, OamTblAddrCtl_MaBaseAddr_f, OamTblAddrCtl_MaNameBaseAddr_f};

    uint32 max = 0, min = 0, middle = 0;
    uint32 block_idx = 0;

    sal_memset(&dynamic_ds_lpm_cam0, 0, sizeof(dynamic_ds_lpm_cam0));
    sal_memset(&dynamic_ds_lpm_cam1, 0, sizeof(dynamic_ds_lpm_cam1));
    sal_memset(&dynamic_ds_lpm_cam2, 0, sizeof(dynamic_ds_lpm_cam2));
    sal_memset(&dynamic_ds_lpm_cam3, 0, sizeof(dynamic_ds_lpm_cam3));
    sal_memset(&dynamic_ds_oam_index_cam, 0, sizeof(dynamic_ds_oam_index_cam));

    /* check if the table num in ds_dynamic_cam_list and ds_dynamic_cam_table_list is same */
    if ((sizeof(ds_dynamic_cam_list)/sizeof(ds_dynamic_cam_list[0]))
        != (sizeof(ds_dynamic_cam_table_list)/sizeof(ds_dynamic_cam_table_list[0])))
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! In dynamic_table_base_register function, num of ds_dynamic_cam_list and ds_dynamic_cam_table_list is mismatch\n");
        return DRV_E_INVALID_DYNIC_TBL_ALLOC;
    }

    /* set dynamic ds cam info in  ds_dynamic_cam_list */
    for (list_index = 0; list_index < sizeof(ds_dynamic_cam_list)/sizeof(ds_dynamic_cam_list[0]); list_index++)
    {
        dynamic_cam_tbl_id = ds_dynamic_cam_list[list_index];
        tbl_id = ds_dynamic_cam_table_list[list_index];
        /* if the table is not allocated, shouldn't set the dynamic register */
        if (TABLE_MAX_INDEX(tbl_id) != 0)
        {
            DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_get_dynamic_base_info(&dynamic_ds_base_cam_ptr, tbl_id,
                                                                        TABLE_ENTRY_SIZE(dynamic_cam_tbl_id)/DRV_BYTES_PER_WORD));
            cmd = DRV_IOW(dynamic_cam_tbl_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, dynamic_ds_base_cam_ptr));
            dynamic_ds_base_cam_ptr = NULL;
        }
    }

    /* fixed code for lpm key0 lpm key1 and oamMep soooooo~~ stupid code, must modify code for each profile,
       must change if there is free time */

    /* Lpm lookup Key0 share table, pipeline1 and pipeline2 use half of lpm lookup key0 space*/
    /* for default profile, lpm lookup key0 is 16K and is in memory block 2 */
    tbl_id = DsLpmLookupKey0_t;
    blk_id = 3;

    if (TABLE_MAX_INDEX(tbl_id) != 0)
    {
        /* set DynamicDsLpmCam0 info */
        dynamic_ds_lpm_cam0.ds_lpm0_base0 = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, DYNAMIC_SHIFT_NUM);
        dynamic_ds_lpm_cam0.ds_lpm0_min_index0 = 0>>DYNAMIC_SHIFT_NUM;
        dynamic_ds_lpm_cam0.ds_lpm0_max_index0 = (DYNAMIC_ENTRY_NUM(tbl_id, blk_id) - 1)>>DYNAMIC_SHIFT_NUM;

        dynamic_ds_base_cam_ptr = &dynamic_ds_lpm_cam0;
        dynamic_cam_tbl_id = DynamicDsLpmIndexCam0_t;
        cmd = DRV_IOW(dynamic_cam_tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, dynamic_ds_base_cam_ptr));
        dynamic_ds_base_cam_ptr = NULL;
    }

    tbl_id = DsLpmLookupKey3_t;
    blk_id = 3;

    if (TABLE_MAX_INDEX(tbl_id) != 0)
    {
        /* set DynamicDsLpmCam3 info */
        dynamic_ds_lpm_cam3.ds_lpm3_base0 = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, DYNAMIC_SHIFT_NUM);

        dynamic_ds_lpm_cam3.ds_lpm3_min_index0 = 0>>DYNAMIC_SHIFT_NUM;
        dynamic_ds_lpm_cam3.ds_lpm3_max_index0 = (DYNAMIC_ENTRY_NUM(tbl_id, blk_id)-1)>>DYNAMIC_SHIFT_NUM;

        dynamic_ds_base_cam_ptr = &dynamic_ds_lpm_cam3;
        dynamic_cam_tbl_id = DynamicDsLpmIndexCam3_t;
        cmd = DRV_IOW(dynamic_cam_tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, dynamic_ds_base_cam_ptr));
        dynamic_ds_base_cam_ptr = NULL;
    }


    /* Lpm lookup Key1 share table */
    /* for default profile, lpm lookup key1 is 16K and is in memory block 2 */
    tbl_id = DsLpmLookupKey1_t;
    blk_id = 1;

    if (TABLE_MAX_INDEX(tbl_id) != 0)
    {
        /* set DynamicDsLpmCam1 info */
        dynamic_ds_lpm_cam1.ds_lpm1_base0 = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, DYNAMIC_SHIFT_NUM);
        dynamic_ds_lpm_cam1.ds_lpm1_min_index0 = 0>>DYNAMIC_SHIFT_NUM;
        dynamic_ds_lpm_cam1.ds_lpm1_max_index0 = (DYNAMIC_ENTRY_NUM(tbl_id, blk_id)-1)>>DYNAMIC_SHIFT_NUM;

        dynamic_ds_base_cam_ptr = &dynamic_ds_lpm_cam1;
        dynamic_cam_tbl_id = DynamicDsLpmIndexCam1_t;
        cmd = DRV_IOW(dynamic_cam_tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, dynamic_ds_base_cam_ptr));
        dynamic_ds_base_cam_ptr = NULL;
    }

    tbl_id = DsLpmLookupKey2_t;
    blk_id = 1;
    if (TABLE_MAX_INDEX(tbl_id) != 0)
    {
            /* set DynamicDsLpmCam2 info */
        dynamic_ds_lpm_cam2.ds_lpm2_base0 = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, DYNAMIC_SHIFT_NUM);
        dynamic_ds_lpm_cam2.ds_lpm2_min_index0 = 0 >>DYNAMIC_SHIFT_NUM;
        dynamic_ds_lpm_cam2.ds_lpm2_max_index0 = (DYNAMIC_ENTRY_NUM(tbl_id, blk_id) -1)>>DYNAMIC_SHIFT_NUM;

        dynamic_ds_base_cam_ptr = &dynamic_ds_lpm_cam2;
        dynamic_cam_tbl_id = DynamicDsLpmIndexCam2_t;
        cmd = DRV_IOW(dynamic_cam_tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, dynamic_ds_base_cam_ptr));
        dynamic_ds_base_cam_ptr = NULL;
    }

    /* ??? shenhg different from spec V5.6, the true  mep/ma/maName index only use OamTblAddrCtl.xxBase,
       tangfei has told to jiping, will release in next spec , keep old index style */
    /*oam share table*/
    tmp_min_index = 0;
    tmp_max_index = 0;

    for(blk_id = 0; blk_id < (MAX_MEMORY_BLOCK_NUM); blk_id++)
    {
        if(IS_BIT_SET(DYNAMIC_BITMAP(DsEthMep_t), blk_id)
            || IS_BIT_SET(DYNAMIC_BITMAP(DsMa_t), blk_id)
            || IS_BIT_SET(DYNAMIC_BITMAP(DsMaName_t), blk_id))
        {
            if(IS_BIT_SET(DYNAMIC_BITMAP(DsEthMep_t), blk_id))
            {
                mep_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(DsEthMep_t, blk_id, 0);
            }
            else
            {
                mep_base = 0xFFFFFFFF;
            }

            if(IS_BIT_SET(DYNAMIC_BITMAP(DsMaName_t), blk_id))
            {
                maname_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(DsMaName_t, blk_id, 0);
            }
            else
            {
                maname_base = 0xFFFFFFFF;
            }

            if(IS_BIT_SET(DYNAMIC_BITMAP(DsMa_t), blk_id))
            {
                ma_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(DsMa_t, blk_id, 0);
            }
            else
            {
                ma_base = 0xFFFFFFFF;
            }

            oam_mep_base = (maname_base < ma_base) ? maname_base :ma_base;
            oam_mep_base = (oam_mep_base < mep_base) ? oam_mep_base :mep_base;

            tmp_max_index += DYNAMIC_ENTRY_NUM(DsEthMep_t, blk_id) + DYNAMIC_ENTRY_NUM(DsMa_t, blk_id) + DYNAMIC_ENTRY_NUM(DsMaName_t, blk_id);
            switch(block_idx)
            {
                case 0:
                    dynamic_ds_oam_index_cam.ds_oam_base0 = oam_mep_base >>DYNAMIC_SHIFT_NUM;
                    dynamic_ds_oam_index_cam.ds_oam_min_index0 = tmp_min_index >> DYNAMIC_SHIFT_NUM;
                    dynamic_ds_oam_index_cam.ds_oam_max_index0 = (tmp_max_index - 1) >> DYNAMIC_SHIFT_NUM;
                    break;
                case 1:
                    dynamic_ds_oam_index_cam.ds_oam_base1 = oam_mep_base >>DYNAMIC_SHIFT_NUM;
                    dynamic_ds_oam_index_cam.ds_oam_min_index1 = tmp_min_index >> DYNAMIC_SHIFT_NUM;
                    dynamic_ds_oam_index_cam.ds_oam_max_index1 = (tmp_max_index - 1) >> DYNAMIC_SHIFT_NUM;
                    break;
                case 2:
                    dynamic_ds_oam_index_cam.ds_oam_base2 = oam_mep_base >>DYNAMIC_SHIFT_NUM;
                    dynamic_ds_oam_index_cam.ds_oam_min_index2 = tmp_min_index >> DYNAMIC_SHIFT_NUM;
                    dynamic_ds_oam_index_cam.ds_oam_max_index2 = (tmp_max_index - 1) >> DYNAMIC_SHIFT_NUM;
                    break;
                default:
                    break;
            }

            tmp_min_index = tmp_max_index;
            block_idx ++;
        }
    }

    dynamic_ds_base_cam_ptr = &dynamic_ds_oam_index_cam;
    dynamic_cam_tbl_id = DynamicDsOamIndexCam_t;
    cmd = DRV_IOW(dynamic_cam_tbl_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, dynamic_ds_base_cam_ptr));
    dynamic_ds_base_cam_ptr = NULL;

    /*oam engine internal register ctl*/
    /*sort ma, maname, mep*/
    for(blk_id = 0; blk_id < (MAX_MEMORY_BLOCK_NUM); blk_id++)
    {
        if(mep_block_id == -1)
        {
            tbl_id = DsEthMep_t;
            if(IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
            {
                mep_block_id = blk_id;
                mep_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 0);
            }
        }

        if(ma_block_id == -1)
        {
            tbl_id = DsMa_t;
            if(IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
            {
                ma_block_id = blk_id;
                ma_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 0);
            }
        }

        if (namame_block_id == -1)
        {
            tbl_id = DsMaName_t;
            if(IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
            {
                namame_block_id = blk_id;
                maname_base = _cm_sim_cfg_kit_get_dynamic_table_base_in_block(tbl_id, blk_id, 0);
            }
        }

        if((ma_block_id != -1) && (mep_block_id != -1) && (namame_block_id != -1))
        {
            max = (maname_base > ma_base) ? maname_base :ma_base;
            max = (max > mep_base) ? max : mep_base;

            min = (maname_base < ma_base) ? maname_base :ma_base;
            min = (min < mep_base) ? min :mep_base;

            if((min != mep_base) && (max != mep_base))
            {
                middle = mep_base;
            }
            else if((min != ma_base) && (max != ma_base))
            {
                middle = ma_base;
            }
            else
            {
                middle = maname_base;
            }

            if(min == mep_base)
            {
                tlbs[0] = DsEthMep_t;
                fileds[0] = OamTblAddrCtl_MpBaseAddr_f;
            }
            else if(min == ma_base)
            {
                tlbs[0] = DsMa_t;
                fileds[0] = OamTblAddrCtl_MaBaseAddr_f;
            }
            else if(min == maname_base)
            {
                tlbs[0] = DsMaName_t;
                fileds[0] = OamTblAddrCtl_MaNameBaseAddr_f;
            }

            if(middle == mep_base)
            {
                tlbs[1] = DsEthMep_t;
                fileds[1] = OamTblAddrCtl_MpBaseAddr_f;
            }
            else if(middle == ma_base)
            {
                tlbs[1] = DsMa_t;
                fileds[1] = OamTblAddrCtl_MaBaseAddr_f;
            }
            else if(middle == maname_base)
            {
                tlbs[1] = DsMaName_t;
                fileds[1] = OamTblAddrCtl_MaNameBaseAddr_f;
            }

            if(max == mep_base)
            {
                tlbs[2] = DsEthMep_t;
                fileds[2] = OamTblAddrCtl_MpBaseAddr_f;
            }
            else if(max == ma_base)
            {
                tlbs[2] = DsMa_t;
                fileds[2] = OamTblAddrCtl_MaBaseAddr_f;
            }
            else if(max == maname_base)
            {
                tlbs[2] = DsMaName_t;
                fileds[2] = OamTblAddrCtl_MaNameBaseAddr_f;
            }

            break;
        }
    }

    if((0 == mep_base) || (0 == ma_base) || (0 == maname_base))
    {
        return DRV_E_INVALID_DYNIC_TBL_ALLOC;
    }

    entry_index = 0;
    /* DsMa/DsMaName/DsEthMep_t table base setting */
    for(idx = 0 ; idx < sizeof(tlbs)/sizeof(tlbs[0]); idx++)
    {
        tbl_id = tlbs[idx];
        field_id = fileds[idx];
        dynic_tbl_base = (entry_index >> 6);
        cmd = DRV_IOW(OamTblAddrCtl_t, field_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &dynic_tbl_base));
        entry_index += TABLE_MAX_INDEX(tbl_id)*TABLE_ENTRY_SIZE(tbl_id)/DRV_BYTES_PER_ENTRY;
    }

    return DRV_E_NONE;
}


/* because function _cm_sim_cfg_kit_init_dynamic_table_edram_bitmap_register cann't work if no RTL new struct,
   for passing compile , need remark this function */

static int32
_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(uint32 chip_id, uint8 mem_type,
                                            tbls_id_t table_id, uint32 *cfg_bitmap)
{
    #define GB_EDRAM_NUM 9
    uint32 j = 0;
    int32 i = 0;
    uint8 chipid_base = 0;
    uint16 alloc_tbl_edram_bitmap = 0;
    uint16 mem_type_edram_bitmap = 0;
#if 0
    char edram_block_info[256] = {0}, temp_str[10] = {0};
#endif

    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chipid_base));
    alloc_tbl_edram_bitmap = DYNAMIC_BITMAP(table_id);
    mem_type_edram_bitmap = dynic_table_related_edram_bitmap[mem_type];


    for (i = GB_EDRAM_NUM-1; i >= 0; i--)
    {
        if (IS_BIT_SET(alloc_tbl_edram_bitmap, i))
        {
            if (i < 0)
            {
                continue; /* jump 8th edram(from 0 - 8), because 8th edram fixed to used for DsStats */
            }

            if (IS_BIT_SET(mem_type_edram_bitmap, i))
            {
#if 0
                sal_sprintf(temp_str, "%d ", i);
                sal_strcat(edram_block_info, temp_str);
#endif
                SET_BIT(*cfg_bitmap, j);
                j++;
            }
            else
            {
                CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Dynimic tableId %d can not be allocated into EDRAM %d !!\n", table_id, i);
                CMODEL_DEBUG_OUT_INFO("Please check your dynic table's allocation profile!!\n");
            }
        }
        else
        {
            if (IS_BIT_SET(mem_type_edram_bitmap, i))
            {
                j++;
            }
        }
    }
#if 0
    if (cmodel_debug_on)
    {
        char table_name[128] = {0};
        drv_get_tbl_string_by_id(table_id, table_name);
        CMODEL_DEBUG_OUT_INFO("%-40s    0x%02x            0x%02x    %s\n", table_name, alloc_tbl_edram_bitmap, *cfg_bitmap, edram_block_info);
    }
#endif
    return DRV_E_NONE;
}


static int32
_cm_sim_cfg_kit_init_dynamic_table_edram_bitmap_register(uint32 chip_id)
{
/* ??? shenhg when V5.6 co-sim, function _cm_sim_cfg_kit_init_dynamic_table_edram_bitmap_register
    need update new dynamic_ds_edram_select_t struct, in V5.6 cmodel code,
    the dynamic_ds_edram_select_t is RTL 4.28 ds, can't used by new allocation */

    uint32 cmd = 0;
    uint32 cfg_edram_bitmap = 0;
    dynamic_ds_edram_select_t ds_edram_sel_bitmap;
    tbls_id_t tbl_id = MaxTblId_t;
    uint32 user_id_hash_key_entry_num = 0;
    uint32 user_id_hash_key_level1_enable = FALSE;

#if 0
    CMODEL_DEBUG_OUT_INFO("%-40s %-15s %-10s %-s\n", "DynimicTableName", "EdramBitMap", "CfgValue", "Block");
#endif

    /* DsUserIdHashKey dynamic control bit is not in DynamicDsEdramSelect_t, it is UserIdHashLookupCtl.level1HashEn
       if entry num of DsUserIdHashKey is more than 16K, hash level 1 is enable */
    tbl_id = DsUserIdDoubleVlanHashKey_t;

    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_get_entry_num_of_table(tbl_id, &user_id_hash_key_entry_num));

    if (user_id_hash_key_entry_num > DRV_MEMORY7_MAX_ENTRY_NUM)
    {
        user_id_hash_key_level1_enable = TRUE;
    }
    else
    {
        user_id_hash_key_level1_enable = FALSE;
    }

    cmd = DRV_IOW(UserIdHashLookupCtl_t, UserIdHashLookupCtl_Level1HashEn_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &user_id_hash_key_level1_enable));

    sal_memset(&ds_edram_sel_bitmap, 0, sizeof(ds_edram_sel_bitmap));

    /* -------- ReadMe, how to configure table DynamicDsEdramSelect_t info. ----------------- */
    /* cfgDsFwdEdramSel, the high bit means the start of eDram. For example, DsFwd max can cfg use eDram 3,4,5,6,
    if set cfgDsFwdEdramSel=4'b1000, means DsFwd locate in eDram3. */
    /*the following code can be optimize*/
    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                EDIT_SHARE_TABLE, DsL2EditEth4W_t, &cfg_edram_bitmap));
    /* DsL2Edit/DsL3Edit {edram1, edram4, edram5 } */
    ds_edram_sel_bitmap.cfg_ds_edit_edram_sel = cfg_edram_bitmap&0x7;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                FWD_SHARE_TABLE, DsFwd_t, &cfg_edram_bitmap));
    /* DsFwd  {edram0, edram3, edram4, edram5} */
    ds_edram_sel_bitmap.cfg_ds_fwd_edram_sel = cfg_edram_bitmap&0xF;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                FIB_HASH_AD_SHARE_TABLE, DsMac_t, &cfg_edram_bitmap));
    /* DsMac  {edram0, edram4, edram5, edram6} */
    ds_edram_sel_bitmap.cfg_ds_mac_ip_edram_sel = cfg_edram_bitmap&0xF;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                OAM_MEP_SHARE_TABLE, DsEthMep_t, &cfg_edram_bitmap));
    /* DsMep  {edram4, edram5, edram6} */
    ds_edram_sel_bitmap.cfg_ds_mep_edram_sel = cfg_edram_bitmap&0x7;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                MET_ENTRY_SHARE_TABLE, DsMetEntry_t, &cfg_edram_bitmap));
    /* DsMetEntry {edram0, edram4, edram5} */
    ds_edram_sel_bitmap.cfg_ds_met_edram_sel = cfg_edram_bitmap&0x7;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                MPLS_SHARE_TABLE, DsMpls_t, &cfg_edram_bitmap));
    /* DsMpls {edram1, edram2, edram4, edram5} */
    ds_edram_sel_bitmap.cfg_ds_mpls_edram_sel = cfg_edram_bitmap&0xF;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                NEXTHOP_SHARE_TABLE, DsNextHop4W_t, &cfg_edram_bitmap));
    /* DsNextHop {edram1, edram3, edram4, edram5} */
    ds_edram_sel_bitmap.cfg_ds_next_hop_edram_sel = cfg_edram_bitmap&0xF;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                OAM_LM_STAT, DsOamLmStats_t, &cfg_edram_bitmap));
    /* DsOamLm {edram8}, must in {edram9} */
    ds_edram_sel_bitmap.cfg_ds_lm_stats_edram_sel = cfg_edram_bitmap&0x1;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                STATS_SHARE_TABLE, DsStats_t, &cfg_edram_bitmap));
    /* DsStats {edram2, edram3, edram6, edram8} */
    ds_edram_sel_bitmap.cfg_ds_stats_edram_sel = cfg_edram_bitmap&0xF;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                USER_ID_HASH_AD_SHARE_TABLE, DsUserId_t, &cfg_edram_bitmap));
    /* DsUserId {edram3, edram4, edram5, edram6} */
    ds_edram_sel_bitmap.cfg_ds_user_id_edram_sel = cfg_edram_bitmap&0xF;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                LPM_HASH_KEY_SHARE_TABLE, DsLpmIpv4Hash8Key_t, &cfg_edram_bitmap));
    /* DsLpmHashKey    {edram3, edram6} */
    ds_edram_sel_bitmap.cfg_lpm_hash_edram_sel = cfg_edram_bitmap&0x3;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                LPM_LOOKUP_KEY_TABLE0, DsLpmLookupKey0_t, &cfg_edram_bitmap));
    /* DsLpmLookupKey0 {edram0, edram3} */
    /* lpmpipeLine0 and lpmPipeLine3 */
    ds_edram_sel_bitmap.cfg_lpm_pipe0_edram_sel = cfg_edram_bitmap&0x3;
    /* lpmpipeLine0 and lpmPipeLine3 */
    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                LPM_LOOKUP_KEY_TABLE3, DsLpmLookupKey3_t, &cfg_edram_bitmap));
    ds_edram_sel_bitmap.cfg_lpm_pipe3_edram_sel = cfg_edram_bitmap&0x3;

    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                LPM_LOOKUP_KEY_TABLE1, DsLpmLookupKey1_t, &cfg_edram_bitmap));
    /* DsLpmLookupKey1 {edram1, edram2} */
    /* lpmpipeLine1 and lpmPipeLine2 */
    ds_edram_sel_bitmap.cfg_lpm_pipe1_edram_sel = cfg_edram_bitmap&0x3;


    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                LPM_LOOKUP_KEY_TABLE2, DsLpmLookupKey2_t, &cfg_edram_bitmap));
    /* DsLpmLookupKey1 {edram1, edram2} */
    /* lpmpipeLine1 and lpmPipeLine2 */
    ds_edram_sel_bitmap.cfg_lpm_pipe2_edram_sel = cfg_edram_bitmap&0x3;

    /*DsOamLmStats_t*/
    cfg_edram_bitmap = 0;
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_dynimic_table_edram_bitmap_convert(chip_id,
                                OAM_LM_STAT, DsOamLmStats_t, &cfg_edram_bitmap));
    ds_edram_sel_bitmap.cfg_ds_lm_stats_edram_sel = cfg_edram_bitmap&0x1;

    cmd = DRV_IOW(DynamicDsEdramSelect_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ds_edram_sel_bitmap));

#if 1
    CMODEL_DEBUG_OUT_INFO("\n");
#endif

    return DRV_E_NONE;
}

static int32
_cm_sim_cfg_kit_init_dynamic_table_register(uint32 chip_id)
{
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_dynamic_table_base_register(chip_id));
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_dynamic_table_edram_bitmap_register(chip_id));

    return DRV_E_NONE;
}

static int32
_cm_sim_cfg_kit_init_oam_mp_drv(uint32 chip_id)
{

#if (SDK_WORK_PLATFORM == 0)
    int32  blk_id = 0;

    uint32 tbl_id       = DsEthMep_t;
    uint32 entry_num    = 0;
    uint32 hw_addr      = DS_MP_OFFSET;

    for (blk_id = 0; blk_id < MAX_DRV_BLOCK_NUM; blk_id++)
    {
        if (!IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
        {
            continue;
        }

        DYNAMIC_DATA_BASE(tbl_id, blk_id) = hw_addr + entry_num*4*DRV_BYTES_PER_WORD;
        DYNAMIC_DATA_BASE(DsEthRmep_t, blk_id) = hw_addr + entry_num*4*DRV_BYTES_PER_WORD;
        DYNAMIC_DATA_BASE(DsBfdMep_t, blk_id) = hw_addr + entry_num*4*DRV_BYTES_PER_WORD;
        DYNAMIC_DATA_BASE(DsBfdRmep_t, blk_id) = hw_addr + entry_num*4*DRV_BYTES_PER_WORD;

        entry_num += DYNAMIC_ENTRY_NUM(tbl_id, blk_id);
    }
#endif

    return DRV_E_NONE;
}


static int32
_cm_sim_cfg_kit_init_oam_udp_register(uint32 chip_id)
{
#define CHIP_CORE_FRE  450
    uint32 cmd = 0;
    oam_update_ctl_t oam_update_ctl;
    oam_ether_cci_ctl_t oam_ether_cci_ctl;

    sal_memset(&oam_update_ctl, 0, sizeof(oam_update_ctl));
    oam_update_ctl.ccm_min_ptr = 2;
    oam_update_ctl.oam_up_phy_num = TABLE_MAX_INDEX(DsEthMep_t) - 1 - oam_update_ctl.ccm_min_ptr;
    oam_update_ctl.upd_interval = (CHIP_CORE_FRE *833.3)/(oam_update_ctl.oam_up_phy_num - oam_update_ctl.ccm_min_ptr + 1) - 1;
    oam_update_ctl.ccm_max_ptr = (CHIP_CORE_FRE * 833.3)/(oam_update_ctl.upd_interval + 1) + oam_update_ctl.ccm_min_ptr - 1;
    cmd = DRV_IOW(OamUpdateCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_update_ctl));

    sal_memset(&oam_ether_cci_ctl, 0, sizeof(oam_ether_cci_ctl));
    oam_ether_cci_ctl.quater_cci2_interval =(oam_update_ctl.upd_interval + 1) * 3 *(oam_update_ctl.ccm_max_ptr - oam_update_ctl.ccm_min_ptr + 1);
    oam_ether_cci_ctl.relative_cci3_interval = 9;
    oam_ether_cci_ctl.relative_cci4_interval = 9;
    oam_ether_cci_ctl.relative_cci5_interval = 9;
    oam_ether_cci_ctl.relative_cci6_interval = 5;
    oam_ether_cci_ctl.relative_cci7_interval = 9;
    cmd = DRV_IOW(OamEtherCciCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_ether_cci_ctl));

    return DRV_E_NONE;
}

static int32
_cm_sim_cfg_kit_init_fdb_and_lpm_entry_num_register(uint32 chip_id)
{
#define INDEX_SHIFT 13
#define GRANULARITY (8*1024)
    uint32 macLevelBitmap = 0, lpm_hash_num_mode = 0;
    uint32 cmd = 0;
    dynamic_ds_fdb_hash_index_cam_t dynamic_ds_fdb_hash_cam;
    tbls_id_t tbl_id = MaxTblId_t;
    uint32 total_entry_num = 0, entry_num_in_block = 0, hw_base_in_block = 0;
    uint8 blk_id = 0;
    uint32 entry_offset_base = 0, hw_4w_8w_base_offset = 0, dynamic_base_address = 0;

    sal_memset(&dynamic_ds_fdb_hash_cam, 0, sizeof(dynamic_ds_fdb_hash_cam));

    /*  initial fdb associated register info */
    /*  default profile, fdb hash has 16+32K, set level-3 16K, level-4 32K */

    tbl_id = DsMacHashKey_t;

    if (TABLE_ENTRY_SIZE(tbl_id) == DRV_BYTES_PER_ENTRY)
    {
        dynamic_base_address = DRV_MEMORY0_BASE_4W;
    }
    else
    {
        dynamic_base_address = DRV_MEMORY0_BASE_8W;
    }
    /* address offset of table DsMacHashKey_t between DRV_MEMORY0_BASE_4W */
    hw_4w_8w_base_offset = dynamic_base_address - DRV_MEMORY0_BASE_4W;

    /* level1 hash */
    blk_id = 0;
    if (IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
    {
        SET_BIT(macLevelBitmap, blk_id);
    }
    entry_num_in_block = DYNAMIC_ENTRY_NUM(tbl_id, blk_id);
    dynamic_ds_fdb_hash_cam.mac_num0 = (total_entry_num >> INDEX_SHIFT);
    dynamic_ds_fdb_hash_cam.level0_bucket_num = entry_num_in_block ? (DRV_MEMORY0_MAX_ENTRY_NUM/entry_num_in_block -1):0;

    hw_base_in_block = DYNAMIC_DATA_BASE(tbl_id, blk_id);
    entry_offset_base = hw_base_in_block?((hw_base_in_block - hw_4w_8w_base_offset - DRV_MEMORY0_BASE_4W)/DRV_ADDR_BYTES_PER_ENTRY):0;
    if (entry_offset_base % GRANULARITY)
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Offset of table %s in block %d is %d, not equal the Granularity %d\n",
                                TABLE_NAME(tbl_id), blk_id, entry_offset_base, GRANULARITY);
        return DRV_E_INVALID_ALLOC_INFO;
    }
    dynamic_ds_fdb_hash_cam.level0_bucket_base = entry_offset_base/GRANULARITY;
    total_entry_num += entry_num_in_block;

    /* level2 hash */
    blk_id = 1;
    if (IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
    {
        SET_BIT(macLevelBitmap, blk_id);
    }
    entry_num_in_block = DYNAMIC_ENTRY_NUM(tbl_id, blk_id);
    dynamic_ds_fdb_hash_cam.mac_num1 = (total_entry_num >> INDEX_SHIFT);
    dynamic_ds_fdb_hash_cam.level1_bucket_num = entry_num_in_block ? (DRV_MEMORY1_MAX_ENTRY_NUM/entry_num_in_block -1):0;

    hw_base_in_block = DYNAMIC_DATA_BASE(tbl_id, blk_id);
    entry_offset_base = hw_base_in_block?((hw_base_in_block - hw_4w_8w_base_offset - DRV_MEMORY1_BASE_4W)/DRV_ADDR_BYTES_PER_ENTRY):0;
    if (entry_offset_base % GRANULARITY)
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Offset of table %s in block %d is %d, not equal the Granularity %d\n",
                                TABLE_NAME(tbl_id), blk_id, entry_offset_base, GRANULARITY);
        return DRV_E_INVALID_ALLOC_INFO;
    }
    dynamic_ds_fdb_hash_cam.level1_bucket_base = entry_offset_base/GRANULARITY;
    total_entry_num += entry_num_in_block;

    /* level3 hash */
    blk_id = 2;
    if (IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
    {
        SET_BIT(macLevelBitmap, blk_id);
    }
    entry_num_in_block = DYNAMIC_ENTRY_NUM(tbl_id, blk_id);
    dynamic_ds_fdb_hash_cam.mac_num2 = (total_entry_num >> INDEX_SHIFT);
    dynamic_ds_fdb_hash_cam.level2_bucket_num = entry_num_in_block ? (DRV_MEMORY2_MAX_ENTRY_NUM/entry_num_in_block -1):0;

    hw_base_in_block = DYNAMIC_DATA_BASE(tbl_id, blk_id);
    entry_offset_base = hw_base_in_block?((hw_base_in_block - hw_4w_8w_base_offset - DRV_MEMORY2_BASE_4W)/DRV_ADDR_BYTES_PER_ENTRY):0;
    if (entry_offset_base % GRANULARITY)
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Offset of table %s in block %d is %d, not equal the Granularity %d\n",
                                TABLE_NAME(tbl_id), blk_id, entry_offset_base, GRANULARITY);
        return DRV_E_INVALID_ALLOC_INFO;
    }
    dynamic_ds_fdb_hash_cam.level2_bucket_base = entry_offset_base/GRANULARITY;
    total_entry_num += entry_num_in_block;

    /* level4 hash */
    blk_id = 3;
    if (IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
    {
        SET_BIT(macLevelBitmap, blk_id);
    }
    entry_num_in_block = DYNAMIC_ENTRY_NUM(tbl_id, blk_id);
    dynamic_ds_fdb_hash_cam.mac_num3 = (total_entry_num >> INDEX_SHIFT);
    dynamic_ds_fdb_hash_cam.level3_bucket_num = entry_num_in_block ? (DRV_MEMORY3_MAX_ENTRY_NUM/entry_num_in_block -1):0;

    hw_base_in_block = DYNAMIC_DATA_BASE(tbl_id, blk_id);
    entry_offset_base = hw_base_in_block?((hw_base_in_block - hw_4w_8w_base_offset - DRV_MEMORY3_BASE_4W)/DRV_ADDR_BYTES_PER_ENTRY):0;
    if (entry_offset_base % GRANULARITY)
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Offset of table %s in block %d is %d, not equal the Granularity %d\n",
                                TABLE_NAME(tbl_id), blk_id, entry_offset_base, GRANULARITY);
        return DRV_E_INVALID_ALLOC_INFO;
    }
    dynamic_ds_fdb_hash_cam.level3_bucket_base = entry_offset_base/GRANULARITY;
    total_entry_num += entry_num_in_block;

    /* level5 hash */
    blk_id = 6;
    if (IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
    {
        SET_BIT(macLevelBitmap, blk_id);
    }
    entry_num_in_block = DYNAMIC_ENTRY_NUM(tbl_id, blk_id);
    dynamic_ds_fdb_hash_cam.mac_num4 = (total_entry_num >> INDEX_SHIFT);
    dynamic_ds_fdb_hash_cam.level4_bucket_num = entry_num_in_block ? (DRV_MEMORY6_MAX_ENTRY_NUM/entry_num_in_block -1):0;

    hw_base_in_block = DYNAMIC_DATA_BASE(tbl_id, blk_id);
    entry_offset_base = hw_base_in_block?((hw_base_in_block - hw_4w_8w_base_offset - DRV_MEMORY6_BASE_4W)/DRV_ADDR_BYTES_PER_ENTRY):0;
    if (entry_offset_base % GRANULARITY)
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Offset of table %s in block %d is %d, not equal the Granularity %d\n",
                                TABLE_NAME(tbl_id), blk_id, entry_offset_base, GRANULARITY);
        return DRV_E_INVALID_ALLOC_INFO;
    }
    dynamic_ds_fdb_hash_cam.level4_bucket_base = entry_offset_base/GRANULARITY;
    total_entry_num += entry_num_in_block;

    cmd = DRV_IOW(DynamicDsFdbHashCtl_t, DynamicDsFdbHashCtl_MacLevelBitmap_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &macLevelBitmap));

    cmd = DRV_IOW(DynamicDsFdbHashIndexCam_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &dynamic_ds_fdb_hash_cam));

#if 0
    /* macLevelBitmap 0,1 */
    SET_BIT(macLevelBitmap, 0);
    SET_BIT(macLevelBitmap, 1);
    cmd = DRV_IOW(FibEngineLookupCtl_t, FibEngineLookupCtl_MacLevelBitmap_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &macLevelBitmap));

    /* mac_numX =  ��(mac_num{0..X-1}) >> 10 */
    dynamic_ds_fdb_hash_cam.mac_num0 = 0;
    dynamic_ds_fdb_hash_cam.mac_num1 = (NUM_32K >> 10);

    /* if levelX_bucket_num = y, the level-X hash key max num = 32K >> y */
    /* the base indicated the base of level-X hash key in blockZ */
    dynamic_ds_fdb_hash_cam.level0_bucket_num = 0;
    dynamic_ds_fdb_hash_cam.level0_bucket_base = 0;
    dynamic_ds_fdb_hash_cam.level1_bucket_num = 1;
    dynamic_ds_fdb_hash_cam.level1_bucket_base = 0;
    cmd = DRV_IOW(DynamicDsFdbHashIndexCam_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &dynamic_ds_fdb_hash_cam));
#endif

    /* set lpm hash key register info */
    total_entry_num = 0;
    tbl_id = DsLpmIpv4Hash8Key_t;

    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_get_entry_num_of_table(tbl_id, &total_entry_num));

    /* FibEngineHashCtl.lpmHashNumMode[1:0]
       3  -->  4K lpm hash
       2  -->  8K lpm hash
       1  -->  16K lpm hash
       0  -->  32K lpm hash
    */
    switch (total_entry_num)
    {
        case NUM_16K:
            lpm_hash_num_mode = 1;
            break;

        case NUM_8K:
            lpm_hash_num_mode = 2;
            break;

        case NUM_4K:
            lpm_hash_num_mode = 3;
            break;

        default:
            lpm_hash_num_mode = 0;
            break;
    }

    cmd = DRV_IOW(FibEngineHashCtl_t, FibEngineHashCtl_LpmHashNumMode_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &lpm_hash_num_mode));

    return DRV_E_NONE;

}


static int32
_cm_sim_cfg_kit_init_register(uint32 chip_id)
{
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_tcam_userid_ctl_register(chip_id));
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_tcam_lookup_ctl_register(chip_id));
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_tcam_ctl_register(chip_id));
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_tcam_lookupresult_ctl_register(chip_id));

    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_default_entry_base_register(chip_id));
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_fdb_and_lpm_entry_num_register(chip_id));
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_dynamic_table_register(chip_id));
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_oam_udp_register(chip_id));
    DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_oam_mp_drv(chip_id));

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_malloc_dymanic_tbl_info
 * Purpose:    malloc dynamic table ext info
 * Parameters:
 * Input:      void
 * Output:     tbl_ext_info -- tbl ext info
 *             dynamic_mem_ext_content -- dynamic ext content
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static void cm_sim_cfg_kit_malloc_dymanic_tbl_info (tbls_ext_info_t **tbl_ext_info,
                                                            dynamic_mem_ext_content_t **dynamic_mem_ext_content)
{

    if (((*tbl_ext_info) != NULL) || ((*dynamic_mem_ext_content) != NULL))
    {
        SAL_LOG_FATAL("%s:%d ******** Parameter must use NULL ptr, or may be memory lack of program!!********\n",
                        __FUNCTION__, __LINE__);
        exit(1);
    }

    *tbl_ext_info = (tbls_ext_info_t*) sal_malloc(sizeof(tbls_ext_info_t));
    *dynamic_mem_ext_content = (dynamic_mem_ext_content_t *) sal_malloc(sizeof(dynamic_mem_ext_content_t));

    if (((*tbl_ext_info) == NULL) || ((*dynamic_mem_ext_content) == NULL))
    {
        SAL_LOG_FATAL("%s:%d ******** When allocate dynamic table info, no enough memory!!********\n",
                        __FUNCTION__, __LINE__);
        exit(1);
    }

    sal_memset(*tbl_ext_info, 0, sizeof(tbls_ext_info_t));
    sal_memset(*dynamic_mem_ext_content, 0, sizeof(dynamic_mem_ext_content_t));


    (*tbl_ext_info)->ext_content_type = EXT_INFO_TYPE_DYNAMIC;
    (*tbl_ext_info)->ptr_next = NULL;

    (*tbl_ext_info)->ptr_ext_content = (void *)(*dynamic_mem_ext_content);
    return;

}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_change_share_info_by_default_userid
 * Purpose:    update the default entry info ,and decrease the entry num in share list info
 * Parameters:
 * Input:      mem_id  -- share list id
 *             table_id -- table id in share list
 * Output:     void
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static void cm_sim_cfg_kit_change_share_info_by_default_userid(uint8 mem_id,
                                                                            uint8 block_num,
                                                                            uint32 entry_num_left,
                                                                            uint32 entry_num_sub,
                                                                            tbls_id_t table_id,
                                                                            dynamic_mem_ext_content_t *dynamic_mem_ext_content)
{
    uint32 hw_addr_base_offset = 0, hw_addr_offset = 0;
    uint32 start_index = 0, end_index = 0;
    uint32 total_index = 0;

    /* if DsTunnelIdDefault_t, the ds total index = 64 */
    if (table_id == DsTunnelIdDefault_t)
    {
        total_index = DS_TUNNEL_ID_DEFAULT_INDEX_NUM;
    }
    else if (table_id == DsUserIdIngressDefault_t)
    {
        total_index = DS_USER_ID_INGRESS_DEFAULT_INDEX_NUM;
    }
    else if (table_id == DsUserIdEgressDefault_t)
    {
        total_index = DS_USER_ID_EGRESS_DEFAULT_INDEX_NUM;
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("%s:%d There may be some mistake of function calling.\n",__FUNCTION__, __LINE__);
        return;
    }

    /* set bitmap info to default dynamic table */
    SET_BIT(dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_bitmap, block_num);
    hw_addr_base_offset = cm_sim_cfg_kit_get_addr_offset_for_index(block_num);
    hw_addr_offset = (hw_addr_base_offset + MEM_PROFILE_HW_OFFSET(mem_id, block_num) +
                        MEM_PROFILE_ENTRY_NUM(mem_id, block_num) - entry_num_sub)*DRV_ADDR_BYTES_PER_ENTRY;


    if (TABLE_ENTRY_SIZE(table_id) == (2*DRV_BYTES_PER_ENTRY))
    {
        dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_hw_data_base[block_num] =
                DRV_MEMORY0_BASE_8W + hw_addr_offset;
    }
    else
    {
        dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_hw_data_base[block_num] =
                DRV_MEMORY0_BASE_4W + hw_addr_offset;
    }

    /* allocated the default table info, include entry_num and start and end index */
    dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_num[block_num] = entry_num_sub;
    start_index = total_index - (entry_num_left + entry_num_sub)*DRV_BYTES_PER_ENTRY/TABLE_ENTRY_SIZE(table_id);
    dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_start_index[block_num] =
                start_index;
    end_index = total_index - (entry_num_left)*DRV_BYTES_PER_ENTRY/TABLE_ENTRY_SIZE(table_id) -1;
    dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_end_index[block_num] =
                end_index;

    /* sub the num of default entry to DsUserId share table */
    MEM_PROFILE_ENTRY_NUM(mem_id, block_num) -= entry_num_sub;
    /* if the entry in block_num is all allocated to default entry , should clear the bitmap */
    if(MEM_PROFILE_ENTRY_NUM(mem_id, block_num) == 0)
    {
        CLEAR_BIT(MEM_PROFILE_BITMAP(mem_id), block_num);
        MEM_PROFILE_HW_OFFSET(mem_id, block_num) = 0;
    }

    return;
}


/****************************************************************************
 * Name:       cm_sim_cfg_kit_deal_user_share_list
 * Purpose:    deal with of userid ad share list, allocated the default table info
 * Parameters:
 * Input:      mem_id  -- share list id
 *             table_id -- table id in share list
 * Output:     max_index_num -- return the allocated index num
 *             dynamic_mem_ext_content -- write the allocated info of block8/9
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32 cm_sim_cfg_kit_deal_user_share_list(uint8 mem_id)
{
    /* magic num 3 means: 0: DsUserIdIngressDefault_t, 1: DsUserIdEgressDefault_t, 2: DsTunnelIdDefault_t */
    tbls_ext_info_t *tbl_ext_info[3];
    dynamic_mem_ext_content_t *dynamic_mem_ext_content[3];
    int8 block_num = 0;
    uint32 user_id_ingress_default_entry_num_left = DS_USER_ID_INGRESS_DEFAULT_INDEX_NUM;
    uint32 user_id_egress_default_entry_num_left = DS_USER_ID_EGRESS_DEFAULT_INDEX_NUM;
    uint32 tunnel_id_default_entry_num_left = DS_TUNNEL_ID_DEFAULT_INDEX_NUM;
    uint32 entry_num_left = 0, entry_num_sub = 0;
    uint8 tbl_ptr_index = 0;
    uint32 table_id = 0;

    if (mem_id != USER_ID_HASH_AD_SHARE_TABLE)
    {
        CMODEL_DEBUG_OUT_INFO("%s:%d There may be some mistake of function calling.\n",__FUNCTION__, __LINE__);
        return DRV_E_CALL_WRONG_FUNCTION;
    }

    /* if share list is not allocated, can't initialize table info */
    if (MEM_PROFILE_INFO_PTR(mem_id) == NULL)
    {
        CMODEL_DEBUG_OUT_INFO("%s:%d There are no memory allocation profile info of user id share list",__FUNCTION__, __LINE__);
        exit(1);
    }

    TABLE_MAX_INDEX(DsUserIdIngressDefault_t) = DS_USER_ID_INGRESS_DEFAULT_INDEX_NUM;
    TABLE_MAX_INDEX(DsUserIdEgressDefault_t) = DS_USER_ID_EGRESS_DEFAULT_INDEX_NUM;
    TABLE_MAX_INDEX(DsTunnelIdDefault_t) = DS_TUNNEL_ID_DEFAULT_INDEX_NUM;

    for (tbl_ptr_index = 0; tbl_ptr_index < 3; tbl_ptr_index++)
    {
        tbl_ext_info[tbl_ptr_index] = NULL;
        dynamic_mem_ext_content[tbl_ptr_index] = NULL;
        cm_sim_cfg_kit_malloc_dymanic_tbl_info(&tbl_ext_info[tbl_ptr_index], &dynamic_mem_ext_content[tbl_ptr_index]);

        dynamic_mem_ext_content[tbl_ptr_index]->dynamic_access_mode = DYNAMIC_DEFAULT;
    }

    for (block_num = MAX_MEMORY_BLOCK_NUM; block_num >= 0 ; block_num--)
    {
        /* if share list is no info in the block ,continue */
        if ((!IS_BIT_SET(MEM_PROFILE_BITMAP(mem_id), block_num))
             || (MEM_PROFILE_ENTRY_NUM(mem_id, block_num) == 0))
        {
            continue;
        }

        /* allocated the tunnel id default first */
        if (tunnel_id_default_entry_num_left != 0)
        {
            if (MEM_PROFILE_ENTRY_NUM(mem_id, block_num) == 0)
            {
                continue;
            }

            tbl_ptr_index = 2;
            table_id = DsTunnelIdDefault_t;

            entry_num_left = tunnel_id_default_entry_num_left*TABLE_ENTRY_SIZE(table_id)/DRV_BYTES_PER_ENTRY;
            /* if the entry num in block is more than left entry num, allocated all left entry */
            if (MEM_PROFILE_ENTRY_NUM(mem_id, block_num) >= entry_num_left)
            {
                entry_num_sub = entry_num_left;
                tunnel_id_default_entry_num_left -= (entry_num_sub*DRV_BYTES_PER_ENTRY/TABLE_ENTRY_SIZE(table_id));
                entry_num_left -= entry_num_sub;
                cm_sim_cfg_kit_change_share_info_by_default_userid(mem_id, block_num, entry_num_left, entry_num_sub,
                                                                    table_id, dynamic_mem_ext_content[tbl_ptr_index]);
            }
            else
            {
                /* if the entry num in block is less than left entry, allocated the entry num in this block,
                   update the left entry num, continue to next block */
                entry_num_sub = MEM_PROFILE_ENTRY_NUM(mem_id, block_num);
                tunnel_id_default_entry_num_left -= (entry_num_sub*DRV_BYTES_PER_ENTRY/TABLE_ENTRY_SIZE(table_id));
                entry_num_left -= entry_num_sub;
                cm_sim_cfg_kit_change_share_info_by_default_userid(mem_id, block_num, entry_num_left, entry_num_sub,
                                                                    table_id, dynamic_mem_ext_content[tbl_ptr_index]);

                /* if the memory block is less than entry_num_left, need use next block info, so continue */
                continue;
            }

        }

        if (user_id_egress_default_entry_num_left != 0)
        {
            if (MEM_PROFILE_ENTRY_NUM(mem_id, block_num) == 0)
            {
                continue;
            }

            tbl_ptr_index = 1;
            table_id = DsUserIdEgressDefault_t;

            entry_num_left = user_id_egress_default_entry_num_left*TABLE_ENTRY_SIZE(table_id)/DRV_BYTES_PER_ENTRY;
            if (MEM_PROFILE_ENTRY_NUM(mem_id, block_num) >= entry_num_left)
            {
                entry_num_sub = entry_num_left;
                user_id_egress_default_entry_num_left -= (entry_num_sub*DRV_BYTES_PER_ENTRY/TABLE_ENTRY_SIZE(table_id));
                entry_num_left -= entry_num_sub;
                cm_sim_cfg_kit_change_share_info_by_default_userid(mem_id, block_num, entry_num_left, entry_num_sub,
                                                                    table_id, dynamic_mem_ext_content[tbl_ptr_index]);
            }
            else
            {
                entry_num_sub = MEM_PROFILE_ENTRY_NUM(mem_id, block_num);
                user_id_egress_default_entry_num_left -= (entry_num_sub*DRV_BYTES_PER_ENTRY/TABLE_ENTRY_SIZE(table_id));
                entry_num_left -= entry_num_sub;
                cm_sim_cfg_kit_change_share_info_by_default_userid(mem_id, block_num, entry_num_left, entry_num_sub,
                                                                    table_id, dynamic_mem_ext_content[tbl_ptr_index]);

                /* if the memory block is less than entry_num_left, need use next block info, so continue */
                continue;
            }

        }
        if (user_id_ingress_default_entry_num_left != 0)
        {
            if (MEM_PROFILE_ENTRY_NUM(mem_id, block_num) == 0)
            {
                continue;
            }

            tbl_ptr_index = 0;
            table_id = DsUserIdIngressDefault_t;

            entry_num_left = user_id_ingress_default_entry_num_left*TABLE_ENTRY_SIZE(table_id)/DRV_BYTES_PER_ENTRY;
            if (MEM_PROFILE_ENTRY_NUM(mem_id, block_num) >= entry_num_left)
            {
                entry_num_sub = entry_num_left;
                user_id_ingress_default_entry_num_left -= (entry_num_sub*DRV_BYTES_PER_ENTRY/TABLE_ENTRY_SIZE(table_id));
                entry_num_left -= entry_num_sub;
                cm_sim_cfg_kit_change_share_info_by_default_userid(mem_id, block_num, entry_num_left, entry_num_sub,
                                                                    table_id, dynamic_mem_ext_content[tbl_ptr_index]);
            }
            else
            {
                entry_num_sub = MEM_PROFILE_ENTRY_NUM(mem_id, block_num);
                user_id_ingress_default_entry_num_left -= (entry_num_sub*DRV_BYTES_PER_ENTRY/TABLE_ENTRY_SIZE(table_id));
                entry_num_left -= entry_num_sub;
                cm_sim_cfg_kit_change_share_info_by_default_userid(mem_id, block_num, entry_num_left, entry_num_sub,
                                                                    table_id, dynamic_mem_ext_content[tbl_ptr_index]);

                /* if the memory block is less than entry_num_left, need use next block info, so continue */
                continue;
            }

        }

    }

    if ((tunnel_id_default_entry_num_left != 0) || (user_id_egress_default_entry_num_left != 0)
        || (user_id_ingress_default_entry_num_left != 0))
    {
        CMODEL_DEBUG_OUT_INFO("%s:%d There are no enough memory allocated to user id share list"
                                "less than default entry %d\n",__FUNCTION__, __LINE__,
                                (DS_USER_ID_INGRESS_DEFAULT_INDEX_NUM+DS_USER_ID_EGRESS_DEFAULT_INDEX_NUM+DS_TUNNEL_ID_DEFAULT_INDEX_NUM));
        exit(1);
    }

    TABLE_EXT_INFO_PTR(DsUserIdIngressDefault_t) = tbl_ext_info[0];
    TABLE_EXT_INFO_PTR(DsUserIdEgressDefault_t) = tbl_ext_info[1];
    TABLE_EXT_INFO_PTR(DsTunnelIdDefault_t) = tbl_ext_info[2];

    return DRV_E_NONE;

}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_allocate_special_tbl_info
 * Purpose:    allocated memory8 and memory 9 info, special for allocating DsStats and DsOamLmStats,
               the content in memory8 and memory9 will has the smaller index
 * Parameters:
 * Input:      mem_id  -- share list id
 *             table_id -- table id in share list
 * Output:     max_index_num -- return the allocated index num
 *             dynamic_mem_ext_content -- write the allocated info of block8/9
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static void cm_sim_cfg_kit_allocate_special_tbl_info(uint8 mem_id, uint32 table_id, uint32 *max_index_num,
                                                           dynamic_mem_ext_content_t *dynamic_mem_ext_content)
{
    uint8 block_num = 0;
    /*
    uint8 oam_lm_stats_num = 0, oam_lm_stats_static_tbl_index = 0;
    */
    uint32 hw_addr_offset = 0, hw_addr_base_offset;
    /*
    tbls_id_t oam_stats_static_tbl_id = MaxTblId_t;
    */

    if (TABLE_MAX_INDEX(table_id) != 0)
    {
        CMODEL_DEBUG_OUT_INFO("%s:%d table %s has been allocated\n",__FUNCTION__, __LINE__, TABLE_NAME(table_id));
        return ;
    }

    if (mem_id == OAM_LM_STAT)
    {
#if 0
        /* should add the static DsOamLmStats0~1 info to dynamic table DsOamLmStats */
        /* add the static DsOamLmStats0 info to DsOamLmStats */
        for (oam_lm_stats_static_tbl_index = 0; oam_lm_stats_static_tbl_index < LM_EXT_BLOCK_NUM; oam_lm_stats_static_tbl_index++)
        {
            switch (oam_lm_stats_static_tbl_index)
            {
                case 0:
                    oam_stats_static_tbl_id = DsOamLmStats0_t;
                    break;

                case 1:
                    oam_stats_static_tbl_id = DsOamLmStats1_t;
                    break;

                default:
                    break;
            }

            block_num = MAX_MEMORY_BLOCK_NUM + (oam_lm_stats_num++);
            SET_BIT(dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_bitmap, block_num);
            dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_hw_data_base[block_num] = TABLE_DATA_BASE(oam_stats_static_tbl_id);

            dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_num[block_num] =
                                        TABLE_MAX_INDEX(oam_stats_static_tbl_id)*TABLE_ENTRY_SIZE(oam_stats_static_tbl_id)/DRV_BYTES_PER_ENTRY;

            dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_start_index[block_num] =
                                        *max_index_num;
            *max_index_num += TABLE_MAX_INDEX(oam_stats_static_tbl_id);
            dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_end_index[block_num] =
                                        *max_index_num -1;

        }
#endif
    }
    else if ((mem_id == USER_ID_HASH_KEY_SHARE_TABLE))
    {
        block_num = 7;

        /* if share list is no info in the block ,continue */
        if (!IS_BIT_SET(MEM_PROFILE_BITMAP(mem_id), block_num))
        {
            return ;
        }

        hw_addr_base_offset = cm_sim_cfg_kit_get_addr_offset_for_index(block_num);
        hw_addr_offset = (hw_addr_base_offset + MEM_PROFILE_HW_OFFSET(mem_id, block_num))*DRV_ADDR_BYTES_PER_ENTRY;

        if (TABLE_ENTRY_SIZE(table_id) == (DRV_BYTES_PER_ENTRY))
        {
            dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_hw_data_base[block_num] =
                    DRV_MEMORY0_BASE_4W + hw_addr_offset;
        }
        else
        {
            dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_hw_data_base[block_num] =
                    DRV_MEMORY0_BASE_8W + hw_addr_offset;
        }

        dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_num[block_num] =
            MEM_PROFILE_ENTRY_NUM(mem_id, block_num);

        dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_start_index[block_num] = *max_index_num;

        if (MEM_PROFILE_ACCESS_MODE_FLAG(mem_id))
        {
            /* always 3w address for 4w/8w care table */
            *max_index_num += (MEM_PROFILE_ENTRY_NUM(mem_id, block_num));
        }
        else
        {
            *max_index_num += (MEM_PROFILE_ENTRY_NUM(mem_id, block_num))*DRV_BYTES_PER_ENTRY/TABLE_ENTRY_SIZE(table_id);
        }

        dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_end_index[block_num] = (*max_index_num - 1);

    }
    else
    {
        /* not the special table */
    }

    return;

}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_allocate_tbl_info
 * Purpose:    allocated table info according the share list profile info
 * Parameters:
 * Input:      mem_id  -- share list id
 *             table_id -- table id in share list
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32 cm_sim_cfg_kit_allocate_tbl_info(uint8 mem_id, uint32 table_id)
{
    tbls_ext_info_t *tbl_ext_info = NULL;
    dynamic_mem_ext_content_t *dynamic_mem_ext_content = NULL;
    uint8 block_num = 0;
    uint32 hw_addr_offset = 0, hw_addr_base_offset = 0;
    uint32 max_index_num = 0;

    if (TABLE_MAX_INDEX(table_id) != 0)
    {
        CMODEL_DEBUG_OUT_INFO("%s:%d table %s has been allocated\n",__FUNCTION__, __LINE__, TABLE_NAME(table_id));
        return DRV_E_NONE;
    }

    cm_sim_cfg_kit_malloc_dymanic_tbl_info(&tbl_ext_info, &dynamic_mem_ext_content);

    dynamic_mem_ext_content->dynamic_access_mode = DYNAMIC_DEFAULT;
    /* when table in share list has different entry_size , should set access mode is 4W or 8W for driver*/
    if (MEM_PROFILE_ACCESS_MODE_FLAG(mem_id))
    {
        if (TABLE_ENTRY_SIZE(table_id) == (2*DRV_BYTES_PER_ENTRY))
        {
            dynamic_mem_ext_content->dynamic_access_mode = DYNAMIC_8W_MODE;
        }
        else if (TABLE_ENTRY_SIZE(table_id) == DRV_BYTES_PER_ENTRY)
        {
            dynamic_mem_ext_content->dynamic_access_mode = DYNAMIC_4W_MODE;
        }
    }

    dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_bitmap = MEM_PROFILE_BITMAP(mem_id);

    /* special index of DsUserIdHashKey and DsLm, DsUserIdHashKey in memory7, DsLm in memory8 use the small index */
    cm_sim_cfg_kit_allocate_special_tbl_info(mem_id, table_id, &max_index_num, dynamic_mem_ext_content);

    /* except DsLm, DsUserIdHashKey other share list table only access block0~6 and 8 */
    for (block_num = 0; block_num < (MAX_MEMORY_BLOCK_NUM); block_num++)
    {

        if (block_num == 7)
        {
            /* block 7 is only used by DsUserIdHashKey, can't used by other table */
            continue;
        }

        /* if share list is no info in the block ,continue */
        if (!IS_BIT_SET(MEM_PROFILE_BITMAP(mem_id), block_num))
        {
            continue;
        }
        hw_addr_base_offset = cm_sim_cfg_kit_get_addr_offset_for_index(block_num);
        hw_addr_offset = (hw_addr_base_offset + MEM_PROFILE_HW_OFFSET(mem_id, block_num))*DRV_ADDR_BYTES_PER_ENTRY;

        if (TABLE_ENTRY_SIZE(table_id) == (DRV_BYTES_PER_ENTRY))
        {
            dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_hw_data_base[block_num] =
                    DRV_MEMORY0_BASE_4W + hw_addr_offset;
        }
        else
        {
            dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_hw_data_base[block_num] =
                    DRV_MEMORY0_BASE_8W + hw_addr_offset;
        }

        dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_num[block_num] =
            MEM_PROFILE_ENTRY_NUM(mem_id, block_num);

        dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_start_index[block_num] = max_index_num;

        if (MEM_PROFILE_ACCESS_MODE_FLAG(mem_id))
        {
            /* always 3w address for 4w/8w care table */
            max_index_num += (MEM_PROFILE_ENTRY_NUM(mem_id, block_num));
        }
        else
        {
            max_index_num += (MEM_PROFILE_ENTRY_NUM(mem_id, block_num))*DRV_BYTES_PER_ENTRY/TABLE_ENTRY_SIZE(table_id);
        }

        dynamic_mem_ext_content->dynamic_mem_allocate_info.dynamic_mem_entry_end_index[block_num] = (max_index_num - 1);

    }

    /* assign the info to driver */
    TABLE_MAX_INDEX(table_id) = max_index_num;
    TABLE_EXT_INFO_PTR(table_id) = tbl_ext_info;
    tbl_ext_info = NULL;
    return DRV_E_NONE;

}

/****************************************************************************
 * Name:       cm_sim_clear_mem_profile_malloc_info
 * Purpose:    release memory profile malloc info
 * Parameters:
 * Input:      mem_profile_index  -- mem profile index
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static void cm_sim_release_mem_profile_malloc_info(void)
{
    uint32 mem_id = 0;

    for (mem_id = 0; mem_id < MAX_SRAM_SHARE_MEM_ID; mem_id++)
    {
        if (MEM_PROFILE_INFO_PTR(mem_id) != NULL)
        {
            sal_free(MEM_PROFILE_INFO_PTR(mem_id));
            MEM_PROFILE_INFO_PTR(mem_id) = NULL;
        }
    }
}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_allocate_check_profile_info
 * Purpose:    check if the memory profile is right
 * Parameters:
 * Input:      mem_profile_index  -- mem profile index
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32 cm_sim_cfg_kit_allocate_check_profile_info(void)
{
    uint8 share_mem_table_index = 0, tmp_share_mem_table_index = 0;
    uint8 block_record_index = 0;
    uint8 block_num = 0;
    uint32 block_allocated_entry_num[MAX_MEMORY_BLOCK_NUM] = {0};
    cm_block_allocated_record_t block_allocated_record[MAX_SHARE_TABLE_IN_ONE_MEMORY_BLOCK]; /* record allocated index in block */
    uint8 block_allocated_record_num = 0;
    uint32 min_record_num = 0, max_record_num = 0;

    sal_memset(block_allocated_entry_num, 0, sizeof(block_allocated_entry_num));
    sal_memset(block_allocated_record, 0, sizeof(block_allocated_record));

    for (block_num = 0; block_num < MAX_MEMORY_BLOCK_NUM; block_num++)
    {
        /* for each block, clear the block_allocated_record info */
        sal_memset(block_allocated_record, 0, sizeof(block_allocated_record));
        block_allocated_record_num = 0;
        for (share_mem_table_index = 0; share_mem_table_index < MAX_SRAM_SHARE_MEM_ID; share_mem_table_index++)
        {
            if (MEM_PROFILE_INFO_PTR(share_mem_table_index) == NULL)
            {

                CMODEL_DEBUG_OUT_INFO("Share list %d is not allocated in profile.\n", share_mem_table_index);
                continue;
            }

            /* share list is not in this block, continue */
            if(!IS_BIT_SET(MEM_PROFILE_BITMAP(share_mem_table_index), block_num))
            {
                continue;
            }

            /* if share list is same of checked share list, continue*/
            if (MEM_PROFILE_CHKED_FLG(share_mem_table_index, block_num))
            {
                continue;
            }

            /* check the following share list, examine if other share list has same block info of this share list,
               and examine that in the same block, if there are conflict index between different share list */
            for(tmp_share_mem_table_index = (share_mem_table_index + 1);
                    tmp_share_mem_table_index < MAX_SRAM_SHARE_MEM_ID;
                    tmp_share_mem_table_index++)
            {
                if (MEM_PROFILE_INFO_PTR(share_mem_table_index) == NULL)
                {
                    CMODEL_DEBUG_OUT_INFO("Share list %d is not allocated in profile.\n", share_mem_table_index);

                    continue;
                }
                /* share list is not in this block, continue */
                if(!IS_BIT_SET(MEM_PROFILE_BITMAP(share_mem_table_index), block_num))
                {
                    continue;
                }
                /* exam if index in following share list is conflict of all allocated index */
                for(block_record_index = 0; block_record_index < block_allocated_record_num; block_record_index++)
                {
                    min_record_num = block_allocated_record[block_record_index].min_allocated_num;
                    max_record_num = block_allocated_record[block_record_index].max_allocated_num;

                    /* if there are conflict index , output the debug log, ans exit */
                    if (((MEM_PROFILE_MIN_ENTRY_INDEX(tmp_share_mem_table_index, block_num) > min_record_num)
                            &&(MEM_PROFILE_MIN_ENTRY_INDEX(tmp_share_mem_table_index, block_num) <= max_record_num))
                        ||((MEM_PROFILE_MAX_ENTRY_INDEX(tmp_share_mem_table_index, block_num) >= min_record_num)
                            &&(MEM_PROFILE_MAX_ENTRY_INDEX(tmp_share_mem_table_index, block_num) < max_record_num)))
                    {
                        CMODEL_DEBUG_OUT_INFO("******* mem allocation may be some mistake **********\n");
                        CMODEL_DEBUG_OUT_INFO("allocated resource confilt of share list num = %d and num = %d in block %d\n",
                                            tmp_share_mem_table_index, share_mem_table_index, block_num);
                        exit(1);
                    }
                    /* if there are same block info , set the check flg, avoid to do second check */
                    if ((MEM_PROFILE_MIN_ENTRY_INDEX(tmp_share_mem_table_index, block_num) == min_record_num)
                        &&(MEM_PROFILE_MIN_ENTRY_INDEX(tmp_share_mem_table_index, block_num) == max_record_num))
                    {
                        MEM_PROFILE_CHKED_FLG(tmp_share_mem_table_index, block_num) = TRUE;
                        break;
                    }

                }

            }

            /* record the entry num of this share list */
            block_allocated_entry_num[block_num] += MEM_PROFILE_ENTRY_NUM(share_mem_table_index, block_num);
            /* store the max and min index info of this share list, used for examine if the following other share list index is conflict */
            block_allocated_record[block_allocated_record_num].max_allocated_num = MEM_PROFILE_MAX_ENTRY_INDEX(share_mem_table_index, block_num);
            block_allocated_record[block_allocated_record_num].min_allocated_num = MEM_PROFILE_MIN_ENTRY_INDEX(share_mem_table_index, block_num);
            block_allocated_record_num++;

        }

    }

    /* count the allocated entry num of every block, and compare with the max entry num of this block,
       if the allocated  entry num is not equal the max entry num of this block, it's flagrant */
    for (block_num = 0; block_num < MAX_MEMORY_BLOCK_NUM; block_num++)
    {
        if(block_allocated_entry_num[block_num] < mem_chip_info[block_num].max_mem_entry_num)
        {
            CMODEL_DEBUG_OUT_INFO("**** Warning: allocated entry num %d is less then max entry num %d\n",
                                    block_allocated_entry_num[block_num], mem_chip_info[block_num].max_mem_entry_num);
            return DRV_E_INVALID_ALLOC_INFO;
        }

        if(block_allocated_entry_num[block_num] > mem_chip_info[block_num].max_mem_entry_num)
        {
            CMODEL_DEBUG_OUT_INFO("**** Warning: allocated entry num %d is more then max entry num %d\n",
                                    block_allocated_entry_num[block_num], mem_chip_info[block_num].max_mem_entry_num);
            return DRV_E_INVALID_ALLOC_INFO;
        }

    }
    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       cm_sim_cfg_kit_init_mem_allocation_profile
 * Purpose:    init configure for mem profile for all dynamic tables
               set the memory profile info to every share list
 * Parameters:
 * Input:      mem_profile_index  -- mem profile index
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32 cm_sim_cfg_kit_init_mem_allocation_profile(cm_mem_profile_t mem_profile_index)
{
    uint8 chip_id_offset = 0, chip_num = 0;
    uint8 chip_id = 0;
    sram_share_mem_id_t sram_share_mem_id = 0;
    uint8 mem_block_num = 0;
   // cmodel_tbl_info_t* tbl_info = NULL;

    DRV_IF_ERROR_RETURN(drv_get_chipnum(&chip_num));
    for(chip_id_offset=0; chip_id_offset<chip_num; chip_id_offset++)
    {
        switch(mem_profile_index)
        {
            case CM_MEM_PROFILE_OAM_PERF: /*Default*/
                /*Share tables*/

                /* ??? shenhg_mem malloc value should be free when mem allocation process end */
                /* --> function  cm_sim_release_mem_profile_malloc_info */

                /* memory profile info is not flexible, if there is free time,
                   it should be changed to get profile info by cli or config in future , so tu~~*/

                /*LPM+MAC AD*/
                sram_share_mem_id = FIB_HASH_AD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x11; /*Memory0,4*/
                mem_block_num = 0;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_32K;
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_LPM_LOOKUP_KEY1*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE1;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;
                /*DS_LPM_LOOKUP_KEY2*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE2;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_8K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*DS_MPLS */
                sram_share_mem_id = MPLS_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /* check for all NEXTHOP_SHARE_TABLE*/
                sram_share_mem_id = NEXTHOP_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x22; /*Memory1,5*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*DS_LPM_LOOKUP_KEY0*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE0;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x8; /*Memory3*/
                mem_block_num = 3;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;
                /*DS_LPM_LOOKUP_KEY3*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE3;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x8; /*Memory3*/
                mem_block_num = 3;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*MAC hash key*/
                sram_share_mem_id = FIB_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0xC; /*Memory2,3*/
                mem_block_num = 2;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_32K;
                mem_block_num = 3;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_FWD*/
                sram_share_mem_id = FWD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x10; /*Memory4*/
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*DS_MET_ENTRY*/
                sram_share_mem_id = MET_ENTRY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x10; /*Memory4*/
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;


                /* check for all L2_EDIT_SHARE_TABLE*/
                sram_share_mem_id = EDIT_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_4K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /* DsUserId/TunnelId in same memory chip */
                sram_share_mem_id = USER_ID_HASH_AD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_8K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_12K;

                /* DsOamchan */
                sram_share_mem_id = OAM_HASH_CHAN_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_20K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*DS_MA*/
                sram_share_mem_id = MA_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                /*DS_MA_NAME*/
                sram_share_mem_id = MA_NAME_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_26K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                /* check for all OAM_MEP_SHARE_TABLE, not include DsMa/DsMaName */
                sram_share_mem_id = OAM_MEP_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x60; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_28K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                mem_block_num = 6;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*LPM hash key*/
                sram_share_mem_id = LPM_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x40; /*Memory6*/
                mem_block_num = 6;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_4K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_12K;

                /* user id hash/tunnel id hash/oma hash keys in same memeory chips*/
                sram_share_mem_id = USER_ID_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x80; /*Memory7*/
                mem_block_num = 7;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_STATS*/
                sram_share_mem_id = STATS_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x100; /*Memory8*/
                mem_block_num = 8;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*DS_OAM_LM_STAT */
                /* DsOamLmStat must initilized even if there is no dynamic table to DsOamLmStats,
                   because must add static DsOamLmStats0~X info to DsOamLmStats */
                /* no dynamic info of DsOamLmStats in default profile */
                sram_share_mem_id = OAM_LM_STAT;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x100;
                mem_block_num = 8;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_8K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                break;

            case CM_MEM_PROFILE_DEFAULT: /*Default*/
                /*Share tables*/

                /* ??? shenhg_mem malloc value should be free when mem allocation process end */
                /* --> function  cm_sim_release_mem_profile_malloc_info */

                /* memory profile info is not flexible, if there is free time,
                   it should be changed to get profile info by cli or config in future , so tu~~*/

                /*LPM+MAC AD*/
                sram_share_mem_id = FIB_HASH_AD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x11; /*Memory0,4*/
                mem_block_num = 0;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_32K;
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_LPM_LOOKUP_KEY1*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE1;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;
                /*DS_LPM_LOOKUP_KEY2*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE2;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_8K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*DS_MPLS */
                sram_share_mem_id = MPLS_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /* check for all NEXTHOP_SHARE_TABLE*/
                sram_share_mem_id = NEXTHOP_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x22; /*Memory1,5*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*DS_LPM_LOOKUP_KEY0*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE0;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x8; /*Memory3*/
                mem_block_num = 3;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;
                /*DS_LPM_LOOKUP_KEY3*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE3;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x8; /*Memory3*/
                mem_block_num = 3;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*MAC hash key*/
                sram_share_mem_id = FIB_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0xC; /*Memory2,3*/
                mem_block_num = 2;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_32K;
                mem_block_num = 3;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_FWD*/
                sram_share_mem_id = FWD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x10; /*Memory4*/
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*DS_MET_ENTRY*/
                sram_share_mem_id = MET_ENTRY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x10; /*Memory4*/
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /* check for all OAM_MEP_SHARE_TABLE, not include DsMa/DsMaName */
                sram_share_mem_id = OAM_MEP_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_4K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*DS_MA*/
                sram_share_mem_id = MA_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_8K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                /*DS_MA_NAME*/
                sram_share_mem_id = MA_NAME_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_10K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                /* check for all L2_EDIT_SHARE_TABLE*/
                sram_share_mem_id = EDIT_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_12K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /* DsUserId/TunnelId in same memory chip */
                sram_share_mem_id = USER_ID_HASH_AD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_14K;

                /* DsOamchan */
                sram_share_mem_id = OAM_HASH_CHAN_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_30K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                /*LPM hash key*/
                sram_share_mem_id = LPM_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x40; /*Memory6*/
                mem_block_num = 6;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /* user id hash/tunnel id hash/oma hash keys in same memeory chips*/
                sram_share_mem_id = USER_ID_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x80; /*Memory7*/
                mem_block_num = 7;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_STATS*/
                sram_share_mem_id = STATS_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x100; /*Memory8*/
                mem_block_num = 8;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*DS_OAM_LM_STAT */
                /* DsOamLmStat must initilized even if there is no dynamic table to DsOamLmStats,
                   because must add static DsOamLmStats0~X info to DsOamLmStats */
                /* no dynamic info of DsOamLmStats in default profile */
                sram_share_mem_id = OAM_LM_STAT;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x100;
                mem_block_num = 8;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_8K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;


                break;

            case CM_MEM_PROFILE_ENTERPRISE0: /*Enterpricse 0*/

                /* not enterprose0 profile, only bak of 5.1 profile,
                   DsMaName, DsMa and DsMep is all in block 5, but the address is not continuous */

                /*LPM+MAC AD*/
                sram_share_mem_id = FIB_HASH_AD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x11; /*Memory0,4*/
                mem_block_num = 0;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_32K;
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_LPM_LOOKUP_KEY1*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE1;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_MPLS */
                sram_share_mem_id = MPLS_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /* check for all NEXTHOP_SHARE_TABLE*/
                sram_share_mem_id = NEXTHOP_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x22; /*Memory1,5*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_4K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*DS_LPM_LOOKUP_KEY0*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE0;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x4; /*Memory2*/
                mem_block_num = 2;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*MAC hash key*/
                sram_share_mem_id = FIB_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0xC; /*Memory2,3*/
                mem_block_num = 2;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;
                mem_block_num = 3;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_32K;

                /*DS_FWD*/
                sram_share_mem_id = FWD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x10; /*Memory4*/
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*DS_MET_ENTRY*/
                sram_share_mem_id = MET_ENTRY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x10; /*Memory4*/
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /* check for all OAM_MEP_SHARE_TABLE, not include DsMa/DsMaName */
                sram_share_mem_id = OAM_MEP_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*DS_MA*/
                sram_share_mem_id = MA_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_8K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                /*DS_MA_NAME*/
                sram_share_mem_id = MA_NAME_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_10K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                /* check for all L2_EDIT_SHARE_TABLE*/
                sram_share_mem_id = EDIT_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_12K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /* DsUserId/TunnelId and Oamchan in same memory chip */
                sram_share_mem_id = USER_ID_HASH_AD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*LPM hash key*/
                sram_share_mem_id = LPM_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x40; /*Memory6*/
                mem_block_num = 6;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /* user id hash/tunnel id hash/oma hash keys in same memeory chips*/
                sram_share_mem_id = USER_ID_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x80; /*Memory7*/
                mem_block_num = 7;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_STATS*/
                sram_share_mem_id = STATS_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x100; /*Memory8*/
                mem_block_num = 8;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /* special manager to dsOamLmStatsX */

                break;
            case CM_MEM_PROFILE_ENTERPRISE1: /*Enterpricse 1*/

                /* test for SpecV5.9, DsOamLmStats include static table DsOamLmStats0~3 and dynamic block 8 2K info*/

                /*LPM+MAC AD*/
                sram_share_mem_id = FIB_HASH_AD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x11; /*Memory0,4*/
                mem_block_num = 0;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_32K;
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_LPM_LOOKUP_KEY1*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE1;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_MPLS */
                sram_share_mem_id = MPLS_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /* check for all NEXTHOP_SHARE_TABLE*/
                sram_share_mem_id = NEXTHOP_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x22; /*Memory1,5*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*DS_LPM_LOOKUP_KEY0*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE0;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x4; /*Memory2*/
                mem_block_num = 2;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*MAC hash key*/
                sram_share_mem_id = FIB_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0xC; /*Memory2,3*/
                mem_block_num = 2;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;
                mem_block_num = 3;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_32K;

                /*DS_FWD*/
                sram_share_mem_id = FWD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x10; /*Memory4*/
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*DS_MET_ENTRY*/
                sram_share_mem_id = MET_ENTRY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x10; /*Memory4*/
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /* check for all OAM_MEP_SHARE_TABLE, not include DsMa/DsMaName */
                sram_share_mem_id = OAM_MEP_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_4K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*DS_MA*/
                sram_share_mem_id = MA_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_8K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                /*DS_MA_NAME*/
                sram_share_mem_id = MA_NAME_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_10K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                /* check for all L2_EDIT_SHARE_TABLE*/
                sram_share_mem_id = EDIT_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_12K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /* DsUserId/TunnelId and Oamchan in same memory chip */
                sram_share_mem_id = USER_ID_HASH_AD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*LPM hash key*/
                sram_share_mem_id = LPM_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x40; /*Memory6*/
                mem_block_num = 6;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /* user id hash/tunnel id hash/oma hash keys in same memeory chips*/
                sram_share_mem_id = USER_ID_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x80; /*Memory7*/
                mem_block_num = 7;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /* test for SpecV5.9, DsOamLmStats include static table DsOamLmStats0~3 and dynamic block 8 2K info */
                /* DS_STATS has 14K, and DsOamLmStats has 2K */
                /*DS_STATS*/
                sram_share_mem_id = STATS_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x100; /*Memory8*/
                mem_block_num = 8;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_14K;

                /*DS_OAM_LM_STAT */
                /* DsOamLmStat must initilized even if there is no dynamic table to DsOamLmStats,
                   because must add static DsOamLmStats0~X info to DsOamLmStats */
                /* no dynamic info of DsOamLmStats in default profile */
                sram_share_mem_id = OAM_LM_STAT;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x100;/*Memory8*/
                mem_block_num = 8;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_14K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                break;
            case CM_MEM_PROFILE_ENTERPRISE2: /*Enterpricse 2*/
                break;
            case CM_MEM_PROFILE_ENTERPRISE3: /*Enterpricse 3*/
                break;
            case CM_MEM_PROFILE_ENTERPRISE4: /*Enterpricse 4*/
                break;
            case CM_MEM_PROFILE_ENTERPRISE5: /*Enterpricse 5*/
                break;
            case CM_MEM_PROFILE_ENTERPRISE6: /*Enterpricse 6*/
                break;

            case CM_MEM_PROFILE_METRO0: /*Metro 0*/
                /* add for independence l2 and l3Edit info for testing */

                /*LPM+MAC AD*/
                sram_share_mem_id = FIB_HASH_AD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x11; /*Memory0,4*/
                mem_block_num = 0;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_32K;
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_LPM_LOOKUP_KEY1*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE1;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_MPLS */
                sram_share_mem_id = MPLS_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x2; /*Memory1*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /* check for all NEXTHOP_SHARE_TABLE*/
                sram_share_mem_id = NEXTHOP_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x22; /*Memory1,5*/
                mem_block_num = 1;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_4K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*DS_LPM_LOOKUP_KEY0*/
                sram_share_mem_id = LPM_LOOKUP_KEY_TABLE0;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x4; /*Memory2*/
                mem_block_num = 2;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*MAC hash key*/
                sram_share_mem_id = FIB_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0xC; /*Memory2,3*/
                mem_block_num = 2;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;
                mem_block_num = 3;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_32K;

                /*DS_FWD*/
                sram_share_mem_id = FWD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x10; /*Memory4*/
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /*DS_MET_ENTRY*/
                sram_share_mem_id = MET_ENTRY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x10; /*Memory4*/
                mem_block_num = 4;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_24K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_8K;

                /* check for all OAM_MEP_SHARE_TABLE, not include DsMa/DsMaName */
                sram_share_mem_id = OAM_MEP_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;

                /*DS_MA*/
                sram_share_mem_id = MA_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_8K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;

                /*DS_MA_NAME*/
                sram_share_mem_id = MA_NAME_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_10K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_2K;
#if 0
                /* check for all L2_EDIT_SHARE_TABLE*/
                sram_share_mem_id = EDIT_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_12K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_4K;
#endif
                /* DsUserId/TunnelId and Oamchan in same memory chip */
                sram_share_mem_id = USER_ID_HASH_AD_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x20; /*Memory5*/
                mem_block_num = 5;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = NUM_16K;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*LPM hash key*/
                sram_share_mem_id = LPM_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x40; /*Memory6*/
                mem_block_num = 6;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /* user id hash/tunnel id hash/oma hash keys in same memeory chips*/
                sram_share_mem_id = USER_ID_HASH_KEY_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x80; /*Memory7*/
                mem_block_num = 7;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /*DS_STATS*/
                sram_share_mem_id = STATS_SHARE_TABLE;
                INITILIZE_MEM_PROFILE_INFO_PTR(sram_share_mem_id);
                MEM_PROFILE_BITMAP(sram_share_mem_id) = 0x100; /*Memory8*/
                mem_block_num = 8;
                MEM_PROFILE_HW_OFFSET(sram_share_mem_id, mem_block_num) = 0;
                MEM_PROFILE_ENTRY_NUM(sram_share_mem_id, mem_block_num) = NUM_16K;

                /* special manager to dsOamLmStatsX */

                break;
            case CM_MEM_PROFILE_METRO1: /*Metro 1*/
                break;
            case CM_MEM_PROFILE_METRO2: /*Metro 2*/
                break;
            case CM_MEM_PROFILE_METRO3: /*Metro 3*/
                break;
            case CM_MEM_PROFILE_METRO4: /*Metro 4*/
                break;
            case CM_MEM_PROFILE_METRO5: /*Metro 5*/
                break;

            default:
                return DRV_E_INVALID_PARAMETER;
            break;
        }
    }

    chip_id_offset = 0;
    //sram_info[chip_id_offset].mem_profile_index = mem_profile_index;

    /*set acl key lookup bitmap */
    drv_get_chipid_from_offset(chip_id_offset, &chip_id);

    DRV_IF_ERROR_RETURN(drv_set_acl_lookup_bitmap(chip_id, 0, 0x1));
    DRV_IF_ERROR_RETURN(drv_set_acl_lookup_bitmap(chip_id, 1, 0x2));
    DRV_IF_ERROR_RETURN(drv_set_acl_lookup_bitmap(chip_id, 2, 0x4));
    DRV_IF_ERROR_RETURN(drv_set_acl_lookup_bitmap(chip_id, 3, 0x8));

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       cm_sim_cfg_kit_is_tcam_ad_tbl
 * Purpose:    judge if the table is tcam ad
 * Parameters:
 * Input:      tbl_id -- table id
 * Output:     None
 * Return:     TRUE = table is tcam ad table.
 *             FALSE = table is not tcam ad table.
 * Note:       none.
 ****************************************************************************/
static int8 cm_sim_cfg_kit_is_tcam_ad_tbl(uint32 tbl_id)
{
    uint32 index = 0;
    uint32 len = mem_extern_tcam_ad_list.tbl_num;

    for (index = 0; index < len; index++)
    {
        if (tbl_id == mem_extern_tcam_ad_list.tbl_list[index])
        {
            return TRUE;
        }

    }

    return FALSE;
}

static int8 cm_sim_cfg_kit_is_lpm_tcam_ad_tbl(uint32 tbl_id)
{
    uint32 index = 0;
    uint32 len = sizeof(lpm_tcam_ad_share_table_list)/sizeof(lpm_tcam_ad_share_table_list[0]);

    for (index = 0; index < len; index++)
    {
        if (tbl_id == lpm_tcam_ad_share_table_list[index])
        {
            return TRUE;
        }

    }

    return FALSE;
}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_clear_no_allocated_tcam_key_tbl_malloc_info
 * Purpose:    clear the ext tcam key content info for tcam key if the tcam key is not allocated
 * Parameters:
 * Input:      void
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static void cm_sim_cfg_kit_clear_no_allocated_tcam_key_tbl_malloc_info(tbls_id_t tbl_id)
{
#if 0
    if (!CHK_TABLE_ID_VALID(tbl_id))
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! When clear no allocated tcam key table info ,table id is wrong, table id = %d.\n", tbl_id);
        exit(1);
    }

    if (TABLE_EXT_INFO_PTR(tbl_id) == NULL)
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! The ptr_ext_info of tcam table %d is NULL, there must be some memory allocated error\n", tbl_id);
        exit(1);
    }

    sal_free(TABLE_EXT_INFO_CONTENT_PTR(tbl_id));
    TABLE_EXT_INFO_CONTENT_PTR(tbl_id) = NULL;
#endif
}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_clear_no_allocated_tcam_key_tbl_malloc_info
 * Purpose:    clear the ext dynamic content info for tcam key if the tcam key is not allocated
 * Parameters:
 * Input:      void
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static void cm_sim_cfg_kit_clear_no_allocated_dynamic_tbl_malloc_info(tbls_id_t tbl_id)
{

    if (!CHK_TABLE_ID_VALID(tbl_id))
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! When clear no allocated dynamic table info ,table id is wrong, table id = %d.\n", tbl_id);
        exit(1);
    }

    if (TABLE_EXT_INFO_PTR(tbl_id) == NULL)
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! The ptr_ext_info of dynamic table %d is NULL, there must be some memory allocated error\n", tbl_id);
        exit(1);
    }

    sal_free(TABLE_EXT_INFO_CONTENT_PTR(tbl_id));
    TABLE_EXT_INFO_CONTENT_PTR(tbl_id) = NULL;


}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_clear_no_allocated_tbl_malloc_info
 * Purpose:    clear the tcam and dynamic table info if the table is not allocated
               because in the drv, th malloc info is used to judge the table is static table
               , tcam key or dynamic
 * Parameters:
 * Input:      void
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static void cm_sim_cfg_kit_clear_no_allocated_tbl_malloc_info(void)
{

    uint8 mem_id = 0;
    uint8 table_id_index = 0;
    tbls_id_t tbl_id;
    uint32 len = mem_extern_tcam_key_list.tbl_num;

    /* clear no allocated tcam key info */
    for (table_id_index = 0; table_id_index < len; table_id_index++)
    {
        tbl_id = mem_extern_tcam_key_list.tbl_list[table_id_index];

        if (TABLE_MAX_INDEX(tbl_id) != 0)
        {
            continue;
        }
        else
        {
            cm_sim_cfg_kit_clear_no_allocated_tcam_key_tbl_malloc_info(tbl_id);
        }
    }

    /* clear no allocated dynamic table info */
    for(mem_id=0; mem_id<MAX_SRAM_SHARE_MEM_ID; mem_id++)
    {

        for(table_id_index=0; table_id_index<sram_share_mem_info[mem_id].table_num; table_id_index++)
        {
            tbl_id = sram_share_mem_info[mem_id].p_share_mem_table_list[table_id_index];

            if (TABLE_MAX_INDEX(tbl_id) != 0)
            {
                continue;
            }
            else
            {
                cm_sim_cfg_kit_clear_no_allocated_dynamic_tbl_malloc_info(tbl_id);
            }
        }
    }
    return;

}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_set_share_list_access_flag
 * Purpose:    check if the share list has different entry size table,
               if has, set the access flag of this share list
 * Parameters:
 * Input:      mem_id -- share list id
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static void cm_sim_cfg_kit_set_share_list_access_flag(uint8 mem_id)
{
    uint32 table_id_index = 0;
    tbls_id_t tbl_id = 0;
    uint32 first_table_entry_size = 0;

    for (table_id_index = 0; table_id_index < sram_share_mem_info[mem_id].table_num; table_id_index++)
    {
        tbl_id = sram_share_mem_info[mem_id].p_share_mem_table_list[table_id_index];

        if (TABLE_ENTRY_SIZE(tbl_id) == 0)
        {
            continue;
        }

        if (first_table_entry_size == 0)
        {
            first_table_entry_size = TABLE_ENTRY_SIZE(tbl_id);
            continue;
        }
        /* if the entry size is different from the first table entry size,
            the share list is has tables of different entry size ,set the flag for setting access mode of table*/
        if (first_table_entry_size != TABLE_ENTRY_SIZE(tbl_id))
        {
            MEM_PROFILE_ACCESS_MODE_FLAG(mem_id) = TRUE;
            break;
        }
    }

    return;

}



/****************************************************************************
 * Name:       cm_sim_cfg_kit_do_memory_allocation
 * Purpose:    Do the memory allocation according the memory allocation profile.
 *             allocate share list info to every table
 * Parameters:
 * Input:      void
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32 cm_sim_cfg_kit_do_memory_allocation(void)
{
    uint32 table_id_index = 0;
    tbls_id_t table_id = 0;
//    uint8 chip_id_offset = 0;
    int32 ret = 0;
    uint8 mem_id = 0;

    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_allocate_check_profile_info());

    /* allocate share tables */
    for(mem_id=0; mem_id<MAX_SRAM_SHARE_MEM_ID; mem_id++)
    {

        if(MEM_PROFILE_INFO_PTR(mem_id) == NULL)
        {
            CMODEL_DEBUG_OUT_INFO("dynamic share list id = %d is empty.\n", mem_id);
            continue;
        }

        /* set access flag for set drv access mode */
        cm_sim_cfg_kit_set_share_list_access_flag(mem_id);

        /* because userId ad has the default entry, deal the default entry first */
        if (mem_id == USER_ID_HASH_AD_SHARE_TABLE)
        {
            ret = cm_sim_cfg_kit_deal_user_share_list(mem_id);
            if (ret < 0)
            {
                CMODEL_DEBUG_OUT_INFO("deal with of user id ad share list error.\n");
                return ret;
            }
        }

        /* allocated all table in one share list, all table in one share list have same allocated info */
        for(table_id_index=0; table_id_index<sram_share_mem_info[mem_id].table_num; table_id_index++)
        {
            table_id = sram_share_mem_info[mem_id].p_share_mem_table_list[table_id_index];

            DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_allocate_tbl_info(mem_id, table_id));
        }
    }

    cm_sim_cfg_kit_clear_no_allocated_tbl_malloc_info();


#if (SDK_WORK_PLATFORM == 1)
    DRV_IF_ERROR_RETURN(sram_model_allocate_sram_tbl_info());
#endif


    cm_sim_release_mem_profile_malloc_info();


    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       cm_sim_cfg_kit_allocate_process
 * Purpose:    Do the memory allocation according the memory allocation profile.
 *             Write the dynamic base and tcam associated registre info
 * Parameters:
 * Input:      void
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32 cm_sim_cfg_kit_allocate_process(void)
{

    uint8 chipid = 0;
    uint8 chip_num = 0;
    uint8 chip_id_base = 0;

    /* do memory allocation */
    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_do_memory_allocation());


    /* write allocation associated register */
    DRV_IF_ERROR_RETURN(drv_get_chipnum(&chip_num));
    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chip_id_base));

    for (chipid = chip_id_base; chipid < chip_id_base + chip_num; chipid++)
    {

        /* Initialize some register(record those dynimic table's position) */
        DRV_IF_ERROR_RETURN(_cm_sim_cfg_kit_init_register(chipid));

    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_show_tcam_allocation
 *             cm_sim_cfg_kit_show_hash_allocation
 *             cm_sim_cfg_kit_show_dynamic_allocation
 * Purpose:    show memory allocation for all dynamic tables
 * Parameters:
 * Input:      None
 * Output:     None
 * Return:     None
 * Note:       None.
 ****************************************************************************/

void cm_sim_cfg_kit_printf_dynamic_tbl_info(uint32 table_id)
{
    uint8 blk_id = 0;

    char dbg_info[20];
    uint8 blk_count = 0;

    sal_memset(dbg_info, 0, sizeof(dbg_info));


    if (TABLE_EXT_INFO_PTR(table_id) == NULL)
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Dynamic table %s has no dynamic ext info, there must be some error!\n", TABLE_NAME(table_id));
        return ;
    }

    if (TABLE_EXT_INFO_TYPE(table_id) != EXT_INFO_TYPE_DYNAMIC)
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Dynamic table %s allocated Failed, ext info type error!\n", TABLE_NAME(table_id));
        return ;
    }

    if (DYNAMIC_EXT_INFO_PTR(table_id) == NULL)
    {
        CMODEL_DEBUG_OUT_INFO("CModelAlloc ERROR! Dynamic table %s is not allocated!\n", TABLE_NAME(table_id));
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("%-40s %-15d %-15d 0x%08x",TABLE_NAME(table_id), TABLE_MAX_INDEX(table_id),
                               TABLE_ENTRY_SIZE(table_id)/4, DYNAMIC_BITMAP(table_id));

        for (blk_id = 0; blk_id < MAX_DRV_BLOCK_NUM; blk_id++)
        {
            if(IS_BIT_SET(DYNAMIC_BITMAP(table_id), blk_id))
            {
                CMODEL_DEBUG_OUT_INFO(" 0x%08x", DYNAMIC_DATA_BASE(table_id, blk_id));
            }
        }

        for (blk_id = 0; blk_id < MAX_DRV_BLOCK_NUM; blk_id++)
        {
            if(IS_BIT_SET(DYNAMIC_BITMAP(table_id), blk_id))
            {
                blk_count++;
                CMODEL_DEBUG_OUT_INFO("\n block%d SI = %-8d EI = %-8d", blk_count, DYNAMIC_START_INDEX(table_id, blk_id), DYNAMIC_END_INDEX(table_id, blk_id));
            }
        }
        CMODEL_DEBUG_OUT_INFO("\n");

        if (DYNAMIC_ACCESS_MODE(table_id) == DYNAMIC_DEFAULT)
        {
            sal_sprintf(dbg_info, "%s", "default mode");
        }
        else if (DYNAMIC_ACCESS_MODE(table_id) == DYNAMIC_4W_MODE)
        {
            sal_sprintf(dbg_info, "%s", "4w mode");
        }
        else if (DYNAMIC_ACCESS_MODE(table_id) == DYNAMIC_8W_MODE)
        {
            sal_sprintf(dbg_info, "%s", "8w mode");
        }

        CMODEL_DEBUG_OUT_INFO(" access mode is %s",dbg_info);
        CMODEL_DEBUG_OUT_INFO("\n");

    }

    return;

}

void cm_sim_cfg_kit_show_tcam_allocation(void)
{
    cm_mem_chip_allocation_info_t* p_mem_chip_info = NULL;
    uint32 table_id = 0;
    char table_name[64] = {0};

    p_mem_chip_info = &mem_chip_info[CM_TCAM_KEY];

    CMODEL_DEBUG_OUT_INFO("\n----------Tcam key allocation information brief ---------\n");
    CMODEL_DEBUG_OUT_INFO("Tcam key allocated in memory %s, %d entries allocated, %d entries available\n",
      p_mem_chip_info->mem_name, p_mem_chip_info->allocated_entry_num,
      p_mem_chip_info->max_mem_entry_num-p_mem_chip_info->allocated_entry_num);
    CMODEL_DEBUG_OUT_INFO("Int Tcam hw data base: 0x%08x, hw mask base: 0x%08x\n",
        DRV_INT_TCAM_KEY_DATA_ASIC_BASE, DRV_INT_TCAM_KEY_MASK_ASIC_BASE);
    CMODEL_DEBUG_OUT_INFO("LPM Tcam hw data base: 0x%08x, hw mask base: 0x%08x\n",
        DRV_INT_LPM_TCAM_DATA_ASIC_BASE, DRV_INT_LPM_TCAM_MASK_ASIC_BASE);

    CMODEL_DEBUG_OUT_INFO("%-40s %-15s %-15s %-15s %-10s\n", "Key name", "Max index num", "Key size(words)",
        "Entry size(words)", "hw base");
    for(table_id=0; table_id<MaxTblId_t; table_id++)
    {
        if(drv_table_is_tcam_key(table_id))
        {
            drv_get_tbl_string_by_id(table_id, table_name);
            CMODEL_DEBUG_OUT_INFO("%-40s %-15d %-15d %-15d 0x%08x 0x%8x\n",
                                   table_name, TABLE_MAX_INDEX(table_id),
                                   TCAM_KEY_SIZE(table_id)/4, TABLE_ENTRY_SIZE(table_id)/4,
                                   TABLE_DATA_BASE(table_id),
                                   TABLE_DATA_BASE(table_id)+TCAM_KEY_SIZE(table_id)*TABLE_MAX_INDEX(table_id));
        }
    }

    p_mem_chip_info = &mem_chip_info[CM_TCAM_AD];
    CMODEL_DEBUG_OUT_INFO("\n----------Tcam AD allocation information brief ---------\n");
    CMODEL_DEBUG_OUT_INFO("Tcam AD allocated in memory %s, %d entries allocated, %d entries available, hwBase(4Word) 0x%08x, hwBase(8Word) 0x%08x\n",
      p_mem_chip_info->mem_name, p_mem_chip_info->allocated_entry_num,
      p_mem_chip_info->max_mem_entry_num-p_mem_chip_info->allocated_entry_num,
      p_mem_chip_info->hardware_data_base_address,
      p_mem_chip_info->hardware_data_base_address_8w);

    CMODEL_DEBUG_OUT_INFO("%-40s %-15s %-15s %-10s\n", "Key name", "Max index num", "Table size(words)", "hw base");
    for(table_id=0; table_id<MaxTblId_t; table_id++)
    {
        if(cm_sim_cfg_kit_is_tcam_ad_tbl(table_id) || cm_sim_cfg_kit_is_lpm_tcam_ad_tbl(table_id))
        {
            drv_get_tbl_string_by_id(table_id, table_name);
            CMODEL_DEBUG_OUT_INFO("%-40s %-15d %-15d 0x%08x\n",
                                   table_name, TABLE_MAX_INDEX(table_id),
                                   TABLE_ENTRY_SIZE(table_id)/4, TABLE_DATA_BASE(table_id));
        }
    }
}


void cm_sim_cfg_kit_show_hash_allocation(void)
{
    uint32 table_id_index = 0;
    uint32 table_id = 0;
    uint8 share_mem_table_index = 0;

    CMODEL_DEBUG_OUT_INFO("\n------ Hash allocation information brief, hwBase(4 Word) 0x%08x ----\n", DRV_MEMORY0_BASE_4W);
    CMODEL_DEBUG_OUT_INFO("------ Hash allocation information brief, hwBase(8 Word) 0x%08x ----\n", DRV_MEMORY0_BASE_8W);
    CMODEL_DEBUG_OUT_INFO("%-40s %-15s %-15s %-10s %-10s %-10s %-10s %-10s %-10s\n",
                         "Key name", "Max index num", "Entry size(words)", "Block", "Hw base0", "Hw base1", "Hw base2",
                         "Hw base3", "Hw base4");

    for(share_mem_table_index=0; share_mem_table_index<=FIB_HASH_AD_SHARE_TABLE; share_mem_table_index++)
    {
        for(table_id_index=0; table_id_index<sram_share_mem_info[share_mem_table_index].table_num; table_id_index++)
        {
            table_id = sram_share_mem_info[share_mem_table_index].p_share_mem_table_list[table_id_index];

            cm_sim_cfg_kit_printf_dynamic_tbl_info(table_id);
        }

        if (share_mem_table_index == USER_ID_HASH_AD_SHARE_TABLE)
        {
#if 0
            table_id = DsUserIdIngressDefault_t;

            CMODEL_DEBUG_OUT_INFO("%-40s %-15d %-15d 0x%08x 0x%08x\n",
                                   TABLE_NAME(table_id), TABLE_MAX_INDEX(table_id),
                                   TABLE_ENTRY_SIZE(table_id)/4, TABLE_DATA_BASE(table_id),
                                   edmem_bitmap[table_id]);

            table_id = DsUserIdEgressDefault_t;
            CMODEL_DEBUG_OUT_INFO("%-40s %-15d %-15d 0x%08x 0x%08x\n",
                                   TABLE_NAME(table_id), TABLE_MAX_INDEX(table_id),
                                   TABLE_ENTRY_SIZE(table_id)/4, TABLE_DATA_BASE(table_id),
                                   edmem_bitmap[table_id]);

            table_id = DsTunnelIdDefault_t;
            CMODEL_DEBUG_OUT_INFO("%-40s %-15d %-15d 0x%08x 0x%08x\n",
                                   TABLE_NAME(table_id), TABLE_MAX_INDEX(table_id),
                                   TABLE_ENTRY_SIZE(table_id)/4, TABLE_DATA_BASE(table_id),
                                   edmem_bitmap[table_id]);
#else
            table_id = DsUserIdIngressDefault_t;

            cm_sim_cfg_kit_printf_dynamic_tbl_info(table_id);

            table_id = DsUserIdEgressDefault_t;
            cm_sim_cfg_kit_printf_dynamic_tbl_info(table_id);

            table_id = DsTunnelIdDefault_t;
            cm_sim_cfg_kit_printf_dynamic_tbl_info(table_id);
#endif
        }

        CMODEL_DEBUG_OUT_INFO("\n");
    }
}

void cm_sim_cfg_kit_show_dynamic_allocation(void)
{
    uint32 table_id_index = 0;
    uint32 table_id = 0;
    uint32 share_table_list_index = 0;

    CMODEL_DEBUG_OUT_INFO("\n---------- Dynamic allocation information brief, hwBase(4 Word) 0x%08x ----\n", DRV_MEMORY0_BASE_4W);
    CMODEL_DEBUG_OUT_INFO("---------- Dynamic allocation information brief, hwBase(8 Word) 0x%08x ----\n", DRV_MEMORY0_BASE_8W);
    CMODEL_DEBUG_OUT_INFO("%-40s %-15s %-15s %-10s %-10s %-10s %-10s %-10s %-10s\n", "Key name", "Max index num",
                          "Entry size(words)", "MemBitMap", "Hw base0", "Hw base1", "Hw base2", "Hw base3", "Hw base4");

    for(share_table_list_index=FWD_SHARE_TABLE; share_table_list_index<=STATS_SHARE_TABLE; share_table_list_index++)
    {
        for(table_id_index=0; table_id_index<sram_share_mem_info[share_table_list_index].table_num; table_id_index++)
        {
            table_id = sram_share_mem_info[share_table_list_index].p_share_mem_table_list[table_id_index];

            cm_sim_cfg_kit_printf_dynamic_tbl_info(table_id);
        }
    }

    /* show DsOamLmStatsX info, include DsOamLmStats */
    for(share_table_list_index=OAM_LM_STAT; share_table_list_index<=OAM_LM_STAT; share_table_list_index++)
    {
        for(table_id_index=0; table_id_index<sram_share_mem_info[share_table_list_index].table_num; table_id_index++)
        {
            table_id = sram_share_mem_info[share_table_list_index].p_share_mem_table_list[table_id_index];

            cm_sim_cfg_kit_printf_dynamic_tbl_info(table_id);
        }
    }

#if 0
    /* special for cmodel */
    cm_sim_cfg_kit_printf_dynamic_tbl_info(DsOamLmStats_t);
#endif

#if 0
    /*Dynamic tables*/
    for(table_id_index=0; table_id_index<sizeof(cm_mem_dynaic_table_list)/sizeof(uint32); table_id_index++)
    {
        table_id = cm_mem_dynaic_table_list[table_id_index];
        drv_get_tbl_string_by_id(table_id, table_name);
        CMODEL_DEBUG_OUT_INFO("%-40s %-15d %-15d 0x%08x 0x%08x\n",
                               table_name, TABLE_MAX_INDEX(table_id),
                               TABLE_ENTRY_SIZE(table_id)/4, TABLE_DATA_BASE(table_id),
                               edmem_bitmap[table_id]);
    }

    table_id = DsStats_t;
    drv_get_tbl_string_by_id(table_id, table_name);
    CMODEL_DEBUG_OUT_INFO("%-40s %-15d %-15d 0x%08x 0x%08x\n",
                           table_name, TABLE_MAX_INDEX(table_id),
                           TABLE_ENTRY_SIZE(table_id)/4, TABLE_DATA_BASE(table_id),
                           edmem_bitmap[table_id]);
#endif


}


void cm_sim_cfg_kit_show_table_allocation(void)
{
    uint32 table_id_index = 0;
    tbls_id_t tbl_id = 0;
    uint32 share_table_list_index = 0;

    CMODEL_DEBUG_OUT_INFO("\n---------- Not allocated tcam ad table is as followed: --------\n");

    for (share_table_list_index = 0; share_table_list_index < mem_extern_tcam_ad_list.tbl_num; share_table_list_index ++)
    {
        tbl_id = mem_extern_tcam_ad_list.tbl_list[share_table_list_index];
        if (TABLE_MAX_INDEX(tbl_id) == 0)
        {
            CMODEL_DEBUG_OUT_INFO("table name = %s, table id = %d\n",TABLE_NAME(tbl_id), tbl_id);
        }
    }

    CMODEL_DEBUG_OUT_INFO("\n---------- Not allocated tcam key table is as followed: --------\n");
    for (share_table_list_index = 0; share_table_list_index < mem_extern_tcam_key_list.tbl_num; share_table_list_index ++)
    {
        tbl_id = mem_extern_tcam_key_list.tbl_list[share_table_list_index];
        if (TABLE_MAX_INDEX(tbl_id) == 0)
        {
            CMODEL_DEBUG_OUT_INFO("table name = %s, table id = %d\n",TABLE_NAME(tbl_id), tbl_id);
        }
    }


    CMODEL_DEBUG_OUT_INFO("\n---------- Not allocated userid default table is as followed: --------\n");
    for (share_table_list_index = 0; share_table_list_index < mem_extern_userid_dft_list.tbl_num; share_table_list_index ++)
    {
        tbl_id = mem_extern_userid_dft_list.tbl_list[share_table_list_index];
        if (TABLE_MAX_INDEX(tbl_id) == 0)
        {
            CMODEL_DEBUG_OUT_INFO("table name = %s, table id = %d\n",TABLE_NAME(tbl_id), tbl_id);
        }
    }

    CMODEL_DEBUG_OUT_INFO("\n---------- Not allocated dynamic table is as followed: --------\n");
    for(share_table_list_index=0; share_table_list_index<MAX_SRAM_SHARE_MEM_ID; share_table_list_index++)
    {
        for(table_id_index=0; table_id_index<sram_share_mem_info[share_table_list_index].table_num; table_id_index++)
        {
            tbl_id = sram_share_mem_info[share_table_list_index].p_share_mem_table_list[table_id_index];

            if (TABLE_MAX_INDEX(tbl_id) == 0)
            {
                CMODEL_DEBUG_OUT_INFO("table name = %s, table id = %d\n",TABLE_NAME(tbl_id), tbl_id);
            }

        }
    }

    return;

}

/* detail_info_flag = 1, printf the actual base add, min and max index,
   detail_info_flag = 0, printf the asic register value */
int32 cm_sim_cfg_kit_show_rtl_register_info(uint8 detail_info_flag)
{
#define DYNAMIC_DS_CAM_SHIFT 10

    /* show dynamic table info */
    dynamic_ds_five_base_cam_t dynamic_ds_five_base_cam;
    dynamic_ds_base_cam_unit_t dynamic_ds_base_cam_unit;
    uint32 dynamic_ds_cam_list_index = 0;
    uint32 dynamic_ds_all_cam_list_num = sizeof(ds_dynamic_all_cam_list)/sizeof(ds_dynamic_all_cam_list[0]);
    tbls_id_t tbl_id = MaxTblId_t;
    uint32 cmd = 0;
    uint8 chip_num = 0, chip_id_base = 0, chip_id = 0;
    uint8 dynamic_block_empty_flag = FALSE;
    uint8 dynamic_ds_base_cam_unit_index = 0;

    oam_tbl_addr_ctl_t oam_tbl_addr_ctl;

    DRV_IF_ERROR_RETURN(drv_get_chipnum(&chip_num));
    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chip_id_base));

    for (chip_id = chip_id_base; chip_id < chip_id_base + chip_num; chip_id++)
    {

        /* printf RTL dynamic register info , DynamicDsxxxxxx info */
        CMODEL_DEBUG_OUT_INFO("\n---------- RTL dynamic register info ----------\n");
        CMODEL_DEBUG_OUT_INFO("%-30s|%-10s %-10s %-10s||%-10s %-10s %-10s||%-10s %-10s %-10s|\n", "Table name", "Base0",
                          "Min index0", "Max index0", "Base1", "Min index1", "Max index1", "Base2", "Min index2", "Max index2");

        for (dynamic_ds_cam_list_index = 0; dynamic_ds_cam_list_index < dynamic_ds_all_cam_list_num; dynamic_ds_cam_list_index++)
        {
            sal_memset(&dynamic_ds_five_base_cam, 0, sizeof(dynamic_ds_five_base_cam));

            tbl_id = ds_dynamic_all_cam_list[dynamic_ds_cam_list_index];
            cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &dynamic_ds_five_base_cam));

            CMODEL_DEBUG_OUT_INFO("%-30s", TABLE_NAME(tbl_id));
            dynamic_block_empty_flag = FALSE;

            for (dynamic_ds_base_cam_unit_index = 0;
                  dynamic_ds_base_cam_unit_index < sizeof(dynamic_ds_five_base_cam)/sizeof(dynamic_ds_base_cam_unit);
                  dynamic_ds_base_cam_unit_index++)
            {

                sal_memset(&dynamic_ds_base_cam_unit, 0, sizeof(dynamic_ds_base_cam_unit));
                sal_memcpy(&dynamic_ds_base_cam_unit,
                            (char *)(&dynamic_ds_five_base_cam) + dynamic_ds_base_cam_unit_index * sizeof(dynamic_ds_base_cam_unit),
                            sizeof(dynamic_ds_base_cam_unit));

                if (!dynamic_block_empty_flag)
                {
                    /* indicated this dynamic cam unit is not set */
                    if ((dynamic_ds_base_cam_unit.ds_dynamic_base == 0)
                       && (dynamic_ds_base_cam_unit.ds_dynamic_max_index == 0)
                       && (dynamic_ds_base_cam_unit.ds_dynamic_min_index == 0))
                    {
                        dynamic_block_empty_flag = TRUE;
                    }
                    else
                    {
                        if (!detail_info_flag)
                        {

                            CMODEL_DEBUG_OUT_INFO("|0x%08x 0x%08x 0x%08x|", dynamic_ds_base_cam_unit.ds_dynamic_base,
                                                dynamic_ds_base_cam_unit.ds_dynamic_min_index,
                                                dynamic_ds_base_cam_unit.ds_dynamic_max_index);
                        }
                        else
                        {
                            CMODEL_DEBUG_OUT_INFO("|0x%08x 0x%08x 0x%08x|", dynamic_ds_base_cam_unit.ds_dynamic_base<<DYNAMIC_DS_CAM_SHIFT,
                                                dynamic_ds_base_cam_unit.ds_dynamic_min_index<<DYNAMIC_DS_CAM_SHIFT,
                                                ((dynamic_ds_base_cam_unit.ds_dynamic_max_index +1)<<DYNAMIC_DS_CAM_SHIFT) -1);
                        }

                        if(dynamic_ds_base_cam_unit_index == 2)
                        {
                            CMODEL_DEBUG_OUT_INFO("\n%-30s","");
                        }

                    }

                }
                else
                {
                    if (!((dynamic_ds_base_cam_unit.ds_dynamic_base == 0)
                       && (dynamic_ds_base_cam_unit.ds_dynamic_max_index == 0)
                       && (dynamic_ds_base_cam_unit.ds_dynamic_min_index == 0)))
                    {
                        CMODEL_DEBUG_OUT_INFO("ERROR: table %s must have error, previous unit is empty, but %d unit has data\n",
                                                TABLE_NAME(tbl_id), dynamic_ds_base_cam_unit_index);

                    }

                }


            }

            CMODEL_DEBUG_OUT_INFO("\n");

        }

        /* printf oam OamTblAddrCtl_t info */
        sal_memset(&oam_tbl_addr_ctl, 0, sizeof(oam_tbl_addr_ctl));
        tbl_id = OamTblAddrCtl_t;
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_tbl_addr_ctl));
        CMODEL_DEBUG_OUT_INFO("\n---------- OamTblAddrCtl_t register info ----------\n");
        CMODEL_DEBUG_OUT_INFO("ma_base_addr = 0x%08x\n", oam_tbl_addr_ctl.ma_base_addr);
        CMODEL_DEBUG_OUT_INFO("ma_name_base_addr = 0x%08x\n", oam_tbl_addr_ctl.ma_name_base_addr);
        CMODEL_DEBUG_OUT_INFO("mp_base_addr = 0x%08x\n", oam_tbl_addr_ctl.mp_base_addr);
        CMODEL_DEBUG_OUT_INFO("\n");

    }

    return DRV_E_NONE;

}


int32
cm_sim_cfg_kit_update_lpm_prefix_table(uint8 chip_id, ds_lpm_request_t* p_ds_lpm_request)
{
#if 0
    ds_lpm_result_t  ds_lpm_result;

    sal_memset(&ds_lpm_result, 0, sizeof(ds_lpm_result));
    DRV_IF_ERROR_RETURN(cm_com_lpm_engine_lpm_update(chip_id, p_ds_lpm_request, &ds_lpm_result));
#endif
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_sim_cfg_kit_allocate_lpm_tcam_key_process
 * Purpose:    LPM TCAM key allocation function
 * Parameters:
 * Input:      table_alloc_info  -- pointer to table information
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32 cm_sim_cfg_kit_allocate_lpm_tcam_key_process(cm_table_allocation_info_t *table_alloc_info)
{
    uint32 tcam_entry_num = 0;
    uint32 table_id_index = 0;
    uint32 table_id = 0;

    cm_mem_chip_allocation_info_t* p_mem_chip_info = NULL;

    p_mem_chip_info = &mem_chip_info[CM_LPM_TCAM_KEY];
    tcam_entry_num = table_alloc_info->index_num;

    if((p_mem_chip_info->allocated_entry_num + tcam_entry_num) >p_mem_chip_info->max_mem_entry_num)
    {
        CMODEL_DEBUG_OUT_INFO("Not enough entry in LPM tcam key for key_id %d\n", table_alloc_info->table_id);
        return DRV_E_EXCEED_MAX_SIZE;
    }

    for(table_id_index=0; table_id_index<tcam_share_mem_info[LPM_TCAM_KEY_SHARE_TABLE].table_num; table_id_index++)
    {
        table_id = tcam_share_mem_info[LPM_TCAM_KEY_SHARE_TABLE].p_share_mem_table_list[table_id_index];
        if(TABLE_MAX_INDEX(table_id) == 0)
        {
            TCAM_KEY_SIZE(table_id) = TABLE_ENTRY_SIZE(table_id);/* table key size are in bytes */

            if((DsLpmTcam80Key_t == table_id) || (DsFibUserId80Key_t == table_id))
            {
                TABLE_MAX_INDEX(table_id) = table_alloc_info->index_num;
            }
            else if((DsLpmTcam160Key_t == table_id) || (DsFibUserId160Key_t == table_id))
            {
                TABLE_MAX_INDEX(table_id) = table_alloc_info->index_num;
            }

            TABLE_DATA_BASE(table_id) = p_mem_chip_info->hardware_data_base_address
                                        + p_mem_chip_info->allocated_entry_num*DRV_BYTES_PER_ENTRY;
            TCAM_MASK_BASE(table_id) = DRV_INT_LPM_TCAM_MASK_ASIC_BASE
                                       + p_mem_chip_info->allocated_entry_num*DRV_BYTES_PER_ENTRY;

        }
    }
    p_mem_chip_info->allocated_entry_num += tcam_entry_num;

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       cm_sim_cfg_kit_allocate_lpm_tcam_ad_process
 * Purpose:    LPM TCAM ad allocation function
 * Parameters:
 * Input:      table_alloc_info  -- pointer to table information
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32 cm_sim_cfg_kit_allocate_lpm_tcam_ad_process(cm_table_allocation_info_t *table_alloc_info)
{
    uint32 tcam_entry_num = table_alloc_info->index_num;
    uint32 table_id_index = 0;
    tbls_id_t table_id = 0;
    uint32 entry_num_per_index = 0;

    cm_mem_chip_allocation_info_t* p_mem_chip_info = NULL;

    p_mem_chip_info = &mem_chip_info[CM_LPM_TCAM_AD];
    if((p_mem_chip_info->allocated_entry_num + tcam_entry_num) >p_mem_chip_info->max_mem_entry_num)
    {
        CMODEL_DEBUG_OUT_INFO("Not enough entry in LPM tcam ad for table %s\n", TABLE_NAME(table_alloc_info->table_id));
        return DRV_E_EXCEED_MAX_SIZE;
    }

    for(table_id_index=0; table_id_index<lpm_tcam_share_ad_mem_info[LPM_TCAM_AD_SHARE_TABLE].table_num; table_id_index++)
    {
        table_id = lpm_tcam_share_ad_mem_info[LPM_TCAM_AD_SHARE_TABLE].p_share_mem_table_list[table_id_index];
        entry_num_per_index = (TABLE_ENTRY_SIZE(table_id)/DRV_BYTES_PER_ENTRY);

        if(TABLE_MAX_INDEX(table_id) == 0)
        {
            TABLE_MAX_INDEX(table_id) = table_alloc_info->index_num/ entry_num_per_index;
            TABLE_DATA_BASE(table_id) = p_mem_chip_info->hardware_data_base_address
                                        + p_mem_chip_info->allocated_entry_num*DRV_BYTES_PER_ENTRY;

        }
    }

    p_mem_chip_info->allocated_entry_num += tcam_entry_num;

    return DRV_E_NONE;
}


int32 cm_sim_cfg_kit_allocate_dynamic_tbl_chk(uint32 chip_id)
{
    uint32 cmd = 0;
    int list_index = 0;
    tbls_id_t tbl_id = MaxTblId_t, dynamic_cam_tbl_id = MaxTblId_t;
    uint32 drv_hw_addr = 0;
    uint32 rtl_hw_addr = 0;
    uint32 entry_base = 0;
    uint32 dynamic_base_address = 0;
    dynamic_ds_five_base_cam_t dynamic_ds_base_cam;
    char table_name[64] = {0};
    char cam_table_name[64] = {0};
    bool not_match = FALSE;

    sal_memset(&dynamic_ds_base_cam, 0, sizeof(dynamic_ds_five_base_cam_t));

    for (list_index = 0; list_index < sizeof(ds_dynamic_cam_list)/sizeof(ds_dynamic_cam_list[0]); list_index++)
    {
        dynamic_cam_tbl_id = ds_dynamic_cam_list[list_index];
        tbl_id = ds_dynamic_cam_table_list[list_index];
        if(tbl_id == DsOamLmStats_t)
        {
            continue;
        }
        else
        {
            drv_table_get_hw_addr(tbl_id, 0, &drv_hw_addr);
        }

        if(tbl_id == DsUserIdDoubleVlanHashKey_t)
        {
            if (TABLE_ENTRY_SIZE(tbl_id) == DRV_BYTES_PER_ENTRY)
            {
                rtl_hw_addr = DRV_MEMORY7_BASE_4W;
            }
            else
            {
                rtl_hw_addr = DRV_MEMORY7_BASE_8W;
            }
        }
        else
        {
            if (TABLE_ENTRY_SIZE(tbl_id) == DRV_BYTES_PER_ENTRY)
            {
                dynamic_base_address = DRV_MEMORY0_BASE_4W;
            }
            else
            {
                dynamic_base_address = DRV_MEMORY0_BASE_8W;
            }
            cmd = DRV_IOR(dynamic_cam_tbl_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &dynamic_ds_base_cam));
            entry_base  = dynamic_ds_base_cam.ds_dynamic_base0;
            rtl_hw_addr = (entry_base << 10)*DRV_ADDR_BYTES_PER_ENTRY + dynamic_base_address;
        }


        if(drv_hw_addr != rtl_hw_addr)
        {
            not_match = TRUE;
            sal_memset(&table_name, 0, sizeof(table_name));
            sal_memset(&cam_table_name, 0, sizeof(cam_table_name));
            drv_get_tbl_string_by_id(tbl_id, table_name);
            drv_get_tbl_string_by_id(dynamic_cam_tbl_id, cam_table_name);
            sal_printf("dynamic table %s 0x%x cam register %s 0x%x cfg error\n", table_name, drv_hw_addr, cam_table_name, rtl_hw_addr);
        }
    }

    if(!not_match)
    {
        sal_printf("dynamic table cam register cfg OK!\n");
    }

    return DRV_E_NONE;
}

int32 cm_sim_cfg_kit_allocate_tcam_tbl_chk(uint32 chip_id)
{
    uint32 list_index = 0;
    tbls_id_t tbl_id = MaxTblId_t;
    uint32 drv_hw_data_addr = 0;
    uint32 drv_hw_mask_addr = 0;
    uint32 rtl_hw_addr = 0;
    uint32 cmd = 0;
    uint32 key_num = 0;

    uint32 *shift    = NULL;
    uint32 *idx_base = NULL;
    uint32 *tbl_base = NULL;

    uint32 shift_bit = 0;
    uint32 index_base = 0;
    uint32 table_base = 0;
    bool not_match = FALSE;
    char table_name[64] = {0};

    tcam_engine_lookup_result_ctl0_t tcam_lkp_rst_ctl0; /* include ACL lookupResult */
    tcam_engine_lookup_result_ctl1_t tcam_lkp_rst_ctl1; /* include UserId & OAM lookupResult */
    tcam_engine_lookup_result_ctl2_t tcam_lkp_rst_ctl2; /* include IP & MAC lookupResult */
    tcam_engine_lookup_result_ctl3_t tcam_lkp_rst_ctl3; /* include FCoE & Trill lookupResult */

    key_num = sizeof(cm_mem_tcam_key_list)/sizeof(cm_mem_tcam_key_list[0]);

    shift       = sal_malloc(key_num*sizeof(uint32));
    if(NULL == shift)
    {
        return DRV_E_NO_MEMORY;
    }

    idx_base    = sal_malloc(key_num*sizeof(uint32));
    if(NULL == idx_base)
    {
        sal_free(shift);
        shift = NULL;
        return DRV_E_NO_MEMORY;
    }

    tbl_base    = sal_malloc(key_num*sizeof(uint32));
    if(NULL == tbl_base)
    {
        sal_free(shift);
        sal_free(idx_base);
        shift = NULL;
        idx_base = NULL;
        return DRV_E_NO_MEMORY;
    }

    sal_memset(shift, 0, key_num*sizeof(uint32));
    sal_memset(idx_base, 0, key_num*sizeof(uint32));
    sal_memset(tbl_base, 0, key_num*sizeof(uint32));

    sal_memset(&tcam_lkp_rst_ctl0, 0, sizeof(tcam_lkp_rst_ctl0));
    sal_memset(&tcam_lkp_rst_ctl1, 0, sizeof(tcam_lkp_rst_ctl1));
    sal_memset(&tcam_lkp_rst_ctl2, 0, sizeof(tcam_lkp_rst_ctl2));
    sal_memset(&tcam_lkp_rst_ctl3, 0, sizeof(tcam_lkp_rst_ctl3));

    cmd = DRV_IOR(TcamEngineLookupResultCtl0_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_lkp_rst_ctl0));

    cmd = DRV_IOR(TcamEngineLookupResultCtl1_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_lkp_rst_ctl1));

    cmd = DRV_IOR(TcamEngineLookupResultCtl2_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_lkp_rst_ctl2));

    cmd = DRV_IOR(TcamEngineLookupResultCtl3_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tcam_lkp_rst_ctl3));

    /*********** ACL lookupResult control setting ***********/
    /* ACL IPv6 key0-key3 */
    shift[DsAclIpv6Key0_e]      = tcam_lkp_rst_ctl0.acl0_index_shift0;
    idx_base[DsAclIpv6Key0_e]   = tcam_lkp_rst_ctl0.acl0_index_base0;
    tbl_base[DsAclIpv6Key0_e]   = tcam_lkp_rst_ctl0.acl0_table_base0;
    shift[DsAclIpv6Key1_e]      = tcam_lkp_rst_ctl0.acl1_index_shift0;
    idx_base[DsAclIpv6Key1_e]   = tcam_lkp_rst_ctl0.acl1_index_base0;
    tbl_base[DsAclIpv6Key1_e]   = tcam_lkp_rst_ctl0.acl1_table_base0;

    /* ACL IPv4 key0-key3 */
    shift[DsAclIpv4Key0_e] = tcam_lkp_rst_ctl0.acl0_index_shift1 ;
    idx_base[DsAclIpv4Key0_e] = tcam_lkp_rst_ctl0.acl0_index_base1;
    tbl_base[DsAclIpv4Key0_e] = tcam_lkp_rst_ctl0.acl0_table_base1;

    shift[DsAclIpv4Key1_e] = tcam_lkp_rst_ctl0.acl1_index_shift1 ;
    idx_base[DsAclIpv4Key1_e] = tcam_lkp_rst_ctl0.acl1_index_base1;
    tbl_base[DsAclIpv4Key1_e] = tcam_lkp_rst_ctl0.acl1_table_base1;

    shift[DsAclIpv4Key2_e] = tcam_lkp_rst_ctl0.acl2_index_shift1 ;
    idx_base[DsAclIpv4Key2_e] = tcam_lkp_rst_ctl0.acl2_index_base1;
    tbl_base[DsAclIpv4Key2_e] = tcam_lkp_rst_ctl0.acl2_table_base1;

    shift[DsAclIpv4Key3_e] = tcam_lkp_rst_ctl0.acl3_index_shift1 ;
    idx_base[DsAclIpv4Key3_e] = tcam_lkp_rst_ctl0.acl3_index_base1;
    tbl_base[DsAclIpv4Key3_e] = tcam_lkp_rst_ctl0.acl3_table_base1;


    /* ACL Mac key0-key3 */
    shift[DsAclMacKey0_e] = tcam_lkp_rst_ctl0.acl0_index_shift2 ;
    idx_base[DsAclMacKey0_e] = tcam_lkp_rst_ctl0.acl0_index_base2;
    tbl_base[DsAclMacKey0_e] = tcam_lkp_rst_ctl0.acl0_table_base2;

    shift[DsAclMacKey1_e] = tcam_lkp_rst_ctl0.acl1_index_shift2 ;
    idx_base[DsAclMacKey1_e] = tcam_lkp_rst_ctl0.acl1_index_base2;
    tbl_base[DsAclMacKey1_e] = tcam_lkp_rst_ctl0.acl1_table_base2;

    shift[DsAclMacKey2_e] = tcam_lkp_rst_ctl0.acl2_index_shift2 ;
    idx_base[DsAclMacKey2_e] = tcam_lkp_rst_ctl0.acl2_index_base2;
    tbl_base[DsAclMacKey2_e] = tcam_lkp_rst_ctl0.acl2_table_base2;

    shift[DsAclMacKey3_e] = tcam_lkp_rst_ctl0.acl3_index_shift2 ;
    idx_base[DsAclMacKey3_e] = tcam_lkp_rst_ctl0.acl3_index_base2;
    tbl_base[DsAclMacKey3_e] = tcam_lkp_rst_ctl0.acl3_table_base2;

    /* ACL MPLS key0-key3 */
    shift[DsAclMplsKey0_e] = tcam_lkp_rst_ctl0.acl0_index_shift1 ;
    idx_base[DsAclMplsKey0_e] = tcam_lkp_rst_ctl0.acl0_index_base1;
    tbl_base[DsAclMplsKey0_e] = tcam_lkp_rst_ctl0.acl0_table_base1;

    shift[DsAclMplsKey1_e] = tcam_lkp_rst_ctl0.acl1_index_shift1 ;
    idx_base[DsAclMplsKey1_e] = tcam_lkp_rst_ctl0.acl1_index_base1;
    tbl_base[DsAclMplsKey1_e] = tcam_lkp_rst_ctl0.acl1_table_base1;

    shift[DsAclMplsKey2_e] = tcam_lkp_rst_ctl0.acl2_index_shift1 ;
    idx_base[DsAclMplsKey2_e] = tcam_lkp_rst_ctl0.acl2_index_base1;
    tbl_base[DsAclMplsKey2_e] = tcam_lkp_rst_ctl0.acl2_table_base1;

    shift[DsAclMplsKey3_e] = tcam_lkp_rst_ctl0.acl3_index_shift1 ;
    idx_base[DsAclMplsKey3_e] = tcam_lkp_rst_ctl0.acl3_index_base1;
    tbl_base[DsAclMplsKey3_e] = tcam_lkp_rst_ctl0.acl3_table_base1;

    /*********** IP and MAC ***********/
    /* IPv4 Uc */
    shift[DsIpv4UcastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_index_shift0;
    idx_base[DsIpv4UcastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_index_base0;
    tbl_base[DsIpv4UcastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_table_base0;
    /* IPv4 Mc */
    shift[DsIpv4McastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_index_shift1;
    idx_base[DsIpv4McastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_index_base1;
    tbl_base[DsIpv4McastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_table_base1;
    /* IPv6 Mc */
    shift[DsIpv6McastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_index_shift3;
    idx_base[DsIpv6McastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_index_base3;
    tbl_base[DsIpv6McastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_table_base3;
    /* IPv6 Uc */
    shift[DsIpv6UcastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_index_shift2;
    idx_base[DsIpv6UcastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_index_base2;
    tbl_base[DsIpv6UcastRouteKey_e] = tcam_lkp_rst_ctl2.ip_da_table_base2;

    /* MacSa */
    shift[DsMacLearningKey_e] = tcam_lkp_rst_ctl2.mac_sa_index_shift;
    idx_base[DsMacLearningKey_e] = tcam_lkp_rst_ctl2.mac_sa_index_base;
    tbl_base[DsMacLearningKey_e] = tcam_lkp_rst_ctl2.mac_sa_table_base;
    /* MacDa */
    shift[DsMacBridgeKey_e] = tcam_lkp_rst_ctl2.mac_da_index_shift;
    idx_base[DsMacBridgeKey_e] = tcam_lkp_rst_ctl2.mac_da_index_base;
    tbl_base[DsMacBridgeKey_e] = tcam_lkp_rst_ctl2.mac_da_table_base;

    /* IPv4 NAT */
    shift[DsIpv4NatKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_shift2;
    idx_base[DsIpv4NatKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_base2;
    tbl_base[DsIpv4NatKey_e] = tcam_lkp_rst_ctl2.ip_sa_table_base2;

    /* IPv6 NAT */
    shift[DsIpv6NatKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_shift3;
    idx_base[DsIpv6NatKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_base3;
    tbl_base[DsIpv6NatKey_e] = tcam_lkp_rst_ctl2.ip_sa_table_base3;

    /* IPv4 PBR */
    shift[DsIpv4PbrKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_shift4;
    idx_base[DsIpv4PbrKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_base4;
    tbl_base[DsIpv4PbrKey_e] = tcam_lkp_rst_ctl2.ip_sa_table_base4;

    /* IPv6 PBR */
    shift[DsIpv6PbrKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_shift5;
    idx_base[DsIpv6PbrKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_base5;
    tbl_base[DsIpv6PbrKey_e] = tcam_lkp_rst_ctl2.ip_sa_table_base5;

    /* IPv4 RPF */
    shift[DsIpv4RpfKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_shift0;
    idx_base[DsIpv4RpfKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_base0;
    tbl_base[DsIpv4RpfKey_e] = tcam_lkp_rst_ctl2.ip_sa_table_base0;

    /* IPv6 RPF */
    shift[DsIpv6RpfKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_shift1;
    idx_base[DsIpv6RpfKey_e] = tcam_lkp_rst_ctl2.ip_sa_index_base1;
    tbl_base[DsIpv6RpfKey_e] = tcam_lkp_rst_ctl2.ip_sa_table_base1;

    /* FCoE Da */
    shift[DsFcoeRouteKey_e] = tcam_lkp_rst_ctl3.fcoe_index_shift0;
    idx_base[DsFcoeRouteKey_e] = tcam_lkp_rst_ctl3.fcoe_index_base0;
    tbl_base[DsFcoeRouteKey_e] = tcam_lkp_rst_ctl3.fcoe_table_base0;

    /* FCoE Sa */
    shift[DsFcoeRpfKey_e] = tcam_lkp_rst_ctl3.fcoe_index_shift1;
    idx_base[DsFcoeRpfKey_e] = tcam_lkp_rst_ctl3.fcoe_index_base1;
    tbl_base[DsFcoeRpfKey_e] = tcam_lkp_rst_ctl3.fcoe_table_base1;

    /* Trill Da Uc */
    shift[DsTrillUcastRouteKey_e] = tcam_lkp_rst_ctl3.trill_index_shift0;
    idx_base[DsTrillUcastRouteKey_e] = tcam_lkp_rst_ctl3.trill_index_base0;
    tbl_base[DsTrillUcastRouteKey_e] = tcam_lkp_rst_ctl3.trill_table_base0;

    /* Trill Da Mc */
    shift[DsTrillMcastRouteKey_e] = tcam_lkp_rst_ctl3.trill_index_shift1;
    idx_base[DsTrillMcastRouteKey_e] = tcam_lkp_rst_ctl3.trill_index_base1;
    tbl_base[DsTrillMcastRouteKey_e] = tcam_lkp_rst_ctl3.trill_table_base1;

    /* UserID Mac */
    shift[DsUserIdMacKey_e] = tcam_lkp_rst_ctl1.user_id_index_shift0;
    idx_base[DsUserIdMacKey_e] = tcam_lkp_rst_ctl1.user_id_index_base0;
    tbl_base[DsUserIdMacKey_e] = tcam_lkp_rst_ctl1.user_id_table_base0;

    /* UserID IPv6 */
    shift[DsUserIdIpv6Key_e] = tcam_lkp_rst_ctl1.user_id_index_shift1;
    idx_base[DsUserIdIpv6Key_e] = tcam_lkp_rst_ctl1.user_id_index_base1;
    tbl_base[DsUserIdIpv6Key_e] = tcam_lkp_rst_ctl1.user_id_table_base1;

    /* UserID IPv4 */
    shift[DsUserIdIpv4Key_e] = tcam_lkp_rst_ctl1.user_id_index_shift2;
    idx_base[DsUserIdIpv4Key_e] = tcam_lkp_rst_ctl1.user_id_index_base2;
    tbl_base[DsUserIdIpv4Key_e] = tcam_lkp_rst_ctl1.user_id_table_base2;

    /* UserID Vlan */
    shift[DsUserIdVlanKey_e] = tcam_lkp_rst_ctl1.user_id_index_shift3;
    idx_base[DsUserIdVlanKey_e] = tcam_lkp_rst_ctl1.user_id_index_base3;
    tbl_base[DsUserIdVlanKey_e] = tcam_lkp_rst_ctl1.user_id_table_base3;

    /* TunnleIpv6 */
    shift[DsTunnelIdIpv6Key_e] = tcam_lkp_rst_ctl1.user_id_index_shift4;
    idx_base[DsTunnelIdIpv6Key_e] = tcam_lkp_rst_ctl1.user_id_index_base4;
    tbl_base[DsTunnelIdIpv6Key_e] = tcam_lkp_rst_ctl1.user_id_table_base4;

    /* TunnleIpv4 */
    shift[DsTunnelIdIpv4Key_e] = tcam_lkp_rst_ctl1.user_id_index_shift5;
    idx_base[DsTunnelIdIpv4Key_e] = tcam_lkp_rst_ctl1.user_id_index_base5;
    tbl_base[DsTunnelIdIpv4Key_e] = tcam_lkp_rst_ctl1.user_id_table_base5;

    /* TunnlePBB */
    shift[DsTunnelIdPbbKey_e] = tcam_lkp_rst_ctl1.user_id_index_shift6;
    idx_base[DsTunnelIdPbbKey_e] = tcam_lkp_rst_ctl1.user_id_index_base6;
    tbl_base[DsTunnelIdPbbKey_e] = tcam_lkp_rst_ctl1.user_id_table_base6;

    /* TunnleCapwap */
    shift[DsTunnelIdCapwapKey_e] = tcam_lkp_rst_ctl1.user_id_index_shift7;
    idx_base[DsTunnelIdCapwapKey_e] = tcam_lkp_rst_ctl1.user_id_index_base7;
    tbl_base[DsTunnelIdCapwapKey_e] = tcam_lkp_rst_ctl1.user_id_table_base7;

    /* TunnleTrill */
    shift[DsTunnelIdTrillKey_e] = tcam_lkp_rst_ctl1.user_id_index_shift8;
    idx_base[DsTunnelIdTrillKey_e] = tcam_lkp_rst_ctl1.user_id_index_base8;
    tbl_base[DsTunnelIdTrillKey_e] = tcam_lkp_rst_ctl1.user_id_table_base8;

    /*
    shift[DsEthOamKey_e] = tcam_lkp_rst_ctl1.user_id_index_shift8;
    idx_base[DsEthOamKey_e] = tcam_lkp_rst_ctl1.user_id_index_base8;
    tbl_base[DsEthOamKey_e] = tcam_lkp_rst_ctl1.user_id_table_base8;

    shift[DsBfdOamKey_e] = tcam_lkp_rst_ctl1.user_id_index_shift8;
    idx_base[DsBfdOamKey_e] = tcam_lkp_rst_ctl1.user_id_index_base8;
    tbl_base[DsBfdOamKey_e] = tcam_lkp_rst_ctl1.user_id_table_base8;

    shift[DsMplsOamLabelKey_e] = tcam_lkp_rst_ctl1.user_id_index_shift8;
    idx_base[DsMplsOamLabelKey_e] = tcam_lkp_rst_ctl1.user_id_index_base8;
    tbl_base[DsMplsOamLabelKey_e] = tcam_lkp_rst_ctl1.user_id_table_base8;

    shift[DsPbtOamKey_e] = tcam_lkp_rst_ctl1.user_id_index_shift8;
    idx_base[DsPbtOamKey_e] = tcam_lkp_rst_ctl1.user_id_index_base8;
    tbl_base[DsPbtOamKey_e] = tcam_lkp_rst_ctl1.user_id_table_base8;

    shift[DsEthOamRmepKey_e] = tcam_lkp_rst_ctl1.user_id_index_shift8;
    idx_base[DsEthOamRmepKey_e] = tcam_lkp_rst_ctl1.user_id_index_base8;
    tbl_base[DsEthOamRmepKey_e] = tcam_lkp_rst_ctl1.user_id_table_base8;
    */
    /* LPM and Fib userId resolve conflict Tcam Key*/

    shift[DsLpmTcam160Key_e] = 0;
    idx_base[DsLpmTcam160Key_e] = 0;
    tbl_base[DsLpmTcam160Key_e] = 0;

    shift[DsLpmTcam80Key_e] = 0;
    idx_base[DsLpmTcam80Key_e] = 0;
    tbl_base[DsLpmTcam80Key_e] = 0;

    shift[DsFibUserId80Key_e] = 0;
    idx_base[DsFibUserId80Key_e] = 0;
    tbl_base[DsFibUserId80Key_e] = 0;

    shift[DsFibUserId160Key_e] = 0;
    idx_base[DsFibUserId160Key_e] = 0;
    tbl_base[DsFibUserId160Key_e] = 0;

    /* DsMacIpv4Key and DsMacIpv6Key */
    /* Ipv4Mac */
    shift[DsMacIpv4Key_e] = tcam_lkp_rst_ctl3.mac_ip_index_shift1;
    idx_base[DsMacIpv4Key_e] = tcam_lkp_rst_ctl3.mac_ip_index_base1;
    tbl_base[DsMacIpv4Key_e] = tcam_lkp_rst_ctl3.mac_ip_table_base1;

    /* Ipv6Mac */
    shift[DsMacIpv6Key_e] = tcam_lkp_rst_ctl3.mac_ip_index_shift0;
    idx_base[DsMacIpv6Key_e] = tcam_lkp_rst_ctl3.mac_ip_index_base0;
    tbl_base[DsMacIpv6Key_e] = tcam_lkp_rst_ctl3.mac_ip_table_base0;


    for (list_index = 0; list_index < key_num; list_index++)
    {
        tbl_id = cm_mem_tcam_key_list[list_index];
        drv_tcam_key_get_hw_addr(tbl_id, 0, TRUE, &drv_hw_data_addr);
        drv_tcam_key_get_hw_addr(tbl_id, 0, FALSE, &drv_hw_mask_addr);

        shift_bit   = shift[list_index];
        index_base  = idx_base[list_index];
        table_base  = tbl_base[list_index];

        switch(list_index)
        {
            case DsEthOamKey_e:
            case DsBfdOamKey_e:
            case DsMplsOamLabelKey_e:
            case DsPbtOamKey_e:
            case DsEthOamRmepKey_e:

            case DsMacLearningKey_e:
                continue;
                break;
            case DsLpmTcam160Key_e:
            case DsLpmTcam80Key_e:
            case DsFibUserId80Key_e:
            case DsFibUserId160Key_e:
                rtl_hw_addr = (index_base << 6)*DRV_BYTES_PER_ENTRY + DRV_INT_LPM_TCAM_DATA_ASIC_BASE;
                break;
            default :
                rtl_hw_addr = (index_base << 6)*DRV_BYTES_PER_ENTRY + DRV_INT_TCAM_KEY_DATA_ASIC_BASE;
                break;
        }

        if(rtl_hw_addr != drv_hw_data_addr)
        {
            not_match = TRUE;
            sal_memset(&table_name, 0, sizeof(table_name));
            drv_get_tbl_string_by_id(tbl_id, table_name);
            sal_printf("tcam key %s 0x%x register 0x%x cfg error\n", table_name, drv_hw_data_addr, rtl_hw_addr);
        }

    }

    if(!not_match)
    {
        sal_printf("tcam key register cfg OK!\n");
    }

    return DRV_E_NONE;
}

