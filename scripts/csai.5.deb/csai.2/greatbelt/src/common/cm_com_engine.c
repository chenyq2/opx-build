/***************************************************************************
 * sim_queue.c  provides do_ipe, do_qmgt, do_epe interface engine interface.
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Revision:     V1.0.
 * Author:       Jiang.
 * Date:         2010-11-1.
 * Reason:       First Create.
 *
 * Modify History:
****************************************************************************/
/***************************************************************************
 *
 * Header Files
 *
***************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "ctcutil_lib.h"
#include "cm_lib.h"

/***************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/

/***************************************************************************
 *
 * Global and Declarations
 *
***************************************************************************/
sim_model_t g_sim_model[MAX_LOCAL_CHIP_NUM];
ctckal_queue_t sim_queue[SIM_MAX_Q] = {0};

static ctckal_event_t fwd_done_evt = NULL;
static ctckal_thread_t sim_thread[SIM_MAX_T] = {0};
static ctckal_mutex_t sim_mux[SIM_MAX_M] = {0};

extern list_head_t oam_tx_pkt_list;
extern list_head_t oam_tx_aps_pkt_list;

/***************************************************************************
*
*
* Functions
*
****************************************************************************/
int32
sim_ioctl(uint8 chip_id, int32 index, uint32 cmd, void* val)
{
#if (SDK_WORK_PLATFORM == 1)
    /* check tools, temp code add by zhouw for cosim */
    uint32 data_entry[MAX_ENTRY_WORD] = {0};
    if (!sim_interface_initialize) /* only use on UML */
    {
        /* Check un-cfg in cmodel case */
        /*****************/
    }
    else
    {
        /* CoSim using */
        if (cosim_db.store_table)
        {
            if ((DRV_IOC_OP(cmd) == DRV_IOC_READ)
                && (!drv_table_is_tcam_key(DRV_IOC_MEMID(cmd))))
            {
                if (drv_io_api.drv_sram_tbl_read)
                {
                    DRV_IF_ERROR_RETURN(drv_io_api.drv_sram_tbl_read(chip_id-drv_init_chip_info.drv_init_chipid_base,
                                                DRV_IOC_MEMID(cmd), index, (uint32 *)data_entry));
                }

                DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DRV_IOC_MEMID(cmd), index, data_entry, FALSE));
            }
        }
    }
#endif
    DRV_IF_ERROR_RETURN(drv_ioctl(chip_id, index, cmd, val));
    return DRV_E_NONE;
}


/***************************************************************************
 * Name:       _sim_engine_install
 * Purpose:    install the ipe/epe/fwd/oam engine according to the chipid and chip type
 * Parameters:
 * Input:      chip_id_offset.
 * Output:     None.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_engine_install(uint8 chip_id_offset)
{
    g_sim_model[chip_id_offset].cm_do_ipe = cm_do_ipe;
    g_sim_model[chip_id_offset].cm_do_epe = cm_do_epe;
    g_sim_model[chip_id_offset].cm_do_fwd = cm_do_fwd;
    g_sim_model[chip_id_offset].cm_do_oam = cm_do_oam;
    return DRV_E_NONE;
}


/***************************************************************************
 * Name:       _sim_tcam_install
 * Purpose:    install the tcam IO
 * Parameters:
 * Input:      chip_id_offset.
 * Output:     None.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_tcam_install(uint8 chip_id_offset)
{
#if (SDK_WORK_PLATFORM == 1)
    g_sim_model[chip_id_offset].tcam_init = tcam_model_initialize;
    g_sim_model[chip_id_offset].tcam_lookup = tcam_model_lookup;
#endif
    return DRV_E_NONE;
}


/***************************************************************************
 * Name:       sim_model_component_install
 * Purpose:    install the engine according to the chipid and chip type
 * Parameters:
 * Input:      chip_id_offset.
 * Output:     None.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
sim_model_component_install(uint8 chip_id_offset)
{
    /* install macrx, mactx, chan2mac, mac2chan engine */
    DRV_IF_ERROR_RETURN(sim_mac_install(chip_id_offset));

    /* iinstall ipe,epe,fwd,oam engine */
    DRV_IF_ERROR_RETURN(_sim_engine_install(chip_id_offset));

    /* install tcam init, reset, lookup engine */
    DRV_IF_ERROR_RETURN(_sim_tcam_install(chip_id_offset));

    return DRV_E_NONE;
}

/***************************************************************************
 * Name:       _sim_outpkt2ipkt
 * Purpose:    translate the out_pkt_t type outpkt to ipkt_t type inpkt
 * Parameters:
 * Input:      outpkt pointer.
 * Output:     ipe_in_pkt_t pointer.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_outpkt2ipkt(out_pkt_t *outpkt, ipe_in_pkt_t *inpkt)
{
    inpkt->chip_id = outpkt->chip_id;
    inpkt->chan_id = outpkt->chan_id;
    inpkt->pkt = outpkt->pkt;
    inpkt->pkt_id = outpkt->pkt_id;
    inpkt->packet_length = outpkt->packet_length;

    inpkt->channelinfo_ptpen = outpkt->channelinfo_ptpen; /* ptp use */
    sal_memcpy(&inpkt->module_bus, &outpkt->module_bus, sizeof(outpkt->module_bus));

    return DRV_E_NONE;
}

/***************************************************************************
 * Name:       _sim_outpkt2qpkt
 * Purpose:    translate the out_pkt_t type outpkt to queue_in_pkt_t type inpkt
 * Parameters:
 * Input:      outpkt pointer.
 * Output:     inpkt pointer.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_outpkt2qpkt(out_pkt_t *outpkt, queue_in_pkt_t *inpkt)
{
    inpkt->chip_id = outpkt->chip_id;
    inpkt->chan_id = outpkt->chan_id;
    inpkt->pkt = outpkt->pkt;
    inpkt->pkt_id = outpkt->pkt_id;
    inpkt->packet_length = outpkt->packet_length;
    inpkt->exception = outpkt->exception;
    inpkt->local_phy_port = outpkt->local_phy_port;
    inpkt->from_fabric = outpkt->from_fabric;
    sal_memcpy(&inpkt->module_bus, &outpkt->module_bus, sizeof(outpkt->module_bus));

    return DRV_E_NONE;
}

/***************************************************************************
 * Name:       _sim_outpkt2epkt
 * Purpose:    translate the out_pkt_t type outpkt to epe_in_pkt_t type inpkt
 * Parameters:
 * Input:      outpkt pointer.
 * Output:     inpkt pointer.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_outpkt2epkt(out_pkt_t *outpkt, epe_in_pkt_t *inpkt)
{
    inpkt->chip_id = outpkt->chip_id;
    inpkt->chan_id = outpkt->chan_id;
    inpkt->pkt = outpkt->pkt;
    inpkt->pkt_id = outpkt->pkt_id;
    inpkt->packet_length = outpkt->packet_length;
    sal_memset(&inpkt->ms_net_tx ,0 ,sizeof (inpkt->ms_net_tx));
    sal_memcpy(&inpkt->module_bus, &outpkt->module_bus, sizeof(outpkt->module_bus));

    return DRV_E_NONE;
}

/***************************************************************************
 * Name:       _sim_outpkt2oampkt
 * Purpose:    translate the out_pkt_t type outpkt to oam_in_pkt_t type inpkt
 * Parameters:
 * Input:      outpkt pointer.
 * Output:     inpkt pointer.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_outpkt2oampkt(out_pkt_t *outpkt, oam_in_pkt_t *inpkt)
{
    inpkt->chip_id = outpkt->chip_id;
    inpkt->chan_id = outpkt->chan_id;
    inpkt->pkt = outpkt->pkt;
    inpkt->pkt_id = outpkt->pkt_id;
    inpkt->packet_length = outpkt->packet_length;
    sal_memcpy(&inpkt->module_bus, &outpkt->module_bus, sizeof(outpkt->module_bus));

    return DRV_E_NONE;
}

/***************************************************************************
 * Name:       _sim_ios_ipe_engine
 * Purpose:    implement IPE engine.
 * Parameters:
 * Input:      none.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static void
_sim_ios_ipe_engine(ctckal_thread_t thread, void *user_param)
{
    int32 ret = DRV_E_NONE, size = 0;
    ipe_in_pkt_t in_pkt;
    out_pkt_t recv_pkt, *out_pkt = NULL;
    list_head_t out_pkt_head, *pos = NULL;

    INIT_LIST_HEAD(&out_pkt_head);
    size = sizeof(recv_pkt);

    for (;;)
    {
        if (CTCKAL_SUCCESS != ctckal_queue_receive(sim_queue[SIM_IPE_Q], (void *)&recv_pkt, (uint32 *)&size, QUE_TIMEOUT_INFINITE))
        {
            CMODEL_DEBUG_OUT_INFO("Receive IPE input packet error!\n");
            continue;
        }

        ret = _sim_outpkt2ipkt(&recv_pkt, &in_pkt);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("IPE engine received invalid packet!\n");
        }
        sal_free(recv_pkt.exception);
        recv_pkt.exception = NULL;

        ret = sim_asic_gen_ipe_inpkt(&in_pkt);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("Failed to generate asic ipe inpkt\n");
        }

        ret = cm_do_ipe(&in_pkt, &out_pkt_head);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("cm_do_ipe error, ret = %d!\n", ret);
        }

        list_for_each(pos, &out_pkt_head)
        {
            out_pkt = list_entry(pos, out_pkt_t, head);

            ret = ctckal_queue_send(sim_queue[out_pkt->dest_queue], (void *)out_pkt, sizeof(*out_pkt));
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("IPE engine send packet to queue error ! ret = %d\n", ret);
                sal_free(out_pkt->pkt);
                out_pkt->pkt = NULL;

                sal_free(out_pkt->exception);
                out_pkt->exception= NULL;
            }
        }

        list_del_all_and_free(&out_pkt_head);
    }
}


/***************************************************************************
 * Name:       _sim_ios_fwd_engine
 * Purpose:    implement QMGT engine.
 * Parameters:
 * Input:      none.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
*****************************************************************************/
static void _sim_ios_fwd_engine(ctckal_thread_t thread, void *user_param)
{
    int32 ret = DRV_E_NONE, size = 0;
    queue_in_pkt_t in_pkt;
    list_head_t out_pkt_head, *pos = NULL;
    out_pkt_t recv_pkt, *out_pkt = NULL;

    INIT_LIST_HEAD(&out_pkt_head);
    size = sizeof(recv_pkt);

    for (;;)
    {
        if(CTCKAL_SUCCESS != ctckal_queue_receive(sim_queue[SIM_FWD_Q], (void *)&recv_pkt, (uint32 *)&size, QUE_TIMEOUT_INFINITE))
        {
            CMODEL_DEBUG_OUT_INFO("receive fwd input packet error!\n");
            continue;
        }

        ret = _sim_outpkt2qpkt(&recv_pkt, &in_pkt);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("FWD engine received invalid packet! ret = %d!\n", ret);
        }

        ret = cm_do_fwd(&in_pkt, &out_pkt_head, NULL);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("cm_do_fwd error, ret = %d!\n", ret);
        }

        list_for_each(pos, &out_pkt_head)
        {
            out_pkt = list_entry(pos, out_pkt_t, head);
            ret = ctckal_queue_send(sim_queue[out_pkt->dest_queue], (void *)out_pkt, sizeof(*out_pkt));
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("FWD engine send outpkt to queue error ! ret = %d\n", ret);
                sal_free(out_pkt->pkt);
                out_pkt->pkt = NULL;

                sal_free(out_pkt->exception);
                out_pkt->exception = NULL;
            }
        }

        list_del_all_and_free(&out_pkt_head);
    }
}


/***************************************************************************
 * Name:       _sim_ios_epe_engine
 * Purpose:    implement EPE engine.
 * Parameters:
 * Input:      none.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
*****************************************************************************/
static void _sim_ios_epe_engine(ctckal_thread_t thread, void *user_param)
{
    int32 ret = DRV_E_NONE, size = 0;
    epe_in_pkt_t in_pkt;
    list_head_t out_pkt_head, *pos = NULL;
    out_pkt_t recv_pkt, *out_pkt = NULL;

    INIT_LIST_HEAD(&out_pkt_head);
    size = sizeof(recv_pkt);

    for (;;)
    {
        if (CTCKAL_SUCCESS != ctckal_queue_receive(sim_queue[SIM_EPE_Q], (void *)&recv_pkt, (uint32 *)&size, QUE_TIMEOUT_INFINITE))
        {
            CMODEL_DEBUG_OUT_INFO("EPE engine receive input packet error!\n");
            continue;
        }

        sal_memset(&in_pkt,0,sizeof(in_pkt));

        ret = _sim_outpkt2epkt(&recv_pkt, &in_pkt);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("EPE received invalid packet! ret = %d!\n", ret);
        }
        sal_free(recv_pkt.exception);
        recv_pkt.exception = NULL;

        ret = cm_do_epe(&in_pkt, &out_pkt_head);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("cm_do_epe error, ret = %d!\n", ret);
        }

        list_for_each(pos, &out_pkt_head)
        {
            out_pkt = list_entry(pos, out_pkt_t, head);

            ret = ctckal_queue_send(sim_queue[out_pkt->dest_queue], (void *)out_pkt, sizeof(*out_pkt));
            if(DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("EPE engine send outpkt to queue error ! ret = %d\n", ret);
                sal_free(out_pkt->pkt);
                out_pkt->pkt = NULL;

                sal_free(out_pkt->exception);
                out_pkt->exception = NULL;
            }
        }

        list_del_all_and_free(&out_pkt_head);
    }
}


/*********************************************************************
 * Name:     _sim_ios_oam_engine
 * Purpose:  handle oam pkt and transparent relay normal pkt(to cpu or fwd)
 * Parameters:
 * Input:    none.
 * Output:   none.
 * Return:   DRV_E_NONE = success.
 *           Other = Error, please refer to DRV_E_XXX.
 * Note:     none.
**********************************************************************/
static void _sim_ios_oam_engine(ctckal_thread_t thread, void *user_param)
{
    int32 size, ret;
    oam_in_pkt_t in_pkt;
    list_head_t   out_pkt_head, *pos;
    out_pkt_t     recv_pkt, *out_pkt;
#if 0
    uint32    mux_type;
#endif

    INIT_LIST_HEAD(&out_pkt_head);
    size = sizeof(out_pkt_t);

    for (;;)
    {
        ret = ctckal_queue_receive(sim_queue[SIM_OAM_Q], (void *)&recv_pkt, (uint32 *)&size, QUE_TIMEOUT_INFINITE);
        if (CTCKAL_SUCCESS != ret)
        {
            CMODEL_DEBUG_OUT_INFO("OAM engine receives input packet error!\n");
            continue;
        }

        if (CPU_CHANID  == recv_pkt.chan_id)
        {
            ret = ctckal_queue_send(sim_queue[SIM_NETTX_Q], (void *)&recv_pkt, sizeof(recv_pkt));
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("OAM send  packet normal packet to cpu error!\n");
            }
            continue;
        }
        else   //(CPU_OAM_CHAN_ID == recv_pkt.chan_id )
        {
            ret = _sim_outpkt2oampkt(&recv_pkt, &in_pkt);
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("OAM received invalid packet!\n");
            }
            sal_free(recv_pkt.exception);
            recv_pkt.exception = NULL;

            if ((ret = sim_asic_gen_oam_inpkt(&in_pkt)) < 0)
            {
                CMODEL_DEBUG_OUT_INFO("Failed to generate asic epe inpkt\n");
            }

            ret = cm_do_oam(&in_pkt, &out_pkt_head);
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("cm_do_oam error, ret = %d!\n", (int)ret);
            }

            list_for_each(pos, &out_pkt_head)
            {
                out_pkt = list_entry(pos, out_pkt_t, head);
#if 0
                mux_type = _sim_queuetype2muxtype(out_pkt->dest_queue);
                incr_sim_rcd(mux_type);
#endif
                ret = sim_oam_output_packet(out_pkt->pkt, out_pkt->packet_length,
                                           out_pkt->chip_id, out_pkt->chan_id);

                ret = ctckal_queue_send(sim_queue[out_pkt->dest_queue], (void *)out_pkt, sizeof(*out_pkt));
                if(DRV_E_NONE != ret)
                {
                    CMODEL_DEBUG_OUT_INFO("OAM engine send outpkt to queue error! ret = %d\n", ret);
                    sal_free(out_pkt->pkt);
                    out_pkt->pkt = NULL;
                    sal_free(out_pkt->exception);
                    out_pkt->exception = NULL;
#if 0
                    decrease_sim_rcd(mux_type);
#endif
                }
            }

            list_del_all_and_free(&out_pkt_head);
#if 0
            decrease_sim_rcd(SIM_OAM_M);
#endif
            /* _sim_fwd_done_event_trigger(); */
        }
    }

}


/****************************************************************************
 * Name:       _sim_get_pkt_from_asic_file
 * Purpose:    show forward use, get packet from inpkt store file.
 * Parameters:
 * Input:      none.
 * Output:     none.
 * Return:     ipkt.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_sim_get_pkt_from_asic_file(FILE* p_file, ipe_in_pkt_t* ipkt)
{
    static char pkt_line[128] = {0};
    uint32 line_num = 0;
    int32 lidx = 0, cidx = 0, tmp_len = 0, tmp_chan = 0, tmp_chip = 0, tmp_val = 0;

    if (NULL == p_file || NULL == ipkt)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    ipkt->pkt = sal_malloc(MTU);
    sal_memset(ipkt->pkt, 0, MTU);

    ipkt->packet_length = 0;

    while (NULL != fgets(pkt_line, 128, p_file))
    {
        if (' ' == pkt_line[0])
        {
            continue;
        }

        if (3 == sal_sscanf(pkt_line, "pkt %d %d %d", &tmp_len, &tmp_chan, &tmp_chip))
        {
            ipkt->packet_length = tmp_len;
            ipkt->chan_id = tmp_chan;
            ipkt->chip_id = tmp_chip;
            line_num = ipkt->packet_length / 16 + 1;

            for (lidx = 0; lidx < line_num; ++lidx)
            {
                sal_memset(pkt_line, 0, 128);

                if (NULL == fgets(pkt_line, 128, p_file))
                {
                    return ipkt->packet_length;
                }

                for (cidx= 0; cidx < 16; cidx++)
                {
                    if (1 == sal_sscanf(pkt_line + cidx * 2, "%02x", &tmp_val))
                    {
                        ipkt->pkt[lidx * 16 + cidx] = tmp_val;
                    }
                    else
                    {
                        break;
                    }
                }
            }

            return ipkt->packet_length;
        }

        sal_memset(pkt_line, 0, 128);
    }

    return 0;
}

/***************************************************************************
 * Name:        sim_emu_show_fwd_lbk_humber
 * Purpose:     emulation show forward debug.
 * Parameters:
 * Input:       inpkt_file, outpkt_file.
 * Output:      outpkt_file.
 * Return:      DRV_E_NONE = success.
 *              Other = Error, please refer to DRV_E_XXX.
 * Note:        none.
 *
 * Author:      YangZL.
 * Date:        2008.12.09
 *
 * Reviser:     XuZX
 * Date:        2010.4.23
 * Note:        Not support iloop, eloop
****************************************************************************/
int32
sim_emu_show_fwd_lbk_humber(uint8 *inpkt_file, char *outpkt_file)
{
#define LOOPBACK_PHY_PORT   30
#define CPU_PHY_PORT        31

    ipe_in_pkt_t cpkt;
    queue_in_pkt_t qpkt_ipe;
    epe_in_pkt_t epkt;
    oam_in_pkt_t oam_pkt;

    list_head_t ipe_out_pkt_head;
    list_head_t epe_out_pkt_head;
    list_head_t oam_out_pkt_head;
    list_head_t fwd_out_pkt_head;

    list_head_t *pos_ipe = NULL;
    list_head_t *pos_fwd = NULL;
    list_head_t *pos_oam = NULL;
    list_head_t *pos_epe = NULL;

    int32 ret = DRV_E_NONE;
    out_pkt_t *ipe_out_pkt = NULL;
    out_pkt_t *epe_out_pkt = NULL;
    out_pkt_t *fwd_out_pkt = NULL;
    out_pkt_t *oam_out_pkt = NULL;

    FILE *aisc_ipe_inpkt = NULL;

    /* reset pakcet informations */
    sal_memset(&qpkt_ipe, 0, sizeof(queue_in_pkt_t));
    sal_memset(&cpkt, 0, sizeof(ipe_in_pkt_t));
    sal_memset(&epkt, 0, sizeof(epe_in_pkt_t));
    sal_memset(&oam_pkt, 0, sizeof(oam_in_pkt_t));

    INIT_LIST_HEAD(&fwd_out_pkt_head);
    INIT_LIST_HEAD(&ipe_out_pkt_head);
    INIT_LIST_HEAD(&epe_out_pkt_head);
    INIT_LIST_HEAD(&oam_out_pkt_head);

    aisc_ipe_inpkt = fopen((char *)inpkt_file, "r");
    if (NULL == aisc_ipe_inpkt)
    {
        CMODEL_DEBUG_OUT_INFO("open input file error!\n");
        return 0;
    }

    /* set outpkt */
    ret = sim_store_outpkt_filename(outpkt_file);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("sim_store_outpkt_filename: error = %d\n", (int)ret);
        return ret;
    }

    /* cycle for packet processing */
    while(_sim_get_pkt_from_asic_file(aisc_ipe_inpkt, &cpkt))
    {
        if (CPU_CHANID != cpkt.chan_id || OAM_CHANID != cpkt.chan_id)
        {
             /* generate ASIC ASCII packet */
            DRV_IF_ERROR_RETURN(sim_asic_gen_ipe_inpkt(&cpkt));

            ret = cm_do_ipe(&cpkt, &ipe_out_pkt_head);
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("cm_do_ipe error = %d!\n", (int)ret);
                goto FREE_MEM_RSC;
            }
        }
        else
        {
            ipe_out_pkt = sal_malloc(sizeof(out_pkt_t));

            if (NULL == ipe_out_pkt)
            {
                CMODEL_DEBUG_OUT_INFO("No memory in sim_emu_show_fwd!\n");
                goto FREE_MEM_RSC;
            }

            sal_memset(ipe_out_pkt, 0, sizeof(out_pkt_t));

            /* mallocate packet information memory */
            qpkt_ipe.pkt = cpkt.pkt;
            cpkt.pkt = NULL;

            /* copy packet */
            qpkt_ipe.packet_length = cpkt.packet_length;
            qpkt_ipe.chip_id = cpkt.chip_id;
            qpkt_ipe.pkt_id = cpkt.pkt_id;
            qpkt_ipe.chan_id = cpkt.chan_id;
            qpkt_ipe.local_phy_port = CPU_PHY_PORT;   /* used for group id assignment */

            ipe_out_pkt->exception = sal_malloc(HUMBER_EXCEPTION_LEN);
            if (NULL == ipe_out_pkt->exception)
            {
                CMODEL_DEBUG_OUT_INFO("No memory in sim_emu_show_fwd!\n");
                goto FREE_MEM_RSC;
            }
            sal_memset(ipe_out_pkt->exception, 0, HUMBER_EXCEPTION_LEN);

            ipe_out_pkt->packet_length = cpkt.packet_length + HUMBER_HEADER_LEN;
            ipe_out_pkt->chan_id = cpkt.chan_id;
            ipe_out_pkt->chip_id = cpkt.chip_id;
            ipe_out_pkt->pkt_id = cpkt.pkt_id;
            ipe_out_pkt->dest_queue = SIM_FWD_Q;
            ipe_out_pkt->local_phy_port = CPU_RESOURCE_GROUPID;
            ipe_out_pkt->pkt = cpkt.pkt;
            list_add_tail(&ipe_out_pkt->head, &ipe_out_pkt_head);
        }

        /* FWD handle */
        list_for_each(pos_ipe, &ipe_out_pkt_head)
        {
            ipe_out_pkt = list_entry(pos_ipe, out_pkt_t, head);
            if (NULL == ipe_out_pkt->pkt)
            {
                CMODEL_DEBUG_OUT_INFO("packet hard discard!\n");
                goto FREE_MEM_RSC;
            }

            ret = _sim_outpkt2qpkt(ipe_out_pkt, &qpkt_ipe);

            ipe_out_pkt->pkt = NULL;
            ipe_out_pkt->exception = NULL;

            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("_sim_outpkt2qpkt error!\n");
                goto FREE_MEM_RSC;
            }

            ret = cm_do_fwd(&qpkt_ipe, &fwd_out_pkt_head, NULL);
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("cm_do_fwd error = %d!\n", (int)ret);
                goto FREE_MEM_RSC;
            }

            /* EPE handle */
            list_for_each(pos_fwd, &fwd_out_pkt_head)
            {
                fwd_out_pkt = list_entry(pos_fwd, out_pkt_t, head);
                if (fwd_out_pkt->dest_queue == SIM_EPE_Q)
                {
                    _sim_outpkt2epkt(fwd_out_pkt, &epkt);

                    fwd_out_pkt->pkt = NULL;
                    fwd_out_pkt->exception = NULL;

                    ret = cm_do_epe(&epkt, &epe_out_pkt_head);
                    if (DRV_E_NONE != ret)
                    {
                        CMODEL_DEBUG_OUT_INFO("cm_do_epe error, ret = %d!\n", (int)ret);
                        goto FREE_MEM_RSC;
                    }
                }
                else if (fwd_out_pkt->dest_queue == SIM_OAM_Q )
                {
                    _sim_outpkt2oampkt(fwd_out_pkt, &oam_pkt);

                    fwd_out_pkt->pkt = NULL;
                    fwd_out_pkt->exception = NULL;

                    ret = cm_do_oam(&oam_pkt, &oam_out_pkt_head);
                    if (DRV_E_NONE != ret)
                    {
                        CMODEL_DEBUG_OUT_INFO("OAM cm_do_oam error! ret = %d\n", ret);
                        goto FREE_MEM_RSC;
                    }

                    list_for_each(pos_oam, &oam_out_pkt_head)
                    {
                        oam_out_pkt = list_entry(pos_oam, out_pkt_t, head);
                        if (SIM_NETTX_Q == oam_out_pkt->dest_queue)
                        {
                            CMODEL_DEBUG_OUT_INFO("OAM cm_do_oam send packet to cpu!\n");
                            ret = sim_output_packet(oam_out_pkt->pkt, oam_out_pkt->packet_length,
                                                    oam_out_pkt->chip_id, oam_out_pkt->chan_id);
                            if (DRV_E_NONE != ret)
                            {
                                CMODEL_DEBUG_OUT_INFO("sim_output_packet error, ret = %d!\n", (int)ret);
                                goto FREE_MEM_RSC;
                            }
                        }
                        else if (SIM_FWD_Q == oam_out_pkt->dest_queue)
                        {
                            CMODEL_DEBUG_OUT_INFO("OAM engine send the packet to fwd!\n");
                            continue;
                        }
                        if (DRV_E_NONE != ret)
                        {
                            CMODEL_DEBUG_OUT_INFO("OAM engine send outpkt to queue error ! ret = %d\n", ret);
                            goto FREE_MEM_RSC;
                        }
                    }
                }

                if (DRV_E_NONE != ret)
                {
                    CMODEL_DEBUG_OUT_INFO("FWD engine send outpkt to queue error ! ret = %d\n", ret);
                    goto FREE_MEM_RSC;
                }
            }
        }

FREE_MEM_RSC:
        list_for_each(pos_epe,  &epe_out_pkt_head)
        {
            epe_out_pkt = list_entry(pos_epe, out_pkt_t, head);
            if (NULL != epe_out_pkt)
            {
                if (epe_out_pkt->pkt)
                {
                    sal_free(epe_out_pkt->pkt);
                    epe_out_pkt->pkt = NULL;
                }

                if (epe_out_pkt->exception)
                {
                    sal_free(epe_out_pkt->exception);
                    epe_out_pkt->exception = NULL;
                }
            }
        }

        list_for_each(pos_oam, &oam_out_pkt_head)
        {
            oam_out_pkt = list_entry(pos_oam, out_pkt_t, head);
            if (NULL != oam_out_pkt)
            {
                if (oam_out_pkt->pkt)
                {
                    sal_free(oam_out_pkt->pkt);
                    oam_out_pkt->pkt = NULL;
                }
                if (oam_out_pkt->exception)
                {
                    sal_free(oam_out_pkt->exception);
                    oam_out_pkt->exception = NULL;
                }
            }
        }

        list_for_each(pos_fwd, &fwd_out_pkt_head)
        {
            fwd_out_pkt = list_entry(pos_fwd, out_pkt_t, head);
            if (NULL != fwd_out_pkt)
            {
                if (fwd_out_pkt->pkt)
                {
                    sal_free(fwd_out_pkt->pkt);
                    fwd_out_pkt->pkt = NULL;
                }

                if (fwd_out_pkt->exception)
                {
                    sal_free(fwd_out_pkt->exception);
                    fwd_out_pkt->exception = NULL;
                }
            }
        }

        list_for_each(pos_ipe, &ipe_out_pkt_head)
        {
            ipe_out_pkt = list_entry(pos_ipe, out_pkt_t, head);
            if (NULL != ipe_out_pkt)
            {
                if (ipe_out_pkt->pkt)
                {
                    sal_free(ipe_out_pkt->pkt);
                    ipe_out_pkt->pkt = NULL;
                }

                if (ipe_out_pkt->exception)
                {
                    sal_free(ipe_out_pkt->exception);
                    ipe_out_pkt->exception = NULL;
                }
            }
        }

        list_del_all_and_free(&fwd_out_pkt_head);
        list_del_all_and_free(&epe_out_pkt_head);
        list_del_all_and_free(&ipe_out_pkt_head);
        list_del_all_and_free(&oam_out_pkt_head);
    }

    if (NULL != aisc_ipe_inpkt)
    {
        fclose(aisc_ipe_inpkt);
        aisc_ipe_inpkt = NULL;
    }

    return ret;
}


/***************************************************************************
 * Name:       sim_ios_set_enable
 * Purpose:    initialize some do forward queue objects.
 * Parameters:
 * Input:      enable -- TRUE = enable, and FALSE = disable.
 * Output:     N/A.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
*****************************************************************************/
int32
sim_ios_set_enable(uint8 enable)
{
    uint32 attr = 0;
    uint32 i = 0;

    if (enable)
    {
        /* create do forward complete event */
        if (NULL == fwd_done_evt)
        {
            DRV_IF_ERROR_RETURN(ctckal_event_create(&fwd_done_evt, ATTR_AUTO_RESET));
        }

        for (i = 0; i < SIM_MAX_Q; i ++)
        {
            if (0 == sim_queue[i])
            {
                DRV_IF_ERROR_RETURN(ctckal_queue_create(&sim_queue[i]));
            }
        }

        for (i = 0; i < SIM_MAX_M; i ++)
        {
            if (0 == sim_mux[i])
            {
                DRV_IF_ERROR_RETURN(ctckal_mutex_create(&sim_mux[i]));
            }
        }

        if (0 == sim_thread[SIM_NETTX_T])
        {
            DRV_IF_ERROR_RETURN(ctckal_thread_create(&sim_thread[SIM_NETTX_T], (void*)&attr,
                                            swemu_ios_nettx_engine, NULL));
        }

        if (0 == sim_thread[SIM_EPE_T])
        {
            DRV_IF_ERROR_RETURN(ctckal_thread_create(&sim_thread[SIM_EPE_T], (void*)&attr,
                                            _sim_ios_epe_engine, NULL));
        }

        if (0 == sim_thread[SIM_OAM_T])
        {
            DRV_IF_ERROR_RETURN(ctckal_thread_create(&sim_thread[SIM_OAM_T], (void*)&attr,
                                            _sim_ios_oam_engine, NULL));
        }

        if (0 == sim_thread[SIM_FWD_T])
        {
            DRV_IF_ERROR_RETURN(ctckal_thread_create(&sim_thread[SIM_FWD_T], (void*)&attr,
                                            _sim_ios_fwd_engine, NULL));
        }

        if (0 == sim_thread[SIM_IPE_T])
        {
            DRV_IF_ERROR_RETURN(ctckal_thread_create(&sim_thread[SIM_IPE_T], (void*)&attr,
                                            _sim_ios_ipe_engine, NULL));
        }

        if (0 == sim_thread[SIM_NETRX_T])
        {
            DRV_IF_ERROR_RETURN(ctckal_thread_create(&sim_thread[SIM_NETRX_T], (void*)&attr,
                                            swemu_ios_netrx_engine, NULL));
        }
    }
    else
    {
        for (i = 0; i < SIM_MAX_T; i ++)
        {
            ctckal_thread_destroy(sim_thread[i]);
            sim_thread[i] = 0;
        }

        for (i = 0; i < SIM_MAX_Q; i ++)
        {
            ctckal_queue_destroy(sim_queue[i]);
            sim_queue[i] = 0;
        }

        for (i = 0; i < SIM_MAX_M; i ++)
        {
            ctckal_mutex_destroy(sim_mux[i]);
            sim_mux[i] = 0;
        }
    }

    cm_com_sysengine_enable(enable);

    return DRV_E_NONE;
}


