/****************************************************************************
 * cm_com_hash.c  All error code Deinfines, include SDK error code.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     v1.0.
 * Author:       XuZx
 * Date:         2010-12-3.
 * Reason:       Create for GreatBelt.
 *
 * Revision:     v4.7.1
 * Revisor:      XuZx
 * Date:         2011-7-29.
 * Reason:       Revise for Specs v4.7.1.
 *
 * Revision:     v4.28.2
 * Revisor:      XuZx
 * Date:         2011-9-27.
 * Reason:       Revise for Specs v4.28.2.
 *
 * Revision:     V5.1.0
 * Revisor:      XuZx
 * Date:         2011-12-12.
 * Reason:       Revise for GreatBelt v5.1.0.
 *
 * Revision:     v5.7.0
 * Revisor:      XuZx
 * Date:         2012-01-17.
 * Reason:       Revise for GreatBelt v5.7.0
 ****************************************************************************/

#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "ctcutil_lib.h"

static int32
_cm_com_fib_lookup_engine_perform_hash_lookup(uint8 chip_id,
                                              fib_key_t* p_fib_key,
                                              fib_key_type_t fib_key_type,
                                              lookup_result_t* p_lookup_result)
{
    lookup_info_t lookup_info;
    uint32 cmd = 0;

    ds_mac_hash_key_t ds_mac_hash_key;
    ds_fcoe_hash_key_t ds_fcoe_hash_key;
    ds_fcoe_rpf_hash_key_t ds_fcoe_rpf_hash_key;
    ds_trill_ucast_hash_key_t ds_trill_ucast_hash_key;
    ds_trill_mcast_hash_key_t ds_trill_mcast_hash_key;
    ds_trill_mcast_vlan_hash_key_t trill_mcast_vlan_hash_key;
    ds_acl_qos_mac_hash_key_t ds_acl_qos_mac_hash_key;
    ds_acl_qos_ipv4_hash_key_t ds_acl_qos_ipv4_hash_key;

    fib_engine_lookup_result_ctl_t fib_engine_lookup_result_ctl;
    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;

    sal_memset(&ds_mac_hash_key, 0, sizeof(ds_mac_hash_key_t));
    sal_memset(&ds_fcoe_hash_key, 0, sizeof(ds_fcoe_hash_key_t));
    sal_memset(&ds_fcoe_rpf_hash_key, 0, sizeof(ds_fcoe_rpf_hash_key_t));
    sal_memset(&ds_trill_ucast_hash_key, 0, sizeof(ds_trill_ucast_hash_key_t));
    sal_memset(&ds_trill_mcast_hash_key, 0, sizeof(ds_trill_mcast_hash_key_t));
    sal_memset(&trill_mcast_vlan_hash_key, 0, sizeof(ds_trill_mcast_vlan_hash_key_t));
    sal_memset(&ds_acl_qos_mac_hash_key, 0, sizeof(ds_acl_qos_mac_hash_key_t));
    sal_memset(&ds_acl_qos_ipv4_hash_key, 0, sizeof(ds_acl_qos_ipv4_hash_key_t));

    sal_memset(&fib_engine_lookup_result_ctl, 0, sizeof(fib_engine_lookup_result_ctl_t));
    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));

    /* Construct FIB hash Lookup Input structure */
    sal_memset(&lookup_info, 0, sizeof(lookup_info));

    cmd = DRV_IOR(FibEngineLookupResultCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_result_ctl));

    lookup_info.chip_id = chip_id;
    lookup_info.hash_type = fib_key_type;
    lookup_info.hash_module = HASH_MODULE_FIB;

    switch (fib_key_type)
    {
        case FIB_KEY_TYPE_MAC_DA:
        case FIB_KEY_TYPE_MAC_SA:
            /* MAC DA/SA, DsMacHashKey */
            ds_mac_hash_key.valid = TRUE;
            ds_mac_hash_key.is_mac_hash = TRUE;
            ds_mac_hash_key.mapped_mac47_32 = p_fib_key->key.mac.mapped_mac47_32;
            ds_mac_hash_key.mapped_mac31_0 = p_fib_key->key.mac.mapped_mac31_0;

            if (fib_engine_lookup_result_ctl.ad_bits_type)
            {
                ds_mac_hash_key.vsi_id = p_fib_key->id.vsi_id & 0x1FFF;
            }
            else
            {
                ds_mac_hash_key.vsi_id = p_fib_key->id.vsi_id;
            }
            lookup_info.hash_type = FIB_HASH_TYPE_MAC;
            lookup_info.p_ds_key = &ds_mac_hash_key;
            break;

        case FIB_KEY_TYPE_FCOE:
            /* FCoE, DsFcoeHashKey */
            ds_fcoe_hash_key.valid = TRUE;
            ds_fcoe_hash_key.fcoe_did = p_fib_key->key.fcoe.fcoe_did;
            ds_fcoe_hash_key.vsi_id = p_fib_key->id.vsi_id;
            ds_fcoe_hash_key.hash_type_low = fib_key_type & 0x1;
            ds_fcoe_hash_key.hash_type_high = (fib_key_type >> 1) & 0x7;
            lookup_info.hash_type = FIB_HASH_TYPE_FCOE;
            lookup_info.p_ds_key = &ds_fcoe_hash_key;
            break;

        case FIB_KEY_TYPE_FCOE_RPF:
            /* FCoE RPF, DsFcoeRpfHashKey */
            ds_fcoe_rpf_hash_key.valid = TRUE;
            ds_fcoe_rpf_hash_key.fcoe_sid = p_fib_key->key.fcoe_rpf.fcoe_sid;
            ds_fcoe_rpf_hash_key.vsi_id = p_fib_key->id.vsi_id;
            ds_fcoe_rpf_hash_key.hash_type_low = fib_key_type & 0x1;
            ds_fcoe_rpf_hash_key.hash_type_high = (fib_key_type >> 1) & 0x7;
            lookup_info.hash_type = FIB_HASH_TYPE_FCOE_RPF;
            lookup_info.p_ds_key = &ds_fcoe_rpf_hash_key;
            break;

        case FIB_KEY_TYPE_TRILL_UCAST:
            /* TRILL Ucast, DsTrillUcastHashKey */
            ds_trill_ucast_hash_key.valid = TRUE;
            ds_trill_ucast_hash_key.hash_type_low = fib_key_type & 0x1;
            ds_trill_ucast_hash_key.hash_type_high = (fib_key_type >> 1) & 0x7;
            ds_trill_ucast_hash_key.egress_nickname = p_fib_key->key.trill_ucast.egress_nickname;
            lookup_info.hash_type = FIB_HASH_TYPE_TRILL_UCAST;
            lookup_info.p_ds_key = &ds_trill_ucast_hash_key;
            break;

        case FIB_KEY_TYPE_TRILL_MCAST:
            /* TRILL Mcast, DsTrillMcastHashKey */
            ds_trill_mcast_hash_key.valid = TRUE;
            ds_trill_mcast_hash_key.hash_type_low = fib_key_type & 0x1;
            ds_trill_mcast_hash_key.hash_type_high = (fib_key_type >> 1) & 0x7;
            ds_trill_mcast_hash_key.egress_nickname = p_fib_key->key.trill_mcast.egress_nickname;
            lookup_info.hash_type = FIB_HASH_TYPE_TRILL_MCAST;
            lookup_info.p_ds_key = &ds_trill_mcast_hash_key;
            break;

        case FIB_KEY_TYPE_TRILL_MCAST_VLAN:
            /* TRILL Mcast VLAN, DsTrillMcastVlanHashKey */
            trill_mcast_vlan_hash_key.valid = TRUE;
            trill_mcast_vlan_hash_key.vlan_id = p_fib_key->key.trill_mcast_vlan.vlan_id;
            trill_mcast_vlan_hash_key.hash_type_low = fib_key_type & 0x1;
            trill_mcast_vlan_hash_key.hash_type_high = (fib_key_type >> 1) & 0x7;
            trill_mcast_vlan_hash_key.egress_nickname = p_fib_key->key.trill_mcast_vlan.egress_nickname;
            lookup_info.hash_type = FIB_HASH_TYPE_TRILL_MCAST_VLAN;
            lookup_info.p_ds_key = &trill_mcast_vlan_hash_key;
            break;

        default:
            /* ACL, DsAclQosMacHashKey, DsAclQosIpv4HashKey */
            cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_ctl));

            if (!p_fib_key->key.acl.is_ipv4_key)
            {
                ds_acl_qos_mac_hash_key.valid0 = TRUE;
                ds_acl_qos_mac_hash_key.valid1 = TRUE;
                ds_acl_qos_mac_hash_key.hash_type0_low = fib_key_type & 0x1;
                ds_acl_qos_mac_hash_key.hash_type0_high = (fib_key_type >> 1) & 0x7;
                ds_acl_qos_mac_hash_key.hash_type1_low = fib_key_type & 0x1;
                ds_acl_qos_mac_hash_key.hash_type1_high = (fib_key_type >> 1) & 0x7;
                ds_acl_qos_mac_hash_key.is_mac_hash0 = FALSE;
                ds_acl_qos_mac_hash_key.is_mac_hash1 = FALSE;
                ds_acl_qos_mac_hash_key.is_ipv4_key = FALSE;

                if (!p_fib_key->key.acl.is_logic_port)
                {
                    if (fib_engine_lookup_ctl.mac_acl_src_phy_port_en)
                    {
                        /* p_fib_key->key.acl.global_src_port is global_src_port or logicSrcPort in lookup manager */
                        ds_acl_qos_mac_hash_key.global_src_port10_0 = p_fib_key->key.acl.global_src_port & 0x7FF;
                        ds_acl_qos_mac_hash_key.global_src_port13_11 = (p_fib_key->key.acl.global_src_port >> 11) & 0x7;
                        ds_acl_qos_mac_hash_key.is_logic_port = p_fib_key->key.acl.is_logic_port;
                    }
                    else
                    {
                        ds_acl_qos_mac_hash_key.global_src_port10_0 = 0;
                        ds_acl_qos_mac_hash_key.global_src_port13_11 = 0;
                        ds_acl_qos_mac_hash_key.is_logic_port = 0;
                    }
                }
                else
                {
                    if (fib_engine_lookup_ctl.mac_acl_src_logic_port_en)
                    {
                        /* p_fib_key->key.acl.global_src_port is global_src_port or logicSrcPort in lookup manager */
                        ds_acl_qos_mac_hash_key.global_src_port10_0 = p_fib_key->key.acl.global_src_port & 0x7FF;
                        ds_acl_qos_mac_hash_key.global_src_port13_11 = (p_fib_key->key.acl.global_src_port >> 11) & 0x7;
                        ds_acl_qos_mac_hash_key.is_logic_port = p_fib_key->key.acl.is_logic_port;
                    }
                    else
                    {
                        ds_acl_qos_mac_hash_key.global_src_port10_0 = 0;
                        ds_acl_qos_mac_hash_key.global_src_port13_11 = 0;
                        ds_acl_qos_mac_hash_key.is_logic_port = 0;
                    }
                }

                if (fib_engine_lookup_ctl.mac_acl_mac_da_en)
                {
                    ds_acl_qos_mac_hash_key.mac_da31_0 = p_fib_key->key.acl.mapped_mac31_0;
                    ds_acl_qos_mac_hash_key.mac_da47_32 = p_fib_key->key.acl.mapped_mac47_32;
                }
                else
                {
                    ds_acl_qos_mac_hash_key.mac_da31_0 = 0;
                    ds_acl_qos_mac_hash_key.mac_da47_32 = 0;
                }

                if (fib_engine_lookup_ctl.mac_acl_ether_type_en)
                {
                    ds_acl_qos_mac_hash_key.ether_type11_0 = p_fib_key->key.acl.ether_type;
                    ds_acl_qos_mac_hash_key.ether_type15_12 = (p_fib_key->key.acl.ether_type >> 12) & 0xF;
                }
                else
                {
                    ds_acl_qos_mac_hash_key.ether_type11_0 = 0;
                    ds_acl_qos_mac_hash_key.ether_type15_12 = 0;
                }

                if (fib_engine_lookup_ctl.mac_acl_vlan_id_en)
                {
                    ds_acl_qos_mac_hash_key.vlan_id = p_fib_key->key.acl.vlan_id;
                }
                else
                {
                    ds_acl_qos_mac_hash_key.vlan_id = 0;
                }

                if (fib_engine_lookup_ctl.mac_acl_cos_en)
                {
                    ds_acl_qos_mac_hash_key.cos = p_fib_key->key.acl.cos;
                }
                else
                {
                    ds_acl_qos_mac_hash_key.cos = 0;
                }

                lookup_info.hash_type = FIB_HASH_TYPE_ACL_MAC;
                lookup_info.p_ds_key = &ds_acl_qos_mac_hash_key;
            }
            else
            {
                ds_acl_qos_ipv4_hash_key.valid0 = TRUE;
                ds_acl_qos_ipv4_hash_key.valid1 = TRUE;
                ds_acl_qos_ipv4_hash_key.hash_type0_low = fib_key_type & 0x1;
                ds_acl_qos_ipv4_hash_key.hash_type0_high = (fib_key_type >> 1) & 0x7;
                ds_acl_qos_ipv4_hash_key.hash_type1_low = fib_key_type & 0x1;
                ds_acl_qos_ipv4_hash_key.hash_type1_high = (fib_key_type >> 1) & 0x7;
                ds_acl_qos_ipv4_hash_key.is_ipv4_key = TRUE;

                if (!p_fib_key->key.acl.is_logic_port)
                {
                    if (fib_engine_lookup_ctl.ipv4_acl_src_phy_port_en)
                    {
                        ds_acl_qos_ipv4_hash_key.global_src_port2_0 = p_fib_key->key.acl.global_src_port & 0x7;
                        ds_acl_qos_ipv4_hash_key.global_src_port13_3 = (p_fib_key->key.acl.global_src_port >> 3) & 0x7FF;
                        ds_acl_qos_ipv4_hash_key.is_logic_port = p_fib_key->key.acl.is_logic_port;
                    }
                    else
                    {
                        ds_acl_qos_ipv4_hash_key.global_src_port2_0 = 0;
                        ds_acl_qos_ipv4_hash_key.global_src_port13_3 = 0;
                        ds_acl_qos_ipv4_hash_key.is_logic_port = 0;
                    }
                }
                else
                {
                    if (fib_engine_lookup_ctl.ipv4_acl_src_logic_port_en)
                    {
                        ds_acl_qos_ipv4_hash_key.global_src_port2_0 = p_fib_key->key.acl.global_src_port & 0x7;
                        ds_acl_qos_ipv4_hash_key.global_src_port13_3 = (p_fib_key->key.acl.global_src_port >> 3) & 0x7FF;
                        ds_acl_qos_ipv4_hash_key.is_logic_port = p_fib_key->key.acl.is_logic_port;
                    }
                    else
                    {
                        ds_acl_qos_ipv4_hash_key.global_src_port2_0 = 0;
                        ds_acl_qos_ipv4_hash_key.global_src_port13_3 = 0;
                        ds_acl_qos_ipv4_hash_key.is_logic_port = 0;
                    }
                }

                if (fib_engine_lookup_ctl.ipv4_acl_l4_source_port_en)
                {
                    ds_acl_qos_ipv4_hash_key.l4_source_port = p_fib_key->key.acl.l4_source_port;
                }
                else
                {
                    ds_acl_qos_ipv4_hash_key.l4_source_port = 0;
                }

                if (fib_engine_lookup_ctl.ipv4_acl_ip_sa_en)
                {
                    ds_acl_qos_ipv4_hash_key.ip_sa = p_fib_key->key.acl.ip_sa;
                }
                else
                {
                    ds_acl_qos_ipv4_hash_key.ip_sa = 0;
                }

                if (fib_engine_lookup_ctl.ipv4_acl_protocol_en)
                {
                    ds_acl_qos_ipv4_hash_key.layer3_header_protocol = p_fib_key->key.acl.layer3_header_protocol;
                }
                else
                {
                    ds_acl_qos_ipv4_hash_key.layer3_header_protocol = 0;
                }

                if (fib_engine_lookup_ctl.ipv4_acl_l4_dest_port_en)
                {
                    ds_acl_qos_ipv4_hash_key.l4_dest_port8_0 = p_fib_key->key.acl.l4_dest_port & 0x1FF;
                    ds_acl_qos_ipv4_hash_key.l4_dest_port12_9 = (p_fib_key->key.acl.l4_dest_port >> 9) & 0xF;
                    ds_acl_qos_ipv4_hash_key.l4_dest_port13 = (p_fib_key->key.acl.l4_dest_port >> 13) & 0x1;
                    ds_acl_qos_ipv4_hash_key.l4_dest_port15_14 = (p_fib_key->key.acl.l4_dest_port >> 14) & 0x3;
                }
                else
                {
                    ds_acl_qos_ipv4_hash_key.l4_dest_port8_0 = 0;
                    ds_acl_qos_ipv4_hash_key.l4_dest_port12_9 = 0;
                    ds_acl_qos_ipv4_hash_key.l4_dest_port13 = 0;
                    ds_acl_qos_ipv4_hash_key.l4_dest_port15_14 = 0;
                }

                if (fib_engine_lookup_ctl.ipv4_acl_ip_da_en)
                {
                    ds_acl_qos_ipv4_hash_key.ip_da = p_fib_key->key.acl.ip_da;
                }
                else
                {
                    ds_acl_qos_ipv4_hash_key.ip_da = 0;
                }

                if (fib_engine_lookup_ctl.ipv4_aclis_arp_en)
                {
                    ds_acl_qos_ipv4_hash_key.is_arp_key = p_fib_key->key.acl.is_arp_key;
                }
                else
                {
                    ds_acl_qos_ipv4_hash_key.is_arp_key = 0;
                }

                if (fib_engine_lookup_ctl.ipv4_acl_dscp_en)
                {
                    ds_acl_qos_ipv4_hash_key.dscp = p_fib_key->key.acl.dscp;
                }
                else
                {
                    ds_acl_qos_ipv4_hash_key.dscp = 0;
                }
                lookup_info.hash_type = FIB_HASH_TYPE_ACL_IPV4;
                lookup_info.p_ds_key = &ds_acl_qos_ipv4_hash_key;
            }
            break;
    }

    tbls_id_t tbl_id = MaxTblId_t;

#if (SDK_WORK_PLATFORM == 1)
    /*Stroe fib hash key for cosim*/
    if (cosim_db.store_key)
    {
        tbl_id = drv_hash_lookup_get_key_table_id(lookup_info.hash_module, lookup_info.hash_type);
        DRV_IF_ERROR_RETURN(cosim_db.store_key(lookup_info.p_ds_key, tbl_id));
    }
#endif

    DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_lookup);
    DRV_IF_ERROR_RETURN(drv_io_api.drv_hash_lookup(&lookup_info, p_lookup_result));

    tbl_id = drv_hash_lookup_get_key_table_id(lookup_info.hash_module, lookup_info.hash_type);
    sim_cmodel_debug_show_hash_tbl(tbl_id, fib_key_type, p_lookup_result->valid, p_lookup_result->key_index);

    return DRV_E_NONE;
}

static int32
_cm_com_fib_lookup_engine_get_associated_lookup_result(uint8 chip_id,
                                                       fib_key_t* p_fib_key,
                                                       fib_key_type_t fib_key_type,
                                                       lookup_result_t* p_fib_result,
                                                       push_info_t* p_push_info)
{
    uint8  fib_result_valid = FALSE;
    uint8  default_entry_valid = FALSE;
    uint8  hash_conflict = FALSE;
    uint8  default_entry_en = FALSE;
    uint8* p_aging_en = NULL;
    uint16 fib_result_index = 0;
    uint32 default_entry_index = 0;
    uint32 retrieve_ds_index = 0;
    uint32 lookup_result_ctl = 0;
    uint32 fib_key_index = 0;
    uint32 cmd = 0;
    uint32 mac_use_default_entry = FALSE;

    fib_engine_lookup_result_ctl_t fib_engine_lookup_result_ctl;
    p_aging_en = (uint8*)p_fib_result->extra;

    ds_ip_da_t    ds_ip_da;
    ds_ip_da_t    ds_ip_sa;
    ds_mac_t      ds_mac;
    ds_fcoe_da_t  ds_fcoe_da;
    ds_fcoe_sa_t  ds_fcoe_sa;
    ds_trill_da_t ds_trill_da;
    ds_acl_t      ds_acl;

    sal_memset(&fib_engine_lookup_result_ctl, 0, sizeof(fib_engine_lookup_result_ctl));
    cmd = DRV_IOR(FibEngineLookupResultCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_result_ctl));

    switch (fib_key_type)
    {
        case FIB_KEY_TYPE_IPV4_UCAST:
        case FIB_KEY_TYPE_IPV4_NAT_DA:
            lookup_result_ctl = fib_engine_lookup_result_ctl.ip_da_lookup_result_ctl0; /* IPv4 Ucast */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        case FIB_KEY_TYPE_IPV4_MCAST:
            lookup_result_ctl = fib_engine_lookup_result_ctl.ip_da_lookup_result_ctl1; /* IPv4 Mcast */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        case FIB_KEY_TYPE_IPV6_UCAST:
        case FIB_KEY_TYPE_IPV6_NAT_DA:
            lookup_result_ctl = fib_engine_lookup_result_ctl.ip_da_lookup_result_ctl2; /* IPv6 Ucast */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        case FIB_KEY_TYPE_IPV6_MCAST:
            lookup_result_ctl = fib_engine_lookup_result_ctl.ip_da_lookup_result_ctl3; /* IPv6 Mcast */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        case FIB_KEY_TYPE_IPV4_RPF:
            lookup_result_ctl = fib_engine_lookup_result_ctl.ip_sa_lookup_result_ctl0; /* IPv4 RPF */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        case FIB_KEY_TYPE_IPV6_RPF:
            lookup_result_ctl = fib_engine_lookup_result_ctl.ip_sa_lookup_result_ctl1; /* IPv6 RPF */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        case FIB_KEY_TYPE_IPV4_NAT_SA:
            lookup_result_ctl = fib_engine_lookup_result_ctl.ip_sa_lookup_result_ctl2; /* IPv4 NAT SA */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        case FIB_KEY_TYPE_IPV6_NAT_SA:
            lookup_result_ctl = fib_engine_lookup_result_ctl.ip_sa_lookup_result_ctl3; /* IPv6 NAT SA */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        case FIB_KEY_TYPE_MAC_DA:
            lookup_result_ctl = fib_engine_lookup_result_ctl.mac_da_lookup_result_ctl; /* MAC SA DA */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;
        case FIB_KEY_TYPE_MAC_SA:
            lookup_result_ctl = fib_engine_lookup_result_ctl.mac_sa_lookup_result_ctl; /* MAC SA */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        case FIB_KEY_TYPE_FCOE:
            lookup_result_ctl = fib_engine_lookup_result_ctl.fcoe_da_lookup_result_ctl; /* FCoE DA */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 17);
            break;

        case FIB_KEY_TYPE_FCOE_RPF:
            lookup_result_ctl = fib_engine_lookup_result_ctl.fcoe_sa_lookup_result_ctl; /* FCoE SA */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 17);
            break;

        case FIB_KEY_TYPE_TRILL_UCAST:
            lookup_result_ctl = fib_engine_lookup_result_ctl.trill_ucast_lookup_result_ctl; /* TRILL Ucast */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 17);
            break;

        case FIB_KEY_TYPE_TRILL_MCAST:
        case FIB_KEY_TYPE_TRILL_MCAST_VLAN:
            lookup_result_ctl = fib_engine_lookup_result_ctl.trill_mcast_lookup_result_ctl; /* TRILL Mcast */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 17);
            break;

        case FIB_KEY_TYPE_MAC_IPV4_MULTICAST:
            lookup_result_ctl = fib_engine_lookup_result_ctl.mac_ipv4_lookup_result_ctl; /* MAC IPv4 Mcast */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        case FIB_KEY_TYPE_MAC_IPV6_MULTICAST:
            lookup_result_ctl = fib_engine_lookup_result_ctl.mac_ipv6_lookup_result_ctl; /* MAC IPv6 Mcast */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;

        default:
            lookup_result_ctl = fib_engine_lookup_result_ctl.acl_lookup_result_ctl; /* ACL */
            default_entry_en = IS_BIT_SET(lookup_result_ctl, 0);
            break;
    }

    if (IS_BIT_SET(fib_key_type, 4))
    {
        /* FDB */
        /* aging_base = fib_engine_lookup_result_ctl.fdb_aging_base; */
    }
    else
    {
        /* FIB */
        /* aging_base = fib_engine_lookup_result_ctl.fdb_agine_base + 256; */
    }

    /* Default entry index */
    if (!IS_BIT_SET(fib_key_type, 4))
    {
        /* IP */
        default_entry_index = (((lookup_result_ctl >> 1) & 0x3FF) << 6) + (p_fib_key->id.vrf_id & 0x3FFF);
    }
    else if ((FIB_KEY_TYPE_MAC_DA == fib_key_type) || (FIB_KEY_TYPE_MAC_SA == fib_key_type))
    {
        /* MAC DA/SA */
        default_entry_index = (((lookup_result_ctl >> 1) & 0x3FF) << 6) + (p_fib_key->id.vsi_id & 0x3FFF);
    }
    else
    {
        /* ACL default entry always in TCAM */
        /* TRILL/FCOE */
        default_entry_index = lookup_result_ctl & 0xFFFF;
    }

    mac_use_default_entry = (FIB_KEY_TYPE_MAC_DA == fib_key_type)
                             && ((fib_engine_lookup_result_ctl.fdb_use_default_entry)
                             || ((fib_engine_lookup_result_ctl.fdb_flooding_vsi_en)
                             && (fib_engine_lookup_result_ctl.fdb_flooding_vsi == p_fib_key->id.vsi_id)));

    if (IS_BIT_SET(fib_key_type, 4))
    {
        fib_result_valid = p_fib_result->valid;
        fib_key_index = p_fib_result->key_index;
        fib_result_index = p_fib_result->ad_index;
        hash_conflict = !p_fib_result->valid && !p_fib_result->free;

        if ((IS_BIT_SET(lookup_result_ctl, 11)) && fib_result_valid && !mac_use_default_entry)
        {
            /*
             * update_aging_cache default entry no aging
             */
            cm_update_aging_cache(chip_id, 2,
                fib_key_index + fib_engine_lookup_result_ctl.fdb_aging_base + 256, 1);
        }
    }
    else
    {
        p_aging_en = (uint8*)p_fib_result->extra;
        fib_result_valid = p_fib_result->valid;
        fib_key_index = p_fib_result->key_index;
        fib_result_index = p_fib_result->ad_index;

        if ((IS_BIT_SET(lookup_result_ctl, 11)) && fib_result_valid && (*p_aging_en))
        {
            /*
             * update_aging_cache default entry no aging
             */
            cm_update_aging_cache(chip_id, 2, fib_key_index, 1);
        }
    }

    if ((FIB_KEY_TYPE_IPV4_RPF == fib_key_type) || (FIB_KEY_TYPE_IPV6_RPF == fib_key_type))
    {
        /* Only IP unicast RPF */
        fib_result_index = fib_result_index + (((lookup_result_ctl  >> 12) & 0x3FF) << 6);
    }



    /* No default entry for TRILL Mcast VLAN, use TRILL Mcast */
    if (mac_use_default_entry) /* force MAC defaultEntry */
    {
        fib_result_index = default_entry_index;
        default_entry_valid = TRUE;
        fib_result_valid = TRUE;
    }
    else if (!fib_result_valid && default_entry_en
            && ((FIB_KEY_TYPE_TRILL_MCAST_VLAN != fib_key_type)
            && (FIB_KEY_TYPE_ACL != fib_key_type)))
    {
        fib_result_index = default_entry_index;
        default_entry_valid = TRUE;
        fib_result_valid = TRUE;
    }

    if (fib_result_valid)
    {
        retrieve_ds_index = fib_result_index;

        switch (fib_key_type)
        {
            case FIB_KEY_TYPE_IPV4_UCAST:
            case FIB_KEY_TYPE_IPV4_NAT_DA:
            case FIB_KEY_TYPE_IPV4_MCAST:
            case FIB_KEY_TYPE_IPV6_UCAST:
            case FIB_KEY_TYPE_IPV6_NAT_DA:
            case FIB_KEY_TYPE_IPV6_MCAST:
                sal_memset(&ds_ip_da, 0, sizeof(ds_ip_da));
                cmd = DRV_IOR(DsIpDa_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, retrieve_ds_index, cmd, &ds_ip_da));
                sal_memcpy(p_push_info->data, &ds_ip_da, sizeof(ds_ip_da));
                CMODEL_DEBUG_OUT_INFO("CModelDebug: DsIpDA index = 0x%x!\n", retrieve_ds_index);
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsIpDa_t", retrieve_ds_index);
                break;
            case FIB_KEY_TYPE_IPV4_RPF:
            case FIB_KEY_TYPE_IPV6_RPF:
            case FIB_KEY_TYPE_IPV4_NAT_SA:
            case FIB_KEY_TYPE_IPV6_NAT_SA:
                sal_memset(&ds_ip_sa, 0, sizeof(ds_ip_sa));
                cmd = DRV_IOR(DsIpDa_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, retrieve_ds_index, cmd, &ds_ip_sa));
                sal_memcpy(p_push_info->data, &ds_ip_sa, sizeof(ds_ip_sa));
                CMODEL_DEBUG_OUT_INFO("CModelDebug: DsIpSA index = 0x%x!\n", retrieve_ds_index);
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsIpDa_t", retrieve_ds_index);
                break;
            case FIB_KEY_TYPE_MAC_DA:
            case FIB_KEY_TYPE_MAC_SA:
            case FIB_KEY_TYPE_MAC_IPV4_MULTICAST:
            case FIB_KEY_TYPE_MAC_IPV6_MULTICAST:
                sal_memset(&ds_mac, 0, sizeof(ds_mac_t));
                cmd = DRV_IOR(DsMac_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, retrieve_ds_index, cmd, &ds_mac));
                sal_memcpy(p_push_info->data, &ds_mac, sizeof(ds_mac_t));
                CMODEL_DEBUG_OUT_INFO("CModelDebug: DsMac index = 0x%x!\n", retrieve_ds_index);
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsMac_t", retrieve_ds_index);
                break;
            case FIB_KEY_TYPE_FCOE:
                sal_memset(&ds_fcoe_da, 0, sizeof(ds_fcoe_da));
                cmd = DRV_IOR(DsFcoeDa_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, retrieve_ds_index, cmd, &ds_fcoe_da));
                sal_memcpy(p_push_info->data, &ds_fcoe_da, sizeof(ds_fcoe_da));
                CMODEL_DEBUG_OUT_INFO("CModelDebug: DsFcoeDa index = 0x%x!\n", retrieve_ds_index);
                break;
            case FIB_KEY_TYPE_FCOE_RPF:
                sal_memset(&ds_fcoe_sa, 0, sizeof(ds_fcoe_sa));
                cmd = DRV_IOR(DsFcoeSa_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, retrieve_ds_index, cmd, &ds_fcoe_sa));
                sal_memcpy(p_push_info->data, &ds_fcoe_sa, sizeof(ds_fcoe_sa));
                CMODEL_DEBUG_OUT_INFO("CModelDebug: DsFcoeSa index = 0x%x!\n", retrieve_ds_index);
                break;
            case FIB_KEY_TYPE_TRILL_UCAST:
            case FIB_KEY_TYPE_TRILL_MCAST:
            case FIB_KEY_TYPE_TRILL_MCAST_VLAN:
                sal_memset(&ds_trill_da, 0, sizeof(ds_trill_da));
                cmd = DRV_IOR(DsTrillDa_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, retrieve_ds_index, cmd, &ds_trill_da));
                sal_memcpy(p_push_info->data, &ds_trill_da, sizeof(ds_trill_da));
                CMODEL_DEBUG_OUT_INFO("CModelDebug: DsTrillDa index = 0x%x!\n", retrieve_ds_index);
                break;
            case FIB_KEY_TYPE_ACL:
                sal_memset(&ds_acl, 0, sizeof(ds_acl_t));
                cmd = DRV_IOR(DsAcl_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, retrieve_ds_index, cmd, &ds_acl));
                sal_memcpy(p_push_info->data, &ds_acl, sizeof(ds_acl_t));
                CMODEL_DEBUG_OUT_INFO("CModelDebug: DsAcl index = 0x%x!\n", retrieve_ds_index);
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsAcl_t", retrieve_ds_index);

                break;
            default:
                break;
        }

        /* First push */
        p_push_info->valid = fib_result_valid;
        p_push_info->conflict = hash_conflict;
        p_push_info->default_entry_valid = default_entry_valid;
    }

    return DRV_E_NONE;
}

int32 cm_com_fib_lookup_engine_lookup_handle(uint8 chip_id,
                                             fib_key_t* p_fib_key,
                                             fib_key_type_t fib_key_type,
                                             lookup_result_t* p_fib_result)
{
    uint8 aging_en = FALSE;
    push_info_t* p_push_info = NULL;

    DRV_PTR_VALID_CHECK(p_fib_key);
    DRV_PTR_VALID_CHECK(p_fib_result);

    p_push_info = p_fib_result->extra;
    p_fib_result->extra = &aging_en;

    /* LOOKUP_TYPE_DECISION */
    if (IS_BIT_SET(fib_key_type, 4)) /* Non-IP Hash Lookup */
    {
        DRV_IF_ERROR_RETURN(_cm_com_fib_lookup_engine_perform_hash_lookup(chip_id, p_fib_key, fib_key_type, p_fib_result));
    }
    else
    {
        cm_com_lpm_engine_perform_lpm_lookup(chip_id, p_fib_key, fib_key_type, p_fib_result);
    }

    DRV_IF_ERROR_RETURN(_cm_com_fib_lookup_engine_get_associated_lookup_result(chip_id, p_fib_key, fib_key_type,
                                                                               p_fib_result, p_push_info));

    return DRV_E_NONE;
}

