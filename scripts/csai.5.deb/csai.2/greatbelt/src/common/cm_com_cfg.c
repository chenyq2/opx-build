/****************************************************************************
 * cm_com_cfg.c: Provides table and register configuration io for simulation
 * Copyright (c)2011 Centec Networks Inc. All rights reserved.
 *
 * Revision:     V4.28.2
 * Author:       ZhouW.
 * Date:         2011-10-09.
 * Modify History:
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_sim_cli.h"

#if (SDK_WORK_PLATFORM==0)
static uint32 _emu_tcam_data_buf[MAX_ENTRY_WORD] = {0};
static uint32 _emu_tcam_mask_buf[MAX_ENTRY_WORD] = {0};
static tbls_id_t _emu_tcam_tbl_id_history = MaxTblId_t;
static uint32 _emu_tcam_tbl_idx_history = 0xFFFFFFFF;
#endif

static uint32 _entry_data_buf[MAX_ENTRY_WORD] = {0};
static uint32 _entry_mask_buf[MAX_ENTRY_WORD] = {0};

/****************************************************************************
* Name   : sim_cfg_set_field
* Purpose: The function use to config table's field(include tcam table).
* Input  :
* Output :
* Return : DRV_E_NONE = success.
*          Other = ErrorCode, please refer to DRV_E_XXX.
* Note   : N/A
****************************************************************************/
int32 sim_cfg_set_field(proc_field_t *field_info)
{
    int32 ret = DRV_E_NONE;
    char tbl_name[64] = {0};
    char fld_name[64] = {0};
    tbl_entry_t entry;
    tbls_id_t tbl_id = field_info->tbl_id;
    uint32 *p_entry_tmp = NULL;
    entry.data_entry = _entry_data_buf;
    entry.mask_entry = _entry_mask_buf;

    DRV_TBL_ID_VALID_CHECK(tbl_id)

    if (cmodel_debug_on)
    {
        DRV_IF_ERROR_RETURN(drv_get_tbl_string_by_id(field_info->tbl_id, tbl_name));
        DRV_IF_ERROR_RETURN(drv_get_field_string_by_id(field_info->tbl_id, field_info->field_id, fld_name));
    }

    /* Read the entry data */
    if (!drv_table_is_tcam_key(tbl_id))
    {
        if (drv_io_api.drv_sram_tbl_read)
        {
            ret = drv_io_api.drv_sram_tbl_read(field_info->chip_id_offset, field_info->tbl_id,
                                             field_info->index, entry.data_entry);
            if (ret < DRV_E_NONE)
            {
                CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_sram_tbl_read fail: tbl_id = %32s, index = 0x%08x, ret = %d\n",
                                       tbl_name, field_info->index, ret);
                return ret;
            }
        }
        else
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_sram_tbl_read is NULL!\n");
            return DRV_E_INVALID_PTR;
        }
    }
    else
    {
        if (drv_io_api.drv_tcam_tbl_read)
        {
            ret = drv_io_api.drv_tcam_tbl_read(field_info->chip_id_offset, field_info->tbl_id,
                                            field_info->index, &entry);
            if (ret < DRV_E_NONE)
            {
                CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_tcam_tbl_read fail: tbl_id = %32s, index = 0x%08x, ret = %d\n",
                                       tbl_name, field_info->index, ret);
                return ret;
            }
        }
        else
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_tcam_tbl_read is NULL!\n");
            return DRV_E_INVALID_PTR;
        }
    }

    /* Modify the entry data according to set field */
    p_entry_tmp = field_info->mask? entry.mask_entry : entry.data_entry;
    if (drv_io_api.drv_set_field)
    {
        ret = drv_io_api.drv_set_field(field_info->tbl_id, field_info->field_id,
                                p_entry_tmp, field_info->value);
        if (ret < DRV_E_NONE)
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_set_field fail: fld_id = %32s, index = 0x%08x, value = 0x%08x\n",
                                  fld_name, field_info->index, field_info->value);
            return ret;
        }
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_set_field is NULL!\n");
        return DRV_E_INVALID_PTR;
    }

    /* Write the entry data after modification */
    if (!drv_table_is_tcam_key(tbl_id))
    {
        if (drv_io_api.drv_sram_tbl_write)
        {
            ret = drv_io_api.drv_sram_tbl_write(field_info->chip_id_offset, field_info->tbl_id,
                                                field_info->index, entry.data_entry);
            if (ret < DRV_E_NONE)
            {
                CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_sram_tbl_write fail: tbl_id = %32s, index = 0x%08x, value = 0x%08x\n",
                                       tbl_name, field_info->index, field_info->value);
                return ret;
            }
        }
        else
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_sram_tbl_write is NULL!\n");
            return DRV_E_INVALID_PTR;
        }
    }
    else
    {
        if (drv_io_api.drv_tcam_tbl_write)
        {
            ret = drv_io_api.drv_tcam_tbl_write(field_info->chip_id_offset, field_info->tbl_id,
                                                field_info->index, &entry);
            if (ret < DRV_E_NONE)
            {
                CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_tcam_tbl_write fail: tbl_id = %32s, index = 0x%08x, value = 0x%08x\n",
                                       tbl_name, field_info->index, field_info->value);
                return ret;
            }
        }
        else
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_tcam_tbl_write is NULL!\n");
            return DRV_E_INVALID_PTR;
        }
    }

    return ret;
}

/****************************************************************************
* Name     : sim_cfg_get_field
* Purpose  : The function use to get table's field(include tcam table).
* Input    :
* Output   :
* Return   : DRV_E_NONE = success.
*            Other = ErrorCode, please refer to DRV_E_XXX.
* Note     :
****************************************************************************/
int32 sim_cfg_get_field(proc_field_t *field_info)
{
    int32 ret = DRV_E_NONE;
    tbl_entry_t entry;
    char tbl_name[32] = {0};
    char fld_name[32] = {0};
    uint32 *p_entry_tmp = NULL;

    sal_memset(_entry_data_buf, 0, sizeof(_entry_data_buf));
    sal_memset(_entry_mask_buf, 0, sizeof(_entry_mask_buf));

    entry.data_entry = _entry_data_buf;
    entry.mask_entry = _entry_mask_buf;

    DRV_TBL_ID_VALID_CHECK(field_info->tbl_id);

    if (cmodel_debug_on)
    {
        DRV_IF_ERROR_RETURN(drv_get_tbl_string_by_id(field_info->tbl_id, tbl_name));
        DRV_IF_ERROR_RETURN(drv_get_field_string_by_id(field_info->tbl_id, field_info->field_id, fld_name));
    }

    if (!drv_table_is_tcam_key(field_info->tbl_id))
    {
        if (drv_io_api.drv_sram_tbl_read)
        {
            ret = drv_io_api.drv_sram_tbl_read(field_info->chip_id_offset, field_info->tbl_id,
                                               field_info->index, entry.data_entry);
            if (ret < DRV_E_NONE)
            {
                CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_sram_tbl_read fail: tbl_id = %32s, index = 0x%08x, ret = %d\n",
                                      tbl_name, field_info->index, ret);
                return ret;
            }
        }
        else
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_sram_tbl_read is NULL!\n");
            return DRV_E_INVALID_PTR;
        }
    }
    else
    {
        if (drv_io_api.drv_tcam_tbl_read)
        {
            ret = drv_io_api.drv_tcam_tbl_read(field_info->chip_id_offset, field_info->tbl_id,
                                               field_info->index, &entry);
            if (ret < DRV_E_NONE)
            {
                CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_tcam_tbl_read fail: tbl_id = %32s, index = 0x%08x, ret = %d\n",
                                       tbl_name, field_info->index, ret);
                return ret;
            }
        }
        else
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_tcam_tbl_read is NULL!\n");
            return DRV_E_INVALID_PTR;
        }
    }

    p_entry_tmp = field_info->mask? entry.mask_entry : entry.data_entry;
    if (drv_io_api.drv_get_field)
    {
        ret = drv_io_api.drv_get_field(field_info->tbl_id, field_info->field_id,
                                    p_entry_tmp, &(field_info->value));
        if (ret < DRV_E_NONE)
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_get_field fail: fld_id = %32s, index = 0x%08x, value = 0x%08x\n",
                                  fld_name, field_info->index, field_info->value);
            return ret;
        }
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_get_field is NULL!\n");
        return DRV_E_INVALID_PTR;
    }

    return ret;
}

#if (SDK_WORK_PLATFORM==0)
int32 sim_cfg_emu_set_tcam_field(proc_field_t *field_info)
{
    int32 ret = DRV_E_NONE;
    char tbl_name[32] = {0};
    char fld_name[32] = {0};
    tbl_entry_t entry;
    tbls_id_t tbl_id = field_info->tbl_id;
    uint32 *p_entry_tmp = NULL;
    entry.data_entry = _emu_tcam_data_buf;
    entry.mask_entry = _emu_tcam_mask_buf;

    DRV_TBL_ID_VALID_CHECK(tbl_id)
    if (cmodel_debug_on)
    {
        DRV_IF_ERROR_RETURN(drv_get_tbl_string_by_id(field_info->tbl_id, tbl_name));
        DRV_IF_ERROR_RETURN(drv_get_field_string_by_id(field_info->tbl_id, field_info->field_id, fld_name));
    }

    if ((_emu_tcam_tbl_id_history != field_info->tbl_id)
        || (_emu_tcam_tbl_idx_history != field_info->index))  /* the tcam table's index is the 1th setting */
    {
        if (drv_io_api.drv_tcam_tbl_read)
        {
            ret = drv_io_api.drv_tcam_tbl_read(field_info->chip_id_offset, field_info->tbl_id,
                                            field_info->index, &entry);
#if 0
            if (cmodel_debug_on)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Read Tcam %s index %d\n", tbl_name, field_info->index);
                for (i = 0; i < TCAM_KEY_SIZE(field_info->tbl_id)/DRV_BYTES_PER_WORD; i++)
                {
                    CMODEL_DEBUG_OUT_INFO("data = 0x%08x\n", _emu_tcam_data_buf[i]);
                }
                for (i = 0; i < TCAM_KEY_SIZE(field_info->tbl_id)/DRV_BYTES_PER_WORD; i++)
                {
                    CMODEL_DEBUG_OUT_INFO("mask = 0x%08x\n", _emu_tcam_mask_buf[i]);
                }
            }
#endif
            if (ret < DRV_E_NONE)
            {
                CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_tcam_tbl_read fail: tbl_id = %32s, index = 0x%08x, ret = %d\n",
                                       tbl_name, field_info->index, ret);
                goto END;
            }

            _emu_tcam_tbl_id_history = field_info->tbl_id;
            _emu_tcam_tbl_idx_history = field_info->index;
        }
        else
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_tcam_tbl_read is NULL!\n");
            ret = DRV_E_INVALID_PTR;
            goto END;
        }
    }

    /* Modify the entry data according to set field */
    p_entry_tmp = field_info->mask? entry.mask_entry : entry.data_entry;
    if (drv_io_api.drv_set_field)
    {
        ret = drv_io_api.drv_set_field(field_info->tbl_id, field_info->field_id,
                                p_entry_tmp, field_info->value);
        if (ret < DRV_E_NONE)
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_set_field fail: fld_id = %32s, index = 0x%08x, value = 0x%08x\n",
                                  fld_name, field_info->index, field_info->value);
            goto END;
        }
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_set_field is NULL!\n");
        ret =  DRV_E_INVALID_PTR;
        goto END;
    }

    if (!field_info->tcam_write_trigger)
    {
#if 0
        if (cmodel_debug_on)
        {
            CMODEL_DEBUG_OUT_INFO("++++ Set Tcam %s[0x%x].%s = %d\n", tbl_name, field_info->index, fld_name, field_info->value);
            for (i = 0; i < TCAM_KEY_SIZE(field_info->tbl_id)/DRV_BYTES_PER_WORD; i++)
            {
                CMODEL_DEBUG_OUT_INFO("data = 0x%08x\n", _emu_tcam_data_buf[i]);
            }
            for (i = 0; i < TCAM_KEY_SIZE(field_info->tbl_id)/DRV_BYTES_PER_WORD; i++)
            {
                CMODEL_DEBUG_OUT_INFO("mask = 0x%08x\n", _emu_tcam_mask_buf[i]);
            }
        }
#endif
        return DRV_E_NONE;
    }

    if (drv_io_api.drv_tcam_tbl_write)
    {
        ret = drv_io_api.drv_tcam_tbl_write(field_info->chip_id_offset, field_info->tbl_id,
                                            field_info->index, &entry);
        if (ret < DRV_E_NONE)
        {
            CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_tcam_tbl_write fail: tbl_id = %32s, index = 0x%08x, value = 0x%08x\n",
                                   tbl_name, field_info->index, field_info->value);
            goto END;
        }
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("CModelCFG ERROR! drv_io_api.drv_tcam_tbl_write is NULL!\n");
        ret =  DRV_E_INVALID_PTR;
        goto END;
    }

END:
#if 0
    if (cmodel_debug_on)
    {
        CMODEL_DEBUG_OUT_INFO("++++ Write Tcam %s index %d\n", tbl_name, field_info->index);
        for (i = 0; i < TCAM_KEY_SIZE(field_info->tbl_id)/DRV_BYTES_PER_WORD; i++)
        {
            CMODEL_DEBUG_OUT_INFO("data = 0x%08x\n", _emu_tcam_data_buf[i]);
        }
        for (i = 0; i < TCAM_KEY_SIZE(field_info->tbl_id)/DRV_BYTES_PER_WORD; i++)
        {
            CMODEL_DEBUG_OUT_INFO("mask = 0x%08x\n", _emu_tcam_mask_buf[i]);
        }
    }
#endif
    sal_memset(_emu_tcam_data_buf, 0, sizeof(_emu_tcam_data_buf));
    sal_memset(_emu_tcam_mask_buf, 0, sizeof(_emu_tcam_mask_buf));

    _emu_tcam_tbl_id_history = MaxTblId_t;
    _emu_tcam_tbl_idx_history = 0xFFFFFFFF;

    return ret;
}
#endif

