/****************************************************************************
* cm_com_asic_model.c: Provides main function threads for cmodel
* Copyright: (c)2010 Centec Networks Inc.  All rights reserved.
*
* Version:       V1.0
* Author:        JiangJf
* Date:          2010-09-30.
* Reason:        First Create.
*
* Modify History:
* Revision:      V4.29.0
* Reviser:       XuZx
* Date:          2010-10-10.
* Reason:        Sync for Specs V4.29.0
****************************************************************************/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
/****************************************************************************
*
* Global and Declarations
*
****************************************************************************/
#if (SDK_WORK_PLATFORM == 1)
static int32 sim_store_share_field(uint32 module_id, uint32 bus_id, void *in_pkt)
{
    ipe_in_pkt_t *ipe_inpkt = NULL;
    epe_in_pkt_t *epe_inpkt = NULL;
    ipe_packet_info_t *ipe_pktinfo = NULL;
    epe_packet_info_t *epe_pktinfo = NULL;
    share_type_t share_type = SHARE_TYPE_NONE;

    if (module_id == SIM_MODULE_IPE)
    {
        ipe_inpkt = (ipe_in_pkt_t *)in_pkt;
        ipe_pktinfo = (ipe_packet_info_t *)ipe_inpkt->pkt_info;
        share_type = ipe_pktinfo->share_type;
        switch (bus_id)
        {
            case SIM_IPE_OM2FW:
                switch (share_type)
                {
                    case SHARE_TYPE_NAT:
                        if (cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_NAT_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_NAT_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_LMTX:
                        if (cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_LM_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_LM_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_PTP:
                        if (cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_PTP_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_PTP_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_OAM:
                        if (cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_OAM_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_OAM_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_DMTX:
                        if (cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_DMTX_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_DMTX_BUS]((void *)in_pkt));
                        }
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }
    else if (module_id == SIM_MODULE_EPE)
    {
        epe_inpkt = (epe_in_pkt_t *)in_pkt;
        epe_pktinfo = (epe_packet_info_t *)epe_inpkt->pkt_info;
        share_type = epe_pktinfo->share_type;
        switch (bus_id)
        {
            case SIM_EPE_HA2NH:
                switch (share_type)
                {
                    case SHARE_TYPE_NAT:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_NAT_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_NAT_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_LMTX:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_LM_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_LM_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_PTP:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_PTP_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_PTP_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_OAM:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_OAM_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_OAM_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_DMTX:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_DMTX_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_DMTX_BUS]((void *)in_pkt));
                        }
                        break;
                    default:
                        break;
                }
                break;
            case SIM_EPE_HP2OM:
                switch (share_type)
                {
                    case SHARE_TYPE_NAT:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_NAT_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_NAT_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_LMTX:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_LM_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_LM_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_PTP:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_PTP_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_PTP_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_OAM:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_OAM_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_OAM_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_DMTX:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_DMTX_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_DMTX_BUS]((void *)in_pkt));
                        }
                        break;
                    default:
                        break;
                }
                break;
            case SIM_EPE_NH2HP:
                switch (share_type)
                {
                    case SHARE_TYPE_NAT:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_NAT_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_NAT_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_LMTX:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_LM_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_LM_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_PTP:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_PTP_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_PTP_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_OAM:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_OAM_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_OAM_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_DMTX:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_DMTX_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_DMTX_BUS]((void *)in_pkt));
                        }
                        break;
                    default:
                        break;
                }
                break;
            case SIM_EPE_OM2HE:
                switch (share_type)
                {
                    case SHARE_TYPE_NAT:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_NAT_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_NAT_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_LMTX:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_LM_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_LM_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_PTP:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_PTP_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_PTP_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_OAM:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_OAM_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_OAM_BUS]((void *)in_pkt));
                        }
                        break;
                    case SHARE_TYPE_DMTX:
                        if (cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_DMTX_BUS])
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_DMTX_BUS]((void *)in_pkt));
                        }
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }

    return DRV_E_NONE;
}
#endif
/****************************************************************************
*
* Functions
*
****************************************************************************/

/****************************************************************************
 * Name:       cm_do_ipe
 * Purpose:    ASIC CModel IPE handle.
 * Parameters:
 * Input:      in_pkt -- pointer to IPE input.
 * Output:     out_pkt_head -- pointer to linklist which store the IPE output packet
 *                                          informations include packet header and exceptions.
 * Return:     DRV_E_NONE = success.

 *             Other = ErrorCode, please refer to DRV_E_XXX.

 * Note:       none.
****************************************************************************/
int32 cm_do_ipe(ipe_in_pkt_t *in_pkt, list_head_t *out_pkt_head)
{
    int32 ret = DRV_E_NONE;

    /* Mallocate memory for IPE input */
    ret = sim_ipe_mallocate_memory(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! sim_ipe_mallocate_memory error!\n");
        return ret;
    }

    /* IPE Header Adjust */
    ret = cm_ipe_header_adjust_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_mux_lbk_hdr_adjust error!\n");
        goto error;
    }

    /* IPE Parsing */
    ret = cm_ipe_dcpt_and_parsing_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_dcpt_and_parsing error!\n");
       goto error;
    }

#if (SDK_WORK_PLATFORM == 1)

    if (cosim_db.store_ipe_bus[SIM_IPE_PR2IM])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_PR2IM]((void *)in_pkt));
    }

#endif

    /* IPE User Identification */
    ret = cm_ipe_user_identify_user_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_user_identification error!\n");
         goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_ipe_bus[SIM_IPE_UI2PP])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_UI2PP]((void *)in_pkt));
    }
#endif

    /* IPE Interface Mapper */
    ret = cm_ipe_interface_mapper(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_interface_mapper error!\n");
         goto error;
    }

    /* IPE MPLS & Tunnel Decapsulation */
    ret = cm_ipe_tunnel_terminate_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_tunnel_terminate_handle error!\n");
         goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
     if (cosim_db.store_ipe_bus[SIM_IPE_IM2PP])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_IM2PP]((void *)in_pkt));
    }

    if (cosim_db.store_ipe_bus[SIM_IPE_IMPI2LM])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_IMPI2LM]((void *)in_pkt));
    }

    if (cosim_db.store_ipe_bus[SIM_IPE_IMPR2LM])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_IMPR2LM]((void *)in_pkt));
    }
#endif

    /* IPE Lookup Manager */
    ret = cm_ipe_lookup_manager_lookup_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_lookup_manager_lookup_handle error!\n");
         goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_ipe_bus[SIM_IPE_LM2PP])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_LM2PP]((void *)in_pkt));
    }
#endif

    /* IPE Outer Learning */
    ret = cm_ipe_outer_learning_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_outer_learning_handle error!\n");
       goto error;
    }

    /* IPE AclQos */
    ret = cm_ipe_acl_qos_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_acl_qos_handle error!\n");
        goto error;
    }

    /* IPE Routing */
    ret = cm_ipe_routing_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_routing_handle error!\n");
      goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_ipe_bus[SIM_IPE_RT2FW])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_RT2FW]((void *)in_pkt));
    }
#endif

    /* IPE Fcoe */
    ret = cm_ipe_fcoe_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_fcoe_handle error!\n");
        goto error;
    }

    /* IPE Trill */
    ret = cm_ipe_trill_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_trill_handle error!\n");
          goto error;
    }

    /* IPE Bridging */
    ret = cm_ipe_bridge_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_bridge_handle error!\n");
       goto error;
    }

    /* IPE Learning */
    ret = cm_ipe_learning_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_learning_handle error!\n");
     goto error;
    }

    /* IPE Classfication */
    ret = cm_ipe_classification_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_classification_handle error!\n");
         goto error;
    }

    /* IPE Oam */
    ret = cm_ipe_oam_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_oam_handle error!\n");
         goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_ipe_bus[SIM_IPE_OM2FW])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_OM2FW]((void *)in_pkt));
    }

    DRV_IF_ERROR_RETURN(sim_store_share_field(SIM_MODULE_IPE, SIM_IPE_OM2FW, in_pkt));
#endif

    /* IPE Forwarding */
    ret = cm_ipe_forwarding_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_ipe_forwarding_handle error!\n");
         goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_ipe_bus[SIM_IPE_EXCP])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_EXCP]((void *)in_pkt));
    }
#endif

    /* Creat IPE Output */
    ret = sim_ipe_create_output(in_pkt, out_pkt_head);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! sim_ipe_create_output error!\n");
        goto error;
    }
error :
    /* Free IPE memory */
    ret = sim_ipe_free_memory(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! sim_ipe_free_memory error!\n");
        return ret;
    }

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       cm_do_fwd
* Purpose:    ASIC CModel FWD handle.
* Parameters:
* Input:      in_pkt -- pointer to FWD input.
* Output:     out_pkt_head -- pointer to linklist which store the FWD output packet
                            informations include packet header and exceptions.
              pkt_buf_info -- pointer to the packet position in bufferStore for co-sim
* Return:     DRV_E_NONE = success.
*             Other = ErrorCode, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
int32 cm_do_fwd(queue_in_pkt_t *in_pkt, list_head_t *out_pkt, void *pkt_buf_info)
{
    int32 ret = DRV_E_NONE;

    ret = sim_asic_gen_qmgt_inpkt(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! sim_asic_gen_qmgt_inpkt error!\n");
        return ret;
    }

    /* Mallocate memory for QMGT infomations */
    ret = sim_qmgt_mallocate_memory(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! sim_qmgt_mallocate_memory error!\n");
        return ret;
    }

    /* QMGT BufferStore */
    ret = cm_qmgt_buffer_store_handle(in_pkt, (pkt_buf_store_info_t *)pkt_buf_info);
    if (DRV_E_NONE != ret)
    {
        if (DRV_E_HARD_DISCARD == ret)
        {
            CMODEL_DEBUG_OUT_INFO("Packet has been hard discard in QMGT Buffer Store!\n");
            return DRV_E_NONE;
        }
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_qmgt_buffer_store_handle error!\n");
       goto error;
    }

    /* QMGT MetFifo */
    ret = cm_qmgt_met_fifo_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_qmgt_met_fifo_handle error!\n");
       goto error;
    }

    /* QMGT Qmanager */
    ret = cm_qmgt_qmanager_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_qmgt_qmanager_handle error!\n");
      goto error;
    }

    /* QMGT Retrieve */
    ret = cm_qmgt_buffer_retrieve_handle(in_pkt, out_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_qmgt_buffer_retrieve_handle error!\n");
       goto error;
    }
error:
    /* Free memory for QMGT infomations */
    ret = sim_qmgt_free_memory(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! sim_qmgt_free_memory error!\n");
        return ret;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_do_epe
 * Purpose:    ASIC CModel EPE handle.
 * Parameters:
 * Input:      in_pkt -- pointer to EPE input.
 * Output:     out_pkt -- pointer to linklist which store the EPE output packet
                        informations include packet header and exceptions.
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 cm_do_epe(epe_in_pkt_t *in_pkt, list_head_t *out_pkt)
{
    int32 ret = DRV_E_NONE;

    /* Store EPE Input packet */
    ret = sim_asic_gen_epe_inpkt(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! sim_asic_gen_epe_inpkt\n");
        return ret;
    }

    /* Mallocate memory for IPE input packet */
    ret = sim_epe_mallocate_memory(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! sim_epe_mallocate_memory error!\n");
        return ret;
    }

    /* EPE Header Adjust */
    ret = cm_epe_header_adjust_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_epe_header_adjust_handle error!\n");
         goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_epe_bus[SIM_EPE_PR2HP])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_PR2HP]((void *)in_pkt));
    }

    if (cosim_db.store_epe_bus[SIM_EPE_HA2NH])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_HA2NH]((void *)in_pkt));
    }

    if (cosim_db.store_epe_bus[SIM_EPE_HA2HP])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_HA2HP]((void *)in_pkt));
    }

    DRV_IF_ERROR_RETURN(sim_store_share_field(SIM_MODULE_EPE, SIM_EPE_HA2NH, in_pkt));
#endif

    /* EPE NextHop */
    ret = cm_epe_nexthop_mapper_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_epe_nexthop_mapper_handle error!\n");
      goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_epe_bus[SIM_EPE_NH2HP])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_NH2HP]((void *)in_pkt));
    }

    DRV_IF_ERROR_RETURN(sim_store_share_field(SIM_MODULE_EPE, SIM_EPE_NH2HP, in_pkt));
#endif

    /* EPE Payload */
    ret = cm_epe_payload_process_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_epe_payload_process_handle error!\n");
        goto error;
    }

    /* EPE Layer3 Edit */
    ret = cm_epe_layer3_editing_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_epe_layer3_editing_handle error!\n");
        goto error;
    }

    /* EPE Layer2 Edit */
    ret = cm_epe_layer2_editing_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_epe_layer2_editing_handle error!\n");
         goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_epe_bus[SIM_EPE_HP2AQ])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_HP2AQ]((void *)in_pkt));
    }

    if (cosim_db.store_epe_bus[SIM_EPE_HP2HE])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_HP2HE]((void *)in_pkt));
    }

    if (cosim_db.store_epe_bus[SIM_EPE_HP2OM])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_HP2OM]((void *)in_pkt));
    }
#endif

    /* EPE AclQos */
    ret = cm_epe_aclqos_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_epe_aclqos_handle error!\n");
          goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_epe_bus[SIM_EPE_AQ2CS])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_AQ2CS]((void *)in_pkt));
    }
#endif

    /* EPE Classification */
    ret = cm_epe_classification_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_epe_classification_handle error!\n");
        goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_epe_bus[SIM_EPE_CS2OM])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_CS2OM]((void *)in_pkt));
    }

    DRV_IF_ERROR_RETURN(sim_store_share_field(SIM_MODULE_EPE, SIM_EPE_HP2OM, in_pkt));
#endif

    /* EPE OAM */
    ret = cm_epe_oam_process_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_epe_oam_process_handle error!\n");
         goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_epe_bus[SIM_EPE_OM2HE])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_OM2HE]((void *)in_pkt));
    }
    DRV_IF_ERROR_RETURN(sim_store_share_field(SIM_MODULE_EPE, SIM_EPE_OM2HE, in_pkt));
#endif

    /* EPE Header Edit */
    ret = cm_epe_header_editing_handle(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_epe_header_editing_handle error!\n");
        goto error;

    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_epe_bus[SIM_EPE_EXCP])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_EXCP]((void *)in_pkt));
    }
#endif

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_epe_bus[SIM_EPE_NETTX])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_NETTX]((void *)in_pkt));
    }
#endif
    /* EPE NetTx */
    ret = cm_epe_net_tx_handle(in_pkt, out_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_epe_net_tx_handle error!\n");
        goto error;
    }
error:
    /* Free EPE Memory */
    ret = sim_epe_free_memory(in_pkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! sim_epe_free_memory error!\n");
    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_do_oam
 * Purpose:    ASIC CModel OAM handle.
 * Parameters:
 * Input:      in_pkt -- pointer to OAM input.
 * Output:     out_pkt -- pointer to linklist which store the OAM output packet
                        informations include packet header and exceptions.
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 cm_do_oam(oam_in_pkt_t* in_pkt, list_head_t *out_pkt)
{
    int32 ret;

    /*allocate memory for in pkt*/
    if ((ret = sim_oam_mallocate_memory(in_pkt)) < 0)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! sim_oam_mallocate_memory error!\n");
        return ret;
    }

    /*retrive pkt hdr info and remove the hdr from pkt data*/
    if ((ret = cm_oam_header_adjust_handle(in_pkt)) < 0)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_oam_header_adjust_handle error!\n");
        goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_oam_bus[SIM_OAM_HA2PP])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_oam_bus[SIM_OAM_HA2PP]((void *)in_pkt));
    }

    if (cosim_db.store_oam_bus[SIM_OAM_PR2PP])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_oam_bus[SIM_OAM_PR2PP]((void *)in_pkt));
    }
#endif

    /*oam rx process*/
    if ((ret = cm_oam_receive_process_handle(in_pkt)) < 0)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_oam_rx_process error!\n");
         goto error;
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_oam_bus[SIM_OAM_PP2FW])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_oam_bus[SIM_OAM_PP2FW]((void *)in_pkt));
    }
#endif

    if ((ret = cm_oam_header_edit_handle(in_pkt)) < 0)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! cm_oam_header_edit error!\n");
       goto error;
    }
    if ((ret = sim_oam_create_output(in_pkt, out_pkt)) < 0)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! oam_creat_output_pkt error!\n");
       goto error;
    }
error:
    if ((ret = sim_oam_free_memory(in_pkt)) < 0)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! oam_creat_output_pkt error!\n");
        return ret;
    }
    return DRV_E_NONE;
}

