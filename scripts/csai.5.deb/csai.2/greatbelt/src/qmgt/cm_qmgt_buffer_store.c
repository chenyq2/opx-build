/****************************************************************************
* cm_qmgt_buff_store.c: Provides buffer store funciton.
*
* Copyright (c)2011 Centec Networks Inc. All rights reserved.
*
* Revision:   V1.0.
* Author:     Zhouw.
* Date:       2010-10-21.
* Reason:     First Create.
*
* Modify History:
* Revision:   V2.0.
* Author:     Zhouw.
* Date:       2011-04-16.
* Reason:     Sync to SpecV2.0.
*
* Revision:   V4.2.1.
* Author:     Shenhg.
* Date:       2011-06-30.
* Reason:     Sync to SpecV4.2.1.
*
* Revision:   V4.28.2.
* Author:     ZhouW.
* Date:       2011-09-26.
* Reason:     Sync to SpecV4.28.2.
*
* Revision:   V4.29.3.
* Author:     Shenhg.
* Date:       2011-10-210.
* Reason:     Sync to SpecV4.29.3.
*
* Revision:   V5.6.0.
* Author:     Shenhg.
* Date:       2012-01-06.
* Reason:     Sync to SpecV5.6.0.
*
* Revision:   V5.9.1.
* Author:     Shenhg.
* Date:       2012-02-04.
* Reason:     Sync to SpecV5.9.1.
*
* Revision:   V5.13.0.
* Author:     ZhouW.
* Date:       2012-03-10.
* Reason:     Sync to SpecV5.13.0.
*
* Revision:   V5.15.0.
* Author:     ZhouW.
* Date:       2012-03-22.
* Reason:     Sync to SpecV5.15.0.
*
* Revision:     V5.15.2.
* Author:       ZhouW.
* Date:         2012-04-01.
* Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
*
* Defines and Macros
*
****************************************************************************/
enum packet_header_type_e
{
    GREATBELT_HEADER_TYPE = 0,
    HUMBE_HEADER_TYPE = 1,
    MAX_HEADER_TYPE = 2
};
typedef enum packet_header_type_e packet_header_type_t;
/****************************************************************************
*
* Global and Declarations
*
****************************************************************************/
/*-----------------------------------------------------------------------------------------------------------
   PhysicalInterface   LogicalInterface     Channel                   assignResourceGroupID[9:0]
-------------------------------------------------------------------------------------------------------------*/
/*  Gmac{0..47}          Gmac{0..47}        0..47         if (BufferStoreCtl.resrcUseLocalPhyPort[chanid]){
                                                            if (BufferStoreCtl.localPhyPortResrcIdPriEn) {
                                                                localPhyPortTmp[7:0]=localPhyPort[7:0]
                                                                                     - localPhyPortBase[7:0];
                                                                resrcGrpId = {localPhyPortTmp[6:0],
                                                                              rescDropPrecedence[2:0]};
                                                            } else
                                                                resrcGrpId = {2'b00, localPhyPort[7:0]};
                                                          } else
                                                            resrcGrpId = {1'b1, chanId[5:0], priority[2:0]};

    Sgmac{0:3}           Sgmac{0:3}     case(sgmaGrp0ChanSel)
                                        2'b00: 12..15
                                        2'b01: 16..19
                                        2'b10: 44..47
                                        2'b11: 48..51

    Sgmac{4:7}           Sgmac{4:7}     case(sgmaGrp1ChanSel)
                                        1'b0: 16..19
                                        1'b1: 48..51

    Sgmac{8:11}          Sgmac{8:11}    case(sgmaGrp2ChanSel)
                                        1'b0: 20..23
                                        1'b1: 52..55

    N/A               Interlaken{0..23}     24..47                    resrcGrpId = {4'd0, 256+chanId[5:0]}
                       (segment mode)

    N/A               Interlaken{0..47}       56                      if (BufferStoreCtl.intLkSingleChan)
                       (packet mode)                                       resrcGrpId = {1'b1, 6'd56, priority[2:0]};
                                                                      else
                                                                           resrcGrpId = {4'd0, chanId[5:0]};

    N/A                   ILoop               57                             10'd256+57

    CPU                   CPU                 58                             10'd256+58

    DMA                   DMA                 59                             10'd256+59

    N/A                   OAM                 60                             10'd256+60

    N/A                   ELoop               61                             10'd256+61

    N/A                   ELog                64..119                        10'd256+62

-------------------------------------------------------------------------------------------------------------*/

/****************************************************************************
*
* Functions
*
****************************************************************************/
static int32
_cm_qmgr_buffer_store_debug_in_packet_header_info(greatbelt_packet_header_t* p_cm_packet_header)
{
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "\nCModel Debug Qmgt Buffer Store: [QMGT HDR]In Pakcet Header: \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "--------------------------------------------------------- \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "mcast 0x%X\n",               p_cm_packet_header->mcast);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "dest_chip_id 0x%X\n",        p_cm_packet_header->dest_chip_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "dest_id 0x%X\n",             p_cm_packet_header->dest_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "next_hop_ptr 0x%X\n",        p_cm_packet_header->next_hop_ptr);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "from_fabric 0x%X\n",         p_cm_packet_header->from_fabric);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "bypass_ingress_edit 0x%X\n", p_cm_packet_header->bypass_ingress_edit);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "from_cpu_or_oam 0x%X\n",     p_cm_packet_header->from_cpu_or_oam);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "operation_type 0x%X\n",      p_cm_packet_header->operation_type);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "--------------------------------------------------------- \n");

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       cm_qmgt_buffer_store_handle
* Purpose:    Handle AISC buffer store simulation function.
* Parameters:
* Input:      p_qpkt  -- queue management packet pointer.
*             p_pkt_buf_info -- Packet buffer information pointer.
* Output:     p_qpkt  -- queue management packet pointer.
* Return:     DRV_E_NONE = success.
*             Other = Error, please refer to DRV_E_XXX.
* Note:       None.
****************************************************************************/
int32
cm_qmgt_buffer_store_handle(queue_in_pkt_t *p_qpkt,  pkt_buf_store_info_t *p_pkt_buf_info)
{
    queue_packet_info_t *p_pkt_info = (queue_packet_info_t*)p_qpkt->pkt_info;
    uint8 p_header[GREAT_BELT_HEADER_LEN] = {0};
    greatbelt_packet_header_t cm_packet_header;
    greatbelt_exception_info_t *p_exception = p_pkt_info->bexception;
    fwd_ms_met_fifo_t *p_ms_met_fifo = (fwd_ms_met_fifo_t*)p_pkt_info->ms_met_fifo;
    buffer_store_ctl_t buffer_store_ctl;
    buf_store_oob_fc_ctl_t buffer_store_ctl0;
    met_fifo_priority_map_table_t met_fifo_priority_map_table;
    buffer_store_force_local_ctl_t buffer_store_force_local_ctl;
    ds_src_sgmac_group_t ds_src_sgmac_group;
    buf_store_sgmac_ctl_t buffer_store_sgmac_ctl;
    ms_packet_header_t *temp_bheader = NULL; /* temp var */

    uint32 cmd = 0, destmap_21_to_0 = 0, mcast_rcd_vector = 0;
    uint8 force_local_switching = FALSE, local_switching = FALSE, resrc_id_use_local_phy_port = FALSE;
    uint8 mcast_rcd = FALSE, metfifo_priority = 0, mcast_metfifo = FALSE;

    uint16 vector_bit_1_num = 0, vector_bit_index = 0;

    uint8 source_chip_id = 0;
    int32 ret = DRV_E_NONE;
    uint8 resc_drop_precedence = 0, tmp_local_phy_port = 0;
    uint8 rx_oam = FALSE, c2c_check_disable = FALSE;
    uint8 cpu_exception_en = FALSE;
    uint8 exception_from_sgmac = FALSE;
    bool from_cpu_en = FALSE;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Buffer Store Process");

    sal_memset(&buffer_store_ctl, 0, sizeof(buffer_store_ctl));

    sal_memset(&met_fifo_priority_map_table, 0, sizeof(met_fifo_priority_map_table));

    sal_memset(&buffer_store_force_local_ctl, 0, sizeof(buffer_store_force_local_ctl_t));
    sal_memset(&buffer_store_ctl0, 0, sizeof(buffer_store_ctl0));
    sal_memset(&buffer_store_sgmac_ctl, 0, sizeof(buffer_store_sgmac_ctl));

    /*for interlaken channel*/
    if (IS_BIT_SET(p_qpkt->chan_id,7))
    {
        p_qpkt->chan_id = INTERLAKEN_CHANID;
    }

    cmd = DRV_IOR(BufStoreOobFcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &buffer_store_ctl0));

    /* Greatbelt Bridge-Header */
    sal_memcpy(p_header, p_qpkt->module_bus.packet_header, sizeof(ms_packet_header_t));
    sal_memcpy(p_exception, p_qpkt->exception, sizeof(greatbelt_exception_info_t));
    DRV_IF_ERROR_RETURN(swap32((uint32*)p_header, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));

    sal_memset(&cm_packet_header, 0, sizeof(greatbelt_packet_header_t));
    cm_gen_greatbelt_packet_header((ms_packet_header_t *)p_header, &cm_packet_header, TRUE);

    _cm_qmgr_buffer_store_debug_in_packet_header_info(&cm_packet_header);

    /* Only accept packets which should be received */
    cmd = DRV_IOR(BufferStoreCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &buffer_store_ctl));

    p_qpkt->from_fabric = cm_packet_header.from_fabric;

    if (!p_qpkt->from_fabric                                                    /* local originated */
        || buffer_store_ctl.chip_id_check_disable                               /* disable checking */
        || (buffer_store_ctl.chip_id == cm_packet_header.dest_chip_id)          /* destChipId matched */
        || (cm_packet_header.mcast && (0x1F == cm_packet_header.dest_chip_id))) /* Fabric/Stacking Bcast */
    {
        CMODEL_DEBUG_OUT_INFO("CModelDebug: BufferStore Accept Packet!\n");
    }
    else
    {
        /* if hard discard, drop this packet immediately,
           free memory and stop forward process */
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE,
                             "Qmgt Buffer Store: Hard Discard Packet1.\n");

        ret = sim_qmgt_free_memory(p_qpkt);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! When Hard discard, fail to free memory!\n");
            return ret;
        }
        CMODEL_DEBUG_OUT_INFO("CModelDebug: BufferStore Discard Packet1!\n");

        return DRV_E_HARD_DISCARD;
    }


    /* Stacking source chipid extraction, PacketHeader.sourcePort[15:0] encoded as:
       For link aggregation,   sourcePort[13:9]: 5'h1F,
                               sourcePort[8:4]: sourceChipId,
                               sourcePort[15:14], sourcePort[3:0]: link aggregation ID
       For individual port,    sourcePort[13:9]: sourceChipId
                               sourcePort[8:0]: port ID     */

    source_chip_id = (cm_packet_header.source_port >> 9) & 0x1F;
    if (p_qpkt->from_fabric && buffer_store_ctl.stacking_en &&(((cm_packet_header.source_port>> 9) & 0x1F) == 0x1F))
    {
        source_chip_id = (cm_packet_header.source_port15_14 << 3) | ((cm_packet_header.source_port>> 6) & 0x7);
    }

    /* C2C to SGMAC with specified priority and buffer policy */
    rx_oam = (cm_packet_header.operation_type == OPERATION_TYPE_OAM)
                && cm_packet_header.ip_sa_u.share3.rx_oam;

    /* bypass normal forward */
    c2c_check_disable = (cm_packet_header.operation_type == OPERATION_TYPE_C2C)
                        && cm_packet_header.rxtx_fcl0_u.c2c_check_disable;

    /* discard self-originated packet for loop prevention, etc */
    cmd = DRV_IOR(BufStoreSgmacCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &buffer_store_sgmac_ctl));

    from_cpu_en = (p_qpkt->chan_id < 32) ? IS_BIT_SET(buffer_store_sgmac_ctl.from_cpu_en31_0, p_qpkt->chan_id):
                  IS_BIT_SET(buffer_store_sgmac_ctl.from_cpu_en63_32, (p_qpkt->chan_id-32));

    if (p_qpkt->from_fabric && (IS_BIT_SET(buffer_store_ctl.force_discard_source_chip, (source_chip_id & 0x1F))
         ||(IS_BIT_SET(buffer_store_ctl.discard_source_chip, (source_chip_id & 0x1F))
        && (!rx_oam && !c2c_check_disable) && !from_cpu_en)))
    {
       /* if hard discard, drop this packet immediately,
          free memory and stop forward process */
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE,
                             "Qmgt Buffer Store: Hard Discard Stacking Loop Packet.\n");

        ret = sim_qmgt_free_memory(p_qpkt);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! When Hard discard, fail to free memory!\n");
            return ret;
        }
        CMODEL_DEBUG_OUT_INFO("CModelDebug: Stacking loop discard packet in BufferStore!\n");

        return DRV_E_HARD_DISCARD;
    }

    /* Hard discard */
    /* No destination(normal and exception) */
    if (p_exception->dest_id_discard && (0 == p_exception->exception_vector))
    {
        /* if hard discard, drop this packet immediately,
           free memory and stop forward process */
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE,
                             "Qmgt Buffer Store: Hard Discard No Dest Packet\n");

        ret = sim_qmgt_free_memory(p_qpkt);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! When Hard discard, fail to free memory!\n");
            return ret;
        }

        CMODEL_DEBUG_OUT_INFO("CModelDebug: PktHdr.destIdDiscard = 1, Discard in BufferStore!\n");

        return DRV_E_HARD_DISCARD;
    }

    /* Deciding if primary destination map is unicast or not */
    destmap_21_to_0 = (cm_packet_header.mcast<<21) | (cm_packet_header.dest_chip_id<<16) | cm_packet_header.dest_id;

    cmd = DRV_IOR(BufferStoreForceLocalCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &buffer_store_force_local_ctl));

    force_local_switching
        = ((destmap_21_to_0 & buffer_store_force_local_ctl.dest_map_mask0)
                == (buffer_store_force_local_ctl.dest_map_value0 & buffer_store_force_local_ctl.dest_map_mask0))
          || ((destmap_21_to_0 & buffer_store_force_local_ctl.dest_map_mask1)
                == (buffer_store_force_local_ctl.dest_map_value1 & buffer_store_force_local_ctl.dest_map_mask1))
          || ((destmap_21_to_0 & buffer_store_force_local_ctl.dest_map_mask2)
                == (buffer_store_force_local_ctl.dest_map_value2 & buffer_store_force_local_ctl.dest_map_mask2))
          || ((destmap_21_to_0 & buffer_store_force_local_ctl.dest_map_mask3)
                == (buffer_store_force_local_ctl.dest_map_value3 & buffer_store_force_local_ctl.dest_map_mask3));
    exception_from_sgmac = p_exception->exception_from_sgmac;

    if (((p_qpkt->chan_id == CPU_CHANID) || (p_qpkt->chan_id == DMA_CHANID))
        && buffer_store_ctl.cpu_tx_exception_en)        /* MsMetFifo.exceptionVector[7:0] must be 0 */
    {
        cpu_exception_en = TRUE;
        exception_from_sgmac = FALSE;
    }
    else if (((p_exception->exception_vector != 0) && buffer_store_ctl.cpu_rx_exception_en0)
             || ((!cm_packet_header.mcast)
                   &&(cm_packet_header.dest_chip_id == buffer_store_ctl.chip_id)
                   && ((cm_packet_header.dest_id & 0xFF) == buffer_store_ctl.cpu_port)
                   && buffer_store_ctl.cpu_rx_exception_en1))
    {
       cpu_exception_en = TRUE;
    }

    /* When local switching is disabled, forceLocalSwitching is expected to be set for CPU queues
       and multicast to different destination chips */
    local_switching = (!buffer_store_ctl.local_switching_disable /* enabled (stacking and standalone mode always enabled */
                       || p_qpkt->from_fabric                    /* from fabric */
                       || force_local_switching);                /* force local switching */

    if (!p_exception->dest_id_discard && local_switching && cm_packet_header.mcast)
    {
        mcast_rcd = TRUE;
    }
    else
    {
        mcast_rcd_vector = ((!p_exception->dest_id_discard) << (MAX_EXCEPTION_VECT_BIT_NUM))
                            | (cpu_exception_en << EXCEPTION_VECT_BIT_CPU_LOG)
                            | (p_exception->exception_vector & 0xFF);

        for (vector_bit_index = 0; vector_bit_index <= MAX_EXCEPTION_VECT_BIT_NUM+1; vector_bit_index++)
        {
            if (IS_BIT_SET(mcast_rcd_vector, vector_bit_index))
            {
                vector_bit_1_num++;
            }
        }

        if (vector_bit_1_num > 1)
        {
            mcast_rcd = TRUE;
        }
        else
        {
            mcast_rcd = FALSE;
        }
    }

    /* SELECT_MET_FIFO */

    cmd = DRV_IOR(MetFifoPriorityMapTable_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id,
                                   (cm_packet_header.priority << 2)|cm_packet_header.color,
                                   cmd, &met_fifo_priority_map_table));
    metfifo_priority = met_fifo_priority_map_table.met_fifo_priority;

    /* The real packet length. In case of error,
       this length may not match the length in the header */

    /*  here cmodel is different from spec, in spec description is as follow:
        MsMetFifo.packetLength[13:0] = packetLength[13:0] */
    p_ms_met_fifo->msg_metfifo.packet_length = p_qpkt->packet_length; /* for eop,sop&eop packet */

    p_ms_met_fifo->msg_metfifo.next_hop_ext = cm_packet_header.next_hop_ext;
    p_ms_met_fifo->msg_metfifo.operation_type = cm_packet_header.operation_type;
    p_ms_met_fifo->msg_metfifo.oam_dest_chip_id = cm_packet_header.source_port_isolate_id_u.share2.oam_dest_chip_id;
    p_ms_met_fifo->msg_metfifo.rx_oam = rx_oam;
    p_ms_met_fifo->msg_metfifo.c2c_check_disable = cm_packet_header.rxtx_fcl0_u.c2c_check_disable;

    p_ms_met_fifo->msg_metfifo.rx_oam_type1_0 = (cm_packet_header.ip_sa_u.share2.oam_type & 0x3);
    p_ms_met_fifo->msg_metfifo.rx_oam_type3_2 = (cm_packet_header.ip_sa_u.share2.oam_type>>2)&0x3;
    p_ms_met_fifo->msg_metfifo.payload_offset = cm_packet_header.packet_offset;

    if (OPERATION_TYPE_NORMAL == cm_packet_header.operation_type)
    {
        p_ms_met_fifo->msg_metfifo.ecn_en = cm_packet_header.ip_sa_u.share1.ecn_en;
        p_ms_met_fifo->msg_metfifo.ecn_aware = cm_packet_header.ip_sa_u.share1.ecn_aware;
    }
    else
    {
        p_ms_met_fifo->msg_metfifo.ecn_en = FALSE;
        p_ms_met_fifo->msg_metfifo.ecn_aware = FALSE;
    }
    
    /* ======== bug 4666 ECO begine ========= */
    //if ((OPERATION_TYPE_NORMAL == cm_packet_header.operation_type) || (OPERATION_TYPE_PTP == cm_packet_header.operation_type))
    if (OPERATION_TYPE_NORMAL == cm_packet_header.operation_type)
    /* ======== bug 4666 ECO end ========= */
    {
        p_ms_met_fifo->msg_metfifo.service_id = cm_packet_header.logic_src_port_u.share1.logic_src_port;
    }

    p_ms_met_fifo->msg_metfifo.is_leaf = cm_packet_header.flow_u.share1.is_leaf;
    p_ms_met_fifo->msg_metfifo.from_fabric = p_qpkt->from_fabric;
    p_ms_met_fifo->msg_metfifo.local_switching = local_switching;

   if (((p_qpkt->chan_id&0x3F )<=NETWORK_MAX_CHANID ) ||(p_qpkt->chan_id&0x3F ) == INTERLAKEN_CHANID)
    {
        cmd = DRV_IOR(DsSrcSgmacGroup_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, p_qpkt->chan_id&0x3F, cmd, &ds_src_sgmac_group));
        p_ms_met_fifo->msg_metfifo.src_sgmac_group_id = ds_src_sgmac_group.sgmac_group_id;
    }

    mcast_metfifo = buffer_store_ctl.mcast_met_fifo_enable
                    && (!p_exception->dest_id_discard)
                    && local_switching
                    && cm_packet_header.mcast;
    p_ms_met_fifo->msg_metfifo.met_fifo_select = (mcast_metfifo << 1) | metfifo_priority;



    p_ms_met_fifo->msg_metfifo.exception_packet_type = p_exception->exception_packet_type;
    p_ms_met_fifo->msg_metfifo.exception_sub_index5_2 = p_exception->exception_sub_index >> 2;
    p_ms_met_fifo->msg_metfifo.exception_sub_index1_0 = p_exception->exception_sub_index & 0x3;
    p_ms_met_fifo->msg_metfifo.l2_span_id = p_exception->l2_span_id;
    p_ms_met_fifo->msg_metfifo.l3_span_id = p_exception->l3_span_id;
    p_ms_met_fifo->msg_metfifo.acl_log_id0 = p_exception->acl_log_id0;
    p_ms_met_fifo->msg_metfifo.acl_log_id1 = p_exception->acl_log_id1;
    p_ms_met_fifo->msg_metfifo.acl_log_id2 = p_exception->acl_log_id2;
    p_ms_met_fifo->msg_metfifo.acl_log_id3 = p_exception->acl_log_id3;
    p_ms_met_fifo->msg_metfifo.exception_number = p_exception->exception_number;
    p_ms_met_fifo->msg_metfifo.exception_vector0_0 =  (p_exception->exception_vector & 0x1);
    p_ms_met_fifo->msg_metfifo.exception_vector8_1 =  ((p_exception->exception_vector >> 0x1) & 0x7F);
    p_ms_met_fifo->msg_metfifo.egress_exception = p_exception->egress_exception;
    p_ms_met_fifo->msg_metfifo.exception_vector8_1 &= 0x7F;
    p_ms_met_fifo->msg_metfifo.exception_vector8_1 |= (cpu_exception_en << 7);
    p_ms_met_fifo->msg_metfifo.exception_from_sgmac = exception_from_sgmac;

    p_ms_met_fifo->msg_metfifo.logic_port_type = cm_packet_header.logic_port_type;
    p_ms_met_fifo->msg_metfifo.fid = cm_packet_header.fid_u.share1.fid;
    p_ms_met_fifo->msg_metfifo.src_queue_select = cm_packet_header.src_queue_select;
    p_ms_met_fifo->msg_metfifo.length_adjust_type = cm_packet_header.length_adjust_type;
    p_ms_met_fifo->msg_metfifo.critical_packet = cm_packet_header.critical_packet;
    p_ms_met_fifo->msg_metfifo.color = cm_packet_header.color;
    p_ms_met_fifo->msg_metfifo.header_hash = (cm_packet_header.header_hash7_3 << 3) | cm_packet_header.header_hash2_0;
    p_ms_met_fifo->msg_metfifo.priority = cm_packet_header.priority;
    p_ms_met_fifo->msg_metfifo.source_port = (cm_packet_header.source_port15_14<<14) | cm_packet_header.source_port;
    p_ms_met_fifo->msg_metfifo.next_hop_ptr = cm_packet_header.next_hop_ptr & 0xFFFF;

    p_ms_met_fifo->msg_metfifo.dest_id_discard = p_exception->dest_id_discard;

    /* ======== bug 4666 ECO begine ========= */
    //if ((OPERATION_TYPE_NORMAL == cm_packet_header.operation_type) || (OPERATION_TYPE_PTP == cm_packet_header.operation_type))
    if (OPERATION_TYPE_NORMAL == cm_packet_header.operation_type)
    /* ======== bug 4666 ECO end ========= */
    {
        p_ms_met_fifo->msg_metfifo.flow_id = cm_packet_header.flow_u.share1.flow_id;
    }

    p_ms_met_fifo->msg_metfifo.old_dest_map = (cm_packet_header.mcast << 21)
                                                | (cm_packet_header.dest_chip_id << 16)
                                                | cm_packet_header.dest_id;

    p_ms_met_fifo->msg_metfifo.mcast_rcd  = mcast_rcd;

    if (p_qpkt->from_fabric && buffer_store_ctl.critical_packet_from_fabric)
    {
        p_ms_met_fifo->msg_metfifo.critical_packet  = TRUE;
        temp_bheader = (ms_packet_header_t *)p_header;
        temp_bheader->critical_packet = TRUE;
        DRV_IF_ERROR_RETURN(swap32((uint32*)temp_bheader, GREAT_BELT_HEADER_LEN/4, HOST_TO_NETWORK));

        /* Recal HeaderCRC */
        ((uint8 *)temp_bheader)[GREATBELT_HDR_CRC_OFFSET] &= 0xF0;
        ((uint8 *)temp_bheader)[GREATBELT_HDR_CRC_OFFSET] |= calculate_crc4((uint8 *)temp_bheader, GREAT_BELT_HEADER_LEN, 0);
        sal_memcpy(p_qpkt->module_bus.packet_header, temp_bheader, GREAT_BELT_HEADER_LEN);
    }

    switch (p_ms_met_fifo->msg_metfifo.met_fifo_select)
    {
        /* Here CMODEL can not realize */
        case 0:
            /* push into unicast low priority MET FIFO */
            break;
        case 1:
            /* push into unicast high priority MET FIFO */
            break;
        case 2:
            /* push into multicast log priority MET FIFO */
            break;
        default:
            /* push into multicast high priority MET FIFO */
            break;
    }

    /* Only use simulation, when bus compare. Asic will send the value to cmodel,
       so easily find the corresponding msg in the saved msg list. */
    if (NULL != p_pkt_buf_info)
    {
        p_ms_met_fifo->msg_metfifo.head_buffer_ptr = p_pkt_buf_info->head_buffer_ptr;
        p_ms_met_fifo->msg_metfifo.tail_buffer_ptr = p_pkt_buf_info->tail_buffer_ptr;
        p_ms_met_fifo->msg_metfifo.buffer_count = p_pkt_buf_info->buffer_count;
        p_ms_met_fifo->msg_metfifo.head_buf_offset = p_pkt_buf_info->head_buf_offset;
        p_ms_met_fifo->msg_metfifo.msg_type =  p_pkt_buf_info->msg_type;
    }

    if (p_qpkt->chan_id < MAX_CHANID)  /* Nework channel */
    {
        if (p_qpkt->chan_id < 32)
        {
            resrc_id_use_local_phy_port
                = IS_BIT_SET(buffer_store_ctl.resrc_id_use_local_phy_port31_0, p_qpkt->chan_id);
        }
        else
        {
            resrc_id_use_local_phy_port
                = IS_BIT_SET(buffer_store_ctl.resrc_id_use_local_phy_port63_32, (p_qpkt->chan_id - 32));
        }

        if (resrc_id_use_local_phy_port)
        {
            if (buffer_store_ctl0.local_phy_port_resrc_pri_en)
            {
                tmp_local_phy_port = (cm_packet_header.ip_sa_u.share2.local_phy_port & 0xFF)
                                - buffer_store_ctl0.local_phy_port_resrc_base; /* buffer_store_ctl0 need to get from RTL??? */

                p_ms_met_fifo->msg_metfifo.resource_group_id
                    = ((tmp_local_phy_port&0x7F)<<3) | resc_drop_precedence;
            }
            else
            {
                p_ms_met_fifo->msg_metfifo.resource_group_id = p_qpkt->local_phy_port & 0xFF;
            }
        }
        else
        {
            p_ms_met_fifo->msg_metfifo.resource_group_id
                = (1<<9) | ((p_qpkt->chan_id&0x3F) << 3) | resc_drop_precedence;
        }
    }
    else if (I_LOOPBACK_CHANID == p_qpkt->chan_id) /* I-Loop channel */
    {
        p_ms_met_fifo->msg_metfifo.resource_group_id = I_LOOP_RESOURCE_GROUPID;
    }
    else if (CPU_CHANID == p_qpkt->chan_id)       /* CPU channel */
    {
        p_ms_met_fifo->msg_metfifo.resource_group_id = CPU_RESOURCE_GROUPID;
    }
    else if (DMA_CHANID == p_qpkt->chan_id)       /* DMA channel */
    {
        p_ms_met_fifo->msg_metfifo.resource_group_id = DMA_RESOURCE_GROUPID;
    }
    else if (OAM_CHANID == p_qpkt->chan_id)       /* OAM channel */
    {
        p_ms_met_fifo->msg_metfifo.resource_group_id = OAM_RESOURCE_GROUPID;
    }
    else if (E_LOOPBACK_CHANID == p_qpkt->chan_id)/* ELOOP channel */
    {
        p_ms_met_fifo->msg_metfifo.resource_group_id = E_LOOP_RESOURCE_GROUPID;
    }
    else if ((p_qpkt->chan_id >= ELOG_MIN_CHANID)
            && (p_qpkt->chan_id <= ELOG_MAX_CHANID))/* ELOG channel: 64 - 119 */
    {
        p_ms_met_fifo->msg_metfifo.resource_group_id = ELOG_RESOURCE_GROUPID;
    }
    else if (IS_BIT_SET(p_qpkt->chan_id, 7))/* InterLaken channel(Packet Model), Segment Model??? */
    {
        if (buffer_store_ctl0.int_lk_single_chan)
        {
            p_ms_met_fifo->msg_metfifo.resource_group_id
                = (1<<9) | (56 << 3) | resc_drop_precedence;
        }
        else
        {
            p_ms_met_fifo->msg_metfifo.resource_group_id = (p_qpkt->chan_id&0x3F);
        }
    }
    else
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE,
                             "Qmgt Buffer Store: Hard Discard No Dest Packet.\n");
        return DRV_E_INVALID_CHANID;
    }


#if (SDK_WORK_PLATFORM == 1)
    /* Store metfifo message for fwd co-simulation */
    if(cosim_db.store_bsr_bus[SIM_FWD_MS_MET_FIFO])
    {
        ret = cosim_db.store_bsr_bus[SIM_FWD_MS_MET_FIFO](p_ms_met_fifo);
        if(DRV_E_NONE != ret)
        {
            return ret;
        }
    }
#endif

    return DRV_E_NONE;
}

