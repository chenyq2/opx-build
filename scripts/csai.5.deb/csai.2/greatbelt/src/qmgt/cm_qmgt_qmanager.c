/****************************************************************************
* cm_qmgt_qmanager.c: Provides Queue management funciton.
*
* Copyright:(c)2011 Centec Networks Inc. All rights reserved.
*
* Revision:   V1.0.
* Author:     Zhouw.
* Date:       2010-10-21.
* Reason:     First Create.
*
* Modify History:
* Revision:   V2.0.
* Author:     Zhouw.
* Date:       2011-04-18.
* Reason:     Sync to SpecV2.0.
*
* Modify History:
* Revision:   V4.2.1.
* Author:     Shenhg.
* Date:       2011-07-08.
* Reason:     Sync to SpecV4.2.1.
*
* Revision:   V4.28.2.
* Author:     ZhouW.
* Date:       2011-09-26.
* Reason:     Sync to SpecV4.28.2.
*
* Revision:   V4.29.3.
* Author:     Shenhg.
* Date:       2011-10-10.
* Reason:     Sync to SpecV4.29.3.
*
* Revision:   V5.6.0.
* Author:     Shenhg.
* Date:       2012-01-06.
* Reason:     Sync to SpecV5.6.0.
*
* Revision:   V5.13.0.
* Author:     ZhouW.
* Date:       2012-03-10.
* Reason:     Sync to SpecV5.13.0.
*
* Revision:   V5.15.0.
* Author:     ZhouW.
* Date:       2012-03-22.
* Reason:     Sync to SpecV5.15.0.
*
* Revision:     V5.15.2.
* Author:       ZhouW.
* Date:         2012-04-01.
* Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
*
* Defines and Macros
*
****************************************************************************/
/****************************************************************************
*
* Global and Declarations
*
****************************************************************************/
struct cm_qmgt_qmanager_q_hash_cam_ctl_s
{
   uint32 rsv_0                                                            :6;
   uint32 queue_base0                                                      :10;
   uint32 rsv_1                                                            :1;
   uint32 hash_type0                                                       :7;
   uint32 rsv_2                                                            :2;
   uint32 sgmac0                                                           :6;

   uint32 dest_queue0                                                      :16;
   uint32 valid0                                                           :1;
   uint32 rsv_3                                                            :1;
   uint32 channel_id0                                                      :6;
   uint32 rsv_4                                                            :2;
   uint32 mcast0                                                           :1;
   uint32 dest_chip_id0                                                    :5;

   uint32 rsv_5                                                            :2;
   uint32 service_id0                                                      :14;
   uint32 rsv_6                                                            :2;
   uint32 fid0                                                             :14;
};

typedef struct cm_qmgt_qmanager_q_hash_cam_ctl_s cm_qmgt_qmanager_q_hash_cam_ctl_t;

/****************************************************************************
*
* Functions
*
****************************************************************************/
static int32
_cm_qmgr_qmanager_debug_queue_hash_key_lookup_info(lookup_info_t* p_lookup_info)
{
    ds_queue_hash_key_t* p_ds_queue_hash_key;

    p_ds_queue_hash_key = (ds_queue_hash_key_t*)p_lookup_info->p_ds_key;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "\n[Debug Qmgt Queue Manager]: [LOOKUP��KEY]Queue Hash Lookup Key, Chip Id %d.\n", p_lookup_info->chip_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "--------------------------------------------------------- \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "sgmac0: 0x%X\n",       p_ds_queue_hash_key->sgmac0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "hash_type0: 0x%X\n",   p_ds_queue_hash_key->hash_type0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "queue_base0: 0x%X\n",  p_ds_queue_hash_key->queue_base0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "dest_chip_id: 0x%X\n", p_ds_queue_hash_key->dest_chip_id0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "mcast0: 0x%X\n",       p_ds_queue_hash_key->mcast0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "channel_id0: 0x%X\n",  p_ds_queue_hash_key->channel_id0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "valid0: 0x%X\n",       p_ds_queue_hash_key->valid0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "dest_queue0: 0x%X\n",  p_ds_queue_hash_key->dest_queue0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "fid0: 0x%X\n",         p_ds_queue_hash_key->fid0);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY, "service_id0: 0x%X\n",  p_ds_queue_hash_key->service_id0);

    return DRV_E_NONE;
}

static int32
_cm_qmgr_qmanager_debug_queue_hash_key_result_info(lookup_result_t* p_lookup_result)
{
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_KEY_INFO, "\n[Debug Qmgt Queue Manager]: [KEY INFO]Queue Hash Lookup Key Lookup Result.\n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_KEY_INFO, "--------------------------------------------------------- \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_KEY_INFO, "key_index: 0x%X\n",   p_lookup_result->key_index);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_KEY_INFO, "valid: 0x%X\n",       p_lookup_result->valid);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_KEY_INFO, "queue_base: 0x%X\n",  p_lookup_result->ad_index);

    return DRV_E_NONE;
}

static int32
_cm_qmgr_qmanager_debug_dequeue_msg(fwd_ms_dequeue_t *p_ms_dequeue)
{
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "\n[Debug Qmgt Queue Manager]: [QMGT MSG]Dequeue Msg: \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "--------------------------------------------------------- \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "head_buffer_ptr: 0x%X\n",     p_ms_dequeue->msg_dequeue.head_buffer_ptr);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "head_buf_offset: 0x%X\n",     p_ms_dequeue->msg_dequeue.head_ptr_offset);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "buffer_count: 0x%X\n",        p_ms_dequeue->msg_dequeue.resource_group_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "replication_ctl_ext: 0x%X\n", p_ms_dequeue->msg_dequeue.packet_length);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "msg_type: 0x%X\n",            p_ms_dequeue->msg_dequeue.sub_grp_sel);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "tail_buffer_ptr: 0x%X\n",     p_ms_dequeue->msg_dequeue.rcd);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "resource_group_id: 0x%X\n",   p_ms_dequeue->msg_dequeue.mcast_rcd);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "packet_length: 0x%X\n",       p_ms_dequeue->msg_dequeue.release_packet);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "rcd: 0x%X\n",                 p_ms_dequeue->msg_dequeue.grp_bucket_upd_vec);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "mcast_rcd: 0x%X\n",           p_ms_dequeue->msg_dequeue.que_use_cir_deficit);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "last_enqueue: 0x%X\n",        p_ms_dequeue->msg_dequeue.queue_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "enqueue_discard: 0x%X\n",     p_ms_dequeue->msg_dequeue.grp_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "fid: 0x%X\n",                 p_ms_dequeue->msg_dequeue.chan_pri);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "payload_offset: 0x%X\n",      p_ms_dequeue->msg_dequeue.replication_ctl);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "source_chip_id: 0x%X\n",      p_ms_dequeue->msg_dequeue.in_profile);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "operation_type: 0x%X\n",      p_ms_dequeue->msg_dequeue.next_hop_ext);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "dest_sgmac_group_id: 0x%X\n", p_ms_dequeue->msg_dequeue.pt_enable);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "color: 0x%X\n",               p_ms_dequeue->msg_dequeue.length_adjust_type);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "next_hop_ext: 0x%X\n",        p_ms_dequeue->msg_dequeue.dest_select);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "rx_oam: 0x%X\n",              p_ms_dequeue->msg_dequeue.discard);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "ecn_aware: 0x%X\n",           p_ms_dequeue->msg_dequeue.congestion_valid);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "replicated_met: 0x%X\n",      p_ms_dequeue->msg_dequeue.dest_map);

    return DRV_E_NONE;
}

static uint16
_cm_qmgt_qmanager_fn_queue_shift( uint16 pre_shift_vector, uint8 shift)
{
/* shift function FnQueueShift used is as following:
    case (shift[3:0])
    // 4'b0000: shiftedVector[15:0] = preShiftedVector[15;0];
    // 4'b0001: shitfedVector[15:0] = {preShiftedVector[0], preShiftedVector[15:1]};
    // 4'b0010: shitfedVector[15:0] = {preShiftedVector[1:0], preShiftedVector[15:2]};
    // 4'b0011: shitfedVector[15:0] = {preShiftedVector[2:0], preShiftedVector[15:3]};
    // 4'b0100: shitfedVector[15:0] = {preShiftedVector[3:0], preShiftedVector[15:4]};
    // 4'b0101: shitfedVector[15:0] = {preShiftedVector[4:0], preShiftedVector[15:5]};
    // 4'b0110: shitfedVector[15:0] = {preShiftedVector[5:0], preShiftedVector[15:6]};
    // 4'b0111: shitfedVector[15:0] = {preShiftedVector[6:0], preShiftedVector[15:7]};
    // 4'b1000: shitfedVector[15:0] = {preShiftedVector[7:0], preShiftedVector[15:8]};
    // 4'b1001: shitfedVector[15:0] = {preShiftedVector[8:0], preShiftedVector[15:9]};
    // 4'b1010: shitfedVector[15:0] = {preShiftedVector[9:0], preShiftedVector[15:10]};
    // 4'b1011: shitfedVector[15:0] = {preShiftedVector[10:0], preShiftedVector[15:11]};
    // 4'b1100: shitfedVector[15:0] = {preShiftedVector[11:0], preShiftedVector[15:12]};
    // 4'b1101: shitfedVector[15:0] = {preShiftedVector[12:0], preShiftedVector[15:13]};
    // 4'b1110: shitfedVector[15:0] = {preShiftedVector[13:0], preShiftedVector[15:14]};
    // 4'b1111: shitfedVector[15:0] = {preShiftedVector[14:0], preShiftedVector[15]};
        endcase
*/
#define MAX_SHIFT_VALUE 0xFFFF
#define MAX_SHIFT_NUM 16
    uint16 shift_vector = 0;

    shift_vector = ((pre_shift_vector >> shift)&(MAX_SHIFT_VALUE >> shift))
                    | ((pre_shift_vector & (MAX_SHIFT_VALUE >> (MAX_SHIFT_NUM - shift))) << (MAX_SHIFT_NUM - shift));

    return shift_vector;
}

/****************************************************************************
* Name:      _cm_qmgt_qmanager_generate_dequeue
* Purpose:   Generate dequeue message.
* Parameters:
* Input:     p_qpkt -- queue management packet pointer
*            p_ms_en_queue -- enqueue message pointer
*            p_queue_entry -- queue entry message pointer
* Output:    ms_dequeue_list -- dequeue message link list
* Return:    DRV_E_NONE = success.
*            Other = ErrorCode, please refer to DRV_E_XXX.
* Note:      None.
****************************************************************************/
static int32
_cm_qmgt_qmanager_generate_dequeue(queue_in_pkt_t *p_qpkt,
                          fwd_ms_enqueue_t *p_ms_en_queue,
                          fwd_queue_entry_t *p_queue_entry)
{
    uint32 release_packet = TRUE;
    uint32 logical_rep_base = 0, logical_rep_count =  0;
    int32 copy = 0;
    fwd_ms_dequeue_t *p_ms_dequeue = NULL;
    fwd_ms_dequeue_t tmp_ms_dequeue;
    queue_packet_info_t *p_pkt_info = (queue_packet_info_t *)p_qpkt->pkt_info;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Queue Manager Generate Dequeue Process.");

    sal_memset(&tmp_ms_dequeue, 0, sizeof(tmp_ms_dequeue));
    tmp_ms_dequeue.msg_dequeue.head_buffer_ptr = p_queue_entry->ds_queueentry.head_buffer_ptr;
    tmp_ms_dequeue.msg_dequeue.head_ptr_offset = p_queue_entry->ds_queueentry.head_ptr_offset;
    tmp_ms_dequeue.msg_dequeue.resource_group_id = p_queue_entry->ds_queueentry.resource_group_id;
    tmp_ms_dequeue.msg_dequeue.packet_length = p_queue_entry->ds_queueentry.packet_length;
    tmp_ms_dequeue.msg_dequeue.rcd = p_queue_entry->ds_queueentry.rcd;
    tmp_ms_dequeue.msg_dequeue.mcast_rcd = p_queue_entry->ds_queueentry.mcast_rcd;
    tmp_ms_dequeue.msg_dequeue.queue_id = p_queue_entry->queue_id;
    tmp_ms_dequeue.msg_dequeue.next_hop_ext = p_queue_entry->ds_queueentry.next_hop_ext;
    tmp_ms_dequeue.msg_dequeue.length_adjust_type = p_queue_entry->ds_queueentry.length_adjust_type;
    tmp_ms_dequeue.msg_dequeue.dest_select = p_queue_entry->ds_queueentry.dest_select;
    tmp_ms_dequeue.msg_dequeue.replication_ctl = (p_queue_entry->ds_queueentry.replication_ctl&0x3ffff);
    tmp_ms_dequeue.msg_dequeue.dest_map = p_queue_entry->ds_queueentry.dest_map;
    tmp_ms_dequeue.msg_dequeue.in_profile = TRUE;/* No queue shaping in co-sim */
    tmp_ms_dequeue.msg_dequeue.pt_enable = p_queue_entry->ds_queueentry.pt_enable;
    /* tmp_ms_dequeue.msg_dequeue.discard = ??? */
    /* tmp_ms_dequeue.msg_dequeue.congestion_valid = ??? */

    /* new */
    if (!tmp_ms_dequeue.msg_dequeue.dest_select)
    {
        logical_rep_base = p_queue_entry->ds_queueentry.replication_ctl>>4;
        logical_rep_count = p_queue_entry->ds_queueentry.replication_ctl & 0xF;
    }

    /* Maximun 32 logic replications for one physical replication */
    copy = ((p_queue_entry->replication_ctl_ext<<4) | logical_rep_count);

    /* Exception pkt not be replicated */
    if (!tmp_ms_dequeue.msg_dequeue.dest_select)     /* primary destination */
    {
        /* Move the logical replication from BufferRetrieve to this module */
        while (copy >= 0)
        {
            p_ms_dequeue = sal_malloc(sizeof(fwd_ms_dequeue_t));

            if(NULL == p_ms_dequeue)
            {
                return DRV_E_NO_MEMORY;
            }

            sal_memcpy(p_ms_dequeue, &tmp_ms_dequeue, sizeof(fwd_ms_dequeue_t));

            p_ms_dequeue->msg_dequeue.replication_ctl
                = ((logical_rep_base & 0xFFFF) + (p_queue_entry->ds_queueentry.next_hop_ext?
                                                        ((copy & 0x1F) << 1):(copy & 0x1F))) & 0xFFFF;

            if((0 != copy) && (!p_queue_entry->ds_queueentry.dest_select))
            {
                release_packet = FALSE;
            }
            else
            {
                release_packet = TRUE;
            }

            p_ms_dequeue->msg_dequeue.release_packet = release_packet;
            p_ms_dequeue->discard = p_queue_entry->discard;

            _cm_qmgr_qmanager_debug_dequeue_msg(p_ms_dequeue);
            list_add_tail(&p_ms_dequeue->head, &p_pkt_info->ms_dequeue_list);
            copy--;
        }
    }
    else            /* Exception */
    {
        p_ms_dequeue = sal_malloc(sizeof(fwd_ms_dequeue_t));
        if(NULL == p_ms_dequeue)
        {
            return DRV_E_NO_MEMORY;
        }
        sal_memcpy(p_ms_dequeue, &tmp_ms_dequeue, sizeof(fwd_ms_dequeue_t));

        p_ms_dequeue->msg_dequeue.release_packet = release_packet;
        p_ms_dequeue->discard = p_queue_entry->discard;

        _cm_qmgr_qmanager_debug_dequeue_msg(p_ms_dequeue);
        list_add_tail(&p_ms_dequeue->head, &p_pkt_info->ms_dequeue_list);
    }

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_qmgt_qmanager_generate_qid
* Purpose:    Provides generate queue ID per-enqueue message function.
* Parameters:
* Input:      p_qpkt -- queue management packet pointer
*             p_ms_en_queue -- enqueue message pointer
*             p_queue_entry -- queue entry pointer
* Output:     p_qpkt -- queue management packet pointer
* Return:     DRV_E_NONE = success.
*             Other = ErrorCode, please refer to DRV_E_XXX.
* Note:       None.
****************************************************************************/
static int32
_cm_qmgt_qmanager_generate_qid(queue_in_pkt_t *p_qpkt,
                                        fwd_ms_enqueue_t *p_ms_en_queue,
                                        fwd_queue_entry_t *p_queue_entry)
{
    q_write_ctl_t que_write_ctl;
    ds_queue_num_gen_ctl_t ds_queue_num_gen_ctl;
    ds_queue_select_map_t ds_queue_select_map;

    ds_link_aggregate_member_t ds_link_aggregate_member;
    q_link_agg_timer_ctl0_t q_linkagg_timer_ctl0;
    q_link_agg_timer_ctl1_t q_linkagg_timer_ctl1;
    q_link_agg_timer_ctl2_t q_linkagg_timer_ctl2;
    ds_link_aggregate_group_t ds_link_aggregate_group;
    ds_link_aggregation_port_t ds_linkagg_port;
    ds_link_aggregate_channel_group_t ds_link_aggregate_channel_group;
    ds_link_aggregate_channel_member_t ds_link_aggregate_channel_member;


    q_write_sgmac_ctl_t qwrite_sgmac_ctl;
    ds_sgmac_map_t ds_sgmac_map;
    ds_link_aggregate_sgmac_group_t ds_link_aggregate_sgmac_group;
    ds_link_aggregate_sgmac_member_t ds_link_aggregate_sgmac_member;

    lookup_result_t lookup_result;
    lookup_info_t lookup_info;
    ds_queue_hash_key_t ds_queue_lookup_key;

    q_hash_cam_ctl_t q_hash_cam_ctl;

    cm_qmgt_qmanager_q_hash_cam_ctl_t tmp_q_hash_cam_ctl;
    uint8 hash_type = 0;

    uint32 q_hash_cam_entry_num = 0;
    uint32 cmd = 0, dest_map = 0;
    uint8 queue_on_chip_id = FALSE, replicated_met = FALSE, src_queue_select = FALSE;
    uint8 rx_oam = FALSE, oam_dest_chip_id_match = FALSE, trans_link_agg = FALSE, no_linkagg_member_discard = FALSE;
    uint8 queue_select = 0, header_hash = 0, dest_chip_id = 0, oam_dest_chip_id = 0;
    uint8 dest_chip_id_match = FALSE, from_fabric = FALSE;
    uint16 rx_oam_queue_base = 0, service_id = 0;
    uint32 qnum_gen_ctl = 0, dest_queue = 0, queue_number = 0, qselect_type = 0;

    uint8 linkagg_id = 0, linkagg_sel = 0;
    uint8 linkagg_mem_num = 0, linkagg_port_rmep_en = 0, linkagg_flow_num = 0, linkagg_port_member_ptr = 0;
    uint16 linkagg_mem_base = 0;
    uint8 linkagg_channel_group = 0;
    uint32 dslinkagg_ptr = 0;

    uint32 channel_id = 0, queue_base = 0, fid = 0;

    uint32 sgmac_index = 0;

    uint8 sgmac = 0;

    uint8 priority = 0, color = 0, rx_oam_type = 0, source_chip_id = 0, flow_id = 0;
    uint8 stacking_discard = FALSE;
    uint8 drop_precedence = 0;
    uint8 qcn_queue_id_valid = FALSE;
    uint8 table_index = 0;

    bool channel_linkagg_remap_en = FALSE;
    uint8 channel_linkagg_flow_num = 0;
    uint16 channel_linkagg_mem_base = 0;
    uint8 channel_linkagg_member_ptr = 0;
    uint8 channel_linkagg_mem_num = 0;

    uint8 src_sgmac_group_id = 0, dest_sgmac_group_id = 0;
    uint32 old_dest_map = 0;

    uint8 ds_sgmac_index = 0;
    uint8 sgmac_link_agg_remap_en = FALSE, sgmac_link_agg_flow_num = 0, sgmac_link_agg_member_ptr = 0, sgmac_id = 0;
    uint8 sgmac_link_agg_mem_num = 0;
    uint16 sgmac_link_agg_mem_base = 0;
    uint8 masked_queue_select = 0, masked_dest_chip_id = 0, masked_sgmac_queue = 0, masked_channel_id = 0;
    uint16 masked_dest_queue = 0, masked_fid = 0, masked_service_id = 0, masked_flow_id = 0;
    uint16 shifted_queue_select = 0, shifted_dest_chip_id = 0, shifted_sgmac_queue = 0;
    uint16 shifted_dest_queue = 0, shifted_fid = 0, shifted_service_id = 0, shifted_flow_id = 0, shifted_channel_id = 0;
    uint16 shift_queue_num = 0;
    uint8 channel_id_en = FALSE;
    uint8 c2c_check_disable = FALSE;
    bool mcast_link_aggregation_discard = FALSE, mcast_channel_bunding_discard = FALSE;


#if CMODEL_CAN_NOT_REALIZE
    q_channel_link_state_t q_channel_link_state;
    ds_link_aggregate_sgmac_member_set_t ds_link_aggregate_sgmac_member_set;
    uint16 ds_sgmac_link_aggregation_ptr = 0;
    uint32 ds_channel_linkagg_ptr = 0;
    uint32 dest_sgmac[8] = {0}, sgmac_class[7] = {0};
    uint32 temp_dest_queue = 0, channel_class[16] = {0};
    uint32 dest_channel[16]= {0};
    uint8 index = 0;
    uint32 current_ts = 0xF;
    uint8 max_channel_class = 0;
    uint8 max_channel_class_count = 0;
    uint8 max_channel_class_index_array[16] = {0};
    uint32 random = 0;
    uint8 q_channel_link_state_state = FALSE;
    uint8 sgmac_trunk_index = 0;
#endif

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Generate Queue Id Process.");

    sal_memset(&que_write_ctl, 0, sizeof(que_write_ctl));
    cmd = DRV_IOR(QWriteCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &que_write_ctl));

    /* INIT_FIELDS */
    priority = p_ms_en_queue->msg_enqueue.priority;
    color = p_ms_en_queue->msg_enqueue.color;
    dest_map = p_ms_en_queue->msg_enqueue.dest_map;
    queue_on_chip_id = p_ms_en_queue->msg_enqueue.queue_on_chip_id;
    replicated_met = p_ms_en_queue->msg_enqueue.replicated_met;
    header_hash = p_ms_en_queue->msg_enqueue.header_hash;
    src_queue_select = p_ms_en_queue->msg_enqueue.src_queue_select;
    rx_oam = p_ms_en_queue->msg_enqueue.rx_oam;
    oam_dest_chip_id = p_ms_en_queue->msg_enqueue.oam_dest_chip_id;
    from_fabric = p_ms_en_queue->msg_enqueue.from_fabric;
    service_id = p_ms_en_queue->msg_enqueue.service_id;
    fid = p_ms_en_queue->msg_enqueue.fid;
    rx_oam_type = p_ms_en_queue->msg_enqueue.rx_oam_type;

    source_chip_id = p_ms_en_queue->msg_enqueue.source_chip_id;
    flow_id = p_ms_en_queue->msg_enqueue.flow_id;
    src_sgmac_group_id = p_ms_en_queue->msg_enqueue.src_sgmac_group_id;
    dest_sgmac_group_id = p_ms_en_queue->msg_enqueue.dest_sgmac_group_id;
    old_dest_map = p_ms_en_queue->msg_enqueue.old_dest_map;

    /* from IPEFwd { queueOnChipId, replicatedMet, oamDestChipId[4:0], rxOam, fromFabric, serviceId[13:0],
                    fid[13:0], rxOamType[3:0], left, sourceChipId[4:0], flowId[3:0]} = 0 */
    sal_memset(&q_linkagg_timer_ctl0, 0, sizeof(q_linkagg_timer_ctl0));
    cmd = DRV_IOR(QLinkAggTimerCtl0_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &q_linkagg_timer_ctl0));

    sal_memset(&q_linkagg_timer_ctl1, 0, sizeof(q_linkagg_timer_ctl1));
    cmd = DRV_IOR(QLinkAggTimerCtl1_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &q_linkagg_timer_ctl1));

    sal_memset(&q_linkagg_timer_ctl2, 0, sizeof(q_linkagg_timer_ctl2));
    cmd = DRV_IOR(QLinkAggTimerCtl2_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &q_linkagg_timer_ctl2));

    sal_memset(&ds_queue_select_map, 0, sizeof(ds_queue_select_map));
    cmd = DRV_IOR(DsQueueSelectMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, (((priority &0x3F) << 2) | (color & 0x3)),
                                    cmd, &ds_queue_select_map));

    queue_select = ds_queue_select_map.queue_select;
    drop_precedence = ds_queue_select_map.drop_precedence;

    oam_dest_chip_id_match = (oam_dest_chip_id == que_write_ctl.chip_id);

    if (rx_oam && (oam_dest_chip_id != 0x1F))
    {
        dest_chip_id = oam_dest_chip_id;
    }
    else
    {
        dest_chip_id = GET_DESTCHIPID_IN_DESTMAP(dest_map);
    }

    trans_link_agg = (0x1F == dest_chip_id) && (!IS_BIT_SET(dest_map, 21)|| replicated_met); /* unicast or local MET */
    no_linkagg_member_discard = FALSE;

    /* TRANSLATE_LINK_AGGREGATE_PORT */
    if (trans_link_agg)
    {
        /* GetLinkAggMem here for OAM Engine */
        /* localPhyPort level link aggregation */
        sal_memset(&ds_link_aggregate_group, 0, sizeof(ds_link_aggregate_group));
        linkagg_id = dest_map & 0x3F;
        cmd = DRV_IOR(DsLinkAggregateGroup_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, linkagg_id, cmd, &ds_link_aggregate_group));

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_LINKAGG, "[Debug QMGT LINKAGG]:  %s[0x%X]\n",
                             "Linkagg Id", linkagg_id);

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_LINKAGG, "[Debug QMGT LINKAGG]:  %s[0x%X]\n",
                             "Linkagg Member Num", linkagg_mem_num);

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_LINKAGG, "[Debug QMGT LINKAGG]:  %s[0x%X]\n",
                             "Linkagg Member Base", ds_link_aggregate_group.link_agg_mem_base);

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                             "DsLinkAggregateGroup_t", linkagg_id);

        linkagg_mem_num = ds_link_aggregate_group.link_agg_mem_num;
        linkagg_mem_base = ds_link_aggregate_group.link_agg_mem_base;
        linkagg_port_rmep_en = ds_link_aggregate_group.link_agg_port_remap_en;
        linkagg_flow_num = ds_link_aggregate_group.link_agg_flow_num;
        linkagg_port_member_ptr = ds_link_aggregate_group.link_agg_port_member_ptr;

        no_linkagg_member_discard = ((linkagg_mem_num & 0xF) == 0);

        if (!linkagg_port_rmep_en)   /* static load balance */
        {
            /* if (QwriteCtl.headerHashMode) headerHash[7:0] = Generate hash use (headerHash[7:0]); */
#if 0
            switch (que_write_ctl.header_hash_bits_num)
            {
                case 1:
                    header_hash = header_hash & 0x7;
                    break;

                case 2:
                    header_hash = header_hash & 0xF;
                    break;

                case 3:
                    header_hash = header_hash & 0x1F;
                    break;

                case 4:
                    header_hash = header_hash & 0x3F;
                    break;

                default:
                    header_hash = header_hash & 0x7F;
                    break;
            }
#endif
            if (linkagg_mem_num == 0)        /* 128 members */
            {
                linkagg_sel = header_hash & 0x7F;
            }
            else if (linkagg_mem_num <= 8)
            {
                linkagg_sel = header_hash % linkagg_mem_num;
            }
            else if (linkagg_mem_num == 9)   /* 16 members */
            {
                linkagg_sel = header_hash & 0xF;
            }
            else if (linkagg_mem_num == 10)   /* 32 members */
            {
                linkagg_sel = header_hash & 0x1F;
            }
            else if (linkagg_mem_num == 11)   /* 64 members */
            {
                linkagg_sel = header_hash & 0x3F;
            }
            else                              /* 128 members */
            {
                linkagg_sel = header_hash & 0x7F;
            }

            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_LINKAGG, "[Debug QMGT LINKAGG]:  %s[0x%X]\n",
                                 "Linkagg Header Hash", header_hash);

            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_LINKAGG, "[Debug QMGT LINKAGG]:  %s[0x%X]\n",
                                 "Linkagg Member Offset Value toward Linkagg Mem Base", linkagg_sel);

            sal_memset(&ds_link_aggregate_member, 0, sizeof(ds_link_aggregate_member));
            cmd = DRV_IOR(DsLinkAggregateMember_t, DRV_ENTRY_FLAG);
            dslinkagg_ptr = (linkagg_mem_base&0x3FF) + (linkagg_sel&0x7F);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, dslinkagg_ptr, cmd, &ds_link_aggregate_member));

            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                 "DsLinkAggregateMember_t", dslinkagg_ptr);

            dest_chip_id = ds_link_aggregate_member.dest_chip_id & 0x1F;
            SET_DESTCHIPID_IN_DESTMAP(dest_map, dest_chip_id);
            dest_map = (dest_map & 0x3FFE00) | ds_link_aggregate_member.dest_queue;

            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_LINKAGG, "[Debug QMGT LINKAGG]:  %s[0x%X]\n",
                                 "Linkagg Dest Chipid", dest_chip_id);

            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_LINKAGG, "[Debug QMGT LINKAGG]:  %s[0x%X]\n",
                                 "Linkagg destmap", dest_map);
        }
        else   /* dynimic load balance */
        {
#if CMODEL_CAN_NOT_REALIZE
            switch (linkagg_flow_num&0x3)
            {
                case 0:
                    dslinkagg_ptr = linkagg_mem_base + (header_hash&0xFF);
                    break;
                case 1:
                    dslinkagg_ptr = linkagg_mem_base + (header_hash&0x7F);
                    break;
                case 2:
                    dslinkagg_ptr = linkagg_mem_base + (header_hash&0x3F);
                    break;
                default:
                    dslinkagg_ptr = linkagg_mem_base + (header_hash&0x1F);
                    break;
            }

            sal_memset(&ds_link_aggregate_member, 0, sizeof(ds_link_aggregate_member));
            cmd = DRV_IOR(DsLinkAggregateMember_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, dslinkagg_ptr, cmd, &ds_link_aggregate_member));

            if (ds_link_aggregate_member.active
                && (current_ts - ds_link_aggregate_member.old_ts) < q_linkagg_timer_ctl0.ts_threshold) /* flow active */
            {
                dest_chip_id = ds_link_aggregate_member.dest_chip_id & 0x1F;
                SET_DESTCHIPID_IN_DESTMAP(dest_map, dest_chip_id);
                dest_map &= 0x3FFE00;
                dest_map |= ds_link_aggregate_member.dest_queue;
                ds_link_aggregate_member.old_ts = current_ts;

                cmd = DRV_IOW(DsLinkAggregateMember_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, dslinkagg_ptr, cmd, &ds_link_aggregate_member));
            }
            else                                                                               /* flow inactive */
            {
                /* flow inactive */
                for (index = 0; index < 8; index++)
                {
                    cmd = DRV_IOR(DsLinkAggregateMemberSet_t, DsLinkAggregateMemberSet_DestChannel0_f+index);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, linkagg_port_member_ptr, cmd, &(dest_channel[index])));

                    /* update by QMgr */
                    cmd = DRV_IOR(QMgrEnqChanClassTable_t, QMgrEnqChanClassTable_ChannelClass0_f+(dest_channel[index] & 0x3F));
                    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &(channel_class[index])));
                }

                /* find index ... ... ??? */

                max_channel_class = channel_class[0];       /* store current max_channel_class */
                max_channel_class_index_array[0] = 0;       /* store index of all max_channel_class item */
                max_channel_class_count = 1;                /* max_channel_class item count */

                for (index = 1; index < linkagg_mem_num&0x7; index ++)
                {
                    if(channel_class[index] == max_channel_class)
                    {
                        max_channel_class_index_array[max_channel_class_count] = index;
                        max_channel_class_count ++;
                    }
                    else if(channel_class[index] > max_channel_class)
                    {
                        max_channel_class_index_array[0] = index;
                        max_channel_class_count = 1;
                        max_channel_class = channel_class[index];
                    }
                }

                if (1 == max_channel_class_count)
                {
                    index = max_channel_class_index_array[0];
                }
                else
                {
                    ctcutil_rand(0, max_channel_class_count - 1, &random);
                    index = max_channel_class_index_array[random];
                }

                cmd = DRV_IOR(DsLinkAggregateMemberSet_t, DsLinkAggregateMemberSet_DestQueue0_f+index);
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, linkagg_port_member_ptr, cmd, &temp_dest_queue));

                ds_link_aggregate_member.dest_queue = temp_dest_queue;
                ds_link_aggregate_member.old_ts = current_ts;
                ds_link_aggregate_member.active = TRUE;

                dest_chip_id = ds_link_aggregate_member.dest_chip_id & 0x1F;
                SET_DESTCHIPID_IN_DESTMAP(dest_map, dest_chip_id);
                dest_map &= 0x3FFE00;
                dest_map |= temp_dest_queue;

                cmd = DRV_IOW(DsLinkAggregateMember_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, linkagg_port_member_ptr, cmd, &ds_link_aggregate_member));
            }
#endif
        }
    }

    /* QUEUE_NUM_GEN_CTL --> TRANSLATE_LINK_AGGREGATE_CHANNEL*/
    dest_chip_id_match = (dest_chip_id == que_write_ctl.chip_id);
    channel_id = 0;

    if (dest_chip_id_match && ((!rx_oam) || que_write_ctl.rx_oam_channel_group_en))
    {
        sal_memset(&ds_linkagg_port, 0, sizeof(ds_linkagg_port));
        cmd = DRV_IOR(DsLinkAggregationPort_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, dest_map&0x7F, cmd, &ds_linkagg_port));

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                             "DsLinkAggregationPort_t", dest_map&0x7F);

        channel_id = ds_linkagg_port.channel_id;
        linkagg_channel_group = ds_linkagg_port.link_aggregation_channel_group;

        if (linkagg_channel_group != 0) /* channel bundling */
        {
            sal_memset(&ds_link_aggregate_channel_group, 0, sizeof(ds_link_aggregate_channel_group));
            cmd = DRV_IOR(DsLinkAggregateChannelGroup_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, linkagg_channel_group, cmd, &ds_link_aggregate_channel_group));

            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                 "DsLinkAggregateChannelGroup_t", linkagg_channel_group);

            channel_linkagg_remap_en = ds_link_aggregate_channel_group.channel_link_agg_remap_en;
            channel_linkagg_flow_num = ds_link_aggregate_channel_group.channel_link_agg_flow_num;
            channel_linkagg_mem_base = ds_link_aggregate_channel_group.channel_link_agg_mem_base;
            channel_linkagg_member_ptr = ds_link_aggregate_channel_group.channel_link_agg_member_ptr;
            channel_linkagg_mem_num = ds_link_aggregate_channel_group.channel_link_agg_mem_num;

            no_linkagg_member_discard |= (channel_linkagg_mem_num == 0);

            if (!channel_linkagg_remap_en)
            {
                switch (channel_linkagg_mem_num & 0xF)
                {
                    case 1:
                        linkagg_sel = 0;
                        break;
                    case 2:
                        linkagg_sel = header_hash & 0x1;
                        break;
                    case 3:
                        linkagg_sel = header_hash % 3;
                        break;
                    case 4:
                        linkagg_sel = header_hash & 0x3;
                        break;
                    case 5:
                        linkagg_sel = header_hash % 5;
                        break;
                    case 6:
                        linkagg_sel = header_hash % 6;
                        break;
                    case 7:
                        linkagg_sel = header_hash % 7;
                        break;
                    case 8:
                        linkagg_sel = header_hash & 0x7;
                        break;

                    default:
                        linkagg_sel = header_hash & 0xF;
                        break;
                }

                sal_memset(&ds_link_aggregate_channel_member, 0, sizeof(ds_link_aggregate_channel_member));
                cmd = DRV_IOR(DsLinkAggregateChannelMember_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id,
                                    channel_linkagg_mem_base + linkagg_sel, cmd, &ds_link_aggregate_channel_member));

                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                     "DsLinkAggregateChannelMember_t", channel_linkagg_mem_base + linkagg_sel);

                dest_chip_id = ds_link_aggregate_channel_member.dest_chip_id;
                SET_DESTCHIPID_IN_DESTMAP(dest_map, ds_link_aggregate_channel_member.dest_chip_id);
                channel_id = ds_link_aggregate_channel_member.channel_id;
            }
            else
            {
#if CMODEL_CAN_NOT_REALIZE
                switch(channel_linkagg_flow_num&0x3)
                {
                    case 0:
                        ds_channel_linkagg_ptr = channel_linkagg_mem_base + (header_hash&0xFF);
                        break;
                    case 1:
                        ds_channel_linkagg_ptr = channel_linkagg_mem_base + (header_hash%0x7F);
                        break;
                    case 2:
                        ds_channel_linkagg_ptr = channel_linkagg_mem_base + (header_hash%0x3F);
                        break;
                    default:
                        ds_channel_linkagg_ptr = channel_linkagg_mem_base + (header_hash%0x1F);
                        break;
                }

                sal_memset(&ds_link_aggregate_channel_member, 0, sizeof(ds_link_aggregate_channel_member));
                cmd = DRV_IOR(DsLinkAggregateChannelMember_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, ds_channel_linkagg_ptr, cmd, &ds_link_aggregate_channel_member));

                sal_memset(&q_channel_link_state, 0, sizeof(q_channel_link_state));
                cmd = DRV_IOR(QChannelLinkState_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &q_channel_link_state));

                /* link up */
                if (ds_link_aggregate_channel_member.channel_id < 32)
                {
                    q_channel_link_state_state = IS_BIT_SET(q_channel_link_state.link_state31_0,
                                                            ds_link_aggregate_channel_member.channel_id);
                }
                else
                {
                    q_channel_link_state_state = IS_BIT_SET(q_channel_link_state.link_state55_32,
                                                            ds_link_aggregate_channel_member.channel_id - 32);
                }

                if (ds_link_aggregate_channel_member.active
                    &&((ds_link_aggregate_channel_member.dest_chip_id != que_write_ctl.chip_id)
                        || q_channel_link_state_state)
                    && ((current_ts - ds_link_aggregate_channel_member.old_ts)<q_linkagg_timer_ctl1.ts_threshold))  /* flow active */
                {
                    dest_chip_id = ds_link_aggregate_channel_member.dest_chip_id;
                    SET_DESTCHIPID_IN_DESTMAP(dest_map, dest_chip_id);
                    channel_id = ds_link_aggregate_channel_member.channel_id;

                    cmd = DRV_IOW(DsLinkAggregateChannelMember_t, DsLinkAggregateChannelMember_OldTs_f);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, ds_channel_linkagg_ptr, cmd, &current_ts));
                }
                else                                                                              /* flow inactive */
                {
                    for (index = 0; index < 8; index++)
                    {
                        dest_channel[index] = 0;
                        channel_class[index] = 0;

                        cmd = DRV_IOR(DsLinkAggregateChannelMemberSet_t,
                                      DsLinkAggregateChannelMemberSet_DestChannel0_f+index);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id,
                                      channel_linkagg_member_ptr, cmd, &(dest_channel[index])));

                        cmd = DRV_IOR(QMgrEnqChanClassTable_t,
                                      QMgrEnqChanClassTable_ChannelClass0_f+(dest_channel[index] & 0x3F));
                        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &(channel_class[index])));
                    }

                    /* find index ... ... ??? */
                    max_channel_class = channel_class[0];       /* store current max_channel_class */
                    max_channel_class_index_array[0] = 0;       /* store index of all max_channel_class item */
                    max_channel_class_count = 1;                /* max_channel_class item count */

                    sal_memset(&q_channel_link_state, 0, sizeof(q_channel_link_state));
                    cmd = DRV_IOR(QChannelLinkState_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &q_channel_link_state));

                    for (index = 1; index < channel_linkagg_mem_num; index ++)
                    {
                        if (IS_BIT_SET(q_channel_link_state.link_state31_0, index))
                        {
                            if(channel_class[index] == max_channel_class)
                            {
                                max_channel_class_index_array[max_channel_class_count] = index;
                                max_channel_class_count ++;
                            }
                            else if(channel_class[index] > max_channel_class)
                            {
                                max_channel_class_index_array[0] = index;
                                max_channel_class_count = 1;
                                max_channel_class = channel_class[index];
                            }
                        }
                    }

                    if (1 == max_channel_class_count)
                    {
                        index = max_channel_class_index_array[0];
                    }
                    else
                    {
                        ctcutil_rand(0, max_channel_class_count - 1, &random);
                        index = max_channel_class_index_array[random];
                    }
                    /* ??? shenhg in spec: DsLinkAggregateChannelMember.destChannel[5:0] =
                                           DsChannelLinkAggregateMember.destChannel{index[3:0]}[5:0]; */
                    ds_link_aggregate_channel_member.channel_id = dest_channel[index];
                    ds_link_aggregate_channel_member.old_ts = current_ts;
                    ds_link_aggregate_channel_member.active = TRUE;

                    dest_chip_id = ds_link_aggregate_channel_member.dest_chip_id;
                    SET_DESTCHIPID_IN_DESTMAP(dest_map, dest_chip_id);
                    channel_id = dest_channel[index];

                    cmd = DRV_IOW(DsLinkAggregateChannelMember_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, ds_channel_linkagg_ptr, cmd, &ds_link_aggregate_channel_member));
                }
#endif
            }

            dest_chip_id_match = (dest_chip_id == que_write_ctl.chip_id);
            mcast_channel_bunding_discard = !dest_chip_id_match && IS_BIT_SET(dest_map, 21);
            if (dest_chip_id_match)
            {
                channel_id_en = (dest_chip_id == que_write_ctl.chip_id);
            }
        }
    }
    else
    {
        mcast_link_aggregation_discard = replicated_met && trans_link_agg && (!dest_chip_id_match);
    }

    if (0 == que_write_ctl.queue_sel_type_bits)
    {
        qselect_type = (dest_map >> 14) & 0x3;
    }
    else if (1 == que_write_ctl.queue_sel_type_bits)
    {
        qselect_type = (dest_map >> 13) & 0x7;
    }
    else
    {
        qselect_type = (dest_map >> 12) & 0xF;
    }

    if (queue_on_chip_id && IS_BIT_SET(dest_map, 21))
    {
        qselect_type = 0xF;
    }

    dest_queue = dest_map & 0xFFFF;

    qnum_gen_ctl = (from_fabric << 7)
                   | (queue_on_chip_id << 6)
                   | (src_queue_select << 5)
                   | (dest_chip_id_match << 4)
                   | (qselect_type & 0xF);

    sal_memset(&ds_queue_num_gen_ctl, 0, sizeof(ds_queue_num_gen_ctl));
    cmd = DRV_IOR(DsQueueNumGenCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, qnum_gen_ctl, cmd, &ds_queue_num_gen_ctl));

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                         "DsQueueNumGenCtl_t", qnum_gen_ctl);

    /* UPLINK_SELECTION */
    sal_memset(&qwrite_sgmac_ctl, 0, sizeof(q_write_sgmac_ctl_t));
    cmd = DRV_IOR(QWriteSgmacCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &qwrite_sgmac_ctl));

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                         "QWriteSgmacCtl_t", 0);

    if ((!IS_BIT_SET(dest_map, 21)) || qwrite_sgmac_ctl.sgmac_index_mcast_en || rx_oam)
    {
        ds_sgmac_index = dest_chip_id & 0x1F;
        sal_memset(&ds_sgmac_map, 0, sizeof(ds_sgmac_map));
        cmd = DRV_IOR(DsSgmacMap_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, ds_sgmac_index, cmd, &ds_sgmac_map));

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                             "DsSgmacMap_t", ds_sgmac_index);

        dest_sgmac_group_id = ds_sgmac_map.sgmac_group_id;
    }

    sal_memset(&ds_link_aggregate_sgmac_group, 0, sizeof(ds_link_aggregate_sgmac_group));
    cmd = DRV_IOR(DsLinkAggregateSgmacGroup_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, dest_sgmac_group_id, cmd, &ds_link_aggregate_sgmac_group));

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                         "DsLinkAggregateSgmacGroup_t", dest_sgmac_group_id);

    if(qwrite_sgmac_ctl.sgmac_en && (dest_sgmac_group_id != 0))
    {
        sgmac_link_agg_remap_en = ds_link_aggregate_sgmac_group.sgmac_link_agg_remap_en;
        sgmac_link_agg_flow_num = ds_link_aggregate_sgmac_group.sgmac_link_agg_flow_num;
        sgmac_link_agg_mem_base = ds_link_aggregate_sgmac_group.sgmac_link_agg_mem_base;
        sgmac_link_agg_member_ptr = ds_link_aggregate_sgmac_group.sgmac_link_agg_member_ptr;
        sgmac_id = ds_link_aggregate_sgmac_group.sgmac_id;
        sgmac_link_agg_mem_num = ds_link_aggregate_sgmac_group.sgmac_link_agg_mem_num;

        if (sgmac_link_agg_mem_num == 0)
        {
            no_linkagg_member_discard = TRUE;
        }
        else if (sgmac_link_agg_mem_num == 1)    /* individual SGMAC */
        {
            sgmac = sgmac_id;
        }
        else if (!sgmac_link_agg_remap_en)     /* static link aggregation */
        {
            if (sgmac_link_agg_mem_num == 0)
            {
                sgmac_index = header_hash % 0x7;
            }
            else
            {
                sgmac_index = header_hash % sgmac_link_agg_mem_num;
            }

            sal_memset(&ds_link_aggregate_sgmac_member, 0, sizeof(ds_link_aggregate_sgmac_member));
            cmd = DRV_IOR(DsLinkAggregateSgmacMember_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, (sgmac_index + sgmac_link_agg_mem_base),
                                         cmd, &ds_link_aggregate_sgmac_member));

            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                 "DsLinkAggregateSgmacMember_t", (sgmac_index + sgmac_link_agg_mem_base));

            sgmac = ds_link_aggregate_sgmac_member.sgmac;
        }
        else
        {
#if CMODEL_CAN_NOT_REALIZE
            switch (sgmac_link_agg_flow_num)
            {
                case 0:
                    ds_sgmac_link_aggregation_ptr = sgmac_link_agg_mem_base + header_hash;
                    break;

                case 1:
                    ds_sgmac_link_aggregation_ptr = sgmac_link_agg_mem_base + (header_hash & 0x7F);
                    break;

                case 2:
                    ds_sgmac_link_aggregation_ptr = sgmac_link_agg_mem_base + (header_hash & 0x3F) ;
                    break;

                case 3:
                    ds_sgmac_link_aggregation_ptr = sgmac_link_agg_mem_base + (header_hash & 0x1F);
                    break;
                default:
                    break;
            }

            sal_memset(&ds_link_aggregate_sgmac_member, 0, sizeof(ds_link_aggregate_sgmac_member));
            cmd = DRV_IOR(DsLinkAggregateSgmacMember_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, ds_sgmac_link_aggregation_ptr,
                                           cmd, &ds_link_aggregate_sgmac_member));

            if (ds_link_aggregate_sgmac_member.active
                && ((current_ts - ds_link_aggregate_sgmac_member.old_ts) < q_linkagg_timer_ctl2.ts_threshold))  /* active */
            {
                sgmac = ds_link_aggregate_sgmac_member.sgmac;
                ds_link_aggregate_sgmac_member.old_ts = current_ts;
                cmd = DRV_IOW(DsLinkAggregateSgmacMember_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, ds_sgmac_link_aggregation_ptr,
                                               cmd, &ds_link_aggregate_sgmac_member));
            }
            else                                                                                    /* flow inactive */
            {
                sal_memset(&ds_link_aggregate_sgmac_member_set, 0, sizeof(ds_link_aggregate_sgmac_member_set));
                cmd = DRV_IOR(DsLinkAggregateSgmacMemberSet_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, sgmac_link_agg_member_ptr,
                                               cmd, &ds_link_aggregate_sgmac_member_set));

                sal_memset(dest_sgmac, 0, sizeof(dest_sgmac));
                sal_memset(sgmac_class, 0, sizeof(sgmac_class));

                for (index = 0; index < 8; index ++)
                {
                    cmd = DRV_IOR(DsLinkAggregateSgmacMemberSet_t, DsLinkAggregateSgmacMemberSet_DestSgmac0_f+ index);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, sgmac_link_agg_member_ptr,
                                                   cmd, &(dest_sgmac[index])));

                    cmd = DRV_IOR(QMgrEnqChanClassTable_t, QMgrEnqChanClassTable_ChannelClass0_f + dest_sgmac[index]);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, sgmac_link_agg_member_ptr,
                                                   cmd, &(sgmac_class[index])));
                }

                /* find index ... ... ??? */
                max_channel_class = dest_sgmac[0];       /* store current max_channel_class */
                max_channel_class_index_array[0] = 0;       /* store index of all max_channel_class item */
                max_channel_class_count = 1;                /* max_channel_class item count */

                sal_memset(&q_channel_link_state, 0, sizeof(q_channel_link_state));
                cmd = DRV_IOR(QChannelLinkState_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &q_channel_link_state));

                for (index = 1; index < sgmac_link_agg_mem_num; index ++)
                {
                    if (IS_BIT_SET(q_channel_link_state.link_state31_0, index))
                    {
                        if(dest_sgmac[index] == max_channel_class)
                        {
                            max_channel_class_index_array[max_channel_class_count] = index;
                            max_channel_class_count ++;
                        }
                        else if(dest_sgmac[index] > max_channel_class)
                        {
                            max_channel_class_index_array[0] = index;
                            max_channel_class_count = 1;
                            max_channel_class = dest_sgmac[index];
                        }
                    }
                }

                if (1 == max_channel_class_count)
                {
                    index = max_channel_class_index_array[0];
                }
                else
                {
                    ctcutil_rand(0, max_channel_class_count - 1, &random);
                    index = max_channel_class_index_array[random];
                }

                sal_memset(&ds_link_aggregate_sgmac_member, 0, sizeof(ds_link_aggregate_sgmac_member));
                cmd = DRV_IOR(DsLinkAggregateSgmacMember_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, index,
                                               cmd, &ds_link_aggregate_sgmac_member));
                /* ??? shenhg need to comfirm */
                sgmac = dest_sgmac[index];

                ds_link_aggregate_sgmac_member.sgmac = sgmac;
                ds_link_aggregate_sgmac_member.old_ts = current_ts;
                ds_link_aggregate_sgmac_member.active = TRUE;

            }
#endif
        }

        /* stacking ucast reflect discard */
        if (qwrite_sgmac_ctl.uplink_reflect_check_en && (src_sgmac_group_id == dest_sgmac_group_id))
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE,
                                 "Qmgt Queue Manager Generate Queue Id: Stacking Ucast Reflect Discard.\n");
            stacking_discard = TRUE;
        }

        /* Stacking last node terminiation, not send to source chip */
        c2c_check_disable = (p_ms_en_queue->msg_enqueue.operation_type == OPERATION_TYPE_C2C)
                            && p_ms_en_queue->msg_enqueue.c2c_check_disable;
        if (qwrite_sgmac_ctl.discard_replication_penultimate_hop
            && (!c2c_check_disable)
            && (source_chip_id == ds_link_aggregate_sgmac_group.peer_chip_id)) /* discard ahead to orginal chip */
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE,
                                 "Qmgt Queue Manager Generate Queue Id: Stacking Last Node Terminiation, Not Send To Source Chip Discard.\n");
            stacking_discard = TRUE;
        }
    }
    else if (qwrite_sgmac_ctl.sgmac_en && !dest_chip_id_match && qwrite_sgmac_ctl.discard_unkown_sgmac_group)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "Qmgt Queue Manager Generate Queue Id: Unkown Sgmac Group Discard.\n");
        stacking_discard = TRUE;
    }
    else
    {
        sgmac = 0;
        stacking_discard = FALSE;
    }

    /* sgmac[5:0] to MAC channel mapping by DsQueueMap */

    /* QUEUE_HASH_LOOKUP */
    channel_id_en |= ds_queue_num_gen_ctl.channel_id_en;
    if (ds_queue_num_gen_ctl.queue_gen_mode)
    {
        /* DsQueueNumGenCtl.channelIdEn ??? */
        hash_type = ds_queue_num_gen_ctl.dest_queue_en | (ds_queue_num_gen_ctl.dest_chip_id_en << 1)
                     | (ds_queue_num_gen_ctl.sgmac_en << 2) | (ds_queue_num_gen_ctl.service_queue_en << 3)
                     | (channel_id_en << 4) | (ds_queue_num_gen_ctl.mcast_en << 5)
                     | (ds_queue_num_gen_ctl.fid_en << 6);

        sal_memset(&ds_queue_lookup_key, 0, sizeof(ds_queue_hash_key_t));
        ds_queue_lookup_key.hash_type0 = hash_type & 0x7F;
        ds_queue_lookup_key.fid0 = IS_BIT_SET(hash_type, 6) ? ((fid&0x3FFF) & ds_queue_num_gen_ctl.fid_mask) : 0;
        ds_queue_lookup_key.mcast0 = IS_BIT_SET(hash_type, 5) ? (IS_BIT_SET(dest_map, 21)& 0x1) : 0;
        ds_queue_lookup_key.channel_id0 = IS_BIT_SET(hash_type, 4) ?
                                            ((channel_id & 0x3F) & ds_queue_num_gen_ctl.channel_id_mask): 0;
        ds_queue_lookup_key.service_id0 = IS_BIT_SET(hash_type, 3) ?
                                            ((service_id&0x3FFF) & ds_queue_num_gen_ctl.service_id_mask) : 0;
        ds_queue_lookup_key.sgmac0 = IS_BIT_SET(hash_type, 2) ? ((sgmac& 0x3F)&ds_queue_num_gen_ctl.sgmac_mask) : 0;
        ds_queue_lookup_key.dest_chip_id0 = IS_BIT_SET(hash_type, 1) ?
                                                ((dest_chip_id & 0x1F) & ds_queue_num_gen_ctl.dest_chip_id_mask): 0;
        ds_queue_lookup_key.dest_queue0 = IS_BIT_SET(hash_type, 0) ?
                                            ((dest_queue & 0xFFFF) & ds_queue_num_gen_ctl.dest_queue_mask): 0;
        ds_queue_lookup_key.valid0 = TRUE;
        sal_memset(&lookup_info, 0, sizeof(lookup_info_t));
        sal_memset(&lookup_result, 0, sizeof(lookup_result_t));
        lookup_info.chip_id = p_qpkt->chip_id;
        lookup_info.hash_module = HASH_MODULE_QUEUE;
        lookup_info.hash_type = QUEUE_KEY_TYPE_KEY;
        lookup_info.p_ds_key = &ds_queue_lookup_key;

        _cm_qmgr_qmanager_debug_queue_hash_key_lookup_info(&lookup_info);

        DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_lookup);
        /* polynormal: X^8 + X^2 + X + 1 */
        DRV_IF_ERROR_RETURN(drv_io_api.drv_hash_lookup(&lookup_info, &lookup_result));

        _cm_qmgr_qmanager_debug_queue_hash_key_result_info(&lookup_result);

#if (SDK_WORK_PLATFORM == 1)
        /*Stroe Queue hash key for cosim*/
        if (cosim_db.store_key)
        {
            tbls_id_t tbl_id = MaxTblId_t;
            tbl_id = drv_hash_lookup_get_key_table_id(lookup_info.hash_module, lookup_info.hash_type);
            DRV_IF_ERROR_RETURN(cosim_db.store_key(lookup_info.p_ds_key, tbl_id));
        }
#endif
        if (lookup_result.valid)
        {
            queue_base = lookup_result.ad_index;
        }
        else
        {
            queue_base = 0; /* do not hit */
            sal_memset(&q_hash_cam_ctl, 0, sizeof(q_hash_cam_ctl));
            cmd = DRV_IOR(QHashCamCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &q_hash_cam_ctl));

            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                 "QHashCamCtl_t", 0);

            q_hash_cam_entry_num = sizeof(q_hash_cam_ctl_t) / sizeof(cm_qmgt_qmanager_q_hash_cam_ctl_t);

            for (table_index = 0; table_index < q_hash_cam_entry_num; table_index++)
            {
                sal_memset(&tmp_q_hash_cam_ctl, 0, sizeof(tmp_q_hash_cam_ctl));
                switch (table_index)
                {
                    case 0:
                        tmp_q_hash_cam_ctl.channel_id0 = q_hash_cam_ctl.channel_id0;
                        tmp_q_hash_cam_ctl.dest_chip_id0 = q_hash_cam_ctl.dest_chip_id0;
                        tmp_q_hash_cam_ctl.dest_queue0 = q_hash_cam_ctl.dest_queue0;
                        tmp_q_hash_cam_ctl.hash_type0 = q_hash_cam_ctl.hash_type0;
                        tmp_q_hash_cam_ctl.mcast0 = q_hash_cam_ctl.mcast0;
                        tmp_q_hash_cam_ctl.queue_base0 = q_hash_cam_ctl.queue_base0;
                        tmp_q_hash_cam_ctl.service_id0 = q_hash_cam_ctl.service_id0;
                        tmp_q_hash_cam_ctl.sgmac0 = q_hash_cam_ctl.sgmac0;
                        tmp_q_hash_cam_ctl.valid0 = q_hash_cam_ctl.valid0;
                        tmp_q_hash_cam_ctl.fid0 = q_hash_cam_ctl.fid0;
                        break;

                    case 1:
                        tmp_q_hash_cam_ctl.channel_id0 = q_hash_cam_ctl.channel_id1;
                        tmp_q_hash_cam_ctl.dest_chip_id0 = q_hash_cam_ctl.dest_chip_id1;
                        tmp_q_hash_cam_ctl.dest_queue0 = q_hash_cam_ctl.dest_queue1;
                        tmp_q_hash_cam_ctl.hash_type0 = q_hash_cam_ctl.hash_type1;
                        tmp_q_hash_cam_ctl.mcast0 = q_hash_cam_ctl.mcast1;
                        tmp_q_hash_cam_ctl.queue_base0 = q_hash_cam_ctl.queue_base1;
                        tmp_q_hash_cam_ctl.service_id0 = q_hash_cam_ctl.service_id1;
                        tmp_q_hash_cam_ctl.sgmac0 = q_hash_cam_ctl.sgmac1;
                        tmp_q_hash_cam_ctl.valid0 = q_hash_cam_ctl.valid1;
                        tmp_q_hash_cam_ctl.fid0 = q_hash_cam_ctl.fid1;
                        break;

                    case 2:
                        tmp_q_hash_cam_ctl.channel_id0 = q_hash_cam_ctl.channel_id2;
                        tmp_q_hash_cam_ctl.dest_chip_id0 = q_hash_cam_ctl.dest_chip_id2;
                        tmp_q_hash_cam_ctl.dest_queue0 = q_hash_cam_ctl.dest_queue2;
                        tmp_q_hash_cam_ctl.hash_type0 = q_hash_cam_ctl.hash_type2;
                        tmp_q_hash_cam_ctl.mcast0 = q_hash_cam_ctl.mcast2;
                        tmp_q_hash_cam_ctl.queue_base0 = q_hash_cam_ctl.queue_base2;
                        tmp_q_hash_cam_ctl.service_id0 = q_hash_cam_ctl.service_id2;
                        tmp_q_hash_cam_ctl.sgmac0 = q_hash_cam_ctl.sgmac2;
                        tmp_q_hash_cam_ctl.valid0 = q_hash_cam_ctl.valid2;
                        tmp_q_hash_cam_ctl.fid0 = q_hash_cam_ctl.fid2;
                        break;

                    case 3:
                        tmp_q_hash_cam_ctl.channel_id0 = q_hash_cam_ctl.channel_id3;
                        tmp_q_hash_cam_ctl.dest_chip_id0 = q_hash_cam_ctl.dest_chip_id3;
                        tmp_q_hash_cam_ctl.dest_queue0 = q_hash_cam_ctl.dest_queue3;
                        tmp_q_hash_cam_ctl.hash_type0 = q_hash_cam_ctl.hash_type3;
                        tmp_q_hash_cam_ctl.mcast0 = q_hash_cam_ctl.mcast3;
                        tmp_q_hash_cam_ctl.queue_base0 = q_hash_cam_ctl.queue_base3;
                        tmp_q_hash_cam_ctl.service_id0 = q_hash_cam_ctl.service_id3;
                        tmp_q_hash_cam_ctl.sgmac0 = q_hash_cam_ctl.sgmac3;
                        tmp_q_hash_cam_ctl.valid0 = q_hash_cam_ctl.valid3;
                        tmp_q_hash_cam_ctl.fid0 = q_hash_cam_ctl.fid3;
                        break;

                    case 4:
                        tmp_q_hash_cam_ctl.channel_id0 = q_hash_cam_ctl.channel_id4;
                        tmp_q_hash_cam_ctl.dest_chip_id0 = q_hash_cam_ctl.dest_chip_id4;
                        tmp_q_hash_cam_ctl.dest_queue0 = q_hash_cam_ctl.dest_queue4;
                        tmp_q_hash_cam_ctl.hash_type0 = q_hash_cam_ctl.hash_type4;
                        tmp_q_hash_cam_ctl.mcast0 = q_hash_cam_ctl.mcast4;
                        tmp_q_hash_cam_ctl.queue_base0 = q_hash_cam_ctl.queue_base4;
                        tmp_q_hash_cam_ctl.service_id0 = q_hash_cam_ctl.service_id4;
                        tmp_q_hash_cam_ctl.sgmac0 = q_hash_cam_ctl.sgmac4;
                        tmp_q_hash_cam_ctl.valid0 = q_hash_cam_ctl.valid4;
                        tmp_q_hash_cam_ctl.fid0 = q_hash_cam_ctl.fid4;
                        break;

                    case 5:
                        tmp_q_hash_cam_ctl.channel_id0 = q_hash_cam_ctl.channel_id5;
                        tmp_q_hash_cam_ctl.dest_chip_id0 = q_hash_cam_ctl.dest_chip_id5;
                        tmp_q_hash_cam_ctl.dest_queue0 = q_hash_cam_ctl.dest_queue5;
                        tmp_q_hash_cam_ctl.hash_type0 = q_hash_cam_ctl.hash_type5;
                        tmp_q_hash_cam_ctl.mcast0 = q_hash_cam_ctl.mcast5;
                        tmp_q_hash_cam_ctl.queue_base0 = q_hash_cam_ctl.queue_base5;
                        tmp_q_hash_cam_ctl.service_id0 = q_hash_cam_ctl.service_id5;
                        tmp_q_hash_cam_ctl.sgmac0 = q_hash_cam_ctl.sgmac5;
                        tmp_q_hash_cam_ctl.valid0 = q_hash_cam_ctl.valid5;
                        tmp_q_hash_cam_ctl.fid0 = q_hash_cam_ctl.fid5;
                        break;

                    case 6:
                        tmp_q_hash_cam_ctl.channel_id0 = q_hash_cam_ctl.channel_id6;
                        tmp_q_hash_cam_ctl.dest_chip_id0 = q_hash_cam_ctl.dest_chip_id6;
                        tmp_q_hash_cam_ctl.dest_queue0 = q_hash_cam_ctl.dest_queue6;
                        tmp_q_hash_cam_ctl.hash_type0 = q_hash_cam_ctl.hash_type6;
                        tmp_q_hash_cam_ctl.mcast0 = q_hash_cam_ctl.mcast6;
                        tmp_q_hash_cam_ctl.queue_base0 = q_hash_cam_ctl.queue_base6;
                        tmp_q_hash_cam_ctl.service_id0 = q_hash_cam_ctl.service_id6;
                        tmp_q_hash_cam_ctl.sgmac0 = q_hash_cam_ctl.sgmac6;
                        tmp_q_hash_cam_ctl.valid0 = q_hash_cam_ctl.valid6;
                        tmp_q_hash_cam_ctl.fid0 = q_hash_cam_ctl.fid6;
                        break;
                    case 7:
                        tmp_q_hash_cam_ctl.channel_id0 = q_hash_cam_ctl.channel_id7;
                        tmp_q_hash_cam_ctl.dest_chip_id0 = q_hash_cam_ctl.dest_chip_id7;
                        tmp_q_hash_cam_ctl.dest_queue0 = q_hash_cam_ctl.dest_queue7;
                        tmp_q_hash_cam_ctl.hash_type0 = q_hash_cam_ctl.hash_type7;
                        tmp_q_hash_cam_ctl.mcast0 = q_hash_cam_ctl.mcast7;
                        tmp_q_hash_cam_ctl.queue_base0 = q_hash_cam_ctl.queue_base7;
                        tmp_q_hash_cam_ctl.service_id0 = q_hash_cam_ctl.service_id7;
                        tmp_q_hash_cam_ctl.sgmac0 = q_hash_cam_ctl.sgmac7;
                        tmp_q_hash_cam_ctl.valid0 = q_hash_cam_ctl.valid7;
                        tmp_q_hash_cam_ctl.fid0 = q_hash_cam_ctl.fid7;
                        break;

                    default:
                        break;
                }

                if ((tmp_q_hash_cam_ctl.channel_id0 == ds_queue_lookup_key.channel_id0)
                    && (tmp_q_hash_cam_ctl.dest_chip_id0 == ds_queue_lookup_key.dest_chip_id0)
                    && (tmp_q_hash_cam_ctl.dest_queue0 == ds_queue_lookup_key.dest_queue0)
                    && (tmp_q_hash_cam_ctl.hash_type0 == ds_queue_lookup_key.hash_type0)
                    && (tmp_q_hash_cam_ctl.mcast0 == ds_queue_lookup_key.mcast0)
                    && (tmp_q_hash_cam_ctl.service_id0 == ds_queue_lookup_key.service_id0)
                    && (tmp_q_hash_cam_ctl.sgmac0 == ds_queue_lookup_key.sgmac0)
                    && (tmp_q_hash_cam_ctl.valid0 == ds_queue_lookup_key.valid0)
                    && (tmp_q_hash_cam_ctl.fid0 == ds_queue_lookup_key.fid0))
                {
                    queue_base = tmp_q_hash_cam_ctl.queue_base0;
                    break;
                }
            }
        }

        /* GEN_QUEUE_NUM */
        /* in hash mode, ds_queue_num_gen_ctl.flow_id_mask is used as flowIdEn */
        if ((flow_id != 0) && (ds_queue_num_gen_ctl.flow_id_mask != 0))
        {
            queue_number = (queue_base & 0x3FF) + (flow_id & 0xF);
        }
        else
        {

            queue_number = (queue_base & 0x3FF) + ((queue_select & 0x3F) >> ds_queue_num_gen_ctl.queue_select_shift);
        }
    }
    else
    {
        /* Mask bits */
        masked_queue_select = queue_select & ds_queue_num_gen_ctl.queue_select_mask;
        masked_dest_chip_id = (dest_chip_id - ds_queue_num_gen_ctl.dest_chip_id_base)
                                & ds_queue_num_gen_ctl.dest_chip_id_mask;
        masked_dest_queue = (dest_queue - ds_queue_num_gen_ctl.dest_queue_base)
                                & ds_queue_num_gen_ctl.dest_queue_mask;
        masked_sgmac_queue = (sgmac - ds_queue_num_gen_ctl.sgmac_base) & ds_queue_num_gen_ctl.sgmac_mask;
        masked_fid = (fid - ds_queue_num_gen_ctl.fid_base) & ds_queue_num_gen_ctl.fid_mask;
        masked_service_id = (service_id - ds_queue_num_gen_ctl.service_id_base)
                                & ds_queue_num_gen_ctl.service_id_mask;
        masked_flow_id = (flow_id - ds_queue_num_gen_ctl.flow_id_base) & ds_queue_num_gen_ctl.flow_id_mask;
        masked_channel_id = (channel_id - ds_queue_num_gen_ctl.channel_id_base) & ds_queue_num_gen_ctl.channel_id_mask;

        /* generate shift */
        shifted_queue_select = _cm_qmgt_qmanager_fn_queue_shift(masked_queue_select,
                                                                ds_queue_num_gen_ctl.queue_select_shift);
        shifted_dest_chip_id = _cm_qmgt_qmanager_fn_queue_shift(masked_dest_chip_id,
                                                                ds_queue_num_gen_ctl.dest_chip_id_shift);
        shifted_dest_queue = _cm_qmgt_qmanager_fn_queue_shift(masked_dest_queue,
                                                                ds_queue_num_gen_ctl.dest_queue_shift);
        shifted_sgmac_queue = _cm_qmgt_qmanager_fn_queue_shift(masked_sgmac_queue,
                                                                ds_queue_num_gen_ctl.sgmac_shift);
        shifted_fid = (_cm_qmgt_qmanager_fn_queue_shift(masked_fid, ds_queue_num_gen_ctl.fid_shift));
        shifted_service_id = (_cm_qmgt_qmanager_fn_queue_shift(masked_service_id,
                                                            ds_queue_num_gen_ctl.service_id_shift));
        shifted_flow_id = (_cm_qmgt_qmanager_fn_queue_shift(masked_flow_id, ds_queue_num_gen_ctl.flow_id_shift));
        shifted_channel_id = (_cm_qmgt_qmanager_fn_queue_shift(masked_channel_id, ds_queue_num_gen_ctl.channel_id_shift));

        /* final queue number */
        if ((flow_id != 0 ) && (ds_queue_num_gen_ctl.flow_id_mask != 0))
        {
            shift_queue_num = (shifted_dest_chip_id | shifted_dest_queue | shifted_sgmac_queue
                                | shifted_flow_id | shifted_fid | shifted_service_id | shifted_channel_id) & 0x3FF;
        }
        else
        {
            shift_queue_num = (shifted_dest_chip_id | shifted_dest_queue | shifted_sgmac_queue
                                | shifted_queue_select | shifted_fid | shifted_service_id | shifted_channel_id) & 0x3FF;
        }

        queue_number = shift_queue_num + ds_queue_num_gen_ctl.queue_num_base;

    }

    /* GEN_QUEUE_NUM */
    if (que_write_ctl.gen_que_id_rx_ether_oam && rx_oam && oam_dest_chip_id_match)
    {
        switch ((rx_oam_type & 0xF) - 1)
        {
            case 0:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base0;
                break;
            case 1:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base1;
                break;
            case 2:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base2;
                break;
            case 3:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base3;
                break;
            case 4:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base4;
                break;
            case 5:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base5;
                break;
            case 6:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base6;
                break;
            case 7:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base7;
                break;
            case 8:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base8;
                break;
            case 9:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base9;
                break;
            case 10:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base10;
                break;
            case 11:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base11;
                break;
            case 12:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base12;
                break;
            case 13:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base13;
                break;
            case 14:
                rx_oam_queue_base = que_write_ctl.rx_ether_oam_queue_base14;
                break;
            default:
                break;
        }

        queue_number = rx_oam_queue_base + ((queue_select & 0x3F) >> que_write_ctl.rx_ether_oam_queue_select_shift);
    }

    qcn_queue_id_valid = dest_chip_id_match;
    /* return {qcn_queue_id_valid, queueNum[9:0]} to IPEFwd, how realize?? */

    /* DEST_MAP_OVERWRITE */
    if (no_linkagg_member_discard
            || mcast_link_aggregation_discard
            || stacking_discard
            || p_ms_en_queue->msg_enqueue.enqueue_discard
            || mcast_channel_bunding_discard)
    {
        /* enqueue discard */
        p_queue_entry->discard = TRUE;
        CMODEL_DEBUG_OUT_INFO("StackingDiscard or McastLinkaggDiscard or NoLinkaggMemberDiscard is set, file:%s line:%d function:%s\n",
                              __FILE__, __LINE__, __FUNCTION__);

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE,
                             "Qmgt Queue Manager: StackingDiscard or McastLinkaggDiscard or NoLinkaggMemberDiscard.\n");
    }

    p_queue_entry->ds_queueentry.head_buffer_ptr = p_ms_en_queue->msg_enqueue.head_buffer_ptr;
    p_queue_entry->ds_queueentry.head_ptr_offset = p_ms_en_queue->msg_enqueue.head_buf_offset;
    p_queue_entry->ds_queueentry.resource_group_id = p_ms_en_queue->msg_enqueue.resource_group_id;
    p_queue_entry->ds_queueentry.packet_length = p_ms_en_queue->msg_enqueue.packet_length;
    p_queue_entry->ds_queueentry.next_hop_ext = p_ms_en_queue->msg_enqueue.next_hop_ext;
    p_queue_entry->ds_queueentry.length_adjust_type = p_ms_en_queue->msg_enqueue.length_adjust_type;
    p_queue_entry->ds_queueentry.mcast_rcd = p_ms_en_queue->msg_enqueue.mcast_rcd;
    p_queue_entry->ds_queueentry.dest_select = p_ms_en_queue->msg_enqueue.dest_select;

    /* understanding by shenhg according autogen ds, need to comfirm ???*/
    p_queue_entry->ds_queueentry.replication_ctl = (p_ms_en_queue->msg_enqueue.replication_ctl);
    //p_queue_entry->logical_rep_count = (p_ms_en_queue->msg_enqueue.replication_ctl & 0xF);

    p_queue_entry->ds_queueentry.rcd = p_ms_en_queue->msg_enqueue.rcd;
    /* p_queue_entry->ds_queueentry.congestion_valid = p_ms_en_queue->msg_enqueue.congestion_valid ??? */
    p_queue_entry->ds_queueentry.pt_enable= p_ms_en_queue->msg_enqueue.pt_enable;

    /* here only cmodel realize */
    p_queue_entry->queue_id = queue_number;
    p_queue_entry->replication_ctl_ext = p_ms_en_queue->msg_enqueue.replication_ctl_ext;

    if (que_write_ctl.use_old_dest_map && (!from_fabric)
        && qwrite_sgmac_ctl.sgmac_en && (dest_sgmac_group_id !=0))
    {
        p_queue_entry->ds_queueentry.dest_map = (old_dest_map & 0x3FFFFF);
    }
    else
    {
        p_queue_entry->ds_queueentry.dest_map = (dest_map & 0x3FFFFF);
    }

    /* queue scheduling/shaping/drop use lengthAdjustType, payloadOffset[6:0],muxLengthType[1:0] */
    /* (add muxlengthType[1:0] to payloadOffset[7:0] in BufferStore ??? */
    /* packetLength[13:0] = packetLength[13:0] - (lengthAdjustType,payloadOffset[7:0],muxLengthType[1:0]) length;*/
    return DRV_E_NONE;
}

/****************************************************************************
* Name:       cm_qmgt_qmanager_handle
* Purpose:    Provides generate queue ID per-enqueue message function.
* Parameters:
* Input:      p_qpkt  -- queue management packet pointer
* Output:     p_qpkt  -- queue management packet pointer
* Return:     DRV_E_NONE = success.
*             Other = Error, please refer to DRV_E_XXX.
* Note:       None.
****************************************************************************/
int32
cm_qmgt_qmanager_handle(queue_in_pkt_t *p_qpkt)
{
    queue_packet_info_t *p_pkt_info = (queue_packet_info_t *)p_qpkt->pkt_info;
    list_head_t *p_pos = NULL;
    fwd_ms_enqueue_t *p_ms_enqueue = NULL;
    fwd_queue_entry_t que_entry;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Queue Manager Process");

    list_for_each(p_pos, &p_pkt_info->ms_enqueue_list)
    {
        p_ms_enqueue = list_entry(p_pos, fwd_ms_enqueue_t, head);

#if 0
        if (p_ms_enqueue->msg_enqueue.enqueue_discard)
        {
            continue;
        }
#endif

#if (SDK_WORK_PLATFORM == 1)
        if(cosim_db.store_bsr_bus[SIM_FWD_MS_ENQUEUE])
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_bsr_bus[SIM_FWD_MS_ENQUEUE](p_ms_enqueue));
        }
#endif
        sal_memset(&que_entry, 0, sizeof(fwd_queue_entry_t));

        DRV_IF_ERROR_RETURN(_cm_qmgt_qmanager_generate_qid(p_qpkt, p_ms_enqueue, &que_entry));

        DRV_IF_ERROR_RETURN(_cm_qmgt_qmanager_generate_dequeue(p_qpkt, p_ms_enqueue, &que_entry));
    }

    return DRV_E_NONE;
}


