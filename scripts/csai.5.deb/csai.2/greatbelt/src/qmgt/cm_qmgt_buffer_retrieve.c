/****************************************************************************
* cm_qmgt_buffer_retrieve.c: Provides Buffer retrieve funciton.
*
* Copyright (c)2011 Centec Networks Inc. All rights reserved.
*
* Revision:   V1.0.
* Author:     Zhouw.
* Date:       2010-10-21.
* Reason:     First Create.
*
* Modify History:
* Revision:   V2.0.
* Author:     Zhouw.
* Date:       2011-04-16.
* Reason:     Sync to SpecV2.0.
*
* Revision:   V4.28.2.
* Author:     ZhouW.
* Date:       2011-09-28.
* Reason:     Sync to SpecV4.28.2.
*
* Revision:   V4.29.3.
* Author:     Shenhg.
* Date:       2011-10-10.
* Reason:     Sync to SpecV4.29.3.
*
* Revision:   V5.6.0.
* Author:     Shenhg.
* Date:       2012-01-06.
* Reason:     Sync to SpecV5.6.0.
*
* Revision:   V5.13.0.
* Author:     ZhouW.
* Date:       2012-03-10.
* Reason:     Sync to SpecV5.13.0.
*
* Revision:   V5.15.0.
* Author:     ZhouW.
* Date:       2012-03-22.
* Reason:     Sync to SpecV5.15.0.
*
* Revision:   V5.15.2.
* Author:     ZhouW.
* Date:       2012-04-01.
* Reason:     Sync to SpecV5.15.2.
*
* Revision:     V5.15.2.
* Author:       ZhouW.
* Date:         2012-04-01.
* Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "cm_lib.h"
#include "drv_lib.h"

/****************************************************************************
*
* Defines and Macros
*
****************************************************************************/
struct quemap_other_info_s
{
    uint8 from_fabric;
    uint8 chan_id;
    uint8 discard;
};
typedef struct quemap_other_info_s quemap_other_info_t;

/****************************************************************************
*
* Global and Declarations
*
****************************************************************************/

/****************************************************************************
*
* Functions
*
****************************************************************************/
static int32
_cm_qmgr_buffer_retrieve_debug_out_packet_info(out_pkt_t *p_out_pkt)
{
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "\nCModel Debug Qmgt Buffer Retrieve: [QMGT HDR]Output Packet: \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "--------------------------------------------------------- \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "chan_id: 0x%X\n",           p_out_pkt->chan_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "chip_id: 0x%X\n",           p_out_pkt->chip_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "--------------------------------------------------------- \n");

    return DRV_E_NONE;
}

static int32
_cm_qmgr_buffer_retrieve_debug_dequeue_info(fwd_ms_dequeue_t *p_ms_dequeue)
{
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "\nCModel Debug Qmgt Buffer Retrieve: [QMGT MSG]Dequeue Msg: \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "--------------------------------------------------------- \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "queue_id: 0x%X\n",             p_ms_dequeue->msg_dequeue.queue_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "dest_map: 0x%X\n",             p_ms_dequeue->msg_dequeue.dest_map);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_MSG, "--------------------------------------------------------- \n");

    return DRV_E_NONE;
}

static int32
_cm_qmgr_buffer_retrieve_debug_out_packet_header_info(greatbelt_packet_header_t* p_cm_packet_header)
{
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "\nCModel Debug Qmgt Buffer Retrieve: [QMGT HDR]Out Pakcet Header: \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "--------------------------------------------------------- \n");
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "mcast 0x%X\n",               p_cm_packet_header->mcast);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "dest_chip_id 0x%X\n",        p_cm_packet_header->dest_chip_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "dest_id 0x%X\n",             p_cm_packet_header->dest_id);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "next_hop_ptr 0x%X\n",        p_cm_packet_header->next_hop_ptr);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "from_fabric 0x%X\n",         p_cm_packet_header->from_fabric);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "bypass_ingress_edit 0x%X\n", p_cm_packet_header->bypass_ingress_edit);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "from_cpu_or_oam 0x%X\n",     p_cm_packet_header->from_cpu_or_oam);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "operation_type 0x%X\n",      p_cm_packet_header->operation_type);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_QMGT_HDR, "--------------------------------------------------------- \n");

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_qmgt_buffer_retrieve_reform_ouput_pkt
* Purpose:    Reform output packet from bufferRetriv(include re-calculate
              headerCRC and form outpkt with new bridge header).
* Parameters:
* Input:      p_qpkt -- queue management packet pointer.
*             p_greatbelt_header -- greatbelt header pointer.
* Output:     p_outpkt_ptr -- output pakcet pointer.
* Return:     DRV_E_NONE = success.
*             Other = ErrorCode, please refer to DRV_E_XXX.
* Note:       None.
****************************************************************************/
static int32
_cm_qmgt_buffer_retrieve_reform_ouput_pkt(greatbelt_packet_header_t *p_greatbelt_header,
                                                              uint8 *p_inpkt_ptr,
                                                              out_pkt_t *p_outpkt,uint32 pkt_len)
{
    ms_packet_header_t *p_src_hdr = NULL;

    p_src_hdr = sal_malloc(sizeof(ms_packet_header_t));
    sal_memset(p_src_hdr, 0, sizeof(ms_packet_header_t));

    /* Convert Bridge Header */
    cm_gen_greatbelt_packet_header(p_src_hdr, p_greatbelt_header, FALSE);

    /* Rewrite HeaderCRC */
    DRV_IF_ERROR_RETURN(swap32((uint32 *)p_src_hdr, GREAT_BELT_HEADER_LEN / 4, HOST_TO_NETWORK));
    ((uint8 *)p_src_hdr)[GREATBELT_HDR_CRC_OFFSET] &= 0xF0;
    ((uint8 *)p_src_hdr)[GREATBELT_HDR_CRC_OFFSET] |= calculate_crc4((uint8 *)p_src_hdr, GREAT_BELT_HEADER_LEN, 0);

    /* Replace Bridge Header and form outpacket */

    sal_memcpy(p_outpkt->pkt,p_inpkt_ptr,pkt_len);
    sal_memcpy(p_outpkt->module_bus.packet_header, p_src_hdr, GREAT_BELT_HEADER_LEN);

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_bheader)
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_bheader(p_outpkt->module_bus.packet_header, SIM_MODULE_FWD));
    }
#endif

    sal_free(p_src_hdr);
    p_src_hdr = NULL;

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_qmgt_buffer_retrieve_gen_excep_outpkt
* Purpose:    Generation exception dequeue message's outpkt.
* Parameters:
* Input:      p_qpkt -- queue management packet pointer.
*             p_ms_dequeue -- dequeue message pointer.
*             p_quemap_infoptr
* Output:     p_outpkt_list -- output packet list pointer.
* Return:     DRV_E_NONE = success.
*             Other = ErrorCode, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/

static int32
_cm_qmgt_buffer_retrieve_gen_excep_outpkt(fwd_ms_dequeue_t *p_ms_dequeue,
                                                  queue_in_pkt_t *p_qpkt,
                                                  list_head_t *p_outpkt_list,
                                                  quemap_other_info_t *p_quemap_infoptr)
{

    uint32 cmd = 0;
    greatbelt_packet_header_t greatbelt_header;
    out_pkt_t *p_newpkt_node = NULL;
    ds_buf_retrv_excp_t bufrev_exp;
    q_mgr_que_deq_stats_base_t deq_stats_base;
    buffer_retrieve_ctl_t buffer_retrieve_ctl;
    ds_buf_retrv_color_map_t ds_buf_retrv_color_map;
    ds_buf_retrv_priority_ctl_t ds_buf_retrv_pri_ctl;
    uint8 exception_index = 0;
    uint8 p_header[GREAT_BELT_HEADER_LEN] = {0};
    uint8 ingress_exception_en = FALSE;
    uint8 exception_reset_header = FALSE;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Buffer Retrieve Generate Excepion Output Packet");

    sal_memset(&deq_stats_base, 0, sizeof(deq_stats_base));
    cmd = DRV_IOR(QMgrQueDeqStatsBase_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &deq_stats_base));

    sal_memset(&bufrev_exp, 0, sizeof(ds_buf_retrv_excp_t));
    /* MsDequeue.replicationCtl = {5'd0, exceptionPacketType[2:0], exceptionIndex[7:0]} */
    exception_index = p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF;
    cmd = DRV_IOR(DsBufRetrvExcp_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, exception_index, cmd, &bufrev_exp));

    /* Adjust packet header */
    sal_memcpy(p_header, p_qpkt->module_bus.packet_header, sizeof(ms_packet_header_t));
    DRV_IF_ERROR_RETURN(swap32((uint32*)p_header, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));
    sal_memset(&greatbelt_header, 0, sizeof(greatbelt_header));
    cm_gen_greatbelt_packet_header((ms_packet_header_t*)p_header, &greatbelt_header, TRUE);

    greatbelt_header.next_hop_ptr = bufrev_exp.next_hop_ptr;

    sal_memset(&buffer_retrieve_ctl, 0, sizeof(buffer_retrieve_ctl));
    cmd = DRV_IOR(BufferRetrieveCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &buffer_retrieve_ctl));

    /* {4'd0, egressExceptionFromSgmac, exceptionPacketType[2:0], exceptionIndex[7:0]} */
    if ((p_ms_dequeue->msg_dequeue.replication_ctl>>11)&0x1) /* egressExceptionFromSgmac */
    {
        greatbelt_header.next_hop_ptr += (buffer_retrieve_ctl.sgmac_exception_nexthop_base & 0xFFFF);
    }

    if (buffer_retrieve_ctl.color_map_en)
    {
        sal_memset(&ds_buf_retrv_color_map, 0, sizeof(ds_buf_retrv_color_map));
        cmd = DRV_IOR(DsBufRetrvColorMap_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id,
                                     ((greatbelt_header.priority << 1) | (p_ms_dequeue->msg_dequeue.in_profile)),
                                      cmd, &ds_buf_retrv_color_map));

        greatbelt_header.color = ds_buf_retrv_color_map.color;
    }

    sal_memset(&ds_buf_retrv_pri_ctl, 0, sizeof(ds_buf_retrv_pri_ctl));
    cmd = DRV_IOR(DsBufRetrvPriorityCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, (p_ms_dequeue->msg_dequeue.replication_ctl&0xFF),
                                 cmd, &ds_buf_retrv_pri_ctl));

    if (ds_buf_retrv_pri_ctl.priority_en)
    {
        greatbelt_header.priority = ds_buf_retrv_pri_ctl.priority<<3;
        greatbelt_header.color = COLOR_GREEN;
    }

    greatbelt_header.length_adjust_type = p_ms_dequeue->msg_dequeue.length_adjust_type;
    greatbelt_header.mcast = GET_MCAST_IN_DESTMAP(p_ms_dequeue->msg_dequeue.dest_map);
    greatbelt_header.dest_chip_id = GET_DESTCHIPID_IN_DESTMAP(p_ms_dequeue->msg_dequeue.dest_map);
    greatbelt_header.dest_id = GET_DESTID_IN_DESTMAP(p_ms_dequeue->msg_dequeue.dest_map);
    greatbelt_header.next_hop_ext = p_ms_dequeue->msg_dequeue.next_hop_ext;

    /* when exception, MsDequeue.replicationCtl = {8'd0, exceptionFromSgmac, exceptionPacketType[2:0],
        exceptionIndex[7:0] } */
    if (!IS_BIT_SET(p_ms_dequeue->msg_dequeue.replication_ctl,11)
        ||bufrev_exp.packet_offset_reset)
    {
        greatbelt_header.packet_offset = 0;/* force offset to 0 for exception (with outer header to CPU) */
        greatbelt_header.packet_type = (p_ms_dequeue->msg_dequeue.replication_ctl>>8)&0x7;
    }
    else if (IS_BIT_SET(p_ms_dequeue->msg_dequeue.replication_ctl,11))  /* (without outer header to CPU) */
    {
        greatbelt_header.packet_offset += 32;
    }

    /*bug 4668 ECO begin*/
    /* if (buffer_retrieve_ctl.exception_follow_mirror
        || ((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF) < 24)
        || (((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF) > 31)
            && ((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF) < 56)))*/
    if (buffer_retrieve_ctl.exception_follow_mirror || ((p_ms_dequeue->msg_dequeue.replication_ctl&0xFF)<24)
        ||(((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF) >= 31)
            && ((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF) < 56))
        ||((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF)==27))
    /*bug 4668 ECO end*/
    {
        greatbelt_header.svlan_tag_operation_valid = FALSE;
        greatbelt_header.mux_length_type = 0;
        if (greatbelt_header.operation_type == OPERATION_TYPE_NORMAL)
        {
            greatbelt_header.ip_sa_u.share1.cvlan_tag_operation_valid = FALSE;
            greatbelt_header.ip_sa_u.share1.isid_valid = FALSE;
            greatbelt_header.fid_u.share1.acl_dscp_valid = FALSE;
        }
    }

    /* in spec, PacketHeader.destIdDiscard describe as following:
    if (MsDequeue.discard)
        PacketHeader.destIdDiscard = 1'b1;
    else
        PacketHeader.destIdDiscard = 1'b0;

    but, MsDequeue.discard is Discard for queue aging, cmodel is useless */
    p_qpkt->module_bus.dest_id_discard = FALSE;

    if (buffer_retrieve_ctl.critical_packet_to_fabric
        && (GET_DESTCHIPID_IN_DESTMAP(p_ms_dequeue->msg_dequeue.dest_map) != buffer_retrieve_ctl.chip_id))
    {
        greatbelt_header.critical_packet = TRUE;
    }

    if (p_ms_dequeue->msg_dequeue.pt_enable)
    {
        greatbelt_header.pbb_src_port_type_u.share1.pt_enable = TRUE;
    }

    switch ((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF) >> 5)
    {
    case 0:
        exception_reset_header = IS_BIT_SET(buffer_retrieve_ctl.exception_reset_header31_0,p_ms_dequeue->msg_dequeue.replication_ctl & 0x1F);
        break;
    case 1:
        exception_reset_header = IS_BIT_SET(buffer_retrieve_ctl.exception_reset_header63_32,p_ms_dequeue->msg_dequeue.replication_ctl & 0x1F);
        break;
    case 2:
        exception_reset_header = IS_BIT_SET(buffer_retrieve_ctl.exception_reset_header95_64,p_ms_dequeue->msg_dequeue.replication_ctl & 0x1F);
        break;
    case 3:
        exception_reset_header = IS_BIT_SET(buffer_retrieve_ctl.exception_reset_header127_96,p_ms_dequeue->msg_dequeue.replication_ctl & 0x1F);
        break;
    case 4:
        exception_reset_header = IS_BIT_SET(buffer_retrieve_ctl.exception_reset_header159_128,p_ms_dequeue->msg_dequeue.replication_ctl & 0x1F);
        break;
    case 5:
        exception_reset_header = IS_BIT_SET(buffer_retrieve_ctl.exception_reset_header191_160,p_ms_dequeue->msg_dequeue.replication_ctl & 0x1F);
        break;
    case 6:
        exception_reset_header = IS_BIT_SET(buffer_retrieve_ctl.exception_reset_header223_192,p_ms_dequeue->msg_dequeue.replication_ctl & 0x1F);
        break;
    case 7:
        exception_reset_header = IS_BIT_SET(buffer_retrieve_ctl.exception_reset_header255_224,p_ms_dequeue->msg_dequeue.replication_ctl & 0x1F);
        break;
    default:
        break;
    }

    if ((greatbelt_header.operation_type != OPERATION_TYPE_NORMAL) && exception_reset_header)  /* other bits ??? */
    {
        greatbelt_header.operation_type = OPERATION_TYPE_NORMAL;

        greatbelt_header.src_ctag_offset_type_u.src_ctag_offset_type = FALSE;
        greatbelt_header.ttl_u.ttl = 0;
        greatbelt_header.source_port_isolate_id_u.source_port_isolate_id = 0;
        greatbelt_header.pbb_src_port_type_u.pbb_src_port_type = 0;
        greatbelt_header.src_cvlan_id_valid_u.src_cvlanid_valid = FALSE;
        /* rxtxFcl[31:0] = 0 */
        greatbelt_header.rxtx_fcl0_u.rxtx_fcl_0 = 0;
        greatbelt_header.rxtx_fcl2_1_u.rxtx_fcl_2_1 = 0;
        greatbelt_header.rxtx_fcl3_u.rxtx_fcl_3 = 0;
        greatbelt_header.src_cvlan_id_u.rxtx_fcl_15_4 = 0;
        greatbelt_header.src_cvlan_id_valid_u.rxtx_fcl_16 = 0;
        greatbelt_header.rxtx_fcl_22_17_u.rxtx_fcl_22_17 = 0;
        greatbelt_header.ttl_u.rxtx_fcl_30_23 = 0;
        greatbelt_header.src_ctag_offset_type_u.rxtx_fcl_31 = 0;
        /* srcCvlanId[11:0] = 0 */
        greatbelt_header.src_cvlan_id_u.src_cvlan_id = 0;
        /* fid[15:0] = 0 */
        greatbelt_header.fid_u.rx_fcb_31_16 = 0;
        /* logicSrcPort[15:0] = 0 */
        greatbelt_header.logic_src_port_u.rx_fcb_15_0 = 0;
        /* txFcb[31:0] = 0 */
        greatbelt_header.ip_sa_u.tx_fcb_31_0 = 0;

        greatbelt_header.source_port_isolate_id_u.source_port_isolate_id = 0;
    }

    /* Force exception source chip self */
    /* IPE exception only occur in source chip, to CPU with source port */
    /* EPE exception to CPU with dest port */
    /* ingress/egress mirror use mirrored source chip, localPhyPort filling in IPE Fwd/EPE Header Edit */

    ingress_exception_en = ((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF) < 26)
                            || (((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF) >= 28) && ((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF) <= 31))
                            || ((p_ms_dequeue->msg_dequeue.replication_ctl & 0xFF) >= 64);

    if (buffer_retrieve_ctl.stacking_en && IS_BIT_SET(p_ms_dequeue->msg_dequeue.replication_ctl,11)  /* used as exceptionFromSgmac */
           && ingress_exception_en)
    {
        /* stacking mirror use srcSgmacGroupId[3:0](associated with logId) */
        /* egress mirror use SGMAC port as sourcePort in EPE Header edit */
        greatbelt_header.source_port15_14 = 0;
        greatbelt_header.source_port = ((buffer_retrieve_ctl.chip_id) << 9) | (1 << 8) | ((p_ms_dequeue->msg_dequeue.replication_ctl >> 12) & 0xF);
    } /* mirror from network port use local chipId[4:0] */

    greatbelt_header.bypass_ingress_edit = TRUE;
    greatbelt_header.from_fabric = FALSE;

    /* creat new outpkt node*/
    p_newpkt_node = (out_pkt_t *)sal_malloc(sizeof(out_pkt_t));
    if (NULL == p_newpkt_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(p_newpkt_node, 0, sizeof(out_pkt_t));

    p_newpkt_node->pkt = (uint8 *)sal_malloc(MTU);
    if (NULL == p_newpkt_node->pkt)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(p_newpkt_node->pkt, 0, MTU);

    p_newpkt_node->exception = (void *)sal_malloc(sizeof(greatbelt_exception_info_t));
    if (NULL == p_newpkt_node->exception)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(p_newpkt_node->exception, 0, sizeof(greatbelt_exception_info_t));

    p_newpkt_node->chan_id = p_quemap_infoptr->chan_id;
    p_newpkt_node->pkt_id = p_qpkt->pkt_id;
    p_newpkt_node->chip_id = p_qpkt->chip_id;
    p_newpkt_node->local_phy_port = p_qpkt->local_phy_port;
    p_newpkt_node->packet_length = p_qpkt->packet_length;
    sal_memcpy(&p_newpkt_node->module_bus, &p_qpkt->module_bus, sizeof(p_qpkt->module_bus));

    if (CPU_CHANID == p_newpkt_node->chan_id)
    {
        p_newpkt_node->dest_queue = SIM_NETTX_Q;
    }
    else if (DMA_CHANID == p_newpkt_node->chan_id)
    {
        p_newpkt_node->dest_queue = SIM_NETTX_Q;
    }
    else if (OAM_CHANID == p_newpkt_node->chan_id)
    {
        p_newpkt_node->dest_queue = SIM_OAM_Q;
    }
    else if (I_LOOPBACK_CHANID == p_newpkt_node->chan_id)
    {
        p_newpkt_node->dest_queue = SIM_IPE_Q;
    }
#if 0
    else if ((p_newpkt_node->chan_id <= FABRIC_MAX_CHAN_ID) /* Fabric channel([128-255]) */
              && (p_newpkt_node->chan_id >= FABRIC_MIN_CHAN_ID))
    {
        p_newpkt_node->dest_queue = SIM_FWD_Q; /* Cmodel code simulation two chip */
        /* Cmodel code simulation only one chip, each dut has one image. */
        /*newpkt_node->dest_queue = SIM_NETTX_Q;*/
    }
#endif
    else
    {
        p_newpkt_node->dest_queue = SIM_EPE_Q;
    }

    if ((CPU_CHANID == p_newpkt_node->chan_id)
         || (OAM_CHANID == p_newpkt_node->chan_id))
    {
        DRV_IF_ERROR_RETURN(sim_increase_statistics(p_qpkt->chip_id, CM_STATS_DEFAULT,
                                            p_newpkt_node->chan_id, p_newpkt_node->packet_length));
    }

    /* Get pkt comment(include header,and humber and greatbelt has 32 bytes) */
    DRV_IF_ERROR_RETURN(_cm_qmgt_buffer_retrieve_reform_ouput_pkt(&greatbelt_header, p_qpkt->pkt,
                                                                p_newpkt_node,p_newpkt_node->packet_length));

    /* can not trust Ipe -> BSR's brgHdr's pktLen (do not include ILOOP) */
    p_newpkt_node->module_bus.pkt_len = p_newpkt_node->packet_length;

    _cm_qmgr_buffer_retrieve_debug_out_packet_header_info(&greatbelt_header);
    _cm_qmgr_buffer_retrieve_debug_out_packet_info(p_newpkt_node);

    /* insert new node into fwd out pkt linklist */
    list_add_tail(&(p_newpkt_node->head), p_outpkt_list);

#if V5_8_NOTE
    if (deq_stats_base.deq_stats_en)
    {
        DRV_IF_ERROR_RETURN(sim_increase_statistics(p_qpkt->chip_id, CM_STATS_DEFAULT,
                                        (p_ms_dequeue->msg_dequeue.queue_id + deq_stats_base.deq_stats_base * 256),
                                        p_newpkt_node->packet_length));
    }
#endif
    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_qmgt_buffer_retrieve_gen_local_outpkt
* Purpose:    Generation local dequeue message's outpkt.
* Parameters:
* Input:      p_qpkt -- queue management packet pointer.
*             p_ms_dequeue -- dequeue message pointer.
*             p_quemap_infoptr
* Output:     p_outpkt_list -- output packet list pointer.
* Return:     DRV_E_NONE = success.
*             Other = ErrorCode, please refer to DRV_E_XXX.
* Note:       None.
****************************************************************************/
static int32
_cm_qmgt_buffer_retrieve_gen_local_outpkt(fwd_ms_dequeue_t *p_ms_dequeue,
                                          queue_in_pkt_t *p_qpkt,
                                          list_head_t *p_outpkt_list,
                                          quemap_other_info_t *p_quemap_infoptr)
{
    #define FABRIC_CHAN_BASE 128
    uint32 cmd = 0;
    greatbelt_packet_header_t greatbelt_header;
    out_pkt_t *p_newpkt_node = NULL;
    q_mgr_que_deq_stats_base_t deq_stats_base;
    buffer_retrieve_ctl_t buffer_retrieve_ctl;
    ds_buf_retrv_color_map_t ds_buf_retrv_color_map;
    uint8 p_header[GREAT_BELT_HEADER_LEN] = {0};

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Buffer Retrieve Generate Local OutPut Packet");

    sal_memset(&deq_stats_base, 0, sizeof(deq_stats_base));
    cmd = DRV_IOR(QMgrQueDeqStatsBase_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &deq_stats_base));

    /* Adjust packet header */
    sal_memcpy(p_header, p_qpkt->module_bus.packet_header, sizeof(ms_packet_header_t));
    DRV_IF_ERROR_RETURN(swap32((uint32*)p_header, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));
    sal_memset(&greatbelt_header, 0, sizeof(greatbelt_header));
    cm_gen_greatbelt_packet_header((ms_packet_header_t*)p_header, &greatbelt_header, TRUE);

    /* in spec, PacketHeader.destIdDiscard describe as following:
    if (MsDequeue.discard)
        destIdDiscard = 1'b1;
    else
        destIdDiscard = 1'b0;
    but, MsDequeue.discard is Discard for queue aging, cmodel is useless */
    p_qpkt->module_bus.dest_id_discard = p_quemap_infoptr->discard;

    sal_memset(&buffer_retrieve_ctl, 0, sizeof(buffer_retrieve_ctl));
    cmd = DRV_IOR(BufferRetrieveCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &buffer_retrieve_ctl));

    if (buffer_retrieve_ctl.color_map_en)
    {
        sal_memset(&ds_buf_retrv_color_map, 0, sizeof(ds_buf_retrv_color_map));
        cmd = DRV_IOR(DsBufRetrvColorMap_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id,
                                     ((greatbelt_header.priority << 1) | (p_ms_dequeue->msg_dequeue.in_profile)),
                                      cmd, &ds_buf_retrv_color_map));

        greatbelt_header.color = ds_buf_retrv_color_map.color;
    }

    greatbelt_header.length_adjust_type = p_ms_dequeue->msg_dequeue.length_adjust_type;
    greatbelt_header.mcast = GET_MCAST_IN_DESTMAP(p_ms_dequeue->msg_dequeue.dest_map);
    greatbelt_header.dest_chip_id = GET_DESTCHIPID_IN_DESTMAP(p_ms_dequeue->msg_dequeue.dest_map);
    greatbelt_header.dest_id = GET_DESTID_IN_DESTMAP(p_ms_dequeue->msg_dequeue.dest_map);
    greatbelt_header.next_hop_ext = p_ms_dequeue->msg_dequeue.next_hop_ext;
    greatbelt_header.next_hop_ptr += p_ms_dequeue->msg_dequeue.replication_ctl;

    if (buffer_retrieve_ctl.cross_chip_high_priority_en
        && (GET_DESTCHIPID_IN_DESTMAP(p_ms_dequeue->msg_dequeue.dest_map) != buffer_retrieve_ctl.chip_id))
    {
        greatbelt_header.critical_packet = TRUE;
    }

    if (p_ms_dequeue->msg_dequeue.pt_enable)
    {
        greatbelt_header.pbb_src_port_type_u.share1.pt_enable = TRUE;
    }

    if (greatbelt_header.operation_type == OPERATION_TYPE_NORMAL)
    {
        greatbelt_header.ip_sa_u.share1.congestion_valid = p_ms_dequeue->msg_dequeue.congestion_valid;
    }

    /* creat new outpkt node */
    p_newpkt_node = (out_pkt_t *)sal_malloc(sizeof(out_pkt_t));
    if (NULL == p_newpkt_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(p_newpkt_node, 0, sizeof(out_pkt_t));

    p_newpkt_node->pkt = (uint8 *)sal_malloc(MTU);
    if (NULL == p_newpkt_node->pkt)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(p_newpkt_node->pkt, 0, MTU);

    p_newpkt_node->exception = (void *)sal_malloc(sizeof(greatbelt_exception_info_t));
    if (NULL == p_newpkt_node->exception)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(p_newpkt_node->exception, 0, sizeof(greatbelt_exception_info_t));

    p_newpkt_node->chan_id = p_quemap_infoptr->chan_id;
    p_newpkt_node->pkt_id = p_qpkt->pkt_id;
    p_newpkt_node->local_phy_port = p_qpkt->local_phy_port;
    p_newpkt_node->packet_length = p_qpkt->packet_length;
    p_newpkt_node->dest_queue = SIM_EPE_Q;
    p_newpkt_node->from_fabric = p_quemap_infoptr->from_fabric;
    sal_memcpy(&p_newpkt_node->module_bus, &p_qpkt->module_bus, sizeof(p_qpkt->module_bus));

    if (p_quemap_infoptr->from_fabric)
    {
        p_newpkt_node->chip_id = (p_quemap_infoptr->chan_id - FABRIC_CHAN_BASE) % 32;
    }
    else
    {
        p_newpkt_node->chip_id = p_qpkt->chip_id;
    }

    if (I_LOOPBACK_CHANID == p_newpkt_node->chan_id) /* I-Loop */
    {
        CMODEL_DEBUG_OUT_INFO("++++++++++++++++++++++++ Do I_loop!\n");
        p_newpkt_node->dest_queue = SIM_IPE_Q;
    }
    else if (E_LOOPBACK_CHANID == p_newpkt_node->chan_id) /* E-Loop */
    {
        CMODEL_DEBUG_OUT_INFO("++++++++++++++++++++++++ Do E_loop!\n");
        p_newpkt_node->dest_queue = SIM_EPE_Q;
    }
    else if (p_newpkt_node->chan_id >= ELOG_MIN_CHANID && p_newpkt_node->chan_id <= ELOG_MAX_CHANID) /* E-Log chanid: 64 ~ 119 */
    {
        CMODEL_DEBUG_OUT_INFO("++++++++++++++++++++++++ Do ELOG!\n");
        p_newpkt_node->dest_queue = SIM_EPE_Q;
    }
    else if (CPU_CHANID == p_newpkt_node->chan_id)  /* CPU Channel */
    {
        CMODEL_DEBUG_OUT_INFO("++++++++++++++++++++++++ To CPU!\n");
        p_newpkt_node->dest_queue = SIM_NETTX_Q;
        DRV_IF_ERROR_RETURN(sim_increase_statistics(p_qpkt->chip_id, CM_STATS_DEFAULT,
                                                    CPU_CHANID, p_newpkt_node->packet_length));
    }
    else if (OAM_CHANID == p_newpkt_node->chan_id) /* OAM Channel */
    {
        CMODEL_DEBUG_OUT_INFO("++++++++++++++++++++++++ To OAM!\n");
        p_newpkt_node->dest_queue = SIM_OAM_Q;
        DRV_IF_ERROR_RETURN(sim_increase_statistics(p_qpkt->chip_id, CM_STATS_DEFAULT,
                                                    OAM_CHANID, p_newpkt_node->packet_length));
    }
    else if ((p_newpkt_node->chan_id <= SGMAC_MAX_CHANID) /* XGMAC */
             && (p_newpkt_node->chan_id >= SGMAC_MIN_CHANID))
    {
        p_newpkt_node->dest_queue = SIM_EPE_Q;
    }
    else if (DMA_CHANID == p_newpkt_node->chan_id)       /* DMA channel */
    {
        CMODEL_DEBUG_OUT_INFO("++++++++++++++++++++++++ To DMA!\n");
        p_newpkt_node->dest_queue = SIM_NETTX_Q;
        //DRV_IF_ERROR_RETURN(sim_increase_statistics(p_qpkt->chip_id, CM_STATS_DEFAULT,
        //                                            CPU_CHANID, p_newpkt_node->packet_length));
    }
    else if (INTERLAKEN_CHANID == p_qpkt->chan_id)/* InterLaken channel */
    {
        p_newpkt_node->dest_queue = SIM_EPE_Q;
    }
    else                                          /* GMAC */
    {
        p_newpkt_node->dest_queue = SIM_EPE_Q;
    }

    /* get pkt comment */
    DRV_IF_ERROR_RETURN(_cm_qmgt_buffer_retrieve_reform_ouput_pkt(&greatbelt_header, p_qpkt->pkt,
                                                                    p_newpkt_node,p_newpkt_node->packet_length));

    /* can not trust Ipe -> BSR's brgHdr's pktLen (do not include ILOOP) */
    p_newpkt_node->module_bus.pkt_len = p_newpkt_node->packet_length;

    _cm_qmgr_buffer_retrieve_debug_out_packet_header_info(&greatbelt_header);
    _cm_qmgr_buffer_retrieve_debug_out_packet_info(p_newpkt_node);

    /* insert new node into fwd out pkt linklist */
    list_add_tail(&p_newpkt_node->head, p_outpkt_list);

#if V5_8_NOTE
    if (deq_stats_base.deq_stats_en)
    {
        DRV_IF_ERROR_RETURN(sim_increase_statistics(p_qpkt->chip_id, CM_STATS_DEFAULT,
                               (p_ms_dequeue->msg_dequeue.queue_id + deq_stats_base.deq_stats_base * 256),
                               p_newpkt_node->packet_length));
    }
#endif

    return DRV_E_NONE;
}
/****************************************************************************
* Name:       _cm_qmgt_buffer_retrieve_gen_outpacket_list
* Purpose:    Add a new packet header to the tail.
* Parameters:
* Input:      p_qpkt -- queue management packet pointer.
*             p_ms_dequeue -- dequeue message pointer.
* Output:     p_out_pkt_list -- output packet list pointer.
* Return:     DRV_E_NONE = success.
*             Other = ErrorCode, please refer to DRV_E_XXX.
* Note:       None.
****************************************************************************/
static int32
_cm_qmgt_buffer_retrieve_gen_outpacket_list(fwd_ms_dequeue_t *p_ms_dequeue,
                                                   queue_in_pkt_t *p_qpkt, list_head_t *p_out_pkt_list)
{

    uint32 cmd = 0;
    ds_que_map_t que_map;
    quemap_other_info_t quemap_info;
    q_mgr_reserved_channel_range_t qmgt_rsv_chan_rag;
    ds_grp_shp_wfq_ctl_t ds_grp_shp_wfq_ctl;
    ds_egr_resrc_ctl_t ds_egr_resrc_ctl;

    sal_memset(&quemap_info, 0, sizeof(quemap_other_info_t));
    sal_memset(&que_map, 0, sizeof(que_map));
    sal_memset(&ds_grp_shp_wfq_ctl, 0, sizeof(ds_grp_shp_wfq_ctl));
    sal_memset(&ds_egr_resrc_ctl, 0, sizeof(ds_egr_resrc_ctl_t));

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Buffer Retrieve Gen Out Packet List");

    cmd = DRV_IOR(DsQueMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, p_ms_dequeue->msg_dequeue.queue_id, cmd, &que_map));
    p_ms_dequeue->msg_dequeue.grp_id = que_map.grp_id;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x], chan id 0x%X, group id 0x%X\n",
                         "DsQueMap_t", p_ms_dequeue->msg_dequeue.queue_id, que_map.chan_id, que_map.grp_id);

    /* reclaculate qid according to RTL realization, do not forget to cfg the table */
    cmd = DRV_IOR(DsGrpShpWfqCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, que_map.grp_id, cmd, &ds_grp_shp_wfq_ctl));
    p_ms_dequeue->msg_dequeue.queue_id = ds_grp_shp_wfq_ctl.start_que_id + que_map.offset;

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_bsr_bus[SIM_FWD_MS_DEQUEUE])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_bsr_bus[SIM_FWD_MS_DEQUEUE](p_ms_dequeue));
    }

#if 1
        cmd = DRV_IOR(DsEgrResrcCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(p_qpkt->chip_id, p_ms_dequeue->msg_dequeue.queue_id, cmd, &ds_egr_resrc_ctl));
        if (ds_egr_resrc_ctl.grp_drop_prof_id_high == 1)
        {
                CMODEL_DEBUG_OUT_INFO("Resource group manager discard, file:%s line:%d function:%s\n",
                                      __FILE__, __LINE__, __FUNCTION__);

                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "Qmgt Buffer Retrieve Discard: DROP channel discard\n");
                return DRV_E_NONE;

        }
#endif
#if 0
    ds_que_shp_ctl_t ds_que_shp_ctl;
    sal_memset(&ds_que_shp_ctl, 0, sizeof(ds_que_shp_ctl_t));
    cmd = DRV_IOR(DsQueShpCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, p_ms_dequeue->msg_dequeue.grp_id, cmd, &ds_que_shp_ctl));

    if (IS_BIT_SET(ds_que_shp_ctl.que_shp_en_vec, que_map.offset))
    {
         ds_que_shp_wfq_ctl_t ds_que_shp_wfq_ctl;
        sal_memset(&ds_que_shp_wfq_ctl, 0, sizeof(ds_que_shp_wfq_ctl_t));
        cmd = DRV_IOR(DsQueShpWfqCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, p_ms_dequeue->msg_dequeue.queue_id, cmd, &ds_que_shp_wfq_ctl));


        ds_que_shp_profile_t ds_que_shp_profile;
        cmd = DRV_IOR(DsQueShpProfile_t, DRV_ENTRY_FLAG);
        sal_memset(&ds_que_shp_profile, 0, sizeof(ds_que_shp_profile_t));
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, ds_que_shp_wfq_ctl.que_shp_prof_id, cmd, &ds_que_shp_profile));
        if ((0 == ds_que_shp_profile.token_rate) && (0 == ds_que_shp_profile.token_rate_frac))
        {
            quemap_info.discard = TRUE;
            if (quemap_info.discard)
            {
                CMODEL_DEBUG_OUT_INFO("Queue Shape discard, file:%s line:%d function:%s\n",
                                      __FILE__, __LINE__, __FUNCTION__);

                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "Qmgt Buffer Retrieve Discard: DROP channel discard\n");
                return DRV_E_NONE;
            }
        }

    }
#endif


#endif

    if (p_ms_dequeue->discard) /* maybe aging */
    {
        return DRV_E_NONE;
    }

    /* if channel id is reserved channel, discard */
    sal_memset(&qmgt_rsv_chan_rag, 0, sizeof(qmgt_rsv_chan_rag));
    cmd =  DRV_IOR(QMgrReservedChannelRange_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &qmgt_rsv_chan_rag));

    if (qmgt_rsv_chan_rag.reserved_channel_valid0)
    {
        if ((que_map.chan_id <= qmgt_rsv_chan_rag.reserved_channel_max0)           /* default cofig 54-127*/
            && (que_map.chan_id >= qmgt_rsv_chan_rag.reserved_channel_min0))
        {
            quemap_info.discard = TRUE;
            if (quemap_info.discard)
            {
                CMODEL_DEBUG_OUT_INFO("Reserved channel0 discard, file:%s line:%d function:%s\n",
                                       __FILE__, __LINE__, __FUNCTION__);

                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "Qmgt Buffer Retrieve Discard: Reserved Channel0 Discard.\n");
                return DRV_E_NONE;
            }
        }
    }

    if (qmgt_rsv_chan_rag.reserved_channel_valid1)
    {
        if ((que_map.chan_id <= qmgt_rsv_chan_rag.reserved_channel_max1)
            && (que_map.chan_id >= qmgt_rsv_chan_rag.reserved_channel_min1))
        {
            quemap_info.discard = TRUE;
            if (quemap_info.discard)
            {
                CMODEL_DEBUG_OUT_INFO("Reserved channel1 discard, file:%s line:%d function:%s\n",
                                       __FILE__, __LINE__, __FUNCTION__);

                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "Qmgt Buffer Retrieve Discard: Reserved Channel1 Discard.\n");
                return DRV_E_NONE;
            }
        }
    }

    quemap_info.from_fabric = FALSE;
    quemap_info.chan_id = que_map.chan_id;

    /* Generate corresponding output according to different message type */
    if (p_ms_dequeue->msg_dequeue.dest_select) /* DS_EXCEPTION */
    {
        DRV_IF_ERROR_RETURN(_cm_qmgt_buffer_retrieve_gen_excep_outpkt(p_ms_dequeue, p_qpkt,
                                                           p_out_pkt_list, &quemap_info));
    }
    else                                       /* LOCAL */
    {
        DRV_IF_ERROR_RETURN(_cm_qmgt_buffer_retrieve_gen_local_outpkt(p_ms_dequeue, p_qpkt,
                                                           p_out_pkt_list, &quemap_info));
    }
    return DRV_E_NONE;
}

/****************************************************************************
* Name:       cm_qmgt_buffer_retrieve_handle
* Purpose:    Provides generate queue ID per-enqueue message function.
* Parameters:
* Input:      p_qpkt -- queue management packet pointer
* Output:     p_out_pkt_list -- output packet list pointer
* Return:     DRV_E_NONE = success.
*             Other = ErrorCode, please refer to DRV_E_XXX.
* Note:       None.
****************************************************************************/
int32
cm_qmgt_buffer_retrieve_handle(queue_in_pkt_t *p_qpkt, list_head_t *p_out_pkt_list)
{

    queue_packet_info_t *p_pkt_info = (queue_packet_info_t *)p_qpkt->pkt_info;
    fwd_ms_dequeue_t *p_ms_dequeue = NULL;
    list_head_t *p_pos = NULL;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Buffer Retrieve Process");

    list_for_each(p_pos, &p_pkt_info->ms_dequeue_list) /* Get dequeue message */
    {
        p_ms_dequeue = list_entry(p_pos, fwd_ms_dequeue_t, head);

        if (!p_ms_dequeue)
        {
            break;
        }

        _cm_qmgr_buffer_retrieve_debug_dequeue_info(p_ms_dequeue);
        DRV_IF_ERROR_RETURN(_cm_qmgt_buffer_retrieve_gen_outpacket_list(p_ms_dequeue, p_qpkt, p_out_pkt_list));

    }

    return DRV_E_NONE;
}

