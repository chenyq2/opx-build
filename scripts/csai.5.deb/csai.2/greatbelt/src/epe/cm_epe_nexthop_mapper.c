/****************************************************************************
 * cm_epe_nexhop_mapper.c    Provides EPE next hop mapper function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-10-20.
 * Reason:       First Create.
 *
 * Revision:     V1.0.
 * Author:       JiaK.
 * Date:         2010-11-16.
 * Reason:       Sync spec Revision 5.0.0.
 *
 * Revision:     V4.2.1.
 * Author:       JiaK.
 * Date:         2011-06-30.
 * Reason:       Sync spec Revision 4.2.1.
 *
 * Revision:     V4.3.0
 * Author:       JiaK.
 * Date:         2011-07-11.
 * Reason:       Sync spec revision 4.3.0.
 *
 * Revision:     V4.5.1
 * Author:       JiaK.
 * Date:         2011-07-11.
 * Reason:       Sync spec revision 4.5.1.
 *
 * Revision:     V4.7.1
 * Author:       JiaK.
 * Date:         2011-07-28.
 * Reason:       Sync spec revision 4.7.1.
 *
 * Revision:     V4.28
 * Author:       JiaK.
 * Date:         2011-09-27.
 * Reason:       Sync spec revision 4.28.
 *
 * Revision:     V4.29.3
 * Author:       JiaK.
 * Date:         2011-10-10.
 * Reason:       Sync spec revision 4.29.3
 *
 * Revision:     V4.31.0
 * Author:       JiaK.
 * Date:         2011-10-22.
 * Reason:       sync spec to v4.31.0
 *
 * Revision:     V5.1.0
 * Author:       JiaK.
 * Date:         2011-12-9.
 * Reason:       sync spec to v5.1.0
 *
 * Revision:     V5.6.0
 * Author:       JiaK.
 * Date:         2012-01-7.
 * Reason:       sync spec to v5.6.0
 *
 * Revision:     V5.9.0
 * Author:       JiaK.
 * Date:         2012-01-19.
 * Reason:       sync spec to v5.9.0
 *
 * Revision:     V5.9.1
 * Author:       Wangcy.
 * Date:         2012-02-04.
 * Reason:       sync spec to v5.9.1
 *
 * Revision:     V5.11.0
 * Author:       Wangcy.
 * Date:         2012-03-01.
 * Reason:       sync spec to v5.11.0
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "ctcutil_rand.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
enum user_id_lookup_num_e
{
    USER_ID_LOOKUP1,
    USER_ID_LOOKUP2,
    USER_ID_LOOKUP_NUM,
};
typedef enum user_id_lookup_num_e user_id_lookup_num_t;

struct epe_per_lookup_s
{
    uint32  vlan_hash_type :5;
    lookup_result_t hash_lookup_result;
};
typedef struct epe_per_lookup_s epe_per_lookup_t;

/* epe userId lkp's input and output result structure*/
struct epe_user_id_info_s
{
    uint32  is_label       :1;
    uint32  hash_port      :14;

    uint32  svlan_id       :12;
    uint32  stag_cos       :3;
    uint32  stag_cfi       :1;

    uint32  cvlan_id       :12;
    uint32  ctag_cos       :3;
    uint32  ctag_cfi       :1;

    uint32  l3_edit_ptr    :18;
    uint32  l2_edit_ptr    :18;
    uint32  nexthop_output_svlan_id_valid :1;
    uint32  nexthop_output_cvlan_id_valid :1;

    uint32  nexthop_payload_operation :3;
    uint32  aps_group_id              :11;
    uint32  is_end                    :1;
    uint32  link_oam                  :1;
    uint32  qos_domain                :3;
    uint32  egress_filtering_en       :1;
    uint32  egress_filtering_disable  :1;
    uint32  bypass_all                :1;
    uint32  is_leaf                   :1;
    uint32  mtu_check_en              :1;
    uint32  source_port               :16;
    uint32  vlan_id_valid             :1;
    uint32  edit_bypass               :1;
    uint32  non_mirror_packet         :1;
    uint32  bcast_mac                 :1;
    uint32  mcast_mac                 :1;

    uint32 is_nexthop_8w              :1;
    uint32 replace_dscp               :1;
    uint32 nexthop_logic_port_check   :1;

    uint32 ptp_checksum_bypass        :1;
    uint32 tagged_mode                :1;

    ds_vlan_xlate_t ds_vlan_xlate;
    tcam_lkp_outputs_t tcam_lookup_result;
    epe_per_lookup_t per_lookup[USER_ID_LOOKUP_NUM];
};
typedef struct epe_user_id_info_s epe_user_id_info_t;

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
 /****************************************************************************
  * Name:      _cm_reclac_ip_checksum
  * Purpose:   recalculate ip checksum.
  * Parameters:
  * Input:     old_u16  --  old data
  *            new_u16 -- new data
  *            old_chksum -- old checksum
  * Return:    new checksum
  * Note:      none.
 ****************************************************************************/
 static uint16
 _cm_reclac_ip_checksum(uint16 old_u16, uint16 new_u16, uint16 old_chksum)
 {
     uint32 sum = 0;
     uint16 new_sum = 0;

     sum = (~old_chksum) & 0xFFFF;

     sum = sum + (~old_u16 & 0xFFFF);
     sum = (sum >> 16) + (sum & 0xFFFF);

     sum = sum + new_u16;
     new_sum = (sum >> 16) + (sum & 0xFFFF);
     return (~new_sum);
 }
 /****************************************************************************
 * Name:      _cm_epe_nexthop_mapper_get_dsnexthop
 * Purpose:   Retrieve dsnexthop and get the information from it.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_nexthop_mapper_get_dsnexthop(epe_in_pkt_t* ipkt, epe_user_id_info_t* p_epe_user_id_info)
{

    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    ds_next_hop8_w_t ds_next_hop8_w;
    epe_next_hop_ctl_t epe_next_hop_ctl;
    ds_aps_bridge_t ds_aps_bridge1;
    ds_aps_bridge_t ds_aps_bridge2;

    uint32 cmd = 0;
    uint8* p_ds_next_hop8_w = NULL;
    uint8 parser_offset = 0;
    uint8 aps_next_hop_en = FALSE;
    uint8 next_aps_bridge_en2 = FALSE;
    uint16 next_aps_group_id2 = 0;
    uint8 l2_edit_ptr_offset = 0;

    /* POP DS */
    sal_memset(&epe_next_hop_ctl, 0, sizeof(epe_next_hop_ctl_t));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_next_hop_ctl));

    parser_offset = pkt_info->parser_offset << 2;
    if (pkt_info->share_type != SHARE_TYPE_PTP)
    {
        parser_result->layer2_offset = parser_offset & 0x1F;
        parser_result->l2_s.layer3_offset += (parser_offset & 0x1F);
        parser_result->l3_s.layer4_offset += (parser_offset & 0x1F);
    }

    if ((pkt_info->rx_oam_type == OAM_ACH) && (pkt_info->gal_exist || pkt_info->entropy_label_exist))/* update for section OAM */
    {
        parser_result->layer3_type = L3_TYPE_MPLS;
    }

    p_epe_user_id_info->link_oam = ((pkt_info->rx_oam_type == OAM_ETHER) && pkt_info->link_or_section_oam);

    if (pkt_info->ingress_edit_en && (0 != (pkt_info->logic_src_port & 0x3FFF)))
    {
        /* For ingress edit, logic port check in ingress chip, egress chip use it for service ACL */
        pkt_info->logic_dest_port = pkt_info->logic_src_port;
        pkt_info->logic_src_port = 0;
    }

    pkt_info->dest_vlan_ptr = pkt_info->src_vlan_ptr;

    if (pkt_info->ingress_edit_en)
    {
        pkt_info->src_vlan_ptr = 0;
    }

    p_epe_user_id_info->ptp_checksum_bypass = pkt_info->bypass_all;

    /* Note: DsNextHop8W's index is 72bits per-unit */
    sal_memset(&ds_next_hop8_w, 0, sizeof(ds_next_hop8_w_t));

    if (!pkt_info->bypass_all)
    {
        if (pkt_info->next_hop_ext)
        {
            /* Get DsNextHopBits[159:0] */
            p_ds_next_hop8_w = pkt_info->DsNextHopBits;
            sal_memcpy(&ds_next_hop8_w, p_ds_next_hop8_w, sizeof(ds_next_hop8_w_t));
        }
        else
        {
            if (IS_BIT_SET(pkt_info->next_hop_ptr, 0))
            {
                /* Get DsNexHopBits[79:0] */
                p_ds_next_hop8_w = pkt_info->DsNextHopBits;
                sal_memcpy(&ds_next_hop8_w, p_ds_next_hop8_w + sizeof(ds_next_hop4_w_t), sizeof(ds_next_hop4_w_t));
            }
            else
            {
                /* Get DsNexHopBits[159:80] */
                p_ds_next_hop8_w = pkt_info->DsNextHopBits;
                sal_memcpy(&ds_next_hop8_w, p_ds_next_hop8_w, sizeof(ds_next_hop4_w_t));
            }
        }
    }
    else
    {
        sal_memset(&ds_next_hop8_w, 0, sizeof(ds_next_hop8_w_t));
    }

    if ((ds_next_hop8_w.is_met || !ds_next_hop8_w.is_nexthop
            || (pkt_info->next_hop_ext ^ ds_next_hop8_w.is_nexthop8_w))
        && !pkt_info->bypass_all)
    {
        pkt_info->discard = TRUE;
        pkt_info->discard_type = EPE_DISCARD_DS_NEXT_HOP_DATA_VIOLATE;

        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE nextHopMapper discardPacket!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }
    p_epe_user_id_info->is_nexthop_8w = ds_next_hop8_w.is_nexthop8_w;
    p_epe_user_id_info->replace_dscp = ds_next_hop8_w.replace_dscp;
    p_epe_user_id_info->source_port = pkt_info->source_port & 0x3FFF;
    p_epe_user_id_info->tagged_mode =  ds_next_hop8_w.tagged_mode;
    p_epe_user_id_info->nexthop_payload_operation = ds_next_hop8_w.payload_operation;

    if (epe_next_hop_ctl.stacking_en)
    {
        if (0x1F == ((pkt_info->source_port >> 9) & 0x1F))
        {
            p_epe_user_id_info->source_port &= 0xFE3F; /* source_port[8:6] = 0 */
        }
    }

    p_epe_user_id_info->is_end = (ds_next_hop8_w.is_met || !ds_next_hop8_w.is_nexthop)
                                 && !pkt_info->bypass_all;

    pkt_info->mcast = IS_BIT_SET(pkt_info->dest_map, 21);

    if (p_epe_user_id_info->is_end)
    {
        return DRV_E_NONE;
    }

    /* DS_NEXT_HOP */
    if ((((ds_next_hop8_w.dest_vlan_ptr == 0x1FFE) && pkt_info->rx_oam_type == OAM_NONE)
            || (ds_next_hop8_w.dest_vlan_ptr == 0x1FFD)) && !pkt_info->discard)
    {
        pkt_info->discard_type = EPE_DISCARD_DEST_VLAN_PTR_DISCARD;
        pkt_info->discard = TRUE;
        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE nextHopMapper discardPacket!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }

    pkt_info->payload_operation = ds_next_hop8_w.payload_operation;
    /* replaceCtagCos[0]: replaceCtagCos / mirrorTagAdd/macDa[14] */
    pkt_info->mirror_tag_add = ds_next_hop8_w.replace_ctag_cos;

    if ((OAM_NONE != pkt_info->rx_oam_type)
         && ((OAM_ETHER != pkt_info->rx_oam_type) || !epe_next_hop_ctl.ether_oam_use_payload_operation)
         && pkt_info->from_cpu_or_oam
         && epe_next_hop_ctl.oam_ignore_payload_operation)
    {
        pkt_info->payload_operation = CM_PLD_OP_NONE;         /* Down mep no payloadOp */
    }

    if (!pkt_info->discard)
    {
        pkt_info->vlan_xlate_mode = (pkt_info->payload_operation != CM_PLD_OP_ROUTE_COMPACT)
                                    && ds_next_hop8_w.vlan_xlate_mode;
        pkt_info->inner_svlan_tpid_index = ds_next_hop8_w.svlan_tpid;
        pkt_info->inner_svlan_tpid_en = ds_next_hop8_w.svlan_tpid_en;

        if (pkt_info->vlan_xlate_mode)
        {
            pkt_info->stag_cfi = ds_next_hop8_w.stag_cfi;
            pkt_info->copy_ctag_cos = ds_next_hop8_w.copy_ctag_cos;
            pkt_info->stag_cos = ds_next_hop8_w.stag_cos;

            pkt_info->tagged_mode = ds_next_hop8_w.tagged_mode;
            /* outputSvlanIdValid[0]: outputSvlanIdValid / tpidSwap / macDaSvlanEn */
            pkt_info->tpid_swap = ds_next_hop8_w.output_svlan_id_valid;
            /* outputCvlanIdValid[0]: outputCvlanIdValid / cosSwap / macDa[33] */
            pkt_info->cos_swap = ds_next_hop8_w.output_cvlan_id_valid;
            pkt_info->derive_stag_cos = ds_next_hop8_w.derive_stag_cos;
            /* stagCfi[0]: stagCfi / replaceStagCos / macDa[40] */
        }
        pkt_info->replace_ctag_cos = ds_next_hop8_w.replace_ctag_cos;
        pkt_info->replace_stag_cos = ds_next_hop8_w.stag_cfi;
        /* stagCos[2:0]: stagCos[2:0] / {copyDscp, svlanTagDisable, useTtlFromPacket} / macDa[39:37] */
        /* copyCtagCos[0]: copyCtagCos / cvlanTagDisable / macDa[36]*/
        pkt_info->svlan_tag_disable = (pkt_info->payload_operation != CM_PLD_OP_ROUTE_COMPACT)
                                      && ds_next_hop8_w.derive_stag_cos
                                      && IS_BIT_SET(ds_next_hop8_w.stag_cos, 1);      /* svlanTagDisable */
        pkt_info->cvlan_tag_disable = (pkt_info->payload_operation != CM_PLD_OP_ROUTE_COMPACT)
                                      && !ds_next_hop8_w.replace_ctag_cos
                                      && IS_BIT_SET(ds_next_hop8_w.copy_ctag_cos, 0); /* cvlanTagDisable */
        pkt_info->svlan_tagged = ds_next_hop8_w.svlan_tagged;

        if (CM_PLD_OP_ROUTE_COMPACT == pkt_info->payload_operation)
        {
            pkt_info->mac_da_mcast_mode = ds_next_hop8_w.output_svlan_id_valid; /* macDaMcastMode */
            pkt_info->route_no_l2_edit = TRUE;

            /* vlanXlateMode[0]: vlanXlateMode / macDa[47] */
            /* statsPtr[13:0]: statsPtr / {macDa[46:41], statsPtr[7:0]} */
            /* stagCfi[0]: stagcfi/macDa[40] */
            /* stagCos[2:0]:stagCos[2:0]/macDa[39:37] */
            /* copyCtagCos[0]:copyCtagCos/macDa[36] */
            /* svlanTagged[0]: SvlanTagged / macDa[35] */
            /* cvlanTagged[0]: CvlanTagged / macDa[34] */
            /* outputCvlanIdValid[0]:outputCvlanIdValid/macDa[33] */
            /* l2EditPtr0[17:0]: {l2EditPtr[14:12], l3EditPtr[14:0]} / {4'd0, outputSvlanId[11:0]} / macDa[32:15] */
            /* replaceCtagCos[0]:replaceCtagCos/macDa[14] */
            /* deriveStagCos[0]:deriveStagCos/macDa[13] */
            /* taggedMode[0]: taggedMode / macDa[12] */
            /* l2EditPtr1[11:0]: l2EditPtr[11:0] / outputCvlanId[11:0] / macDa[11:0] */
            if (epe_next_hop_ctl.mac_da_bit40_mode)
            {
                pkt_info->mac_47_to_32 = (ds_next_hop8_w.vlan_xlate_mode << 15)
                                         | (((ds_next_hop8_w.stats_ptr >> 8) & 0x3F) << 9)
                                         | (ds_next_hop8_w.stag_cos << 5)
                                         | (ds_next_hop8_w.copy_ctag_cos << 4)
                                         | (ds_next_hop8_w.l3_edit_ptr15_15 << 3)
                                         | (ds_next_hop8_w.l2_edit_ptr15 << 2)
                                         | (ds_next_hop8_w.output_cvlan_id_valid << 1)
                                         | ((ds_next_hop8_w.l3_edit_ptr14_0 >> 14) & 0x1);
                pkt_info->mac_31_to_0 = ((ds_next_hop8_w.l3_edit_ptr14_0 & 0x3FFF) << 18)
                                         | (ds_next_hop8_w.l2_edit_ptr14_12 << 15)
                                         | (ds_next_hop8_w.replace_ctag_cos << 14)
                                         | (ds_next_hop8_w.derive_stag_cos << 13)
                                         | (ds_next_hop8_w.tagged_mode << 12)
                                         | ds_next_hop8_w.l2_edit_ptr11_0;
                pkt_info->ttl_no_decrease = ds_next_hop8_w.stag_cfi;    /* ttlNoDecrease */
            }
            else
            {
                pkt_info->mac_47_to_32 = (ds_next_hop8_w.vlan_xlate_mode << 15)            /* macDa[47] */
                                         | (((ds_next_hop8_w.stats_ptr >> 8) & 0x3F) << 9) /* macDa[46:41] */
                                         | (ds_next_hop8_w.stag_cfi << 8)                  /* macDa[40] */
                                         | (ds_next_hop8_w.stag_cos << 5)                  /* macDa[39:37] */
                                         | (ds_next_hop8_w.copy_ctag_cos << 4)             /* macDa[36] */
                                         | (ds_next_hop8_w.l3_edit_ptr15_15 << 3)              /* macDa[35] */
                                         | (ds_next_hop8_w.l2_edit_ptr15 << 2)              /* macDa[34] */
                                         | (ds_next_hop8_w.output_cvlan_id_valid << 1)     /* macDa[33] */
                                         | ((ds_next_hop8_w.l3_edit_ptr14_0 >> 14) & 0x1);    /* macDa[32] */
                pkt_info->mac_31_to_0 = ((ds_next_hop8_w.l3_edit_ptr14_0 & 0x3FFF) << 18)    /* macDa[31:18] */
                                        | (ds_next_hop8_w.l2_edit_ptr14_12 << 15)          /* macDa[17:15] */
                                        | (ds_next_hop8_w.replace_ctag_cos << 14)          /* macDa[14] */
                                        | (ds_next_hop8_w.derive_stag_cos << 13)           /* macDa[13] */
                                        | (ds_next_hop8_w.tagged_mode << 12)               /* macDa[12] */
                                        | ds_next_hop8_w.l2_edit_ptr11_0;                  /* macDa[11:0] */
                pkt_info->ttl_no_decrease = 0;
            }
        }
        else if (ds_next_hop8_w.radio_mac_en)
        {
            /* outputSvlanIdExt[11:0]: outputSvlanIdExt / {3'd0, radioMac[47:39]} */
            /* outputCvlanIdExt[11:0]: outputCvlanIdExt / radioMac[38:27] / tunnelMtuSize[13:2] */
            /* logicDestPort[12:0]: logicDestPort[12:0] / radioMac[12:0] */
            pkt_info->mac_47_to_32 = ((ds_next_hop8_w.output_svlan_id_ext & 0x1FF) << 7)/* radioMac[47:39] */
                                     | (ds_next_hop8_w.output_cvlan_id_ext >> 5);       /* radioMac[39:32] */
            pkt_info->mac_31_to_0 = ((ds_next_hop8_w.output_cvlan_id_ext & 0x1F) << 27) /* radioMac[31:27] */
                                    | (ds_next_hop8_w.radio_mac << 14)                  /* radioMac[26:14] */
                                    | ds_next_hop8_w.logic_dest_port;                   /* radioMac[13:0] */
        }

        pkt_info->use_ttl_from_packet = (pkt_info->payload_operation != CM_PLD_OP_ROUTE_COMPACT)
                                        && IS_BIT_SET(ds_next_hop8_w.stag_cos, 0)/* useTtlFrompacket */
                                        && ds_next_hop8_w.derive_stag_cos;

        pkt_info->copy_dscp = (pkt_info->payload_operation != CM_PLD_OP_ROUTE_COMPACT)
                              && IS_BIT_SET(ds_next_hop8_w.stag_cos, 2);/* copyDscp */

        p_epe_user_id_info->nexthop_logic_port_check = ds_next_hop8_w.logic_port_check; /* cmodel:uesed in DS_DEST_PORT */

        if (ds_next_hop8_w.logic_port_check)
        {
            pkt_info->logic_port_check = TRUE;
            pkt_info->logic_dest_port = ds_next_hop8_w.logic_dest_port;
        }

        if (ds_next_hop8_w.logic_port_check && ds_next_hop8_w.use_logic_port_no_check)
        {
            pkt_info->logic_port_check = FALSE;
        }

        if (ds_next_hop8_w.tunnel_mtu_check_en)
        {
            pkt_info->tunnel_mtu_check = TRUE;
            /* outputCvlanIdExt[11:0]: outputCvlanIdExt[11:0] / radioMac[38:27] / tunnelMtuSize[13:2] */
            pkt_info->tunnel_mtu_size = (ds_next_hop8_w.output_cvlan_id_ext << 2)
                                    | ds_next_hop8_w.tunnel_mtu_size1_0;
        }

        if (pkt_info->next_hop_ext)
        {
            /* l2EditPtr0[17:0]: {l2EditPtr[14:12], l3EditPtr[14:0]} / {4'd0, outputSvlanId[11:0]} / macDa[32:15] */
            /* l2EditPtr1[11:0]: l2EditPtr[11:0] / outputCvlanId[11:0] / macDa[11:0] */
            /* l2EditPtr2[4:0]:  l2EditPtr[19:15] */
            /* l3EditPtr0[2:0]:  l3EditPtr[19:17] */
            /* l3EditPtr1[1:0]:  l3EditPtr[16:15] */
            p_epe_user_id_info->l3_edit_ptr
                      = (ds_next_hop8_w.l3_edit_ptr17_16 << 16)           /* l3EditPtr[17:16] */
                        | (ds_next_hop8_w.l3_edit_ptr15_15 << 15)            /* l3EditPtr[15] */
                        | (ds_next_hop8_w.l3_edit_ptr14_0 & 0x7FFF);         /* l3EditPtr[14:0] */

            p_epe_user_id_info->l2_edit_ptr
                      = ((ds_next_hop8_w.l2_edit_ptr17_16 << 16)    /* l2EditPtr[17:16} */
                         | (ds_next_hop8_w.l2_edit_ptr15 << 15)     /* l2EditPtr[15] */
                         | (ds_next_hop8_w.l2_edit_ptr14_12 << 12)  /* l2EditPtr[14:12] */
                         | ds_next_hop8_w.l2_edit_ptr11_0);         /* l2EditPtr[11:0] */
            aps_next_hop_en = ((p_epe_user_id_info->l2_edit_ptr >> 11) == 0x7F);
        }
        else
        {
            p_epe_user_id_info->l3_edit_ptr
                      = (ds_next_hop8_w.l3_edit_ptr15_15 << 15)      /* l3EditPtr[15] */
                      | (ds_next_hop8_w.l3_edit_ptr14_0 & 0x7FFF);   /* l3EditPtr[14:0] */

            p_epe_user_id_info->l2_edit_ptr
                      = ((ds_next_hop8_w.l2_edit_ptr15 << 15)
                          |(ds_next_hop8_w.l2_edit_ptr14_12 << 12)/* l2EditPtr[14:12] */
                          | ds_next_hop8_w.l2_edit_ptr11_0);       /* l2EditPtr[11:0] */
            aps_next_hop_en = (((p_epe_user_id_info->l2_edit_ptr >> 11) & 0x1F) == 0x1F);
        }
        p_epe_user_id_info->aps_group_id = p_epe_user_id_info->l2_edit_ptr & 0x7FF;

        if (ds_next_hop8_w.dest_vlan_ptr != 0)
        {
            pkt_info->dest_vlan_ptr = ds_next_hop8_w.dest_vlan_ptr;
        }

        p_epe_user_id_info->nexthop_output_svlan_id_valid = ds_next_hop8_w.output_svlan_id_valid;
        p_epe_user_id_info->nexthop_output_cvlan_id_valid = ds_next_hop8_w.output_cvlan_id_valid;

        if (!p_epe_user_id_info->nexthop_output_svlan_id_valid
            && (CM_PLD_OP_ROUTE_COMPACT != pkt_info->payload_operation))
        {
            if (aps_next_hop_en)
            {
                sal_memset(&ds_aps_bridge1, 0, sizeof(ds_aps_bridge_t));
                cmd = DRV_IOR(DsApsBridge_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, p_epe_user_id_info->aps_group_id, cmd, &ds_aps_bridge1));

                p_epe_user_id_info->l2_edit_ptr = ds_aps_bridge1.protecting_en
                                    ? ds_aps_bridge1.protecting_l2_edit_ptr
                                    : ds_aps_bridge1.working_l2_edit_ptr;

                if (ds_aps_bridge1.protecting_en)
                {
                    if (ds_aps_bridge1.protecting_dest_vlan_ptr != 0)
                    {
                        pkt_info->dest_vlan_ptr = ds_aps_bridge1.protecting_dest_vlan_ptr;
                    }
                }
                else
                {
                    if (ds_aps_bridge1.working_dest_vlan_ptr != 0)
                    {
                        pkt_info->dest_vlan_ptr = ds_aps_bridge1.working_dest_vlan_ptr;
                    }
                }

                if (ds_aps_bridge1.protecting_en && ds_aps_bridge1.protecting_next_aps_bridge_en)
                {
                    next_aps_bridge_en2 = TRUE;
                    next_aps_group_id2 = ds_aps_bridge1.protecting_dest_map & 0xFFFF;
                }
                else if (!ds_aps_bridge1.protecting_en && ds_aps_bridge1.working_next_aps_bridge_en)
                {
                    next_aps_bridge_en2 = TRUE;
                    next_aps_group_id2 = ds_aps_bridge1.working_dest_map & 0xFFFF;
                }
            }
            /* PacketInfo.aps_protectingEn2 or DS.aps_bridge_en? */
            if (aps_next_hop_en && next_aps_bridge_en2)
            {
                sal_memset(&ds_aps_bridge2, 0, sizeof(ds_aps_bridge_t));
                cmd = DRV_IOR(DsApsBridge_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id,
                        next_aps_group_id2, cmd, &ds_aps_bridge2));
                l2_edit_ptr_offset = ds_aps_bridge2.protecting_en ?
                            (ds_aps_bridge2.different_l2_edit_ptr_en ? (1 << ds_aps_bridge2.l2_edit_ptr_shift_en) : 0) : 0;
                p_epe_user_id_info->l2_edit_ptr += l2_edit_ptr_offset;

                if (ds_aps_bridge2.protecting_en)
                {
                    if (ds_aps_bridge2.protecting_dest_vlan_ptr != 0)
                    {
                        pkt_info->dest_vlan_ptr = ds_aps_bridge2.protecting_dest_vlan_ptr;
                    }
                }
                else
                {
                    if (ds_aps_bridge2.working_dest_vlan_ptr != 0)
                    {
                        pkt_info->dest_vlan_ptr = ds_aps_bridge2.working_dest_vlan_ptr;
                    }
                }

            }

        }

        if (ds_next_hop8_w.output_svlan_id_valid_ext)
        {
            pkt_info->output_svlan_id_valid = TRUE;
            pkt_info->output_svlan_id = ds_next_hop8_w.output_svlan_id_ext;
        }
        else if (ds_next_hop8_w.output_svlan_id_valid)
        {
            pkt_info->output_svlan_id_valid = TRUE;
            pkt_info->output_svlan_id = ds_next_hop8_w.l3_edit_ptr14_0 & 0xFFF;/* l3EditPtr[11:0] */
        }
#if 0
        else
        {
            pkt_info->output_svlan_id_valid = pkt_info->src_svlan_id_valid;
            pkt_info->output_svlan_id = parser_result->l2_s.svlan_id;
        }
#endif

        if (ds_next_hop8_w.output_cvlan_id_valid_ext)
        {
            pkt_info->output_cvlan_id_valid = TRUE;
            pkt_info->output_cvlan_id = ds_next_hop8_w.output_cvlan_id_ext;
        }
        else if (ds_next_hop8_w.output_cvlan_id_valid)
        {
            pkt_info->output_cvlan_id_valid = TRUE;
            pkt_info->output_cvlan_id = ds_next_hop8_w.l2_edit_ptr11_0;  /*used as outputCvlanId */
        }
#if 0
        else
        {
            pkt_info->output_cvlan_id_valid = pkt_info->src_cvlan_id_valid;
            pkt_info->output_cvlan_id = parser_result->l2_s.cvlan_id;
        }
#endif
    }

    /* statsPtr[13:0]: statsPtr[13:0] / {macDa[46:41], statsPtr[7:0]} */
    if (CM_PLD_OP_ROUTE_COMPACT != pkt_info->payload_operation)
    {
        /* statsPtr has 14 bits */
        if ((0 != ds_next_hop8_w.stats_ptr) && !pkt_info->flow_stats2_valid)
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = ds_next_hop8_w.stats_ptr;
        }
    }
    else
    {
        /* statsPtr has 8 bits */
        if ((0 != (ds_next_hop8_w.stats_ptr & 0xFF)) && !pkt_info->flow_stats2_valid)
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = ds_next_hop8_w.stats_ptr & 0xFF;
        }
    }

    p_epe_user_id_info->is_leaf = ds_next_hop8_w.is_leaf;             /* use for DS_DEST_PORT */
    p_epe_user_id_info->mtu_check_en = ds_next_hop8_w.mtu_check_en;   /* use for DS_DEST_INTERFACE */

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_nexthop_mapper_get_dest_port
 * Purpose:   Retrieve dsdestport and get port information from it.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_nexthop_mapper_get_dest_port(epe_in_pkt_t *ipkt, epe_user_id_info_t* p_epe_user_id_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    ds_dest_port_t ds_dest_port;
    ds_dest_channel_t ds_dest_channel;
    epe_next_hop_ctl_t epe_next_hop_ctl;

    uint32 random = 0;
    uint32 cmd = 0;

    sal_memset(&epe_next_hop_ctl, 0, sizeof(epe_next_hop_ctl));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_next_hop_ctl));

    /* RETRIEVE_DS_DEST_PORT */
    if (pkt_info->discard && (CM_PLD_OP_MIRROR == pkt_info->payload_operation)
       && !epe_next_hop_ctl.mirror_obey_discard)
    {
        pkt_info->discard = FALSE;
    }
    else if (pkt_info->discard)
    {
        pkt_info->payload_operation = CM_PLD_OP_NONE;
    }

    p_epe_user_id_info->bypass_all = pkt_info->bypass_all || pkt_info->ds_nexthop_dot_bypass_all || pkt_info->discard
                                        || pkt_info->ingress_edit_nexthop_bypass_all
                                        || ((CM_PLD_OP_MIRROR == pkt_info->payload_operation) && p_epe_user_id_info->tagged_mode);
    p_epe_user_id_info->edit_bypass = pkt_info->bypass_all;

    sal_memset(&ds_dest_port, 0, sizeof(ds_dest_port_t));
    cmd = DRV_IOR(DsDestPort_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->local_phy_port & 0x7F, cmd, &ds_dest_port));

    /* DS_DEST_PORT */
    pkt_info->l2_span_id = ds_dest_port.l2_span_id;
    pkt_info->l2_span_en = ds_dest_port.l2_span_en;
    pkt_info->global_dest_port = ds_dest_port.global_dest_port;
    pkt_info->discard_non_8023_oam = ds_dest_port.discard_non8023_o_a_m;
    pkt_info->random_log_en = ds_dest_port.random_log_en;
    pkt_info->link_lm_type = ds_dest_port.link_lm_type;
    pkt_info->link_lm_cos = ds_dest_port.link_lm_cos;
    pkt_info->link_lm_cos_type = ds_dest_port.link_lm_cos_type;
    pkt_info->link_lm_index_base = ds_dest_port.link_lm_index_base;
    pkt_info->mpls_section_lm_en = ds_dest_port.mpls_section_lm_en;
    pkt_info->ether_lm_valid = ds_dest_port.ether_lm_valid;
    pkt_info->default_pcp = ds_dest_port.default_pcp;

    pkt_info->dest_mux_port_type = ds_dest_port.mux_port_type;

    if ((pkt_info->rx_oam_type != OAM_ACH) && (!pkt_info->from_cpu_or_oam))
    {
        if (parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->source_cos = parser_result->l2_s.stag_cos;
            pkt_info->source_cfi = parser_result->l2_s.stag_cfi;
        }
        else if (parser_result->l2_s.cvlan_id_valid)
        {
            pkt_info->source_cos = parser_result->l2_s.ctag_cos;
            pkt_info->source_cfi = parser_result->l2_s.ctag_cfi;
        }
        else
        {
            pkt_info->source_cos = ds_dest_port.default_pcp;
            pkt_info->source_cfi = 0;
        }
    }

    ctcutil_rand(0, 0x7FFF, &random);
    if (ds_dest_port.random_log_en && (random < ds_dest_port.random_threshold))
    {
        pkt_info->port_log_en = TRUE;
    }
    else
    {
        pkt_info->port_log_en = FALSE;
    }

    if ((pkt_info->payload_operation != CM_PLD_OP_MIRROR) && ds_dest_port.dest_discard
        && !pkt_info->discard && !p_epe_user_id_info->link_oam)
    {
        pkt_info->discard_type = EPE_DISCARD_DEST_PHY_PORT_DEST_ID_DISCARD;
        pkt_info->discard = TRUE;
        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE DsDestPort destDiscard is set, portID = %d!\n", pkt_info->local_phy_port);
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }

    if (ds_dest_port.svlan_tpid_valid)
    {
        pkt_info->svlan_tpid_index = ds_dest_port.svlan_tpid_index;
    }

    sal_memset(&ds_dest_channel, 0, sizeof(ds_dest_channel_t));
    cmd = DRV_IOR(DsDestChannel_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id & 0x3F, cmd, &ds_dest_channel));

    pkt_info->use_logic_port = ds_dest_channel.use_logic_port;

    if (!p_epe_user_id_info->bypass_all)    /* Discard ??? */
    {
        pkt_info->untag_default_vlan_id = ds_dest_port.untag_default_vlan_id;
        pkt_info->port_policer_valid = ds_dest_port.port_policer_valid;
        pkt_info->l2_acl_en0 = ds_dest_port.l2_acl_en0;
        pkt_info->l2_acl_en1 = ds_dest_port.l2_acl_en1;
        pkt_info->l2_acl_en2 = ds_dest_port.l2_acl_en2;
        pkt_info->l2_acl_en3 = ds_dest_port.l2_acl_en3;
        pkt_info->untag_default_svlan = ds_dest_port.untag_default_svlan;
        pkt_info->bridge_en = ds_dest_port.bridge_en;
        pkt_info->dot1_q_en = ds_dest_port.dot1_q_en;
        pkt_info->default_vlan_id = ds_dest_port.default_vlan_id;
        pkt_info->ipg_index = ds_dest_port.ipg_index;
        pkt_info->mcast_flooding_disable = ds_dest_port.mcast_flooding_disable;
        pkt_info->port_mac_sa = ds_dest_port.port_mac_sa;
        pkt_info->l2_acl_label = ds_dest_port.l2_acl_label;
        pkt_info->cvlan_space = ds_dest_port.cvlan_space;
        pkt_info->fcoe_oui_index = ds_dest_port.fcoe_oui_index;
        pkt_info->ctag_dei_en = ds_dest_port.ctag_dei_en;
        pkt_info->port_mac_sa_type = ds_dest_port.port_mac_sa_type;
        pkt_info->priority_tag_en = ds_dest_port.priority_tag_en;
        pkt_info->force_ipv6_key = ds_dest_port.force_ipv6_key;
        pkt_info->ether_oam_edge_port = ds_dest_port.ether_oam_edge_port;
        pkt_info->stag_operation_disable = ds_dest_port.stag_operation_disable;
        pkt_info->ctag_operation_disable = ds_dest_port.ctag_operation_disable;
        pkt_info->mpls_key_use_label = ds_dest_port.mpls_key_use_label;
        pkt_info->acl_port_num = ds_dest_port.acl_port_num;
        pkt_info->mac_key_use_label = ds_dest_port.mac_key_use_label;
        pkt_info->ipv4_key_use_label = ds_dest_port.ipv4_key_use_label;
        pkt_info->ipv6_key_use_label = ds_dest_port.ipv6_key_use_label;
        pkt_info->l2_ipv6_acl_en0 = ds_dest_port.l2_ipv6_acl_en0;
        pkt_info->l2_ipv6_acl_en1 = ds_dest_port.l2_ipv6_acl_en1;
        pkt_info->force_ipv4_to_mackey = ds_dest_port.force_ipv4_to_mac_key;
        pkt_info->force_ipv6_to_mackey = ds_dest_port.force_ipv6_to_mac_key;
        pkt_info->service_policer_valid = ds_dest_port.service_policer_valid;
        pkt_info->service_acl_qos_en = ds_dest_port.service_acl_qos_en;
        pkt_info->ucast_flooding_disable = ds_dest_port.ucast_flooding_disable;
        pkt_info->known_mcast_flooding_disable = ds_dest_port.known_mcast_flooding_disable;
        pkt_info->bcast_flooding_disable = ds_dest_port.bcast_flooding_disable;
        pkt_info->flooding_discard_type = ds_dest_port.flooding_discard_type;
        pkt_info->port_loopback_index = ds_dest_port.port_loopback_index;
        pkt_info->evb_default_local_phy_port_valid = (pkt_info->local_phy_port == ds_dest_port.evb_local_phy_port);
        pkt_info->evb_default_logic_port_valid = (pkt_info->logic_dest_port == ds_dest_port.evb_logic_dest_port);

        pkt_info->replace_stag_cos = pkt_info->replace_stag_cos || ds_dest_port.replace_stag_cos;
        pkt_info->replace_ctag_cos = pkt_info->replace_ctag_cos || ds_dest_port.replace_ctag_cos;
        p_epe_user_id_info->qos_domain = ds_dest_port.qos_domain;
        p_epe_user_id_info->egress_filtering_en = ds_dest_port.egress_filtering_en;
        p_epe_user_id_info->egress_filtering_disable = ds_dest_port.egress_filtering_disable;
        pkt_info->pbb_dest_port_type = ds_dest_port.pbb_port_type;  /* PBB */
        pkt_info->stp_check_en = ds_dest_port.stp_check_en && (!pkt_info->from_cpu_or_oam || pkt_info->is_up);
        pkt_info->routed_port = ds_dest_port.routed_port;
        pkt_info->is_leaf = p_epe_user_id_info->is_leaf || ds_dest_port.is_leaf;

        if (!p_epe_user_id_info->nexthop_logic_port_check && !pkt_info->packet_header_en)
        {
            /* first get DsDestPort,then get DsNextHop,logicPort/physicalPort,learning ??? */
            pkt_info->logic_port_check = ds_dest_port.logic_port_check_en;
            pkt_info->logic_dest_port = ds_dest_port.logic_dest_port;
        }
    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_nexthop_mapper_vlan_hash_type
 * Purpose:   Handle EPE nexthop mapper perform vlan hash type select.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_nexthop_mapper_vlan_hash_type(epe_in_pkt_t *ipkt, epe_user_id_info_t *p_epe_user_id_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    ds_egress_vlan_range_profile_t ds_vlan_range_profile;
    ds_dest_port_t ds_dest_port;
    epe_next_hop_ctl_t epe_next_hop_ctl;

    uint8 vlan_range_valid = FALSE;
    uint16 vlan_range_check_id = 0;
    uint16 vlan_range_max = 0;
    uint32 cmd = 0;

    sal_memset(&ds_dest_port, 0, sizeof(ds_dest_port_t));
    cmd = DRV_IOR(DsDestPort_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->local_phy_port & 0xFF, cmd, &ds_dest_port));

    sal_memset(&epe_next_hop_ctl, 0, sizeof(epe_next_hop_ctl_t));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_next_hop_ctl));

    /* EGRESS_VLAN_HASH_TYPE */

    /* Egress UserId, for egress VLAN tag operation */

    /*===========bug 4690 ECO begin=================*/
    /*if (0 != ds_dest_port.vlan_hash1_type)*/
    if ((0 != ds_dest_port.vlan_hash1_type) && (p_epe_user_id_info->nexthop_payload_operation != CM_PLD_OP_MIRROR))
    /*===========bug 4690 ECO end=================*/
    {
        p_epe_user_id_info->per_lookup[USER_ID_LOOKUP1].vlan_hash_type = ds_dest_port.vlan_hash1_type;
    }
    else
    {
        p_epe_user_id_info->per_lookup[USER_ID_LOOKUP1].vlan_hash_type = USERID_KEY_TYPE_DISABLE;
    }

    /*===========bug 4690 ECO begin=================*/
    /*if (0 != ds_dest_port.vlan_hash2_type)*/
    if ((0 != ds_dest_port.vlan_hash2_type) && (p_epe_user_id_info->nexthop_payload_operation != CM_PLD_OP_MIRROR))
    /*===========bug 4690 ECO end=================*/
    {
        p_epe_user_id_info->per_lookup[USER_ID_LOOKUP2].vlan_hash_type = ds_dest_port.vlan_hash2_type;
    }
    else
    {
        p_epe_user_id_info->per_lookup[USER_ID_LOOKUP2].vlan_hash_type = USERID_KEY_TYPE_DISABLE;
    }

    if (ds_dest_port.vlan_hash_use_logic_port)
    {
        p_epe_user_id_info->hash_port = pkt_info->logic_dest_port;
    }
    else if (ds_dest_port.vlan_hash_use_label)
    {
        p_epe_user_id_info->hash_port = ds_dest_port.vlan_hash_label;
    }
    else
    {
        p_epe_user_id_info->hash_port = ds_dest_port.global_dest_port;
    }

    p_epe_user_id_info->is_label = ds_dest_port.vlan_hash_use_label;
    p_epe_user_id_info->svlan_id = parser_result->l2_s.svlan_id;
    p_epe_user_id_info->cvlan_id = parser_result->l2_s.cvlan_id;
    p_epe_user_id_info->stag_cos = parser_result->l2_s.stag_cos;
    p_epe_user_id_info->ctag_cos = parser_result->l2_s.ctag_cos;
    p_epe_user_id_info->stag_cfi = parser_result->l2_s.stag_cfi;
    p_epe_user_id_info->ctag_cfi = parser_result->l2_s.ctag_cfi;

    /* EGRESS_VLAN_RANGE */
    if (ds_dest_port.vlan_range_profile_en
        && (!parser_result->parser_length_error || !epe_next_hop_ctl.parser_error_ignore))
    {
        if (parser_result->l2_s.svlan_id_valid && ds_dest_port.vlan_range_type)
        {
            vlan_range_check_id = p_epe_user_id_info->svlan_id;
        }
        else if (parser_result->l2_s.cvlan_id_valid && !ds_dest_port.vlan_range_type)
        {
            vlan_range_check_id = p_epe_user_id_info->cvlan_id;
        }
        else
        {
            vlan_range_check_id = ds_dest_port.default_vlan_id;
        }

        /* DsVlanEgressRangeProfile is not share with IPE */
        sal_memset(&ds_vlan_range_profile, 0, sizeof(ds_egress_vlan_range_profile_t));
        cmd = DRV_IOR(DsEgressVlanRangeProfile_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ds_dest_port.vlan_range_profile,
                                          cmd, &ds_vlan_range_profile));

        if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max0)
           && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min0)
           && (ds_vlan_range_profile.vlan_max0 != ds_vlan_range_profile.vlan_min0))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max0;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max1)
                && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min1)
                && (ds_vlan_range_profile.vlan_max1 != ds_vlan_range_profile.vlan_min1))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max1;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max2)
                && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min2)
                && (ds_vlan_range_profile.vlan_max2 != ds_vlan_range_profile.vlan_min2))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max2;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max3)
                && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min3)
                && (ds_vlan_range_profile.vlan_max3 != ds_vlan_range_profile.vlan_min3))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max3;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max4)
                && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min4)
                && (ds_vlan_range_profile.vlan_max4 != ds_vlan_range_profile.vlan_min4))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max4;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max5)
                && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min5)
                && (ds_vlan_range_profile.vlan_max5 != ds_vlan_range_profile.vlan_min5))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max5;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max6)
                && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min6)
                && (ds_vlan_range_profile.vlan_max6 != ds_vlan_range_profile.vlan_min6))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max6;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max7)
                && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min7)
                && (ds_vlan_range_profile.vlan_max7 != ds_vlan_range_profile.vlan_min7))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max7;
            vlan_range_valid = TRUE;
        }
        else
        {
            vlan_range_max = 0;
            vlan_range_valid = FALSE;
        }

        if (vlan_range_valid && ds_dest_port.vlan_range_type)
        {
            p_epe_user_id_info->svlan_id = vlan_range_max & 0xFFF;
        }
        else if (vlan_range_valid && !ds_dest_port.vlan_range_type)
        {
            p_epe_user_id_info->cvlan_id = vlan_range_max & 0xFFF;
        }

    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_nexthop_mapper_vlan_hash_lookup
 * Purpose:   Handle EPE nexthop mapper perform vlan hash lookup.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_nexthop_mapper_vlan_hash_lookup(epe_in_pkt_t *ipkt, epe_user_id_info_t *p_epe_user_id_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    userid_key_t userid_key;
    epe_next_hop_ctl_t epe_next_hop_ctl;
    userid_lookup_extra_info_t userid_lookup_extra_info;

    lookup_info_t userid_lookup_request;
    lookup_result_t *p_userid_lookup_result = NULL;

    uint8 vlan_hash_key_type = 0;
    uint32 cmd = 0;
    uint8 hash_index = 0;

    sal_memset(&userid_lookup_extra_info, 0, sizeof(userid_lookup_extra_info));
    userid_lookup_extra_info.direction = USERID_DIRECTION_OTHER;
    /* Use for getting the default AD */
    userid_lookup_extra_info.local_phy_port = pkt_info->local_phy_port;

    /* EGRESS_VLAN_HASH_LOOKUP */
    sal_memset(&epe_next_hop_ctl, 0, sizeof(epe_next_hop_ctl_t));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_next_hop_ctl));

    sal_memset(&userid_lookup_request, 0, sizeof(lookup_info_t));

    userid_lookup_request.extra = &userid_lookup_extra_info;

    for (hash_index = 0; hash_index < USER_ID_LOOKUP_NUM; hash_index ++)
    {
        p_userid_lookup_result = &p_epe_user_id_info->per_lookup[hash_index].hash_lookup_result;

        if (USERID_KEY_TYPE_DISABLE != p_epe_user_id_info->per_lookup[hash_index].vlan_hash_type
            && (!parser_result->parser_length_error
                || !epe_next_hop_ctl.parser_error_ignore))
        {
            vlan_hash_key_type = p_epe_user_id_info->per_lookup[hash_index].vlan_hash_type;
            userid_lookup_request.hash_type = vlan_hash_key_type;
            userid_lookup_request.hash_module = HASH_MODULE_USERID;
            userid_lookup_request.chip_id = ipkt->chip_id;

            sal_memset(&userid_key, 0, sizeof(userid_key));

            switch (vlan_hash_key_type)
            {
                case USERID_KEY_TYPE_TWO_VLAN:
                    userid_key.xport.global.src = p_epe_user_id_info->hash_port;
                    userid_key.key.two_vlan.is_label = p_epe_user_id_info->is_label;
                    userid_key.key.two_vlan.svlan_id = p_epe_user_id_info->svlan_id;
                    userid_key.key.two_vlan.cvlan_id = p_epe_user_id_info->cvlan_id;
                    break;
                case USERID_KEY_TYPE_SVLAN:
                    userid_key.xport.global.src = p_epe_user_id_info->hash_port;
                    userid_key.key.svlan.is_label = p_epe_user_id_info->is_label;
                    userid_key.key.svlan.svlan_id = p_epe_user_id_info->svlan_id;
                    break;
                case USERID_KEY_TYPE_CVLAN:
                    userid_key.xport.global.src = p_epe_user_id_info->hash_port;
                    userid_key.key.cvlan.is_label = p_epe_user_id_info->is_label;
                    userid_key.key.cvlan.cvlan_id = p_epe_user_id_info->cvlan_id;
                    break;
                case USERID_KEY_TYPE_SVLAN_COS:
                    userid_key.xport.global.src = p_epe_user_id_info->hash_port;
                    userid_key.key.svlan_cos.is_label = p_epe_user_id_info->is_label;
                    userid_key.key.svlan_cos.svlan_id = p_epe_user_id_info->svlan_id;
                    userid_key.key.svlan_cos.stag_cos = p_epe_user_id_info->stag_cos;
                    break;
                case USERID_KEY_TYPE_CVLAN_COS:
                    userid_key.xport.global.src = p_epe_user_id_info->hash_port;
                    userid_key.key.cvlan_cos.is_label = p_epe_user_id_info->is_label;
                    userid_key.key.cvlan_cos.cvlan_id = p_epe_user_id_info->cvlan_id;
                    userid_key.key.cvlan_cos.ctag_cos = p_epe_user_id_info->ctag_cos;
                    break;
                case USERID_KEY_TYPE_PORT:
                    userid_key.xport.global.src = p_epe_user_id_info->hash_port;
                    userid_key.key.port.is_label = p_epe_user_id_info->is_label;
                    break;
                case USERID_KEY_TYPE_PORT_IPV4_SA: /* port cross */
                    userid_key.xport.global.dest = p_epe_user_id_info->hash_port;
                    userid_key.key.port_ipv4_sa.is_label = p_epe_user_id_info->is_label;
                    userid_key.xport.global.src = p_epe_user_id_info->source_port;
                    break;
                case USERID_KEY_TYPE_IPV4_SA: /* port vlan cross */
                    userid_key.xport.global.dest = p_epe_user_id_info->hash_port;
                    userid_key.key.ipv4_sa.is_label = p_epe_user_id_info->is_label;
                    userid_key.xport.global.src = p_epe_user_id_info->source_port;
                    userid_key.key.ipv4_sa.vlan_id = parser_result->l2_s.svlan_id_valid ?
                                                p_epe_user_id_info->svlan_id : p_epe_user_id_info->cvlan_id;
                    break;
                case USERID_KEY_TYPE_PBB:
                    userid_key.xport.global.src = p_epe_user_id_info->hash_port;
                    userid_key.key.pbb.is_label = p_epe_user_id_info->is_label;
                    userid_key.key.pbb.is_id= parser_result->l3_s.ip_da.cmac.itag_tci.share.isid;
                    break;
                default:
                    vlan_hash_key_type = USERID_KEY_TYPE_DISABLE; /* no hash lookup performed */
                    break;
            }

            if (vlan_hash_key_type != USERID_KEY_TYPE_DISABLE)
            {
                DRV_IF_ERROR_RETURN(cm_com_userid_hash_lookup_request(ipkt->chip_id, pkt_info->local_phy_port,
                                &userid_key, vlan_hash_key_type, USERID_DIRECTION_OTHER, p_userid_lookup_result));
            }
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_nexthop_mapper_vlan_lookup_result
 * Purpose:   Retrieve vlan lookup result info.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_nexthop_mapper_vlan_lookup_result(epe_in_pkt_t* ipkt, epe_user_id_info_t *p_epe_user_id_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_next_hop_ctl_t epe_next_hop_ctl;
    userid_lookup_extra_result_t* p_userid_lookup_extra_result1 = NULL;
    userid_lookup_extra_result_t* p_userid_lookup_extra_result2 = NULL;

    uint8 user_id_result_valid = FALSE;
    uint8 vlan_hash1_result_valid = FALSE;
    uint8 hash1_default_entry_valid = FALSE;
    uint8 vlan_hash2_result_valid = FALSE;
    uint8 hash2_default_entry_valid = FALSE;
    uint32 cmd = 0;

    sal_memset(&p_epe_user_id_info->ds_vlan_xlate, 0, sizeof(ds_vlan_xlate_t));

    sal_memset(&epe_next_hop_ctl, 0, sizeof(epe_next_hop_ctl_t));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_next_hop_ctl));

    p_userid_lookup_extra_result1 = (userid_lookup_extra_result_t*)p_epe_user_id_info->per_lookup[USER_ID_LOOKUP1].hash_lookup_result.extra;
    p_userid_lookup_extra_result2 = (userid_lookup_extra_result_t*)p_epe_user_id_info->per_lookup[USER_ID_LOOKUP2].hash_lookup_result.extra;

    /* VLAN_LOOKUP_RESULT */
    p_epe_user_id_info->non_mirror_packet = (CM_PLD_OP_MIRROR != pkt_info->payload_operation);
    p_epe_user_id_info->bcast_mac = (parser_result->l2_s.mac_da5 == 0xFF && parser_result->l2_s.mac_da4 == 0xFF
                                     && parser_result->l2_s.mac_da3 == 0xFF && parser_result->l2_s.mac_da2 == 0xFF
                                     && parser_result->l2_s.mac_da1 == 0xFF && parser_result->l2_s.mac_da0 == 0xFF);

    p_epe_user_id_info->mcast_mac = IS_BIT_SET(parser_result->l2_s.mac_da5,0) && !p_epe_user_id_info->bcast_mac;

    if (p_epe_user_id_info->per_lookup[USER_ID_LOOKUP1].vlan_hash_type != USERID_KEY_TYPE_DISABLE)
    {
        vlan_hash1_result_valid = p_epe_user_id_info->per_lookup[USER_ID_LOOKUP1].hash_lookup_result.valid;
        hash1_default_entry_valid = p_userid_lookup_extra_result1->default_entry_valid;
    }

    if (p_epe_user_id_info->per_lookup[USER_ID_LOOKUP2].vlan_hash_type != USERID_KEY_TYPE_DISABLE)
    {
        vlan_hash2_result_valid = p_epe_user_id_info->per_lookup[USER_ID_LOOKUP2].hash_lookup_result.valid;
        hash2_default_entry_valid = p_userid_lookup_extra_result2->default_entry_valid;
    }

    /* DsVlanXlate is different from DsUserId */
    if (vlan_hash1_result_valid && !hash1_default_entry_valid)      /* hash 1 lookup result */
    {
        user_id_result_valid = TRUE;
        sal_memcpy(&p_epe_user_id_info->ds_vlan_xlate,
            p_userid_lookup_extra_result1->data, sizeof(ds_vlan_xlate_t));
    }
    else if (vlan_hash2_result_valid && !hash2_default_entry_valid) /* hash 2 lookup result */
    {
        user_id_result_valid = TRUE;
        sal_memcpy(&p_epe_user_id_info->ds_vlan_xlate,
            p_userid_lookup_extra_result2->data, sizeof(ds_vlan_xlate_t));
    }
    else if (vlan_hash1_result_valid && hash1_default_entry_valid)  /* default entry */
    {
        user_id_result_valid = TRUE;
        sal_memcpy(&p_epe_user_id_info->ds_vlan_xlate,
            p_userid_lookup_extra_result1->data, sizeof(ds_vlan_xlate_t));
    }
    else if (vlan_hash2_result_valid && hash2_default_entry_valid)  /* default entry */
    {
        user_id_result_valid = TRUE;
        sal_memcpy(&p_epe_user_id_info->ds_vlan_xlate,
            p_userid_lookup_extra_result2->data, sizeof(ds_vlan_xlate_t));
    }

    if (user_id_result_valid)
    {
        pkt_info->xlate_svlan_id = p_epe_user_id_info->ds_vlan_xlate.user_svlan_id;
        pkt_info->xlate_stag_cos = p_epe_user_id_info->ds_vlan_xlate.user_scos;
        pkt_info->xlate_stag_cfi = p_epe_user_id_info->ds_vlan_xlate.user_scfi;
        pkt_info->xlate_cvlan_id = p_epe_user_id_info->ds_vlan_xlate.user_cvlan_id;
        pkt_info->xlate_ctag_cos = p_epe_user_id_info->ds_vlan_xlate.user_ccos;
        pkt_info->xlate_ctag_cfi = p_epe_user_id_info->ds_vlan_xlate.user_ccfi;
        pkt_info->stag_action = p_epe_user_id_info->ds_vlan_xlate.s_tag_action;
        pkt_info->ctag_action = p_epe_user_id_info->ds_vlan_xlate.c_tag_action;
        pkt_info->svlan_id_action = p_epe_user_id_info->ds_vlan_xlate.s_vlan_id_action;
        pkt_info->cvlan_id_action = p_epe_user_id_info->ds_vlan_xlate.c_vlan_id_action;
        pkt_info->stag_cos_action = p_epe_user_id_info->ds_vlan_xlate.s_cos_action;
        pkt_info->ctag_cos_action = p_epe_user_id_info->ds_vlan_xlate.c_cos_action;

        /* enum definition is the same as sCosAction[1:0] */
        pkt_info->s_cfi_action = p_epe_user_id_info->ds_vlan_xlate.s_cfi_action;
        /* enum definition is the same as cCosAction[1:0] */
        pkt_info->c_cfi_action = p_epe_user_id_info->ds_vlan_xlate.c_cfi_action;
        pkt_info->svlan_xlate_valid = p_epe_user_id_info->ds_vlan_xlate.svlan_xlate_valid;
        pkt_info->cvlan_xlate_valid = p_epe_user_id_info->ds_vlan_xlate.cvlan_xlate_valid;
        pkt_info->ctag_add_mode = p_epe_user_id_info->ds_vlan_xlate.ctag_add_mode;

        if ((pkt_info->ctag_action == USERID_CTAG_ACTION_MODIFY)
            && (!parser_result->l2_s.cvlan_id_valid)
            && (p_epe_user_id_info->ds_vlan_xlate.ctag_modify_mode))
        {
            pkt_info->ctag_action = USERID_CTAG_ACTION_ADD; /* packet without ctag upgrade action to add */
        }

        if ((pkt_info->stag_action == USERID_STAG_ACTION_MODIFY)
            && (!parser_result->l2_s.svlan_id_valid)
            && (p_epe_user_id_info->ds_vlan_xlate.stag_modify_mode))
        {
            pkt_info->stag_action = USERID_STAG_ACTION_ADD; /* packet without stag upgrade action to add */
        }


        if (p_epe_user_id_info->ds_vlan_xlate.svlan_tpid_index_en)
        {
            pkt_info->xlate_svlan_tpid_index_en = TRUE;
            pkt_info->xlate_svlan_tpid_index = p_epe_user_id_info->ds_vlan_xlate.svlan_tpid_index;
        }

        if (0 != p_epe_user_id_info->ds_vlan_xlate.user_vlan_ptr)
        {
            pkt_info->dest_vlan_ptr = p_epe_user_id_info->ds_vlan_xlate.user_vlan_ptr;
        }

        if (p_epe_user_id_info->ds_vlan_xlate.user_priority_en)
        {
            pkt_info->priority = p_epe_user_id_info->ds_vlan_xlate.user_priority;
        }

        if (0 != p_epe_user_id_info->ds_vlan_xlate.user_color)
        {
            pkt_info->color = p_epe_user_id_info->ds_vlan_xlate.user_color;
        }

        if (p_epe_user_id_info->ds_vlan_xlate.ds_fwd_ptr_valid && !p_epe_user_id_info->link_oam )
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_DS_VLAN_TRANS_DIS;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE UserID Ad set discard DsFwdPtr! \n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (p_epe_user_id_info->ds_vlan_xlate.user_id_exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 0;
        }

        if ((0 != p_epe_user_id_info->ds_vlan_xlate.stats_ptr) && !pkt_info->flow_stats2_valid)
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = p_epe_user_id_info->ds_vlan_xlate.stats_ptr;
        }

        /* PBB isid egress translation,only for dest port is CBP */
        if (p_epe_user_id_info->ds_vlan_xlate.isid_valid)
        {
            pkt_info->new_itag_valid = TRUE;
            pkt_info->itag_offset_type = parser_result->l2_s.svlan_id_valid;
            pkt_info->new_itag = p_epe_user_id_info->ds_vlan_xlate.new_itag;
        }

        /* port isolate based egress vlan xlate lookup,for PORTVLANCROSS and PORTCROSS */
        if (p_epe_user_id_info->ds_vlan_xlate.vlan_xlate_port_isolate_en
            && ((CM_PLD_OP_BRIDGE == pkt_info->payload_operation)
                || (epe_next_hop_ctl.route_obey_isolate && (CM_PLD_OP_BRIDGE != pkt_info->payload_operation))))
        {
            /* discard unknown unicast packet */
            if (pkt_info->mcast && !IS_BIT_SET(parser_result->l2_s.mac_da5,0)
                    && p_epe_user_id_info->ds_vlan_xlate.discard_unknown_ucast && p_epe_user_id_info->non_mirror_packet)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Port Isolate disable Unknown Ucast Flooding! \n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }

            /* discard unknown multicast packet */
            if (!pkt_info->mac_known && p_epe_user_id_info->mcast_mac
                    && p_epe_user_id_info->ds_vlan_xlate.discard_unknown_mcast && p_epe_user_id_info->non_mirror_packet)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Port Isolate disable Unknown Mcast Flooding! \n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }

            /* discard known multicast packet */
            if (pkt_info->mac_known && p_epe_user_id_info->mcast_mac
                    && p_epe_user_id_info->ds_vlan_xlate.discard_known_mcast && p_epe_user_id_info->non_mirror_packet)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Port Isolate disable known Mcast Flooding! \n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }

            /* discard broadcast packet */
            if (p_epe_user_id_info->bcast_mac && p_epe_user_id_info->ds_vlan_xlate.discard_bcast
                    && p_epe_user_id_info->non_mirror_packet)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Port Isolate disable Bcast Flooding! \n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }

            /* discard known unicast packet */
            if (!pkt_info->mcast && !IS_BIT_SET(parser_result->l2_s.mac_da5,0)
                    && p_epe_user_id_info->ds_vlan_xlate.discard_known_ucast && p_epe_user_id_info->non_mirror_packet)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Port Isolate disable known Ucast! \n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_nexthop_mapper_get_dest_vlan_interface
 * Purpose:   Retrieve dsdestvlan and get the vlan informations from it.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/

static int32
_cm_epe_nexthop_mapper_get_dest_vlan_interface(epe_in_pkt_t* ipkt,
                epe_user_id_info_t* p_epe_user_id_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *) ipkt->pkt_info;
    ds_vlan_t ds_vlan;
    epe_next_hop_ctl_t epe_next_hop_ctl;
    ds_vlan_profile_t ds_vlan_profile;
    ds_dest_interface_t ds_dest_interface;
    ds_dest_port_t ds_dest_port;

    uint8 if_mtu_check_en = FALSE;
    uint8 vlan_transmit_disable = FALSE;
    uint32 cmd = 0;

    sal_memset(&ds_dest_port, 0, sizeof(ds_dest_port));
    cmd = DRV_IOR(DsDestPort_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->local_phy_port & 0xFF, cmd, &ds_dest_port));

    sal_memset(&epe_next_hop_ctl, 0, sizeof(epe_next_hop_ctl));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_next_hop_ctl));

    /* RETRIEVE_DS_DEST_VLAN */
    if (!p_epe_user_id_info->bypass_all && !IS_BIT_SET(pkt_info->dest_vlan_ptr, 12))
    {
        sal_memset(&ds_vlan, 0, sizeof(ds_vlan));
        cmd = DRV_IOR(DsVlan_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->dest_vlan_ptr, cmd, &ds_vlan));

        p_epe_user_id_info->egress_filtering_en = (p_epe_user_id_info->egress_filtering_en
                                                  || ds_vlan.egress_filtering_en)
                                                  && (!p_epe_user_id_info->egress_filtering_disable)
                                                  && (!pkt_info->from_cpu_or_oam || pkt_info->is_up);

        if (!pkt_info->routed_port
            && p_epe_user_id_info->egress_filtering_en
            && (pkt_info->local_phy_port < MAX_NETWORK_PORT_WO_MUX))
        {
            if (IS_BIT_SET(pkt_info->local_phy_port, 5))
            {
                p_epe_user_id_info->vlan_id_valid = IS_BIT_SET(ds_vlan.vlan_id_valid59_32, pkt_info->local_phy_port & 0x1F);
            }
            else
            {
                p_epe_user_id_info->vlan_id_valid = IS_BIT_SET(ds_vlan.vlan_id_valid31_0,pkt_info->local_phy_port & 0x1F);
            }
        }

        vlan_transmit_disable = ds_vlan.transmit_disable;
        pkt_info->stp_id = ds_vlan.stp_id;

        if ((pkt_info->local_phy_port < MAX_NETWORK_PORT_WO_MUX) && epe_next_hop_ctl.tag_port_bit_map_en)
        {
            if (IS_BIT_SET(pkt_info->local_phy_port, 5))
            {
                pkt_info->dot1_q_en &= (((IS_BIT_SET(ds_vlan.tag_port_bit_map59_32,pkt_info->local_phy_port & 0x1F)) << 1)|1);
            }
            else
            {
                pkt_info->dot1_q_en &= (((IS_BIT_SET(ds_vlan.tag_port_bit_map31_0,pkt_info->local_phy_port & 0x1F)) << 1)|1);
            }
        }

        if (ds_vlan.profile_id != 0)
        {
            sal_memset(&ds_vlan_profile, 0, sizeof(ds_vlan_profile));
            cmd = DRV_IOR(DsVlanProfile_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ds_vlan.profile_id, cmd, &ds_vlan_profile));

            pkt_info->l3_acl_routed_only = ds_vlan_profile.egress_vlan_acl_routed_only;
            pkt_info->l3_acl_en0 = ds_vlan_profile.egress_vlan_acl_en0;
            pkt_info->l3_acl_en1 = ds_vlan_profile.egress_vlan_acl_en1;
            pkt_info->l3_acl_en2 = ds_vlan_profile.egress_vlan_acl_en2;
            pkt_info->l3_acl_en3 = ds_vlan_profile.egress_vlan_acl_en3;
            pkt_info->l3_span_en = ds_vlan_profile.egress_vlan_span_en;
            pkt_info->l3_span_id = ds_vlan_profile.egress_vlan_span_id;
            pkt_info->l3_acl_label = ds_vlan_profile.egress_vlan_acl_label;
            pkt_info->l3_ipv6_acl_en0 = ds_vlan_profile.egress_vlan_ipv6_acl_en0;
            pkt_info->l3_ipv6_acl_en1 = ds_vlan_profile.egress_vlan_ipv6_acl_en1;
        }
    }
    else
    {
        vlan_transmit_disable = FALSE;
    }

    if (pkt_info->packet_header_en && epe_next_hop_ctl.stacking_dot1_q_en)
    {
        pkt_info->dot1_q_en = 0x3;
    }

    /* VLAN stats */
    /* ======== bug 4728/4738 ECO begine ========= */
    //if (epe_next_hop_ctl.vlan_stats_en && !pkt_info->flow_stats2_valid)
    if (!p_epe_user_id_info->bypass_all && !IS_BIT_SET(pkt_info->dest_vlan_ptr, 12)
        && epe_next_hop_ctl.vlan_stats_en && !pkt_info->flow_stats2_valid && !pkt_info->packet_header_en)
    /* ======== bug 4728/4738 ECO end ========= */
    {
        if (0 == epe_next_hop_ctl.stats_mode)
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = (epe_next_hop_ctl.vlan_stats_ucast_ptr_bit << 12) | (pkt_info->dest_vlan_ptr & 0xFFF);
        }
        else if (1 == epe_next_hop_ctl.stats_mode && !p_epe_user_id_info->mcast_mac && !p_epe_user_id_info->bcast_mac)
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = (epe_next_hop_ctl.vlan_stats_ucast_ptr_bit << 12) | (pkt_info->dest_vlan_ptr & 0xFFF);
        }
        else if (2 == epe_next_hop_ctl.stats_mode && p_epe_user_id_info->mcast_mac)
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = (epe_next_hop_ctl.vlan_stats_mcast_ptr_bit << 12) | (pkt_info->dest_vlan_ptr & 0xFFF);
        }
        else if (3 == epe_next_hop_ctl.stats_mode && p_epe_user_id_info->bcast_mac)
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = (epe_next_hop_ctl.vlan_stats_bcast_ptr_bit << 12) | (pkt_info->dest_vlan_ptr & 0xFFF);
        }
        else
        {
            /* do nothing */
        }
    }

    /* DS_DEST_INTERFACE */
    if (!p_epe_user_id_info->bypass_all && !IS_BIT_SET(pkt_info->dest_vlan_ptr, 12))
    {
        pkt_info->interface_id = ds_vlan.interface_id;
    }
    else if (4 == (pkt_info->dest_vlan_ptr >> 10))
    {
        pkt_info->interface_id = pkt_info->dest_vlan_ptr & 0x3FF;   /* vlanPtr[12:0]-13'h1000 */
    }
    else
    {
        pkt_info->interface_id = 0;
    }

    if (!p_epe_user_id_info->bypass_all)
    {
        if (pkt_info->interface_id != 0)
        {
            sal_memset(&ds_dest_interface, 0, sizeof(ds_dest_interface));
            cmd = DRV_IOR(DsDestInterface_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->interface_id, cmd, &ds_dest_interface));

            pkt_info->mtu_exception_en = ds_dest_interface.mtu_exception_en;
            pkt_info->mcast_ttl_threshold = ds_dest_interface.mcast_ttl_threshold;
            pkt_info->mac_sa_type = ds_dest_interface.mac_sa_type;
            pkt_info->mac_sa = ds_dest_interface.mac_sa;
            pkt_info->mtu_size = ds_dest_interface.mtu_size;
            pkt_info->mpls_section_lm_en |= ds_dest_interface.mpls_section_lm_en;
            pkt_info->mpls_label_space = ds_dest_interface.interface_label_space;
            if_mtu_check_en = ds_dest_interface.mtu_check_en;
            pkt_info->interface_vlan_id_en = TRUE;
            pkt_info->interface_svlan_tagged = ds_dest_interface.interface_svlan_tagged;
            pkt_info->interface_vlan_id = ds_dest_interface.vlan_id;
        }
        else
        {
            pkt_info->mtu_exception_en = FALSE;
            pkt_info->mcast_ttl_threshold = 0;
            pkt_info->mac_sa_type = 0;
            pkt_info->mac_sa = 0;
            pkt_info->mtu_size = 0;

            if_mtu_check_en = FALSE;
        }

        pkt_info->mtu_check_en = p_epe_user_id_info->mtu_check_en && if_mtu_check_en;

        if (p_epe_user_id_info->is_nexthop_8w)
        {
            pkt_info->replace_dscp = p_epe_user_id_info->replace_dscp || ds_dest_port.replace_dscp;
        }
        else
        {
            pkt_info->replace_dscp = ds_dest_port.replace_dscp;
        }

        if ((vlan_transmit_disable || ds_dest_port.transmit_disable) && !p_epe_user_id_info->link_oam)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_DS_VLAN_TRANS_DIS;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("+++++++ pkt_info->ds_nexthop_dot_bypass_all = %d\n", pkt_info->ds_nexthop_dot_bypass_all);
                if (vlan_transmit_disable)
                {
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE DsVlan transmitEn disable, vlanPtr = 0x%x!\n",
                                           pkt_info->dest_vlan_ptr);
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }

                if (ds_dest_port.transmit_disable)
                {
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE DsDestPort transmitEn disable, port = 0x%x!\n",
                                           pkt_info->local_phy_port);
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
        }
    }

    if((CM_PLD_OP_MIRROR == pkt_info->payload_operation) && epe_next_hop_ctl.deny_duplicate_mirror)
    {
        pkt_info->l2_span_en = FALSE;
        pkt_info->l3_span_en = FALSE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_epe_nexthop_mapper_overwrite_routing
 * Purpose:    Over write routing when l3match (destvlanPtr = srcVlanptr).
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                      header ,and processing information
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                      header ,and processing information
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_epe_nexthop_mapper_overwrite_routing(epe_in_pkt_t* ipkt, epe_user_id_info_t* p_epe_user_id_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_next_hop_ctl_t epe_nexthop_ctl;

    uint8 l3_match = FALSE;
    uint8 payload_op_is_route = FALSE;
    uint32 cmd = 0;

    /* Actually should use interfaceId, not vlanPtr */
    /* Multicast back to this routedPort will be discard by l2Match, multicast between sub-interfaces will be permitted */
    if (pkt_info->dest_vlan_ptr == pkt_info->src_vlan_ptr)
    {
        l3_match = TRUE;    /* ip multicast must use DsL2Edit for outputVlanId */
    }

    sal_memset(&epe_nexthop_ctl, 0, sizeof(epe_nexthop_ctl));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_nexthop_ctl));

    payload_op_is_route = (CM_PLD_OP_ROUTE == pkt_info->payload_operation)
                          || (CM_PLD_OP_ROUTE_NOTTL == pkt_info->payload_operation)
                          || (CM_PLD_OP_ROUTE_COMPACT == pkt_info->payload_operation);

    if (epe_nexthop_ctl.force_bridge_l3_match
            && l3_match
            && pkt_info->mcast
            && (parser_result->layer3_type != L3_TYPE_TRILL)
            && payload_op_is_route)
    {
        pkt_info->payload_operation = CM_PLD_OP_BRIDGE;    /* Overwrite to bridge*/
        p_epe_user_id_info->l3_edit_ptr = 0;
        p_epe_user_id_info->l2_edit_ptr = 0;
        pkt_info->mtu_check_en = FALSE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_nexthop_mapper_lookup_editing_ds
 * Purpose:   Look up dsl2edit and dsl3edit.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_nexthop_mapper_lookup_editing_ds(epe_in_pkt_t* ipkt, epe_user_id_info_t* p_epe_user_id_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *) ipkt->pkt_info;
    epe_next_hop_ctl_t epe_next_hop_ctl;

    uint32 cmd = 0;

    sal_memset(&epe_next_hop_ctl, 0, sizeof(epe_next_hop_ctl_t));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_next_hop_ctl));

    if (!p_epe_user_id_info->edit_bypass)
    {
        /* LOOKUP_EDITING_DS */

        if (!p_epe_user_id_info->nexthop_output_svlan_id_valid
            && (CM_PLD_OP_ROUTE_COMPACT != pkt_info->payload_operation))
        {
            if (0 != p_epe_user_id_info->l3_edit_ptr) /* always retrieve 160bits */
            {
                cmd = DRV_IOR(DsL3EditMpls8W_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, (p_epe_user_id_info->l3_edit_ptr & 0x3FFFE),
                                               cmd, pkt_info->l3_edit));
                pkt_info->l3_edit_ptr_bit0 = IS_BIT_SET(p_epe_user_id_info->l3_edit_ptr, 0);
                pkt_info->ds_l3_edit_exist = TRUE;
            }
        }

        if (!p_epe_user_id_info->nexthop_output_svlan_id_valid
            && !p_epe_user_id_info->nexthop_output_cvlan_id_valid
            && (CM_PLD_OP_ROUTE_COMPACT != pkt_info->payload_operation))
        {
            if (0 != p_epe_user_id_info->l2_edit_ptr) /* always retrieve 160bits */
            {
                cmd = DRV_IOR(DsL2EditEth8W_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, (p_epe_user_id_info->l2_edit_ptr & 0x3FFFE),
                                               cmd, pkt_info->l2_edit));
                pkt_info->l2_edit_ptr_bit0 = IS_BIT_SET(p_epe_user_id_info->l2_edit_ptr, 0);
                pkt_info->ds_l2_edit_exist = TRUE;
            }
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_epe_nexthop_mapper_bridge_discard
 * Purpose:    Brige discard when l2match (sourceport = globalDestport).
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                      header ,and processing information
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                      header ,and processing information
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_epe_nexthop_mapper_bridge_discard(epe_in_pkt_t* ipkt, epe_user_id_info_t* p_epe_user_id_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    ds_dest_port_t ds_dest_port;
    epe_next_hop_ctl_t epe_nexthop_ctl;

    uint8 non_bridge_operation_discard = FALSE;
    uint8 bridge_operation_discard = FALSE;
    uint8 port_isolate_valid = FALSE;
    uint8 src_community_id = 0;
    uint8 dest_community_id = 0;
    uint8 src_is_c_port = FALSE;
    uint8 src_is_p_port = FALSE;
    uint8 dest_is_c_port = FALSE;
    uint8 dest_is_p_port = FALSE;
    uint8 bridge_operation = 0;
    uint8 src_is_logic_tunnel = FALSE;
    uint8 dest_is_logic_tunnel = FALSE;
    uint32 cmd = 0;
    uint8 bcast_mac_addr = FALSE;
    uint8 mcast_mac_addr = FALSE;

    sal_memset(&epe_nexthop_ctl, 0, sizeof(epe_nexthop_ctl));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_nexthop_ctl));

    sal_memset(&ds_dest_port, 0, sizeof(ds_dest_port));
    cmd = DRV_IOR(DsDestPort_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->local_phy_port & 0xFF, cmd, &ds_dest_port));

    /* BRIDGE_DISCARD */
    bcast_mac_addr = (0xFF == parser_result->l2_s.mac_da5)
                               && (0xFF == parser_result->l2_s.mac_da4)
                               && (0xFF == parser_result->l2_s.mac_da3)
                               && (0xFF == parser_result->l2_s.mac_da2)
                               && (0xFF == parser_result->l2_s.mac_da1)
                               && (0xFF == parser_result->l2_s.mac_da0);

    mcast_mac_addr = IS_BIT_SET(parser_result->l2_s.mac_da5, 0) && !bcast_mac_addr;

    if (!p_epe_user_id_info->bypass_all)
    {
        if (epe_nexthop_ctl.isolated_type
                && (0 != pkt_info->source_port_isolate_id)
                && (0 != ds_dest_port.dest_port_isolate_id))
        {
            if (IS_BIT_SET(pkt_info->source_port_isolate_id, 5)
               && IS_BIT_SET(ds_dest_port.dest_port_isolate_id, 5))    /* PVLAN */
            {
                if (!IS_BIT_SET(pkt_info->source_port_isolate_id, 4))
                {
                    src_is_c_port = TRUE;
                    src_community_id = pkt_info->source_port_isolate_id & 0xF;
                }
                else
                {
                    src_is_p_port = !IS_BIT_SET(pkt_info->source_port_isolate_id, 3);
                }

                if (!IS_BIT_SET(ds_dest_port.dest_port_isolate_id, 4))
                {
                    dest_is_c_port = TRUE;
                    dest_community_id = ds_dest_port.dest_port_isolate_id & 0xF;
                }
                else
                {
                    dest_is_p_port = !IS_BIT_SET(ds_dest_port.dest_port_isolate_id, 3);
                }

                if (src_is_p_port || dest_is_p_port
                    || (src_is_c_port && dest_is_c_port
                        && (src_community_id == dest_community_id)))
                {
                    port_isolate_valid = FALSE;
                }
                else
                {
                    port_isolate_valid = TRUE;
                }
            }
            else if (!IS_BIT_SET(pkt_info->source_port_isolate_id, 5)
                    && !IS_BIT_SET(ds_dest_port.dest_port_isolate_id, 5))    /* PORT ISOLATE */
            {
                if (pkt_info->flooding_discard_type)    /* flooding discard only affect in isolation group */
                {
                    port_isolate_valid = ((ds_dest_port.dest_port_isolate_id & 0x1F)
                                          == (pkt_info->source_port_isolate_id & 0x1F))
                                          && (p_epe_user_id_info->source_port != pkt_info->global_dest_port)
                                          && ((pkt_info->mcast && !IS_BIT_SET(parser_result->l2_s.mac_da5, 0)
                                          && pkt_info->ucast_flooding_disable)
                                          || (!pkt_info->mac_known
                                          && mcast_mac_addr && pkt_info->mcast_flooding_disable)
                                          || (pkt_info->mac_known
                                          && mcast_mac_addr && pkt_info->known_mcast_flooding_disable)
                                          || (bcast_mac_addr && pkt_info->bcast_flooding_disable));
                }
                else
                {
                    port_isolate_valid = ((ds_dest_port.dest_port_isolate_id & 0x1F)
                                          == (pkt_info->source_port_isolate_id & 0x1F))
                                          && (p_epe_user_id_info->source_port != pkt_info->global_dest_port);
                }
            }

            bridge_operation_discard = port_isolate_valid
                                        && (((CM_PLD_OP_BRIDGE == pkt_info->payload_operation) && !pkt_info->ingress_edit_en)
                                            ||(pkt_info->bridge_operation && pkt_info->ingress_edit_en));

            non_bridge_operation_discard = port_isolate_valid && epe_nexthop_ctl.route_obey_isolate
                                           && (((CM_PLD_OP_BRIDGE != pkt_info->payload_operation) && !pkt_info->ingress_edit_en)
                                            ||(!pkt_info->bridge_operation && pkt_info->ingress_edit_en));

            if ((bridge_operation_discard || non_bridge_operation_discard) && !p_epe_user_id_info->link_oam)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = EPE_DISCARD_PORT_ISOLATE_DISCARD;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Port Isolate discard!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
        }
    }

    pkt_info->l2_match = (p_epe_user_id_info->source_port == pkt_info->global_dest_port);

    src_is_logic_tunnel = pkt_info->logic_port_type;
    dest_is_logic_tunnel = ds_dest_port.logic_port_type || (CM_PLD_OP_BRIDGE_VPLS == pkt_info->payload_operation);
    bridge_operation = (((CM_PLD_OP_BRIDGE == pkt_info->payload_operation)
                           || (CM_PLD_OP_BRIDGE_VPLS == pkt_info->payload_operation)
                           || (CM_PLD_OP_BRIDGE_INNER == pkt_info->payload_operation)) && !pkt_info->ingress_edit_en)
                       || (pkt_info->bridge_operation && pkt_info->ingress_edit_en);

    if (!p_epe_user_id_info->bypass_all && epe_nexthop_ctl.discard_reflective_bridge
       && pkt_info->l2_match && bridge_operation
       && (!(pkt_info->from_cpu_or_oam && (OAM_ETHER == pkt_info->rx_oam_type)))
       && !ds_dest_port.reflective_bridge_en) /* normal bridge discard */
    {
        pkt_info->port_reflective_discard = TRUE;
    }

    if (!p_epe_user_id_info->bypass_all && epe_nexthop_ctl.discard_logic_tunnel_match && src_is_logic_tunnel
       && dest_is_logic_tunnel && bridge_operation)
    {
        if(!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_VPLS_HORIZON_SPLIT_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE VPLS horizon split discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /*============bug 4690 ECO begin===========*/
    /*if (!p_epe_user_id_info->bypass_all && ds_dest_port.ether_oam_valid && !port_isolate_valid)*/
    if (!p_epe_user_id_info->bypass_all && ds_dest_port.ether_oam_valid 
        && !port_isolate_valid && p_epe_user_id_info->non_mirror_packet)
    /*============bug 4690 ECO end=============*/
    {
        pkt_info->ether_oam_valid = TRUE;
    }

    /*============bug 4690 ECO begin===========*/
    if (!p_epe_user_id_info->bypass_all && pkt_info->src_leaf 
        && pkt_info->is_leaf && p_epe_user_id_info->non_mirror_packet)
    /*============bug 4690 ECO end=============*/
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_VPLS_HORIZON_SPLIT_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE VPLS horizon split discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    return DRV_E_NONE;
}

static int32
_cm_epe_nexthop_mapper_filtering(epe_in_pkt_t* ipkt,
                        epe_user_id_info_t* p_epe_user_id_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_next_hop_ctl_t epe_nexthop_ctl;
    ds_dest_port_t ds_dest_port;
    ds_dest_channel_t ds_dest_channel;

    uint8 non_mirror_packet = p_epe_user_id_info->non_mirror_packet;
    uint32 cmd = 0;
    uint8 ptp_message_type = 0;
    uint32 ptp_correction_field_63_to_32 = 0;
    uint32 ptp_correction_field_31_to_0 = 0;
    uint32 ptp_timestamp_63_to_32 = 0;
    uint32 ptp_timestamp_31_to_0 = 0;
    uint16 mac_da_47_to_32 = 0;
    uint32 mac_da_31_to_0 = 0;
    uint16 mac_sa_47_to_32 = 0;
    uint32 mac_sa_31_to_0 = 0;
    uint8 oam_valid = FALSE, is_ether_type = FALSE, is_same_mac = FALSE, is_same_v4_ip = FALSE, is_same_v6_ip = FALSE;
    uint16 ds_stp_state_index = 0;
    uint16 stp_field_offset = 0;
    uint8 stp_state = 0;
    uint32 stp_field_value = 0;
    uint8 route_or_mpls = FALSE;
    uint8 bcast_mac_addr = FALSE;
    uint8 mcast_mac_addr = FALSE;
    cm_uint64_t timestamp,tmp_64_a,tmp_64_b;
    uint8 parser_offset = 0;

    sal_memset(&epe_nexthop_ctl, 0, sizeof(epe_nexthop_ctl));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_nexthop_ctl));

    sal_memset(&ds_dest_channel, 0, sizeof(ds_dest_channel_t));
    cmd = DRV_IOR(DsDestChannel_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &ds_dest_channel));

    /* PTP */
    parser_offset = pkt_info->parser_offset << 2;
    if (parser_result->layer3_type == L3_TYPE_PTP)
    {
        pkt_info->ptp_offset = parser_result->l2_s.layer3_offset + parser_offset
                               + (pkt_info->share_fields_u.ptp.ptp_extra_offset << 2);
    }
    else if (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_UDP_PTP)
    {
        pkt_info->ptp_offset = parser_result->l3_s.layer4_offset + 8 +parser_offset
                               + (pkt_info->share_fields_u.ptp.ptp_extra_offset << 2);
    }

    pkt_info->udp_ptp = (parser_result->layer4_type == L4_TYPE_UDP);

    if (((parser_result->layer3_type == L3_TYPE_PTP)
           && (parser_result->l3_s.ip_da.ptp.ptp_version == PTP_VERSION2))
        || ((parser_result->layer4_type == L4_TYPE_UDP)
            && (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_UDP_PTP)
            && (((parser_result->l4_s.isatap_ptp_ver.udp_ptp_version1 << 1)
                  | parser_result->l4_s.rid_ptp_bfd.ptp_msg_type.udp_ptp_version0) == 2)))
    {
        pkt_info->ptp_offset_type = PTP_OFFSET_TYPE_PTPV2;  /* PTPV2 */
    }
    else if (((parser_result->layer3_type == L3_TYPE_PTP)
                && (parser_result->l3_s.ip_da.ptp.ptp_version == PTP_VERSION1))
              || ((parser_result->layer4_type == L4_TYPE_UDP)
                  && (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_UDP_PTP)
                  && (((parser_result->l4_s.isatap_ptp_ver.udp_ptp_version1 << 1)
                       | parser_result->l4_s.rid_ptp_bfd.ptp_msg_type.udp_ptp_version0) == 1)))
    {
        pkt_info->ptp_offset_type = PTP_OFFSET_TYPE_PTPV1;  /* PTPV1 */
    }
    else
    {
        pkt_info->ptp_offset_type = PTP_OFFSET_TYPE_OTHER;  /* Other(DM,etc) */
    }

    ptp_message_type = (parser_result->layer3_type == L3_TYPE_PTP)
                        ? parser_result->l3_s.ip_da.ptp.ptp_message_type
                        : parser_result->l4_s.rid_ptp_bfd.ptp_msg_type.udp_ptp_message_type;

    ptp_correction_field_63_to_32 = (parser_result->layer3_type == L3_TYPE_PTP)
                        ? parser_result->l3_s.ip_da.ptp.ptp_correction_field_63_32
                        : parser_result->l4_s.ptp_oam_ach.udp_ptp_correction_field_63_32;

    ptp_correction_field_31_to_0 = (parser_result->layer3_type == L3_TYPE_PTP)
                        ? parser_result->l3_s.ip_da.ptp.ptp_correction_field_31_0
                        : parser_result->l4_s.gre_bfd_ptp.udp_ptp_correction_field_31_0;

    ptp_timestamp_63_to_32 = (parser_result->layer3_type == L3_TYPE_PTP)
                        ? parser_result->l3_s.ip_sa.ptp.ptp_timestamp_63_32
                        : parser_result->l4_s.udp_ptp_timestamp_63_to_32;
    ptp_timestamp_31_to_0 = (parser_result->layer3_type == L3_TYPE_PTP)
                        ? parser_result->l3_s.ip_sa.ptp.ptp_timestamp_31_0
                        : parser_result->l4_s.udp_ptp_timestamp_31_to_0;


    if (SHARE_TYPE_PTP == pkt_info->share_type && !pkt_info->packet_header_en)
    {
       if (pkt_info->share_fields_u.ptp.ptp_edit_type == PTP_CORRECTION)   /* TC */
       {
            sal_memset(&tmp_64_a, 0, sizeof(tmp_64_a));
            tmp_64_a.high_63_32 = pkt_info->share_fields_u.ptp.time_stamp_61_32;
            tmp_64_a.low_31_0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;

            sal_memset(&tmp_64_b, 0, sizeof(tmp_64_b));
            tmp_64_b.high_63_32 = ptp_correction_field_63_to_32 >> 16;
            tmp_64_b.low_31_0 = ((ptp_correction_field_63_to_32 & 0xFFFF) << 16)
                                    | (ptp_correction_field_31_to_0 >> 16);

            sal_memset(&timestamp,0,sizeof(timestamp));
            timestamp = cm_sub64(tmp_64_a, tmp_64_b);   /* only for ns */

            pkt_info->share_fields_u.ptp.time_stamp_61_32 = timestamp.high_63_32;
            pkt_info->share_fields_u.ptp.time_stamp_31_0 = timestamp.low_31_0;

             /* Asymmetry correction for egress port */
            if ((ptp_message_type == PTP_MESSAGE_TYPE_DELAY_REQ)
                || (ptp_message_type == PTP_MESSAGE_TYPE_PDELAY_REQ))
            {
                if (!ds_dest_channel.asymmetry_delay_negtive)
                {
                    sal_memset(&tmp_64_a,0,sizeof(tmp_64_a));
                    tmp_64_a.high_63_32 = pkt_info->share_fields_u.ptp.time_stamp_61_32;
                    tmp_64_a.low_31_0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;

                    sal_memset(&tmp_64_b,0,sizeof(tmp_64_b));
                    tmp_64_b.high_63_32 = ds_dest_channel.asymmetry_delay35_32 & 0xF;
                    tmp_64_b.low_31_0 = ds_dest_channel.asymmetry_delay31_0;

                    sal_memset(&timestamp,0,sizeof(timestamp));
                    timestamp = cm_add64(tmp_64_a, tmp_64_b);

                    pkt_info->share_fields_u.ptp.time_stamp_61_32 = timestamp.high_63_32;
                    pkt_info->share_fields_u.ptp.time_stamp_31_0 = timestamp.low_31_0;
                }
                else
                {
                    sal_memset(&tmp_64_a,0,sizeof(tmp_64_a));
                    tmp_64_a.high_63_32 = pkt_info->share_fields_u.ptp.time_stamp_61_32;
                    tmp_64_a.low_31_0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;

                    sal_memset(&tmp_64_b,0,sizeof(tmp_64_b));
                    tmp_64_b.high_63_32 = ds_dest_channel.asymmetry_delay35_32 & 0xF;
                    tmp_64_b.low_31_0 = ds_dest_channel.asymmetry_delay31_0;

                    sal_memset(&timestamp,0,sizeof(timestamp));
                    timestamp = cm_sub64(tmp_64_a, tmp_64_b);

                    pkt_info->share_fields_u.ptp.time_stamp_61_32 = timestamp.high_63_32;
                    pkt_info->share_fields_u.ptp.time_stamp_31_0 = timestamp.low_31_0;
                }
            }
        }
    }

    pkt_info->new_l4_check_sum = parser_result->l4_s.layer4_check_sum;

    if (SHARE_TYPE_PTP == pkt_info->share_type && !p_epe_user_id_info->ptp_checksum_bypass && !pkt_info->ingress_edit_en )    /* PTP & NTP,put where ??? */
    {
        if (pkt_info->udp_ptp && (0 != parser_result->l4_s.layer4_check_sum)
            && !IS_BIT_SET(parser_result->l3_s.frag_info,1))  /* UDP check sum enabled */
        {
            if (pkt_info->share_fields_u.ptp.ptp_edit_type == PTP_CORRECTION) /* TC for correctionField */
            {
                pkt_info->new_l4_checksum_valid = TRUE;
                pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum((ptp_correction_field_31_to_0 >> 16) & 0xFFFF, 0,
                                               parser_result->l4_s.layer4_check_sum);
                pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(ptp_correction_field_31_to_0 & 0xFFFF, 0,
                                               pkt_info->new_l4_check_sum);
                pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum((ptp_correction_field_63_to_32 >> 16) & 0xFFFF, 0,
                                               pkt_info->new_l4_check_sum);
                pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(ptp_correction_field_63_to_32 & 0xFFFF, 0,
                                               pkt_info->new_l4_check_sum);
            }
            else if (pkt_info->share_fields_u.ptp.ptp_edit_type == PTP_REPLACE_ONLY)
            {
                pkt_info->new_l4_checksum_valid = TRUE;
                pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum((ptp_timestamp_31_to_0 >> 16) & 0xFFFF, 0,
                                               parser_result->l4_s.layer4_check_sum);
                pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(ptp_timestamp_31_to_0 & 0xFFFF, 0,
                                               pkt_info->new_l4_check_sum);
                pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum((ptp_timestamp_63_to_32 >> 16) & 0xFFFF, 0,
                                               pkt_info->new_l4_check_sum);
                pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(ptp_timestamp_63_to_32 & 0xFFFF, 0,
                                               pkt_info->new_l4_check_sum);
            }
        }
    }

    /* FILTERING */

    sal_memset(&ds_dest_port, 0, sizeof(ds_dest_port));
    cmd = DRV_IOR(DsDestPort_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->local_phy_port & 0xFF, cmd, &ds_dest_port));
    if (pkt_info->pbb_check_discard && (PBB_PORT_TYPE_CNP == ds_dest_port.pbb_port_type))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = EPE_DISCARD_PBB_CHK_FAIL_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE egress pbb check fail discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (parser_result->parser_length_error && non_mirror_packet)
    {
        if (!IS_BIT_SET(epe_nexthop_ctl.parser_length_error_mode, 1))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_EGRESS_PARSER_LEN_ERR_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE egress parser length error!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if ((0 == epe_nexthop_ctl.parser_length_error_mode) && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 1;
        }
    }

    if ((PBB_PORT_TYPE_CBP == pkt_info->pbb_dest_port_type)
       && (L3_TYPE_CMAC == parser_result->layer3_type)
       && (0 != parser_result->l3_s.ip_da.cmac.itag_tci.share.res2)    /* res2 */
       && epe_nexthop_ctl.cbp_tci_res2_check_en
       && non_mirror_packet)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_PBB_CHK_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE egress PBB check fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (!pkt_info->flooding_discard_type)
    {
        /* discard unknown unicast packet */
        if (pkt_info->mcast && (!IS_BIT_SET(parser_result->l2_s.mac_da5, 0))
                && pkt_info->ucast_flooding_disable
                && !p_epe_user_id_info->link_oam
                && non_mirror_packet)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE discard ucast flooding packet!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        bcast_mac_addr = (0xFF == parser_result->l2_s.mac_da5)
                           && (0xFF == parser_result->l2_s.mac_da4)
                           && (0xFF == parser_result->l2_s.mac_da3)
                           && (0xFF == parser_result->l2_s.mac_da2)
                           && (0xFF == parser_result->l2_s.mac_da1)
                           && (0xFF == parser_result->l2_s.mac_da0);

        mcast_mac_addr = IS_BIT_SET(parser_result->l2_s.mac_da5, 0) && !bcast_mac_addr;

        /* discard unknown multicast packet */
        if (!pkt_info->mac_known && mcast_mac_addr
                && pkt_info->mcast_flooding_disable
                && non_mirror_packet
                && !p_epe_user_id_info->link_oam)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE discard unknown mcast flooding packet!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        /* discard known multicast packet */
        if (pkt_info->mac_known
                && mcast_mac_addr
                && pkt_info->known_mcast_flooding_disable
                && non_mirror_packet
                && !p_epe_user_id_info->link_oam)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE discard known mcast flooding packet!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        /* discard broadcst packet */
        if (bcast_mac_addr
                && pkt_info->bcast_flooding_disable
                && non_mirror_packet
                && !p_epe_user_id_info->link_oam)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE discard bcast flooding packet!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    mac_da_47_to_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);
    mac_da_31_to_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                 parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);

    if (pkt_info->discard_non_8023_oam
        && !((L3_TYPE_SLOWPROTO == parser_result->layer3_type)
            && (3 == (parser_result->l3_s.ip_da.slow_ptl.slow_protocol_sub_type))
            && (0x0180 == mac_da_47_to_32) && (0xc2000002 == mac_da_31_to_0))
        && non_mirror_packet && pkt_info->from_cpu_or_oam)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_802_3_OAM_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE discard 802.3 OAM  packet!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (pkt_info->use_ttl_from_packet)
    {
        pkt_info->packet_ttl = parser_result->l3_s.ttl;
    }

    oam_valid = pkt_info->ether_oam_valid && !pkt_info->oam_tunnel_en
                && (L3_TYPE_ETHEROAM == parser_result->layer3_type) && non_mirror_packet;

    if (oam_valid)
    {
        pkt_info->rx_oam_type = OAM_ETHER;
    }
    if (pkt_info->is_up && pkt_info->from_cpu_or_oam
        && (parser_result->layer3_type == L3_TYPE_ETHEROAM)
        && pkt_info->ether_oam_edge_port)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_OAM_FILTERING_DISCARD;
            pkt_info->discard = TRUE;
        }

    }
    /*=========bug 4690 ECO begin=========*/
    /*else if ((parser_result->layer3_type == L3_TYPE_ETHEROAM)
            && (parser_result->l3_s.ip_da.eth_oam.eth_oam_level == 0)
            && !pkt_info->from_cpu_or_oam
            && epe_nexthop_ctl.link_oam_discard_en)*/
    else if ((parser_result->layer3_type == L3_TYPE_ETHEROAM)
            && (parser_result->l3_s.ip_da.eth_oam.eth_oam_level == 0)
            && !pkt_info->from_cpu_or_oam 
            && epe_nexthop_ctl.link_oam_discard_en && non_mirror_packet)
    /*=========bug 4690 ECO end=========*/
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_OAM_FILTERING_DISCARD;
            pkt_info->discard = TRUE;
        }
    }
    else if ((pkt_info->pbb_dest_port_type == PBB_PORT_TYPE_PIP)
            && oam_valid
            && epe_nexthop_ctl.pbb_bv_oam_on_egs_pip_en)
    {
        /* I am not sure if we need to terminate this type of pbb-bv,so reg is added to control
           if terminate while mep not found */
        pkt_info->rx_oam_type = epe_nexthop_ctl.terminate_pbb_bv_oam_on_egs_pip ? OAM_PBB_BV : OAM_ETHER;
    }
    else if ((pkt_info->pbb_dest_port_type == PBB_PORT_TYPE_CBP) && oam_valid)
    {
        pkt_info->rx_oam_type = OAM_PBB_BV; /* pbb-bv */
    }
    else if ((pkt_info->pbb_dest_port_type == PBB_PORT_TYPE_CBP)
            && (parser_result->layer4_type == L4_TYPE_PBB_ITAG_OAM)
            && (parser_result->layer3_type == L3_TYPE_CMAC)
            && epe_nexthop_ctl.pbb_bsi_oam_on_egs_cbp_en
            && non_mirror_packet)
    {
        pkt_info->rx_oam_type = OAM_PBB_BSI;    /* pbb-bsi */
    }

    mac_sa_47_to_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
    mac_sa_31_to_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                 parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
    is_ether_type = ((parser_result->layer2_type == L2_TYPE_ETHSAP)
                    || (parser_result->layer2_type == L2_TYPE_ETHV2)
                    || (parser_result->layer2_type == L2_TYPE_ETHSNAP));

    is_same_mac = ((mac_sa_47_to_32 == mac_da_47_to_32) && (mac_sa_31_to_0 == mac_da_31_to_0));
    is_same_v4_ip = (parser_result->l3_s.ip_da.ipv4.ipda == parser_result->l3_s.ip_sa.ipv4.ipsa);
    is_same_v6_ip = ((parser_result->l3_s.ip_da.ipv6.ipda_31_0 == parser_result->l3_s.ip_sa.ipv6.ipsa_31_0)
                    && (parser_result->l3_s.ip_da.ipv6.ipda_63_32 == parser_result->l3_s.ip_sa.ipv6.ipsa_63_32)
                    && (parser_result->l3_s.ip_da.ipv6.ipda_95_64 == parser_result->l3_s.ip_sa.ipv6.ipsa_95_64)
                    && (parser_result->l3_s.ip_da.ipv6.ipda_127_96 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96));
    if ((is_ether_type && is_same_mac && epe_nexthop_ctl.discard_same_mac_addr)
        || ((((parser_result->layer3_type == L3_TYPE_IPV4) && is_same_v4_ip)
              || ((parser_result->layer3_type == L3_TYPE_IPV6) && is_same_v6_ip))
            && epe_nexthop_ctl.discard_same_ip_addr))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_IPDA_EQUALS_TO_IPSA_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE discard sam mac or sam ip packet!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (!pkt_info->routed_port && p_epe_user_id_info->egress_filtering_en && (!IS_BIT_SET(pkt_info->dest_vlan_ptr, 12))
        && (pkt_info->local_phy_port < MAX_NETWORK_PORT_WO_MUX))
    {
        if (!p_epe_user_id_info->vlan_id_valid)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_EGRESS_VLAN_FILTER_DISCARD;

                if (pkt_info->rx_oam_type != OAM_ETHER)
                {
                    pkt_info->discard = TRUE;
                }
                else if (!p_epe_user_id_info->link_oam)
                {
                    pkt_info->ether_oam_discard = TRUE;
                }
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE vlan filtering failed,port:%d,vlan:%d\n",pkt_info->local_phy_port,pkt_info->dest_vlan_ptr);
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    if (pkt_info->stp_check_en && !pkt_info->routed_port)
    {
        ds_stp_state_index = (pkt_info->local_phy_port << epe_nexthop_ctl.ds_stp_state_shift)
                                + ((pkt_info->stp_id >> 4) & 0x7);

        stp_field_offset = pkt_info->stp_id & 0xF;

        cmd = DRV_IOR(DsStpState_t, DsStpState_StpState0_f + stp_field_offset);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ds_stp_state_index, cmd, &stp_field_value));

        stp_state = stp_field_value & 0x3;
    }
    else
    {
        stp_state = STP_FORWARDING;    /* Forwarding */
    }

    route_or_mpls = (CM_PLD_OP_ROUTE == pkt_info->payload_operation)
                    || (CM_PLD_OP_ROUTE_COMPACT == pkt_info->payload_operation)
                    || (CM_PLD_OP_ROUTE_NOTTL == pkt_info->payload_operation);

    if ((STP_FORWARDING != stp_state)
            && (STP_INVALID != stp_state)
            && (!pkt_info->from_cpu_or_oam || pkt_info->is_up)
            && (!route_or_mpls || (route_or_mpls && epe_nexthop_ctl.route_obey_stp)))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_STP_DISCARD;
            if (pkt_info->rx_oam_type != OAM_ETHER)
            {
                pkt_info->discard = TRUE;    /* invalid VLAN discard */
            }
            else if (!p_epe_user_id_info->link_oam)
            {
                pkt_info->ether_oam_discard = TRUE;
            }
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE stp state check fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_nexthop_mapper_map_priority
 * Purpose:   Map priority.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_nexthop_mapper_map_priority(epe_in_pkt_t* ipkt,epe_user_id_info_t* p_epe_user_id_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *) ipkt->pkt_info;
    epe_edit_priority_map_t epe_edit_priority_map;
    uint32 cmd = 0;
    uint32 map_index = 0;

    /* MAP_PRIORITY */
    map_index = (p_epe_user_id_info->qos_domain << 8) | (pkt_info->priority << 2) | pkt_info->color;

    sal_memset(&epe_edit_priority_map, 0, sizeof(epe_edit_priority_map_t));
    cmd = DRV_IOR(EpeEditPriorityMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, map_index, cmd, &epe_edit_priority_map));

    pkt_info->mapped_dscp = epe_edit_priority_map.dscp;
    pkt_info->mapped_cos = epe_edit_priority_map.cos;
    pkt_info->mapped_exp = epe_edit_priority_map.exp;
    pkt_info->mapped_cfi = epe_edit_priority_map.cfi;

    return DRV_E_NONE;
}
/****************************************************************************
 * Name:       cm_epe_nexthop_mapper_handle
 * Purpose:    Retrieves next hop information including egress processing
               and editing instructions. process egress interfaces information
               such as port and VLAN information.
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                      header ,and processing information
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                      header ,and processing information
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_epe_nexthop_mapper_handle(epe_in_pkt_t* ipkt)
{
    epe_user_id_info_t epe_user_id_info;
    userid_lookup_extra_result_t userid_lookup_result_info_hash1;
    userid_lookup_extra_result_t userid_lookup_result_info_hash2;

    ds_vlan_xlate_t hash1_ds_vlan_xlate;
    ds_vlan_xlate_t hash2_ds_vlan_xlate;
    ds_vlan_xlate_t tcam_ds_vlan_xlate;

    DRV_PTR_VALID_CHECK(ipkt);

    sal_memset(&userid_lookup_result_info_hash1, 0, sizeof(userid_lookup_extra_result_t));
    sal_memset(&userid_lookup_result_info_hash2, 0, sizeof(userid_lookup_extra_result_t));
    sal_memset(&epe_user_id_info, 0, sizeof(epe_user_id_info_t));
    sal_memset(&hash1_ds_vlan_xlate, 0, sizeof(ds_vlan_xlate_t));
    sal_memset(&hash2_ds_vlan_xlate, 0, sizeof(ds_vlan_xlate_t));
    sal_memset(&tcam_ds_vlan_xlate, 0, sizeof(ds_vlan_xlate_t));

    userid_lookup_result_info_hash1.default_entry_valid = FALSE;
    userid_lookup_result_info_hash1.data = &hash1_ds_vlan_xlate;
    userid_lookup_result_info_hash2.default_entry_valid = FALSE;
    userid_lookup_result_info_hash2.data = &hash2_ds_vlan_xlate;

    epe_user_id_info.per_lookup[USER_ID_LOOKUP1].hash_lookup_result.extra = &userid_lookup_result_info_hash1;
    epe_user_id_info.per_lookup[USER_ID_LOOKUP2].hash_lookup_result.extra = &userid_lookup_result_info_hash2;
    epe_user_id_info.tcam_lookup_result.tcam_lkp_output[0].ds_ad = &tcam_ds_vlan_xlate;

    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_get_dsnexthop(ipkt, &epe_user_id_info));
    if (epe_user_id_info.is_end)
    {
        return DRV_E_NONE;
    }

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE NextHop Mapper Process");

    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_get_dest_port(ipkt,&epe_user_id_info));
    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_vlan_hash_type(ipkt, &epe_user_id_info));
    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_vlan_hash_lookup(ipkt, &epe_user_id_info));
    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_vlan_lookup_result(ipkt, &epe_user_id_info));
    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_get_dest_vlan_interface(ipkt,&epe_user_id_info));
    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_overwrite_routing(ipkt, &epe_user_id_info));
    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_lookup_editing_ds(ipkt, &epe_user_id_info));
    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_bridge_discard(ipkt, &epe_user_id_info));
    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_filtering(ipkt,&epe_user_id_info));
    DRV_IF_ERROR_RETURN(_cm_epe_nexthop_mapper_map_priority(ipkt, &epe_user_id_info));
    return DRV_E_NONE;
}

