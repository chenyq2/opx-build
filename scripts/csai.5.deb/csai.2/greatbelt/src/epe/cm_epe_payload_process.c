/****************************************************************************
 * cm_epe_payload_process.c  Provides EPE payload process function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-10-22.
 * Reason:       First Create.
 *
 * Revision:     V1.0.
 * Author:       JiaK.
 * Date:         2010-11-18.
 * Reason:       Sync spec Revision 5.0.0.
 *
 * Revision:     V4.2.1
 * Author:       JiaK.
 * Date:         2011-06-30.
 * Reason:       Sync spec revision 4.2.1.
 *
 * Revision:     V4.3.0
 * Author:       JiaK.
 * Date:         2011-07-11.
 * Reason:       Sync spec revision 4.3.0.
 *
 * Revision:     V4.5.1
 * Author:       JiaK.
 * Date:         2011-07-11.
 * Reason:       Sync spec revision 4.5.1.
 *
 * Revision:     V4.7.1
 * Author:       JiaK.
 * Date:         2011-07-28.
 * Reason:       Sync spec revision 4.7.1.
 *
 * Revision:     V4.28
 * Author:       JiaK.
 * Date:         2011-09-28.
 * Reason:       Sync spec revision 4.28.
 *
 * Revision:     V4.29.3
 * Author:       JiaK.
 * Date:         2011-10-10.
 * Reason:       Sync spec revision 4.29.3
 *
 * Revision:     V4.31.0
 * Author:       JiaK.
 * Date:         2011-10-22.
 * Reason:       sync spec to v4.31.0
 *
 * Revision:     V5.1.0
 * Author:       JiaK.
 * Date:         2011-12-9.
 * Reason:       sync spec to v5.1.0
 *
 * Revision:     V5.6.0
 * Author:       JiaK.
 * Date:         2012-01-7.
 * Reason:       sync spec to v5.6.0
 *
 * Revision:     V5.9.0
 * Author:       JiaK.
 * Date:         2012-01-19.
 * Reason:       sync spec to v5.9.0
 *
 * Revision:     V5.9.1
 * Author:       Wangcy.
 * Date:         2012-02-04.
 * Reason:       sync spec to v5.9.1
 *
 * Revision:     V5.11.0
 * Author:       Wangcy.
 * Date:         2012-03-01.
 * Reason:       sync spec to v5.11.0
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "ctcutil_lib.h"


/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/
/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
extern uint16 func_packet_length_adjust_add(epe_in_pkt_t* ipkt, uint8 a);
extern uint16 func_packet_length_adjust_subtract(epe_in_pkt_t* ipkt, uint8 a);

struct epe_payload_proc_info_s
{
    uint32 bridge_inner:1;
};

typedef struct epe_payload_proc_info_s epe_payload_proc_info_t;

/****************************************************************************
 * Name:      _cm_epe_payload_process_mpls
 * Purpose:   Perform mpls payload operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_payload_process_mpls(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_pkt_proc_ctl_t epe_pkt_proc_tcl;

    uint32 cmd = 0;

    /* PACKET_TYPE */
    pkt_info->strip_offset = parser_result->l2_s.layer3_offset;
    pkt_info->packet_type = PKT_TYPE_MPLS;
    parser_result->layer2_type = L2_TYPE_NONE;    /* Remove layer2 */

    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* TTL_DSCP */
    if ((CM_PLD_OP_ROUTE_NOTTL != pkt_info->payload_operation) && !pkt_info->ttl_no_decrease)
    {
        pkt_info->new_ttl = (pkt_info->packet_ttl > 1) ? (pkt_info->packet_ttl - 1) : 0;   /* Decrement TTL */
        pkt_info->new_ttl_valid = TRUE;    /* indicate replace TTL */
        pkt_info->packet_ttl = pkt_info->new_ttl;
    }
    else
    {
        pkt_info->new_ttl_valid = FALSE;   /* pipe, short pipe */
    }

    sal_memset(&epe_pkt_proc_tcl, 0, sizeof(epe_pkt_proc_tcl));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0,cmd, &epe_pkt_proc_tcl));

    if ((0 == pkt_info->new_ttl) && pkt_info->new_ttl_valid && epe_pkt_proc_tcl.discard_mpls_ttl0)
    {
        if (!pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 2;
        }

        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_TTL_FAIL;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE MPLSTtl=0 and DiscardMplsTtl0 is set!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (pkt_info->replace_dscp)
    {
        pkt_info->new_dscp_valid = TRUE;

        if (pkt_info->copy_dscp)
        {
            pkt_info->new_dscp = ((pkt_info->src_dscp >> 3) << 3);
        }
        else
        {
            pkt_info->new_dscp = (pkt_info->mapped_exp << 3);
        }

        parser_result->l3_s.ip_da.mpls.mpls_label0 = (parser_result->l3_s.ip_da.mpls.mpls_label0 & 0xFFFFF1FF)
                                                     | (((pkt_info->new_dscp >> 3) & 0x7) << 9);
        pkt_info->section_lm_exp = (pkt_info->src_dscp >> 3)& 0x7;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_payload_process_trill
 * Purpose:   Perform trill payload operations.
 * Parameters:
 *  Input:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
 _cm_epe_payload_process_trill(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_pkt_proc_ctl_t epe_pkt_proc_tcl;

    //uint8 non_trill = FALSE;
    uint32 cmd = 0;

    /* PACKET_TYPE */
    pkt_info->strip_offset = parser_result->l2_s.layer3_offset ;
    pkt_info->packet_type = PKT_TYPE_TRILL;
    parser_result->layer2_type = L2_TYPE_NONE;    /* Remove layer2 */

    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* TTL */
    if ((CM_PLD_OP_ROUTE_NOTTL != pkt_info->payload_operation) && !pkt_info->ttl_no_decrease)
    {
        pkt_info->new_ttl = (pkt_info->packet_ttl > 1) ? (pkt_info->packet_ttl - 1) : 0;    /* Decrement TTL */
    }
    else
    {
        pkt_info->new_ttl = pkt_info->packet_ttl;
    }

    pkt_info->new_ttl_valid = TRUE;                /* indicate replace TTL */
    pkt_info->packet_ttl = pkt_info->new_ttl;

    sal_memset(&epe_pkt_proc_tcl, 0, sizeof(epe_pkt_proc_tcl));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0,cmd, &epe_pkt_proc_tcl));

    if ((0 == pkt_info->new_ttl) && epe_pkt_proc_tcl.discard_trill_ttl0)
    {
        if (!pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 2;
        }

        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_TTL_FAIL;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE TrillTtl=0 and DiscardTillTtl0 is set!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_epe_payload_process_route
 * Purpose:    Perform routing operations.
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_epe_payload_process_route(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_pkt_proc_ctl_t epe_pkt_proc_tcl;

    uint8 non_ip = 0;
    uint8 ipv4_mcast_address = 0;
    uint8 ipv6_mcast_address = 0;
    uint32 cmd = 0;

    /* PACKET_TYPE */
    /* For IPv4 */
    ipv4_mcast_address = (L3_TYPE_IPV4 == parser_result->layer3_type)
                         && (0xE == (parser_result->l3_s.ip_da.ipv4.ipda >> 28));
    /* For IPv6 */
    ipv6_mcast_address = (L3_TYPE_IPV6 == parser_result->layer3_type)
                         && (0xFF == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24));

    non_ip = (L3_TYPE_IPV4 != parser_result->layer3_type) && (L3_TYPE_IPV6 != parser_result->layer3_type);

    if (non_ip)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_ROUTE_PAYLOAD_OPERATION_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Route PayloadOP but is not IP packet!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    pkt_info->strip_offset = parser_result->l2_s.layer3_offset;

    if (L3_TYPE_IPV6 == parser_result->layer3_type)
    {
        pkt_info->packet_type = PKT_TYPE_IPV6;
    }
    else
    {
        pkt_info->packet_type = PKT_TYPE_IPV4;
    }

    parser_result->layer2_type = L2_TYPE_NONE;    /* Remove layer2 */

    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* TTL_DSCP */
    if ((CM_PLD_OP_ROUTE_NOTTL != pkt_info->payload_operation) && !pkt_info->ttl_no_decrease)
    {
        pkt_info->new_ttl = (pkt_info->packet_ttl > 1) ? (pkt_info->packet_ttl - 1) : 0;    /* Decrease TTl */
    }
    else
    {
        pkt_info->new_ttl = pkt_info->packet_ttl;
    }

    pkt_info->new_ttl_valid = TRUE;                   /* indicate replace TTL */

    if ((ipv4_mcast_address || ipv6_mcast_address)
       && (pkt_info->packet_ttl <= pkt_info->mcast_ttl_threshold))
    {
        if (!pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 2;
        }

        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_TTL_FAIL;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE IpMc but PktTtl <= McastTtlThreshold!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    pkt_info->packet_ttl = pkt_info->new_ttl;    /* Update packet's TTL */

    sal_memset(&epe_pkt_proc_tcl, 0, sizeof(epe_pkt_proc_tcl));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_tcl));

    if ((0 == pkt_info->new_ttl) && epe_pkt_proc_tcl.discard_route_ttl0)
    {
        if (!pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 2;
        }

        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_TTL_FAIL;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE PktTtl=0 and DiscardRouteTtl0 is set!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (pkt_info->replace_dscp && !pkt_info->acl_dscp_valid)
    {
        pkt_info->new_dscp_valid = TRUE;

        if (pkt_info->copy_dscp)
        {
            pkt_info->new_dscp = pkt_info->src_dscp;
        }
        else
        {
            pkt_info->new_dscp = pkt_info->mapped_dscp;
        }
    }

    /* IP_CHECK_SUM */

    if (pkt_info->new_dscp_valid)
    {
        parser_result->l3_s.tos.ip_tos = (pkt_info->new_dscp << 2) | (parser_result->l3_s.tos.ip_tos & 0x3);
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_payload_process_bridge_greatbelt init
 * Purpose:   Perform payload bridging greatbelt operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_payload_process_bridge_greatbelt_init(epe_in_pkt_t* ipkt,epe_payload_proc_info_t *p_epe_payload_proc_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_l2_tpid_ctl_t epe_l2_tpid_ctl;
    epe_pkt_proc_ctl_t epe_pkt_proc_tcl;

    uint8 bridge_inner = 0;
    uint8 untag_default_vlan = 0;
    uint32 cmd = 0;
    uint8 dot1q_en0 = 0, dot1q_en1 = 0;
    uint8 update_stag_parser_result_info = FALSE, update_ctag_parser_result_info = FALSE;
    uint8 new_stag_cos = 0, new_ctag_cos = 0;
    uint8 new_stag_cfi = 0, new_ctag_cfi = 0;
    uint16 new_svlan_id = 0, new_cvlan_id = 0;
    uint16 new_svlan_tpid = 0, new_cvlan_tpid = 0;
    uint16 tmp_svlan_tpid_index = 0;
    uint8 svlan_id_valid = 0,cvlan_id_valid = 0;

    sal_memset(&epe_l2_tpid_ctl, 0, sizeof(epe_l2_tpid_ctl));
    cmd = DRV_IOR(EpeL2TpidCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_tpid_ctl));

    sal_memset(&epe_pkt_proc_tcl, 0, sizeof(epe_pkt_proc_tcl));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_tcl));

    /* OUTER_TAG */
    /* GreatBelt egress bridge process */
    bridge_inner = p_epe_payload_proc_info->bridge_inner;

    untag_default_vlan = !bridge_inner && pkt_info->untag_default_vlan_id && pkt_info->untag_default_svlan
                         && (parser_result->l2_s.svlan_id == pkt_info->default_vlan_id);

    dot1q_en1 = bridge_inner || IS_BIT_SET(pkt_info->dot1_q_en, 1); /* consider bridgeInner */

    if ((pkt_info->stag_operation_disable && !bridge_inner) || pkt_info->svlan_tag_disable)/* DsDestPort.stagOperationDisable, DsNextHop.svlanTagDisable */
    {
        pkt_info->svlan_tag_operation = VTAG_OP_NONE;
        update_stag_parser_result_info = FALSE;
    }
    else if (pkt_info->svlan_xlate_valid && (USERID_STAG_ACTION_ADD == pkt_info->stag_action))
    {
        pkt_info->svlan_tag_operation = VTAG_OP_ADD;
        update_stag_parser_result_info = TRUE;
        svlan_id_valid = TRUE;

        if ((USERID_SVLAN_ID_ACTION_NONE == pkt_info->svlan_id_action)
            && parser_result->l2_s.svlan_id_valid)
        {
            new_svlan_id = parser_result->l2_s.svlan_id;
        }
        else if ((USERID_SVLAN_ID_ACTION_NONE == pkt_info->svlan_id_action)
            && !parser_result->l2_s.svlan_id_valid)
        {
            new_svlan_id = pkt_info->default_vlan_id;
        }
        else if ((USERID_SVLAN_ID_ACTION_SWAP == pkt_info->svlan_id_action)
            && parser_result->l2_s.cvlan_id_valid)
        {
            new_svlan_id = parser_result->l2_s.cvlan_id;
        }
        else if ((USERID_SVLAN_ID_ACTION_SWAP == pkt_info->svlan_id_action)
            && !parser_result->l2_s.cvlan_id_valid)
        {
            new_svlan_id = pkt_info->default_vlan_id;
        }
        else if (USERID_SVLAN_ID_ACTION_USER == pkt_info->svlan_id_action)
        {
            new_svlan_id = pkt_info->xlate_svlan_id;
        }

        if ((USERID_SCOS_ACTION_NONE == pkt_info->stag_cos_action)
            && parser_result->l2_s.svlan_id_valid)
        {
            new_stag_cos = parser_result->l2_s.stag_cos;
        }
        else if ((USERID_SCOS_ACTION_NONE == pkt_info->stag_cos_action)
            && !parser_result->l2_s.svlan_id_valid)
        {
            new_stag_cos = pkt_info->source_cos;
        }
        else if ((USERID_SCOS_ACTION_SWAP == pkt_info->stag_cos_action)
            && parser_result->l2_s.cvlan_id_valid)
        {
            new_stag_cos = parser_result->l2_s.ctag_cos;
        }
        else if ((USERID_SCOS_ACTION_SWAP == pkt_info->stag_cos_action)
            && !parser_result->l2_s.cvlan_id_valid)
        {
            new_stag_cos = pkt_info->source_cos;
        }
        else if (USERID_SCOS_ACTION_USER == pkt_info->stag_cos_action)
        {
            new_stag_cos = pkt_info->xlate_stag_cos;
        }
        else    /* must be mapped */
        {
            new_stag_cos = pkt_info->mapped_cos;
        }

        if ((USERID_SCFI_ACTION_NONE == pkt_info->s_cfi_action)
            && parser_result->l2_s.svlan_id_valid)
        {
            new_stag_cfi = parser_result->l2_s.stag_cfi;
        }
        else if ((USERID_SCFI_ACTION_NONE == pkt_info->s_cfi_action)
            && !parser_result->l2_s.svlan_id_valid)
        {
            new_stag_cfi = pkt_info->source_cfi;
        }
        else if ((USERID_SCFI_ACTION_SWAP == pkt_info->s_cfi_action)
            && parser_result->l2_s.cvlan_id_valid)
        {
            new_stag_cfi = parser_result->l2_s.ctag_cfi;
        }
        else if ((USERID_SCFI_ACTION_SWAP == pkt_info->s_cfi_action)
            && !parser_result->l2_s.cvlan_id_valid)
        {
            new_stag_cfi = pkt_info->source_cfi;
        }
        else if (USERID_SCFI_ACTION_USER == pkt_info->s_cfi_action)
        {
            new_stag_cfi = pkt_info->xlate_stag_cfi;
        }
        else    /* must be mapped */
        {
            new_stag_cfi = pkt_info->mapped_cfi;
        }

        pkt_info->oam_vlan = new_svlan_id;
    }
    else if (!parser_result->l2_s.svlan_id_valid)  /* untagged */
    {
        if (dot1q_en1 && !untag_default_vlan && (pkt_info->svlan_tagged || !epe_pkt_proc_tcl.next_hop_stag_ctl_en) &&
                pkt_info->output_svlan_id_valid)
        {
            pkt_info->svlan_tag_operation = VTAG_OP_ADD;
            update_stag_parser_result_info = TRUE;

            svlan_id_valid = TRUE;
            new_svlan_id = pkt_info->output_svlan_id;

            if (pkt_info->replace_stag_cos)
            {
                new_stag_cos = pkt_info->mapped_cos;
                new_stag_cfi = pkt_info->mapped_cfi;
            }
            else
            {
                new_stag_cos = pkt_info->source_cos;
                new_stag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi:pkt_info->source_cfi;
            }


            pkt_info->oam_vlan = new_svlan_id;
        }
        else if (pkt_info->priority_tag_en && !pkt_info->cvlan_space)
        {
            pkt_info->svlan_tag_operation = VTAG_OP_ADD;
            update_stag_parser_result_info = TRUE;

            svlan_id_valid = TRUE;
            new_svlan_id = 0;

            if (pkt_info->replace_stag_cos)
            {
                new_stag_cos =pkt_info->mapped_cos;
                new_stag_cfi = pkt_info->mapped_cfi;
            }
            else
            {
                new_stag_cos = pkt_info->source_cos;
                new_stag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi:pkt_info->source_cfi;
            }
        }
        else
        {
            pkt_info->svlan_tag_operation = VTAG_OP_NONE;
            update_stag_parser_result_info = FALSE;
        }

        if (pkt_info->svlan_xlate_valid)
        {
            pkt_info->svlan_tag_operation = VTAG_OP_NONE;
            update_stag_parser_result_info = FALSE;
        }
    }
    else    /* tagged or priority tagged */
    {
        if (parser_result->l2_s.svlan_id_valid && (0 == parser_result->l2_s.svlan_id)) /* priority tagged */
        {
            if (dot1q_en1 && !untag_default_vlan && (pkt_info->svlan_tagged || !epe_pkt_proc_tcl.next_hop_stag_ctl_en) &&
                pkt_info->output_svlan_id_valid)
            {
                pkt_info->svlan_tag_operation = VTAG_OP_REPLACE;
                update_stag_parser_result_info = TRUE;

                svlan_id_valid = TRUE;
                new_svlan_id = pkt_info->output_svlan_id;

                if (pkt_info->replace_stag_cos)
                {
                    new_stag_cos =pkt_info->mapped_cos;
                    new_stag_cfi = pkt_info->mapped_cfi;
                }
                else
                {
                    new_stag_cos = parser_result->l2_s.stag_cos;
                    new_stag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi:parser_result->l2_s.stag_cfi;
                }
            }
            else if (pkt_info->priority_tag_en && !pkt_info->cvlan_space)
            {
                pkt_info->svlan_tag_operation = VTAG_OP_REPLACE;
                update_stag_parser_result_info = TRUE;

                svlan_id_valid = TRUE;
                new_svlan_id = 0;

                if (pkt_info->replace_stag_cos)
                {
                    new_stag_cos =pkt_info->mapped_cos;
                    new_stag_cfi = pkt_info->mapped_cfi;
                }
                else
                {
                    new_stag_cos = parser_result->l2_s.stag_cos;
                    new_stag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi:parser_result->l2_s.stag_cfi;
                }
            }
            else
            {
                pkt_info->svlan_tag_operation = VTAG_OP_DELETE;
                update_stag_parser_result_info = TRUE;

                svlan_id_valid = FALSE;
                new_svlan_id = 0;

                new_stag_cos = 0;
                new_stag_cfi = 0;
            }
        }
        else if ((dot1q_en1 && untag_default_vlan) || !dot1q_en1 || (!pkt_info->svlan_tagged && epe_pkt_proc_tcl.next_hop_stag_ctl_en))  /* tagged */
        {
            if (pkt_info->priority_tag_en && !pkt_info->cvlan_space)
            {
                pkt_info->svlan_tag_operation = VTAG_OP_REPLACE;
                update_stag_parser_result_info = TRUE;

                svlan_id_valid = TRUE;
                new_svlan_id = 0;

                if (pkt_info->replace_stag_cos)
                {
                    new_stag_cos = pkt_info->mapped_cos;
                    new_stag_cfi = pkt_info->mapped_cfi;
                }
                else
                {
                    new_stag_cos = parser_result->l2_s.stag_cos;
                    new_stag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi:parser_result->l2_s.stag_cfi;
                }
            }
            else
            {
                pkt_info->svlan_tag_operation = VTAG_OP_DELETE;
                update_stag_parser_result_info = TRUE;

                svlan_id_valid = FALSE;
                new_svlan_id = 0;

                new_stag_cos = 0;
                new_stag_cfi = 0;
            }
        }
        else if (pkt_info->replace_stag_cos)
        {
            pkt_info->svlan_tag_operation = VTAG_OP_REPLACE;
            update_stag_parser_result_info = TRUE;

            svlan_id_valid = TRUE;
            new_svlan_id = parser_result->l2_s.svlan_id;

            new_stag_cos = pkt_info->mapped_cos;
            new_stag_cfi = pkt_info->mapped_cfi;
        }
        else
        {
            pkt_info->svlan_tag_operation = VTAG_OP_NONE;
            update_stag_parser_result_info = FALSE;
        }

        if (pkt_info->svlan_xlate_valid)
        {
            if (USERID_STAG_ACTION_MODIFY == pkt_info->stag_action)
            {
                pkt_info->svlan_tag_operation = VTAG_OP_REPLACE;
                update_stag_parser_result_info = TRUE;
                svlan_id_valid = TRUE;

                if (USERID_SVLAN_ID_ACTION_NONE == pkt_info->svlan_id_action)
                {
                    new_svlan_id = parser_result->l2_s.svlan_id;
                }
                else if ((USERID_SVLAN_ID_ACTION_SWAP == pkt_info->svlan_id_action)
                    && parser_result->l2_s.cvlan_id_valid)
                {
                    new_svlan_id = parser_result->l2_s.cvlan_id;
                }
                else if ((USERID_SVLAN_ID_ACTION_SWAP == pkt_info->svlan_id_action)
                    && !parser_result->l2_s.cvlan_id_valid)
                {
                    new_svlan_id = pkt_info->default_vlan_id;
                }
                else if (USERID_SVLAN_ID_ACTION_USER == pkt_info->svlan_id_action)
                {
                    new_svlan_id = pkt_info->xlate_svlan_id;
                }

                if (USERID_SCOS_ACTION_NONE == pkt_info->stag_cos_action)
                {
                    new_stag_cos = parser_result->l2_s.stag_cos;
                }
                else if ((USERID_SCOS_ACTION_SWAP == pkt_info->stag_cos_action)
                    && parser_result->l2_s.cvlan_id_valid)
                {
                    new_stag_cos = parser_result->l2_s.ctag_cos;
                }
                else if ((USERID_SCOS_ACTION_SWAP == pkt_info->stag_cos_action)
                    && !parser_result->l2_s.cvlan_id_valid)
                {
                    new_stag_cos = pkt_info->source_cos;
                }
                else if (USERID_SCOS_ACTION_USER == pkt_info->stag_cos_action)
                {
                    new_stag_cos = pkt_info->xlate_stag_cos;
                }
                else    /* must mapped */
                {
                    new_stag_cos = pkt_info->mapped_cos;
                }

                if (USERID_SCFI_ACTION_NONE == pkt_info->s_cfi_action)
                {
                    new_stag_cfi = parser_result->l2_s.stag_cfi;
                }
                else if ((USERID_SCFI_ACTION_SWAP == pkt_info->s_cfi_action)
                    && parser_result->l2_s.cvlan_id_valid)
                {
                    new_stag_cfi = parser_result->l2_s.ctag_cfi;
                }
                else if ((USERID_SCFI_ACTION_SWAP == pkt_info->s_cfi_action)
                    && !parser_result->l2_s.cvlan_id_valid)
                {
                    new_stag_cfi = pkt_info->source_cfi;
                }
                else if (USERID_SCFI_ACTION_USER == pkt_info->s_cfi_action)
                {
                    new_stag_cfi = pkt_info->xlate_stag_cfi;
                }
                else    /* must be mapped */
                {
                    new_stag_cfi = pkt_info->mapped_cfi;
                }
            }
            else if (USERID_STAG_ACTION_DELETE == pkt_info->stag_action)
            {
                pkt_info->svlan_tag_operation = VTAG_OP_DELETE;
                update_stag_parser_result_info = TRUE;

                svlan_id_valid = FALSE;
                new_svlan_id = 0;

                new_stag_cos = 0;
                new_stag_cfi = 0;
            }
            else
            {
                pkt_info->svlan_tag_operation = VTAG_OP_NONE;
                update_stag_parser_result_info = FALSE;
            }
        }
    }

    if (pkt_info->xlate_svlan_tpid_index_en)
    {
        tmp_svlan_tpid_index = pkt_info->xlate_svlan_tpid_index;
    }
    else
    {
        tmp_svlan_tpid_index = (pkt_info->inner_svlan_tpid_en)?
                                pkt_info->inner_svlan_tpid_index : pkt_info->svlan_tpid_index;
    }

    switch (tmp_svlan_tpid_index)
    {
        case 0:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid0;
            break;
        case 1:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid1;
            break;
        case 2:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid2;
            break;
        case 3:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid3;
            break;
        default:
            break;
    }

    pkt_info->l2_new_svlan_tag = (new_svlan_tpid << 16)
                                 | (new_stag_cos << 13)
                                 | (new_stag_cfi << 12)
                                 | new_svlan_id;
    pkt_info->output_svlan_id = new_svlan_id;

    /* INNER_TAG */
    /* GreatBelt egress bridge process */
    untag_default_vlan = !bridge_inner && pkt_info->untag_default_vlan_id && !pkt_info->untag_default_svlan
                         && (parser_result->l2_s.cvlan_id == pkt_info->default_vlan_id);

    dot1q_en0 = bridge_inner || IS_BIT_SET(pkt_info->dot1_q_en, 0);    /* Consider bridgeInner */

    if ((pkt_info->ctag_operation_disable && !bridge_inner) || pkt_info->cvlan_tag_disable)
    {
        pkt_info->cvlan_tag_operation = VTAG_OP_NONE;
        update_ctag_parser_result_info = FALSE;
    }
    else if (pkt_info->cvlan_xlate_valid && (USERID_CTAG_ACTION_ADD == pkt_info->ctag_action))
    {
        pkt_info->cvlan_tag_operation = VTAG_OP_ADD;
        update_ctag_parser_result_info = TRUE;
        cvlan_id_valid = TRUE;

        pkt_info->cvlan_id_offset_type = parser_result->l2_s.svlan_id_valid ?
                                (!pkt_info->ctag_add_mode) : CTAG_OFFSET_TYPE_AFTER_MAC;

        if ((USERID_CVLAN_ID_ACTION_NONE == pkt_info->cvlan_id_action)
            && parser_result->l2_s.cvlan_id_valid)
        {
            new_cvlan_id = parser_result->l2_s.cvlan_id;
        }
        else if ((USERID_CVLAN_ID_ACTION_NONE == pkt_info->cvlan_id_action)
            && !parser_result->l2_s.cvlan_id_valid)
        {
            new_cvlan_id = pkt_info->default_vlan_id;
        }
        else if ((USERID_CVLAN_ID_ACTION_SWAP == pkt_info->cvlan_id_action)
            && parser_result->l2_s.svlan_id_valid)
        {
            new_cvlan_id = parser_result->l2_s.svlan_id;
        }
        else if ((USERID_CVLAN_ID_ACTION_SWAP == pkt_info->cvlan_id_action)
            && !parser_result->l2_s.svlan_id_valid)
        {
            new_cvlan_id = pkt_info->default_vlan_id;
        }
        else if (USERID_CVLAN_ID_ACTION_USER == pkt_info->cvlan_id_action)
        {
            new_cvlan_id = pkt_info->xlate_cvlan_id;
        }

        if ((USERID_CCOS_ACTION_NONE == pkt_info->ctag_cos_action)
            && parser_result->l2_s.cvlan_id_valid)
        {
            new_ctag_cos = parser_result->l2_s.ctag_cos;
        }
        else if ((USERID_CCOS_ACTION_NONE == pkt_info->ctag_cos_action)
            && !parser_result->l2_s.cvlan_id_valid)
        {
            new_ctag_cos = pkt_info->source_cos;
        }
        else if ((USERID_CCOS_ACTION_SWAP == pkt_info->ctag_cos_action)
            && parser_result->l2_s.svlan_id_valid)
        {
            new_ctag_cos = parser_result->l2_s.stag_cos;
        }
        else if ((USERID_CCOS_ACTION_SWAP == pkt_info->ctag_cos_action)
            && !parser_result->l2_s.svlan_id_valid)
        {
            new_ctag_cos = pkt_info->source_cos;
        }
        else if (USERID_CCOS_ACTION_USER == pkt_info->ctag_cos_action)
        {
            new_ctag_cos = pkt_info->xlate_ctag_cos;
        }
        else    /* must be mapped */
        {
            new_ctag_cos = pkt_info->mapped_cos;
        }

        if ((USERID_CCFI_ACTION_NONE == pkt_info->c_cfi_action)
            && parser_result->l2_s.cvlan_id_valid)
        {
            new_ctag_cfi = parser_result->l2_s.ctag_cfi;
        }
        else if ((USERID_CCFI_ACTION_NONE == pkt_info->c_cfi_action)
            && !parser_result->l2_s.cvlan_id_valid)
        {
            new_ctag_cfi = pkt_info->source_cfi;
        }
        else if ((USERID_CCFI_ACTION_SWAP == pkt_info->c_cfi_action)
            && parser_result->l2_s.svlan_id_valid)
        {
            new_ctag_cfi = parser_result->l2_s.stag_cfi;
        }
        else if ((USERID_CCFI_ACTION_SWAP == pkt_info->c_cfi_action)
            && !parser_result->l2_s.svlan_id_valid)
        {
            new_ctag_cfi = pkt_info->source_cfi;
        }
        else if (USERID_CCFI_ACTION_USER == pkt_info->c_cfi_action)
        {
            new_ctag_cfi = pkt_info->xlate_ctag_cfi;
        }
        else    /* must be mapped */
        {
            new_ctag_cfi = pkt_info->mapped_cfi;
        }

    }
    else if (!parser_result->l2_s.cvlan_id_valid) /* untagged */
    {
        if (dot1q_en0 && !untag_default_vlan && pkt_info->cvlan_space && pkt_info->output_cvlan_id_valid)
        {
            pkt_info->cvlan_tag_operation = VTAG_OP_ADD;
            update_ctag_parser_result_info = TRUE;

            cvlan_id_valid = TRUE;
            pkt_info->cvlan_id_offset_type = parser_result->l2_s.svlan_id_valid ? !pkt_info->ctag_add_mode : 0;
            new_cvlan_id = pkt_info->output_cvlan_id;

            new_ctag_cos = (pkt_info->replace_ctag_cos) ? pkt_info->mapped_cos : pkt_info->source_cos;
            if (pkt_info->replace_ctag_cos)
            {
                new_ctag_cfi = pkt_info->mapped_cfi;
            }
            else
            {
                new_ctag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi:pkt_info->source_cfi;
            }
        }
        else if (pkt_info->priority_tag_en && pkt_info->cvlan_space)
        {
            pkt_info->cvlan_tag_operation = VTAG_OP_ADD;
            update_ctag_parser_result_info = TRUE;

            cvlan_id_valid = TRUE;
            pkt_info->cvlan_id_offset_type = parser_result->l2_s.svlan_id_valid ? !pkt_info->ctag_add_mode : 0;
            new_cvlan_id = 0;

            new_ctag_cos = (pkt_info->replace_ctag_cos) ? pkt_info->mapped_cos : pkt_info->source_cos;
            if (pkt_info->replace_ctag_cos)
            {
                new_ctag_cfi = pkt_info->mapped_cfi;
            }
            else
            {
                new_ctag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi:pkt_info->source_cfi;
            }
        }
        else
        {
            pkt_info->cvlan_tag_operation = VTAG_OP_NONE;
            update_ctag_parser_result_info = FALSE;
        }

        if (pkt_info->cvlan_xlate_valid)
        {
            pkt_info->cvlan_tag_operation = VTAG_OP_NONE;
            update_ctag_parser_result_info = FALSE;
        }
    }
    else  /* tagged or priority tagged*/
    {
        if (parser_result->l2_s.cvlan_id_valid && (0 == parser_result->l2_s.cvlan_id))  /* priority tagged */
        {
            if (dot1q_en0 && !untag_default_vlan && pkt_info->output_cvlan_id_valid)
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_REPLACE;
                update_ctag_parser_result_info = TRUE;

                cvlan_id_valid = TRUE;
                new_cvlan_id = pkt_info->output_cvlan_id;

                new_ctag_cos = pkt_info->replace_ctag_cos ? pkt_info->mapped_cos :parser_result->l2_s.ctag_cos;
                if (pkt_info->replace_ctag_cos)
                {
                    new_ctag_cfi = pkt_info->mapped_cfi;
                }
                else
                {
                    new_ctag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi:parser_result->l2_s.ctag_cfi;
                }
            }
             else if (pkt_info->priority_tag_en && pkt_info->cvlan_space)
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_REPLACE;
                update_ctag_parser_result_info = TRUE;

                cvlan_id_valid = TRUE;
                new_cvlan_id = 0;

                new_ctag_cos = (pkt_info->replace_ctag_cos) ? pkt_info->mapped_cos : parser_result->l2_s.ctag_cos;
                if (pkt_info->replace_ctag_cos)
                {
                    new_ctag_cfi = pkt_info->mapped_cfi;
                }
                else
                {
                    new_ctag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi:parser_result->l2_s.ctag_cfi;
                }
            }
            else
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_DELETE;
                update_ctag_parser_result_info = TRUE;

                cvlan_id_valid = FALSE;
                new_cvlan_id = 0;

                new_ctag_cos = 0;
                new_ctag_cfi = 0;
            }
        }
        else if ((dot1q_en0 && untag_default_vlan) || !dot1q_en0)  /* tagged */
        {
            if (pkt_info->priority_tag_en && pkt_info->cvlan_space)
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_REPLACE;
                update_ctag_parser_result_info = TRUE;

                cvlan_id_valid = TRUE;
                new_cvlan_id = 0;

                new_ctag_cos = (pkt_info->replace_ctag_cos) ? pkt_info->mapped_cos :parser_result->l2_s.ctag_cos;
                if (pkt_info->replace_ctag_cos)
                {
                    new_ctag_cfi = pkt_info->mapped_cfi;
                }
                else
                {
                    new_ctag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi:parser_result->l2_s.ctag_cfi;
                }
            }
            else
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_DELETE;
                update_ctag_parser_result_info = TRUE;

                cvlan_id_valid = FALSE;
                new_cvlan_id = 0;

                new_ctag_cos = 0;
                new_ctag_cfi = 0;
            }
        }
        else if (pkt_info->replace_ctag_cos)
        {
            pkt_info->cvlan_tag_operation = VTAG_OP_REPLACE;
            update_ctag_parser_result_info = TRUE;

            cvlan_id_valid = TRUE;
            new_cvlan_id = parser_result->l2_s.cvlan_id;

            new_ctag_cos = pkt_info->mapped_cos;
            new_ctag_cfi = pkt_info->mapped_cfi;
        }
        else
        {
            pkt_info->cvlan_tag_operation = VTAG_OP_NONE;
            update_ctag_parser_result_info = FALSE;
        }

        if (pkt_info->cvlan_xlate_valid)
        {
            if (USERID_CTAG_ACTION_MODIFY == pkt_info->ctag_action)
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_REPLACE;
                update_ctag_parser_result_info = TRUE;
                pkt_info->cvlan_id_offset_type = parser_result->l2_s.svlan_id_valid;
                cvlan_id_valid = TRUE;

                if (USERID_CVLAN_ID_ACTION_NONE == pkt_info->cvlan_id_action)
                {
                    new_cvlan_id = parser_result->l2_s.cvlan_id;
                }
                else if ((USERID_CVLAN_ID_ACTION_SWAP == pkt_info->cvlan_id_action)
                    && parser_result->l2_s.svlan_id_valid)
                {
                    new_cvlan_id = parser_result->l2_s.svlan_id;
                }
                else if ((USERID_CVLAN_ID_ACTION_SWAP == pkt_info->cvlan_id_action)
                    && !parser_result->l2_s.svlan_id_valid)
                {
                    new_cvlan_id = pkt_info->default_vlan_id;
                }
                else if (USERID_CVLAN_ID_ACTION_USER == pkt_info->cvlan_id_action)
                {
                    new_cvlan_id = pkt_info->xlate_cvlan_id;
                }

                if (USERID_CCOS_ACTION_NONE == pkt_info->ctag_cos_action)
                {
                    new_ctag_cos = parser_result->l2_s.ctag_cos;
                }
                else if ((USERID_CCOS_ACTION_SWAP == pkt_info->ctag_cos_action)
                    && parser_result->l2_s.svlan_id_valid)
                {
                    new_ctag_cos = parser_result->l2_s.stag_cos;
                }
                else if ((USERID_CCOS_ACTION_SWAP == pkt_info->ctag_cos_action)
                    && !parser_result->l2_s.svlan_id_valid)
                {
                    new_ctag_cos = pkt_info->source_cos;
                }
                else if (USERID_CCOS_ACTION_USER == pkt_info->ctag_cos_action)
                {
                    new_ctag_cos = pkt_info->xlate_ctag_cos;
                }
                else    /* must be mapped */
                {
                    new_ctag_cos = pkt_info->mapped_cos;
                }

                if ((USERID_CCFI_ACTION_NONE == pkt_info->c_cfi_action)
                    && parser_result->l2_s.cvlan_id_valid)
                {
                    new_ctag_cfi = parser_result->l2_s.ctag_cfi;
                }
                else if ((USERID_CCFI_ACTION_SWAP == pkt_info->c_cfi_action)
                    && parser_result->l2_s.svlan_id_valid)
                {
                    new_ctag_cfi = parser_result->l2_s.stag_cfi;
                }
                else if ((USERID_CCFI_ACTION_SWAP == pkt_info->c_cfi_action)
                    && !parser_result->l2_s.svlan_id_valid)
                {
                    new_ctag_cfi = pkt_info->source_cfi;
                }
                else if (USERID_CCFI_ACTION_USER == pkt_info->c_cfi_action)
                {
                    new_ctag_cfi = pkt_info->xlate_ctag_cfi;
                }
                else    /* must be mapped */
                {
                    new_ctag_cfi = pkt_info->mapped_cfi;
                }
            }
            else if (USERID_CTAG_ACTION_DELETE == pkt_info->ctag_action)
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_DELETE;
                update_ctag_parser_result_info = TRUE;
                cvlan_id_valid = FALSE;
                pkt_info->cvlan_id_offset_type = parser_result->l2_s.svlan_id_valid;
                new_cvlan_id = 0;
                new_ctag_cos = 0;
                new_ctag_cfi = 0;
            }
            else
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_NONE;
                update_ctag_parser_result_info = FALSE;
            }
        }
    }

    new_cvlan_tpid = epe_l2_tpid_ctl.cvlan_tpid;

    /* for acl edit vlan tag using */

    if (update_stag_parser_result_info)
    {
        parser_result->l2_s.svlan_id = new_svlan_id;
        parser_result->l2_s.stag_cos = new_stag_cos;
        parser_result->l2_s.stag_cfi = new_stag_cfi;
        parser_result->l2_s.svlan_id_valid = svlan_id_valid;
    }

    if (update_ctag_parser_result_info)
    {
        parser_result->l2_s.cvlan_id = new_cvlan_id;
        parser_result->l2_s.ctag_cos = new_ctag_cos;
        parser_result->l2_s.ctag_cfi = new_ctag_cfi;
        parser_result->l2_s.cvlan_id_valid = cvlan_id_valid;
    }

    pkt_info->l2_new_cvlan_tag = (new_cvlan_tpid << 16)
                                 | (new_ctag_cos << 13)
                                 | (new_ctag_cfi << 12)
                                 | new_cvlan_id;
    pkt_info->output_cvlan_id = new_cvlan_id;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_payload_process_bridge_humber_init
 * Purpose:   Perform payload bridging humber operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_payload_process_bridge_humber_init(epe_in_pkt_t* ipkt,epe_payload_proc_info_t* p_epe_payload_proc_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_l2_tpid_ctl_t epe_l2_tpid_ctl;
    epe_pkt_proc_ctl_t epe_pkt_proc_tcl;

    uint8 bridge_inner = 0;
    uint8 untag_default_vlan = 0;
    uint8 packet_svlan_tagged = 0;
    uint8 packet_cvlan_tagged = 0;
    uint8 dot1q_en0 = 0;
    uint8 dot1q_en1 = 0;
    uint8 new_stag_cos_valid = 0;
    uint8 new_stag_cos = 0;
    uint8 new_stag_cfi = 0;
    uint8 new_ctag_cos_valid = 0;
    uint8 new_ctag_cos = 0;
    uint8 new_ctag_cfi = 0;
    uint8 cos_temp = 0;
    uint8 cfi_temp = 0;
    uint8 vlan_swap = 0;
    uint8 cos_swap_en = 0;
    uint8 tpid_swap_en = 0;
    uint16 new_svlan_tpid = 0;
    uint16 new_cvlan_tpid = 0;
    uint16 svlan_tpid = 0;
    uint16 inner_svlan_tpid = 0;
    uint16 vlan_id_temp = 0;
    uint32 cmd = 0;

    sal_memset(&epe_l2_tpid_ctl, 0, sizeof(epe_l2_tpid_ctl));
    cmd = DRV_IOR(EpeL2TpidCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_tpid_ctl));

    sal_memset(&epe_pkt_proc_tcl, 0, sizeof(epe_pkt_proc_tcl));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_tcl));

    /* HUMBER_MODE_INIT */
    packet_cvlan_tagged = parser_result->l2_s.cvlan_id_valid;
    packet_svlan_tagged = parser_result->l2_s.svlan_id_valid;
    vlan_id_temp = parser_result->l2_s.svlan_id;
    cos_temp = parser_result->l2_s.stag_cos;
    cfi_temp = parser_result->l2_s.stag_cfi;
    vlan_swap = pkt_info->svlan_tag_disable && pkt_info->cvlan_tag_disable
                && pkt_info->tagged_mode && packet_svlan_tagged && packet_cvlan_tagged;

    if (vlan_swap)
    {
        cos_swap_en = pkt_info->cos_swap;
        tpid_swap_en = pkt_info->tpid_swap;
    }

    /* SVLAN_TAG */
    bridge_inner = p_epe_payload_proc_info->bridge_inner;

    untag_default_vlan = !bridge_inner && pkt_info->untag_default_vlan_id && pkt_info->untag_default_svlan
                         && (pkt_info->output_svlan_id == pkt_info->default_vlan_id);

    dot1q_en1 = bridge_inner || IS_BIT_SET(pkt_info->dot1_q_en, 1);

    if (vlan_swap)
    {
        new_stag_cos_valid = TRUE;
        pkt_info->svlan_tag_operation = VTAG_OP_REPLACE;
        pkt_info->output_svlan_id = parser_result->l2_s.cvlan_id;
        parser_result->l2_s.svlan_id = parser_result->l2_s.cvlan_id;
    }
    else if (pkt_info->svlan_tag_disable)
    {
        pkt_info->svlan_tag_operation = VTAG_OP_NONE;
        new_stag_cos_valid = packet_svlan_tagged;
    }
    else if (pkt_info->svlan_tagged && !untag_default_vlan && dot1q_en1)    /* Tag S-VLAN */
    {
        if (pkt_info->tagged_mode)
        {
            pkt_info->svlan_tag_operation = VTAG_OP_ADD;
            parser_result->l2_s.svlan_id_valid = TRUE;
            parser_result->l2_s.svlan_id = pkt_info->output_svlan_id;
            new_stag_cos_valid = TRUE;
        }
        else if (pkt_info->output_svlan_id_valid)
        {
            parser_result->l2_s.svlan_id = pkt_info->output_svlan_id;
            new_stag_cos_valid = TRUE;

            if (packet_svlan_tagged)
            {
                pkt_info->svlan_tag_operation = VTAG_OP_REPLACE;/* replace S-VLAN */
            }
            else
            {
                pkt_info->svlan_tag_operation = VTAG_OP_ADD;    /* add S-VLAN */
                parser_result->l2_s.svlan_id_valid = TRUE;
            }
        }
        else
        {
            if (packet_svlan_tagged && (pkt_info->replace_stag_cos || !pkt_info->derive_stag_cos))
            {
                pkt_info->output_svlan_id = parser_result->l2_s.svlan_id;
                pkt_info->svlan_tag_operation = VTAG_OP_REPLACE;      /* replace S-VLAN */
                new_stag_cos_valid = TRUE;
            }
            else
            {
                pkt_info->svlan_tag_operation = VTAG_OP_NONE;       /* no operation */
                new_stag_cos_valid = packet_svlan_tagged;
            }
        }
    }
    else                                                        /* Untag S-VLAN */
    {
        if (packet_svlan_tagged)
        {
            pkt_info->svlan_tag_operation = VTAG_OP_DELETE;     /* delete S-VLAN */
            parser_result->l2_s.svlan_id_valid = FALSE;
            new_stag_cos_valid = FALSE;
            parser_result->l2_s.svlan_id = 0;
        }
        else
        {
            pkt_info->svlan_tag_operation = VTAG_OP_NONE;       /* no operation */
            new_stag_cos_valid = FALSE;
        }
    }

    if (cos_swap_en) /* swap */
    {
        new_stag_cos = parser_result->l2_s.ctag_cos;
        new_stag_cfi = parser_result->l2_s.ctag_cfi;
    }
    else if (pkt_info->derive_stag_cos && pkt_info->replace_stag_cos) /* mapping */
    {
        new_stag_cos = pkt_info->mapped_cos;
        new_stag_cfi = pkt_info->mapped_cfi;
    }
    else if (!pkt_info->derive_stag_cos) /* nexthop set */
    {
        new_stag_cos = pkt_info->stag_cos;
        new_stag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi : pkt_info->stag_cfi;
    }
    else /* none */
    {
        if (packet_svlan_tagged)
        {
            new_stag_cos = parser_result->l2_s.stag_cos;
            new_stag_cfi = parser_result->l2_s.stag_cfi;
        }
        else
        {
            new_stag_cos = pkt_info->source_cos;
            new_stag_cfi = epe_pkt_proc_tcl.always_map_cfi ? pkt_info->mapped_cfi : pkt_info->source_cfi;
        }
    }

    if (new_stag_cos_valid)
    {
        parser_result->l2_s.stag_cos = new_stag_cos;
        parser_result->l2_s.stag_cfi = new_stag_cfi;
        pkt_info->new_cos = new_stag_cos;
        pkt_info->new_cfi = new_stag_cfi;
    }
    else
    {
        parser_result->l2_s.stag_cos = 0;
        parser_result->l2_s.stag_cfi = 0;
    }

    switch (pkt_info->svlan_tpid_index)
    {
        case 0:
            svlan_tpid = epe_l2_tpid_ctl.svlan_tpid0;
            break;
        case 1:
            svlan_tpid = epe_l2_tpid_ctl.svlan_tpid1;
            break;
        case 2:
            svlan_tpid = epe_l2_tpid_ctl.svlan_tpid2;
            break;
        case 3:
            svlan_tpid = epe_l2_tpid_ctl.svlan_tpid3;
            break;
        default:
            break;
    }

    switch (pkt_info->inner_svlan_tpid_index)
    {
        case 0:
            inner_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid0;
            break;
        case 1:
            inner_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid1;
            break;
        case 2:
            inner_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid2;
            break;
        case 3:
            inner_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid3;
            break;
        default:
            break;
    }

    if (tpid_swap_en)
    {
        new_svlan_tpid = epe_l2_tpid_ctl.cvlan_tpid;
    }
    else
    {
        if (pkt_info->inner_svlan_tpid_en)
        {
            new_svlan_tpid = inner_svlan_tpid;
        }
        else
        {
            new_svlan_tpid = svlan_tpid;
        }
    }

    pkt_info->l2_new_svlan_tag = (new_svlan_tpid << 16)
                                 | (new_stag_cos << 13)
                                 | (new_stag_cfi << 12)
                                 | pkt_info->output_svlan_id;

    if (VTAG_OP_ADD ==pkt_info->svlan_tag_operation)
    {
        pkt_info->oam_vlan = pkt_info->output_svlan_id;
    }

    /* CVLAN_TAG */
    untag_default_vlan = !bridge_inner && pkt_info->untag_default_vlan_id && !pkt_info->untag_default_svlan
                         && (pkt_info->output_cvlan_id == pkt_info->default_vlan_id);
    dot1q_en0 = bridge_inner || IS_BIT_SET(pkt_info->dot1_q_en, 0);

    if (vlan_swap)
    {
        new_ctag_cos_valid = TRUE;
        pkt_info->cvlan_tag_operation = VTAG_OP_REPLACE;
        pkt_info->output_cvlan_id = vlan_id_temp;
        parser_result->l2_s.cvlan_id = vlan_id_temp;
    }
    else if (pkt_info->cvlan_tag_disable)
    {
        pkt_info->cvlan_tag_operation = VTAG_OP_NONE;
        new_ctag_cos_valid = packet_cvlan_tagged;
    }
    else if (!untag_default_vlan && dot1q_en0)    /* Tag C-VLAN */
    {
        if (pkt_info->tagged_mode)
        {
            new_ctag_cos_valid = TRUE;
            pkt_info->cvlan_tag_operation = VTAG_OP_ADD;            /* add C-VLAN */
            parser_result->l2_s.cvlan_id_valid = TRUE;
            pkt_info->cvlan_id_offset_type = 0;
            parser_result->l2_s.cvlan_id = pkt_info->output_cvlan_id;
        }
        else if (pkt_info->output_cvlan_id_valid)
        {
            parser_result->l2_s.cvlan_id = pkt_info->output_cvlan_id;
            new_ctag_cos_valid = TRUE;

            if (packet_cvlan_tagged)
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_REPLACE;    /* replace C-VLAN */
            }
            else
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_ADD;        /* add C-VLAN */
                parser_result->l2_s.cvlan_id_valid = TRUE;
            }
        }
        else
        {
            if (packet_cvlan_tagged && pkt_info->replace_ctag_cos)
            {
                pkt_info->output_cvlan_id = parser_result->l2_s.cvlan_id;
                pkt_info->cvlan_tag_operation = VTAG_OP_REPLACE;    /* replace C-VLAN */
                new_ctag_cos_valid = TRUE;
            }
            else
            {
                pkt_info->cvlan_tag_operation = VTAG_OP_NONE;           /* no operation */
                new_ctag_cos_valid = packet_cvlan_tagged;
            }
        }
    }
    else
    {
        if (packet_cvlan_tagged)                                            /* Untag C-VLAN */
        {
            pkt_info->cvlan_tag_operation= VTAG_OP_DELETE;          /* delete C-VLAN */
            parser_result->l2_s.cvlan_id_valid = FALSE;
            new_ctag_cos_valid = FALSE;
            parser_result->l2_s.cvlan_id = 0;
        }
        else
        {
            pkt_info->cvlan_tag_operation= VTAG_OP_NONE;            /* no operation */
            new_ctag_cos_valid = FALSE;
        }
    }

    new_ctag_cfi = pkt_info->ctag_dei_en ? pkt_info->mapped_cfi : 0;

    if (cos_swap_en)
    {
        new_ctag_cos = cos_temp;
        new_ctag_cfi = cfi_temp;
    }
    else if (pkt_info->replace_ctag_cos)
    {
        if (pkt_info->copy_ctag_cos)
        {
            new_ctag_cos = pkt_info->source_cos;
        }
        else if (!pkt_info->copy_ctag_cos)
        {
            new_ctag_cos = pkt_info->mapped_cos;
        }
    }
    else if (packet_cvlan_tagged)
    {
        new_ctag_cos = parser_result->l2_s.ctag_cos;
    }
    else
    {
        new_ctag_cos = epe_pkt_proc_tcl.use_global_ctag_cos
                       ? epe_pkt_proc_tcl.global_ctag_cos : pkt_info->source_cos;
    }

    if (new_ctag_cos_valid)
    {
        parser_result->l2_s.ctag_cos = new_ctag_cos;
    }
    else
    {
        parser_result->l2_s.ctag_cos = 0;
    }

    if (new_ctag_cos_valid && !new_stag_cos_valid)
    {
        pkt_info->new_cos = new_ctag_cos;
    }

    if (tpid_swap_en)
    {
        if (pkt_info->inner_svlan_tpid_en)
        {
            new_cvlan_tpid = inner_svlan_tpid;
        }
        else
        {
            new_cvlan_tpid = svlan_tpid;
        }
    }
    else
    {
        new_cvlan_tpid = epe_l2_tpid_ctl.cvlan_tpid;
    }

    pkt_info->l2_new_cvlan_tag = (new_cvlan_tpid << 16)
                                 | (new_ctag_cos << 13)
                                 | (new_ctag_cfi << 12)
                                 | pkt_info->output_cvlan_id;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_payload_process_bridge
 * Purpose:   Perform payload bridging operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_payload_process_bridge(epe_in_pkt_t* ipkt,epe_payload_proc_info_t *p_epe_payload_proc_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    uint8 bridge_inner = 0;
    uint8 length_adjust = 0;
    uint32 length_adjust_byte = 0;
    uint16 packet_length_adjust = 0;

    /* PACKET_TYPE */
    pkt_info->packet_type = PKT_TYPE_ETHERNETV2; /* ParserResult.layer2Type must be ethernet ??? (for ingress edit untagDefaultVlanId) */

    bridge_inner = p_epe_payload_proc_info->bridge_inner;

    if (!bridge_inner && (!pkt_info->bridge_en && !pkt_info->ingress_edit_en))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_BRG_PAYLOAD_OPERATION_DISCARD;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE bridge is not enable!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    pkt_info->cvlan_id_offset_type = parser_result->l2_s.svlan_id_valid;

    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    if (pkt_info->vlan_xlate_mode)
    {
        DRV_IF_ERROR_RETURN(_cm_epe_payload_process_bridge_humber_init(ipkt,p_epe_payload_proc_info));
    }
    else
    {
        DRV_IF_ERROR_RETURN(_cm_epe_payload_process_bridge_greatbelt_init(ipkt,p_epe_payload_proc_info));
    }

    /* REPLACE_DSCP */
    /* length adjust */
    switch ((pkt_info->svlan_tag_operation << 2) | pkt_info->cvlan_tag_operation)
    {
        case 0:
            length_adjust = 0;
            break;
        case 1:
            length_adjust = 0;
            break;
        case 2:
            length_adjust = 1;
            break;
        case 3:
            length_adjust = 5;
            break;
        case 4:
            length_adjust = 0;
            break;
        case 5:
            length_adjust = 0;
            break;
        case 6:
            length_adjust = 1;
            break;
        case 7:
            length_adjust = 5;
            break;
        case 8:
            length_adjust = 1;
            break;
        case 9:
            length_adjust = 1;
            break;
        case 10:
            length_adjust = 2;
            break;
        case 11:
            length_adjust = 0;
            break;
        case 12:
            length_adjust = 5;
            break;
        case 13:
            length_adjust = 5;
            break;
        case 14:
            length_adjust = 0;
            break;
        case 15:
            length_adjust = 6;
            break;
        default:
            break;
    }

    length_adjust_byte = ((length_adjust & 0x3) << 2);

    if (!IS_BIT_SET(length_adjust, 2)) /* signed adder */
    {
        packet_length_adjust = func_packet_length_adjust_add(ipkt, length_adjust_byte);
        pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
        pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;

        pkt_info->ptp_offset += length_adjust_byte;
    }
    else                                 /* signed subtration */
    {
        packet_length_adjust = func_packet_length_adjust_subtract(ipkt, length_adjust_byte);
        pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
        pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;

        pkt_info->ptp_offset -= length_adjust_byte;
    }

    /* Replace DSCP */
    if (!bridge_inner && pkt_info->replace_dscp
       && ((L3_TYPE_IPV4 == parser_result->layer3_type) || (L3_TYPE_IPV6 == parser_result->layer3_type))
       && (!pkt_info->acl_dscp_valid))
    {
        pkt_info->new_dscp = pkt_info->mapped_dscp;
        pkt_info->new_dscp_valid = TRUE;

        parser_result->l3_s.tos.ip_tos = (pkt_info->new_dscp << 2) | (parser_result->l3_s.tos.ip_tos & 0x3);
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_payload_process_fcoe
 * Purpose:   Perform  fcoe operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_payload_process_fcoe(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    pkt_info->strip_offset = parser_result->l2_s.layer3_offset & 0xFF;
    parser_result->layer2_type = L2_TYPE_NONE;  /* remove layer2 */

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_payload_process_mirror
 * Purpose:   Perform  mirror operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_payload_process_mirror(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_mirror_escape_cam_t epe_mirror_escape_cam;
    epe_l2_tpid_ctl_t epe_l2_tpid_ctl;
    epe_pkt_proc_ctl_t epe_pkt_proc_tcl;

    uint8 length_adjust_byte = 0;
    uint16 mac_da_47_to_32 = 0;
    uint32 mac_da_31_to_0 = 0;
    uint32 cmd = 0;
    uint8 is_hitted = FALSE;
    uint16 svlan_tpid = 0;
    uint16 packet_length_adjust = 0;

    sal_memset(&epe_l2_tpid_ctl , 0 , sizeof(epe_l2_tpid_ctl) );
    cmd = DRV_IOR(EpeL2TpidCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_tpid_ctl));

    /* MIRROR_VLAN_TAG */
    /* Resume old VLAN Tag */
    pkt_info->cvlan_id_offset_type = 0;
    pkt_info->mirrored_packet = TRUE;

    if (SHARE_TYPE_NONE != pkt_info->share_type)
    {
        pkt_info->share_type = SHARE_TYPE_NONE;
    }

    /* Add remote mirror VLAN if necessary */
    if (pkt_info->mirror_tag_add)
    {
        pkt_info->svlan_tag_operation = VTAG_OP_ADD;     /* Add VLAN, insert after MAC SA */

        switch (pkt_info->svlan_tpid_index)
        {
            case 0:
                svlan_tpid = epe_l2_tpid_ctl.svlan_tpid0;
                break;
            case 1:
                svlan_tpid = epe_l2_tpid_ctl.svlan_tpid1;
                break;
            case 2:
                svlan_tpid = epe_l2_tpid_ctl.svlan_tpid2;
                break;
            case 3:
                svlan_tpid = epe_l2_tpid_ctl.svlan_tpid3;
                break;
            default:
                break;
        }

        pkt_info->l2_new_svlan_tag = (svlan_tpid << 16)
                                     | (pkt_info->source_cos << 13)
                                     | (pkt_info->source_cfi << 12)
                                     | pkt_info->output_svlan_id;

        mac_da_31_to_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                     parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
        mac_da_47_to_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);

        length_adjust_byte = 4;
        packet_length_adjust = func_packet_length_adjust_add(ipkt, length_adjust_byte);
        pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
        pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;

        pkt_info->ptp_offset += 4;

        sal_memset(&epe_mirror_escape_cam, 0, sizeof(epe_mirror_escape_cam));
        cmd = DRV_IOR(EpeMirrorEscapeCam_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_mirror_escape_cam));

        sal_memset(&epe_pkt_proc_tcl, 0, sizeof(epe_pkt_proc_tcl));
        cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0,cmd, &epe_pkt_proc_tcl));

        if (((mac_da_47_to_32 & epe_mirror_escape_cam.mac_da_mask0_high)
                    == (epe_mirror_escape_cam.mac_da_value0_high & epe_mirror_escape_cam.mac_da_mask0_high))
             &&((mac_da_31_to_0 & epe_mirror_escape_cam.mac_da_mask0_low)
                    == (epe_mirror_escape_cam.mac_da_value0_low & epe_mirror_escape_cam.mac_da_mask0_low)))
        {
            is_hitted = TRUE;
        }

        if (!is_hitted)
        {
             if (((mac_da_47_to_32 & epe_mirror_escape_cam.mac_da_mask1_high)
                    == (epe_mirror_escape_cam.mac_da_value1_high & epe_mirror_escape_cam.mac_da_mask1_high))
                &&((mac_da_31_to_0 & epe_mirror_escape_cam.mac_da_mask1_low)
                    == (epe_mirror_escape_cam.mac_da_value1_low & epe_mirror_escape_cam.mac_da_mask1_low)))
            {
                is_hitted = TRUE;
            }
        }

        if (epe_pkt_proc_tcl.mirror_escape_cam_en && is_hitted)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_REMOTE_MIRROR_ESCAPE_DISCARD;
                pkt_info->discard = TRUE;

                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Mirror escape!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      cm_epe_payload_process_handle
 * Purpose:   Perform routing, bridging, mpls, mirror or trill operation based
              on the internal payload.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32
cm_epe_payload_process_handle(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*)ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_result;
    epe_payload_proc_info_t epe_payload_proc_info ;

    uint8 ingress_edit_en = FALSE;
    uint16 packet_length_adjust = 0;
    uint8 payload_operation = 0,payload_operation_route = 0,route_operation = 0,mpls_operation = 0;
    uint8 trill_operation = 0,bridge_operation = 0,mirrir_operation = 0,fcoe_operation = 0,no_operation = 0;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Patload process");

    sal_memset(&epe_payload_proc_info, 0, sizeof(epe_payload_proc_info));
    /* PAYLOAD_OPERATION_INIT */
    pkt_info->new_dscp = pkt_info->src_dscp;
    pkt_info->new_cos = pkt_info->source_cos;
    pkt_info->new_cfi = pkt_info->source_cfi;
    pkt_info->new_ip_check_sum = parser_result->l3_s.ip_sa.ipv4.ip_check_sum;
    pkt_info->new_ip_check_sum_valid = FALSE;

    epe_payload_proc_info.bridge_inner = (CM_PLD_OP_BRIDGE_VPLS == pkt_info->payload_operation)
                                         || (CM_PLD_OP_BRIDGE_INNER == pkt_info->payload_operation);
    pkt_info->checksum_old_dscp = (parser_result->l3_s.tos.ip_tos >> 2) & 0x3F;
    /* ===== bug 4648 ECO begine ==== */
    pkt_info->checksum_old_ecn = (parser_result->l3_s.tos.ip_tos & 0x3);
    /* ===== bug 4648 ECO end ==== */

    if (parser_result->layer3_type == L3_TYPE_IPV4)
    {
        pkt_info->new_ttl_packet_type = TTL_TYPE_IPV4;
    }
    else if (parser_result->layer3_type == L3_TYPE_IPV6)
    {
        pkt_info->new_ttl_packet_type = TTL_TYPE_IPV6;
    }
    else if (parser_result->layer3_type == L3_TYPE_MPLS || parser_result->layer3_type == L3_TYPE_MPLSMCAST)
    {
        pkt_info->new_ttl_packet_type = TTL_TYPE_MPLS;
    }
    else
    {
        pkt_info->new_ttl_packet_type = TTL_TYPE_TRILL;
    }

    pkt_info->bridge_operation = FALSE;

    pkt_info->oam_vlan = parser_result->l2_s.svlan_id_valid ? parser_result->l2_s.svlan_id : pkt_info->default_vlan_id;

    /* PAYLOAD_OPERATION_TYPE */
    if (!pkt_info->discard)
    {
        payload_operation = pkt_info->payload_operation;
        payload_operation_route = ((CM_PLD_OP_ROUTE == pkt_info->payload_operation)
                              || (CM_PLD_OP_ROUTE_NOTTL == pkt_info->payload_operation)
                              || (CM_PLD_OP_ROUTE_COMPACT== pkt_info->payload_operation));
        route_operation = (payload_operation_route && ((L3_TYPE_IP == parser_result->layer3_type)
                                ||(L3_TYPE_IPV4 == parser_result->layer3_type)
                                ||(L3_TYPE_IPV6 == parser_result->layer3_type)));
        mpls_operation = (payload_operation_route && ((L3_TYPE_MPLS == parser_result->layer3_type)
                                ||(L3_TYPE_MPLSMCAST == parser_result->layer3_type)));
        trill_operation = (payload_operation_route && (L3_TYPE_TRILL == parser_result->layer3_type));

        bridge_operation = (CM_PLD_OP_BRIDGE == pkt_info->payload_operation
                                ||CM_PLD_OP_BRIDGE_VPLS == pkt_info->payload_operation
                                ||CM_PLD_OP_BRIDGE_INNER == pkt_info->payload_operation);

        mirrir_operation = (CM_PLD_OP_MIRROR == pkt_info->payload_operation);

        fcoe_operation = (payload_operation_route && (L3_TYPE_FCOE == parser_result->layer3_type));

        no_operation = (CM_PLD_OP_NONE == pkt_info->payload_operation);

        ingress_edit_en = pkt_info->ingress_edit_en;

        pkt_info->bridge_operation = bridge_operation;

        if (no_operation)
        {
            /* to FWD_STATS */
        }
        else if (route_operation)
        {
            DRV_IF_ERROR_RETURN(_cm_epe_payload_process_route(ipkt));
        }
        else if (mpls_operation)
        {
            DRV_IF_ERROR_RETURN(_cm_epe_payload_process_mpls(ipkt));
        }
        else if (trill_operation)
        {
            DRV_IF_ERROR_RETURN(_cm_epe_payload_process_trill(ipkt));
        }
        else if (bridge_operation)
        {
            DRV_IF_ERROR_RETURN(_cm_epe_payload_process_bridge(ipkt,&epe_payload_proc_info));
        }
        else if (mirrir_operation)
        {
            DRV_IF_ERROR_RETURN(_cm_epe_payload_process_mirror(ipkt));
        }
        else if (fcoe_operation)
        {
            DRV_IF_ERROR_RETURN(_cm_epe_payload_process_fcoe(ipkt));
        }
    }

    /* FWD_STATS */
    packet_length_adjust = func_packet_length_adjust_subtract(ipkt, pkt_info->strip_offset);
    pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
    pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;
    pkt_info->ptp_offset = pkt_info->ptp_offset - pkt_info->strip_offset;
    return DRV_E_NONE;
}

