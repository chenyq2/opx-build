/****************************************************************************
 * cm_epe_header_editing.c    Provides EPE header editing function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-10-24.
 * Reason:       First Create.
 *
 * Revision:     V1.0.
 * Author:       JiaK.
 * Date:         2010-11-24.
 * Reason:       Sync spec Revision 5.0.0.
 *
 * Revision:     V2.0.
 * Author:       JiaK.
 * Date:         2010-11-24.
 * Reason:       Sync spec Revision 3.0.3.
 *
 * Revision:     V4.3.0
 * Author:       Zhouw.
 * Date:         2011-07-01.
 * Reason:       Sync spec Revision 4.3.0.
 *
 * Revision:     V4.7.1
 * Author:       JiaK.
 * Date:         2011-07-28.
 * Reason:       Sync spec revision 4.7.1.
 *
 * Revision:     V4.28.2
 * Author:       JiaK.
 * Date:         2011-09-28.
 * Reason:       Sync spec revision 4.28.1.
 *
 * Revision:     V4.29.3
 * Author:       JiaK.
 * Date:         2011-10-10.
 * Reason:       Sync spec revision 4.29.3.
 *
 * Revision:     V4.31.0
 * Author:       JiaK.
 * Date:         2011-10-22.
 * Reason:       sync spec to v4.31.0
 *
 * Revision:     V5.1.0
 * Author:       JiaK.
 * Date:         2011-12-9.
 * Reason:       sync spec to v5.1.0
 *
 * Revision:     V5.6.0
 * Author:       JiaK.
 * Date:         2012-01-7.
 * Reason:       sync spec to v5.6.0
 *
 * Revision:     V5.9.0
 * Author:       JiaK.
 * Date:         2012-01-19.
 * Reason:       sync spec to v5.9.0
 *
 * Revision:     V5.9.1
 * Author:       Wangcy.
 * Date:         2012-02-04.
 * Reason:       sync spec to v5.9.1
 *
 * Revision:     V5.11.0
 * Author:       Wangcy.
 * Date:         2012-03-01.
 * Reason:       sync spec to v5.11.0
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
/* start position: layer3 header */
#define IPV4_TTL_OFFSET 8
#define IPV4_HEADER_CHECKSUM_OFFSET 10
#define IPV4_IPSA_OFFSET 12
#define IPV4_IPDA_OFFSET 16
#define IPV6_HOP_LIMIT_OFFSET 7
#define MPLS_TTL_OFFSET 3
#define TRILL_TTL_OFFSET 1

/* start position: layer4 header */
#define L4_SRC_PORT_OFFSET 0
#define L4_DST_PORT_OFFSET 2

/* start position: layer2 header */
#define MACDA_OFFSET 0
#define MACSA_OFFSET 6
#define INGRESS_EDIT_PKT_HEADER_OUTER_LEN 32
#define EGRESS_EDIT_PKT_HEADER_OUTER_LEN 32

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/
/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/

#define REPLACE_OAM_COUNTER(st_position, value)\
    *(st_position) = ((value>>24)&0xFF); \
    *(st_position+1) = ((value>>16)&0xFF); \
    *(st_position+2) = ((value>>8)&0xFF); \
    *(st_position+3) = (value&0xFF); \

/****************************************************************************
 * Name:      _cm_reclac_ip_checksum
 * Purpose:   recalculate ip checksum.
 * Parameters:
 * Input:     old_u16  --  old data
 *            new_u16 -- new data
 *            old_chksum -- old checksum
 * Return:    new checksum
 * Note:      none.
****************************************************************************/

static uint16
_uint16_ip_chksum (uint16 *start, uint16 length, uint32 init)
{
    uint32 sum = init;
    uint16 len = length >> 1;

    while (len-- > 0)
        sum += ntohs(*start++);


    if (length & 1)
        sum += (ntohs(*start) & 0xFF00);

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);

    len = sum & 0xFFFF;
    return(~len);
}

/****************************************************************************
 * Name:      _cm_epe_header_editing_update_stats
 * Purpose:   EPE header editing update fwdstas.
 * Parameters:
 * Input:     ipkt -- pointer to buffer which save input packet and packet
 *                    header ,and processing information
 * Output:    ipkt -- pointer to buffer which save input packet and packet
 *                    header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_header_editing_update_stats(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    epe_header_edit_ctl_t epe_header_edit_ctl;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    uint8 cos_stats_offset = 0;
    uint16 stats_length = 0;
    uint16 phb_stats_offset = 0;
    uint32 cmd = 0;
    uint32 epe_priority_to_stats_cos = 0;

    /* FWD_STATS */
    sal_memset(&epe_header_edit_ctl, 0, sizeof(epe_header_edit_ctl));
    cmd = DRV_IOR(EpeHeaderEditCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_header_edit_ctl));

    if (pkt_info->share_type == SHARE_TYPE_PTP)
    {
        pkt_info->layer3_offset = parser_result->l2_s.layer3_offset + (pkt_info->share_fields_u.ptp.ptp_extra_offset << 2);
        pkt_info->layer4_offset = parser_result->l3_s.layer4_offset + (pkt_info->share_fields_u.ptp.ptp_extra_offset << 2);
    }
    if (pkt_info->share_type == SHARE_TYPE_OAM)
    {
        /* packetType should use old packetType, but OAM/CPU only parser as Ethernet */

        pkt_info->packet_length = pkt_info->packet_length + pkt_info->strip_offset;
        pkt_info->packet_length = pkt_info->packet_length - pkt_info->l2_new_header_len;

        pkt_info->l2_new_header_len = 0;

        if ((pkt_info->l3_new_header_len != 0) && (pkt_info->l3_new_header_len != 127))
        {
            pkt_info->packet_length = pkt_info->packet_length - pkt_info->l3_new_header_len;
            pkt_info->l3_new_header_len = 0;
        }

        if (USERID_CTAG_ACTION_ADD == pkt_info->cvlan_tag_operation)
        {
            pkt_info->packet_length = pkt_info->packet_length - 4;
        }
        else if (USERID_CTAG_ACTION_DELETE == pkt_info->cvlan_tag_operation)
        {
            pkt_info->packet_length = pkt_info->packet_length + 4;
        }

        if (USERID_STAG_ACTION_ADD == pkt_info->svlan_tag_operation)
        {
            pkt_info->packet_length = pkt_info->packet_length - 4;
        }
        else if (USERID_STAG_ACTION_DELETE == pkt_info->svlan_tag_operation)
        {
            pkt_info->packet_length = pkt_info->packet_length + 4;
        }

        pkt_info->strip_offset = 0;
        pkt_info->congestion_valid = 0;
        pkt_info->new_ttl_valid = 0;
        pkt_info->new_dscp_valid = 0;
        pkt_info->new_ip_check_sum_valid = 0;
        pkt_info->new_l4_checksum_valid = 0;
        pkt_info->new_ip_da_valid = 0;
        pkt_info->new_l4_dest_port_valid = 0;
        pkt_info->dest_mux_port_type = 0;
        pkt_info->new_itag_valid = 0;
        pkt_info->cvlan_tag_operation = USERID_CTAG_ACTION_NONE;
        pkt_info->svlan_tag_operation = USERID_STAG_ACTION_NONE;
        pkt_info->new_macsa_valid = 0;
        pkt_info->new_macda_valid = 0;
    }

    /* muxLengthType */
    /* Only network channel/InterLaken support policing,loopback not support */
    stats_length = pkt_info->packet_length;

    /*pkt_info->tmp_stats_length = stats_length; fix cmodel bug by yongchao*/

    /* Random log, DsPortLogStatsTable */
    if (pkt_info->random_log_en && (!pkt_info->discard || epe_header_edit_ctl.log_port_discard))
    {
        /* update port log stats */
        DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_STATS_DEFAULT,
                  (epe_header_edit_ctl.port_log_stats_base << 6) + pkt_info->local_phy_port, stats_length));
    }

    /* flowStats0: aclFlowStats0
       flowStats1: aclFlowStats1, MPLS-LSP
       flowStats2: userId, VLAN, nextHop, MPLS-PW */

    if (COLOR_GREEN == pkt_info->color)
    {
        phb_stats_offset = 0;   /* in-profile stats offset */
    }
    else
    {
        phb_stats_offset = 1;   /* out-of-profile stats offset */
    }

    cmd = DRV_IOR(EpePriorityToStatsCos_t, (EpePriorityToStatsCos_Cos0_f + pkt_info->priority));
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_priority_to_stats_cos));

    cos_stats_offset = epe_priority_to_stats_cos;    /* per-cos stats offset */

    switch (epe_header_edit_ctl.stats_mode)
    {
        case 1: /* in/out profile stats */
            pkt_info->flow_stats0_ptr = pkt_info->flow_stats0_ptr + phb_stats_offset;
            pkt_info->flow_stats1_ptr = pkt_info->flow_stats1_ptr + phb_stats_offset;
            pkt_info->flow_stats2_ptr = pkt_info->flow_stats2_ptr + phb_stats_offset;
            break;
        case 2: /* per-cos stats */
            pkt_info->flow_stats0_ptr = pkt_info->flow_stats0_ptr + cos_stats_offset;
            pkt_info->flow_stats1_ptr = pkt_info->flow_stats1_ptr + cos_stats_offset;
            pkt_info->flow_stats2_ptr = pkt_info->flow_stats2_ptr + cos_stats_offset;
            break;
        case 3: /* in/out profile and per-cos stats */
            pkt_info->flow_stats0_ptr = pkt_info->flow_stats0_ptr + (cos_stats_offset << 1) + phb_stats_offset;
            pkt_info->flow_stats1_ptr = pkt_info->flow_stats1_ptr + (cos_stats_offset << 1) + phb_stats_offset;
            pkt_info->flow_stats2_ptr = pkt_info->flow_stats2_ptr + (cos_stats_offset << 1) + phb_stats_offset;
            break;
        default:  /* stats pointer no change */
            break;
    }

    /* update flow stats */
    if (pkt_info->flow_stats0_valid && (!pkt_info->discard || epe_header_edit_ctl.flow_stats0_discard_stats_en))
    {
        DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_STATS_DEFAULT,
                                                    pkt_info->flow_stats0_ptr, stats_length));
    }

    if (pkt_info->flow_stats1_valid && (!pkt_info->discard || epe_header_edit_ctl.flow_stats1_discard_stats_en))
    {
        DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_STATS_DEFAULT,
                                                    pkt_info->flow_stats1_ptr, stats_length));
    }

    if (pkt_info->flow_stats2_valid && (!pkt_info->discard || epe_header_edit_ctl.flow_stats2_discard_stats_en))
    {
        DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_STATS_DEFAULT,
                                                    pkt_info->flow_stats2_ptr, stats_length));
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_header_editing_edit_header
 * Purpose:   replace payload ,bridge vlan tag ,
              add l2 new header and l3 new header to the original payload.
 * Parameters:
 * Input:     ipkt -- pointer to buffer which save input packet and packet
 *                    header ,and processing informations
 * Output:    ipkt -- pointer to buffer which save input packet and packet
 *                    header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_header_editing_edit_header(epe_in_pkt_t* ipkt, uint16* header_len)
{
    #define L3_HEADER_MAX_LEN 64
    #define L2_HEADER_LEN 18
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;

    epe_pkt_hdr_ctl_t epe_pkt_hdr_ctl;
    ds_packet_header_edit_tunnel_t ds_packet_header_edit_tunnel;
    cm_greatbelt_packet_header_outer_t cm_packet_header_outer;
    greatbelt_packet_header_t cm_packet_header;
    greatbelt_packet_header_t *p_cm_packet_header = &cm_packet_header;
    epe_header_edit_ctl_t epe_header_edit_ctl;
    packet_header_outer_t packet_header_outer;


    uint32 cmd = 0;
    uint8* l3_hdr = NULL;
    uint8* l4_hdr = NULL;
    uint8 offset = 0;
    uint32 effcient_first_buffer_length = 0xFF; /* temp code, cmodel can not realize buffstore ?? */
    uint8 l3_new_header_outer_len = 0;
    uint8 l2_new_header_outer_len = 0;
    uint16 udp_length = 0;
    uint8 l3_new_header_outer[L3_HEADER_MAX_LEN] = {0};
    uint8 l2_new_header_outer[L2_HEADER_LEN] = {0};
    uint16 header_length = 0;
    uint8 new_dscp = 0;
    uint8 new_ttl = 0;
    uint8 new_protocol = 0;
    uint16 new_total_length = 0;
    uint32 new_ip_sa[4] = {0};
    uint32 new_ip_da[4] = {0};
    uint16 new_ip_checksum = 0;
    uint32 new_flow_label = 0;
    uint16 new_payload_length = 0;
    uint16 new_ether_type = 0;
    uint32 new_mac_da31_0 = 0, new_mac_sa31_0 = 0;
    uint16 new_mac_da47_32 = 0, new_mac_sa47_32 = 0;
    uint8 new_cos = 0;
    uint8 sgmac_strip_header = FALSE;
    uint32 ptp_timestamp31_0 = 0;
    uint32 ptp_timestamp61_32 = 0;
    uint32 dm_timestamp61_32 = 0;
    uint32 dm_timestamp31_0 = 0;

    sal_memset(&epe_pkt_hdr_ctl, 0 ,sizeof(epe_pkt_hdr_ctl_t));
    cmd = DRV_IOR(EpePktHdrCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_hdr_ctl));

    sal_memset(&epe_header_edit_ctl, 0 ,sizeof(epe_header_edit_ctl_t));
    cmd = DRV_IOR(EpeHeaderEditCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_header_edit_ctl));

    /* STRIP_TILL_PAYLOAD */
    if (pkt_info->strip_offset > effcient_first_buffer_length)
    {
        if (!pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 6;
        }

        pkt_info->tmp_strip_error = TRUE;

        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_PT_LAYER4_OFFSET_LAGER_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE StripOffset exceed ErrorLayer4Offset!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }
    else
    {
        /* Move to position after the old Packet header editing, modify zhouw according to SPEC 2012-06-12 for bug4553 */
        /* sal_memmove(ipkt->pkt, ipkt->pkt + pkt_info->strip_offset, pkt_info->tmp_stats_length); */
    }

    /* PacketInfo.layer3Offset[7:0], PacketInfo.layer4Offset[7:0] before strip */
    /* l3Hdr and l4Hdr position before EPEediting, modify zhouw according to SPEC 2012-06-12 for bug4553 */
    l3_hdr = ipkt->pkt + pkt_info->layer3_offset;
    l4_hdr = ipkt->pkt + pkt_info->layer4_offset;

    /* PAYLOAD */
    if(SHARE_TYPE_LMTX == pkt_info->share_type)
    {
        switch(pkt_info->share_fields_u.lmtx.lm_packet_type & 0x7)
        {
            case 0:  /* Ethernet CCM */
                /* replace txFcf: layer3Offset + 58 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l3_hdr + 58, pkt_info->share_fields_u.lmtx.rxtx_fcl);

                /* replace rxFcb: layer3Offset + 62 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l3_hdr + 62, pkt_info->share_fields_u.lmtx.rx_fcb);

                /* replace txFcb: layer3Offset + 66 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l3_hdr + 66, pkt_info->share_fields_u.lmtx.tx_fcb);
                break;
            case 1:  /* Ethernet LMM */
                /* replace txFcf: layer3Offset + 4 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l3_hdr + 4, pkt_info->share_fields_u.lmtx.rxtx_fcl);
                break;
            case 2:  /* Ethernet LMR */
                /* replace txFcb: layer3Offset + 12 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l3_hdr + 12, pkt_info->share_fields_u.lmtx.rxtx_fcl);
                break;
            case 3:  /* MPLS-TP ACH LM */
                /* replace txFcf: layer4Offset + 24 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l4_hdr + 24, pkt_info->share_fields_u.lmtx.tx_fcb);

                /* replace txFcb: layer4Offset + 28 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l4_hdr + 28, pkt_info->share_fields_u.lmtx.rxtx_fcl);
                break;
            case 4:  /* MPLS-TP Y1731 CCM */
                /* replace txFcf: layer4Offset + 62 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l4_hdr + 62, pkt_info->share_fields_u.lmtx.rxtx_fcl);

                /* replace rxFcb: layer4Offset + 66 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l4_hdr + 66, pkt_info->share_fields_u.lmtx.rx_fcb);

                /* replace txFcb: layer4Offset + 70 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l4_hdr + 70, pkt_info->share_fields_u.lmtx.tx_fcb);
                break;
            case 5:  /* MPLS-TP Y1731 LMM */
                /* replace txFcf: layer4Offset + 8 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l4_hdr + 8, pkt_info->share_fields_u.lmtx.rxtx_fcl);
                break;
            case 6:  /* MPLS-TP Y1731 LMR */
                /* replace txFcb: layer4Offset + 16 + (oamOffset<<2) */
                REPLACE_OAM_COUNTER(l4_hdr + 16, pkt_info->share_fields_u.lmtx.rxtx_fcl);
                break;
            default:
                break;
        }

    }

    if (!IS_BIT_SET(pkt_info->new_ttl_packet_type, 1))     /* IP */
    {
        if (pkt_info->congestion_valid)   /* reamark QCN */
        {
            if (TTL_TYPE_IPV4 == pkt_info->new_ttl_packet_type)
            {
                /* ReplaceIpv4Ecn(2'b11,byte{PacketInfo.layer3Offset[7:0] + 1}[1:0]); */
            }
            else
            {
                /* ReplaceIpv6Ecn(2'b11,byte{PacketInfo.layer3Offset[7:0] + 1}[5:4]); */
            }
        }

        if (pkt_info->new_ttl_valid)      /* update ttl */
        {
            if (TTL_TYPE_IPV4 == pkt_info->new_ttl_packet_type)
            {
                /* relpace ipv4 ttl */
                l3_hdr[IPV4_TTL_OFFSET] = pkt_info->new_ttl;         /* IPV4 TTL offset from packetinfo.layer3offset[7:0]
                                                                        (include stripOffset/Mux) */
            }
            else
            {
                /* replace ipv6 ttl */
                l3_hdr[IPV6_HOP_LIMIT_OFFSET] = pkt_info->new_ttl;   /* IPV6 TTL offset from packetinfo.layer3offset[7:0] */
            }
        }

        if (pkt_info->new_dscp_valid)     /* replace dscp */
        {
            if (TTL_TYPE_IPV4 == pkt_info->new_ttl_packet_type)
            {
                /* replace ipv4 dscp */
                l3_hdr[1] = (l3_hdr[1] & 0x3) | (pkt_info->new_dscp << 2); /* IPV4 DSCP offset from packetinfo.layer3offset[7:0] */
            }
            else
            {
                /* replace ipv6 dscp */
                l3_hdr[0] = (l3_hdr[0] & 0xF0) | (pkt_info->new_dscp >> 2);
                l3_hdr[1] = (l3_hdr[1] & 0x3F) | ((pkt_info->new_dscp & 0x3) << 6); /* IPV6 DSCP offset
                                                                                    from packetinfo.layer3offset[7:0] */
            }
        }
    }
    else if (TTL_TYPE_MPLS == pkt_info->new_ttl_packet_type)   /* mpls */
    {
        if(pkt_info->new_ttl_valid)    /* update ttl */
        {
            /* replace mpls ttl */
            l3_hdr[MPLS_TTL_OFFSET] = pkt_info->new_ttl;
        }

        if(pkt_info->new_dscp_valid)   /* replace exp */
        {
            /* replace mpls exp */
            l3_hdr[2] = (l3_hdr[2] & 0xF1) | (((pkt_info->new_dscp >> 3) & 0x7) << 1);
        }
    }
    else if (TTL_TYPE_TRILL == pkt_info->new_ttl_packet_type)   /* trill */
    {
        if(pkt_info->new_ttl_valid)
        {
            /* replace trill ttl */
            l3_hdr[TRILL_TTL_OFFSET] = (l3_hdr[TRILL_TTL_OFFSET] & 0xC0) | (pkt_info->new_ttl & 0x3F);
        }
    }

    if (pkt_info->new_ip_check_sum_valid && (TTL_TYPE_IPV4 == pkt_info->new_ttl_packet_type))
    {
        /* replace ipv4 checksum */
        l3_hdr[IPV4_HEADER_CHECKSUM_OFFSET] = (pkt_info->new_ip_check_sum >> 8) & 0xFF;  /* IPV4 checkSum offset from
                                                                                         packetinfo.layer3Offset[7:0] */
        l3_hdr[IPV4_HEADER_CHECKSUM_OFFSET+1] = pkt_info->new_ip_check_sum & 0xFF;
    }

    /* NAT */
    if ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_ip_sa_valid)   /* IPV4 IP SA offset from packetinfo.layer3offset */
    {
        /* replace ipsa */
        l3_hdr[IPV4_IPSA_OFFSET] = (pkt_info->share_fields_u.nat.new_ip_sa_31_0 >> 24) & 0xFF;
        l3_hdr[IPV4_IPSA_OFFSET+1] = (pkt_info->share_fields_u.nat.new_ip_sa_31_0 >> 16) & 0xFF;
        l3_hdr[IPV4_IPSA_OFFSET+2] = (pkt_info->share_fields_u.nat.new_ip_sa_31_0 >> 8) & 0xFF;
        l3_hdr[IPV4_IPSA_OFFSET+3] = pkt_info->share_fields_u.nat.new_ip_sa_31_0 & 0xFF;
    }

    if ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_l4_source_port_valid)  /* TCP/UDP source port offset from packetinfo.layer4.offset[7:0] */
    {
        /* replace layer4 source port */
        l4_hdr[L4_SRC_PORT_OFFSET] = (pkt_info->share_fields_u.nat.new_l4_source_port >> 8) & 0xFF;
        l4_hdr[L4_SRC_PORT_OFFSET+1] = pkt_info->share_fields_u.nat.new_l4_source_port & 0xFF;
    }


    /* TCP/UDP dest port offset from packetinfo.layer4.offset[7:0] based on packetinfo.is_tcp*/
    if (pkt_info->new_ip_da_valid)
    {
        /* replace ipda */
        l3_hdr[IPV4_IPDA_OFFSET] = (pkt_info->new_ip_da >> 24) & 0xFF;
        l3_hdr[IPV4_IPDA_OFFSET+1] = (pkt_info->new_ip_da >> 16) & 0xFF;
        l3_hdr[IPV4_IPDA_OFFSET+2] = (pkt_info->new_ip_da >> 8) & 0xFF;
        l3_hdr[IPV4_IPDA_OFFSET+3] = pkt_info->new_ip_da & 0xFF;
    }

    if (pkt_info->new_l4_dest_port_valid)
    {
        /* replace layer4 dest port */
        l4_hdr[L4_DST_PORT_OFFSET] = (pkt_info->new_l4_dest_port >> 8) & 0xFF;
        l4_hdr[L4_DST_PORT_OFFSET+1] = pkt_info->new_l4_dest_port & 0xFF;
    }

    /* TCP/UDP checksum offset from packetinfo.layer4.offset[7:0] */
    if (pkt_info->new_l4_checksum_valid)
    {
        /* replace layer4 checksum */
        if (pkt_info->is_tcp)
        {
            offset = 16;
        }
        else if (pkt_info->is_udp)
        {
            offset = 6;
        }

        l4_hdr[offset] = (pkt_info->new_l4_check_sum >> 8) & 0xFF;
        l4_hdr[offset+1] = pkt_info->new_l4_check_sum & 0xFF;
    }

    if (pkt_info->strip_offset <= effcient_first_buffer_length)
    {
        /* Move to position after the old Packet header editing, modify zhouw according to SPEC 2012-06-12 for bug4553 */
        sal_memmove(ipkt->pkt, ipkt->pkt + pkt_info->strip_offset, pkt_info->tmp_stats_length);
        pkt_info->tmp_stats_length -= pkt_info->strip_offset;
    }

    if (0 == pkt_info->strip_offset)
    {
        /* BRIDGE_VLAN_TAG */

        /* PacketInfo.layer2Offset[6:0] === 0 */
        /* ITAG offset from MAC DA + MAC SA + (B-VLAN) */

        if(pkt_info->new_itag_valid)   /* new_itag_valid or cvlan_tag_operation only one valid */
        {                               /* ITAG offset from MAC DA + MAC SA +(B-VLAN) */
            if(pkt_info->itag_offset_type)
            {
                /* replace Itag (with BTag)*/
                ipkt->pkt[19] = (pkt_info->new_itag >> 16) & 0xFF;
                ipkt->pkt[20] = (pkt_info->new_itag >> 8) & 0xFF;
                ipkt->pkt[21] = pkt_info->new_itag & 0xFF;

            }
            else
            {
                /* replace Itag (No BTag)*/
                ipkt->pkt[15] = (pkt_info->new_itag >> 16) & 0xFF;
                ipkt->pkt[16] = (pkt_info->new_itag >> 8) & 0xFF;
                ipkt->pkt[17] = pkt_info->new_itag & 0xFF;
            }
        }

        switch (pkt_info->cvlan_tag_operation) /* C-vlan tag operation */
        {
            case VTAG_OP_REPLACE:
                if(pkt_info->cvlan_id_offset_type)
                {
                    /* Replace c-vlan tag (with Stag) */
                    ipkt->pkt[16] = (pkt_info->l2_new_cvlan_tag>> 24) & 0xFF;
                    ipkt->pkt[17] = (pkt_info->l2_new_cvlan_tag >> 16) & 0xFF;
                    ipkt->pkt[18] = (pkt_info->l2_new_cvlan_tag >> 8) & 0xFF;
                    ipkt->pkt[19] = pkt_info->l2_new_cvlan_tag & 0xFF;
                }
                else
                {
                    /* Replace c-vlan tag (No Stag) */
                    ipkt->pkt[12] = (pkt_info->l2_new_cvlan_tag >> 24) & 0xFF;
                    ipkt->pkt[13] = (pkt_info->l2_new_cvlan_tag >> 16) & 0xFF;
                    ipkt->pkt[14] = (pkt_info->l2_new_cvlan_tag >> 8) & 0xFF;
                    ipkt->pkt[15] = pkt_info->l2_new_cvlan_tag & 0xFF;
                }
                break;
            case VTAG_OP_ADD:
                if(pkt_info->cvlan_id_offset_type)
                {
                    /* Add a new c-vlan tag (with Stag) */
                    sal_memmove((ipkt->pkt + 20), (ipkt->pkt + 16), (pkt_info->tmp_stats_length - 16));
                    ipkt->pkt[16] = (pkt_info->l2_new_cvlan_tag >> 24) & 0xFF;
                    ipkt->pkt[17] = (pkt_info->l2_new_cvlan_tag >> 16) & 0xFF;
                    ipkt->pkt[18] = (pkt_info->l2_new_cvlan_tag >> 8) & 0xFF;
                    ipkt->pkt[19] = pkt_info->l2_new_cvlan_tag & 0xFF;
                    pkt_info->tmp_stats_length += 4;
                }
                else
                {
                    /* Add a new c-vlan tag (No Stag) */
                    sal_memmove((ipkt->pkt + 16), (ipkt->pkt + 12), (pkt_info->tmp_stats_length - 12));
                    ipkt->pkt[12] = (pkt_info->l2_new_cvlan_tag >> 24) & 0xFF;
                    ipkt->pkt[13] = (pkt_info->l2_new_cvlan_tag >> 16) & 0xFF;
                    ipkt->pkt[14] = (pkt_info->l2_new_cvlan_tag >> 8) & 0xFF;
                    ipkt->pkt[15] = pkt_info->l2_new_cvlan_tag & 0xFF;
                    pkt_info->tmp_stats_length += 4;
                }
                break;
            case VTAG_OP_DELETE:
                if(pkt_info->cvlan_id_offset_type)
                {
                    /* Delete a new c-vlan tag (with Stag) */
                    sal_memmove((ipkt->pkt + 16), (ipkt->pkt + 20), (pkt_info->tmp_stats_length - 20));
                    pkt_info->tmp_stats_length -= 4;
                }
                else
                {
                    /* Delete a new c-vlan tag (No Stag) */
                    sal_memmove((ipkt->pkt + 12), (ipkt->pkt + 16), (pkt_info->tmp_stats_length - 16));
                    pkt_info->tmp_stats_length -= 4;
                }
                break;
            default:
                break;
        }

        switch (pkt_info->svlan_tag_operation)  /* S-vlan tag operation */
        {
            case VTAG_OP_REPLACE:
                /* Replace S-vlan tag */
                ipkt->pkt[12] = (pkt_info->l2_new_svlan_tag >> 24) & 0xFF;
                ipkt->pkt[13] = (pkt_info->l2_new_svlan_tag >> 16) & 0xFF;
                ipkt->pkt[14] = (pkt_info->l2_new_svlan_tag >> 8) & 0xFF;
                ipkt->pkt[15] = pkt_info->l2_new_svlan_tag & 0xFF;
                break;
            case VTAG_OP_ADD:
                /* Add a new S-vlan tag */
                sal_memmove((ipkt->pkt + 16), (ipkt->pkt + 12), (pkt_info->tmp_stats_length - 12));
                ipkt->pkt[12] = (pkt_info->l2_new_svlan_tag >> 24) & 0xFF;
                ipkt->pkt[13] = (pkt_info->l2_new_svlan_tag >> 16) & 0xFF;
                ipkt->pkt[14] = (pkt_info->l2_new_svlan_tag >> 8) & 0xFF;
                ipkt->pkt[15] = pkt_info->l2_new_svlan_tag & 0xFF;
                pkt_info->tmp_stats_length += 4;
                break;
            case VTAG_OP_DELETE:
                /* Delete S-vlan tag */
                sal_memmove((ipkt->pkt + 12), (ipkt->pkt + 16), (pkt_info->tmp_stats_length - 16));
                pkt_info->tmp_stats_length -= 4;
                break;
            default:
                break;
        }

        /* replace macsa */
        if(pkt_info->new_macsa_valid)
        {
            ipkt->pkt[MACSA_OFFSET] = (pkt_info->new_macsa_upper16 >> 8)  & 0xFF;
            ipkt->pkt[MACSA_OFFSET+1] = pkt_info->new_macsa_upper16 & 0xFF;
            ipkt->pkt[MACSA_OFFSET+2] = (pkt_info->new_macsa_lower32 >> 24) & 0xFF;
            ipkt->pkt[MACSA_OFFSET+3] = (pkt_info->new_macsa_lower32 >> 16) & 0xFF;
            ipkt->pkt[MACSA_OFFSET+4] = (pkt_info->new_macsa_lower32 >> 8) & 0xFF;
            ipkt->pkt[MACSA_OFFSET+5] = pkt_info->new_macsa_lower32 & 0xFF;
        }

        /* replace macda */
        if(pkt_info->new_macda_valid)
        {
            ipkt->pkt[MACDA_OFFSET] = (pkt_info->new_macda_upper16 >> 8)  & 0xFF;
            ipkt->pkt[MACDA_OFFSET+1] = pkt_info->new_macda_upper16 & 0xFF;
            ipkt->pkt[MACDA_OFFSET+2] = (pkt_info->new_macda_lower32 >> 24) & 0xFF;
            ipkt->pkt[MACDA_OFFSET+3] = (pkt_info->new_macda_lower32 >> 16) & 0xFF;
            ipkt->pkt[MACDA_OFFSET+4] = (pkt_info->new_macda_lower32 >> 8) & 0xFF;
            ipkt->pkt[MACDA_OFFSET+5] = pkt_info->new_macda_lower32 & 0xFF;
        }
    }


    /* LAYER2_3_NEW_HEADER */

    if((0 != pkt_info->l3_new_header_len) && (pkt_info->l3_new_header_len != 127))
    {
        sal_memmove((ipkt->pkt + pkt_info->l3_new_header_len), ipkt->pkt, (pkt_info->packet_length));

        sal_memcpy(ipkt->pkt, pkt_info->l3_header, pkt_info->l3_new_header_len);
    }

    if(pkt_info->l2_new_header_len != 0)
    {
        sal_memmove((ipkt->pkt + pkt_info->l2_new_header_len), ipkt->pkt,
            (pkt_info->packet_length + pkt_info->l3_new_header_len));

        sal_memcpy(ipkt->pkt, pkt_info->l2_header, pkt_info->l2_new_header_len);
    }

    /* PACKET_HEADER_ADD */
    cm_gen_greatbelt_packet_header(pkt_info->ingress_header,&cm_packet_header,TRUE);
    header_length = 0;
    if (pkt_info->packet_header_en) /* put in egress chip ??? */
    {
        if ((pkt_info->ingress_header->operation_type == OPERATION_TYPE_C2C)
            && (pkt_info->ingress_header->rxtx_fcl3)) /* used as sgmacStripHeader */
        {
            sgmac_strip_header = TRUE;
        }
        else if (!pkt_info->from_fabric)
        {
            sal_memset (&cm_packet_header_outer, 0, sizeof(cm_packet_header_outer));
            cm_packet_header_outer.svlan_tpid_index = cm_packet_header.svlan_tpid_index_u.svlan_tpid_index;
            cm_packet_header_outer.timestamp107_96_u.share1.from_cpu_or_oam = cm_packet_header.from_cpu_or_oam;
            cm_packet_header_outer.mcast = cm_packet_header.mcast;
            cm_packet_header_outer.dest_chip_id = cm_packet_header.dest_chip_id;
            cm_packet_header_outer.dest_id = cm_packet_header.dest_id;
            cm_packet_header_outer.outer_vlan_is_c_vlan = cm_packet_header.src_vlan_ptr_t.share1.outer_vlan_is_cvlan;
            cm_packet_header_outer.mirrored_packet = pkt_info->mirrored_packet;
            /*================bug4692 ECO begin====================*/
            cm_packet_header_outer.source_port = (cm_packet_header.source_port15_14 << 14)
                                                 |cm_packet_header.source_port;
            /*================bug4692 ECO end====================*/
            /*cm_packet_header_outer.source_port = cm_packet_header.source_port;*/
            cm_packet_header_outer.priority = cm_packet_header.priority;
            cm_packet_header_outer.critical_packet = cm_packet_header.critical_packet
                                                     || (pkt_info->congestion_valid
                                                     && epe_header_edit_ctl.ecn_critical_packet_en);
            cm_packet_header_outer.packet_type = pkt_info->packet_type;
            cm_packet_header_outer.color = cm_packet_header.color;
            cm_packet_header_outer.oam_tunnel_en_u.oam_tunnel_en = cm_packet_header.oam_tunnel_en;
            cm_packet_header_outer.source_port_extender = cm_packet_header.source_port_extender;
            cm_packet_header_outer.ttl = cm_packet_header.ttl_u.ttl;
            cm_packet_header_outer.source_port_isolate_id = pkt_info->source_port_isolate_id;
            cm_packet_header_outer.header_hash=pkt_info->header_hash;
            cm_packet_header_outer.bridge_operation = pkt_info->bridge_operation;
            cm_packet_header_outer.logic_src_port = pkt_info->logic_src_port;
            cm_packet_header_outer.logic_port_type = pkt_info->logic_port_type;
            cm_packet_header_outer.mac_known = cm_packet_header.ip_sa_u.share1.mac_known;
            cm_packet_header_outer.is_leaf = cm_packet_header.flow_u.share1.is_leaf;

            if ((OPERATION_TYPE_NAT == cm_packet_header.operation_type) && pkt_info->packet_header_en_egress)
            {
                cm_packet_header_outer.operation_type = OPERATION_TYPE_NAT;
                cm_packet_header_outer.timestamp107_96_u.share5.l4_source_port_valid = cm_packet_header.pbb_src_port_type_u.share1.l4_source_port_valid;
                cm_packet_header_outer.timestamp107_96_u.share5.ip_sa_valid = cm_packet_header.pbb_src_port_type_u.share1.ip_sa_valid;
                cm_packet_header_outer.timestamp107_96_u.share5.src_address_mode = cm_packet_header.fid_u.share2.src_address_mode;
                cm_packet_header_outer.timestamp107_96_u.share5.ipv4_src_embeded_mode = cm_packet_header.fid_u.share2.ipv4_src_embeded_mode;
                cm_packet_header_outer.timestamp107_96_u.share5.pt_enable = cm_packet_header.pbb_src_port_type_u.share1.pt_enable;
                cm_packet_header_outer.timestamp107_96_u.share5.ip_sa_prefix_length = cm_packet_header.fid_u.share2.ip_sa_prefix_length;
                cm_packet_header_outer.timestamp107_96_u.share5.ip_sa_mode = cm_packet_header.fid_u.share2.ip_sa_mode;
                cm_packet_header_outer.timestamp63_32_u.share1.l4_source_port = cm_packet_header.logic_src_port_u.l4_source_port;
                cm_packet_header_outer.timestamp63_32_u.share1.ip_sa_39_32 = cm_packet_header.fid_u.share2.ip_sa_39_32;
                cm_packet_header_outer.timestamp31_0_u.ip_sa_31_0 = cm_packet_header.ip_sa_u.ip_sa;
            }
            else if (OPERATION_TYPE_PTP == cm_packet_header.operation_type)
            {
                cm_packet_header_outer.operation_type = OPERATION_TYPE_PTP;
                cm_packet_header_outer.timestamp107_96_u.share2.ptp_sequence_id
                              = cm_packet_header.source_port_isolate_id_u.share1.ptp_sequence_id;
                cm_packet_header_outer.timestamp107_96_u.share2.ptp_edit_type
                              = cm_packet_header.source_port_isolate_id_u.share1.ptp_edit_type;
                cm_get_ptp_timestamp_in_header(p_cm_packet_header,&ptp_timestamp61_32,&ptp_timestamp31_0);
                cm_packet_header_outer.timestamp31_0_u.timestamp_31_0 = ptp_timestamp31_0;

                cm_packet_header_outer.timestamp63_32_u.share2.timestamp_61_32 = ptp_timestamp61_32;
                if (!pkt_info->packet_header_en_egress)
                {
                    cm_packet_header_outer.timestamp95_64_u.share4.ptp_offset = pkt_info->ptp_offset;
                }
                else
                {
                    cm_packet_header_outer.timestamp107_96_u.share2.ptp_extra_offset
                                              = cm_packet_header.pbb_src_port_type_u.share3.ptp_extra_offset;
                }

            }
            else if (pkt_info->tx_dm_en)  /* DM */
            {
                cm_packet_header_outer.operation_type = OPERATION_TYPE_DM_TX;
                cm_packet_header_outer.timestamp107_96_u.share4.dm_offset = pkt_info->ptp_offset;
                cm_packet_header_outer.timestamp63_32_u.share2.timestamp_61_32
                            = ((cm_packet_header.ttl_u.ttl&0xF) << (58-32))
                                |(cm_packet_header.src_cvlan_id_u.src_cvlan_id << (46-32))
                                |(cm_packet_header.fid_u.rx_fcb_31_16&0x3FFF);
                cm_packet_header_outer.timestamp31_0_u.timestamp_31_0 = cm_packet_header.ip_sa_u.ip_sa;
            }
            else if ((OPERATION_TYPE_OAM == cm_packet_header.operation_type)
                    && (cm_packet_header.ip_sa_u.share2.oam_type != OAM_TYPE_NONE))
            {
                cm_packet_header_outer.operation_type = OPERATION_TYPE_OAM;
                cm_packet_header_outer.timestamp107_96_u.share1.from_cpu_or_oam
                                                       = cm_packet_header.from_cpu_or_oam;
                cm_packet_header_outer.timestamp107_96_u.share1.rx_oam
                                                       = cm_packet_header.ip_sa_u.share2.rx_oam;
                cm_packet_header_outer.timestamp107_96_u.share1.oam_type
                                                       = cm_packet_header.ip_sa_u.share2.oam_type;
                cm_packet_header_outer.timestamp107_96_u.share1.is_up
                                                       = cm_packet_header.source_port_isolate_id_u.share2.is_up;
                cm_packet_header_outer.timestamp107_96_u.share1.link_oam
                                                       = cm_packet_header.ip_sa_u.share2.link_oam;
                cm_packet_header_outer.timestamp107_96_u.share1.gal_exist
                                                       = cm_packet_header.ip_sa_u.share2.gal_exist;
                cm_packet_header_outer.timestamp107_96_u.share1.dm_en
                                                       = cm_packet_header.ip_sa_u.share2.dm_en;
                cm_packet_header_outer.timestamp107_96_u.share1.mip_en_or_cw_added
                                                       = cm_packet_header.ip_sa_u.share2.mip_en_or_cw_added;
                cm_packet_header_outer.timestamp107_96_u.share1.entropy_label_exist
                                                       = cm_packet_header.ip_sa_u.share2.entropy_label_exist;
                cm_packet_header_outer.timestamp95_64_u.share1.oam_dest_chip
                                                       = cm_packet_header.source_port_isolate_id_u.share2.oam_dest_chip_id;
                cm_packet_header_outer.timestamp95_64_u.share1.local_phy_port
                                                       = cm_packet_header.ip_sa_u.share3.local_phy_port;
                cm_packet_header_outer.timestamp95_64_u.share1.mep_index
                                                       = cm_packet_header.ip_sa_u.share2.mep_index & 0x3FFF;
                cm_packet_header_outer.timestamp95_64_u.share1.oam_packet_offset7_5
                                                       = (cm_packet_header.packet_offset >> 5)& 0x7;
                cm_packet_header_outer.timestamp95_64_u.share1.oam_packet_offset4
                                                       = (cm_packet_header.packet_offset >> 4)& 0x1;
                cm_packet_header_outer.timestamp95_64_u.share1.oam_packet_offset3_2
                                                       = (cm_packet_header.packet_offset >> 2)& 0x3;
                cm_packet_header_outer.timestamp63_32_u.share2.oam_packet_offset1_0
                                                       = cm_packet_header.packet_offset & 0x3;

                if (cm_packet_header.ip_sa_u.share2.dm_en)
                {
                    cm_get_dm_rx_timestamp_in_header (&cm_packet_header,&dm_timestamp61_32,&dm_timestamp31_0);
                    cm_packet_header_outer.timestamp31_0_u.timestamp_31_0 = dm_timestamp31_0;
                    cm_packet_header_outer.timestamp63_32_u.share2.timestamp_61_32 = dm_timestamp61_32;
                }


            }
            else if (OPERATION_TYPE_C2C == cm_packet_header.operation_type)
            {
                cm_packet_header_outer.operation_type = OPERATION_TYPE_C2C;
                cm_packet_header_outer.oam_tunnel_en_u.c2c_disable
                                                      = cm_packet_header.rxtx_fcl0_u.c2c_check_disable;
            }
            else
            {
                cm_packet_header_outer.operation_type = OPERATION_TYPE_NORMAL;
                cm_packet_header_outer.timestamp107_96_u.share3.flow_id
                                                      = cm_packet_header.flow_u.share1.flow_id;
                cm_packet_header_outer.timestamp107_96_u.share3.capwap_state = cm_packet_header.rxtx_fcl2_1_u.capwap_state;
                cm_packet_header_outer.timestamp107_96_u.share3.pbb_check_discard = cm_packet_header.logic_src_port_u.share1.pbb_check_discard;
                cm_packet_header_outer.timestamp95_64_u.share3.src_dscp = cm_packet_header.ip_sa_u.share1.src_dscp;
            }

            if (!pkt_info->packet_header_en_egress)/* ingress edit */
            {
                cm_packet_header_outer.header_type = HEADER_TYPE_INGRESS_EDIT;
                cm_packet_header_outer.src_vlan_ptr = pkt_info->dest_vlan_ptr;
                cm_packet_header_outer.port_mac_sa_en = pkt_info->port_mac_sa_en;

                cm_packet_header_outer.logic_src_port = (pkt_info->logic_dest_port != 0)?
                                                         pkt_info->logic_dest_port : pkt_info->logic_src_port; /* only for egress service ACL */
                cm_packet_header_outer.logic_port_type = 0; /* no check in Egress chip in case of ingress editing */
                cm_packet_header_outer.bypass_all = pkt_info->ds_nexthop_dot_bypass_all;
                cm_packet_header_outer.from_cpu_lm_up_disable = pkt_info->from_cpu_lm_up_disable;
                cm_packet_header_outer.from_cpu_lm_down_disable = pkt_info->from_cpu_lm_down_disable;
                header_length = INGRESS_EDIT_PKT_HEADER_OUTER_LEN;

                sal_memset (&packet_header_outer, 0, sizeof(packet_header_outer));
                cm_gen_greatbelt_packet_header_outer(&packet_header_outer,&cm_packet_header_outer,FALSE);
                DRV_IF_ERROR_RETURN(swap32((uint32*)(&packet_header_outer), header_length / 4, HOST_TO_NETWORK));
                /*attach packet_header_outer*/
                sal_memmove((ipkt->pkt + header_length),
                             ipkt->pkt, pkt_info->packet_length);
                sal_memcpy(ipkt->pkt, &packet_header_outer, header_length);

            }
            else if ((ipkt->chan_id < 32) ?
                (IS_BIT_SET(epe_header_edit_ctl.from_cpu_en31_0,ipkt->chan_id)) :
                (IS_BIT_SET(epe_header_edit_ctl.from_cpu_en63_32,ipkt->chan_id - 32)))
            {
                header_length = INGRESS_EDIT_PKT_HEADER_OUTER_LEN;

                sal_memset (&packet_header_outer, 0, sizeof(packet_header_outer));
                sal_memcpy(&packet_header_outer, pkt_info->ingress_header, header_length);  /* PacketHeaderOut format is MsPacketHeader */
                DRV_IF_ERROR_RETURN(swap32((uint32*)(&packet_header_outer), header_length / 4, HOST_TO_NETWORK));
                /*attach packet_header_outer*/
                sal_memmove((ipkt->pkt + header_length),
                             ipkt->pkt, pkt_info->packet_length);
                sal_memcpy(ipkt->pkt, &packet_header_outer, header_length);
            }
            else    /* egress edit */
            {
                cm_packet_header_outer.header_type = HEADER_TYPE_EGRESS_EDIT;
                cm_packet_header_outer.src_vlan_ptr = cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr;
                cm_packet_header_outer.next_hop_ext = cm_packet_header.next_hop_ext;
                cm_packet_header_outer.next_hop_ptr = cm_packet_header.next_hop_ptr;

                header_length = EGRESS_EDIT_PKT_HEADER_OUTER_LEN;

                sal_memset (&packet_header_outer, 0, sizeof(packet_header_outer));
                cm_gen_greatbelt_packet_header_outer(&packet_header_outer,&cm_packet_header_outer,FALSE);
                DRV_IF_ERROR_RETURN(swap32((uint32*)(&packet_header_outer), header_length / 4, HOST_TO_NETWORK));
                /*attach packet_header_outer*/
                sal_memmove((ipkt->pkt + header_length),
                             ipkt->pkt, pkt_info->packet_length);
                sal_memcpy(ipkt->pkt, &packet_header_outer, header_length);
            }


        }

        pkt_info->header_packet_type = PKT_TYPE_RESERVED;

        sal_memset(&ds_packet_header_edit_tunnel, 0 ,sizeof(ds_packet_header_edit_tunnel_t));
        cmd = DRV_IOR(DsPacketHeaderEditTunnel_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &ds_packet_header_edit_tunnel));

        switch (ds_packet_header_edit_tunnel.packet_header_l3_type)
        {
            case 0: /* None */
                l3_new_header_outer_len = 0;
                break;
            case 1: /* IPv4 */
                if (epe_pkt_hdr_ctl.header_udp_en)
                {
                    if (epe_pkt_hdr_ctl.use_udp_payload_length) /* real packet length,stacking/fabric only support sotre-and-forward ??? */
                    {
                        udp_length = pkt_info->packet_length + 8 - (!pkt_info->non_crc ? 4 : 0) + header_length;
                    }
                    else
                    {
                        udp_length = epe_pkt_hdr_ctl.header_udp_length;
                    }
                    l3_new_header_outer[0] = epe_pkt_hdr_ctl.udp_src_port >> 8;;
                    l3_new_header_outer[1] = epe_pkt_hdr_ctl.udp_src_port & 0xFF;
                    l3_new_header_outer[2] = epe_pkt_hdr_ctl.udp_dest_port >> 8;
                    l3_new_header_outer[3] = epe_pkt_hdr_ctl.udp_dest_port & 0xFF;
                    l3_new_header_outer[4] = (udp_length >> 8) & 0x3F;
                    l3_new_header_outer[5] = udp_length & 0xFF;
                    l3_new_header_outer[6] = 0;
                    l3_new_header_outer[7] = 0;

                    header_length += 8;
                }

                l3_new_header_outer_len = epe_pkt_hdr_ctl.header_udp_en ? 28 : 20;
                new_dscp = epe_pkt_hdr_ctl.derive_dscp ? pkt_info->mapped_dscp : epe_pkt_hdr_ctl.header_dscp;
                new_ttl = epe_pkt_hdr_ctl.derive_ttl ? pkt_info->packet_ttl : epe_pkt_hdr_ctl.header_ttl;
                new_protocol = epe_pkt_hdr_ctl.header_ip_protocol;

                if (epe_pkt_hdr_ctl.use_ip_payload_length)
                {
                    new_total_length = pkt_info->packet_length + 20 - (!pkt_info->non_crc ? 4 : 0) + header_length;
                }
                else
                {
                    new_total_length = epe_pkt_hdr_ctl.header_ip_length;
                }

                new_ip_sa[0] = epe_pkt_hdr_ctl.header_ip_sa31_0;
                new_ip_da[0] = ds_packet_header_edit_tunnel.ip_da31_0;

                sal_memmove(l3_new_header_outer + 20, l3_new_header_outer, 8);
                l3_new_header_outer[0] = 0x45;
                l3_new_header_outer[1] = (new_dscp & 0x3F) << 2;
                l3_new_header_outer[2] = (new_total_length >> 8) & 0x3F;
                l3_new_header_outer[3] = new_total_length & 0xFF;
                l3_new_header_outer[4] = 0;
                l3_new_header_outer[5] = 0;
                l3_new_header_outer[6] = 0;
                l3_new_header_outer[7] = 0;
                l3_new_header_outer[8] = new_ttl & 0xFF;
                l3_new_header_outer[9] = new_protocol & 0xFF;
                l3_new_header_outer[10] = 0;
                l3_new_header_outer[11] = 0;
                l3_new_header_outer[12] = new_ip_sa[0] >> 24;
                l3_new_header_outer[13] = (new_ip_sa[0] >> 16) & 0xFF;
                l3_new_header_outer[14] = (new_ip_sa[0] >> 8) & 0xFF;
                l3_new_header_outer[15] = new_ip_sa[0] & 0xFF;
                l3_new_header_outer[16] = new_ip_da[0] >> 24;
                l3_new_header_outer[17] = (new_ip_da[0] >> 16) & 0xFF;
                l3_new_header_outer[18] = (new_ip_da[0] >> 8) & 0xFF;
                l3_new_header_outer[19] = new_ip_da[0] & 0xFF;

                new_ip_checksum = _uint16_ip_chksum((uint16*)l3_new_header_outer, 20, 0);
                l3_new_header_outer[10] = new_ip_checksum >> 8;
                l3_new_header_outer[11] = new_ip_checksum & 0xFF;

                header_length += 20;
                pkt_info->header_packet_type = PKT_TYPE_IPV4;
                break;
            case 2: /* IPv6 */

                if (epe_pkt_hdr_ctl.header_udp_en)
                {
                    if (epe_pkt_hdr_ctl.use_udp_payload_length)
                    {
                        udp_length = pkt_info->packet_length + 8 - (!pkt_info->non_crc ? 4 : 0) + header_length;
                    }
                    else
                    {
                        udp_length = epe_pkt_hdr_ctl.header_udp_length;
                    }


                    l3_new_header_outer[0] = epe_pkt_hdr_ctl.udp_src_port >> 8;
                    l3_new_header_outer[1] = epe_pkt_hdr_ctl.udp_src_port & 0xFF;
                    l3_new_header_outer[2] = epe_pkt_hdr_ctl.udp_dest_port >> 8;
                    l3_new_header_outer[3] = epe_pkt_hdr_ctl.udp_dest_port & 0xFF;
                    l3_new_header_outer[4] = (udp_length >> 8) & 0x3F;
                    l3_new_header_outer[5] = udp_length & 0xFF;
                    l3_new_header_outer[6] = 0;
                    l3_new_header_outer[7] = 0;

                    header_length += 8;
                }

                l3_new_header_outer_len = epe_pkt_hdr_ctl.header_udp_en ? 48 : 40;
                new_dscp = epe_pkt_hdr_ctl.derive_dscp ? pkt_info->mapped_dscp : epe_pkt_hdr_ctl.header_dscp;
                new_ttl = epe_pkt_hdr_ctl.derive_ttl ? pkt_info->packet_ttl : epe_pkt_hdr_ctl.header_ttl;
                new_flow_label = epe_pkt_hdr_ctl.header_flow_label;

                if (epe_pkt_hdr_ctl.use_ip_payload_length)
                {
                    new_payload_length = pkt_info->packet_length - (!pkt_info->non_crc ? 4 : 0) + header_length;
                }
                else
                {
                    new_payload_length = epe_pkt_hdr_ctl.header_ip_length;
                }

                new_protocol = epe_pkt_hdr_ctl.header_ip_protocol;
                new_ip_sa[0] = epe_pkt_hdr_ctl.header_ip_sa31_0;
                new_ip_sa[1] = epe_pkt_hdr_ctl.header_ip_sa63_32;
                new_ip_sa[2] = epe_pkt_hdr_ctl.header_ip_sa95_64;
                new_ip_sa[3] = epe_pkt_hdr_ctl.header_ip_sa127_96;

                new_ip_da[0] = ds_packet_header_edit_tunnel.ip_da31_0;
                new_ip_da[1] = ds_packet_header_edit_tunnel.ip_da63_32;
                new_ip_da[2] = ds_packet_header_edit_tunnel.ip_da95_64;
                new_ip_da[3] = ds_packet_header_edit_tunnel.ip_da127_96;

                sal_memmove(l3_new_header_outer + 40, l3_new_header_outer, 8);

                l3_new_header_outer[0] = (6 << 4) | ((new_dscp >> 2) & 0xF);
                l3_new_header_outer[1] = ((new_dscp & 0x3) << 6)
                                            | ((new_flow_label >> 16) & 0xF);
                l3_new_header_outer[2] = (new_flow_label >> 8) & 0xFF;
                l3_new_header_outer[3] = new_flow_label & 0xFF;
                l3_new_header_outer[4] = (new_payload_length >> 8) & 0x3F;
                l3_new_header_outer[5] = new_payload_length & 0xFF;
                l3_new_header_outer[6] = new_protocol & 0xFF;
                l3_new_header_outer[7] = new_ttl & 0xFF;
                l3_new_header_outer[8] = (new_ip_sa[3] >> 24) & 0xFF;
                l3_new_header_outer[9] = (new_ip_sa[3] >> 16) & 0xFF;
                l3_new_header_outer[10] = (new_ip_sa[3] >> 8) & 0xFF;
                l3_new_header_outer[11] = new_ip_sa[3] & 0xFF;
                l3_new_header_outer[12] = (new_ip_sa[2] >> 24) & 0xFF;
                l3_new_header_outer[13] = (new_ip_sa[2] >> 16) & 0xFF;
                l3_new_header_outer[14] = (new_ip_sa[2] >> 8) & 0xFF;
                l3_new_header_outer[15] = new_ip_sa[2] & 0xFF;
                l3_new_header_outer[16] = (new_ip_sa[1] >> 24) & 0xFF;
                l3_new_header_outer[17] = (new_ip_sa[1] >> 16) & 0xFF;
                l3_new_header_outer[18] = (new_ip_sa[1] >> 8) & 0xFF;
                l3_new_header_outer[19] = new_ip_sa[1] & 0xFF;
                l3_new_header_outer[20] = (new_ip_sa[0] >> 24) & 0xFF;
                l3_new_header_outer[21] = (new_ip_sa[0] >> 16) & 0xFF;
                l3_new_header_outer[22] = (new_ip_sa[0] >> 8) & 0xFF;
                l3_new_header_outer[23] = new_ip_sa[0] & 0xFF;
                l3_new_header_outer[24] = (new_ip_da[3] >> 24) & 0xFF;
                l3_new_header_outer[25] = (new_ip_da[3] >> 16) & 0xFF;
                l3_new_header_outer[26] = (new_ip_da[3] >> 8) & 0xFF;
                l3_new_header_outer[27] = new_ip_da[3] & 0xFF;
                l3_new_header_outer[28] = (new_ip_da[2] >> 24) & 0xFF;
                l3_new_header_outer[29] = (new_ip_da[2] >> 16) & 0xFF;
                l3_new_header_outer[30] = (new_ip_da[2] >> 8) & 0xFF;
                l3_new_header_outer[31] = new_ip_da[2] & 0xFF;
                l3_new_header_outer[32] = (new_ip_da[1] >> 24) & 0xFF;
                l3_new_header_outer[33] = (new_ip_da[1] >> 16) & 0xFF;
                l3_new_header_outer[34] = (new_ip_da[1] >> 8) & 0xFF;
                l3_new_header_outer[35] = new_ip_da[1] & 0xFF;
                l3_new_header_outer[36] = (new_ip_da[0] >> 24) & 0xFF;
                l3_new_header_outer[37] = (new_ip_da[0] >> 16) & 0xFF;
                l3_new_header_outer[38] = (new_ip_da[0] >> 8) & 0xFF;
                l3_new_header_outer[39] = new_ip_da[0] & 0xFF;

                header_length += 40;
                pkt_info->header_packet_type = PKT_TYPE_IPV6;
                break;
            default:
                break;
        }

        if (ds_packet_header_edit_tunnel.packet_header_l2_en)
        {
            if (ds_packet_header_edit_tunnel.packet_header_l3_type == PKT_HDR_L3_TYPE_IPV4)
            {
                new_ether_type = 0x0800;
            }
            else if (ds_packet_header_edit_tunnel.packet_header_l3_type == PKT_HDR_L3_TYPE_IPV6)
            {
                new_ether_type = 0x86DD;
            }
            else
            {
                new_ether_type = epe_pkt_hdr_ctl.header_ether_type;
            }

            if (!epe_pkt_hdr_ctl.fabric_mode_en)
            {
                new_mac_da31_0 = ds_packet_header_edit_tunnel.mac_da31_0;
                new_mac_da47_32 = ds_packet_header_edit_tunnel.mac_da47_32;

                new_mac_sa31_0 = ds_packet_header_edit_tunnel.mac_sa31_0;
                new_mac_sa47_32 = ds_packet_header_edit_tunnel.mac_sa47_32;
            }
            else
            {
                if (cm_packet_header.mcast)
                {
                    new_mac_da31_0 = ((epe_pkt_hdr_ctl.mcast_mac_da_base & 0xFFFF) << 16)
                                     | (cm_packet_header.dest_id & 0xFFFF);
                    new_mac_da47_32 = (epe_pkt_hdr_ctl.mcast_mac_da_base >> 16) & 0xFFFF;
                }
                else
                {
                    new_mac_da31_0 = ds_packet_header_edit_tunnel.mac_da31_0 + cm_packet_header.dest_chip_id;
                    new_mac_da47_32 = ds_packet_header_edit_tunnel.mac_da47_32;
                }

                new_mac_sa31_0 = ds_packet_header_edit_tunnel.mac_sa31_0;
                new_mac_sa47_32 = ds_packet_header_edit_tunnel.mac_sa47_32;
            }

            new_cos = epe_pkt_hdr_ctl.derive_cos ? pkt_info->mapped_cos
                      : ((epe_pkt_hdr_ctl.header_cos2_1 << 1) | epe_pkt_hdr_ctl.header_cos0);

            if (ds_packet_header_edit_tunnel.vlan_id_valid)
            {
                l2_new_header_outer_len = 18;

                l2_new_header_outer[0] = (new_mac_da47_32 >> 8) & 0xFF;
                l2_new_header_outer[1] = new_mac_da47_32 & 0xFF;
                l2_new_header_outer[2] = (new_mac_da31_0 >> 24) & 0xFF;
                l2_new_header_outer[3] = (new_mac_da31_0 >> 16) & 0xFF;
                l2_new_header_outer[4] = (new_mac_da31_0 >> 8) & 0xFF;
                l2_new_header_outer[5] = new_mac_da31_0 & 0xFF;
                l2_new_header_outer[6] = (new_mac_sa47_32 >> 8) & 0xFF;
                l2_new_header_outer[7] = new_mac_sa47_32 & 0xFF;
                l2_new_header_outer[8] = (new_mac_sa31_0 >> 24) & 0xFF;
                l2_new_header_outer[9] = (new_mac_sa31_0 >> 16) & 0xFF;
                l2_new_header_outer[10] = (new_mac_sa31_0 >> 8) & 0xFF;
                l2_new_header_outer[11] = new_mac_sa31_0 & 0xFF;
                l2_new_header_outer[12] = (epe_pkt_hdr_ctl.tpid >> 8) & 0xFF;
                l2_new_header_outer[13] = epe_pkt_hdr_ctl.tpid & 0xFF;
                l2_new_header_outer[14] = (new_cos << 5) | (ds_packet_header_edit_tunnel.vlan_id >> 8);
                l2_new_header_outer[15] = ds_packet_header_edit_tunnel.vlan_id & 0xFF;
                l2_new_header_outer[16] = new_ether_type >> 8;
                l2_new_header_outer[17] = new_ether_type & 0xFF;
            }
            else
            {
                l2_new_header_outer_len = 14;

                l2_new_header_outer[0] = (new_mac_da47_32 >> 8) & 0xFF;
                l2_new_header_outer[1] = new_mac_da47_32 & 0xFF;
                l2_new_header_outer[2] = (new_mac_da31_0 >> 24) & 0xFF;
                l2_new_header_outer[3] = (new_mac_da31_0 >> 16) & 0xFF;
                l2_new_header_outer[4] = (new_mac_da31_0 >> 8) & 0xFF;
                l2_new_header_outer[5] = new_mac_da31_0 & 0xFF;
                l2_new_header_outer[6] = (new_mac_sa47_32 >> 8) & 0xFF;
                l2_new_header_outer[7] = new_mac_sa47_32 & 0xFF;
                l2_new_header_outer[8] = (new_mac_sa31_0 >> 24) & 0xFF;
                l2_new_header_outer[9] = (new_mac_sa31_0 >> 16) & 0xFF;
                l2_new_header_outer[10] = (new_mac_sa31_0 >> 8) & 0xFF;
                l2_new_header_outer[11] = new_mac_sa31_0 & 0xFF;
                l2_new_header_outer[12] = new_ether_type >> 8;
                l2_new_header_outer[13] = new_ether_type & 0xFF;
            }

            header_length += l2_new_header_outer_len;
            pkt_info->header_packet_type = PKT_TYPE_ETHERNETV2;
        }
    }
    else
    {
        pkt_info->header_packet_type = pkt_info->packet_type;
    }

    if ((l3_new_header_outer_len != 0) && !sgmac_strip_header)
    {
        /* attachL3NewHeader(l3NewHeaderOuter), fragment processed by network manager */
        sal_memmove((ipkt->pkt + l3_new_header_outer_len),
                    ipkt->pkt, pkt_info->packet_length + header_length);
        sal_memcpy(ipkt->pkt, l3_new_header_outer, l3_new_header_outer_len);
    }

    if ((l2_new_header_outer_len != 0) && !sgmac_strip_header)
    {
        /* attachL2NewHeader(l2NewHeaderOuter) */
        sal_memmove((ipkt->pkt + l2_new_header_outer_len), ipkt->pkt,
                    (pkt_info->packet_length + header_length + l3_new_header_outer_len));
        sal_memcpy(ipkt->pkt, l2_new_header_outer, l2_new_header_outer_len);
    }

    *header_len = (!sgmac_strip_header) ? header_length : 0;
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_header_editing_destination
 * Purpose:   get dest port type ,destination and exception .
 * Parameters:
 * Input:     ipkt -- pointer to buffer which save input packet and packet
 *                    header ,and processing informations
 * Output:    ipkt -- pointer to buffer which save input packet and packet
 *                    header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_header_editing_destination(epe_in_pkt_t* ipkt, uint16 header_length)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    ms_net_tx_t *p_ms_net_tx = &(ipkt->ms_net_tx);

    greatbelt_exception_info_t* greatbelt_exception_info = NULL;
    ms_packet_header_t * bheader = NULL;
    ms_packet_header_t * ingress_header = NULL;
    uint8* temp_packet_header = NULL;
    greatbelt_packet_header_t cm_packet_header;

    ds_dest_port_loopback_t ds_dest_port_loopback;
    epe_header_edit_ctl_t epe_header_edit_ctl;
    epe_header_edit_mux_ctl_t epe_header_edit_mux_ctl;
    epe_header_edit_phy_port_map_t epe_header_edit_phy_port_map;

    uint16 dest_port = 0;
    uint16 source_port = 0;
    uint8 exception_vector = 0;
    uint8 is_oam_discard = FALSE;
    uint8 asic_hard_error = FALSE; /* cmodel can not realize */
    uint32 crc = 0;
    uint32 cmd = 0;
    uint16 source_ecid = 0, ecid = 0;
    uint32 lb_dest_map = 0;
    uint16 lb_next_hop_ptr = 0;
    uint8 lb_next_hop_ext = FALSE, loopback_en = FALSE, lb_length_adjust_type = 0;
    uint8 mux_length_type = 0;
    uint8 vlan_encode_type = 0;
    uint16 mux_vlan_id = 0;
    uint8 symbol = FALSE;
    uint8 vlan_encode_en = FALSE;
    uint8 net_tx_discard = FALSE;
    uint8 complete_discard = FALSE;
    uint8 channel_ized_valid = FALSE;
    bool channel_id_match = FALSE;
    uint16 port_entender_source_port = 0;
    uint16 port_entender_port_vlan_base = 0;

    sal_memset(&epe_header_edit_ctl, 0 ,sizeof(epe_header_edit_ctl));
    cmd = DRV_IOR(EpeHeaderEditCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_header_edit_ctl));

    sal_memset(&epe_header_edit_mux_ctl, 0, sizeof(epe_header_edit_mux_ctl_t));
    cmd = DRV_IOR(EpeHeaderEditMuxCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_header_edit_mux_ctl));

    sal_memset(&epe_header_edit_phy_port_map, 0, sizeof(epe_header_edit_phy_port_map_t));


    /* PORT_TYPE */
    source_port = pkt_info->source_port & 0x3FFF;

    if (epe_header_edit_ctl.stacking_en)
    {
        if (0x1F == ((pkt_info->source_port >> 9) & 0x1F))
        {
            source_port &= 0xFE3F; /* sourcePort[8:6] = 0 */
        }
    }

    lb_dest_map = pkt_info->dest_map;
    lb_next_hop_ext = pkt_info->next_hop_ext;

    if (pkt_info->loopback_en)       /* loopback */
    {
        loopback_en = !pkt_info->discard;
        /* l2NewHeader or l3NewHeader, only one enabled */
        if (127 == pkt_info->l3_new_header_len)
        {
            lb_length_adjust_type = (pkt_info->l3_header[0] >> 6) & 0x1;
            lb_dest_map = ((pkt_info->l3_header[0] & 0x3F) << 16)
                          |(pkt_info->l3_header[1] << 8)
                          | pkt_info->l3_header[2] ;
            lb_next_hop_ext = (pkt_info->l3_header[3] >> 7) & 0x1;
            lb_next_hop_ptr = ((pkt_info->l3_header[3] & 0x3) << 13)
                              |(pkt_info->l3_header[4] << 5)
                              |((pkt_info->l3_header[5] >> 3) & 0x1F);
        }
        else
        {
            lb_length_adjust_type = (pkt_info->l2_header[0] >> 7) & 0x1;
            lb_dest_map = ((pkt_info->l2_header[0] & 0x7F) << 15)
                          | (pkt_info->l2_header[1] << 7)
                          | ((pkt_info->l2_header[2] >> 1) & 0x3F);
            lb_next_hop_ext = pkt_info->l2_header[2] & 0x1;
            lb_next_hop_ptr = ((pkt_info->l2_header[3] & 0x1F) << 10)
                              | (pkt_info->l2_header[4] << 2)
                              | ((pkt_info->l2_header[5] >> 6) & 0x3);
        }
    }
    else
    {
        switch (pkt_info->dest_mux_port_type)
        {
            case 2:
                vlan_encode_en = TRUE;
                vlan_encode_type = 0;   /* old Mux/DEMUX */
                cmd = DRV_IOR(EpeHeaderEditPhyPortMap_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_header_edit_phy_port_map));
                channel_ized_valid = epe_header_edit_phy_port_map.channelized_valid;
                mux_vlan_id = epe_header_edit_phy_port_map.symbol
                              ? (pkt_info->local_phy_port - (epe_header_edit_phy_port_map.port_vlan_base & 0x1FF))
                              : (pkt_info->local_phy_port + (epe_header_edit_phy_port_map.port_vlan_base & 0xFFF));
                break;

            case 3:          /* loopbackEncode*/
                loopback_en = !pkt_info->discard;

                sal_memset(&ds_dest_port_loopback, 0, sizeof(ds_dest_port_loopback));
                cmd = DRV_IOR(DsDestPortLoopback_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->port_loopback_index, cmd, &ds_dest_port_loopback)); /* LoopbackEncode */
                lb_length_adjust_type = ds_dest_port_loopback.lb_length_adjust_type;
                lb_dest_map = ds_dest_port_loopback.lb_dest_map;
                lb_next_hop_ext = ds_dest_port_loopback.lb_next_hop_ext;
                lb_next_hop_ptr = ds_dest_port_loopback.lb_next_hop_ptr & 0xFFFF;
                break;

            case 4:          /* EVB */
                if (!pkt_info->use_logic_port)   /* use localPhyPort */
                {
                    if (!pkt_info->evb_default_local_phy_port_valid)
                    {
                        vlan_encode_en = TRUE;
                        vlan_encode_type = 1;
                        cmd = DRV_IOR(EpeHeaderEditPhyPortMap_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_header_edit_phy_port_map));
                        channel_ized_valid = epe_header_edit_phy_port_map.channelized_valid;
                        mux_vlan_id = epe_header_edit_phy_port_map.symbol
                                      ? (pkt_info->local_phy_port - (epe_header_edit_phy_port_map.port_vlan_base & 0x1FF))
                                      : (pkt_info->local_phy_port + (epe_header_edit_phy_port_map.port_vlan_base & 0xFFF));
                    }
                    else
                    {
                        vlan_encode_en = FALSE;   /* priority EVB tagged not support??? */
                    }
                }
                else    /* use logicDestPort */
                {
                    if (!pkt_info->evb_default_logic_port_valid)
                    {
                        vlan_encode_en = TRUE;
                        vlan_encode_type = 1;
                        cmd = DRV_IOR(EpeHeaderEditPhyPortMap_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_header_edit_phy_port_map));
                        channel_ized_valid = epe_header_edit_phy_port_map.channelized_valid;
                        mux_vlan_id = epe_header_edit_phy_port_map.symbol
                                      ? (pkt_info->logic_dest_port - epe_header_edit_phy_port_map.port_vlan_base)
                                      : (pkt_info->logic_dest_port + epe_header_edit_phy_port_map.port_vlan_base);
                    }
                    else
                    {
                        vlan_encode_en = FALSE;
                    }
                }
                break;

            case 5:          /* Controlling Bridge downlink */
                if (IS_BIT_SET(pkt_info->dest_map, 21))   /* multicast */
                {
                    channel_id_match = (pkt_info->dest_channel_link_aggregate_en == pkt_info->source_channel_link_aggregate_en)
                                       && (pkt_info->dest_channel_link_aggregate == pkt_info->source_channel_link_aggregate);

                    port_entender_source_port = pkt_info->use_logic_port ? pkt_info->logic_src_port
                                                : (source_port & 0x1FF);
                    cmd = DRV_IOR(EpeHeaderEditPhyPortMap_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_header_edit_phy_port_map));
                    channel_ized_valid = epe_header_edit_phy_port_map.channelized_valid;
                    port_entender_port_vlan_base = epe_header_edit_phy_port_map.port_vlan_base;
                    symbol = epe_header_edit_phy_port_map.symbol;
                    source_ecid = !channel_id_match ? 0 : (symbol ?
                                  (port_entender_source_port - port_entender_port_vlan_base) :
                                  (port_entender_source_port + port_entender_port_vlan_base));
                    ecid = (pkt_info->mcast_id - ((epe_header_edit_mux_ctl.port_extender_met_base & 0xFF) << 6)) + 4096;
                    vlan_encode_en = TRUE;
                    vlan_encode_type = 2;

                }
                else    /* unicast */
                {
                    source_ecid = 0;

                    if (!pkt_info->use_logic_port)  /* use localPhyPort */
                    {
                        if (!pkt_info->evb_default_local_phy_port_valid)
                        {
                            vlan_encode_en = TRUE;
                            vlan_encode_type = 2;   /* port extender */
                            cmd = DRV_IOR(EpeHeaderEditPhyPortMap_t, DRV_ENTRY_FLAG);
                            DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_header_edit_phy_port_map));
                            channel_ized_valid = epe_header_edit_phy_port_map.channelized_valid;
                            ecid = epe_header_edit_phy_port_map.symbol
                                   ? (pkt_info->local_phy_port - (epe_header_edit_phy_port_map.port_vlan_base & 0x1FF))
                                   : (pkt_info->local_phy_port + (epe_header_edit_phy_port_map.port_vlan_base & 0xFFF));
                        }
                        else
                        {
                            vlan_encode_en = FALSE;
                        }
                    }
                    else    /* use logicDestPort */
                    {
                        if (!pkt_info->evb_default_logic_port_valid)
                        {
                            vlan_encode_en = TRUE;
                            vlan_encode_type = 2;
                            cmd = DRV_IOR(EpeHeaderEditPhyPortMap_t, DRV_ENTRY_FLAG);
                            DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_header_edit_phy_port_map));
                            ecid = epe_header_edit_phy_port_map.symbol
                                   ? (pkt_info->logic_dest_port - epe_header_edit_phy_port_map.port_vlan_base)
                                   : (pkt_info->logic_dest_port + epe_header_edit_phy_port_map.port_vlan_base);
                        }
                        else
                        {
                            vlan_encode_en = FALSE;
                        }
                    }
                }
                break;

            case 6:          /* PE Uplink */
                source_ecid = 0;

                if (!pkt_info->use_logic_port)  /* use localPhyPort */
                {
                    if ((source_port != pkt_info->global_dest_port) && !pkt_info->source_port_extender)
                    {
                        vlan_encode_en = TRUE;
                        vlan_encode_type = 2;   /* port extender */
                        cmd = DRV_IOR(EpeHeaderEditPhyPortMap_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_header_edit_phy_port_map));
                        ecid = epe_header_edit_phy_port_map.symbol
                               ? ((source_port & 0x1FF) - (epe_header_edit_phy_port_map.port_vlan_base & 0x1FF))
                               : ((source_port & 0x1FF)+ (epe_header_edit_phy_port_map.port_vlan_base & 0xFFF));
                    }
                    else
                    {
                        vlan_encode_en = FALSE;
                    }
                }
                else
                {
                    if ((pkt_info->logic_src_port != pkt_info->global_dest_port) && !pkt_info->source_port_extender)
                    {
                        vlan_encode_en = TRUE;
                        vlan_encode_type = 2;   /* port extender */
                        cmd = DRV_IOR(EpeHeaderEditPhyPortMap_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_header_edit_phy_port_map));
                        ecid = epe_header_edit_phy_port_map.symbol
                               ? (pkt_info->logic_src_port - epe_header_edit_phy_port_map.port_vlan_base)
                               : (pkt_info->logic_src_port + epe_header_edit_phy_port_map.port_vlan_base);
                    }
                    else
                    {
                        vlan_encode_en = FALSE;
                    }
                }
                /* PE Downlink crossconnect to PE Uplink without editing */
               break;
            default:
                break;
        }
    }

    if ((pkt_info->strip_offset == 0) && vlan_encode_en && (pkt_info->l3_new_header_len == 0)
        && (pkt_info->l2_new_header_len == 0))
    {
        switch (vlan_encode_type & 0x3)   /* use outer vlan cos/cfi */
        {
            case 0:
                /* 4Bytes */
                sal_memmove((ipkt->pkt+16), (ipkt->pkt+12), pkt_info->tmp_stats_length - 12);
                ipkt->pkt[12] = (0x8100 >> 8) & 0xFF;
                ipkt->pkt[12 + 1] = 0x8100 & 0xFF;
                ipkt->pkt[12 + 2] = (pkt_info->mapped_cos << 5)
                                    | (pkt_info->mapped_cfi << 4)
                                    | (mux_vlan_id >> 8);
                ipkt->pkt[12 + 3] = mux_vlan_id & 0xFF;
                mux_length_type = MUX_LENGTH_TYPE1;
                pkt_info->tmp_stats_length += 4;
                break;
            case 1:
                /* 4Bytes */
                sal_memmove((ipkt->pkt+16), (ipkt->pkt+12), pkt_info->tmp_stats_length - 12);
                ipkt->pkt[12] = (epe_header_edit_ctl.evb_tpid >> 8) & 0xFF;
                ipkt->pkt[12 + 1] = epe_header_edit_ctl.evb_tpid & 0xFF;
                ipkt->pkt[12 + 2] = (pkt_info->mapped_cos << 5)
                                    | (pkt_info->mapped_cfi << 4)
                                    | (mux_vlan_id >> 8);
                ipkt->pkt[12 + 3] = mux_vlan_id & 0xFF;
                mux_length_type = MUX_LENGTH_TYPE1;
                pkt_info->tmp_stats_length += 4;
                break;
            case 2:
                /* 8Bytes */
                sal_memmove((ipkt->pkt+20), (ipkt->pkt+12), pkt_info->tmp_stats_length - 12);
                ipkt->pkt[12] = (epe_header_edit_ctl.port_extender_tpid >> 8) & 0xFF;
                ipkt->pkt[12 + 1] = epe_header_edit_ctl.port_extender_tpid & 0xFF;
                ipkt->pkt[12 + 2] = (pkt_info->mapped_cos << 5)
                                    | (pkt_info->mapped_cfi << 4)
                                    | (source_ecid >> 8);
                ipkt->pkt[12 + 3] = source_ecid & 0xFF;
                ipkt->pkt[12 + 4] = (ecid & 0x3FFF) >> 8;
                ipkt->pkt[12 + 5] = ecid & 0xFF;
                ipkt->pkt[12 + 6] = 0;
                ipkt->pkt[12 + 7] = 0;
                mux_length_type = MUX_LENGTH_TYPE2;
                pkt_info->tmp_stats_length += 8;
                break;
            default:
                break;
        }
    }
    else
    {
        mux_length_type = MUX_LENGTH_TYPE0;
    }

    pkt_info->ptp_offset = pkt_info->ptp_offset + ((mux_length_type & 0x3) << 2);

    pkt_info->packet_length += (((mux_length_type & 0x3) << 2) + header_length);
    ipkt->packet_length = pkt_info->packet_length;

    pkt_info->ptp_offset += (mux_length_type << 2);

    if (pkt_info->packet_header_en)
    {
        /* PACKET_HEADER_PROC */
        bheader = pkt_info->bheader;
        sal_memset(bheader, 0, sizeof(ms_packet_header_t));

        ingress_header = pkt_info->ingress_header;

        bheader->svlan_tpid_index = ingress_header->svlan_tpid_index;
        bheader->from_cpu_or_oam = ingress_header->from_cpu_or_oam;
        bheader->source_cos = ingress_header->source_cos;
        bheader->dest_map = ingress_header->dest_map;
        bheader->source_cfi = ingress_header->source_cfi;

        /* outerVlanIsCVlan */
        if (IS_BIT_SET(ingress_header->src_vlan_ptr, 13))
        {
            SET_BIT(bheader->src_vlan_ptr, 13);
        }
        else
        {
            CLEAR_BIT(bheader->src_vlan_ptr, 13);
        }

        dest_port = pkt_info->global_dest_port;
        if (epe_header_edit_ctl.stacking_en && (((pkt_info->global_dest_port >> 9) & 0x1F) == 0x1F))
        {
            dest_port &=0x3E3F;
            dest_port |= (((epe_header_edit_ctl.chip_id) >>3) << 14);
            dest_port |= ((epe_header_edit_ctl.chip_id & 0x7) << 6);
        }
        bheader->source_port = dest_port;

        bheader->priority = pkt_info->priority;
        bheader->packet_type = pkt_info->packet_type;
        bheader->color = pkt_info->color;
        if (header_length != 0)
        {
            bheader->packet_offset = header_length - 32;
        }
        else
        {
            bheader->packet_offset = 0;
        }
        bheader->logic_src_port &= 0xC000;
        bheader->logic_src_port |= pkt_info->logic_src_port;
        bheader->fid &= 0xC000;
        bheader->fid |= pkt_info->fid;
        bheader->src_vlan_ptr &= 0xE000;
        bheader->src_vlan_ptr |= pkt_info->dest_vlan_ptr;

        greatbelt_exception_info = pkt_info->bexception;
        sal_memset(greatbelt_exception_info, 0, sizeof(greatbelt_exception_info_t));
        greatbelt_exception_info->egress_exception = 1;
        greatbelt_exception_info->exception_from_sgmac = TRUE;
        p_ms_net_tx->mac_valid = !pkt_info->discard;
        p_ms_net_tx->loopback_en = loopback_en;
        greatbelt_exception_info->dest_id_discard = TRUE;

        if (!asic_hard_error)
        {
            /* Exceptions */
            greatbelt_exception_info->exception_packet_type = pkt_info->packet_type;/* get original packet type */
            greatbelt_exception_info->exception_vector = (pkt_info->port_log_en << 7)
                                                            | (pkt_info->l2_span_en << 1)
                                                            | (pkt_info->exception_en);
            if (pkt_info->discard)
            {
                exception_vector = greatbelt_exception_info->exception_vector;
                exception_vector &= ((epe_header_edit_ctl.log_on_discard << 1) | 0x1);
                greatbelt_exception_info->exception_vector = (exception_vector & 0xFF);
            }

            greatbelt_exception_info->l2_span_id = pkt_info->l2_span_id;
            greatbelt_exception_info->l3_span_id = pkt_info->l3_span_id;
            greatbelt_exception_info->acl_log_id3 = pkt_info->acl_log_id3;
            greatbelt_exception_info->acl_log_id2 = pkt_info->acl_log_id2;
            greatbelt_exception_info->acl_log_id1 = pkt_info->acl_log_id1;
            greatbelt_exception_info->acl_log_id0 = pkt_info->acl_log_id0;
            greatbelt_exception_info->egress_exception = TRUE;
            greatbelt_exception_info->exception_number = pkt_info->exception_index;

            if (pkt_info->discard && greatbelt_exception_info->exception_vector)
            {
                CMODEL_DEBUG_OUT_INFO("================ EPE Discard and exception ====== START\n");
                CMODEL_DEBUG_OUT_INFO("********** pkt_info->bypass_all = 0x%x\n", pkt_info->bypass_all);
                CMODEL_DEBUG_OUT_INFO("********** exceptionVector = 0x%x\n", greatbelt_exception_info->exception_vector);
                CMODEL_DEBUG_OUT_INFO("********** egressException = 0x%x\n", greatbelt_exception_info->egress_exception);
                CMODEL_DEBUG_OUT_INFO("********** pkt_info->discard_type = %d\n", pkt_info->discard_type);
                CMODEL_DEBUG_OUT_INFO("================ EPE Discard and exception ======= END\n");
            }
            else if (pkt_info->discard)
            {
                CMODEL_DEBUG_OUT_INFO("================ EPE Discard No exception ====== START\n");
                CMODEL_DEBUG_OUT_INFO("********** pkt_info->bypass_all = 0x%x\n", pkt_info->bypass_all);
                CMODEL_DEBUG_OUT_INFO("********** pkt_info->discard_type = %d\n", pkt_info->discard_type);
                CMODEL_DEBUG_OUT_INFO("================ EPE Discard No exception ======= END\n");
            }
        }

        DRV_IF_ERROR_RETURN(swap32((uint32 *)bheader, GREAT_BELT_HEADER_LEN / 4, HOST_TO_NETWORK));
        temp_packet_header = (uint8*)bheader;
        /* header crc */
        temp_packet_header[GREATBELT_HDR_CRC_OFFSET] &= 0xF0; /* clear headerCRC[3:0] */
        temp_packet_header[GREATBELT_HDR_CRC_OFFSET] |= calculate_crc4((uint8 *)bheader, GREAT_BELT_HEADER_LEN, 0);

#if (SDK_WORK_PLATFORM == 1)
        if (cosim_db.store_discard_type)
        {
            cosim_db.store_discard_type(pkt_info->discard, pkt_info->discard_type);
        }

        if (cosim_db.store_bheader)
        {
            DRV_IF_ERROR_RETURN(swap32((uint32 *)bheader, GREAT_BELT_HEADER_LEN / 4, NETWORK_TO_HOST));
            DRV_IF_ERROR_RETURN(cosim_db.store_bheader(((void *)bheader), SIM_MODULE_EPE));
        }
#endif

        complete_discard = asic_hard_error || (pkt_info->discard && !loopback_en && !greatbelt_exception_info->exception_vector);
        pkt_info->tmp_complete_discard = complete_discard;

        /* always update crc */
        DRV_IF_ERROR_RETURN(ctcutil_crc32(0xFFFFFFFF, ipkt->pkt, (pkt_info->packet_length - 4), &crc));
        DRV_IF_ERROR_RETURN(swap32(&crc, 1, HOST_TO_NETWORK));
        ipkt->pkt[pkt_info->packet_length - 4] = (crc >> 24) & 0xFF;
        ipkt->pkt[pkt_info->packet_length - 3] = (crc >> 16) & 0xFF;
        ipkt->pkt[pkt_info->packet_length - 2] = (crc >> 8) & 0xFF;
        ipkt->pkt[pkt_info->packet_length - 1] = crc & 0xFF;

             /* stats epe pktinfo discard */
        if (pkt_info->discard)
        {
            DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_EGRESS_DISCARD,
                                                        pkt_info->discard_type, pkt_info->packet_length));
        }

        /* stats epe loopback */
        if (loopback_en)
        {
            DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_STATS_ELOOP, 0, 0));
        }
        /* stats epe exceptions */
        if (greatbelt_exception_info->exception_vector)
        {
            DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_STATS_EXCEPTION, 0, 0));
        }
        /* stats epe complete discard */
        if (complete_discard)
        {
            DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_STATS_COMPLETE_DISCARD, 0, 0));
        }

        /* to NET_TX */
        return DRV_E_NONE;
    }

    /* DESTINATION */
    if (SHARE_TYPE_OAM == pkt_info->share_type)
    {
        lb_next_hop_ptr = pkt_info->next_hop_ptr & 0xFFFF;

        if (pkt_info->discard_type < 32)
        {
            is_oam_discard = IS_BIT_SET(epe_header_edit_ctl.oam_discard_bitmap31_0, pkt_info->discard_type);
        }
        else
        {
            is_oam_discard = IS_BIT_SET(epe_header_edit_ctl.oam_discard_bitmap63_32, pkt_info->discard_type - 32);
        }

        loopback_en = !pkt_info->discard || !is_oam_discard;
    }

    net_tx_discard = pkt_info->discard || loopback_en;

    /* packet header */
    sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));

    cm_packet_header.priority = pkt_info->priority;
    cm_packet_header.mcast = IS_BIT_SET(lb_dest_map,21);
    cm_packet_header.dest_chip_id = (lb_dest_map >> 16) & 0x1F;
    cm_packet_header.dest_id = lb_dest_map & 0xFFFF;
    cm_packet_header.source_cos = pkt_info->new_cos;
    cm_packet_header.packet_type = pkt_info->packet_type;
    cm_packet_header.non_crc = pkt_info->non_crc;

    /* Egress sflow use destport */
    dest_port = pkt_info->global_dest_port;

    if (epe_header_edit_ctl.stacking_en && ((pkt_info->global_dest_port >> 9) & 0x1F) == 0x1F)
    {
        dest_port &=0x3E3F;
        dest_port |= ((((epe_header_edit_ctl.chip_id) >>3) & 0x3) << 14);
        dest_port |= ((epe_header_edit_ctl.chip_id & 0x7) << 6);
    }
    
    if (epe_header_edit_ctl.stacking_en && ((pkt_info->source_port >> 9) & 0x1F) == 0x1F)
    {
        source_port &=0x3E3F;
        source_port |= ((((epe_header_edit_ctl.chip_id) >>3) & 0x3) << 14);
        source_port |= ((epe_header_edit_ctl.chip_id & 0x7) << 6);
    }

    if ((loopback_en && epe_header_edit_ctl.loopback_use_source_port) || (INTERLAKEN_CHANID == ipkt->chan_id))
    {
        cm_packet_header.source_port = source_port;
    }
    else
    {
        cm_packet_header.source_port = dest_port;
    }

    cm_packet_header.logic_port_type = pkt_info->logic_port_type;
    cm_packet_header.header_hash2_0 = (pkt_info->header_hash & 0x7);
    cm_packet_header.header_hash7_3 = (pkt_info->header_hash >> 3);
    cm_packet_header.src_vlan_id_u.src_vlan_id = 0;
    cm_packet_header.color = pkt_info->color;
    cm_packet_header.length_adjust_type = lb_length_adjust_type;
    cm_packet_header.critical_packet = (SHARE_TYPE_OAM == pkt_info->share_type) && epe_header_edit_ctl.rx_ether_oam_critical;

    if (epe_header_edit_ctl.from_cpu_or_oam_en)
    {
        cm_packet_header.from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    }

    if (loopback_en)
    {
        cm_packet_header.next_hop_ptr = lb_next_hop_ptr & 0xFFFF;
    }
    else
    {
        cm_packet_header.next_hop_ptr = pkt_info->next_hop_ptr & 0xFFFF;
    }

    /* exception/OAM use unmodified packet length */
    cm_packet_header.source_port_extender = pkt_info->source_port_extender;
    cm_packet_header.source_port_isolate_id_u.source_port_isolate_id = pkt_info->source_port_isolate_id;
    cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr = pkt_info->dest_vlan_ptr;
    cm_packet_header.ttl_u.ttl = pkt_info->packet_ttl;
    cm_packet_header.src_vlan_ptr_t.share1.outer_vlan_is_cvlan = 0;     /* used as outerVlanIsCvlan */
    cm_packet_header.source_cfi = pkt_info->new_cfi;
    cm_packet_header.next_hop_ext = lb_next_hop_ext;
    cm_packet_header.svlan_tpid_index_u.svlan_tpid_index = 0;
    cm_packet_header.src_cvlan_id_u.src_cvlan_id = 0;
    cm_packet_header.rxtx_fcl2_1_u.capwap_state = pkt_info->roaming_state;

    if (SHARE_TYPE_OAM == pkt_info->share_type)     /* OAM */
    {
        cm_packet_header.operation_type = OPERATION_TYPE_OAM;
        cm_packet_header.ip_sa_u.share2.rx_oam = TRUE;
        cm_packet_header.source_port_isolate_id_u.share2.oam_dest_chip_id = pkt_info->share_fields_u.oam.oam_dest_chip_id;
        cm_packet_header.ip_sa_u.share2.mip_en_or_cw_added = pkt_info->share_fields_u.oam.mip_en;
        cm_packet_header.ip_sa_u.share2.mep_index = pkt_info->share_fields_u.oam.mep_index & 0x1FFF;
        cm_packet_header.ip_sa_u.share2.dm_en = pkt_info->share_fields_u.oam.dm_en;
        cm_packet_header.source_port_isolate_id_u.share2.is_up = 1;
        cm_packet_header.ip_sa_u.share2.oam_type = pkt_info->share_fields_u.oam.rx_oam_type;
        cm_packet_header.ip_sa_u.share2.local_phy_port = pkt_info->local_phy_port;
        cm_packet_header.dest_id &= 0xF800; /* clear [10:0] bits */
        cm_packet_header.dest_id |= (((pkt_info->global_dest_port >> 9) & 0x7) << 8)
                                    | (pkt_info->global_dest_port & 0xff);
        cm_packet_header.ip_sa_u.share3.gal_exist = ((pkt_info->global_dest_port >> 13) & 0x1);
        cm_packet_header.ip_sa_u.share3.entropy_label_exist = ((pkt_info->global_dest_port >> 12) & 0x1);

        if (pkt_info->share_fields_u.oam.dm_en)
        {
            cm_packet_header.src_ctag_offset_type_u.dm_timestamp_61
                                   = (pkt_info->share_fields_u.ptp.time_stamp_61_32 >> 29) & 0x1;
            cm_packet_header.rxtx_fcl_22_17_u.dm_timestamp_60_55
                                   = (pkt_info->share_fields_u.ptp.time_stamp_61_32 >> 23) & 0x3F;
            cm_packet_header.ttl_u.dm_timestamp_54_47
                                   = (pkt_info->share_fields_u.ptp.time_stamp_61_32 >> 15) & 0xFF;
            cm_packet_header.src_cvlan_id_valid_u.dm_timestamp_46
                                   = (pkt_info->share_fields_u.ptp.time_stamp_61_32 >> 14) & 0x1;
            cm_packet_header.src_cvlan_id_u.dm_timestamp_45_34
                                   = (pkt_info->share_fields_u.ptp.time_stamp_61_32 >> 2) & 0xFFF;
            cm_packet_header.fid_u.dm_timestamp_33_18
                                   = ((pkt_info->share_fields_u.ptp.time_stamp_61_32 & 0x3)<< 14)
                                     |((pkt_info->share_fields_u.ptp.time_stamp_31_0 >> 18) & 0x3FFF);
            cm_packet_header.logic_src_port_u.dm_timestamp_17_2
                                   = (pkt_info->share_fields_u.ptp.time_stamp_31_0 >> 2)& 0xFFFF;
            cm_packet_header.rxtx_fcl3_u.dm_timestamp_1_1
                                   = (pkt_info->share_fields_u.ptp.time_stamp_31_0 >> 1) & 0x1;
            cm_packet_header.rxtx_fcl0_u.dm_timestamp_0_0
                                   = pkt_info->share_fields_u.ptp.time_stamp_31_0 & 0x1;


        }
        else if (pkt_info->share_fields_u.oam.lm_received_packet)
        {
            /* rxtxFcl */
            cm_packet_header.src_ctag_offset_type_u.rxtx_fcl_31
                            = ((pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 31) & 0x1);
            cm_packet_header.ttl_u.rxtx_fcl_30_23
                            = ((pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 23) & 0xFF);
            cm_packet_header.rxtx_fcl_22_17_u.rxtx_fcl_22_17
                            = ((pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 17) & 0x3F);
            cm_packet_header.src_cvlan_id_valid_u.rxtx_fcl_16
                            = ((pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 16) & 0x1);
            cm_packet_header.src_cvlan_id_u.rxtx_fcl_15_4
                            = ((pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 4) & 0xFFF);
            cm_packet_header.rxtx_fcl3_u.rxtx_fcl_3
                            = ((pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 3) & 0x1);
            cm_packet_header.rxtx_fcl2_1_u.rxtx_fcl_2_1
                            = ((pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 >> 1) & 0x3);
            cm_packet_header.rxtx_fcl0_u.rxtx_fcl_0
                            = (pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 & 0x1);
            cm_packet_header.pbb_src_port_type_u.share2.lm_received_packet = pkt_info->share_fields_u.oam.lm_received_packet;
        }
    }
    else if (SHARE_TYPE_PTP == pkt_info->share_type) /* PTP */
    {
        cm_packet_header.operation_type = OPERATION_TYPE_PTP;
        p_ms_net_tx->ptp_offset = pkt_info->ptp_offset;  /* to NetTx */
        cm_set_ptp_timestamp_in_header(&cm_packet_header,
                                       pkt_info->share_fields_u.ptp.time_stamp_61_32,
                                       pkt_info->share_fields_u.ptp.time_stamp_31_0);

        cm_packet_header.source_port_isolate_id_u.share1.ptp_sequence_id = pkt_info->share_fields_u.ptp.ptp_sequence_id;
        cm_packet_header.source_port_isolate_id_u.share1.ptp_edit_type = pkt_info->share_fields_u.ptp.ptp_edit_type;

        p_ms_net_tx->udp_ptp = pkt_info->udp_ptp;  /* to NetTx */
        p_ms_net_tx->layer4_check_sum = pkt_info->new_l4_check_sum;
        p_ms_net_tx->frag_info1 = IS_BIT_SET(pkt_info->frag_info,1);  /* PacketHeader.fragInfo.1 ??? */

        cm_packet_header.source_port_isolate_id_u.share1.ptp_offset_type = pkt_info->ptp_offset_type;
        cm_packet_header.ip_sa_u.share1.src_dscp = pkt_info->new_dscp;
    }
    else if (pkt_info->tx_dm_en)  /* DM */
    {
        p_ms_net_tx->ptp_offset = pkt_info->ptp_offset;  /* to NetTx */
        cm_packet_header.operation_type = OPERATION_TYPE_PTP;
        cm_packet_header.source_port_isolate_id_u.share1.ptp_offset_type = 0x3;
        cm_packet_header.source_port_isolate_id_u.share1.ptp_edit_type = pkt_info->is_up ? 1 : 0;
        cm_set_ptp_timestamp_in_header(&cm_packet_header,
                                       pkt_info->share_fields_u.ptp.time_stamp_61_32,
                                       pkt_info->share_fields_u.ptp.time_stamp_31_0);
    }
    else  /* normal */
    {
        cm_packet_header.ip_sa_u.share1.src_dscp = pkt_info->new_dscp;
        cm_packet_header.logic_src_port_u.share1.logic_src_port = pkt_info->logic_src_port;
        cm_packet_header.fid_u.share1.fid = pkt_info->fid;
    }

    p_ms_net_tx->channel_lized_valid = channel_ized_valid;

    /* EXCEPTION */
    /* asicHardError is parity/ECC(memory) erro, BridgeHeader error, MAC error(fragment, jumbo frame, etc??? ) */

    greatbelt_exception_info = pkt_info->bexception;
    sal_memset(greatbelt_exception_info, 0, sizeof(greatbelt_exception_info_t));

    greatbelt_exception_info->dest_id_discard = !loopback_en;   /* no loopback,the header should be marked as discard */

    if (!asic_hard_error)
    {
        /* exceptions */
        greatbelt_exception_info = pkt_info->bexception;
        greatbelt_exception_info->exception_packet_type = pkt_info->packet_type;/* get original packet type */
        greatbelt_exception_info->exception_vector = (pkt_info->port_log_en << 7)
                                                     | (pkt_info->acl_log_en3 << 6)
                                                     | (pkt_info->acl_log_en2 << 5)
                                                     | (pkt_info->acl_log_en1 << 4)
                                                     | (pkt_info->acl_log_en0 << 3)
                                                     | (pkt_info->l3_span_en << 2)
                                                     | (pkt_info->l2_span_en << 1)
                                                     | pkt_info->exception_en;
        if (pkt_info->discard)
        {
            exception_vector = greatbelt_exception_info->exception_vector;
            exception_vector &= ((epe_header_edit_ctl.log_on_discard << 1) | 0x1);
            greatbelt_exception_info->exception_vector = (exception_vector & 0xFF);
        }

        greatbelt_exception_info->l2_span_id = pkt_info->l2_span_id;
        greatbelt_exception_info->l3_span_id = pkt_info->l3_span_id;
        greatbelt_exception_info->acl_log_id3 = pkt_info->acl_log_id3;
        greatbelt_exception_info->acl_log_id2 = pkt_info->acl_log_id2;
        greatbelt_exception_info->acl_log_id1 = pkt_info->acl_log_id1;
        greatbelt_exception_info->acl_log_id0 = pkt_info->acl_log_id0;
        greatbelt_exception_info->egress_exception = TRUE;
        greatbelt_exception_info->exception_number = pkt_info->exception_index;

        if (pkt_info->tmp_strip_error)
        {
            p_ms_net_tx->loopback_en = FALSE;
            p_ms_net_tx->mac_valid = FALSE;
        }
        else
        {
            p_ms_net_tx->loopback_en = loopback_en;
            p_ms_net_tx->mac_valid = !net_tx_discard;  /* only for EPE to NetTx to ELOOP_ELOG to MUX_LAN */
        }

        if (pkt_info->discard && greatbelt_exception_info->exception_vector)
        {
            CMODEL_DEBUG_OUT_INFO("================ EPE Discard and exception ====== START\n");
            CMODEL_DEBUG_OUT_INFO("********** pkt_info->bypass_all = 0x%x\n", pkt_info->bypass_all);
            CMODEL_DEBUG_OUT_INFO("********** exceptionVector = 0x%x\n", greatbelt_exception_info->exception_vector);
            CMODEL_DEBUG_OUT_INFO("********** egressException = 0x%x\n", greatbelt_exception_info->egress_exception);
            CMODEL_DEBUG_OUT_INFO("********** pkt_info->discard_type = %d\n", pkt_info->discard_type);
            CMODEL_DEBUG_OUT_INFO("================ EPE Discard and exception ======= END\n");
        }
        else if (pkt_info->discard)
        {
            CMODEL_DEBUG_OUT_INFO("================ EPE Discard No exception ====== START\n");
            CMODEL_DEBUG_OUT_INFO("********** pkt_info->bypass_all = 0x%x\n", pkt_info->bypass_all);
            CMODEL_DEBUG_OUT_INFO("********** pkt_info->discard_type = %d\n", pkt_info->discard_type);
            CMODEL_DEBUG_OUT_INFO("================ EPE Discard No exception ======= END\n");
        }
    }

    complete_discard = asic_hard_error || (net_tx_discard && !loopback_en && !greatbelt_exception_info->exception_vector);
    pkt_info->tmp_complete_discard = complete_discard;

    bheader = pkt_info->bheader;
    sal_memset(bheader, 0, sizeof(ms_packet_header_t));
    cm_gen_greatbelt_packet_header(bheader, &cm_packet_header, FALSE);

    DRV_IF_ERROR_RETURN(swap32((uint32 *)bheader, GREAT_BELT_HEADER_LEN / 4, HOST_TO_NETWORK));
    temp_packet_header = (uint8*)bheader;
    /* header crc */
    temp_packet_header[GREATBELT_HDR_CRC_OFFSET] &= 0xF0; /* clear headerCRC[3:0] */
    temp_packet_header[GREATBELT_HDR_CRC_OFFSET] |= calculate_crc4((uint8 *)bheader, GREAT_BELT_HEADER_LEN, 0);

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_discard_type)
    {
        cosim_db.store_discard_type(pkt_info->discard, pkt_info->discard_type);
    }

    if (cosim_db.store_bheader)
    {
        DRV_IF_ERROR_RETURN(swap32((uint32 *)bheader, GREAT_BELT_HEADER_LEN / 4, NETWORK_TO_HOST));
        DRV_IF_ERROR_RETURN(cosim_db.store_bheader(((void *)bheader), SIM_MODULE_EPE));
    }
#endif

    /* always update crc */
    DRV_IF_ERROR_RETURN(ctcutil_crc32(0xFFFFFFFF, ipkt->pkt, (pkt_info->packet_length - 4), &crc));
    DRV_IF_ERROR_RETURN(swap32(&crc, 1, HOST_TO_NETWORK));
    ipkt->pkt[pkt_info->packet_length - 4] = (crc >> 24) & 0xFF;
    ipkt->pkt[pkt_info->packet_length - 3] = (crc >> 16) & 0xFF;
    ipkt->pkt[pkt_info->packet_length - 2] = (crc >> 8) & 0xFF;
    ipkt->pkt[pkt_info->packet_length - 1] = crc & 0xFF;

    /* stats epe pktinfo discard */
    if (pkt_info->discard)
    {
        sim_cmodel_debug_show_discard(CTC_CMODEL_DEBUG_EPE, pkt_info->discard_type);
        DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_EGRESS_DISCARD,
                                                    pkt_info->discard_type, pkt_info->packet_length));
    }

    /* stats epe loopback */
    if (loopback_en)
    {
        DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_STATS_ELOOP, 0, 0));
    }

    /* stats epe exceptions */
    if (greatbelt_exception_info->exception_vector)
    {
        DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_STATS_EXCEPTION, 0, 0));
    }

    /* stats epe complete discard */
    if(complete_discard)
    {
        DRV_IF_ERROR_RETURN(sim_increase_statistics(ipkt->chip_id, CM_STATS_COMPLETE_DISCARD, 0, 0));
    }

    /* to NET_TX */
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      cm_epe_header_editing_handle
 * Purpose:   perform actual header editing operation on the original payload.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32
cm_epe_header_editing_handle(epe_in_pkt_t* ipkt)
{
    uint16 header_len = 0;

    DRV_PTR_VALID_CHECK(ipkt);
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Header Editing Process");

    DRV_IF_ERROR_RETURN(_cm_epe_header_editing_update_stats(ipkt));
    DRV_IF_ERROR_RETURN(_cm_epe_header_editing_edit_header(ipkt, &header_len));
    DRV_IF_ERROR_RETURN(_cm_epe_header_editing_destination(ipkt, header_len));
    return DRV_E_NONE;
}

