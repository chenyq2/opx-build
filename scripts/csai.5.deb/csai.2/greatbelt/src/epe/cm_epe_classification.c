/****************************************************************************
 * cm_epe_clsssfication.c    Provides EPE classification function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-10-24.
 * Reason:       First Create.
 *
 * Revision:     V1.0.
 * Author:       JiaK.
 * Date:         2010-11-22.
 * Reason:       Sync spec Revision 5.0.0.
 *
 * Revision:     V2.0.
 * Author:       JiaK.
 * Date:         2010-11-22.
 * Reason:       Sync spec Revision 3.0.3.
 *
 * Revision:     V4.2.1.
 * Author:       Shenhg.
 * Date:         2011-7-5.
 * Reason:       Sync spec Revision 4.2.1.
 *
 * Revision:     V4.28.
 * Author:       JiaK.
 * Date:         2011-09-28.
 * Reason:       Sync spec Revision 4.28.
 *
 * Revision:     V5.1.0
 * Author:       JiaK.
 * Date:         2011-12-13.
 * Reason:       sync spec to v5.1.0
 *
 * Revision:     V5.6.0
 * Author:       JiaK.
 * Date:         2012-01-7.
 * Reason:       sync spec to v5.6.0
 *
 * Revision:     V5.11.0
 * Author:       Wangcy.
 * Date:         2012-03-01.
 * Reason:       sync spec to v5.11.0
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "cm_com_policing.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/
/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/

/****************************************************************************
 * Name:      cm_epe_classification_handle
 * Purpose:   perform egress packet classification and request egress
              policing operation.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32
cm_epe_classification_handle(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    epe_classification_ctl_t epe_class_ctl;
    epe_ipg_ctl_t  epe_ipg_ctl;
    policing_info_t policing_info;

    uint8 ipg = 0;
    uint8 phb_label = 0;
    uint8 phb_color = 0;
    uint8 new_color = 0;

    uint8 port_policer_valid = FALSE;
    uint8 flow_policer_valid = FALSE;
    uint16 inport_policer = 0;

    uint16 port_policer = 0;
    uint16 flow_policer = 0;
    uint16 policer_len = 0;
    uint32 phb_offset_field_id = 0;
    uint32 policer_layer3_offset = 0;
    uint32 tmp_phb_offset = 0;
    uint32 cmd = 0;
    uint8 phb_offset = 0;
    uint8 channel_policing_en = FALSE;

    new_color = pkt_info->color;

    if (pkt_info->packet_length_adjust_type)   /* store-and-forward / EOP, real packet length */
    {
        pkt_info->packet_length -= pkt_info->packet_length_adjust;
    }
    else
    {
        pkt_info->packet_length += pkt_info->packet_length_adjust;
    }

    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    sal_memset(&policing_info, 0, sizeof(policing_info));
    policing_info.new_color = new_color;

    /* INCOMING_PHB_STATS */
    phb_label = pkt_info->priority;
    phb_color = pkt_info->color;

    phb_offset_field_id = EpeClassificationPhbOffset_PhbOffset0_f + phb_label;
    cmd = DRV_IOR(EpeClassificationPhbOffset_t, phb_offset_field_id);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &tmp_phb_offset));
    phb_offset = tmp_phb_offset & 0x3;

    /* POLICER_PARAMETERS */
    /* get policer offset,different PHB label may use the same policer */
    sal_memset(&epe_class_ctl, 0, sizeof(epe_class_ctl));
    cmd = DRV_IOR(EpeClassificationCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_class_ctl));

    inport_policer = pkt_info->local_phy_port << epe_class_ctl.port_policer_shift;

    if (epe_class_ctl.port_policer_phb_en)
    {
        port_policer = (inport_policer & 0x1FFF) + (phb_offset & 0x3) + epe_class_ctl.port_policer_base;
    }
    else
    {
        port_policer = (inport_policer & 0x1FFF) + epe_class_ctl.port_policer_base;
    }


    port_policer_valid = pkt_info->port_policer_valid
                         || pkt_info->agg_flow_policer_valid;


    /* Temp code for check lack cfg (zhouw) */
    FILE *fp = NULL;
    char path[] = "../../regression/lackCfgRecord.txt";
    char case_name[512] = {0};
    char *pos = NULL;
    const char match_str[] = "function_testcase/";
    /****************************************/

    if (pkt_info->agg_flow_policer_valid)
    {
        port_policer = (pkt_info->agg_flow_policer_ptr & 0x1FFF);

        fp = fopen(path, "a+");
        if (fp == NULL)
        {
            CMODEL_DEBUG_OUT_INFO("++++++++++++++ EPE Do agg flow policer ++++++++++++++\n");
            CMODEL_DEBUG_OUT_INFO("agg_flow_policer_ptr = %d\n", pkt_info->agg_flow_policer_ptr);
        }
        else
        {
            if (getcwd(case_name, 512))
            {
                pos = sal_strstr(case_name, match_str);
                sal_fprintf(fp, "\n++++++ %s \n", pos+sizeof(match_str)-1);
            }

            sal_fprintf(fp, "EPE Do agg flow policer!\n");
            fclose(fp);
            fp = NULL;
        }
    }


    if (pkt_info->flow_policer_valid)  /* use flow policer from QOS lookup */
    {
        flow_policer = pkt_info->flow_policer_ptr & 0x1FFF;
        flow_policer_valid = TRUE;

        fp = fopen(path, "a+");
        if (fp == NULL)
        {
            CMODEL_DEBUG_OUT_INFO("++++++++++++++ EPE Do Flow policer ++++++++++++++\n");
            CMODEL_DEBUG_OUT_INFO("Flow_policer_ptr = %d\n", pkt_info->flow_policer_ptr);
        }
        else
        {
            if (getcwd(case_name, 512))
            {
                pos = sal_strstr(case_name, match_str);
                sal_fprintf(fp, "\n++++++ %s \n", pos+sizeof(match_str)-1);
            }

            sal_fprintf(fp, "EPE Do Flow policer!\n");
            fclose(fp);
            fp = NULL;
        }
    }
    else if(pkt_info->service_policer_valid)
    {
        flow_policer_valid = TRUE;
        if ( epe_class_ctl.service_policer_mode)    /* not hierachical policer */
        {
            flow_policer = (((pkt_info->logic_dest_port & 0xFFF) << 2) + 1
                            + (((phb_offset & 0x3) == 3) ? 2 : (phb_offset & 0x3))) & 0x1FFF; /* merge 2 and 3 */
            port_policer = ((pkt_info->logic_dest_port & 0xFFF) << 2) & 0x1FFF;
            port_policer_valid = TRUE;

            fp = fopen(path, "a+");
            if (fp == NULL)
            {
                CMODEL_DEBUG_OUT_INFO("++++++++++++++ EPE Do Service policer0 -- triple-play policer mode ++++++++++++++\n");
                CMODEL_DEBUG_OUT_INFO("flow_policer_ptr = %d,  port_policer_ptr= %d\n", flow_policer, port_policer);
            }
            else
            {
                if (getcwd(case_name, 512))
                {
                    pos = sal_strstr(case_name, match_str);
                    sal_fprintf(fp, "\n++++++ %s \n", pos+sizeof(match_str)-1);
                }

                sal_fprintf(fp, "EPE Do Service policer0 -- triple-play policer mode!\n");
                fclose(fp);
                fp = NULL;
            }
        }
        else
        {
            flow_policer = (((pkt_info->logic_dest_port & 0xFFF) << 2) + (phb_offset & 0x3))& 0x1FFF;

            fp = fopen(path, "a+");
            if (fp == NULL)
            {
                CMODEL_DEBUG_OUT_INFO("++++++++++++++ EPE Do Service policer1 -- MEF hierachical policer mode ++++++++++++++\n");
                CMODEL_DEBUG_OUT_INFO("flow_policer_ptr = %d\n", flow_policer);
            }
            else
            {
                if (getcwd(case_name, 512))
                {
                    pos = sal_strstr(case_name, match_str);
                    sal_fprintf(fp, "\n++++++ %s \n", pos+sizeof(match_str)-1);
                }

                sal_fprintf(fp, "EPE Do Service policer1 -- MEF hierachical policer mode!\n");
                fclose(fp);
                fp = NULL;
            }
        }
    }
    else
    {
        flow_policer = 0;
        flow_policer_valid = FALSE;
    }

    /* Only network channel support policing,interLaken/loopback not support */
    policer_len = pkt_info->packet_length;

    policer_layer3_offset = 0;  /* Not support userLayer3Length for egress policer */

    /* POLICING_OPERATION */

    if (ipkt->chan_id > 31)
    {
        channel_policing_en = IS_BIT_SET(epe_class_ctl.channel_policing_en63_32,ipkt->chan_id & 0x1F);
    }
    else
    {
        channel_policing_en = IS_BIT_SET(epe_class_ctl.channel_policing_en31_0,ipkt->chan_id & 0x1F);
    }


    if ((flow_policer_valid || port_policer_valid)&& channel_policing_en)   /* perform policing operation */
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Classification Process");

        sal_memset(&epe_ipg_ctl, 0, sizeof(epe_ipg_ctl));
        cmd = DRV_IOR(EpeIpgCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_ipg_ctl));

        switch (pkt_info->ipg_index)
        {
            case 0:
                ipg = epe_ipg_ctl.ipg0;
                break;
            case 1:
                ipg = epe_ipg_ctl.ipg1;
                break;
            case 2:
                ipg = epe_ipg_ctl.ipg2;
                break;
            case 3:
                ipg = epe_ipg_ctl.ipg3;
                break;
            default:
                break;
        }

        if (epe_class_ctl.flow_policer_first)
        {
            policing_info.chip_id = ipkt->chip_id;
            policing_info.packet_length = (policer_len & 0x3FFF);
            policing_info.color = (phb_color & 0x3);
            policing_info.policer_valid0 = (flow_policer_valid & 0x1);
            policing_info.policer_ptr0 = (flow_policer & 0x1FFF);
            policing_info.layer3_offset = (policer_layer3_offset & 0xFF);
            policing_info.policer_valid1 = (port_policer_valid & 0x1);
            policing_info.policer_ptr1 = (port_policer & 0x1FFF);
            policing_info.ipg = ipg;

            /* here send packet must < 256B, CoSim use */
            policing_info.sop = TRUE;
            policing_info.eop = TRUE;
            policing_info.sop_color = 0;
            DRV_IF_ERROR_RETURN(cm_com_policing_operation(&policing_info));
        }
        else
        {
            policing_info.chip_id = ipkt->chip_id;
            policing_info.packet_length = (policer_len& 0x3FFF);
            policing_info.color = (phb_color & 0x3);
            policing_info.policer_valid0 = (port_policer_valid & 0x1);
            policing_info.policer_ptr0 = (port_policer & 0x1FFF);
            policing_info.layer3_offset = (policer_layer3_offset & 0xFF);
            policing_info.policer_valid1 = (flow_policer_valid & 0x1);
            policing_info.policer_ptr1 = (flow_policer & 0x1FFF);
            policing_info.ipg = ipg;

            /* here send packet must < 256B, CoSim use */
            policing_info.sop = TRUE;
            policing_info.eop = TRUE;
            policing_info.sop_color = 0;
            DRV_IF_ERROR_RETURN(cm_com_policing_operation(&policing_info));
        }
    }

    /* CLASSIFICATION_RESULT */
    if (policing_info.mark_drop && ((OAM_NONE == pkt_info->rx_oam_type) || !epe_class_ctl.oam_bypass_policing_discard))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_POLICING_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE classification mark to drop Packet! File:%s Line:%d Function:%s\n",
                                  __FILE__, __LINE__, __FUNCTION__);
        }
    }

    pkt_info->color = (OAM_NONE != pkt_info->rx_oam_type) ? pkt_info->color : (policing_info.new_color & 0x3);

    return DRV_E_NONE;
}

