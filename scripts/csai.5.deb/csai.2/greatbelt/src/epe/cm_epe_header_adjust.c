/****************************************************************************
 * cm_epe_header_adjust.c: Provides EPE header adjust function.
 *
 * Copyright:    (c)2010 Centec Networks Inc. All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-10-18.
 * Reason:       First create.
 *
 * Revision:     V1.0.
 * Author:       JiaK.
 * Date:         2010-11-16.
 * Reason:       Sync spec revision 5.0.0.
 *
 * Revision:     V2.0.
 * Author:       ZhouW.
 * Date:         2011-04-11.
 * Reason:       V2.0 review done.
 *
 * Revision:     V4.2.1
 * Author:       JiaK.
 * Date:         2011-06-30.
 * Reason:       Sync spec revision 4.2.1.
 *
 * Revision:     V4.3.0
 * Author:       JiaK.
 * Date:         2011-07-11.
 * Reason:       Sync spec revision 4.3.0.
 *
 * Revision:     V4.5.1
 * Author:       JiaK.
 * Date:         2011-07-11.
 * Reason:       Sync spec revision 4.5.1.
 *
 * Revision:     V4.7.1
 * Author:       JiaK.
 * Date:         2011-07-28.
 * Reason:       Sync spec revision 4.7.1.
 *
 * Revision:     V4.28
 * Author:       JiaK.
 * Date:         2011-09-27.
 * Reason:       Sync spec revision 4.28.
 *
 * Revision:     V4.29.3
 * Author:       JiaK.
 * Date:         2011-10-10.
 * Reason:       Sync spec revision 4.29.3
 *
 * Modify History:
 * Revision:     V4.31.0
 * Author:       JiaK.
 * Date:         2011-10-22.
 * Reason:       sync spec to v4.31.0
 *
 * Revision:     V5.1.0
 * Author:       JiaK.
 * Date:         2011-12-9.
 * Reason:       sync spec to v5.1.0
 *
 * Revision:     V5.6.0
 * Author:       JiaK.
 * Date:         2012-01-7.
 * Reason:       sync spec to v5.6.0
 *
 * Revision:     V5.9.0
 * Author:       JiaK.
 * Date:         2012-01-19.
 * Reason:       sync spec to v5.9.0
 *
 * Revision:     V5.9.1
 * Author:       Wangcy.
 * Date:         2012-02-04.
 * Reason:       sync spec to v5.9.1
 *
 * Revision:     V5.11.0
 * Author:       Wangcy.
 * Date:         2012-03-01.
 * Reason:       sync spec to v5.11.0
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "ctcutil_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/
struct epe_hdr_adjust_info_s
{
   uint32 svlan_tag_operation_valid    :1;
   uint32 cvlan_tag_operation_valid    :1;
   uint32 mux_length_type              :2;
   uint32 channel_id                   :5;
   uint32 packet_offset                :8;
   uint32 isid_valid                   :1;
   uint32 acl_dscp_valid               :1;
   uint32 is_ipv4                      :1;
   uint32 parser_packet_type           :3;
   uint32 acl_dscp                     :6;
   uint32 src_vlan_id                  :12;
   uint32 src_cvlan_id                 :12;
   uint32 ptp_parser_offset            :2;
};
typedef struct epe_hdr_adjust_info_s epe_hdr_adjust_info_t;

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
/****************************************************************************
 * Name:      func_packet_length_adjust_add
 * Purpose:   add length adjust.
 * Parameters:
 * Input:     a  --  length adjust parameter
 *            ipkt --  pointer to buffer which save input packet and packet
 *                     header,and processing informations
 * Return:    packetLengthAdjustType,packetLengthAdjust.
 * Note:      none.
****************************************************************************/


uint16 func_packet_length_adjust_add(epe_in_pkt_t* ipkt, uint8 a)
{
    /* a is always positive,PacketInfo.packetLengthAdjustType is symbol bit */
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;

    DRV_PTR_VALID_CHECK(ipkt);

    if (!pkt_info->packet_length_adjust_type)
    {
        pkt_info->packet_length_adjust = pkt_info->packet_length_adjust + a;
    }
    else if (a >= pkt_info->packet_length_adjust)
    {
        pkt_info->packet_length_adjust = a - pkt_info->packet_length_adjust;
        pkt_info->packet_length_adjust_type = 0;
    }
    else
    {
        pkt_info->packet_length_adjust = pkt_info->packet_length_adjust - a;
    }

    return ((pkt_info->packet_length_adjust_type << 8)
                | pkt_info->packet_length_adjust);
}

/****************************************************************************
 * Name:      func_packet_length_adjust_subtract
 * Purpose:   add length adjust.
 * Parameters:
 * Input:     a  --  length adjust parameter
 *            ipkt --  pointer to buffer which save input packet and packet
 *                     header,and processing informations
 * Return:    packetLengthAdjustType,packetLengthAdjust.
 * Note:      none.
****************************************************************************/
uint16 func_packet_length_adjust_subtract(epe_in_pkt_t* ipkt, uint8 a)
{
    /* a is always positive,PacketInfo.packetLengthAdjustType is symbol bit */
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;

    DRV_PTR_VALID_CHECK(ipkt);

    if (pkt_info->packet_length_adjust_type)
    {
        pkt_info->packet_length_adjust = pkt_info->packet_length_adjust + a;
    }
    else if (a > pkt_info->packet_length_adjust)
    {
        pkt_info->packet_length_adjust = a - pkt_info->packet_length_adjust;
        pkt_info->packet_length_adjust_type = 1;
    }
    else
    {
        pkt_info->packet_length_adjust = pkt_info->packet_length_adjust - a;
    }

    return ((pkt_info->packet_length_adjust_type << 8)
                | pkt_info->packet_length_adjust);
}

/****************************************************************************
 * Name:      _cm_reclac_ip_checksum
 * Purpose:   Recalculate ip checksum.
 * Parameters:
 * Input:     old_u16  --  old data
 *            new_u16 -- new data
 *            old_chksum -- old checksum
 * Return:    new checksum.
 * Note:      none.
****************************************************************************/
static uint16
_cm_reclac_ip_checksum(uint16 old_u16, uint16 new_u16, uint16 old_chksum)
{
    uint32 sum;
    uint16 new_sum;

    sum = (~old_chksum) & 0xFFFF;

    sum = sum + (~old_u16 & 0xFFFF);
    sum = (sum >> 16) + (sum & 0xFFFF);

    sum = sum + new_u16;
    new_sum = (sum >> 16) + (sum & 0xFFFF);

    return (~new_sum);
}

/****************************************************************************
 * Name:       _cm_epe_header_adjust_recover_fields
 * Purpose:    Get the fields info from the forwarding packet header.
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet
               pkt_hdr -- pointer to buffer which save input packet header
 * Output:     pkt_info  -- pointer to buffer which save input packet
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       None.
 ****************************************************************************/
static int32
_cm_epe_header_adjust_recover_fields(epe_in_pkt_t* ipkt, greatbelt_packet_header_t* pkt_hdr,epe_hdr_adjust_info_t *p_epe_hdr_adjust_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*)ipkt->pkt_info;
    epe_hdr_adjust_ctl_t epe_hdr_adjust_ctl;

    uint8 fid_valid = FALSE;
    uint32 cmd = 0;
    uint32 dm_timestamp_31_0 =0;
    uint32 dm_timestamp_61_32 =0;
    uint32 ptp_timestamp_31_0 = 0;
    uint32 ptp_timestamp_61_32 = 0;

    sal_memset(&epe_hdr_adjust_ctl, 0, sizeof(epe_hdr_adjust_ctl));
    cmd = DRV_IOR(EpeHdrAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_hdr_adjust_ctl));

    /* RECOVER_FIELDS */

    /* if (Asic error) parity/ECC(memory)error,data error,packet CRC error,PacketHeader CRC error, */
    /* destIdDiscard for BufferRetrieve */
    /* channelId[5:0] from BufferRetrieve */

    if (ipkt->module_bus.dest_id_discard)
    {
        pkt_info->bypass_all = TRUE;
        pkt_info->discard = TRUE;
        pkt_info->discard_type = EPE_DISCARD_EPE_HDR_ADJ_DEST_ID_DISCARD;

        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Bridge header destIdDicard is set!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }

    p_epe_hdr_adjust_info->channel_id = ipkt->chan_id;
    pkt_info->packet_length = ipkt->module_bus.pkt_len;
    pkt_info->priority = pkt_hdr->priority;
    pkt_info->color = pkt_hdr->color;
    pkt_info->source_port = (pkt_hdr->source_port15_14 << 14) | pkt_hdr->source_port;
    pkt_info->source_cos = pkt_hdr->source_cos;
    pkt_info->logic_port_type = pkt_hdr->logic_port_type;
    pkt_info->header_hash = (pkt_hdr->header_hash7_3 << 3)           /* headerHash[7:3] */
                            | pkt_hdr->header_hash2_0;               /* headerHash[2:0] */
    pkt_info->from_fabric = pkt_hdr->from_fabric;
    pkt_info->dest_map = (pkt_hdr->mcast << 21) | (pkt_hdr->dest_chip_id << 16) | pkt_hdr->dest_id;
    pkt_info->svlan_tpid_index = pkt_hdr->svlan_tpid_index_u.svlan_tpid_index;
    pkt_info->next_hop_ext = pkt_hdr->next_hop_ext;
    pkt_info->src_svlan_id_valid = pkt_hdr->src_svlan_id_valid;
    pkt_info->src_vlan_ptr = pkt_hdr->src_vlan_ptr_t.share1.src_vlan_ptr;    /* srcVlanPtr[12:0] */
    pkt_info->source_cfi = pkt_hdr->source_cfi;
    pkt_info->src_cvlan_id_valid = pkt_hdr->src_cvlan_id_valid_u.src_cvlanid_valid;
    pkt_info->non_crc = pkt_hdr->non_crc;

    pkt_info->from_cpu_or_oam = pkt_hdr->from_cpu_or_oam;
    pkt_info->packet_type = pkt_hdr->packet_type;
    pkt_info->source_port_extender = pkt_hdr->source_port_extender;
    pkt_info->port_mac_sa_en = pkt_hdr->flow_u.share1.port_mac_sa_en;
    pkt_info->ingress_edit_en = pkt_hdr->src_vlan_ptr_t.share1.ingress_edit_en;
    pkt_info->outer_vlan_is_cvlan = pkt_hdr->src_vlan_ptr_t.share1.outer_vlan_is_cvlan;
    pkt_info->bridge_operation = pkt_hdr->bridge_operation;
    pkt_info->from_cpu_lm_up_disable = pkt_hdr->flow_u.share1.from_cpu_lm_up_disable;
    pkt_info->from_cpu_lm_down_disable = pkt_hdr->src_vlan_ptr_t.share1.from_cpu_lm_down_disable;
    pkt_info->oam_use_fid = pkt_hdr->rxtx_fcl0_u.oam_use_fid
                        && epe_hdr_adjust_ctl.oam_fid_en  /* oamUseFid */
                        && (pkt_hdr->operation_type == OPERATION_TYPE_NORMAL);

    pkt_info->next_hop_ptr = pkt_hdr->next_hop_ptr;
    pkt_info->ingress_edit_nexthop_bypass_all = pkt_hdr->loopback_discard_u.ds_next_hop_dot_bypass_all
                                                && pkt_hdr->from_fabric;
    if ((OPERATION_TYPE_PTP == pkt_hdr->operation_type) && pkt_info->ingress_edit_en && pkt_hdr->from_fabric)
    {
        pkt_info->ptp_offset = pkt_hdr->ttl_u.ptp_offset;
    }
    else
    {
        cm_get_dm_rx_timestamp_in_header(pkt_hdr,&dm_timestamp_61_32,&dm_timestamp_31_0);
        pkt_info->ptp_offset = dm_timestamp_31_0 & 0xFF;
    }

    p_epe_hdr_adjust_info->src_vlan_id = pkt_hdr->src_vlan_id_u.src_vlan_id;
    p_epe_hdr_adjust_info->src_cvlan_id = pkt_hdr->src_cvlan_id_u.src_cvlan_id;

    if (!pkt_info->packet_header_en_egress || (OPERATION_TYPE_LM_TX == pkt_hdr->operation_type))
    {
        p_epe_hdr_adjust_info->parser_packet_type = pkt_hdr->packet_type;
    }
    else
    {
        p_epe_hdr_adjust_info->parser_packet_type = PKT_TYPE_RESERVED;
    }

    pkt_info->congestion_valid = pkt_hdr->ip_sa_u.share1.congestion_valid && (pkt_hdr->operation_type == OPERATION_TYPE_NORMAL);
    p_epe_hdr_adjust_info->svlan_tag_operation_valid = pkt_hdr->svlan_tag_operation_valid;
    p_epe_hdr_adjust_info->cvlan_tag_operation_valid = pkt_hdr->ip_sa_u.share1.cvlan_tag_operation_valid
                                    && (pkt_hdr->operation_type == OPERATION_TYPE_NORMAL);
    p_epe_hdr_adjust_info->mux_length_type = pkt_hdr->mux_length_type;

    if ((OPERATION_TYPE_OAM == pkt_hdr->operation_type )
        || (OPERATION_TYPE_PTP == pkt_hdr->operation_type))   /* egress port property only in egress chip */
    {
        pkt_info->source_port_isolate_id = 0;  /* OAM/PTP no port isolate */
    }
    else
    {
        pkt_info->source_port_isolate_id = pkt_hdr->source_port_isolate_id_u.source_port_isolate_id;
    }

    pkt_info->src_leaf = pkt_hdr->flow_u.share1.is_leaf;   /* isLeaf */
    pkt_info->packet_ttl = pkt_hdr->ttl_u.ttl;

    if (pkt_info->from_fabric)
    {
        if (pkt_info->packet_header_en)
        {
            p_epe_hdr_adjust_info->packet_offset = pkt_hdr->packet_offset; /* from stackiing to stacking,remove outer L2/L3 header */
        }
        else
        {
            p_epe_hdr_adjust_info->packet_offset = pkt_hdr->packet_offset + GREAT_BELT_HEADER_LEN;   /* from stacking to network,remove all header */
        }
    }
    else
    {
        if (!((OPERATION_TYPE_OAM == pkt_hdr->operation_type)&& pkt_hdr->ip_sa_u.share2.rx_oam))
        {
            p_epe_hdr_adjust_info->packet_offset = pkt_hdr->packet_offset;    /* always remove header in ingress chip */
        }
    }

    if (p_epe_hdr_adjust_info->svlan_tag_operation_valid)
    {
        pkt_info->stag_action = pkt_hdr->stag_action;
    }

    if (p_epe_hdr_adjust_info->cvlan_tag_operation_valid)
    {
        pkt_info->src_ctag_offset_type = pkt_hdr->src_ctag_offset_type_u.src_ctag_offset_type;
        pkt_info->ctag_action = pkt_hdr->ttl_u.share1.ctag_action;      /* cTagAction[1:0] */
        pkt_info->src_ctag_cos = pkt_hdr->ttl_u.share1.src_ctag_cos;    /* srcCtagCos[2:0] */
        pkt_info->src_ctag_cfi = pkt_hdr->ttl_u.share1.src_ctag_cfi;    /* srcCtagCfi */
    }

    /* PTP, MAC property, only in egress chip */
    if ((OPERATION_TYPE_PTP == pkt_hdr->operation_type) && !pkt_info->packet_header_en_egress)
    {
        pkt_info->share_type = SHARE_TYPE_PTP;
        /* PacketInfo.shareFields[97:0] */
        pkt_info->share_fields_u.ptp.ptp_extra_offset = pkt_hdr->pbb_src_port_type_u.share3.ptp_extra_offset;
        p_epe_hdr_adjust_info->ptp_parser_offset = pkt_hdr->pbb_src_port_type_u.share3.ptp_extra_offset;
        pkt_info->share_fields_u.ptp.ptp_sequence_id = pkt_hdr->source_port_isolate_id_u.share1.ptp_sequence_id;   /* ptpSequenceId[1:0] */

        /* MAC capture/insert/capture&insert/correct timeStamp */
        pkt_info->share_fields_u.ptp.ptp_edit_type = pkt_hdr->source_port_isolate_id_u.share1.ptp_edit_type;       /* ptpEditType[1:0] */
        cm_get_ptp_timestamp_in_header(pkt_hdr,&ptp_timestamp_61_32,&ptp_timestamp_31_0);
        pkt_info->share_fields_u.ptp.time_stamp_31_0 = ptp_timestamp_31_0;
        pkt_info->share_fields_u.ptp.time_stamp_61_32 = ptp_timestamp_61_32;

        if (p_epe_hdr_adjust_info->ptp_parser_offset != 0)
        {
            pkt_info->packet_type = PKT_TYPE_MPLS;
        }
    }

    /* NAT(PT) */
    if ((OPERATION_TYPE_NAT == pkt_hdr->operation_type) && !pkt_info->packet_header_en)
    {
        pkt_info->share_type = SHARE_TYPE_NAT;
        /* PacketInfo.shareFields[97:0] */
        pkt_info->share_fields_u.nat.new_ip_sa_31_0 = pkt_hdr->ip_sa_u.ip_sa;
        pkt_info->share_fields_u.nat.new_ip_sa_39_32 = pkt_hdr->fid_u.share2.ip_sa_39_32;
        pkt_info->share_fields_u.nat.new_l4_source_port = pkt_hdr->logic_src_port_u.l4_source_port;                         /* edit here ??? */
        pkt_info->share_fields_u.nat.new_ip_sa_valid = pkt_hdr->pbb_src_port_type_u.share1.ip_sa_valid;                     /* ipSaValid */
        pkt_info->share_fields_u.nat.new_l4_source_port_valid = pkt_hdr->pbb_src_port_type_u.share1.l4_source_port_valid;   /* l4SourcePortValid */
        pkt_info->share_fields_u.nat.pt_enable = pkt_hdr->pbb_src_port_type_u.share1.pt_enable;                             /* used as ptEnable */
        pkt_info->share_fields_u.nat.ipv4_src_embeded_mode = pkt_hdr->fid_u.share2.ipv4_src_embeded_mode;                   /* used as ipv4SrcEmbededMode */
        pkt_info->share_fields_u.nat.ip_sa_mode = pkt_hdr->fid_u.share2.ip_sa_mode;
        pkt_info->share_fields_u.nat.src_address_mode = pkt_hdr->fid_u.share2.src_address_mode;
        pkt_info->share_fields_u.nat.ip_sa_prefix_length = pkt_hdr->fid_u.share2.ip_sa_prefix_length;
    }

    /* Normal */
    if (OPERATION_TYPE_NORMAL == pkt_hdr->operation_type)
    {
        p_epe_hdr_adjust_info->isid_valid = pkt_hdr->ip_sa_u.share1.isid_valid;
        p_epe_hdr_adjust_info->acl_dscp_valid = pkt_hdr->fid_u.share1.acl_dscp_valid;
        p_epe_hdr_adjust_info->acl_dscp = pkt_hdr->ip_sa_u.share1.acl_dscp;
        p_epe_hdr_adjust_info->is_ipv4 = pkt_hdr->ip_sa_u.share1.is_ipv4;
        pkt_info->roaming_state = pkt_hdr->rxtx_fcl2_1_u.capwap_state;
        pkt_info->src_dscp = pkt_hdr->ip_sa_u.share1.src_dscp;
    }

    /* ======== bug 4740 ECO begine ========= */
    pkt_info->mac_known = TRUE;
    /* ======== bug 4740 ECO end ========= */

    if (OPERATION_TYPE_NORMAL == pkt_hdr->operation_type)
    {
        pkt_info->logic_src_port = pkt_hdr->logic_src_port_u.share1.logic_src_port;
        pkt_info->pbb_check_discard = pkt_hdr->logic_src_port_u.share1.pbb_check_discard;
        pkt_info->mac_known = pkt_hdr->ip_sa_u.share1.mac_known;
    }

    fid_valid = ((!epe_hdr_adjust_ctl.port_extender_mcast_en)
                && (OPERATION_TYPE_NORMAL == pkt_hdr->operation_type));

    pkt_info->fid = fid_valid ? pkt_hdr->fid_u.share1.fid : 0;
    pkt_info->mcast_id = pkt_hdr->fid_u.share1.fid;

    pkt_info->oam_tunnel_en = pkt_hdr->oam_tunnel_en;

    if (OPERATION_TYPE_LM_TX == pkt_hdr->operation_type)
    {
        pkt_info->share_type = SHARE_TYPE_LMTX;
        pkt_info->share_fields_u.lmtx.lm_packet_type = pkt_hdr->pbb_src_port_type_u.share2.lm_packet_type;
        /* rxFcb[31:0] */
        pkt_info->share_fields_u.lmtx.rx_fcb = (pkt_hdr->fid_u.rx_fcb_31_16 << 16) | pkt_hdr->logic_src_port_u.rx_fcb_15_0;
        /* txFcb[31:0] */
        pkt_info->share_fields_u.lmtx.tx_fcb = pkt_hdr->ip_sa_u.tx_fcb_31_0;
        /* txFcl[31:0] */
        pkt_info->share_fields_u.lmtx.rxtx_fcl = (pkt_hdr->src_ctag_offset_type_u.rxtx_fcl_31 << 31)
                           | (pkt_hdr->ttl_u.rxtx_fcl_30_23 << 23)
                           | (pkt_hdr->rxtx_fcl_22_17_u.rxtx_fcl_22_17 << 17)
                           | (pkt_hdr->src_cvlan_id_valid_u.rxtx_fcl_16 << 16)
                           | (pkt_hdr->src_cvlan_id_u.rxtx_fcl_15_4 << 4)
                           | (pkt_hdr->rxtx_fcl3_u.rxtx_fcl_3 << 3)
                           | (pkt_hdr->rxtx_fcl2_1_u.rxtx_fcl_2_1 << 1)
                           | pkt_hdr->rxtx_fcl0_u.rxtx_fcl_0;

    }

    /* OAM */
    if (OPERATION_TYPE_OAM == pkt_hdr->operation_type)
    {
        pkt_info->rx_oam_type = pkt_hdr->ip_sa_u.share2.oam_type;          /* oamType[3:0] */
        pkt_info->link_or_section_oam = pkt_hdr->ip_sa_u.share3.link_oam;
        pkt_info->from_cpu_lm_up_disable = TRUE;                            /* oam engine tx down mep, not count in epe up emp */
        if (pkt_hdr->ip_sa_u.share2.oam_type == OAM_ACH)
        {
            pkt_info->cw_add = pkt_hdr->ip_sa_u.share2.mip_en_or_cw_added;       /* cwAdded */
            pkt_info->gal_exist = pkt_hdr->ip_sa_u.share2.gal_exist;
            pkt_info->entropy_label_exist = pkt_hdr->ip_sa_u.share2.entropy_label_exist;
            pkt_info->mpls_label_disable = pkt_hdr->ip_sa_u.share3.mpls_label_disable;
        }
    }
    else
    {
        pkt_info->is_up = TRUE;
    }

    /* Down Mep DM TX to local, UP MEP DM local iloop to local/remote */
    pkt_info->tx_dm_en = (pkt_hdr->operation_type == OPERATION_TYPE_DM_TX) /* UP MEP DM */
            ||((pkt_hdr->operation_type == OPERATION_TYPE_OAM)   /* Down MEP DM */
              && pkt_hdr->ip_sa_u.share3.dm_en && !pkt_info->packet_header_en);

    if (pkt_hdr->operation_type == OPERATION_TYPE_DM_TX)
    {
        uint32 temp_time_stamp_61_32, temp_time_stamp_31_0;
        cm_get_dm_tx_timestamp_in_header(pkt_hdr, &temp_time_stamp_61_32, &temp_time_stamp_31_0);
        pkt_info->share_fields_u.dmtx.time_stamp_61_32 = temp_time_stamp_61_32;
        pkt_info->share_fields_u.dmtx.time_stamp_31_0 = temp_time_stamp_31_0;

        pkt_info->mac_known = TRUE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      cm_epe_header_adjust_handle
 * Purpose:   Remove the forwarding packet header to recover the original
              packet and removes number of bytes indicated by the packetOffset
              field in the forwarding packet header.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header,and processing informations
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:      None.
 ****************************************************************************/
int32
cm_epe_header_adjust_handle(epe_in_pkt_t* ipkt)
{
    #define MAX_PARSER_PACKET_LEN   256
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    ms_packet_header_t pkt_hdr;
    greatbelt_packet_header_t cm_packet_header;
    parser_info_t parser_info;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_result;
    epe_hdr_adjust_ctl_t epe_hdr_adjust_ctl;
    epe_port_extender_downlink_t epe_port_extender_downlink;
    epe_header_adjust_phy_port_map_t epe_header_adjust_phy_port_map;
    epe_next_hop_ptr_cam_t epe_next_hop_ptr_cam;
    epe_hdr_adjust_info_t epe_hdr_adjust_info;

    int32 ret = DRV_E_NONE;
    uint8 first_buffer_length = 0xFF;
    uint8 cvlan_offset = 0;
    uint8 svlan_offset = 0;
    uint8 parser_layer4_type = 0;
    uint16 cvlan_tpid = 0, svlan_tpid = 0;
    uint32 remove_len = 0;
    uint32 cmd = 0;
    uint8* p_pkt_dscp = NULL;
    uint32 isid_offset = 0;
    uint8 mux_offset = 0;
    uint8 adjust_offset = 0;
    uint8 port_extender_downlink = FALSE;
    uint32 port_extender_downlink_bitmap = 0;
    uint8 packet_header_en_ingress = FALSE,packet_header_edit_ingress = FALSE;
    uint16 new_ip_check_sum = 0;
    uint16 old_u16 = 0,new_u16 = 0;
    uint8* p_pkt_layer3offset10 = NULL;
    uint8* p_pkt_layer3offset11 = NULL;
    uint16 packet_length_adjust = 0;
    uint32 ds_next_hop_index = 0;
    uint32 temp_packet_len = ipkt->packet_length;

    DRV_PTR_VALID_CHECK(ipkt);

    sal_memset(&pkt_hdr, 0, sizeof(pkt_hdr));
    sal_memcpy(&pkt_hdr, ipkt->module_bus.packet_header, sizeof(pkt_hdr));
    DRV_IF_ERROR_RETURN(swap32((uint32*)(&pkt_hdr), GREAT_BELT_HEADER_LEN / 4, NETWORK_TO_HOST));

    /* Store epe input GreatBelt Header */
    ret = sim_asic_gen_epe_bhdr_inpkt(&pkt_hdr);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("Store EPE GreatBelt Header error!\n");
        return ret;
    }

    sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));
    cm_gen_greatbelt_packet_header(&pkt_hdr, &cm_packet_header, TRUE);

    /* note by zhouw because ipe->bsr->epe --- > ipe->bsr->epe process */
    /* ipkt->chip_id = cm_packet_header.dest_chip_id; */

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Header Adjust Process");

    sal_memset(&epe_hdr_adjust_ctl, 0, sizeof(epe_hdr_adjust_ctl_t));
    cmd = DRV_IOR(EpeHdrAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_hdr_adjust_ctl));

    /* INIT */
    /* Edit in IPE delayed to this should be done in splite of ingress/egress edit.Other egress editing action can be bypassed */

    if (ipkt->chan_id <= 31)
    {
        if (IS_BIT_SET(epe_hdr_adjust_ctl.packet_header_en31_0, ipkt->chan_id))
        {
            pkt_info->packet_header_en = TRUE;
        }

        if (IS_BIT_SET(epe_hdr_adjust_ctl.packet_header_edit_ingress31_0, ipkt->chan_id))
        {
            packet_header_edit_ingress = TRUE;
        }
    }
    else if (ipkt->chan_id <= 63)
    {
        if (IS_BIT_SET(epe_hdr_adjust_ctl.packet_header_en63_32, ipkt->chan_id - 32))
        {
            pkt_info->packet_header_en = TRUE;
        }

        if (IS_BIT_SET(epe_hdr_adjust_ctl.packet_header_edit_ingress63_32, ipkt->chan_id - 32))
        {
            packet_header_edit_ingress = TRUE;
        }
    }

    packet_header_en_ingress = pkt_info->packet_header_en && !cm_packet_header.from_fabric
                                && !cm_packet_header.bypass_ingress_edit
                                && packet_header_edit_ingress
                                && !cm_packet_header.mcast;  /* only network to fabric */

    pkt_info->packet_header_en_egress = pkt_info->packet_header_en && (!packet_header_en_ingress
                                        || (cm_packet_header.operation_type == OPERATION_TYPE_OAM));
    pkt_info->bypass_all = pkt_info->packet_header_en_egress && epe_hdr_adjust_ctl.packet_header_bypass_all;

    /* send PacketHeader(IngressHeader from BufferRetrieve(sideband)) to EPE Header Edit for later edit */
    sal_memcpy((void *)pkt_info->ingress_header, (void *)ipkt->module_bus.packet_header, GREAT_BELT_HEADER_LEN);
    DRV_IF_ERROR_RETURN(swap32((uint32*)(pkt_info->ingress_header), GREAT_BELT_HEADER_LEN / 4, NETWORK_TO_HOST));

    /* RECOVER_FIELDS */
    sal_memset(&epe_hdr_adjust_info, 0, sizeof(epe_hdr_adjust_info));
    DRV_IF_ERROR_RETURN(_cm_epe_header_adjust_recover_fields(ipkt, &cm_packet_header,&epe_hdr_adjust_info));

    /* RETRIEVE_DS_DEST_PORT */
    if (!pkt_info->packet_header_en)
    {
        pkt_info->local_phy_port = pkt_info->dest_map & 0x7F;
    }
    else
    {
        sal_memset(&epe_header_adjust_phy_port_map, 0, sizeof(epe_header_adjust_phy_port_map));
        cmd = DRV_IOR(EpeHeaderAdjustPhyPortMap_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_header_adjust_phy_port_map));

        pkt_info->local_phy_port = epe_header_adjust_phy_port_map.local_phy_port;
    }
    /* PACKET_ADJUST */
    /* Calculate packet CRC without packet header, mark crcError, so packet send out with error CRC to network,
       or discard when loop/log */
    /* real packet length known in Eop(BSR compute put packetLength into packet header),
       so extra message sent to EPE Classification for policing and EPE Header Edit for stats in Eop
    */
    /* packetOffset < 256bytes, this error only occur when sop/eop ar firstBuffer, datapath calculate
       firstBufferLength */
    if (ipkt->packet_length < first_buffer_length)
    {
        first_buffer_length = ipkt->packet_length;
    }

    if (epe_hdr_adjust_info.packet_offset >= first_buffer_length)
    {
        /* complete discard here */
        pkt_info->discard = TRUE;
        pkt_info->discard_type = EPE_DISCARD_EPE_HDR_ADJ_BYTE_REMOVE_ERR;
        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE packet adjust packetOffset >= firstBufferLength discard!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }

    if (epe_hdr_adjust_info.acl_dscp_valid)   /* replace DSCP action is the same as Egress Header Editing */
    {
        if (epe_hdr_adjust_info.is_ipv4)    /* update dscp,checksum */
        {
            p_pkt_dscp = (uint8*)ipkt->pkt + cm_packet_header.ip_sa_u.share1.layer3_offset + 1;/* Version+IHL:1Byte */
            old_u16 = MAKE_UINT16(0, p_pkt_dscp[0]);
            p_pkt_dscp[0] &= 0x3;  /* clear IPv4 Packet header's dscp, tos[7:2] is Dscp */
            p_pkt_dscp[0] |= ((epe_hdr_adjust_info.acl_dscp & 0x3F) << 2);

            p_pkt_layer3offset10 = (uint8 *)ipkt->pkt + cm_packet_header.ip_sa_u.share1.layer3_offset + 10;
            p_pkt_layer3offset11 = (uint8 *)ipkt->pkt + cm_packet_header.ip_sa_u.share1.layer3_offset + 11;
            new_ip_check_sum = MAKE_UINT16(p_pkt_layer3offset10[0], p_pkt_layer3offset11[0]);
            new_u16 = MAKE_UINT16(0, p_pkt_dscp[0]);
            new_ip_check_sum = _cm_reclac_ip_checksum(old_u16, new_u16, new_ip_check_sum);

            p_pkt_layer3offset10[0] = new_ip_check_sum >> 8;
            p_pkt_layer3offset11[0] = new_ip_check_sum & 0xFF;

        }
        else    /* ipv6,only update dscp */
        {
            /* version[3:0], tos[7:4], tos[3:0], flowLable[15:12]: Dscp = tos[7:2] */
            p_pkt_dscp = (uint8*)ipkt->pkt + cm_packet_header.ip_sa_u.share1.layer3_offset;
            p_pkt_dscp[0] &= 0xF0;
            p_pkt_dscp[0] |= ((epe_hdr_adjust_info.acl_dscp >> 2) & 0xF);
            p_pkt_dscp[1] &= 0x3F;
            p_pkt_dscp[1] |= ((epe_hdr_adjust_info.acl_dscp & 0x3) << 6);
        }
    }
    pkt_info->acl_dscp_valid = epe_hdr_adjust_info.acl_dscp_valid && epe_hdr_adjust_ctl.acl_dscp_high_priority;

    /*   Here,we have an assumption.
     *   1).For local switching packet
     *   if (packetOffset != 0),muxLengthType and s/c vlanTagOperation should not be used
     *   if muxLengthType and s/c vlanTagOperation is used,packetOffset should not equal to 0
     *   2).For stacking switching packet
     *   Both packetOffset,muxLengthType and s/c vlanTagOperation could be used.
    */

    if (epe_hdr_adjust_info.packet_offset != 0)
    {
        pkt_info->packet_length_adjust_type = 1;        /* is negative */
        pkt_info->packet_length_adjust = epe_hdr_adjust_info.packet_offset; /* - packetOffset[6:0] */

        if (first_buffer_length > epe_hdr_adjust_info.packet_offset)
        {
            sal_memmove((void *)(ipkt->pkt),
                    (void *)(ipkt->pkt + epe_hdr_adjust_info.packet_offset),
                    (ipkt->packet_length - epe_hdr_adjust_info.packet_offset));

            temp_packet_len -= epe_hdr_adjust_info.packet_offset;
        }
    }

    /* Remove mux header, don't remove for mirror in case of specified nexthopPtr */
    sal_memset(&epe_port_extender_downlink, 0, sizeof(epe_port_extender_downlink));
    cmd = DRV_IOR(EpePortExtenderDownlink_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_port_extender_downlink));

    switch ((epe_hdr_adjust_info.channel_id & 0x3F)/32)
    {
        case 0:
            port_extender_downlink_bitmap = epe_port_extender_downlink.port_extender_downlink31_0;
            break;
        case 1:
            port_extender_downlink_bitmap = epe_port_extender_downlink.port_extender_downlink63_32;
            break;
        default:
            CMODEL_DEBUG_OUT_INFO("CModel Error! Get EpePortExtenderDownlink_t, Invalid channelId: %d",
                                   epe_hdr_adjust_info.channel_id);
            return DRV_E_INVALID_PARAMETER;
    }

    port_extender_downlink = IS_BIT_SET(port_extender_downlink_bitmap, ((epe_hdr_adjust_info.channel_id & 0x3F) % 32));

    mux_offset = 0;
    if (MUX_LENGTH_TYPE1 == (epe_hdr_adjust_info.mux_length_type & 0x3))           /* 4 Bytes Mux */
    {
        remove_len = MUX_LENGTH_TYPE_BYTES * 1;                  /* Need to remove byte12--byte15 */
        sal_memmove((void *)(ipkt->pkt + 12),
                    (void *)(ipkt->pkt + 12 + remove_len),
                    (temp_packet_len - 12 - remove_len));
        pkt_info->packet_length_adjust_type = 1;
        pkt_info->packet_length_adjust = remove_len; /* - 4 */
        mux_offset = remove_len;
        temp_packet_len -= 4;
    }
    else if ((MUX_LENGTH_TYPE2 == (epe_hdr_adjust_info.mux_length_type & 0x3))
            && !port_extender_downlink)                            /* 8 bytes Mux */
    {
        remove_len = MUX_LENGTH_TYPE_BYTES * 2;                  /* Need to remove byte12--byte19 */
        sal_memmove((void *)(ipkt->pkt + 12),
                    (void *)(ipkt->pkt + 12 + remove_len),
                    (temp_packet_len - 12 - remove_len));
        pkt_info->packet_length_adjust_type = 1;
        pkt_info->packet_length_adjust = remove_len; /* - 8 */
        mux_offset = remove_len;
        temp_packet_len -= 8;
    }

    mux_offset = 0;  /* need to clear,only for Cmodel */

    adjust_offset = epe_hdr_adjust_info.packet_offset + (mux_offset & 0xF);

    /* Update vlan tag */
    if (epe_hdr_adjust_ctl.vlan_edit_en && epe_hdr_adjust_info.cvlan_tag_operation_valid)
    {
        /* C-Vlan tag action */
        cvlan_offset = pkt_info->src_ctag_offset_type? (16 + (adjust_offset & 0xFF)) : (12 + (adjust_offset & 0xFF));
        cvlan_tpid = epe_hdr_adjust_ctl.cvlan_tag_tpid;
        switch (pkt_info->ctag_action)
        {
            case USERID_CTAG_ACTION_MODIFY:                        /* Replace C-Vlan tag */
                ipkt->pkt[cvlan_offset] = (cvlan_tpid >> 8) & 0xFF;
                ipkt->pkt[cvlan_offset+1] = cvlan_tpid & 0xFF;
                ipkt->pkt[cvlan_offset+2] = (pkt_info->src_ctag_cos << 5)
                                            | (pkt_info->src_ctag_cfi << 4)
                                            | (epe_hdr_adjust_info.src_cvlan_id >> 8);
                ipkt->pkt[cvlan_offset+3] = epe_hdr_adjust_info.src_cvlan_id & 0xFF;
                break;
            case USERID_CTAG_ACTION_ADD:                           /* Add C-Vlan tag */
                sal_memmove((ipkt->pkt + 4 + cvlan_offset),
                            (ipkt->pkt + cvlan_offset),
                            (temp_packet_len - cvlan_offset));
                ipkt->pkt[cvlan_offset] = (cvlan_tpid >> 8) & 0xFF;
                ipkt->pkt[cvlan_offset+1] = cvlan_tpid & 0xFF;
                ipkt->pkt[cvlan_offset+2] = (pkt_info->src_ctag_cos << 5)
                                            | (pkt_info->src_ctag_cfi << 4)
                                            | (epe_hdr_adjust_info.src_cvlan_id >> 8);
                ipkt->pkt[cvlan_offset+3] = epe_hdr_adjust_info.src_cvlan_id & 0xFF;

                packet_length_adjust = func_packet_length_adjust_add(ipkt, 4);
                pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
                pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;

                temp_packet_len += 4;
                break;
            case USERID_CTAG_ACTION_DELETE:                       /* Delete C-Vlan tag */
                sal_memmove((ipkt->pkt + cvlan_offset),
                            (ipkt->pkt + 4 + cvlan_offset),
                            (temp_packet_len - cvlan_offset));

                packet_length_adjust = func_packet_length_adjust_subtract(ipkt, 4);
                pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
                pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;

                temp_packet_len -= 4;
                break;
            default:                                             /* No operation */
                break;
        }
    }

    if (epe_hdr_adjust_ctl.vlan_edit_en && epe_hdr_adjust_info.svlan_tag_operation_valid)
    {
        /* S-Vlan tag action */
        svlan_offset = 12 + (adjust_offset & 0xFF);

        if (0 == pkt_info->svlan_tpid_index)
        {
            svlan_tpid = epe_hdr_adjust_ctl.svlan_tag_tpid0;
        }
        else if (1 == pkt_info->svlan_tpid_index)
        {
            svlan_tpid = epe_hdr_adjust_ctl.svlan_tag_tpid1;
        }
        else if (2 == pkt_info->svlan_tpid_index)
        {
            svlan_tpid = epe_hdr_adjust_ctl.svlan_tag_tpid2;
        }
        else if (3 == pkt_info->svlan_tpid_index)
        {
            svlan_tpid = epe_hdr_adjust_ctl.svlan_tag_tpid3;
        }

        switch (pkt_info->stag_action)
        {
            case USERID_STAG_ACTION_MODIFY:                     /* Replace S-Vlan tag */
                ipkt->pkt[svlan_offset] = (svlan_tpid >> 8) & 0xFF;
                ipkt->pkt[svlan_offset+1] = svlan_tpid & 0xFF;
                ipkt->pkt[svlan_offset+2] = (pkt_info->source_cos << 5)
                                            | (pkt_info->source_cfi << 4)
                                            | (epe_hdr_adjust_info.src_vlan_id >> 8);
                ipkt->pkt[svlan_offset+3] = epe_hdr_adjust_info.src_vlan_id & 0xFF;
                break;
            case USERID_STAG_ACTION_ADD:                        /* Add S-Vlan tag */
                sal_memmove((ipkt->pkt + 4 + svlan_offset),
                            (ipkt->pkt + svlan_offset),
                            (temp_packet_len - svlan_offset));
                ipkt->pkt[svlan_offset] = (svlan_tpid >> 8) & 0xFF;
                ipkt->pkt[svlan_offset+1] = svlan_tpid & 0xFF;
                ipkt->pkt[svlan_offset+2] = (pkt_info->source_cos << 5)
                                            | (pkt_info->source_cfi << 4)
                                            | (epe_hdr_adjust_info.src_vlan_id >> 8);
                ipkt->pkt[svlan_offset+3] = epe_hdr_adjust_info.src_vlan_id & 0xFF;

                packet_length_adjust = func_packet_length_adjust_add(ipkt, 4);
                pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
                pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;
                temp_packet_len += 4;

                break;
            case USERID_STAG_ACTION_DELETE:                     /* Delete S-Vlan tag */
                sal_memmove((ipkt->pkt + svlan_offset),
                            (ipkt->pkt + 4 + svlan_offset),
                            (temp_packet_len - svlan_offset - 4));

                packet_length_adjust = func_packet_length_adjust_subtract(ipkt, 4);
                pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
                pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;
                temp_packet_len -= 4;

                break;
            default:                                            /* No operation */
                break;
        }
    }
    pkt_info->tmp_stats_length = temp_packet_len;
    if (epe_hdr_adjust_ctl.vlan_edit_en && epe_hdr_adjust_info.isid_valid)
    {
        /* here iTagOffsetType always is zero.itag offset from MACDA+MACSA+0x88E7+{pcp+dei+nca+res1+res2 */
        isid_offset = (adjust_offset & 0xFF) + 15;
        ipkt->pkt[isid_offset] = (cm_packet_header.src_vlan_id_u.isid_23_12 >> 4);
        ipkt->pkt[isid_offset+1] = ((cm_packet_header.src_vlan_id_u.isid_23_12 & 0xF)<<4)
                                   |(cm_packet_header.src_cvlan_id_u.isid_11_0 >> 8);
        ipkt->pkt[isid_offset+2] = (cm_packet_header.src_cvlan_id_u.isid_11_0 & 0xFF);
    }

    if (!pkt_info->packet_length_adjust_type)
    {
        pkt_info->parser_length = pkt_info->packet_length + pkt_info->packet_length_adjust;
    }
    else
    {
        pkt_info->parser_length = pkt_info->packet_length - pkt_info->packet_length_adjust;
    }

    pkt_info->parser_length = (pkt_info->parser_length > MAX_PARSER_PACKET_LEN)
                               ? MAX_PARSER_PACKET_LEN : pkt_info->parser_length;

    /* REQUEST_PARSING */
    /* It must be performed after PACKET_ADJUST */
    if (OAM_ACH == pkt_info->rx_oam_type)
    {
        parser_layer4_type = L4_TYPE_ACH_OAM;
    }
    else
    {
        parser_layer4_type = L4_TYPE_NONE;
    }

    pkt_info->parser_offset = pkt_info->gal_exist + pkt_info->entropy_label_exist;


    if (!pkt_info->discard)
    {
        sal_memset(&parser_info, 0, sizeof(parser_info_t));
        parser_info.pkt = ipkt->pkt;
        parser_info.chip_id = ipkt->chip_id;
        parser_info.parser_length = pkt_info->parser_length;
        parser_info.packet_type = epe_hdr_adjust_info.parser_packet_type ;
        parser_info.parser_layer4_type = parser_layer4_type;
        parser_info.svlan_tpid_index = pkt_info->svlan_tpid_index;
        parser_info.outer_vlan_is_cvlan = pkt_info->outer_vlan_is_cvlan;
        parser_info.port_id = pkt_info->local_phy_port & 0x7F;
        parser_info.payload_offset = (pkt_info->parser_offset+ epe_hdr_adjust_info.ptp_parser_offset)<< 2;
        parser_info.mux_length_type = 0;
        parser_info.non_crc = pkt_info->non_crc;
        parser_info.parser_result= parser_result;


#if (SDK_WORK_PLATFORM == 1)
        if (cosim_db.store_epe_bus[SIM_EPE_HA2PR])
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_epe_bus[SIM_EPE_HA2PR](&parser_info));
        }
#endif

        DRV_IF_ERROR_RETURN(cm_com_parser_packet_parsing(&parser_info));
    }

#if COSIM_PENDING
    /* zhouw note: Store EPE parser to nextHop bus for ASIC simulation */
    ret = sim_store_epe_pr2hp_bus(ipkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("Store EPE parser to nextHop bus error!\n");
        return ret;
    }
#endif
    /* RETRIEVE_DS_NEXT_HOP */
    if (!pkt_info->bypass_all)
    {
        ds_next_hop_index = pkt_info->next_hop_ptr;
        if (((pkt_info->next_hop_ptr >> 2)&0x3FFF) != (epe_hdr_adjust_ctl.ds_next_hop_internal_base & 0x3FFF))
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n\n",
                                                            "DsNextHop8W_t", (pkt_info->next_hop_ptr & 0xFFFE));
            cmd = DRV_IOR(DsNextHop8W_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->next_hop_ptr & 0xFFFE, cmd, pkt_info->DsNextHopBits));
            /*sal_printf("++++++++++ nexhopPtr = 0x%x\n", pkt_info->next_hop_ptr);*/
        }
        else
        {
            cmd = DRV_IOR(EpeNextHopInternal_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, IS_BIT_SET(pkt_info->next_hop_ptr,1), cmd, pkt_info->DsNextHopBits));
        }

    }

    sal_memset(&epe_next_hop_ptr_cam, 0, sizeof(epe_next_hop_ptr_cam));
    cmd = DRV_IOR(EpeNextHopPtrCam_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_next_hop_ptr_cam));

    if ((((pkt_info->next_hop_ptr&0xFFFF) & epe_next_hop_ptr_cam.pointer_cam_mask0)
        != (epe_next_hop_ptr_cam.pointer_cam_value0 & epe_next_hop_ptr_cam.pointer_cam_mask0))
        && (((pkt_info->next_hop_ptr&0xFFFF)& epe_next_hop_ptr_cam.pointer_cam_mask1)
        != (epe_next_hop_ptr_cam.pointer_cam_value1 & epe_next_hop_ptr_cam.pointer_cam_mask1)))
    {
        pkt_info->ds_nexthop_dot_bypass_all = FALSE;
    }
    else
    {
        pkt_info->ds_nexthop_dot_bypass_all = TRUE;
    }
    return DRV_E_NONE;
}

