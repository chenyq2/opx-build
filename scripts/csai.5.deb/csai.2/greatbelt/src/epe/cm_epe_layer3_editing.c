/****************************************************************************
 * cm_epe_layer3_editing.c  Provides EPE l3edit function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-10-23.
 * Reason:       First Create.
 *
 * Revision:     V1.0.
 * Author:       JiaK.
 * Date:         2010-11-19.
 * Reason:       Sync spec Revision 5.0.0.
 *
 * Revision:     V2.0.
 * Author:       JiaK.
 * Date:         2011-04-06.
 * Reason:       Sync spec Revision 3.0.3.
 *
 * Revision:     V4.2.1
 * Author:       JiaK.
 * Date:         2011-07-05.
 * Reason:       Sync spec Revision 4.2.1.
 *
 * Revision:     V4.3.0
 * Author:       JiaK.
 * Date:         2011-07-11.
 * Reason:       Sync spec revision 4.3.0.
 *
 * Revision:     V4.5.1
 * Author:       JiaK.
 * Date:         2011-07-11.
 * Reason:       Sync spec revision 4.5.1.
 *
 * Revision:     V4.7.1
 * Author:       JiaK.
 * Date:         2011-07-28.
 * Reason:       Sync spec revision 4.7.1.
 *
 * Revision:     V4.28
 * Author:       wangcy.
 * Date:         2011-09-29.
 * Reason:       Sync spec revision 4.28.
 *
 * Revision:     V4.29.3
 * Author:       JiaK.
 * Date:         2011-10-10.
 * Reason:       Sync spec revision 4.29.3
 *
 * Revision:     V4.31.0
 * Author:       JiaK.
 * Date:         2011-10-22.
 * Reason:       sync spec to v4.31.0
 *
 * Revision:     V5.1.0
 * Author:       JiaK.
 * Date:         2011-12-9.
 * Reason:       sync spec to v5.1.0
 *
 * Revision:     V5.6.0
 * Author:       JiaK.
 * Date:         2012-01-7.
 * Reason:       sync spec to v5.6.0
 *
 * Revision:     V5.9.0
 * Author:       JiaK.
 * Date:         2012-01-19.
 * Reason:       sync spec to v5.9.0
 *
 * Revision:     V5.9.1
 * Author:       Wangcy.
 * Date:         2012-02-04.
 * Reason:       sync spec to v5.9.1
 *
 * Revision:     V5.11.0
 * Author:       Wangcy.
 * Date:         2012-03-01.
 * Reason:       sync spec to v5.11.0
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/

#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
struct ds_l3_edit_tunnel_v6_ipda_79_0_s
{
    uint32 ipda_31_0;
    uint32 ipda_63_32;
    uint32 ipda_79_64   :16;
};
typedef struct ds_l3_edit_tunnel_v6_ipda_79_0_s ds_l3_edit_tunnel_v6_ipda_79_0_t;

struct cm_epe_mtu_msg_s
{
    uint32  tunnel_mtu_size             :14;
    uint32  tunnel_mtu_check            :1;
    uint32  tunnel_packet_len           :14;
    uint32  tunnel_dont_frag            :1;
    uint32  first_fragment              :1;
    uint32  first_label                 :1;

    uint32  checksum_old_l4_dest_port   :16;
    uint32  checksum_old_l4_source_port :16;

    uint32  src_dscp5_3                 :3;
    uint32  lm_index                    :2;
    uint32  checksum_old_ttl            :8;
    uint32  checksum_is_old_ipv4        :1;
    uint32  checksum_is_new_ipv4        :1;
    uint32  nat_new_header_is_ipv4      :1;
    uint32  nat_new_header_valid        :1;
    uint32  checksum_ip_da_valid        :1;
    uint32  checksum_ip_sa_valid        :1;
    uint32  is_tcp_update               :1;
    uint32  is_udp_update               :1;
    uint32  layer2_type_update          :4;
    uint32  layer3_type_update          :4;
    uint32  trill_multicast_update      :1;
    uint32  ip_options_update           :1;
    uint32  ip_header_error_update      :1;
    uint32  frag_info_update            :2;

    uint32  ip_checksum_update          :16;
    uint32  layer4_info_mapped_update   :12;
    uint32  no_operation                :1;
    uint32  mpls_operation              :1;
    uint32  nat_operation               :1;
    uint32  tunnelv4_operation          :1;

    uint32  l4_dest_port_update         :16;
    uint32  egress_nick_name_update     :16;
    uint32  tos_update                  :8;
    uint32  ipv6_flow_label_update      :20;
    uint32  trill_version_update        :2;
    uint32  flex_operation              :1;
    uint32  tunnelv6_operation          :1;

    uint32  ingress_nick_name_update    :16;
    uint32  trill_operation             :1;
    uint32  l3_new_header_extra_len     :5;
    uint32  loopback_operation          :1;
    uint32  l2_header_added             :1;
    uint32  l3_header_added             :1;

    uint32  ip_da_31_0_update;
    uint32  ip_da_63_32_update;
    uint32  ip_da_95_64_update;
    uint32  ip_da_127_96_update;
    uint32  ip_sa_31_0_update;
    uint32  ip_sa_63_32_update;
    uint32  ip_sa_95_64_update;
    uint32  ip_sa_127_96_update;

    uint32  checksum_old_ip_da_31_0;
    uint32  checksum_old_ip_da_63_32;
    uint32  checksum_old_ip_da_95_64;
    uint32  checksum_old_ip_da_127_96;
    uint32  checksum_old_ip_sa_31_0;
    uint32  checksum_old_ip_sa_63_32;
    uint32  checksum_old_ip_sa_95_64;
    uint32  checksum_old_ip_sa_127_96;

    uint32  mpls_label_update3;
    uint32  mpls_label_update2;
    uint32  mpls_label_update1;
    uint32  mpls_label_update0;

    uint32  mac_da_5;
    uint32  mac_da_4;
    uint32  mac_da_3;
    uint32  mac_da_2;
    uint32  mac_da_1;
    uint32  mac_da_0;
    uint32  mac_sa_5;
    uint32  mac_sa_4;
    uint32  mac_sa_3;
    uint32  mac_sa_2;
    uint32  mac_sa_1;
    uint32  mac_sa_0;
    uint32  layer2_header_protocol;

    uint32  svlan_id;
    uint32  stag_cos;
    uint32  stag_cfi;
    uint32  cvlan_id;
    uint32  ctag_cos;
    uint32  ctag_cfi;

    uint8*  l3_new_header_extra;
    ds_l3_edit_tunnel_v6_ipda_79_0_t* p_ds_l3_edit_tunnel_v6_ipda_79_0;
};
typedef struct cm_epe_mtu_msg_s cm_epe_mtu_msg_t;

enum ip_type_e
{
    IP_SA,
    IP_DA,
};
typedef enum ip_type_e ip_type_t;

#define UDP_PROTOCOL 17
#define TCP_PROTOCOL 6

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/
extern bool sim_check_flag_use_control_insert_linklist_op;

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/
extern uint16 func_packet_length_adjust_add(epe_in_pkt_t* ipkt, uint8 a);
extern uint16 func_packet_length_adjust_subtract(epe_in_pkt_t* ipkt, uint8 a);
/****************************************************************************
 * Name:      _cm_reclac_ip_checksum
 * Purpose:   recalculate ip checksum.
 * Parameters:
 * Input:     old_u16  --  old data
 *            new_u16 -- new data
 *            old_chksum -- old checksum
 * Return:    new checksum
 * Note:      none.
****************************************************************************/
static uint16
_cm_reclac_ip_checksum(uint16 old_u16, uint16 new_u16, uint16 old_chksum)
{
    uint32 sum = 0;
    uint16 new_sum = 0;

    sum = (~old_chksum) & 0xFFFF;

    sum = sum + (~old_u16 & 0xFFFF);
    sum = (sum >> 16) + (sum & 0xFFFF);

    sum = sum + new_u16;
    new_sum = (sum >> 16) + (sum & 0xFFFF);
    return (~new_sum);
}

/****************************************************************************
 * Name:      _cm_func_get_ipv4_address
 * Purpose:   get new ipv4 from old ipv6.
 * Parameters:
 * Input:     ipkt  --  packet info struct.
 *            ip[4] -- old ipv6.
 *            ipv4_embeded_mode -- ipv4 embeded mode.
 *            ip_prefix_length -- ip prefix length.
 *            new_ip -- new ipv4 pointer.
 * Return:    new ip
 * Note:      none.
****************************************************************************/
static int32
_cm_func_get_ipv4_address(epe_in_pkt_t* ipkt,
            uint32 ip[], uint8 ipv4_embeded_mode, uint8 ip_prefix_length,uint32 *new_ip)
{
    if (ipv4_embeded_mode)  /* use stateless ip address */
    {
        switch (ip_prefix_length & 0x7)
        {
            case 0: /* prefix length 32 */
                *new_ip = ip[2];
                break;
            case 1: /* prefix length 40 */
                *new_ip = ((ip[1] >> 16) & 0xFF) | ((ip[2] & 0xFFFFFF) << 8);
                break;
            case 2: /* prefix length 48 */
                *new_ip = ((ip[1] >> 8) & 0xFFFF) | ((ip[2] & 0xFFFF) << 16);
                break;
            case 3: /* prefix length 56 */
                *new_ip = (ip[1] & 0xFFFFFF) | ((ip[2] & 0xFF) << 24);
                break;
            case 4: /* prefix length 64 */
                *new_ip = ((ip[0] >> 24) & 0xFF) | ((ip[1] & 0xFFFFFF) << 8);
                break;
            case 5: /* prefix length 72 */
                *new_ip = ((ip[0] >> 24) & 0xFF) | ((ip[1] & 0xFFFFFF) << 8);
                break;
            case 6: /* prefix length 80 */
                *new_ip = ((ip[0] >> 16) & 0xFFFF) | ((ip[1] & 0xFFFF) << 16);
                break;
            default:    /* prefix length 96 */
                *new_ip = ip[0];
                break;
        }
    }
    else
    {
        switch (ip_prefix_length & 0x7)
        {
            case 0: /* prefix length 32 */
                *new_ip = ip[2];
                break;
            case 1: /* prefix length 40 */
                *new_ip = (ip[1] >> 24) | ((ip[2] & 0xFFFFFF) << 8);
                break;
            case 2: /* prefix length 48 */
                *new_ip = (ip[1] >> 16) | ((ip[2] & 0xFFFF) << 16);
                break;
            case 3: /* prefix length 56 */
                *new_ip = (ip[1] >> 8) | ((ip[2] & 0xFF) << 24);
                break;
            case 4: /* prefix length 64 */
                *new_ip = ip[1];
                break;
            case 5: /* prefix length 72 */
                *new_ip = (ip[0] >> 24) | ((ip[1] & 0xFFFFFF) << 8);
                break;
            case 6: /* prefix length 80 */
                *new_ip = (ip[0] >> 16) | ((ip[1] & 0xFFFF) << 16);
                break;
            default:    /* prefix length 96 */
                *new_ip = ip[0];
                break;
        }
    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_func_get_ipv6_address
 * Purpose:   get new ipv4 from old ipv6.
 * Parameters:
 * Input:     ipkt  --  packet info struct.
 *            ip_type -- ip type(sa or da)
 *            ip[4] -- old ipv6.
 *            ipv4_embeded_mode -- ipv4 embeded mode.
 *            ip_prefix_length -- ip prefix length.
 *            new_ip -- new ipv4 pointer.
 * Return:    new ip
 * Note:      none.
****************************************************************************/
static uint32
_cm_func_get_ipv6_address(ip_type_t ip_type, uint32 ip,
            uint8 ipv4_embeded_mode, uint8 ip_prefix_length, uint32 ip_prefix[], uint32 new_ip[],
            uint8 pt_zero_reserved_address)
{
    if (ipv4_embeded_mode)  /* ipv6 da bits 64 to 71 are reserved per RFC6052 */
    {
        switch(ip_prefix_length & 0x7)
        {
            case 0: /* prefix length 32 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = ip;
                new_ip[1] = ip_prefix[1];
                new_ip[0] = ip_prefix[0];
                break;
            case 1: /* prefix length 40 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = (ip_prefix[2] & 0xFF000000) | ((ip >> 8) & 0xFFFFFF);
                new_ip[1] = (ip_prefix[1] & 0xFF00FFFF) | ((ip & 0xFF) << 16);
                new_ip[0] = ip_prefix[0];
                break;
            case 2: /* prefix length 48 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = (ip_prefix[2] & 0xFFFF0000) | (ip >> 16);
                new_ip[1] = (ip_prefix[1] & 0xFF0000FF) | ((ip & 0xFFFF) << 8);
                new_ip[0] = ip_prefix[0];
                break;
            case 3: /* prefix length 56 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = (ip_prefix[2] & 0xFFFFFF00) | ((ip >> 24) & 0xFF);
                new_ip[1] = (ip_prefix[1] & 0xFF000000) | (ip & 0xFFFFFF);
                new_ip[0] = ip_prefix[0];
                break;
            case 4: /* prefix length 64 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = ip_prefix[2];
                new_ip[1] = (ip >> 8);
                new_ip[0] = ((ip & 0xFF) << 24) | (ip_prefix[0] & 0xFFFFFF);
                break;
            case 5: /* prefix length 72 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = ip_prefix[2];
                new_ip[1] = (ip_prefix[1] & 0xFF000000) | (ip >> 8);
                new_ip[0] = ((ip & 0xFF) << 24) | (ip_prefix[0] & 0xFFFFFF);
                break;
            case 6: /* prefix length 80 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = ip_prefix[2];
                new_ip[1] = (ip_prefix[1] & 0xFFFF0000) | (ip >> 16);
                new_ip[0] = ((ip & 0xFFFF) << 16) | (ip_prefix[0] & 0xFFFF);
                break;
            default:    /* prefix length 96 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = ip_prefix[2];
                new_ip[1] = ip_prefix[1];
                new_ip[0] = ip;
                break;
        }

        if (pt_zero_reserved_address)
        {
            new_ip[1] &=0x00FFFFFF;
        }

    }
    else    /* ipv6 da bits 64 to 71 are not reserved */
    {
        switch(ip_prefix_length & 0x7)
        {
            case 0: /* prefix length 32 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = ip;
                new_ip[1] = ip_prefix[1];
                new_ip[0] = ip_prefix[0];
                break;
            case 1: /* prefix length 40 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = (ip_prefix[2] & 0xFF000000) | ((ip >> 8) & 0xFFFFFF);
                new_ip[1] = (ip_prefix[1] & 0xFFFFFF) | ((ip & 0xFF) << 24);
                new_ip[0] = ip_prefix[0];
                break;
            case 2: /* prefix length 48 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = (ip_prefix[2] & 0xFFFF0000) | (ip >> 16);
                new_ip[1] = (ip_prefix[1] & 0x0000FFFF) | ((ip & 0xFFFF) << 16);
                new_ip[0] = ip_prefix[0];
                break;
            case 3: /* prefix length 56 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = (ip_prefix[2] & 0xFFFFFF00) | ((ip >> 24) & 0xFF);
                new_ip[1] = (ip_prefix[1] & 0x000000FF) | ((ip & 0xFFFFFF) << 8);
                new_ip[0] = ip_prefix[0];
                break;
            case 4: /* prefix length 64 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = ip_prefix[2];
                new_ip[1] = ip;
                new_ip[0] = ip_prefix[0];
                break;
            case 5: /* prefix length 72 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = ip_prefix[2];
                new_ip[1] = (ip_prefix[1] & 0xFF000000) | (ip >> 8);
                new_ip[0] = ((ip & 0xFF) << 24) | (ip_prefix[0] & 0xFFFFFF);
                break;
            case 6: /* prefix length 80 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = ip_prefix[2];
                new_ip[1] = (ip_prefix[1] & 0xFFFF0000) | (ip >> 16);
                new_ip[0] = ((ip & 0xFFFF) << 16) | (ip_prefix[0] & 0xFFFF);
                break;
            default:    /* prefix length 96 */
                new_ip[3] = ip_prefix[3];
                new_ip[2] = ip_prefix[2];
                new_ip[1] = ip_prefix[1];
                new_ip[0] = ip;
                break;
        }
    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_layer3_editing_loopback
 * Purpose:   perform layer3 loopback editing operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *            ds_l3_edit_nat8_w -- pointer to l3_edit_nat8_w
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_layer3_editing_loopback(epe_in_pkt_t* ipkt, ds_l3_edit_nat8_w_t* ds_l3_edit_nat8_w)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;

    /* DISCARD_SWITCH */
    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* LOOPBACK_FIELDS */
    pkt_info->loopback_en = TRUE;
    /* use l3New header to carry the information */
    /* 1'b0 ,lb_length_adjust_type,lb_dest_map[21:16] */
    pkt_info->l3_header[0] =  ds_l3_edit_nat8_w->ip_da39_32 & 0xFF;
    /* lb_dest_map[15:8] */
    pkt_info->l3_header[1] = (ds_l3_edit_nat8_w->l4_dest_port >> 8) & 0xFF;
    /* lb_dest_map[7:0] */
    pkt_info->l3_header[2] =  ds_l3_edit_nat8_w->l4_dest_port & 0xFF;
    /* lb_next_hop_ext ,2'b00,lb_next_hop_ptr[17:13]*/
    pkt_info->l3_header[3] = (ds_l3_edit_nat8_w->ip_da29_0 >> 13) & 0x9F;
    /* lb_next_hop_ptr[12:5] */
    pkt_info->l3_header[4] = (ds_l3_edit_nat8_w->ip_da29_0 >> 5) & 0xFF;
    /* lb_next_hop_ptr[4:0] */
    pkt_info->l3_header[5] = (ds_l3_edit_nat8_w->ip_da29_0 & 0x1F) << 3;

    pkt_info->l3_new_header_len = 127;/* indicate l3Lookback, no actual l3 edit */

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_layer3_editing_trill
 * Purpose:   perform layer3 Trill editing operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *            ds_l3_edit_nat8_w -- point to ds_l3_edit_nat8_w_t
 *            mtu_msg -- pointer to cm_epe_mtu_msg_t
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *            mtu_msg -- pointer to cm_epe_mtu_msg_t
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_layer3_editing_trill(epe_in_pkt_t* ipkt, ds_l3_edit_nat8_w_t* ds_l3_edit_nat8_w,
                                    cm_epe_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;

    uint8 new_version = 0;
    uint8 new_ttl = 0;
    uint16 new_ingress_nickname = 0;
    uint16 new_egress_nickname = 0;

    /* DISCARD_SWITCH */
    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* NEW_HEADER */

    new_version = (ds_l3_edit_nat8_w->ip_da39_32 >> 6) & 0x3;           /* used as version */

    new_ingress_nickname = (ds_l3_edit_nat8_w->ip_da31_30 << 14)
                           |((ds_l3_edit_nat8_w->ip_da29_0 >> 16)&0x3FFF);/* used as ingress_nick_name */
    new_egress_nickname = ds_l3_edit_nat8_w->ip_da29_0 & 0xFFFF;        /* used as egress_nick_name */

    new_ttl = ds_l3_edit_nat8_w->ip_da39_32 & 0x3F;                     /* used as hop_count */

    if (IS_BIT_SET(ds_l3_edit_nat8_w->l4_dest_port, 14))    /* used as mtuCheckEn */
    {
        mtu_msg->tunnel_mtu_check = TRUE;
        mtu_msg->tunnel_mtu_size = (ds_l3_edit_nat8_w->l4_dest_port) & 0x3FFF; /* used as mtuSize */
    }

    pkt_info->l3_new_header_len = 6;

    /* use l3New header to carry the information */
    pkt_info->l3_header[0] = (new_version << 6) | (IS_BIT_SET(pkt_info->dest_map, 21) << 3);
    pkt_info->l3_header[1] = new_ttl & 0x3F;
    pkt_info->l3_header[2] = (new_egress_nickname >> 8) & 0xFF;
    pkt_info->l3_header[3] = new_egress_nickname & 0xFF;
    pkt_info->l3_header[4] = (new_ingress_nickname >> 8) & 0xFF;
    pkt_info->l3_header[5] = new_ingress_nickname & 0xFF;

    pkt_info->packet_ttl = new_ttl & 0x3F;     /* packet TTL has been updated */
    pkt_info->packet_type= PKT_TYPE_TRILL;

    /* replace parser result */
    mtu_msg->trill_version_update = new_version & 0x3;
    mtu_msg->ingress_nick_name_update = new_ingress_nickname;
    mtu_msg->egress_nick_name_update = new_egress_nickname;
    mtu_msg->trill_multicast_update = IS_BIT_SET(pkt_info->dest_map,21);
    mtu_msg->layer3_type_update = L3_TYPE_TRILL;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_epe_layer3_editing_flex
 * Purpose:    perform layer3 flex editing operations.
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *             ds_l3_edit_flex -- pointer to l3_edit_flex
 *             mtu_msg -- pointer to mtu msg struct
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_epe_layer3_editing_flex(epe_in_pkt_t* ipkt, ds_l3_edit_flex_t* ds_l3_edit_flex,
                    cm_epe_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;

    /* DISCARD_SWTICH */
    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* NEW_HEADER */
    pkt_info->l3_new_header_len = ds_l3_edit_flex->rewrite_byte_num;

    /* l3NewHeader = DsL3EditFlwx.rewriteString[127:0] */
    switch (pkt_info->l3_new_header_len)
    {
        case 0:
            break;
        case 1:
            pkt_info->l3_header[0]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 2:
            pkt_info->l3_header[0]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[1]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 3:
            pkt_info->l3_header[0]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[1]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[2]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 4:
            pkt_info->l3_header[0]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[1]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[2]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[3]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 5:
            pkt_info->l3_header[0]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[1]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[2]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[3]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[4]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 6:
            pkt_info->l3_header[0]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[1]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[2]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[3]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[4]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[5]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 7:
            pkt_info->l3_header[0] = ((ds_l3_edit_flex->rewrite_string63_32 >> 16) & 0xFF);
            pkt_info->l3_header[1]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[2]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[3]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[4]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[5]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[6]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 8:
            pkt_info->l3_header[0] = ((ds_l3_edit_flex->rewrite_string63_32 >> 24) & 0xFF);
            pkt_info->l3_header[1] = ((ds_l3_edit_flex->rewrite_string63_32 >> 16) & 0xFF);
            pkt_info->l3_header[2]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[3]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[4]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[5]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[6]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[7]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 9:
            pkt_info->l3_header[0] = (ds_l3_edit_flex->rewrite_string78_64 & 0xFF);
            pkt_info->l3_header[1] = ((ds_l3_edit_flex->rewrite_string63_32 >> 24) & 0xFF);
            pkt_info->l3_header[2] = ((ds_l3_edit_flex->rewrite_string63_32 >> 16) & 0xFF);
            pkt_info->l3_header[3]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[4]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[5]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[6]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[7]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[8]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 10:
            pkt_info->l3_header[0] = (((ds_l3_edit_flex->rewrite_string108_79 & 1) << 7) | ((ds_l3_edit_flex->rewrite_string78_64 >> 8) & 0x7F));
            pkt_info->l3_header[1] = (ds_l3_edit_flex->rewrite_string78_64 & 0xFF);
            pkt_info->l3_header[2] = ((ds_l3_edit_flex->rewrite_string63_32 >> 24) & 0xFF);
            pkt_info->l3_header[3] = ((ds_l3_edit_flex->rewrite_string63_32 >> 16) & 0xFF);
            pkt_info->l3_header[4]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[5]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[6]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[7]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[8]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[9]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 11:
            pkt_info->l3_header[0] = ((ds_l3_edit_flex->rewrite_string108_79 >> 1) & 0xFF);
            pkt_info->l3_header[1] = (((ds_l3_edit_flex->rewrite_string108_79 & 1) << 7) | ((ds_l3_edit_flex->rewrite_string78_64 >> 8) & 0x7F));
            pkt_info->l3_header[2] = (ds_l3_edit_flex->rewrite_string78_64 & 0xFF);
            pkt_info->l3_header[3] = ((ds_l3_edit_flex->rewrite_string63_32 >> 24) & 0xFF);
            pkt_info->l3_header[4] = ((ds_l3_edit_flex->rewrite_string63_32 >> 16) & 0xFF);
            pkt_info->l3_header[5]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[6]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[7]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[8]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[9]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[10]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 12:
            pkt_info->l3_header[0] = ((ds_l3_edit_flex->rewrite_string108_79 >> 9) & 0xFF);
            pkt_info->l3_header[1] = ((ds_l3_edit_flex->rewrite_string108_79 >> 1) & 0xFF);
            pkt_info->l3_header[2] = (((ds_l3_edit_flex->rewrite_string108_79 & 1) << 7) | ((ds_l3_edit_flex->rewrite_string78_64 >> 8) & 0x7F));
            pkt_info->l3_header[3] = (ds_l3_edit_flex->rewrite_string78_64 & 0xFF);
            pkt_info->l3_header[4] = ((ds_l3_edit_flex->rewrite_string63_32 >> 24) & 0xFF);
            pkt_info->l3_header[5] = ((ds_l3_edit_flex->rewrite_string63_32 >> 16) & 0xFF);
            pkt_info->l3_header[6]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[7]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[8]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[9]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[10]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[11]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 13:
            pkt_info->l3_header[0] = ((ds_l3_edit_flex->rewrite_string108_79 >> 17) & 0xFF);
            pkt_info->l3_header[1] = ((ds_l3_edit_flex->rewrite_string108_79 >> 9) & 0xFF);
            pkt_info->l3_header[2] = ((ds_l3_edit_flex->rewrite_string108_79 >> 1) & 0xFF);
            pkt_info->l3_header[3] = (((ds_l3_edit_flex->rewrite_string108_79 & 1) << 7) | ((ds_l3_edit_flex->rewrite_string78_64 >> 8) & 0x7F));
            pkt_info->l3_header[4] = (ds_l3_edit_flex->rewrite_string78_64 & 0xFF);
            pkt_info->l3_header[5] = ((ds_l3_edit_flex->rewrite_string63_32 >> 24) & 0xFF);
            pkt_info->l3_header[6] = ((ds_l3_edit_flex->rewrite_string63_32 >> 16) & 0xFF);
            pkt_info->l3_header[7]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[8]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[9]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[10]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[11]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[12]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 14:
            pkt_info->l3_header[0] = (((ds_l3_edit_flex->rewrite_string127_109 & 0x7) << 5) | ((ds_l3_edit_flex->rewrite_string108_79 >> 25) & 0x1F));
            pkt_info->l3_header[1] = ((ds_l3_edit_flex->rewrite_string108_79 >> 17) & 0xFF);
            pkt_info->l3_header[2] = ((ds_l3_edit_flex->rewrite_string108_79 >> 9) & 0xFF);
            pkt_info->l3_header[3] = ((ds_l3_edit_flex->rewrite_string108_79 >> 1) & 0xFF);
            pkt_info->l3_header[4] = (((ds_l3_edit_flex->rewrite_string108_79 & 1) << 7) | ((ds_l3_edit_flex->rewrite_string78_64 >> 8) & 0x7F));
            pkt_info->l3_header[5] = (ds_l3_edit_flex->rewrite_string78_64 & 0xFF);
            pkt_info->l3_header[6] = ((ds_l3_edit_flex->rewrite_string63_32 >> 24) & 0xFF);
            pkt_info->l3_header[7] = ((ds_l3_edit_flex->rewrite_string63_32 >> 16) & 0xFF);
            pkt_info->l3_header[8]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[9]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[10]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[11]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[12]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[13]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 15:
            pkt_info->l3_header[0] = ((ds_l3_edit_flex->rewrite_string127_109 >> 3) & 0xFF);
            pkt_info->l3_header[1] = (((ds_l3_edit_flex->rewrite_string127_109 & 0x7) << 5) | ((ds_l3_edit_flex->rewrite_string108_79 >> 25) & 0x1F));
            pkt_info->l3_header[2] = ((ds_l3_edit_flex->rewrite_string108_79 >> 17) & 0xFF);
            pkt_info->l3_header[3] = ((ds_l3_edit_flex->rewrite_string108_79 >> 9) & 0xFF);
            pkt_info->l3_header[4] = ((ds_l3_edit_flex->rewrite_string108_79 >> 1) & 0xFF);
            pkt_info->l3_header[5] = (((ds_l3_edit_flex->rewrite_string108_79 & 1) << 7) | ((ds_l3_edit_flex->rewrite_string78_64 >> 8) & 0x7F));
            pkt_info->l3_header[6] = (ds_l3_edit_flex->rewrite_string78_64 & 0xFF);
            pkt_info->l3_header[7] = ((ds_l3_edit_flex->rewrite_string63_32 >> 24) & 0xFF);
            pkt_info->l3_header[8] = ((ds_l3_edit_flex->rewrite_string63_32 >> 16) & 0xFF);
            pkt_info->l3_header[9]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[10]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[11]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[12]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[13]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[14]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        case 16:
            pkt_info->l3_header[0] = ((ds_l3_edit_flex->rewrite_string127_109 >> 11) & 0xFF);
            pkt_info->l3_header[1] = ((ds_l3_edit_flex->rewrite_string127_109 >> 3) & 0xFF);
            pkt_info->l3_header[2] = (((ds_l3_edit_flex->rewrite_string127_109 & 0x7) << 5) | ((ds_l3_edit_flex->rewrite_string108_79 >> 25) & 0x1F));
            pkt_info->l3_header[3] = ((ds_l3_edit_flex->rewrite_string108_79 >> 17) & 0xFF);
            pkt_info->l3_header[4] = ((ds_l3_edit_flex->rewrite_string108_79 >> 9) & 0xFF);
            pkt_info->l3_header[5] = ((ds_l3_edit_flex->rewrite_string108_79 >> 1) & 0xFF);
            pkt_info->l3_header[6] = (((ds_l3_edit_flex->rewrite_string108_79 & 1) << 7) | ((ds_l3_edit_flex->rewrite_string78_64 >> 8) & 0x7F));
            pkt_info->l3_header[7] = (ds_l3_edit_flex->rewrite_string78_64 & 0xFF);
            pkt_info->l3_header[8] = ((ds_l3_edit_flex->rewrite_string63_32 >> 24) & 0xFF);
            pkt_info->l3_header[9] = ((ds_l3_edit_flex->rewrite_string63_32 >> 16) & 0xFF);
            pkt_info->l3_header[10]= ((ds_l3_edit_flex->rewrite_string63_32 >> 8) & 0xFF);
            pkt_info->l3_header[11]= ((ds_l3_edit_flex->rewrite_string63_32) & 0xFF);
            pkt_info->l3_header[12]= ((ds_l3_edit_flex->rewrite_string31_0 >> 24) & 0xFF);
            pkt_info->l3_header[13]= ((ds_l3_edit_flex->rewrite_string31_0 >> 16) & 0xFF);
            pkt_info->l3_header[14]= ((ds_l3_edit_flex->rewrite_string31_0 >> 8) & 0xFF);
            pkt_info->l3_header[15]= ((ds_l3_edit_flex->rewrite_string31_0) & 0xFF);
            break;
        default:
            break;
    }

    /* REPLACE_PARSER_RESULT */
    mtu_msg->layer3_type_update = L3_TYPE_NONE;

    pkt_info->packet_type = ds_l3_edit_flex->packet_type;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_layer3_editing_tunnelv6
 * Purpose:   perform tunnelv6 encapsulation.
 * Parameters:
 * Input:     ipkt -- pointer to buffer which save input packet and packet
 *                    header ,and processing information
 *            mtu_msg -- pointer to mtu msg struct
 * Output:    ipkt -- pointer to buffer which save input packet and packet
 *                    header ,and processing information
 *            mtu_msg -- pointer to mtu msg struct
 * Return:    DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_layer3_editing_tunnelv6(epe_in_pkt_t* ipkt,
                    ds_l3_edit_tunnel_v6_t* ds_l3_edit_tunnel_v6, cm_epe_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    ds_l3_tunnel_v6_ip_sa_t ds_l3_tunnel_v6_ip;
    epe_pkt_proc_ctl_t epe_pkt_proc_ctl;

    uint8 new_dscp = 0, new_ttl = 0, new_protocol = 0;
    uint8 new_tos_lowbits = 0;
    uint16 new_payload_length = 0;
    uint32 new_ip_sa[4] = {0}, new_ip_da[4] = {0};
    uint32 new_flow_label = 0;
    uint32 cmd = 0;
    uint32 gre_key = 0;
    uint32 packet_length = 0;
    uint32 field_id = 0;
    uint8 ipsa_idx = 0;
    uint8 capwap_wlan_id_bitmap_valid = FALSE;
    uint16 capwap_wlan_id_bitmap = 0;
    uint8 capwap_header_length = 0;
    uint16 capwap_flags = 0;
    uint8 roaming_state = 0;
    uint8 index = 0;
    uint32 ttl = 0;
    uint32 udp_length = 0;
    uint16 udp_src_port = 0;
    uint32 udp_tunnel_type_header[6]= {0};
    uint8 udp_inner_header_length = 0;
    uint8 udp_header[8] = {0};
    uint8 udp_tunnel_flags = 0;

    sal_memset(&epe_pkt_proc_ctl, 0, sizeof(epe_pkt_proc_ctl));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_ctl));

    /* DISCARD_SWITCH */
    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* PREPARE_FIELDS */
    /* Traffic Class */
    if (ds_l3_edit_tunnel_v6->derive_dscp && IS_BIT_SET(ds_l3_edit_tunnel_v6->tos, 0))
    {
        new_dscp = pkt_info->mapped_dscp;
        new_tos_lowbits = 0;
    }
    else if (ds_l3_edit_tunnel_v6->derive_dscp && !(IS_BIT_SET(ds_l3_edit_tunnel_v6->tos, 0)))
    {
        new_dscp = pkt_info->src_dscp;
        new_tos_lowbits = (parser_result->l3_s.tos.ip_tos) & 0x3;
    }
    else
    {
        new_dscp = (ds_l3_edit_tunnel_v6->tos >> 2) & 0x3F;
        new_tos_lowbits = ds_l3_edit_tunnel_v6->tos & 0x3;
    }

    /* Payload Length */
    packet_length = pkt_info->packet_length - (!pkt_info->non_crc ? 4 : 0);
    packet_length += mtu_msg->l3_new_header_extra_len;
    if (!pkt_info->packet_length_adjust_type)
    {
        packet_length += pkt_info->packet_length_adjust;
    }
    else
    {
        packet_length -= pkt_info->packet_length_adjust;
    }

    if (ds_l3_edit_tunnel_v6->inner_header_valid)/* GRE header Valid */
    {
        if (0 == ds_l3_edit_tunnel_v6->inner_header_type)
        {
            new_payload_length = packet_length + 4;/* 4 byte GRE */
        }
        else if (1 == ds_l3_edit_tunnel_v6->inner_header_type)
        {
            new_payload_length= packet_length + 8;/* GRE with key */
        }
        else if (2 == ds_l3_edit_tunnel_v6->inner_header_type)
        {
            capwap_wlan_id_bitmap_valid = pkt_info->mcast
                        && (0 != ((ds_l3_edit_tunnel_v6->gre_protocol15_14 << 14)
                        | ds_l3_edit_tunnel_v6->gre_protocol13_0));/* means capwapWlanIdBitmap[15:0] */
            if ((1 == ((ds_l3_edit_tunnel_v6->gre_key15_0 >> 6)& 0x3))   /* used as udp_tunnel_type[1:0] */
                        && IS_BIT_SET(ds_l3_edit_tunnel_v6->ip_protocol_type, 4))/* means udpTunnelFlags[7:0] */
            {
                new_payload_length= packet_length + 8 + 16 + (capwap_wlan_id_bitmap_valid ? 4 : 0);
                udp_inner_header_length = 16 + (capwap_wlan_id_bitmap_valid ? 4 : 0);/* AC2WTP with radio MAC */
            }
            else if ((1 == ((ds_l3_edit_tunnel_v6->gre_key15_0 >> 6) & 0x3)) /* used as udp_tunnel_type[1:0] */
                        && !IS_BIT_SET(ds_l3_edit_tunnel_v6->ip_protocol_type, 4))/* means udpTunnelFlags[7:0] */
            {
                new_payload_length= packet_length + 8 + 8 + (capwap_wlan_id_bitmap_valid ? 4 : 0);
                udp_inner_header_length = 8 + (capwap_wlan_id_bitmap_valid ? 4 : 0); /* AC2WTP without radio MAC */
            }
            else if (2 == ((ds_l3_edit_tunnel_v6->gre_key15_0 >> 6) & 0x3))  /* used as udp_tunnel_type[1:0] */
            {
                new_payload_length = packet_length + 8 + 8;
                udp_inner_header_length = 8;
            }
            else
            {
                new_payload_length= packet_length + 8;
            }
        }
        else if (3 == ds_l3_edit_tunnel_v6->inner_header_type)
        {
            new_payload_length= packet_length - 8;    /* reserved */
        }
    }
    else
    {
        new_payload_length= packet_length;
    }

    /* Length field for UDP header */
    udp_length = (packet_length & 0x3FFF) + 8 + (udp_inner_header_length & 0x1F);    /* UDP lite ??? */

    /* Hop Limit */
    field_id = EpeL3EditMplsTtl_Ttl0_f + ds_l3_edit_tunnel_v6->ttl_index;
    cmd = DRV_IOR(EpeL3EditMplsTtl_t, field_id);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &ttl));

    if (ds_l3_edit_tunnel_v6->map_ttl)
    {
        new_ttl = (pkt_info->packet_ttl > ttl) ? (pkt_info->packet_ttl - ttl) : 0;
    }
    else
    {
        new_ttl = ttl;
    }

    if (!pkt_info->exception_en && (0 == new_ttl) && epe_pkt_proc_ctl.discard_tunnel_ttl0)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = 2;

        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE NewTTL=0 and DiscardTunnelTTL0 is set!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* Next Header */
    if (!(IS_BIT_SET(ds_l3_edit_tunnel_v6->inner_header_type, 1)) && ds_l3_edit_tunnel_v6->inner_header_valid)
    {
        new_protocol = 47;   /* GRE */
    }
    else if ((IS_BIT_SET(ds_l3_edit_tunnel_v6->inner_header_type, 1)) && ds_l3_edit_tunnel_v6->inner_header_valid)
    {
        new_protocol = 17;   /* UDP */
    }
    else
    {
        new_protocol = ds_l3_edit_tunnel_v6->ip_protocol_type;
    }

    /* New Ip address */
    /* Combine DsL3TunnelV6 and DsL2EditEth8W to get 128 bits ipDa[127:0] */
    ipsa_idx = ds_l3_edit_tunnel_v6->ip_sa_index & 0x7;
    sal_memset(&ds_l3_tunnel_v6_ip, 0, sizeof(ds_l3_tunnel_v6_ip));
    cmd = DRV_IOR(DsL3TunnelV6IpSa_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipsa_idx, cmd, &ds_l3_tunnel_v6_ip));

    new_ip_sa[0] = ds_l3_tunnel_v6_ip.ip_sa31_0;
    new_ip_sa[1] = ds_l3_tunnel_v6_ip.ip_sa63_32;
    new_ip_sa[2] = ds_l3_tunnel_v6_ip.ip_sa95_64;
    new_ip_sa[3] = ds_l3_tunnel_v6_ip.ip_sa127_96;

    if (mtu_msg->p_ds_l3_edit_tunnel_v6_ipda_79_0 != NULL)
    {
        new_ip_da[0] = mtu_msg->p_ds_l3_edit_tunnel_v6_ipda_79_0->ipda_31_0;
        new_ip_da[1] = mtu_msg->p_ds_l3_edit_tunnel_v6_ipda_79_0->ipda_63_32;
        new_ip_da[2] = ((ds_l3_edit_tunnel_v6->ip_da101_90 & 0x3F) << 26)
                       | (ds_l3_edit_tunnel_v6->ip_da89_80 << 16)
                       | (mtu_msg->p_ds_l3_edit_tunnel_v6_ipda_79_0->ipda_79_64);
    }

    new_ip_da[3] = (ds_l3_edit_tunnel_v6->ip_da127_126 << 30)
                   | (ds_l3_edit_tunnel_v6->ip_da125_123 << 27)
                   | (ds_l3_edit_tunnel_v6->ip_da122_122 << 26)
                   | (ds_l3_edit_tunnel_v6->ip_da121_114 << 18)
                   | (ds_l3_edit_tunnel_v6->ip_da113_102 << 6)
                   | (ds_l3_edit_tunnel_v6->ip_da101_90 >> 6);
    /* new flow label */
    if ((!ds_l3_edit_tunnel_v6->new_flow_label_valid) && ( L3_TYPE_IPV6 == parser_result->layer3_type))
    {
        new_flow_label = parser_result->l3_s.ipv6_flow_label;
    }
    else if (ds_l3_edit_tunnel_v6->new_flow_label_mode && ds_l3_edit_tunnel_v6->new_flow_label_valid)
    {
        new_flow_label = ds_l3_edit_tunnel_v6->flow_label + pkt_info->header_hash;
    }
    else
    {
        new_flow_label = ds_l3_edit_tunnel_v6->flow_label;
    }

    if (ds_l3_edit_tunnel_v6->inner_header_valid && (2 == ds_l3_edit_tunnel_v6->inner_header_type)
            && ((1 == ((ds_l3_edit_tunnel_v6->gre_key15_0 >> 6)& 0x3))  /* used as udp_tunnel_type[1:0] */
            || (2 == ((ds_l3_edit_tunnel_v6->gre_key15_0 >> 6) & 0x3)))) /* used as udp_tunnel_type[1:0] */
    {
        udp_src_port = epe_pkt_proc_ctl.capwap_udp_port;
    }
    else
    {
        udp_src_port = (ds_l3_edit_tunnel_v6->gre_protocol15_14 << 14)
                        | ds_l3_edit_tunnel_v6->gre_protocol13_0;          /* means udpSrcPort */
    }

     gre_key = (ds_l3_edit_tunnel_v6->gre_key31_16 <<16) | ds_l3_edit_tunnel_v6->gre_key15_0;

    if (ds_l3_edit_tunnel_v6->inner_header_valid && (2 == ds_l3_edit_tunnel_v6->inner_header_type))/* UDP tunnel */
    {
        capwap_wlan_id_bitmap_valid = (1 == ((ds_l3_edit_tunnel_v6->gre_key15_0 >> 6) & 0x3)) /* used as udp_tunnel_type */
                                       && pkt_info->mcast
                                       && (0 != ((ds_l3_edit_tunnel_v6->gre_protocol15_14 << 14)
                                            | ds_l3_edit_tunnel_v6->gre_protocol13_0));  /* used as capwap_wlan_id_bitmap */
        capwap_wlan_id_bitmap = (ds_l3_edit_tunnel_v6->gre_protocol15_14 << 14)
                        | ds_l3_edit_tunnel_v6->gre_protocol13_0;    /* used as capwap_wlan_id_bitmap */
        udp_tunnel_flags = ds_l3_edit_tunnel_v6->ip_protocol_type ;    /* used as udp_tunnel_flags */
        capwap_flags = udp_tunnel_flags << 2;
       /* capwapFlags[9] : F,   capwapFlags[8] : L */
       /* capwapFlags[7] : W,   capwapFlags[6] : M */
        if ((1 == ((ds_l3_edit_tunnel_v6->gre_key15_0 >> 6) & 0x3))  /* used as udp_tunnel_type */
             && IS_BIT_SET(capwap_flags,6))
        {

            /* AC2WTP with radio MAC */
            udp_tunnel_type_header[1] = (pkt_info->mac_31_to_0 & 0xFFFFFF) << 8;
            udp_tunnel_type_header[2] = (0x6 << 24)
                                        | (pkt_info->mac_47_to_32 << 8)
                                        | ((pkt_info->mac_31_to_0 >> 24) & 0xFF);
            udp_tunnel_type_header[3] = 0;
            udp_tunnel_type_header[4] = (4 << 19)
                                        | (((ds_l3_edit_tunnel_v6->gre_key15_0 >> 1) & 0x1F) << 14)/* used as rid[4:0] */
                                        | (((ds_l3_edit_tunnel_v6->gre_key15_0 >> 8) & 0x1F) << 9) /* used as capwapWbid[4:0] */
                                        | (((capwap_flags >> 8)& 0x3)<< 6)
                                        | ((capwap_wlan_id_bitmap_valid)<< 5)
                                        | (((capwap_flags >> 6)& 0x1)<< 4)
                                        | ((capwap_flags >> 3)& 0x7);
            if (capwap_wlan_id_bitmap_valid)
            {
                udp_tunnel_type_header[4] = (udp_tunnel_type_header[4] & 0xFF07FFFF) | (5 << 19);
                udp_tunnel_type_header[0] = capwap_wlan_id_bitmap << 16;
                capwap_header_length = 3;   /* 20 */
            }
            else
            {
                capwap_header_length = 2;   /* 16 */
            }
        }
        else if ((1 == ((ds_l3_edit_tunnel_v6->gre_key15_0 >> 6) & 0x3))  /* used as udp_tunnel_type */
                    && !IS_BIT_SET(capwap_flags,6)) /* used as udp_tunnel_flags[7:0] */
        {
            /* AC2WTP without radio MAC */

            udp_tunnel_type_header[3] = 0;

            udp_tunnel_type_header[4] = (2 << 19)
                                        | (((ds_l3_edit_tunnel_v6->gre_key15_0 >> 1) & 0x1F) << 14)/* used as rid[4:0] */
                                        | (((ds_l3_edit_tunnel_v6->gre_key15_0 >> 8) & 0x1F) << 9) /* used as capwapWbid[4:0] */
                                        | (((capwap_flags >> 8)& 0x3)<< 6)
                                        | ((capwap_wlan_id_bitmap_valid)<< 5)
                                        | (((capwap_flags >> 6)& 0x1)<< 4)
                                        | ((capwap_flags >> 3)& 0x7);
            if (capwap_wlan_id_bitmap_valid)
            {
                udp_tunnel_type_header[4] = (udp_tunnel_type_header[4] & 0xFF07FFFF) | (3 << 19);
                udp_tunnel_type_header[2] = capwap_wlan_id_bitmap << 16;
                capwap_header_length = 1;   /* 12 */
            }
            else
            {
                capwap_header_length = 0;   /* 8 */
            }
        }
        else if (2 == ((ds_l3_edit_tunnel_v6->gre_key15_0 >> 6) & 0x3))   /* used as udp_tunnel_type */
        {
            /* AC2AC */

            roaming_state = (FA == pkt_info->roaming_state) ? FA : HA; /* FA:2 HA:1 */

            /* For SA FA tunnel 2 HA, For DA HA tunnel 2 FA */
            /* capwapFlags[9] : F,   capwapFlags[8] : L */
            /* capwapFlags[7] : W,   capwapFlags[6] : M */
            /* capwapFlags[5:3] : Flags, capwapFlags[2:0] : roamingState[2:0](Rsvd) */
            switch (epe_pkt_proc_ctl.capwap_roaming_state_bits)
            {
                case 0:
                    capwap_flags = (ds_l3_edit_tunnel_v6->ip_protocol_type & 0xF)   /* used as udp_tunnel_flags[3:0] */
                        | ((roaming_state & 0x3) << 4)
                        | ((ds_l3_edit_tunnel_v6->ip_protocol_type & 0xF0) << 2);   /* used as udp_tunnel_flags[7:4] */
                    break;

                case 1:
                    capwap_flags = (ds_l3_edit_tunnel_v6->ip_protocol_type & 0x7)   /* used as udp_tunnel_flags[2:0] */
                        | ((roaming_state & 0x3) << 3)
                        | ((ds_l3_edit_tunnel_v6->ip_protocol_type & 0xF8) << 2);   /* used as udp_tunnel_flags[7:3] */
                    break;

                case 2:
                    capwap_flags = (ds_l3_edit_tunnel_v6->ip_protocol_type & 0x1)   /* used as udp_tunnel_flags[0:0] */
                        | ((roaming_state & 0x3) << 1)
                        | ((ds_l3_edit_tunnel_v6->ip_protocol_type & 0xFE) << 2);   /* used as udp_tunnel_flags[7:1] */
                    break;

                case 3:
                    capwap_flags = (roaming_state & 0x3)
                        | ((ds_l3_edit_tunnel_v6->ip_protocol_type & 0xFF) << 2);   /* used as udp_tunnel_flags[7:0] */
                    break;

                default:
                    break;

            }

            udp_tunnel_type_header[3] = capwap_flags & 0x7;

            udp_tunnel_type_header[4] = (2 << 19)
                                        |(((ds_l3_edit_tunnel_v6->gre_key15_0 >> 1) & 0x1F) << 14)/* used as rid[4:0] */
                                        |(((ds_l3_edit_tunnel_v6->gre_key15_0 >> 8) & 0x1F) << 9)/* used as capwapWbid[4:0] */
                                        |(((capwap_flags >> 6)& 0xF) << 4)
                                        |((capwap_flags >> 3) & 0x7);
            capwap_header_length = 0;   /* 8 */

        }
        else
        {
            capwap_header_length = 4; /* 0 */
        }
    }

    /* new ipv6 header */
    pkt_info->l3_header[0] =((0x6 << 4) | ((new_dscp >> 2) & 0xF));
    pkt_info->l3_header[1] = ((new_dscp & 0x3) << 6) | (new_tos_lowbits << 4) | ((new_flow_label >> 16) & 0xF);
    pkt_info->l3_header[2] = ((new_flow_label & 0xFF00) >> 8);
    pkt_info->l3_header[3] =  (new_flow_label & 0xFF) ;

    pkt_info->l3_header[4] = ((new_payload_length >> 8) & 0xFF);
    pkt_info->l3_header[5] = (new_payload_length & 0xFF);
    pkt_info->l3_header[6] = (new_protocol & 0xFF);
    pkt_info->l3_header[7] = (new_ttl & 0xFF);

    pkt_info->l3_header[8] = (new_ip_sa[3] >> 24) & 0xFF;
    pkt_info->l3_header[9] = (new_ip_sa[3] >> 16) & 0xFF;
    pkt_info->l3_header[10] = (new_ip_sa[3] >> 8) & 0xFF;
    pkt_info->l3_header[11] = new_ip_sa[3] & 0xFF;
    pkt_info->l3_header[12] = (new_ip_sa[2] >> 24) & 0xFF;
    pkt_info->l3_header[13] = (new_ip_sa[2] >> 16) & 0xFF;
    pkt_info->l3_header[14] = (new_ip_sa[2] >> 8) & 0xFF;
    pkt_info->l3_header[15] = new_ip_sa[2] & 0xFF;
    pkt_info->l3_header[16] = (new_ip_sa[1] >> 24) & 0xFF;
    pkt_info->l3_header[17] = (new_ip_sa[1] >> 16) & 0xFF;
    pkt_info->l3_header[18] = (new_ip_sa[1] >> 8) & 0xFF;
    pkt_info->l3_header[19] = new_ip_sa[1] & 0xFF;
    pkt_info->l3_header[20] = (new_ip_sa[0] >> 24) & 0xFF;
    pkt_info->l3_header[21] = (new_ip_sa[0] >> 16) & 0xFF;
    pkt_info->l3_header[22] = (new_ip_sa[0] >> 8) & 0xFF;
    pkt_info->l3_header[23] = new_ip_sa[0] & 0xFF;

    pkt_info->l3_header[24] = (new_ip_da[3] >> 24) & 0xFF;
    pkt_info->l3_header[25] = (new_ip_da[3] >> 16) & 0xFF;
    pkt_info->l3_header[26] = (new_ip_da[3] >> 8) & 0xFF;
    pkt_info->l3_header[27] = new_ip_da[3] & 0xFF;
    pkt_info->l3_header[28] = (new_ip_da[2] >> 24) & 0xFF;
    pkt_info->l3_header[29] = (new_ip_da[2] >> 16) & 0xFF;
    pkt_info->l3_header[30] = (new_ip_da[2] >> 8) & 0xFF;
    pkt_info->l3_header[31] = new_ip_da[2] & 0xFF;
    pkt_info->l3_header[32] = (new_ip_da[1] >> 24) & 0xFF;
    pkt_info->l3_header[33] = (new_ip_da[1] >> 16) & 0xFF;
    pkt_info->l3_header[34] = (new_ip_da[1] >> 8) & 0xFF;
    pkt_info->l3_header[35] = new_ip_da[1] & 0xFF;
    pkt_info->l3_header[36] = (new_ip_da[0] >> 24) & 0xFF;
    pkt_info->l3_header[37] = (new_ip_da[0] >> 16) & 0xFF;
    pkt_info->l3_header[38] = (new_ip_da[0] >> 8) & 0xFF;
    pkt_info->l3_header[39] = new_ip_da[0] & 0xFF;

    if (ds_l3_edit_tunnel_v6->inner_header_valid)
    {
        switch(ds_l3_edit_tunnel_v6->inner_header_type)
        {
            case 0:  /* GRE without key field*/
                pkt_info->l3_new_header_len = 44;

                pkt_info->l3_header[40] = (ds_l3_edit_tunnel_v6->ip_protocol_type & 0x3) << 4; /*used as greflags*/
                pkt_info->l3_header[41] = (ds_l3_edit_tunnel_v6->ip_protocol_type >> 4) & 0x1;  /* used as gre_version */
                pkt_info->l3_header[42] = (ds_l3_edit_tunnel_v6->gre_protocol15_14 << 6)
                                        | ((ds_l3_edit_tunnel_v6->gre_protocol13_0 >> 8) & 0x3F);
                pkt_info->l3_header[43] = ds_l3_edit_tunnel_v6->gre_protocol13_0 & 0xFF;

                break;

            case 1: /* GRE with key field*/
                pkt_info->l3_new_header_len = 48;

                pkt_info->l3_header[40] = (ds_l3_edit_tunnel_v6->ip_protocol_type  & 0x3) << 4;/*used as greflags*/
                pkt_info->l3_header[41] = (ds_l3_edit_tunnel_v6->ip_protocol_type >> 4) & 0x1;/* used as gre_version */
                pkt_info->l3_header[42] = (ds_l3_edit_tunnel_v6->gre_protocol15_14 << 6)
                                        | ((ds_l3_edit_tunnel_v6->gre_protocol13_0 >> 8) & 0x3F);
                pkt_info->l3_header[43] = ds_l3_edit_tunnel_v6->gre_protocol13_0 & 0xFF;
                pkt_info->l3_header[44] = (gre_key >> 24) & 0xFF;
                pkt_info->l3_header[45] = (gre_key >> 16) & 0xFF;
                pkt_info->l3_header[46] = (gre_key >> 8) & 0xFF;
                pkt_info->l3_header[47] = gre_key & 0xFF;

                break;

            case 2: /* 8 byte UDP header */
                udp_header[0] = (udp_src_port >> 8) & 0xFF; /* used as udp_src_port */
                udp_header[1] = udp_src_port & 0xFF;
                udp_header[2] = (ds_l3_edit_tunnel_v6->gre_key31_16 >> 8) & 0xFF;   /* used as udp_dest_port */
                udp_header[3] = ds_l3_edit_tunnel_v6->gre_key31_16 & 0xFF;
                udp_header[4] = (udp_length >> 8) & 0x3F;
                udp_header[5] = udp_length & 0xFF;
                udp_header[6] = 0;
                udp_header[7] = 0;

                switch (capwap_header_length & 0x7)
                {
                    case 0:
                        pkt_info->l3_new_header_len = 48 + 8;

                        for (index = 40; index < 48; index ++)
                        {
                            pkt_info->l3_header[index] = udp_header[index-40];
                        }

                        pkt_info->l3_header[48+0] = (udp_tunnel_type_header[4] >> 24)& 0xFF;
                        pkt_info->l3_header[48+1] = (udp_tunnel_type_header[4] >> 16)& 0xFF;
                        pkt_info->l3_header[48+2] = (udp_tunnel_type_header[4] >> 8)& 0xFF;
                        pkt_info->l3_header[48+3] = udp_tunnel_type_header[4] & 0xFF;
                        pkt_info->l3_header[48+4] = (udp_tunnel_type_header[3] >> 24)& 0xFF;
                        pkt_info->l3_header[48+5] = (udp_tunnel_type_header[3] >> 16)& 0xFF;
                        pkt_info->l3_header[48+6] = (udp_tunnel_type_header[3] >> 8)& 0xFF;
                        pkt_info->l3_header[48+7] = udp_tunnel_type_header[3] & 0xFF;

                        break;

                     case 1:
                        pkt_info->l3_new_header_len = 48 + 12;

                        for (index = 40; index < 48; index ++)
                        {
                            pkt_info->l3_header[index] = udp_header[index-40];
                        }

                        pkt_info->l3_header[48+0] = (udp_tunnel_type_header[4] >> 24)& 0xFF;
                        pkt_info->l3_header[48+1] = (udp_tunnel_type_header[4] >> 16)& 0xFF;
                        pkt_info->l3_header[48+2] = (udp_tunnel_type_header[4] >> 8)& 0xFF;
                        pkt_info->l3_header[48+3] = udp_tunnel_type_header[4] & 0xFF;
                        pkt_info->l3_header[48+4] = (udp_tunnel_type_header[3] >> 24)& 0xFF;
                        pkt_info->l3_header[48+5] = (udp_tunnel_type_header[3] >> 16)& 0xFF;
                        pkt_info->l3_header[48+6] = (udp_tunnel_type_header[3] >> 8)& 0xFF;
                        pkt_info->l3_header[48+7] = udp_tunnel_type_header[3] & 0xFF;
                        pkt_info->l3_header[48+8] = (udp_tunnel_type_header[2] >> 24)& 0xFF;
                        pkt_info->l3_header[48+9] = (udp_tunnel_type_header[2] >> 16)& 0xFF;
                        pkt_info->l3_header[48+10] = (udp_tunnel_type_header[2] >> 8)& 0xFF;
                        pkt_info->l3_header[48+11] = udp_tunnel_type_header[2] & 0xFF;

                        break;

                     case 2:
                        pkt_info->l3_new_header_len = 48 + 16;

                        for (index = 40; index < 48; index ++)
                        {
                            pkt_info->l3_header[index] = udp_header[index-40];
                        }

                        pkt_info->l3_header[48+0] = (udp_tunnel_type_header[4] >> 24)& 0xFF;
                        pkt_info->l3_header[48+1] = (udp_tunnel_type_header[4] >> 16)& 0xFF;
                        pkt_info->l3_header[48+2] = (udp_tunnel_type_header[4] >> 8)& 0xFF;
                        pkt_info->l3_header[48+3] = udp_tunnel_type_header[4] & 0xFF;
                        pkt_info->l3_header[48+4] = (udp_tunnel_type_header[3] >> 24)& 0xFF;
                        pkt_info->l3_header[48+5] = (udp_tunnel_type_header[3] >> 16)& 0xFF;
                        pkt_info->l3_header[48+6] = (udp_tunnel_type_header[3] >> 8)& 0xFF;
                        pkt_info->l3_header[48+7] = udp_tunnel_type_header[3] & 0xFF;
                        pkt_info->l3_header[48+8] = (udp_tunnel_type_header[2] >> 24)& 0xFF;
                        pkt_info->l3_header[48+9] = (udp_tunnel_type_header[2] >> 16)& 0xFF;
                        pkt_info->l3_header[48+10] = (udp_tunnel_type_header[2] >> 8)& 0xFF;
                        pkt_info->l3_header[48+11] = udp_tunnel_type_header[2] & 0xFF;
                        pkt_info->l3_header[48+12] = (udp_tunnel_type_header[1] >> 24)& 0xFF;
                        pkt_info->l3_header[48+13] = (udp_tunnel_type_header[1] >> 16)& 0xFF;
                        pkt_info->l3_header[48+14] = (udp_tunnel_type_header[1] >> 8)& 0xFF;
                        pkt_info->l3_header[48+15] = udp_tunnel_type_header[1] & 0xFF;

                        break;

                     case 3:

                        pkt_info->l3_new_header_len = 48 + 20;   /* high 4 bytes to L2NewHeader low 4 bytes,len adjustment*/

                        for (index = 40; index < 48; index ++)
                        {
                            pkt_info->l3_header[index] = udp_header[index-40];
                        }

                        pkt_info->l3_header[48+0] = (udp_tunnel_type_header[4] >> 24)& 0xFF;
                        pkt_info->l3_header[48+1] = (udp_tunnel_type_header[4] >> 16)& 0xFF;
                        pkt_info->l3_header[48+2] = (udp_tunnel_type_header[4] >> 8)& 0xFF;
                        pkt_info->l3_header[48+3] = udp_tunnel_type_header[4] & 0xFF;
                        pkt_info->l3_header[48+4] = (udp_tunnel_type_header[3] >> 24)& 0xFF;
                        pkt_info->l3_header[48+5] = (udp_tunnel_type_header[3] >> 16)& 0xFF;
                        pkt_info->l3_header[48+6] = (udp_tunnel_type_header[3] >> 8)& 0xFF;
                        pkt_info->l3_header[48+7] = udp_tunnel_type_header[3] & 0xFF;
                        pkt_info->l3_header[48+8] = (udp_tunnel_type_header[2] >> 24)& 0xFF;
                        pkt_info->l3_header[48+9] = (udp_tunnel_type_header[2] >> 16)& 0xFF;
                        pkt_info->l3_header[48+10] = (udp_tunnel_type_header[2] >> 8)& 0xFF;
                        pkt_info->l3_header[48+11] = udp_tunnel_type_header[2] & 0xFF;
                        pkt_info->l3_header[48+12] = (udp_tunnel_type_header[1] >> 24)& 0xFF;
                        pkt_info->l3_header[48+13] = (udp_tunnel_type_header[1] >> 16)& 0xFF;
                        pkt_info->l3_header[48+14] = (udp_tunnel_type_header[1] >> 8)& 0xFF;
                        pkt_info->l3_header[48+15] = udp_tunnel_type_header[1] & 0xFF;
                        pkt_info->l3_header[48+16] = (udp_tunnel_type_header[0] >> 24)& 0xFF;
                        pkt_info->l3_header[48+17] = (udp_tunnel_type_header[0] >> 16)& 0xFF;
                        pkt_info->l3_header[48+18] = (udp_tunnel_type_header[0] >> 8)& 0xFF;
                        pkt_info->l3_header[48+19] = udp_tunnel_type_header[0] & 0xFF;

                        break;

                    default:
                        pkt_info->l3_new_header_len = 48;
                        for (index = 40; index < 48; index ++)
                        {
                            pkt_info->l3_header[index] = udp_header[index-40];
                        }

                        break;
                }
            break;

        case 3:
            pkt_info->l3_new_header_len = 40;
            break;
        default:
            break;
        }
    }
    else  /* Add IP header only */
    {
        pkt_info->l3_new_header_len = 40;
    }

    /* REPLACE_PARSER_RESULT */
    pkt_info->packet_ttl = new_ttl; /*packet TTL has been updated*/
    pkt_info->packet_type = PKT_TYPE_IPV6;

    /* ParserResult to be updated */
    if (ds_l3_edit_tunnel_v6->inner_header_valid && (IS_BIT_SET(ds_l3_edit_tunnel_v6->inner_header_type, 1)))
    {
        mtu_msg->is_udp_update = TRUE;
    }
    else
    {
        mtu_msg->is_udp_update = FALSE;
    }
    mtu_msg->is_tcp_update = FALSE;
    mtu_msg->frag_info_update = 0;
    mtu_msg->layer3_type_update = L3_TYPE_IPV6;
    mtu_msg->ip_options_update = 0;
    mtu_msg->ip_header_error_update = 0;
    mtu_msg->ip_da_31_0_update = new_ip_da[0];
    mtu_msg->ip_da_63_32_update = new_ip_da[1];
    mtu_msg->ip_da_95_64_update = new_ip_da[2];
    mtu_msg->ip_da_127_96_update = new_ip_da[3];
    mtu_msg->ip_sa_31_0_update = new_ip_sa[0];
    mtu_msg->ip_sa_63_32_update = new_ip_sa[1];
    mtu_msg->ip_sa_95_64_update = new_ip_sa[2];
    mtu_msg->ip_sa_127_96_update = new_ip_sa[3];
    mtu_msg->layer4_info_mapped_update = new_protocol;
    mtu_msg->tos_update = new_tos_lowbits | (new_dscp << 2);
    mtu_msg->ipv6_flow_label_update = new_flow_label;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_epe_layer3_editing_tunnelv4
 * Purpose:    perform tunnelv4 encapsulation.
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *             ds_l3_edit_tunnel_v4 -- pointer to ds_l3_edit_tunnel_v4_t
 *             mtu_msg  -- pointer to mtu msg struct
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *             mtu_msg  -- pointer to mtu msg struct
 * Return:     DRV_E_NONE = success.
 *               Other              = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_epe_layer3_editing_tunnelv4(epe_in_pkt_t* ipkt,
                        ds_l3_edit_tunnel_v4_t* ds_l3_edit_tunnel_v4, cm_epe_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    ds_l3_tunnel_v4_ip_sa_t ds_l3_tunnel_v4_ip_sa;
    epe_l3_ip_identification_t epe_l3_ip_identification;
    epe_pkt_proc_ctl_t epe_pkt_proc_ctl;

    uint8 new_dscp = 0, new_ttl = 0, new_protocol = 0;
    uint8 dont_frag = 0;
    uint16 new_total_len = 0;
    uint16 new_ip_identification = 0;
    uint16 new_check_sum = 0;
    uint32 cmd = 0;
    uint32 new_ip_sa = 0, new_ip_da = 0;
    uint32 gre_key = 0;
    uint32 field_id = 0;
    uint16 packet_length = 0;
    uint32 ipsa_index = 0;
    uint8 index = 0;
    uint8 ipv4_prefix_length = 0;
    uint32 ttl = 0;
    uint8 capwap_wlan_id_bitmap_valid = FALSE;
    uint16 capwap_wlan_id_bitmap = 0;
    uint8 capwap_header_length = 0;
    uint16 capwap_flags = 0;
    uint8 roaming_state = 0;

    uint32 udp_tunnel_type_header[6] = {0};
    uint16 udp_length = 0;
    uint8 udp_inner_header_length = 0;
    uint16 udp_src_port = 0;
    uint8 udp_tunnel_flags = 0;
    uint8 udp_header[8] = {0};

    uint32 _6_to_4_sa = 0, _6_to_4_sa_value = 0, dsl3edit_ipda_value = 0;
    uint32 parser_ipsa_temp = 0, parser_ipda_temp = 0;

    /* DISCARD_SWITCH */
    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    sal_memset(&epe_pkt_proc_ctl, 0, sizeof(epe_pkt_proc_ctl_t));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_ctl));

    /* NEW_IP_HEADER_FIELDS */
    /* DSCP */
    if (ds_l3_edit_tunnel_v4->derive_dscp && IS_BIT_SET(ds_l3_edit_tunnel_v4->dscp, 0))
    {
        new_dscp = pkt_info->mapped_dscp;
    }
    else if (ds_l3_edit_tunnel_v4->derive_dscp && !(IS_BIT_SET(ds_l3_edit_tunnel_v4->dscp, 0)))
    {
        new_dscp = pkt_info->src_dscp;
    }
    else
    {
        new_dscp = ds_l3_edit_tunnel_v4->dscp;
    }

    /* Total length */
    packet_length = pkt_info->packet_length - (!pkt_info->non_crc ? 4 : 0);
    packet_length = packet_length + mtu_msg->l3_new_header_extra_len;
    if (!pkt_info->packet_length_adjust_type)
    {
        packet_length += pkt_info->packet_length_adjust;
    }
    else
    {
        packet_length -= pkt_info->packet_length_adjust;
    }

    if (ds_l3_edit_tunnel_v4->inner_header_valid)
    {
        switch (ds_l3_edit_tunnel_v4->inner_header_type)
        {
            case 0:
                new_total_len = (packet_length & 0x3FFF) + 24;/* 4 byte GRE */
                break;
            case 1:
                new_total_len = (packet_length & 0x3FFF) + 28;/* 8 byte GRE header(with GRE key field) */
                break;
            case 2:
                capwap_wlan_id_bitmap_valid = pkt_info->mcast
                        && (0 != ((ds_l3_edit_tunnel_v4->gre_protocol15_14 << 14)
                                   | (ds_l3_edit_tunnel_v4->gre_protocol13_0)));   /* used as capwap_wlan_id_bitmap */
                if ((1 == (ds_l3_edit_tunnel_v4->gre_flags & 0x3))  /* used as udp_tunnel_type */
                        && IS_BIT_SET(ds_l3_edit_tunnel_v4->ip_protocol_type, 4))/* used as udp_tunnel_flags */
                {
                    /* capwap Flag[6] */
                    /* AC2WTP rMAC */
                    new_total_len = (packet_length & 0x3FFF) + 28 + 16 + (capwap_wlan_id_bitmap_valid ? 4 : 0);
                    udp_inner_header_length = 16 + (capwap_wlan_id_bitmap_valid ? 4 : 0);
                }
                else if ((1 == (ds_l3_edit_tunnel_v4->gre_flags & 0x3))
                        && !(IS_BIT_SET(ds_l3_edit_tunnel_v4->ip_protocol_type, 4)))/* used as udp_tunnel_flags */
                {
                    /* capwap Flag[6] */
                    /* AC2WTP */
                    new_total_len = (packet_length & 0x3FFF) + 28 + 8 + (capwap_wlan_id_bitmap_valid ? 4 : 0);
                    udp_inner_header_length = 8 + (capwap_wlan_id_bitmap_valid ? 4 : 0);
                }
                else if (2 == (ds_l3_edit_tunnel_v4->gre_flags & 0x3))/* used as udp_tunnel_type */
                {
                    /* AC2AC */
                    new_total_len = (packet_length & 0x3FFF) + 28 + 8;
                    udp_inner_header_length = 8;
                }
                else
                {
                    /* Normal UDP tunnel */
                    new_total_len = (packet_length & 0x3FFF) + 28;
                    udp_inner_header_length = 0;
                }
                break;
            case 3:
                /* 12 byte UDP + MIP header */
                new_total_len = (packet_length & 0x3FFF) + 32;
                udp_inner_header_length = 4;
                break;
            default:
                break;
        }
    }
    else
    {
        new_total_len = (packet_length & 0x3FFF) + 20 ;/* excluding CRC, so packet must entry with CRC */
    }

    /* Length field for UDP header */
    udp_length = (packet_length & 0x3FFF) + 8 + (udp_inner_header_length & 0x1F);

    /* IP identification */
    sal_memset(&epe_l3_ip_identification, 0, sizeof(epe_l3_ip_identification_t));
    cmd = DRV_IOR(EpeL3IpIdentification_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l3_ip_identification));

    if (ds_l3_edit_tunnel_v4->ip_identification_type)
    {
        new_ip_identification = epe_l3_ip_identification.ip_identification1;
        epe_l3_ip_identification.ip_identification1++;
    }
    else
    {
        new_ip_identification = epe_l3_ip_identification.ip_identification0;
        epe_l3_ip_identification.ip_identification0++;
    }
    cmd = DRV_IOW(EpeL3IpIdentification_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l3_ip_identification));

    /* TTL */
    field_id = EpeL3EditMplsTtl_Ttl0_f + ds_l3_edit_tunnel_v4->ttl_index;
    cmd = DRV_IOR(EpeL3EditMplsTtl_t, field_id);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &ttl));

    if (ds_l3_edit_tunnel_v4->map_ttl)
    {
        new_ttl = (pkt_info->packet_ttl > ttl) ? (pkt_info->packet_ttl - ttl) : 0;
    }
    else
    {
        new_ttl = ttl;
    }

    if (!pkt_info->exception_en && (0 == new_ttl) && epe_pkt_proc_ctl.discard_tunnel_ttl0)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = 2;

        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE NewTTL=0 and DiscardTunnelTTL0 is set!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* protocol */
    if (!(IS_BIT_SET(ds_l3_edit_tunnel_v4->inner_header_type, 1))
        && ds_l3_edit_tunnel_v4->inner_header_valid)
    {
        new_protocol = 47;  /* GRE */
    }
    else if ((IS_BIT_SET(ds_l3_edit_tunnel_v4->inner_header_type, 1)
        && ds_l3_edit_tunnel_v4->inner_header_valid))
    {
        new_protocol = 17;  /* UDP */
    }
    else
    {
        new_protocol = ds_l3_edit_tunnel_v4->ip_protocol_type;
    }

    /* new ip address */
    if (ds_l3_edit_tunnel_v4->tunnel6_to4_sa)
    {
        ipv4_prefix_length = ds_l3_edit_tunnel_v4->gre_key & 0x1F; /* 6to4TunnelSaIpv4PrefixLength, only even for RTL */
        _6_to_4_sa = (((ds_l3_edit_tunnel_v4->gre_protocol15_14 << 14)
                    | ds_l3_edit_tunnel_v4->gre_protocol13_0) << 16)
                    | (ds_l3_edit_tunnel_v4->ipv4_sa_index & 0xFFFF);
        _6_to_4_sa_value = (_6_to_4_sa&(~((1<<(32-ipv4_prefix_length))- 1))); /* 6to4Sa[31:(32-ipv4PrefixLength)]*/

        switch ((ds_l3_edit_tunnel_v4->gre_key >> 5) & 0x7)       /* 6to4TunnelSaIpv6PrefixLength */
        {
            case 0:                                                        /* prefix length 16 */
                /* ParserResult.ipSa[111:80] */
                parser_ipsa_temp = (parser_result->l3_s.ip_sa.ipv6.ipsa_95_64>>16)
                                | ((parser_result->l3_s.ip_sa.ipv6.ipsa_127_96&0xFFFF)<<16);

                /* {6to4Sa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipSa[111:(112-(32-ipv4PrefixLength[4:0]))]} */
                break;
            case 1:                                                        /* prefix length 24 */
                /* ParserResult.ipSa[103:72] */
                parser_ipsa_temp = (parser_result->l3_s.ip_sa.ipv6.ipsa_95_64>>8)
                                | ((parser_result->l3_s.ip_sa.ipv6.ipsa_127_96&0xFF)<<24);

                /* {6to4Sa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipSa[103:(104-(32-ipv4PrefixLength[4:0]))]} */
                break;
            case 2:                                                        /* prefix length 32 */
                /* ParserResult.ipSa[95:64] */
                parser_ipsa_temp = parser_result->l3_s.ip_sa.ipv6.ipsa_95_64;

                /* {6to4Sa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipSa[95:(96-(32-ipv4PrefixLength[4:0]))]} */
                break;
            case 3:                                                        /* prefix length 40 */
                /* ParserResult.ipSa[87:56] */
                parser_ipsa_temp = (parser_result->l3_s.ip_sa.ipv6.ipsa_63_32>>24)
                                | ((parser_result->l3_s.ip_sa.ipv6.ipsa_95_64&0xFFFFFF)<<8);

                /* {6to4Sa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipSa[87:(88-(32-ipv4PrefixLength[4:0]))]} */
                break;
            case 4:                                                        /* prefix length 48 */
                /* ParserResult.ipSa[79:48] */
                parser_ipsa_temp = (parser_result->l3_s.ip_sa.ipv6.ipsa_63_32>>16)
                                | ((parser_result->l3_s.ip_sa.ipv6.ipsa_95_64&0xFFFF)<<16);

                /* {6to4Sa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipSa[79:(80-(32-ipv4PrefixLength[4:0]))]} */
                break;
            default:                                                       /* prefix length 56 */
                /* ParserResult.ipSa[71:40] */
                parser_ipsa_temp = (parser_result->l3_s.ip_sa.ipv6.ipsa_63_32>>8)
                                | ((parser_result->l3_s.ip_sa.ipv6.ipsa_95_64&0xFF)<<24);

                /* {6to4Sa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipSa[71:(72-(32-ipv4PrefixLength[4:0]))]} */
                break;
        }

        if (0 == ipv4_prefix_length)
        {
            new_ip_sa = parser_ipsa_temp;
        }
        else
        {
            new_ip_sa
                = _6_to_4_sa_value | ((parser_ipsa_temp&(~((1<<ipv4_prefix_length)-1)))>>ipv4_prefix_length);
        }
    }
    else
    {
        ipsa_index = (ds_l3_edit_tunnel_v4->ipv4_sa_index) & 0x1F;    /* ipSaIndex */
        cmd = DRV_IOR(DsL3TunnelV4IpSa_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipsa_index, cmd, &ds_l3_tunnel_v4_ip_sa));

        new_ip_sa = ds_l3_tunnel_v4_ip_sa.ip_sa;
    }

    if (ds_l3_edit_tunnel_v4->isatp_tunnel)
    {
        new_ip_da = parser_result->l3_s.ip_da.ipv6.ipda_31_0; /* lower 32 bit of the ipv6 Da */
    }
    else if (ds_l3_edit_tunnel_v4->tunnel6_to4_da)
    {
        ipv4_prefix_length = (ds_l3_edit_tunnel_v4->gre_key >> 8) & 0x1F;/* means 6to4TunnelIpv4PrefixLength */
        /* DsL3EditTunnelV4.ipDa[31:(32-ipv4PrefixLength)] */
        dsl3edit_ipda_value = (ds_l3_edit_tunnel_v4->ip_da&(~((1<<(32-ipv4_prefix_length))- 1)));

        switch ((ds_l3_edit_tunnel_v4->gre_key >> 13) & 0x7)             /* means 6to4TunnelIpv6PrefixLength */
        {
            case 0:                                                      /* prefix length 16 */
                /* ParserResult.ipDa[111:80] */
                parser_ipda_temp = (parser_result->l3_s.ip_da.ipv6.ipda_95_64>>16)
                                | ((parser_result->l3_s.ip_da.ipv6.ipda_127_96&0xFFFF)<<16);

                /* {DsL3EditTunnelV4.ipDa[31:(32-ipv4PrefixLength)],
                    ParserResult.ipDa[111:(112-(32-ipv4PrefixLength[4:0]))]} */
                break;
            case 1:                                                     /* prefix length 24 */
                /* ParserResult.ipDa[103:72] */
                parser_ipda_temp = (parser_result->l3_s.ip_da.ipv6.ipda_95_64>>8)
                                | ((parser_result->l3_s.ip_da.ipv6.ipda_127_96&0xFF)<<24);

                /* {DsL3EditTunnelV4.ipDa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipDa[103:(104-(32-ipv4PrefixLength[4:0]))]} */
                break;
            case 2:                                                     /* prefix length 32 */
                /* ParserResult.ipDa[95:64] */
                parser_ipda_temp = parser_result->l3_s.ip_da.ipv6.ipda_95_64;

                /* {DsL3EditTunnelV4.ipDa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipDa[95:(96-(32-ipv4PrefixLength[4:0]))]} */
                break;
            case 3:                                                     /* prefix length 40 */
                /* ParserResult.ipDa[87:56] */
                parser_ipda_temp = (parser_result->l3_s.ip_da.ipv6.ipda_63_32>>24)
                                | ((parser_result->l3_s.ip_da.ipv6.ipda_95_64&0xFFFFFF)<<8);

                /* {DsL3EditTunnelV4.ipDa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipDa[87:(88-(32-ipv4PrefixLength[4:0]))]} */
                break;
            case 4:                                                     /* prefix length 48 */
                /* ParserResult.ipDa[79:48] */
                parser_ipda_temp = (parser_result->l3_s.ip_da.ipv6.ipda_63_32>>16)
                                | ((parser_result->l3_s.ip_da.ipv6.ipda_95_64&0xFFFF)<<16);

                /* {DsL3EditTunnelV4.ipDa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipDa[79:(80-(32-ipv4PrefixLength[4:0]))]} */
                break;
            default:                                                    /* prefix length 56 */
                /* ParserResult.ipDa[71:40] */
                parser_ipda_temp = (parser_result->l3_s.ip_da.ipv6.ipda_63_32>>8)
                                | ((parser_result->l3_s.ip_da.ipv6.ipda_95_64&0xFF)<<24);

                /* {DsL3EditTunnelV4.ipDa[31:(32-ipv4PrefixLength[4:0])],
                    ParserResult.ipDa[71:(72-(32-ipv4PrefixLength[4:0]))]} */
                break;
        }

        if (0 == ipv4_prefix_length)
        {
            new_ip_da = parser_ipda_temp;
        }
        else
        {
            new_ip_da
                = dsl3edit_ipda_value | ((parser_ipda_temp&(~((1<<ipv4_prefix_length)-1)))>>ipv4_prefix_length);
        }
    }
    else
    {
        new_ip_da = ds_l3_edit_tunnel_v4->ip_da;
    }

    if (ds_l3_edit_tunnel_v4->copy_dont_frag && parser_result->l3_s.dont_frag)
    {
        dont_frag = TRUE;
    }
    else
    {
        dont_frag = ds_l3_edit_tunnel_v4->dont_frag;
    }

    if (ds_l3_edit_tunnel_v4->inner_header_valid && (2 == ds_l3_edit_tunnel_v4->inner_header_type)
        && ((1 == (ds_l3_edit_tunnel_v4->gre_flags & 0x3))  /* means udpTunnelType */
             || (2 == (ds_l3_edit_tunnel_v4->gre_flags & 0x3))))
    {
        udp_src_port = epe_pkt_proc_ctl.capwap_udp_port;
    }
    else
    {
        udp_src_port = (ds_l3_edit_tunnel_v4->gre_protocol15_14 << 14)
                        | ds_l3_edit_tunnel_v4->gre_protocol13_0;  /* means udpSrcPort */
    }

    /* tunnel MTU check */
    if (ds_l3_edit_tunnel_v4->mtu_check_en)
    {
        mtu_msg->tunnel_mtu_check = TRUE;
        mtu_msg->tunnel_mtu_size = ((ds_l3_edit_tunnel_v4->ipv4_sa_index) >> 16) & 0x3FFF; /* means mtuSize */
    }

    gre_key = ds_l3_edit_tunnel_v4->mtu_check_en ? ds_l3_edit_tunnel_v4->gre_key
                  : ((ds_l3_edit_tunnel_v4->ipv4_sa_index & 0xFFFF0000)     /* means greKey[31:16] */
                      | ds_l3_edit_tunnel_v4->gre_key);                   /* means greKey[15:0] */

    capwap_wlan_id_bitmap_valid = FALSE;

    if (ds_l3_edit_tunnel_v4->inner_header_valid && (2 == ds_l3_edit_tunnel_v4->inner_header_type))/* UDP tunnel */
    {
        capwap_wlan_id_bitmap_valid = (1 == (ds_l3_edit_tunnel_v4->gre_flags & 0x3))  /* used as udp_tunnel_type [1:0] */
                    && pkt_info->mcast
                    && (((ds_l3_edit_tunnel_v4->gre_protocol15_14 << 14)
                    | ds_l3_edit_tunnel_v4->gre_protocol13_0) != 0);  /* used as capwap_wlan_id_bitmap */
        capwap_wlan_id_bitmap = ((ds_l3_edit_tunnel_v4->gre_protocol15_14 << 14)
                    | ds_l3_edit_tunnel_v4->gre_protocol13_0);    /* used as capwap_wlan_id_bitmap */
        udp_tunnel_flags = ds_l3_edit_tunnel_v4->ip_protocol_type ;   /* used as udp_tunnel_flags */
        capwap_flags = (udp_tunnel_flags << 2)& 0x3FF;

        /* capwapFlags[9] : F,   capwapFlags[8] : L  */
        /* capwapFlags[7] : W,   capwapFlags[7] : M  */
        if ((1 == (ds_l3_edit_tunnel_v4->gre_flags & 0x3)) /* used as udp_tunnel_type */
                    && IS_BIT_SET(capwap_flags, 6))        /* used as udp_tunnel_flags */
        {
            /* AC2WTP with radio MAC */
            udp_tunnel_type_header[1] = (pkt_info->mac_31_to_0 & 0xFFFFFF) << 8;
            udp_tunnel_type_header[2] = (0x6 << 24)
                                        | (pkt_info->mac_47_to_32 << 8)
                                        | ((pkt_info->mac_31_to_0 >> 24) & 0xFF);
            udp_tunnel_type_header[3] = 0;
            udp_tunnel_type_header[4] = (4 << 19)
                                        | (((ds_l3_edit_tunnel_v4->gre_flags >> 2) & 0x3) << 17)/* used as rid[4:3]*/
                                        | (((ds_l3_edit_tunnel_v4->gre_version >> 1) & 0x7) << 14)/* used as rid[2:0]*/
                                        | (ds_l3_edit_tunnel_v4->capwap_wbid << 9)
                                        | (((capwap_flags >> 8)& 0x3)<< 6)
                                        | ((capwap_wlan_id_bitmap_valid)<< 5)
                                        | (((capwap_flags >> 6)& 0x1)<< 4)
                                        | ((capwap_flags >> 3)& 0x7);
            if (capwap_wlan_id_bitmap_valid)
            {
                udp_tunnel_type_header[4] = (udp_tunnel_type_header[4] & 0xFF07FFFF) | (5 << 19);
                udp_tunnel_type_header[0] = capwap_wlan_id_bitmap << 16;
                capwap_header_length = 3;   /* 20 */
            }
            else
            {
                capwap_header_length = 2;   /* 16 */
            }
        }
        else if ((1 == (ds_l3_edit_tunnel_v4->gre_flags & 0x3))      /* used as udp_tunnel_type */
                    && !IS_BIT_SET(capwap_flags, 6))       /* used as udp_tunnel_flags */
        {
            /* AC2WTP without radio MAC */
            udp_tunnel_type_header[3] = 0;
            udp_tunnel_type_header[4] = (2 << 19)
                                        | (((ds_l3_edit_tunnel_v4->gre_flags >> 2) & 0x3) << 17)/* used as rid[4:3] */
                                        | (((ds_l3_edit_tunnel_v4->gre_version >> 1) & 0x7) << 14)/* used as rid[2:0] */
                                        | (ds_l3_edit_tunnel_v4->capwap_wbid  << 9)
                                        | (((capwap_flags >> 8)& 0x3)<< 6)
                                        | ((capwap_wlan_id_bitmap_valid)<< 5)
                                        | (((capwap_flags >> 6)& 0x1)<< 4)
                                        | ((capwap_flags >> 3)& 0x7);
            if (capwap_wlan_id_bitmap_valid)
            {
                udp_tunnel_type_header[4] = (udp_tunnel_type_header[4] & 0xFF07FFFF) | (3 << 19);
                udp_tunnel_type_header[2] = capwap_wlan_id_bitmap << 16;
                capwap_header_length = 1;   /* 12 */
            }
            else
            {
                capwap_header_length = 0;   /* 8 */
            }
        }
        else if (2 == (ds_l3_edit_tunnel_v4->gre_flags & 0x3))  /* used as udp_tunnel_type[1:0] */
        {
            /* AC2AC */
            roaming_state = (FA == pkt_info->roaming_state) ? FA: HA; /* FA:2 HA:1 */

            /* For SA FA tunnel 2 HA, For DA HA tunnel 2 FA */
            switch(epe_pkt_proc_ctl.capwap_roaming_state_bits)
            {
                case 0:
                    capwap_flags = (ds_l3_edit_tunnel_v4->ip_protocol_type & 0xF)   /* used as udp_tunnel_type[3:0] */
                        | ((roaming_state & 0x3) << 4)
                        | ((ds_l3_edit_tunnel_v4->ip_protocol_type & 0xF0) << 2);   /* used as udp_tunnel_type[7:4] */
                    break;

                case 1:
                    capwap_flags = (ds_l3_edit_tunnel_v4->ip_protocol_type & 0x7)   /* used as udp_tunnel_type[2:0] */
                        | ((roaming_state & 0x3) << 3)
                        | ((ds_l3_edit_tunnel_v4->ip_protocol_type & 0xF8) << 2);   /* used as udp_tunnel_type[7:3] */
                    break;

                case 2:
                    capwap_flags = (ds_l3_edit_tunnel_v4->ip_protocol_type & 0x1)   /* used as udp_tunnel_type[0:0] */
                        | ((roaming_state & 0x3) << 1)
                        | ((ds_l3_edit_tunnel_v4->ip_protocol_type & 0xFE) << 2);   /* used as udp_tunnel_type[7:1] */
                    break;

                case 3:
                    capwap_flags = (roaming_state & 0x3)
                        | ((ds_l3_edit_tunnel_v4->ip_protocol_type & 0xFF) << 2);   /* used as udp_tunnel_type[7:0] */
                    break;

                default:
                    break;

            }

            udp_tunnel_type_header[4] = (2 << 19)
                                        | (((ds_l3_edit_tunnel_v4->gre_flags >> 2) & 0x3) << 17)/* used as rid[4:3] */
                                        | (((ds_l3_edit_tunnel_v4->gre_version >> 1) & 0x7) << 14)/* used as rid[2:0] */
                                        | (ds_l3_edit_tunnel_v4->capwap_wbid << 9)
                                        | (((capwap_flags >> 6)& 0xF)<< 4)
                                        | ((capwap_flags >> 3)& 0x7);
            udp_tunnel_type_header[3] = capwap_flags & 0x7;

            capwap_header_length = 0;/* 8 */

        }
        else
        {
            capwap_header_length = 4;/* 0 */
        }

    }

    /* NEW_IP_HEADER */
    pkt_info->l3_header[0] = 0x45;
    pkt_info->l3_header[1] = (new_dscp & 0x3F) << 2;
    pkt_info->l3_header[2] = (new_total_len >> 8) & 0x3F;
    pkt_info->l3_header[3] = new_total_len & 0xFF;

    pkt_info->l3_header[4] = (new_ip_identification >> 8) & 0xFF;
    pkt_info->l3_header[5] = new_ip_identification & 0xFF;
    pkt_info->l3_header[6] = dont_frag << 6;
    pkt_info->l3_header[7] = 0;

    pkt_info->l3_header[8] = new_ttl;
    pkt_info->l3_header[9] = new_protocol;
    pkt_info->l3_header[10] = 0; /* clear IPcheckSum */
    pkt_info->l3_header[11] = 0;

    pkt_info->l3_header[12] = (new_ip_sa >> 24) & 0xFF;
    pkt_info->l3_header[13] = (new_ip_sa >> 16) & 0xFF;
    pkt_info->l3_header[14] = (new_ip_sa >> 8) & 0xFF;
    pkt_info->l3_header[15] = new_ip_sa & 0xFF;

    pkt_info->l3_header[16] = (new_ip_da >> 24) & 0xFF;
    pkt_info->l3_header[17] = (new_ip_da >> 16) & 0xFF;
    pkt_info->l3_header[18] = (new_ip_da >> 8) & 0xFF;
    pkt_info->l3_header[19] = new_ip_da & 0xFF;

    if (ds_l3_edit_tunnel_v4->inner_header_valid)    /* Generate newIpCheckSum based on new ip header */
    {
        switch (ds_l3_edit_tunnel_v4->inner_header_type)
        {
            case 0:     /* GRE without key field, 4 byte GRE header */
                pkt_info->l3_new_header_len = 24;

                /* l3NewHeader = {8'h45, newDscp[5:0], 2'b00, 2'b00, newTotalLength[13:0], newIpIdentification[15:0],
                                  1'b0, dontFrag, 14'd0, newTtl[7:0], newProtocol[7:0], newIpChecksum[15:0],
                                  newIpSa[31:0], newIpDa[31:0], 2'b00, DsL3EditTunnelV4.greFlags[1:0], 9'd0, 2'b00,
                                  DsL3EditTunnelV4.greVersion[0], DsL3EditTunnelV4.greProtocol[15:0]} */
                pkt_info->l3_header[20] = (ds_l3_edit_tunnel_v4->gre_flags & 0x3) << 4;
                pkt_info->l3_header[21] = IS_BIT_SET(ds_l3_edit_tunnel_v4->gre_version, 0);
                pkt_info->l3_header[22] = (ds_l3_edit_tunnel_v4->gre_protocol15_14 << 6)
                                            | ((ds_l3_edit_tunnel_v4->gre_protocol13_0 >> 8) & 0x3F);
                pkt_info->l3_header[23] = ds_l3_edit_tunnel_v4->gre_protocol13_0 & 0xFF;
                break;

            case 1:
                pkt_info->l3_new_header_len = 28;

                /* l3NewHeader = {8'h45, newDscp[5:0], 2'b00, 2'b00, newTotalLength[13:0], newIpIdentification[15:0],
                                  1'b0, dontFrag, 14'd0, newTtl[7:0], newProtocol[7:0], newIpChecksum[15:0],
                                  newIpSa[31:0], newIpDa[31:0], 2'b00, DsL3EditTunnelV4.greFlags[1:0], 9'd0, 2'b00,
                                  DsL3EditTunnelV4.greVersion[0], DsL3EditTunnelV4.greProtocol[15:0], greKey[31:0]} */
                pkt_info->l3_header[20] =  (ds_l3_edit_tunnel_v4->gre_flags & 0x3) << 4;
                pkt_info->l3_header[21] = IS_BIT_SET(ds_l3_edit_tunnel_v4->gre_version, 0);
                pkt_info->l3_header[22] = (ds_l3_edit_tunnel_v4->gre_protocol15_14 << 6)
                                          | ((ds_l3_edit_tunnel_v4->gre_protocol13_0 >> 8) & 0x3F);
                pkt_info->l3_header[23] = ds_l3_edit_tunnel_v4->gre_protocol13_0 & 0xFF;

                pkt_info->l3_header[24] = (gre_key >> 24) & 0xFF;
                pkt_info->l3_header[25] = (gre_key >> 16) & 0xFF;
                pkt_info->l3_header[26] = (gre_key >> 8) & 0xFF;
                pkt_info->l3_header[27] = gre_key & 0xFF;
                break;

            case 2:     /* 8 byte UDP header */
                /* l3NewHeader[223:0] = {8'h45, newDscp[5:0], 2'b00, 2'b00, newTotalLength[13:0], newIpIdentification[15:0],
                                  1'b0, dontFrag, 14'd0, newTtl[7:0], newProtocol[7:0], newIpChecksum[15:0],
                                  newIpSa[31:0], newIpDa[31:0], udpSrcPort[15:0], DsL3EditTunnelV4.udpDestPort[15:0],
                                  udpLength[15:0], 16'd0} */
                udp_header[0] = (udp_src_port >> 8)& 0xFF;
                udp_header[1] = udp_src_port& 0xFF;
                udp_header[2] = (ds_l3_edit_tunnel_v4->gre_key >> 8) & 0xFF;/* means udpDestPort */
                udp_header[3] = ds_l3_edit_tunnel_v4->gre_key & 0xFF;

                udp_header[4] = (udp_length >> 8) & 0x3F;
                udp_header[5] = udp_length & 0xFF;
                udp_header[6] = 0;
                udp_header[7] = 0;

                switch (capwap_header_length & 0x7)
                {
                    case 0:
                        pkt_info->l3_new_header_len = 28 + 8;

                        /* l3NewHeader = {udpHeader[223:0], udpTunnelTypeHeader[159:96]} */
                        for (index = 20; index < 28; index ++)
                        {
                            pkt_info->l3_header[index] = udp_header[index-20];
                        }
                        pkt_info->l3_header[28+0] = (udp_tunnel_type_header[4] >> 24)& 0xFF;
                        pkt_info->l3_header[28+1] = (udp_tunnel_type_header[4] >> 16)& 0xFF;
                        pkt_info->l3_header[28+2] = (udp_tunnel_type_header[4] >> 8)& 0xFF;
                        pkt_info->l3_header[28+3] = udp_tunnel_type_header[4] & 0xFF;
                        pkt_info->l3_header[28+4] = (udp_tunnel_type_header[3] >> 24)& 0xFF;
                        pkt_info->l3_header[28+5] = (udp_tunnel_type_header[3] >> 16)& 0xFF;
                        pkt_info->l3_header[28+6] = (udp_tunnel_type_header[3] >> 8)& 0xFF;
                        pkt_info->l3_header[28+7] = udp_tunnel_type_header[3] & 0xFF;
                        break;

                     case 1:
                        pkt_info->l3_new_header_len = 28 + 12;

                        /* l3NewHeader = {udpHeader[223:0], udpTunnelTypeHeader[159:64]} */
                        for (index = 20; index < 28; index ++)
                        {
                            pkt_info->l3_header[index] = udp_header[index-20];
                        }
                        pkt_info->l3_header[28+0] = (udp_tunnel_type_header[4] >> 24)& 0xFF;
                        pkt_info->l3_header[28+1] = (udp_tunnel_type_header[4] >> 16)& 0xFF;
                        pkt_info->l3_header[28+2] = (udp_tunnel_type_header[4] >> 8)& 0xFF;
                        pkt_info->l3_header[28+3] = udp_tunnel_type_header[4] & 0xFF;
                        pkt_info->l3_header[28+4] = (udp_tunnel_type_header[3] >> 24)& 0xFF;
                        pkt_info->l3_header[28+5] = (udp_tunnel_type_header[3] >> 16)& 0xFF;
                        pkt_info->l3_header[28+6] = (udp_tunnel_type_header[3] >> 8)& 0xFF;
                        pkt_info->l3_header[28+7] = udp_tunnel_type_header[3] & 0xFF;
                        pkt_info->l3_header[28+8] = (udp_tunnel_type_header[2] >> 24)& 0xFF;
                        pkt_info->l3_header[28+9] = (udp_tunnel_type_header[2] >> 16)& 0xFF;
                        pkt_info->l3_header[28+10] = (udp_tunnel_type_header[2] >> 8)& 0xFF;
                        pkt_info->l3_header[28+11] =  udp_tunnel_type_header[2] & 0xFF;
                        break;

                     case 2:
                        pkt_info->l3_new_header_len = 28 + 16;

                        /* l3NewHeader = {udpHeader[223:0], udpTunnelTypeHeader[159:32]} */
                        for (index = 20; index < 28; index ++)
                        {
                            pkt_info->l3_header[index] = udp_header[index-20];
                        }
                        pkt_info->l3_header[28+0] = (udp_tunnel_type_header[4] >> 24)& 0xFF;
                        pkt_info->l3_header[28+1] = (udp_tunnel_type_header[4] >> 16)& 0xFF;
                        pkt_info->l3_header[28+2] = (udp_tunnel_type_header[4] >> 8)& 0xFF;
                        pkt_info->l3_header[28+3] = udp_tunnel_type_header[4] & 0xFF;
                        pkt_info->l3_header[28+4] = (udp_tunnel_type_header[3] >> 24)& 0xFF;
                        pkt_info->l3_header[28+5] = (udp_tunnel_type_header[3] >> 16)& 0xFF;
                        pkt_info->l3_header[28+6] = (udp_tunnel_type_header[3] >> 8)& 0xFF;
                        pkt_info->l3_header[28+7] = udp_tunnel_type_header[3] & 0xFF;
                        pkt_info->l3_header[28+8] = (udp_tunnel_type_header[2] >> 24)& 0xFF;
                        pkt_info->l3_header[28+9] = (udp_tunnel_type_header[2] >> 16)& 0xFF;
                        pkt_info->l3_header[28+10] = (udp_tunnel_type_header[2] >> 8)& 0xFF;
                        pkt_info->l3_header[28+11] =  udp_tunnel_type_header[2] & 0xFF;
                        pkt_info->l3_header[28+12] = (udp_tunnel_type_header[1]>> 24)& 0xFF;
                        pkt_info->l3_header[28+13] = (udp_tunnel_type_header[1] >> 16)& 0xFF;
                        pkt_info->l3_header[28+14] = (udp_tunnel_type_header[1] >> 8)& 0xFF;
                        pkt_info->l3_header[28+15] = udp_tunnel_type_header[1] & 0xFF;
                        break;

                     case 3:
                        pkt_info->l3_new_header_len = 28 + 20;

                        /* l3NewHeader = {udpHeader[223:0], udpTunnelTypeHeader[159:0]} */
                        for (index = 20; index < 28; index ++)
                        {
                            pkt_info->l3_header[index] = udp_header[index-20];
                        }
                        pkt_info->l3_header[28+0] = (udp_tunnel_type_header[4] >> 24)& 0xFF;
                        pkt_info->l3_header[28+1] = (udp_tunnel_type_header[4] >> 16)& 0xFF;
                        pkt_info->l3_header[28+2] = (udp_tunnel_type_header[4] >> 8)& 0xFF;
                        pkt_info->l3_header[28+3] = udp_tunnel_type_header[4] & 0xFF;
                        pkt_info->l3_header[28+4] = (udp_tunnel_type_header[3] >> 24)& 0xFF;
                        pkt_info->l3_header[28+5] = (udp_tunnel_type_header[3] >> 16)& 0xFF;
                        pkt_info->l3_header[28+6] = (udp_tunnel_type_header[3] >> 8)& 0xFF;
                        pkt_info->l3_header[28+7] = udp_tunnel_type_header[3] & 0xFF;
                        pkt_info->l3_header[28+8] = (udp_tunnel_type_header[2] >> 24)& 0xFF;
                        pkt_info->l3_header[28+9] = (udp_tunnel_type_header[2] >> 16)& 0xFF;
                        pkt_info->l3_header[28+10] = (udp_tunnel_type_header[2] >> 8)& 0xFF;
                        pkt_info->l3_header[28+11] =  udp_tunnel_type_header[2] & 0xFF;
                        pkt_info->l3_header[28+12] = (udp_tunnel_type_header[1]>> 24)& 0xFF;
                        pkt_info->l3_header[28+13] = (udp_tunnel_type_header[1] >> 16)& 0xFF;
                        pkt_info->l3_header[28+14] = (udp_tunnel_type_header[1] >> 8)& 0xFF;
                        pkt_info->l3_header[28+15] = udp_tunnel_type_header[1] & 0xFF;
                        pkt_info->l3_header[28+16] = (udp_tunnel_type_header[0] >> 24)& 0xFF;
                        pkt_info->l3_header[28+17] = (udp_tunnel_type_header[0] >> 16)& 0xFF;
                        pkt_info->l3_header[28+18] = (udp_tunnel_type_header[0] >> 8)& 0xFF;
                        pkt_info->l3_header[28+19] = udp_tunnel_type_header[0] & 0xFF;
                        break;

                    default:
                        pkt_info->l3_new_header_len = 28;

                        /* l3NewHeader = udpHeader[223:0] */
                        for (index = 20; index < 28; index ++)
                        {
                            pkt_info->l3_header[index] = udp_header[index-20];
                        }
                        break;
                }
                break;

            case 3:
                pkt_info->l3_new_header_len = 32;/* UDP header with MIP */
                /* l3NewHeader = {8'h45, newDscp[5:0], 2'b00, 2'b00, newTotalLength[13:0], newIpIdentification[15:0],
                                  1'b0, dontFrag, 14'd0, newTtl[7:0], newProtocol[7:0], newIpChecksum[15:0],
                                  newIpSa[31:0], newIpDa[31:0], DsL3EditTunnelV4.udpSrcPort[15:0], DsL3EditTunnelV4.udpDestPort[15:0],
                                  udpLength[15:0], 16'd0, 8'd4, DsL3EditTunnelV4.mipType[7:0], 16'd0} */
                pkt_info->l3_header[20] = ds_l3_edit_tunnel_v4->gre_protocol15_14
                                            | ((ds_l3_edit_tunnel_v4->gre_protocol13_0 >> 8) & 0xFF); /* means udpSrcPort[15:8] */
                pkt_info->l3_header[21] = ds_l3_edit_tunnel_v4->gre_protocol13_0 & 0xFF;        /* means udpSrcPort[7:0] */
                pkt_info->l3_header[22] = (ds_l3_edit_tunnel_v4->gre_key >> 8) & 0xFF;      /* means udpDstPort[15:8] */
                pkt_info->l3_header[23] = ds_l3_edit_tunnel_v4->gre_key & 0xFF;             /* means udpDstPort[7:0] */

                pkt_info->l3_header[24] = (udp_length >> 8) & 0x3F;
                pkt_info->l3_header[25] = udp_length & 0xFF;
                pkt_info->l3_header[26] = 0;
                pkt_info->l3_header[27] = 0;
                pkt_info->l3_header[28] = 4;
                pkt_info->l3_header[29] = (ds_l3_edit_tunnel_v4->gre_flags << 4)           /* means mipType[7:4] */
                                        | ds_l3_edit_tunnel_v4->gre_version ;              /* means mipType[3:0] */
                pkt_info->l3_header[30] = 0;
                pkt_info->l3_header[31] = 0;
                break;

            default:
                break;
        }
    }
    else   /* Add IP header only */
    {
        /* l3NewHeader = {8'h45, newDscp[5:0], 2'b00, 2'b00, newTotalLength[13:0], newIpIdentification[15:0],
                          1'b0, dontFrag, 14'd0, newTtl[7:0], newProtocol[7:0], newIpChecksum[15:0],
                          newIpSa[31:0], newIpDa[31:0]} */
        pkt_info->l3_new_header_len = 20;
    }

    /* Note l3NewHeader.newIpChecksum is calculated according to the IP header fields */
    new_check_sum = ip_chksum((uint16*)pkt_info->l3_header, 20, 0);
    pkt_info->l3_header[10] = (new_check_sum >> 8) & 0xFF;
    pkt_info->l3_header[11] = new_check_sum & 0xFF;

    /* REPLACE_PARSER_RESULT */
    pkt_info->packet_ttl = new_ttl;             /* packet TTL has been updated */
    pkt_info->packet_type = PKT_TYPE_IPV4;

    /* parser_result->l4_s.layer4_user_type = ; */
    mtu_msg->is_tcp_update = FALSE;

    if (ds_l3_edit_tunnel_v4->inner_header_valid && IS_BIT_SET(ds_l3_edit_tunnel_v4->inner_header_type, 1))
    {
        mtu_msg->is_udp_update = TRUE;
    }
    else
    {
        mtu_msg->is_udp_update = FALSE;
    }

    mtu_msg->layer3_type_update = L3_TYPE_IPV4;   /* overwrite layer3Type */
    mtu_msg->ip_options_update = 0;          /* no option */
    mtu_msg->ip_header_error_update = 0;     /* no header error */
    mtu_msg->ip_da_31_0_update = new_ip_da;
    mtu_msg->ip_checksum_update = new_check_sum;
    mtu_msg->ip_sa_31_0_update = new_ip_sa;
    mtu_msg->layer4_info_mapped_update = new_protocol; /* No other map, only protocol number*/
    mtu_msg->frag_info_update = 0;
    mtu_msg->tos_update = (mtu_msg->tos_update & 0x3) | ((new_dscp & 0x3F) << 2);

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_layer3_editing_nat
 * Purpose:   perform layer 3 nat editing operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *            ds_l3_edit_nat8_w -- pointer to ds_l3_edit_nat8_w
 *            mtu_msg -- pointer to cm_epe_mtu_msg_t
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *            mtu_msg -- pointer to cm_epe_mtu_msg_t
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_layer3_editing_nat(epe_in_pkt_t* ipkt,
                    ds_l3_edit_nat8_w_t* ds_l3_edit_nat8_w, cm_epe_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    ds_ipv6_nat_prefix_t ds_ipv6_nat_prefix;
    epe_pkt_proc_ctl_t epe_pkt_proc_ctl;
    epe_hdr_proc_frag_ctl_t epe_hdr_proc_frag_ctl;

    uint32 cmd = 0;
    uint32 old_ip_da = 0;
    uint32 new_ip_sa[4] = {0}, new_ip_da[4] = {0};
    uint32 ip_sa_prefix[4] = {0}, ip_da_prefix[4] = {0};
    uint16 new_ip_check_sum = 0;
    uint16 old_l4_dest_port = 0;
    uint16 new_l4_dest_port = 0;
    uint16 new_total_length = 0;
    uint16 source_psid = 0;
    uint16 frag_offset = 0, frag_identification = 0;
    uint8 new_l4_dest_port_valid = FALSE;
    uint8 is_new_ipv4 = FALSE, ip_multicast_address = FALSE;
    uint8 ip_sa_prefix_length = 0, ip_da_prefix_length = 0;
    uint8 dont_frag = 0, more_frag = 0;
    uint8 frag_next_header = 0;
    uint8 source_ratio = 0;
    uint8 new_ip_da_valid = FALSE;
    uint8 new_ttl = 0, new_dscp = 0, new_protocol = 0;
    uint8 is_icmp = FALSE;
    uint8 is_ipv4_icmp_err_msg = FALSE, is_ipv6_icmp_err_msg = FALSE;
    uint8 is_ipv4 = FALSE, is_ipv6 = FALSE;
    uint8 source_divi_en = FALSE;
    uint8 ipv4_src_embeded_mode = 0;
    uint16 packet_length_adjust = 0;
    uint32 ip_da[4] = {0};
    uint32 ip_sa[4] = {0};

    sal_memset(&epe_pkt_proc_ctl, 0, sizeof(epe_pkt_proc_ctl));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_ctl));

    sal_memset(&epe_hdr_proc_frag_ctl, 0, sizeof(epe_hdr_proc_frag_ctl));
    cmd = DRV_IOR(EpeHdrProcFragCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_hdr_proc_frag_ctl));

    /* DISCARD_SWITCH */
    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* ICMP_ERROR_CHECK */
    if (((DS_TYPE_DISCARD == ds_l3_edit_nat8_w->ds_type)
        && ds_l3_edit_nat8_w->replace_ip_da
        && (pkt_info->rx_oam_type == OAM_NONE))
        || ((DS_TYPE_DISCARD == ds_l3_edit_nat8_w->ds_type)
        && !ds_l3_edit_nat8_w->replace_ip_da))
    {
        pkt_info->discard = TRUE;
        pkt_info->discard_type = EPE_DISCARD_DS_L3_EDIT_NAT_DATA_VIOLATE;
        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Layer3 edit discardPacket!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }

    is_ipv4 = (L3_TYPE_IPV4 == parser_result->layer3_type);
    is_ipv6 = (L3_TYPE_IPV6 == parser_result->layer3_type);
    is_icmp = (L4_TYPE_ICMP == parser_result->layer4_type);
    is_ipv4_icmp_err_msg = is_icmp && ((3 == (parser_result->l4_s.l4_src_port.l4_source_port >> 8))
                                        || (4 == (parser_result->l4_s.l4_src_port.l4_source_port >> 8))
                                        || (11 == (parser_result->l4_s.l4_src_port.l4_source_port >> 8))
                                        || (12 == (parser_result->l4_s.l4_src_port.l4_source_port >> 8)));

    is_ipv6_icmp_err_msg = is_icmp && (!IS_BIT_SET(parser_result->l4_s.l4_src_port.l4_source_port, 15));

    if (epe_pkt_proc_ctl.icmp_err_msg_check_en
        && ((is_ipv4 && is_ipv4_icmp_err_msg) || (is_ipv6 && is_ipv6_icmp_err_msg)))
    {
        if (!pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 7;
        }

        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = EPE_DISCARD_NAT_PT_ICMP_ERR;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE NAT-PT ICMP ERROR discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* REPLACE */
    /* destination port */
    old_l4_dest_port = parser_result->l4_s.l4_dst_port.l4_dest_port;
    new_l4_dest_port_valid = ds_l3_edit_nat8_w->replace_l4_dest_port;
    new_l4_dest_port = new_l4_dest_port_valid ? ds_l3_edit_nat8_w->l4_dest_port : old_l4_dest_port;

    is_new_ipv4 = (L3_TYPE_IPV6 == parser_result->layer3_type);

    if ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.pt_enable)    /* protocol translation between ipv4 and ipv6 */
    {
        pkt_info->strip_offset = parser_result->l3_s.layer4_offset & 0x7F;

        packet_length_adjust = func_packet_length_adjust_subtract(ipkt, (pkt_info->strip_offset - parser_result->l2_s.layer3_offset));
        pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
        pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;

        pkt_info->ptp_offset -= (pkt_info->strip_offset - parser_result->l2_s.layer3_offset);

        switch (pkt_info->share_fields_u.nat.ip_sa_mode)
        {
            case 0: /* pkt_info.new_ip_sa[39:32] is ip prefix index,pkt_info->new_ip_sa[31:0] useless */
                sal_memset(&ds_ipv6_nat_prefix, 0, sizeof(ds_ipv6_nat_prefix_t));
                cmd = DRV_IOR(DsIpv6NatPrefix_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->share_fields_u.nat.new_ip_sa_39_32, cmd, &ds_ipv6_nat_prefix));
                ip_sa_prefix_length = ds_ipv6_nat_prefix.prefixe_length;
                ip_sa_prefix[0] = 0; /* [31:0] */
                ip_sa_prefix[1] = ds_ipv6_nat_prefix.prefix63_32;
                ip_sa_prefix[2] = ds_ipv6_nat_prefix.prefix95_64;
                ip_sa_prefix[3] = ds_ipv6_nat_prefix.prefix127_96;
                break;
            case 1: /* pkt_info.new_ip_sa[39:32] is ip prefix index and pkt_info->new_ip_sa[31:0] is new ip sa */
                sal_memset(&ds_ipv6_nat_prefix, 0, sizeof(ds_ipv6_nat_prefix_t));
                cmd = DRV_IOR(DsIpv6NatPrefix_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->share_fields_u.nat.new_ip_sa_39_32, cmd, &ds_ipv6_nat_prefix));
                ip_sa_prefix_length = ds_ipv6_nat_prefix.prefixe_length;
                ip_sa_prefix[0] = 0;
                ip_sa_prefix[1] = ds_ipv6_nat_prefix.prefix63_32;
                ip_sa_prefix[2] = ds_ipv6_nat_prefix.prefix95_64;
                ip_sa_prefix[3] = ds_ipv6_nat_prefix.prefix127_96;
                break;
            case 2: /* pkt_info.new_ip_sa[39:0] is ip prefix */
                ip_sa_prefix_length = pkt_info->share_fields_u.nat.ip_sa_prefix_length;
                ip_sa_prefix[0] = 0;/* [31:0] */
                ip_sa_prefix[1] = 0;/* [63:32] */
                /* ??? there maybe bug exist,Jiping is thinking.... */
                ip_sa_prefix[2] = ((pkt_info->share_fields_u.nat.new_ip_sa_31_0 & 0xFF) << 24); /* newIpSa[7:0], 24'd0 */
                ip_sa_prefix[3] = ((pkt_info->share_fields_u.nat.new_ip_sa_39_32 << 24) | (pkt_info->share_fields_u.nat.new_ip_sa_31_0 >> 8));
                break;
            default:/* pkt_info.new_ip_sa[31:0] is new ip sa */
                ip_sa_prefix_length = 7;
                ip_sa_prefix[0] = pkt_info->share_fields_u.nat.new_ip_sa_31_0;
                ip_sa_prefix[1] = 0;
                ip_sa_prefix[2] = 0;
                ip_sa_prefix[3] = 0;
                break;
        }

        if (!pkt_info->share_fields_u.nat.src_address_mode)
        {
            source_psid = pkt_info->share_fields_u.nat.new_ip_sa_31_0 & 0xFFFF;
            source_ratio = (pkt_info->share_fields_u.nat.new_ip_sa_31_0 >> 16) & 0xF;
            source_divi_en = IS_BIT_SET(pkt_info->share_fields_u.nat.new_ip_sa_31_0, 20);
        }

        ip_da_prefix[0] = (ds_l3_edit_nat8_w->ip_da31_30 << 30)
                            | ds_l3_edit_nat8_w->ip_da29_0;
        ip_da_prefix[1] = (ds_l3_edit_nat8_w->ip_da39_32
                            | (ds_l3_edit_nat8_w->ip_da47_40 << 8)
                            | (ds_l3_edit_nat8_w->ip_da48 << 16)
                            | (ds_l3_edit_nat8_w->ip_da63_49 << 17));
        ip_da_prefix[2] = ds_l3_edit_nat8_w->ip_da95_64;
        ip_da_prefix[3] = (ds_l3_edit_nat8_w->ip_da127_124 << 28)
                            | (ds_l3_edit_nat8_w->ip_da123_120 << 24)
                            | ds_l3_edit_nat8_w->ip_da119_96;

        ip_da_prefix_length = (ds_l3_edit_nat8_w->ip_da_prefix_length2_2 << 2)
                            | ds_l3_edit_nat8_w->ip_da_prefix_length1_0;
        if (is_new_ipv4)/* IPv6 to IPv4 */
        {
            ip_multicast_address = (0xFF == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24));

            ip_sa[0] = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
            ip_sa[1] = parser_result->l3_s.ip_sa.ipv6.ipsa_63_32;
            ip_sa[2] = parser_result->l3_s.ip_sa.ipv6.ipsa_95_64;
            ip_sa[3] = parser_result->l3_s.ip_sa.ipv6.ipsa_127_96;

            ip_da[0] = parser_result->l3_s.ip_da.ipv6.ipda_31_0;
            ip_da[1] = parser_result->l3_s.ip_da.ipv6.ipda_63_32;
            ip_da[2] = parser_result->l3_s.ip_da.ipv6.ipda_95_64;
            ip_da[3] = parser_result->l3_s.ip_da.ipv6.ipda_127_96;

            /* IPv4 SA */
            if (pkt_info->share_fields_u.nat.src_address_mode)/* not same as destination address format */
            {
                if (IS_BIT_SET(pkt_info->share_fields_u.nat.ip_sa_mode, 0))/* use statefull ip address */
                {
                    new_ip_sa[0] = pkt_info->share_fields_u.nat.new_ip_sa_31_0;
                }
                else
                {
                    ipv4_src_embeded_mode = pkt_info->share_fields_u.nat.ipv4_src_embeded_mode;
                    DRV_IF_ERROR_RETURN(_cm_func_get_ipv4_address(ipkt, ip_sa,
                                ipv4_src_embeded_mode, ip_sa_prefix_length, new_ip_sa));
                }
            }
            else    /* same as destination address format, only stateless IP address */
            {
                ipv4_src_embeded_mode = ds_l3_edit_nat8_w->ipv4_embeded_mode;
                DRV_IF_ERROR_RETURN(_cm_func_get_ipv4_address(ipkt, ip_sa,
                            ipv4_src_embeded_mode, (uint8)ip_da_prefix_length, new_ip_sa));
            }

            /* IPv4 DA */
            if (ds_l3_edit_nat8_w->replace_ip_da)
            {
                new_ip_da[0] = (ds_l3_edit_nat8_w->ip_da31_30 << 30)
                            | ds_l3_edit_nat8_w->ip_da29_0;
            }
            else if (ip_multicast_address
                && epe_pkt_proc_ctl.pt_multicast_address_en)/* only IVI multicast */
            {
                new_ip_da[0] = (0xE8 << 24) | (parser_result->l3_s.ip_da.ipv4.ipda & 0xFFFFFF);
            }
            else
            {
                ipv4_src_embeded_mode = ds_l3_edit_nat8_w->ipv4_embeded_mode;
                DRV_IF_ERROR_RETURN(_cm_func_get_ipv4_address(ipkt, ip_da,
                            ipv4_src_embeded_mode, (uint8)ip_da_prefix_length, new_ip_da));
            }
        }
        else    /* IPv4 to IPv6 */
        {
            ip_multicast_address = (0xE == ((parser_result->l3_s.ip_da.ipv4.ipda >> 28) & 0xF));

            /* IPv6 SA */
            if (pkt_info->share_fields_u.nat.src_address_mode)
            {
                if (IS_BIT_SET(pkt_info->share_fields_u.nat.ip_sa_mode, 0))/* use statefull IP address */
                {
                    DRV_IF_ERROR_RETURN(_cm_func_get_ipv6_address(IP_SA, pkt_info->share_fields_u.nat.new_ip_sa_31_0,
                          (uint8)pkt_info->share_fields_u.nat.ipv4_src_embeded_mode, ip_sa_prefix_length, ip_sa_prefix, new_ip_sa,
                          epe_pkt_proc_ctl.pt_zero_reserved_address));
                }
                else
                {
                    DRV_IF_ERROR_RETURN(_cm_func_get_ipv6_address(IP_SA, parser_result->l3_s.ip_sa.ipv4.ipsa,
                          (uint8)pkt_info->share_fields_u.nat.ipv4_src_embeded_mode, ip_sa_prefix_length, ip_sa_prefix, new_ip_sa,
                          epe_pkt_proc_ctl.pt_zero_reserved_address));
                }
            }
            else
            {
                DRV_IF_ERROR_RETURN(_cm_func_get_ipv6_address(IP_SA, parser_result->l3_s.ip_sa.ipv4.ipsa,
                      (uint8)ds_l3_edit_nat8_w->ipv4_embeded_mode, ip_da_prefix_length, ip_da_prefix, new_ip_sa,
                      epe_pkt_proc_ctl.pt_zero_reserved_address));
            }

            if (source_divi_en)
            {
                switch (ip_da_prefix_length & 0x7)
                {
                    case 0:    /* prefix length 32 */
                        if (pkt_info->share_fields_u.nat.ipv4_src_embeded_mode)
                        {
                            new_ip_sa[1] = (new_ip_sa[1] & 0xFF0000FF) | (source_psid << 8);
                        }
                        else
                        {
                            new_ip_sa[1] = (new_ip_sa[1] & 0x0000FFFF) | (source_psid << 16);
                        }
                        break;
                    case 1:    /* prefix length 40 */
                        if (pkt_info->share_fields_u.nat.ipv4_src_embeded_mode)
                        {
                            new_ip_sa[1] = (new_ip_sa[1] & 0xFFFF0000) | source_psid;
                        }
                        else
                        {
                            new_ip_sa[1] = (new_ip_sa[1] & 0xFF0000FF) | (source_psid << 8);
                        }
                        break;
                    case 2:    /* prefix length 48 */
                        if (pkt_info->share_fields_u.nat.ipv4_src_embeded_mode)
                        {
                            new_ip_sa[0] = (new_ip_sa[0] & 0x00FFFFFF) | ((source_psid & 0xFF) << 24);
                            new_ip_sa[1] = (new_ip_sa[1] & 0xFFFFFF00) | (source_psid >> 8);
                        }
                        else
                        {
                            new_ip_sa[1] = (new_ip_sa[1] & 0xFFFF0000) | source_psid;
                        }
                        break;
                    case 3:    /* prefix length 56 */
                        if (pkt_info->share_fields_u.nat.ipv4_src_embeded_mode)
                        {
                            new_ip_sa[0] = (new_ip_sa[0] & 0x0000FFFF) | (source_psid<<16);
                        }
                        else
                        {
                            new_ip_sa[0] = (new_ip_sa[0] & 0x00FFFFFF) | ((source_psid & 0xFF) << 24);
                            new_ip_sa[1] = (new_ip_sa[1] & 0xFFFFFF00) | (source_psid >> 8);
                        }
                        break;
                    default:   /* prefix length 64 */
                        if (pkt_info->share_fields_u.nat.ipv4_src_embeded_mode)
                        {
                            new_ip_sa[0] = (new_ip_sa[0] & 0xFF0000FF) | (source_psid << 8);
                        }
                        else
                        {
                            new_ip_sa[0] = (new_ip_sa[0] & 0x0000FFFF) | (source_psid << 16);
                        }
                        break;
                }

                new_ip_sa[0] = (new_ip_sa[0] & 0xFFFFFFF0) | source_ratio;
            }

            /* IPv6 DA */
            if (ds_l3_edit_nat8_w->replace_ip_da)
            {
                new_ip_da[0] = (ds_l3_edit_nat8_w->ip_da31_30 << 30)
                               | ds_l3_edit_nat8_w->ip_da29_0;
                new_ip_da[1] = ds_l3_edit_nat8_w->ip_da39_32
                               | (ds_l3_edit_nat8_w->ip_da47_40 << 8)
                               | (ds_l3_edit_nat8_w->ip_da48 << 16)
                               | (ds_l3_edit_nat8_w->ip_da63_49 << 17);
                new_ip_da[2] = ds_l3_edit_nat8_w->ip_da95_64;
                new_ip_da[3] = (ds_l3_edit_nat8_w->ip_da127_124 << 28)
                                    | (ds_l3_edit_nat8_w->ip_da123_120 << 24)
                                    | ds_l3_edit_nat8_w->ip_da119_96;
            }
            else if (ip_multicast_address && epe_pkt_proc_ctl.pt_multicast_address_en
                     && epe_pkt_proc_ctl.ivi_multicast_address)
            {
                new_ip_da[0] = (0xF0 << 24) | (parser_result->l3_s.ip_da.ipv4.ipda & 0xFFFFFF);
                new_ip_da[1] = 0;
                new_ip_da[2] = 0;
                new_ip_da[3] = (0xFF3E << 16) | 0;

            }
            else if (ip_multicast_address && epe_pkt_proc_ctl.pt_multicast_address_en)
            {
                new_ip_da[0] = ((ip_da_prefix[0] & 0xFF) << 24) | (parser_result->l3_s.ip_da.ipv4.ipda & 0xFFFFFF);
                new_ip_da[1] = (ip_da_prefix[0] >> 8) | ((ip_da_prefix[1] & 0xFF) << 24);
                new_ip_da[2] = (ip_da_prefix[1] >> 8) | ((ip_da_prefix[2] & 0xFF) << 24);
                new_ip_da[3] = (ip_da_prefix[2] >> 8) | ((ip_da_prefix[3] & 0xFF) << 24);
            }
            else
            {
                DRV_IF_ERROR_RETURN(_cm_func_get_ipv6_address(IP_SA, parser_result->l3_s.ip_da.ipv4.ipda,
                    (uint8)ds_l3_edit_nat8_w->ipv4_embeded_mode, ip_da_prefix_length, ip_da_prefix, new_ip_da,
                    epe_pkt_proc_ctl.pt_zero_reserved_address));

                /* PSID and Q editing all including in ipDaPrefix[127:0] */
            }
        }

        new_ttl = pkt_info->packet_ttl;
        new_protocol = parser_result->l3_s.layer3_header_protocol;

        if (pkt_info->replace_dscp)
        {
            new_dscp = pkt_info->new_dscp;
        }
        else
        {
            new_dscp = (parser_result->l3_s.tos.ip_tos >> 2);
        }

        if (is_new_ipv4)
        {
            new_total_length = pkt_info->packet_length - (!pkt_info->non_crc ? 4 : 0) + 20;
            if (!pkt_info->packet_length_adjust_type)
            {
                new_total_length += pkt_info->packet_length_adjust;
            }
            else
            {
                new_total_length -= pkt_info->packet_length_adjust;
            }

            more_frag = 0;
            frag_offset = 0;
            frag_identification = 0;
            if (epe_pkt_proc_ctl.ipv6_packet_length_check_en
                    && ((new_total_length - 20) <= 1280))
            {
                dont_frag = 0;
            }
            else
            {
                dont_frag = 1;
            }

            if (parser_result->l3_s.frag_info != 0)
            {
                dont_frag = 0;
                frag_identification = parser_result->l3_s.ip_identification;
                more_frag = parser_result->l3_s.more_frag;
                frag_offset = parser_result->l3_s.frag_offset;
            }
        }
        else
        {
            new_total_length = pkt_info->packet_length - (!pkt_info->non_crc ? 4 : 0);
            if (!pkt_info->packet_length_adjust_type)
            {
                new_total_length += pkt_info->packet_length_adjust;
            }
            else
            {
                new_total_length -= pkt_info->packet_length_adjust;
            }

            frag_identification = 0;
            if ((!parser_result->l3_s.dont_frag
                        && epe_pkt_proc_ctl.ipv6_alwayse_add_frag_header)
                        || (parser_result->l3_s.frag_info != 0))
            {
                new_protocol = 44;
                new_total_length += 8;
                frag_next_header = parser_result->l3_s.layer3_header_protocol;
                frag_offset = parser_result->l3_s.frag_offset;
                more_frag = parser_result->l3_s.more_frag;
                frag_identification = parser_result->l3_s.ip_identification;
            }
        }
    }
    else
    {
        old_ip_da = parser_result->l3_s.ip_da.ipv4.ipda;
        /* old_ip_check_sum = pkt_info->new_ip_check_sum; */
        /* old_l4_check_sum = parser_result->l4_s.layer4_check_sum; */
        new_ip_da_valid = ds_l3_edit_nat8_w->replace_ip_da;
        new_ip_da[0] = new_ip_da_valid ? ((ds_l3_edit_nat8_w->ip_da31_30 << 30)
                            | ds_l3_edit_nat8_w->ip_da29_0) : old_ip_da;
    }

    /* CHECKSUM */
    /* New Header */
    if ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.pt_enable)/* new header */
    {
        if (is_new_ipv4)
        {
            pkt_info->l3_new_header_len = 20;

            /* {8'h45, newDscp[5:0], 2'b00, 2'b00, newTotalLength[13:0], fragIdentification[15:0],
                1'b0, dontFrag, moreFrag, fragOffset[12:0], newTtl[7:0], newProtocol[7:0],
                newIpChecksum[15:0], newIpSa[31;0], newIpDa[31:0]} */
            pkt_info->l3_header[0] = 0x45;
            pkt_info->l3_header[1] = ((new_dscp & 0x3F) << 2)
                                        | (parser_result->l3_s.tos.ip_tos & 0x3);
            pkt_info->l3_header[2] = (new_total_length >> 8) & 0x3F;
            pkt_info->l3_header[3] = (new_total_length & 0xFF);
            pkt_info->l3_header[4] = frag_identification >> 8;
            pkt_info->l3_header[5] = frag_identification & 0xFF;
            pkt_info->l3_header[6] = (dont_frag << 6) | (more_frag << 5) | ((frag_offset >> 8) & 0x1F);
            pkt_info->l3_header[7] = frag_offset & 0xFF;
            pkt_info->l3_header[8] = new_ttl;
            pkt_info->l3_header[9] = new_protocol;
            pkt_info->l3_header[10] = 0; /* newIpCheckSum[15:0] */
            pkt_info->l3_header[11] = 0;
            pkt_info->l3_header[12] = new_ip_sa[0] >> 24;
            pkt_info->l3_header[13] = (new_ip_sa[0] >> 16) & 0xFF;
            pkt_info->l3_header[14] = (new_ip_sa[0] >> 8) & 0xFF;
            pkt_info->l3_header[15] = new_ip_sa[0] & 0xFF;
            pkt_info->l3_header[16] = new_ip_da[0] >> 24;
            pkt_info->l3_header[17] = (new_ip_da[0] >> 16) & 0xFF;
            pkt_info->l3_header[18] = (new_ip_da[0] >> 8) & 0xFF;
            pkt_info->l3_header[19] = new_ip_da[0] & 0xFF;

            new_ip_check_sum = ip_chksum((uint16*) pkt_info->l3_header, 20, 0);
            pkt_info->l3_header[10] = (new_ip_check_sum >> 8) & 0xFF;;
            pkt_info->l3_header[11] = new_ip_check_sum & 0xFF;
        }
        else
        {
            pkt_info->l3_header[0] = (6 << 4) | ((new_dscp >> 2) & 0xF);
            pkt_info->l3_header[1] = ((new_dscp & 0x3) << 6) | ((parser_result->l3_s.tos.ip_tos & 0x3)<<4);
            pkt_info->l3_header[2] = 0;
            pkt_info->l3_header[3] = 0;
            pkt_info->l3_header[4] = (new_total_length >> 8) & 0x3F;
            pkt_info->l3_header[5] = new_total_length & 0xFF;
            pkt_info->l3_header[6] = new_protocol;
            pkt_info->l3_header[7] = new_ttl;
            pkt_info->l3_header[8] = (new_ip_sa[3] >> 24) & 0xFF;
            pkt_info->l3_header[9] = (new_ip_sa[3] >> 16) & 0xFF;
            pkt_info->l3_header[10] = (new_ip_sa[3] >> 8) & 0xFF;
            pkt_info->l3_header[11] = new_ip_sa[3] & 0xFF;
            pkt_info->l3_header[12] = (new_ip_sa[2] >> 24) & 0xFF;
            pkt_info->l3_header[13] = (new_ip_sa[2] >> 16) & 0xFF;
            pkt_info->l3_header[14] = (new_ip_sa[2] >> 8) & 0xFF;
            pkt_info->l3_header[15] = new_ip_sa[2] & 0xFF;
            pkt_info->l3_header[16] = (new_ip_sa[1] >> 24) & 0xFF;
            pkt_info->l3_header[17] = (new_ip_sa[1] >> 16) & 0xFF;
            pkt_info->l3_header[18] = (new_ip_sa[1] >> 8) & 0xFF;
            pkt_info->l3_header[19] = new_ip_sa[1] & 0xFF;
            pkt_info->l3_header[20] = (new_ip_sa[0] >> 24) & 0xFF;
            pkt_info->l3_header[21] = (new_ip_sa[0] >> 16) & 0xFF;
            pkt_info->l3_header[22] = (new_ip_sa[0] >> 8) & 0xFF;
            pkt_info->l3_header[23] = new_ip_sa[0] & 0xFF;
            pkt_info->l3_header[24] = (new_ip_da[3] >> 24) & 0xFF;
            pkt_info->l3_header[25] = (new_ip_da[3] >> 16) & 0xFF;
            pkt_info->l3_header[26] = (new_ip_da[3] >> 8) & 0xFF;
            pkt_info->l3_header[27] = new_ip_da[3] & 0xFF;
            pkt_info->l3_header[28] = (new_ip_da[2] >> 24) & 0xFF;
            pkt_info->l3_header[29] = (new_ip_da[2] >> 16) & 0xFF;
            pkt_info->l3_header[30] = (new_ip_da[2] >> 8) & 0xFF;
            pkt_info->l3_header[31] = new_ip_da[2] & 0xFF;
            pkt_info->l3_header[32] = (new_ip_da[1] >> 24) & 0xFF;
            pkt_info->l3_header[33] = (new_ip_da[1] >> 16) & 0xFF;
            pkt_info->l3_header[34] = (new_ip_da[1] >> 8) & 0xFF;
            pkt_info->l3_header[35] = new_ip_da[1] & 0xFF;
            pkt_info->l3_header[36] = (new_ip_da[0] >> 24) & 0xFF;
            pkt_info->l3_header[37] = (new_ip_da[0] >> 16) & 0xFF;
            pkt_info->l3_header[38] = (new_ip_da[0] >> 8) & 0xFF;
            pkt_info->l3_header[39] = new_ip_da[0] & 0xFF;

            if ((!parser_result->l3_s.dont_frag
                    && epe_pkt_proc_ctl.ipv6_alwayse_add_frag_header)
                    || (parser_result->l3_s.frag_info != 0))
            {
                pkt_info->l3_new_header_len = 48;
                /* {4'h6, newDscp[5:0], ParserResult.tos[1:0], 20'd0, 2'b00,
                    newTotalLength[13:0], newProtocol[7:0], newTtl[7:0], newIpSa[127;0], newIpDa[127:0],
                    fragNextHeader[7:0], 8'd0, fragOffset[12:0], 2'd0, moreFrag, 16'd0, fragIdentification[15:0] */
                pkt_info->l3_header[40] = frag_next_header;
                pkt_info->l3_header[41] = 0;
                pkt_info->l3_header[42] = (frag_offset >> 5) & 0xFF;
                pkt_info->l3_header[43] = ((frag_offset & 0x1F) << 3) | (more_frag & 0x1);
                pkt_info->l3_header[44] = 0;
                pkt_info->l3_header[45] = 0;
                pkt_info->l3_header[46] = frag_identification >> 8;
                pkt_info->l3_header[47] = frag_identification & 0xFF;
            }
            else
            {
                /* {4'h6, newDscp[5:0], ParserResult.tos[1:0], 20'd0, 2'b00,
                    newTotalLength[13:0], newProtocol[7:0], newTtl[7:0], newIpSa[127;0], newIpDa[127:0]} */
                pkt_info->l3_new_header_len = 40;
            }
        }
    }

    /* Checksum */
    if (!((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.pt_enable))   /* IPv4 NAT */
    {
        pkt_info->l3_new_header_len = 0;
        pkt_info->new_ip_da_valid = new_ip_da_valid;
        pkt_info->new_ip_da = new_ip_da[0];
        pkt_info->new_l4_dest_port_valid = new_l4_dest_port_valid;
        pkt_info->new_l4_dest_port = new_l4_dest_port;
    }
    else    /* PT */
    {
        mtu_msg->nat_new_header_is_ipv4 = is_new_ipv4 ? TRUE : FALSE;
        mtu_msg->nat_new_header_valid = TRUE;
        mtu_msg->checksum_ip_da_valid = TRUE;
        mtu_msg->checksum_ip_sa_valid = TRUE;
        pkt_info->share_fields_u.nat.new_ip_sa_valid = FALSE;
        pkt_info->new_ip_da_valid = FALSE;
        pkt_info->new_l4_dest_port_valid = new_l4_dest_port_valid;
        pkt_info->new_l4_dest_port = new_l4_dest_port;
        pkt_info->share_fields_u.nat.new_ip_sa_31_0 = new_ip_sa[0];
        pkt_info->share_fields_u.nat.new_ip_sa_39_32 = new_ip_sa[1] & 0xff;
        pkt_info->new_ip_sa63_32 = (new_ip_sa[1] & 0xffffff00)|(pkt_info->share_fields_u.nat.new_ip_sa_39_32);

        pkt_info->new_ip_sa95_64 = new_ip_sa[2];
        pkt_info->new_ip_sa127_96 = new_ip_sa[3];
        pkt_info->new_ip_da = new_ip_da[0];
        pkt_info->new_ip_da63_32 = new_ip_da[1];
        pkt_info->new_ip_da95_64 = new_ip_da[2];
        pkt_info->new_ip_da127_96 = new_ip_da[3];
    }

    /* REPLACE_PARSER_RESULT */
    if (!((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.pt_enable))
    {
        mtu_msg->ip_da_31_0_update = new_ip_da[0];
        mtu_msg->l4_dest_port_update = new_l4_dest_port;
    }
    else if (is_new_ipv4)
    {
        mtu_msg->is_tcp_update = (TCP_PROTOCOL == new_protocol);
        mtu_msg->is_udp_update = (UDP_PROTOCOL == new_protocol);
        mtu_msg->layer3_type_update = L3_TYPE_IPV4;
        mtu_msg->ip_options_update = 0;
        mtu_msg->ip_header_error_update = 0;
        mtu_msg->ip_da_31_0_update = new_ip_da[0];
        mtu_msg->ip_checksum_update = (pkt_info->l3_header[10] <<8)|pkt_info->l3_header[11] ;
        mtu_msg->ip_sa_31_0_update = new_ip_sa[0];
        mtu_msg->layer4_info_mapped_update = new_protocol; /* no other map, only protocol number */
        mtu_msg->frag_info_update = 0;
        mtu_msg->tos_update = (mtu_msg->tos_update & 0x3) | ((new_dscp & 0x3F) << 2);
        mtu_msg->l4_dest_port_update = new_l4_dest_port; /* v3.5.2 bug 1149 */

        pkt_info->packet_ttl = new_ttl; /* packet TTL has been updated */
        pkt_info->packet_type = PKT_TYPE_IPV4;
    }
    else
    {
        mtu_msg->is_tcp_update = ((TCP_PROTOCOL == new_protocol)
                            || ((44 == new_protocol)
                                && (L4_TYPE_TCP == parser_result->layer4_type)
                                && epe_hdr_proc_frag_ctl.nat_frag_en));

        mtu_msg->is_udp_update = ((UDP_PROTOCOL == new_protocol)
                            || ((44 == new_protocol)
                                && (L4_TYPE_UDP == parser_result->layer4_type)
                                && epe_hdr_proc_frag_ctl.nat_frag_en));

        mtu_msg->frag_info_update = 0;
        mtu_msg->layer3_type_update = L3_TYPE_IPV6;
        mtu_msg->ip_options_update = 0;
        mtu_msg->ip_header_error_update = 0;
        mtu_msg->ip_da_31_0_update = new_ip_da[0];
        mtu_msg->ip_da_63_32_update = new_ip_da[1];
        mtu_msg->ip_da_95_64_update = new_ip_da[2];
        mtu_msg->ip_da_127_96_update = new_ip_da[3];
        mtu_msg->ip_sa_31_0_update = new_ip_sa[0];
        mtu_msg->ip_sa_63_32_update = new_ip_sa[1];
        mtu_msg->ip_sa_95_64_update = new_ip_sa[2];
        mtu_msg->ip_sa_127_96_update = new_ip_sa[3];
        mtu_msg->layer4_info_mapped_update = new_protocol;
        mtu_msg->tos_update = (mtu_msg->tos_update & 0x3) | ((new_dscp & 0x3F) << 2);
        mtu_msg->ipv6_flow_label_update = 0;
        mtu_msg->l4_dest_port_update = new_l4_dest_port; /* v3.5.2 bug 1149 */

        pkt_info->packet_ttl = new_ttl; /* packet ttl has been updated */
        pkt_info->packet_type = PKT_TYPE_IPV6;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_layer3_editing_mpls
 * Purpose:   perform layer3 mpls8w editing operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *            ds_l3_edit_mpls8_w -- pointer to ds_l3_edit_mpls8_ws
 *            mtu_msg  -- pointer to mtu msg struct
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *            mtu_msg  -- pointer to mtu msg struct
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_layer3_editing_mpls(epe_in_pkt_t* ipkt,
                        ds_l3_edit_mpls8_w_t* ds_l3_edit_mpls8_w, cm_epe_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_pkt_proc_ctl_t epe_pkt_proc_ctl;

    uint32 cmd = 0;
    uint32 field_id = 0;
    uint8 dest_leaf = 0;
    uint8 mpls_ttl = 0;
    uint8 mpls_exp = 0;
    uint8 mpls_sbit = 0;
    uint32 mpls_label = 0;
    uint32 ttl = 0;
    uint8 is_mpls_packet = FALSE;
    uint8 entropy_label_en = FALSE;
    uint8 l2_is_eth_type = ((L2_TYPE_ETHV2 == parser_result->layer2_type)
                            || (L2_TYPE_ETHSAP == parser_result->layer2_type)
                            || (L2_TYPE_ETHSNAP == parser_result->layer2_type));
    uint8 l3_is_mpls_type = ((L3_TYPE_MPLS == parser_result->layer3_type)
                             || (L3_TYPE_MPLSMCAST == parser_result->layer3_type));
    uint8 mpls_cw_valid = FALSE;
    uint32 mpls_cw = 0;
    uint32* p_l3_header = NULL;

    /* MPLS */
    pkt_info->l3_new_header_len = 0;
    mtu_msg->lm_index = 0;
    mtu_msg->first_label = 1;
    pkt_info->oam_lookup_num = 3;

    sal_memset(&epe_pkt_proc_ctl, 0, sizeof(epe_pkt_proc_ctl));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_ctl));

    /* For L2VPN,cos to exp.L3VPN,DSCP to exp. */
    if ((OAM_ACH == pkt_info->rx_oam_type) && pkt_info->link_or_section_oam)
    {
        mtu_msg->src_dscp5_3 = pkt_info->source_cos;
    }
    else if (ds_l3_edit_mpls8_w->src_dscp_type)
    {
        if (parser_result->l2_s.svlan_id_valid)
        {
            mtu_msg->src_dscp5_3 = parser_result->l2_s.stag_cos;
        }
        else if (parser_result->l2_s.cvlan_id_valid)
        {
            mtu_msg->src_dscp5_3 = parser_result->l2_s.ctag_cos;
        }
        else if (l2_is_eth_type)
        {
            mtu_msg->src_dscp5_3 = (pkt_info->src_dscp >> 3) & 0x7;
        }
    }
    else
    {
        mtu_msg->src_dscp5_3 = (pkt_info->src_dscp >> 3) & 0x7;
    }

    is_mpls_packet = l3_is_mpls_type && (L2_TYPE_NONE == parser_result->layer2_type);
    entropy_label_en = FALSE;

    /* DISCARD_SWITCH */
    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* MARTINI_OR_LABEL0 */
    if (ds_l3_edit_mpls8_w->martini_encap_valid && !pkt_info->cw_add)   /* add matini encapsulation */
    {
        mpls_cw_valid = TRUE;
        dest_leaf = ds_l3_edit_mpls8_w->use_src_leaf ? pkt_info->src_leaf : 0;

        if (IS_BIT_SET(ds_l3_edit_mpls8_w->martini_encap_type, 0))      /* use DsL3EditMpls fields as CW */
        {
            mpls_cw = (ds_l3_edit_mpls8_w->derive_exp0 << 31)
                      | (ds_l3_edit_mpls8_w->exp0 << 28)
                      | ((ds_l3_edit_mpls8_w->etree_leaf_en) ? (dest_leaf << 27) :
                        ((IS_BIT_SET(ds_l3_edit_mpls8_w->label0, 1) << 27)))   /* label0[1] */
                      | (ds_l3_edit_mpls8_w->oam_en0 << 26)
                      | (ds_l3_edit_mpls8_w->entropy_label_en0 << 25)
                      | (IS_BIT_SET(ds_l3_edit_mpls8_w->label0, 0) << 24)
                      | (ds_l3_edit_mpls8_w->ttl_index0 << 20)
                      | ((ds_l3_edit_mpls8_w->label0 & 0xc) << 16)              /* label0[3:2] */
                      | (ds_l3_edit_mpls8_w->map_ttl0 << 17)
                      | ((ds_l3_edit_mpls8_w->mcast_label0) << 16)
                      | ((ds_l3_edit_mpls8_w->label0 >> 4 ) & 0xFFFF);          /* label0[11:4] */
        }
        else    /* fixed CW */
        {
            mpls_cw_valid = TRUE;
            mpls_cw = ((dest_leaf & 0x1) << 27); /* only support ETREE leaf flag, all other is zero */
        }
    }

    /* first label */
    field_id = EpeL3EditMplsTtl_Ttl0_f + ds_l3_edit_mpls8_w->ttl_index0;
    cmd = DRV_IOR(EpeL3EditMplsTtl_t, field_id);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &ttl));

    if (!IS_BIT_SET(pkt_info->mpls_label_disable, 0)
        && ((!ds_l3_edit_mpls8_w->martini_encap_valid)
        || (!ds_l3_edit_mpls8_w->martini_encap_type))
        && pkt_info->ds_l3_edit_exist)
    {
        entropy_label_en |= ds_l3_edit_mpls8_w->entropy_label_en0;

        if (ds_l3_edit_mpls8_w->map_ttl0)
        {
            mpls_ttl = (pkt_info->packet_ttl > ttl) ? (pkt_info->packet_ttl - ttl) : 0;
        }
        else
        {
            mpls_ttl = ttl;
        }

        if (!pkt_info->exception_en && (0 == mpls_ttl) && (epe_pkt_proc_ctl.discard_mpls_tag_ttl0))
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 2;
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE MplsTTL=0 and DiscardMplsTTL0 is set!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (ds_l3_edit_mpls8_w->derive_exp0 && (IS_BIT_SET(ds_l3_edit_mpls8_w->exp0, 0)))
        {
            mpls_exp = pkt_info->mapped_exp;
        }
        else if (ds_l3_edit_mpls8_w->derive_exp0 && !(IS_BIT_SET(ds_l3_edit_mpls8_w->exp0, 0)))
        {
            mpls_exp = mtu_msg->src_dscp5_3;
        }
        else
        {
            mpls_exp = ds_l3_edit_mpls8_w->exp0;
        }

        if (((PKT_TYPE_MPLS == pkt_info->packet_type) || (PKT_TYPE_MCAST_MPLS == pkt_info->packet_type))
            || pkt_info->gal_exist || pkt_info->entropy_label_exist || entropy_label_en)
        {
            mpls_sbit = 0;
        }
        else
        {
            mpls_sbit = 1;
        }

        mpls_label = ds_l3_edit_mpls8_w->label0;

        sal_memmove(pkt_info->l3_header + 4, pkt_info->l3_header, pkt_info->l3_new_header_len);
        pkt_info->l3_header[0] = (mpls_label >> 12) & 0xFF;
        pkt_info->l3_header[1] = (mpls_label >> 4) & 0xFF;
        pkt_info->l3_header[2] = ((mpls_label & 0xF) << 4) | (mpls_exp << 1) | mpls_sbit ;
        pkt_info->l3_header[3] = mpls_ttl;
        pkt_info->l3_new_header_len += 4;

        if (ds_l3_edit_mpls8_w->mcast_label0)
        {
            pkt_info->packet_type = PKT_TYPE_MCAST_MPLS;
            parser_result->layer3_type = L3_TYPE_MPLSMCAST;
        }
        else
        {
            pkt_info->packet_type = PKT_TYPE_MPLS;    /* overwrite packet type */
            parser_result->layer3_type = L3_TYPE_MPLS;
        }

        pkt_info->section_lm_exp = mpls_exp & 0x7;

        if (ds_l3_edit_mpls8_w->oam_en0)
        {
            if (mtu_msg->first_label && (L4_TYPE_ACH_OAM == parser_result->layer4_type))
            {
                pkt_info->oam_lookup_num = mtu_msg->lm_index & 0x3;
            }
            pkt_info->link_lm_type = 0;
            if (0 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid0 = TRUE;
                pkt_info->mpls_lm_label0 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp0 = mpls_exp & 0x7;
            }
            else if (1 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid1 = TRUE;
                pkt_info->mpls_lm_label1 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp1 = mpls_exp & 0x7;
            }
            else if (2 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid2 = TRUE;
                pkt_info->mpls_lm_label2 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp2 = mpls_exp & 0x7;
            }
            mtu_msg->lm_index += 1;
        }

        if (ds_l3_edit_mpls8_w->discard_non_oam0 && (!mtu_msg->first_label
            || (L4_TYPE_ACH_OAM != parser_result->layer4_type)))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;
                pkt_info->discard = TRUE;
            }
        }

        mtu_msg->first_label = 0;
    }

    /* ADD_LABELS_1  */
    if (!IS_BIT_SET(pkt_info->mpls_label_disable, 1) && ds_l3_edit_mpls8_w->label_valid1)/*add secend label*/
    {
        entropy_label_en |= ds_l3_edit_mpls8_w->entropy_label_en1;

        field_id = EpeL3EditMplsTtl_Ttl0_f + ds_l3_edit_mpls8_w->ttl_index1;
        cmd = DRV_IOR(EpeL3EditMplsTtl_t, field_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &ttl));

        if (ds_l3_edit_mpls8_w->map_ttl1)
        {
            mpls_ttl = (pkt_info->packet_ttl > ttl) ? (pkt_info->packet_ttl - ttl) : 0;
        }
        else
        {
            mpls_ttl = ttl;
        }

        if (!pkt_info->exception_en && (0 == mpls_ttl) && epe_pkt_proc_ctl.discard_mpls_tag_ttl0)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 2;

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE MplsTTL=0 and DiscardMplsTTL0 is set!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (ds_l3_edit_mpls8_w->derive_exp1 && (IS_BIT_SET(ds_l3_edit_mpls8_w->exp1, 0)))
        {
            mpls_exp = pkt_info->mapped_exp;
        }
         else if (ds_l3_edit_mpls8_w->derive_exp1 && !(IS_BIT_SET(ds_l3_edit_mpls8_w->exp1, 0)))
        {
            mpls_exp = mtu_msg->src_dscp5_3;
        }
        else
        {
            mpls_exp = ds_l3_edit_mpls8_w->exp1;
        }

        if (((PKT_TYPE_MPLS == pkt_info->packet_type) || (PKT_TYPE_MCAST_MPLS == pkt_info->packet_type))
            || pkt_info->gal_exist || pkt_info->entropy_label_exist || entropy_label_en)
        {
            mpls_sbit = 0;
        }
        else
        {
            mpls_sbit = 1;
        }

        mpls_label = ds_l3_edit_mpls8_w->label1;

        sal_memmove(pkt_info->l3_header + 4, pkt_info->l3_header, pkt_info->l3_new_header_len);
        pkt_info->l3_header[0] = (mpls_label >> 12) & 0xFF;
        pkt_info->l3_header[1] = (mpls_label >> 4) & 0xFF;
        pkt_info->l3_header[2] = ((mpls_label & 0xF) << 4) | (mpls_exp << 1) | mpls_sbit ;
        pkt_info->l3_header[3] = mpls_ttl;
        pkt_info->l3_new_header_len += 4;

        if (ds_l3_edit_mpls8_w->mcast_label1)
        {
            pkt_info->packet_type = PKT_TYPE_MCAST_MPLS;
            parser_result->layer3_type = L3_TYPE_MPLSMCAST;
        }
        else
        {
            pkt_info->packet_type = PKT_TYPE_MPLS;    /* overwrite packet type */
            parser_result->layer3_type = L3_TYPE_MPLS;
        }

        pkt_info->section_lm_exp = mpls_exp & 0x7;

        if (ds_l3_edit_mpls8_w->oam_en1)
        {
            if (mtu_msg->first_label && (L4_TYPE_ACH_OAM == parser_result->layer4_type))
            {
                pkt_info->oam_lookup_num = mtu_msg->lm_index;
            }
            pkt_info->link_lm_type = 0;
            if (0 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid0 = TRUE;
                pkt_info->mpls_lm_label0 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp0 = mpls_exp & 0x7;
            }
            else if (1 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid1 = TRUE;
                pkt_info->mpls_lm_label1 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp1 = mpls_exp & 0x7;
            }
            else if (2 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid2 = TRUE;
                pkt_info->mpls_lm_label2 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp2 = mpls_exp & 0x7;
            }
            mtu_msg->lm_index += 1;
        }

        if (ds_l3_edit_mpls8_w->discard_non_oam1 && (!mtu_msg->first_label
            || (L4_TYPE_ACH_OAM != parser_result->layer4_type)))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;
                pkt_info->discard = TRUE;
            }
        }

        mtu_msg->first_label = 0;
    }
    else if (!ds_l3_edit_mpls8_w->label_valid1)
    {
        if (ds_l3_edit_mpls8_w->mcast_label1)/* logic_port_check1 */
        {
            pkt_info->logic_port_check = TRUE;
            pkt_info->logic_dest_port = ds_l3_edit_mpls8_w->label1 & 0x3FFF;/* logic_dest_port1 */
        }

        if (ds_l3_edit_mpls8_w->map_ttl1     /* stats_ptr1_valid */
                && !pkt_info->flow_stats2_valid)
        {
            pkt_info->flow_stats2_valid = TRUE; /* VC label stats pointer */
            pkt_info->flow_stats2_ptr = (ds_l3_edit_mpls8_w->derive_exp1 << 13)  /* stats_ptr1[13] */
                            | (ds_l3_edit_mpls8_w->exp1 << 10)                   /* stats_ptr1[12:10] */
                            | (ds_l3_edit_mpls8_w->ttl_index1 << 6)              /* stats_ptr1[9:6] */
                            | (ds_l3_edit_mpls8_w->label1 >> 14);                /* stats_ptr1[5:0] */
        }
    }

    /* ADD_LABELS_2 */
    if (!IS_BIT_SET(pkt_info->mpls_label_disable, 2) && ds_l3_edit_mpls8_w->label_valid2)/* add third label */
    {
        entropy_label_en |= ds_l3_edit_mpls8_w->entropy_label_en2;

        field_id = EpeL3EditMplsTtl_Ttl0_f + ds_l3_edit_mpls8_w->ttl_index2;
        cmd = DRV_IOR(EpeL3EditMplsTtl_t, field_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &ttl));

        if (ds_l3_edit_mpls8_w->map_ttl2)
        {
            mpls_ttl = (pkt_info->packet_ttl > ttl) ? (pkt_info->packet_ttl - ttl) : 0;
        }
        else
        {
            mpls_ttl = ttl;
        }

        if (!pkt_info->exception_en && (0 == mpls_ttl) && epe_pkt_proc_ctl.discard_mpls_tag_ttl0)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 2;

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE MplsTTL=0 and DiscardMplsTTL0 is set!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (ds_l3_edit_mpls8_w->derive_exp2 && IS_BIT_SET(ds_l3_edit_mpls8_w->exp2, 0))
        {
            mpls_exp = pkt_info->mapped_exp;
        }
        else if (ds_l3_edit_mpls8_w->derive_exp2 && !(IS_BIT_SET(ds_l3_edit_mpls8_w->exp2, 0)))
        {
            mpls_exp = mtu_msg->src_dscp5_3;
        }
        else
        {
            mpls_exp = ds_l3_edit_mpls8_w->exp2;
        }

        if (((PKT_TYPE_MPLS == pkt_info->packet_type) || (PKT_TYPE_MCAST_MPLS == pkt_info->packet_type))
            || pkt_info->gal_exist || pkt_info->entropy_label_exist || entropy_label_en)
        {
            mpls_sbit = 0;
        }
        else
        {
            mpls_sbit = 1;
        }

        mpls_label = ds_l3_edit_mpls8_w->label2;

        sal_memmove(pkt_info->l3_header + 4, pkt_info->l3_header, pkt_info->l3_new_header_len);
        pkt_info->l3_header[0] = (mpls_label >> 12) & 0xFF;
        pkt_info->l3_header[1] = (mpls_label >> 4) & 0xFF;
        pkt_info->l3_header[2] = ((mpls_label & 0xF) << 4) | (mpls_exp << 1) | mpls_sbit ;
        pkt_info->l3_header[3] = mpls_ttl;
        pkt_info->l3_new_header_len += 4;

        if (ds_l3_edit_mpls8_w->mcast_label2)
        {
            pkt_info->packet_type = PKT_TYPE_MCAST_MPLS;
            parser_result->layer3_type = L3_TYPE_MPLSMCAST;
        }
        else
        {
            pkt_info->packet_type = PKT_TYPE_MPLS;    /* overwrite packet type */
            parser_result->layer3_type = L3_TYPE_MPLS;
        }

        pkt_info->section_lm_exp = mpls_exp & 0x7;

        if (ds_l3_edit_mpls8_w->oam_en2)
        {
            if (mtu_msg->first_label && (L4_TYPE_ACH_OAM == parser_result->layer4_type))
            {
                pkt_info->oam_lookup_num = mtu_msg->lm_index;
            }
            pkt_info->link_lm_type = 0;
            if (0 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid0 = TRUE;
                pkt_info->mpls_lm_label0 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp0 = mpls_exp & 0x7;
            }
            else if (1 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid1 = TRUE;
                pkt_info->mpls_lm_label1 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp1 = mpls_exp & 0x7;
            }
            else if (2 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid2 = TRUE;
                pkt_info->mpls_lm_label2 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp2 = mpls_exp & 0x7;
            }
            mtu_msg->lm_index += 1;
        }

        if (ds_l3_edit_mpls8_w->discard_non_oam2 && (!mtu_msg->first_label
            || (L4_TYPE_ACH_OAM != parser_result->layer4_type)))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;
                pkt_info->discard = TRUE;
            }
        }

        mtu_msg->first_label = 0;
    }
    else if (!ds_l3_edit_mpls8_w->label_valid2)
    {
        if (ds_l3_edit_mpls8_w->mcast_label2)/* logic_port_check2 */
        {
            pkt_info->logic_port_check = TRUE;
            pkt_info->logic_dest_port = ds_l3_edit_mpls8_w->label2 & 0x3FFF;/* logic_dest_port2 */
        }

        if (ds_l3_edit_mpls8_w->map_ttl2     /* stats_ptr2_valid */
                && !pkt_info->flow_stats1_valid)
        {
            pkt_info->flow_stats1_valid = TRUE; /* tunnel label stats pointer */
            pkt_info->flow_stats1_ptr = (ds_l3_edit_mpls8_w->derive_exp2 << 13)/* stats_ptr2[13] */
                            | (ds_l3_edit_mpls8_w->exp2 << 10)                 /* stats_ptr2[12:10] */
                            | (ds_l3_edit_mpls8_w->ttl_index2 << 6)            /* stats_ptr2[9:6] */
                            | (ds_l3_edit_mpls8_w->label2 >> 14);              /* stats_ptr2[5:0] */
        }
    }

    /* ADD_LABELS_3 */
    if (!IS_BIT_SET(pkt_info->mpls_label_disable, 3) && ds_l3_edit_mpls8_w->label_valid3)/* add fourth label */
    {
        entropy_label_en |= ds_l3_edit_mpls8_w->entropy_label_en3;

        field_id = EpeL3EditMplsTtl_Ttl0_f + ds_l3_edit_mpls8_w->ttl_index3;
        cmd = DRV_IOR(EpeL3EditMplsTtl_t, field_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &ttl));

        if (ds_l3_edit_mpls8_w->map_ttl3)
        {
            mpls_ttl = (pkt_info->packet_ttl > ttl) ? (pkt_info->packet_ttl - ttl) : 0;
        }
        else
        {
            mpls_ttl = ttl;
        }

        if (!pkt_info->exception_en && (0 == mpls_ttl) && epe_pkt_proc_ctl.discard_mpls_tag_ttl0)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 2;

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE MplsTTL=0 and DiscardMplsTTL0 is set!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (ds_l3_edit_mpls8_w->derive_exp3 && (IS_BIT_SET(ds_l3_edit_mpls8_w->exp3, 0)))
        {
            mpls_exp = pkt_info->mapped_exp;
        }
        else if (ds_l3_edit_mpls8_w->derive_exp3 && !(IS_BIT_SET(ds_l3_edit_mpls8_w->exp3, 0)))
        {
            mpls_exp = mtu_msg->src_dscp5_3;
        }
        else
        {
            mpls_exp = ds_l3_edit_mpls8_w->exp3;
        }

        if (((PKT_TYPE_MPLS == pkt_info->packet_type) || (PKT_TYPE_MCAST_MPLS == pkt_info->packet_type))
            || pkt_info->gal_exist || pkt_info->entropy_label_exist || entropy_label_en)
        {
            mpls_sbit = 0;
        }
        else
        {
            mpls_sbit = 1;
        }

        mpls_label = ds_l3_edit_mpls8_w->label3;

        sal_memmove(pkt_info->l3_header + 4, pkt_info->l3_header, pkt_info->l3_new_header_len);
        pkt_info->l3_header[0] = (mpls_label >> 12) & 0xFF;
        pkt_info->l3_header[1] = (mpls_label >> 4) & 0xFF;
        pkt_info->l3_header[2] = ((mpls_label & 0xF) << 4) | (mpls_exp << 1) | mpls_sbit ;
        pkt_info->l3_header[3] = mpls_ttl;
        pkt_info->l3_new_header_len += 4;

        if (ds_l3_edit_mpls8_w->mcast_label3)
        {
            pkt_info->packet_type = PKT_TYPE_MCAST_MPLS;
            parser_result->layer3_type = L3_TYPE_MPLSMCAST;
        }
        else
        {
            pkt_info->packet_type = PKT_TYPE_MPLS;    /* overwrite packet type */
            parser_result->layer3_type = L3_TYPE_MPLS;
        }

        pkt_info->section_lm_exp = mpls_exp & 0x7;

        if (ds_l3_edit_mpls8_w->oam_en3 && (mtu_msg->lm_index < 3))
        {
            if (mtu_msg->first_label && (L4_TYPE_ACH_OAM == parser_result->layer4_type))
            {
                pkt_info->oam_lookup_num = mtu_msg->lm_index;
            }
            pkt_info->link_lm_type = 0;
            if (0 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid0 = TRUE;
                pkt_info->mpls_lm_label0 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp0 = mpls_exp & 0x7;
            }
            else if (1 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid1 = TRUE;
                pkt_info->mpls_lm_label1 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp1 = mpls_exp & 0x7;
            }
            else if (2 == mtu_msg->lm_index)
            {
                pkt_info->mpls_lm_valid2 = TRUE;
                pkt_info->mpls_lm_label2 = mpls_label & 0xFFFFF;
                pkt_info->mpls_lm_exp2 = mpls_exp & 0x7;
            }
            mtu_msg->lm_index += 1;
        }

        if (ds_l3_edit_mpls8_w->discard_non_oam3 && (!mtu_msg->first_label
            || (L4_TYPE_ACH_OAM != parser_result->layer4_type)))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;
                pkt_info->discard = TRUE;
            }
        }

        mtu_msg->first_label = 0;
    }
    else if (!ds_l3_edit_mpls8_w->label_valid3)
    {
        if (ds_l3_edit_mpls8_w->mcast_label3)/* logic_port_check3 */
        {
            pkt_info->logic_port_check = TRUE;
            pkt_info->logic_dest_port = ds_l3_edit_mpls8_w->label3 & 0x3FFF;/* logic_dest_port3 */
        }

        if (ds_l3_edit_mpls8_w->map_ttl3    /* stats_ptr3_valid */
                && !pkt_info->flow_stats1_valid)
        {
            pkt_info->flow_stats1_valid = TRUE; /* tunnel label stats pointer */
            pkt_info->flow_stats1_ptr = (ds_l3_edit_mpls8_w->derive_exp3 << 13)/* stats_ptr3[13] */
                            | (ds_l3_edit_mpls8_w->exp3 << 10)                 /* stats_ptr3[12:10] */
                            | (ds_l3_edit_mpls8_w->ttl_index3 << 6)            /* stats_ptr3[9:6] */
                            | (ds_l3_edit_mpls8_w->label3 >> 14);              /* stats_ptr3[5:0] */
        }
    }

    /* ENTROPY_LABEL */
    /* Only one entropy label added,MPLS label stacking within different node ??? */
    if (entropy_label_en && !is_mpls_packet&& !pkt_info->entropy_label_exist)
    {
        pkt_info->l3_header[pkt_info->l3_new_header_len] = ((pkt_info->header_hash
                                        + epe_pkt_proc_ctl.mpls_hash_base) >> 12);
        pkt_info->l3_header[pkt_info->l3_new_header_len + 1] = (((pkt_info->header_hash
                                        + epe_pkt_proc_ctl.mpls_hash_base) >> 4) & 0xFF);
        pkt_info->l3_header[pkt_info->l3_new_header_len + 2] = (((pkt_info->header_hash
                                        + epe_pkt_proc_ctl.mpls_hash_base) & 0xF) << 4)
                                        | 0x1;
        pkt_info->l3_header[pkt_info->l3_new_header_len + 3] = 0;

        pkt_info->l3_new_header_len += 4;
    }

    if (mpls_cw_valid)
    {
        pkt_info->l3_header[pkt_info->l3_new_header_len] = (mpls_cw >> 24) & 0xFF;
        pkt_info->l3_header[pkt_info->l3_new_header_len + 1] = (mpls_cw >> 16) & 0xFF;
        pkt_info->l3_header[pkt_info->l3_new_header_len + 2] = (mpls_cw >> 8) & 0xFF;
        pkt_info->l3_header[pkt_info->l3_new_header_len + 3] = mpls_cw & 0xFF;

        pkt_info->l3_new_header_len += 4;
    }

    p_l3_header = (uint32*)&pkt_info->l3_header[0];

    /* REPLACE_PARSER_RESULT */
    switch(pkt_info->l3_new_header_len >> 2)
    {
       case 6:
            mtu_msg->mpls_label_update3 = sal_ntohl(p_l3_header[3]);
            mtu_msg->mpls_label_update2 = sal_ntohl(p_l3_header[2]);
            mtu_msg->mpls_label_update1 = sal_ntohl(p_l3_header[1]);
            mtu_msg->mpls_label_update0 = sal_ntohl(p_l3_header[0]);
            break;

        case 5:
            mtu_msg->mpls_label_update3 = sal_ntohl(p_l3_header[3]);
            mtu_msg->mpls_label_update2 = sal_ntohl(p_l3_header[2]);
            mtu_msg->mpls_label_update1 = sal_ntohl(p_l3_header[1]);
            mtu_msg->mpls_label_update0 = sal_ntohl(p_l3_header[0]);
            break;

        case 4:
            mtu_msg->mpls_label_update3 = sal_ntohl(p_l3_header[3]);
            mtu_msg->mpls_label_update2 = sal_ntohl(p_l3_header[2]);
            mtu_msg->mpls_label_update1 = sal_ntohl(p_l3_header[1]);
            mtu_msg->mpls_label_update0 = sal_ntohl(p_l3_header[0]);
            break;

        case 3:
            mtu_msg->mpls_label_update3 = parser_result->l3_s.ip_da.mpls.mpls_label0;
            mtu_msg->mpls_label_update2 = sal_ntohl(p_l3_header[2]);
            mtu_msg->mpls_label_update1 = sal_ntohl(p_l3_header[1]);
            mtu_msg->mpls_label_update0 = sal_ntohl(p_l3_header[0]);
            break;

        case 2:
            mtu_msg->mpls_label_update3 = parser_result->l3_s.ip_da.mpls.mpls_label1;
            mtu_msg->mpls_label_update2 = parser_result->l3_s.ip_da.mpls.mpls_label0;
            mtu_msg->mpls_label_update1 = sal_ntohl(p_l3_header[1]);
            mtu_msg->mpls_label_update0 = sal_ntohl(p_l3_header[0]);
            break;

        case 1:
            mtu_msg->mpls_label_update3 = parser_result->l3_s.ip_da.mpls.mpls_label2;
            mtu_msg->mpls_label_update2 = parser_result->l3_s.ip_da.mpls.mpls_label1;
            mtu_msg->mpls_label_update1 = parser_result->l3_s.ip_da.mpls.mpls_label0;
            mtu_msg->mpls_label_update0 = sal_ntohl(p_l3_header[0]);
            break;
        default:    /* 0,no update */
            break;

   }

   return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_layer3_editing_l2_eth_add
 * Purpose:   perform l2 ether header add editing operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *            ds_l2_edit_eth4_w_added  -- pointer to ds_l2_edit_eth4_w_t struct
 *             mtu_msg -- pointer to mtu msg struct
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static uint32
_cm_epe_layer3_editing_l2_eth_add(epe_in_pkt_t* ipkt, ds_l2_edit_eth4_w_t* ds_l2_edit_eth4_w_added,
                            cm_epe_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    epe_l2_port_mac_sa_t epe_l2_port_mac_sa;
    epe_l2_router_mac_sa_t epe_l2_router_mac_sa;
    epe_l2_tpid_ctl_t epe_l2_tpid_ctl;
    epe_l2_snap_ctl_t epe_l2_snap_ctl;
    epe_l2_edit_ctl_t epe_l2_edit_ctl;
    epe_pkt_proc_ctl_t epe_pkt_proc_ctl;

    uint8 packet_type = 0;
    uint32 cmd = 0;
    uint16 new_ether_type = 0;
    uint32 l2_ether_field_value = 0;
    uint8 new_mac_sa[6] = {0}, new_mac_da[6] = {0};
    uint8 dot1q_en1 = FALSE, dot1q_en0 = FALSE;
    uint16 new_svlan_tpid = 0, new_cvlan_tpid = 0;
    uint8 untag_default_svlan = 0, untag_default_cvlan = 0;
    uint8 svlan_tag_en = FALSE, cvlan_tag_en = FALSE;
    uint8 new_stag_cos = 0, new_ctag_cos = 0;
    uint8 new_stag_cfi = 0, new_ctag_cfi = 0;
    uint32 new_svlan_tag = 0, new_cvlan_tag = 0;
    uint16 new_snap_length = 0;
    uint8 offset = 0;
    uint8 header_offset = 0;
    uint16 output_svlan_id = 0,output_cvlan_id = 0;

    /* LAYER2_ETHER */
    packet_type = pkt_info->packet_type;/* this is the payload packet type */

    /* DISCARD_SWITCH */
    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* PREPARE_FIELDS */
    /* EtherType */
    if (ds_l2_edit_eth4_w_added->overwrite_ether_type)
    {
        packet_type = ds_l2_edit_eth4_w_added->packet_type;
    }
    else
    {
        packet_type = pkt_info->packet_type;
    }

    /* Mac Sa */
    sal_memset(&epe_l2_port_mac_sa, 0, sizeof(epe_l2_port_mac_sa_t));
    cmd = DRV_IOR(EpeL2PortMacSa_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_port_mac_sa));

    sal_memset(&epe_l2_router_mac_sa, 0, sizeof(epe_l2_router_mac_sa_t));
    cmd = DRV_IOR(EpeL2RouterMacSa_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_router_mac_sa));

    sal_memset(&epe_l2_edit_ctl, 0, sizeof(epe_l2_edit_ctl_t));
    cmd = DRV_IOR(EpeL2EditCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_edit_ctl));

    if ((L3_TYPE_FCOE == parser_result->layer3_type)
            && ds_l2_edit_eth4_w_added->fcoe_over_trill_mac_sa_en)    /* fcoeOverTrillMacSaEn */
    {
        new_mac_sa[5] = epe_l2_edit_ctl.system_mac_high >> 8;
        new_mac_sa[4] = epe_l2_edit_ctl.system_mac_high & 0xFF;
        new_mac_sa[3] = epe_l2_edit_ctl.system_mac_low >> 24;
        new_mac_sa[2] = (epe_l2_edit_ctl.system_mac_low >> 16) & 0xFF;
        new_mac_sa[1] = (epe_l2_edit_ctl.system_mac_low >> 8) & 0xFF;
        new_mac_sa[0] = epe_l2_edit_ctl.system_mac_low & 0xFF;
    }
    else if ((PKT_TYPE_TRILL == packet_type)
            || ((L3_TYPE_FCOE == parser_result->layer3_type)
            && !ds_l2_edit_eth4_w_added->derive_fcoe_mac_sa))
    {
        if (pkt_info->port_mac_sa_type)
        {
            new_mac_sa[5] = epe_l2_port_mac_sa.port_mac_sa1_47_32 >> 8;
            new_mac_sa[4] = epe_l2_port_mac_sa.port_mac_sa1_47_32 & 0xFF;
            new_mac_sa[3] = epe_l2_port_mac_sa.port_mac_sa1_31_8 >> 16;
            new_mac_sa[2] = ((epe_l2_port_mac_sa.port_mac_sa1_31_8 >> 8) & 0xFF);
            new_mac_sa[1] = epe_l2_port_mac_sa.port_mac_sa1_31_8 & 0xFF;
            new_mac_sa[0] = pkt_info->port_mac_sa;
        }
        else
        {
            new_mac_sa[5] = epe_l2_port_mac_sa.port_mac_sa0_47_32 >> 8;
            new_mac_sa[4] = epe_l2_port_mac_sa.port_mac_sa0_47_32 & 0xFF;
            new_mac_sa[3] = epe_l2_port_mac_sa.port_mac_sa0_31_8 >> 16;
            new_mac_sa[2] = ((epe_l2_port_mac_sa.port_mac_sa0_31_8 >> 8) & 0xFF);
            new_mac_sa[1] = epe_l2_port_mac_sa.port_mac_sa0_31_8 & 0xFF;
            new_mac_sa[0] = pkt_info->port_mac_sa;
        }
    }
    else if ((L3_TYPE_FCOE == parser_result->layer3_type)
            && ds_l2_edit_eth4_w_added->derive_fcoe_mac_sa)
    {
        new_mac_sa[5] = 0xE;
        new_mac_sa[4] = 0xFC;
        new_mac_sa[3] = pkt_info->fcoe_oui_index;
        new_mac_sa[2] = parser_result->l3_s.ip_sa.fcoe.fcoe_sid >> 16;
        new_mac_sa[1] = (parser_result->l3_s.ip_sa.fcoe.fcoe_sid >> 8) & 0xFF;
        new_mac_sa[0] = parser_result->l3_s.ip_sa.fcoe.fcoe_sid & 0xFF;
    }
    else
    {
        if (2 == pkt_info->mac_sa_type)
        {
            new_mac_sa[5] = epe_l2_router_mac_sa.router_mac_sa2_47_32 >> 8;
            new_mac_sa[4] = epe_l2_router_mac_sa.router_mac_sa2_47_32 & 0xFF;
            new_mac_sa[3] = epe_l2_router_mac_sa.router_mac_sa2_31_8 >> 16;
            new_mac_sa[2] = ((epe_l2_router_mac_sa.router_mac_sa2_31_8 >> 8) & 0xFF);
            new_mac_sa[1] = epe_l2_router_mac_sa.router_mac_sa2_31_8 & 0xFF;
            new_mac_sa[0] = pkt_info->mac_sa;
        }
        else if (1 == pkt_info->mac_sa_type)
        {
            new_mac_sa[5] = epe_l2_router_mac_sa.router_mac_sa1_47_32 >> 8;
            new_mac_sa[4] = epe_l2_router_mac_sa.router_mac_sa1_47_32 & 0xFF;
            new_mac_sa[3] = epe_l2_router_mac_sa.router_mac_sa1_31_8 >> 16;
            new_mac_sa[2] = ((epe_l2_router_mac_sa.router_mac_sa1_31_8 >> 8) & 0xFF);
            new_mac_sa[1] = epe_l2_router_mac_sa.router_mac_sa1_31_8 & 0xFF;
            new_mac_sa[0] = pkt_info->mac_sa;
        }
        else if (0 == pkt_info->mac_sa_type)
        {
            new_mac_sa[5] = epe_l2_router_mac_sa.router_mac_sa0_47_32 >> 8;
            new_mac_sa[4] = epe_l2_router_mac_sa.router_mac_sa0_47_32 & 0xFF;
            new_mac_sa[3] = epe_l2_router_mac_sa.router_mac_sa0_31_8 >> 16;
            new_mac_sa[2] = ((epe_l2_router_mac_sa.router_mac_sa0_31_8 >> 8) & 0xFF);
            new_mac_sa[1] = epe_l2_router_mac_sa.router_mac_sa0_31_8 & 0xFF;
            new_mac_sa[0] = pkt_info->mac_sa;
        }
    }

    if (PKT_TYPE_IPV4 == packet_type)
    {
        new_ether_type = 0x0800;
    }
    else if (PKT_TYPE_MPLS == packet_type)
    {
        new_ether_type = 0x8847;
    }
    else if (PKT_TYPE_IPV6 == packet_type)
    {
        new_ether_type = 0x86DD;
    }
    else if (PKT_TYPE_MCAST_MPLS == packet_type)
    {
        new_ether_type = 0x8848;
    }
    else if (PKT_TYPE_TRILL == packet_type)
    {
        new_ether_type = 0x22F3;
    }
    else if (L3_TYPE_FCOE == parser_result->layer3_type)
    {
        new_ether_type = 0x8906;
    }
    else
    {
        cmd = DRV_IOR(EpeL2EtherType_t, EpeL2EtherType_EtherType0_f + (packet_type - 6));
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &l2_ether_field_value));

        new_ether_type = l2_ether_field_value;
    }

    /* MAC DA */
    if (pkt_info->route_no_l2_edit)
    {
        if (!pkt_info->mac_da_mcast_mode
            && (PKT_TYPE_IPV4 == packet_type)
            && (0xE == (parser_result->l3_s.ip_da.ipv4.ipda >> 28)))/* [31:28] */
        {
            /* newMacDa[47:0] = {24'h01005E, 1'b0, ParserResult.ipDa[22:0]} */
            new_mac_da[0] = parser_result->l3_s.ip_da.ipv4.ipda & 0xFF;
            new_mac_da[1] = (parser_result->l3_s.ip_da.ipv4.ipda >> 8) & 0xFF;
            new_mac_da[2] = (parser_result->l3_s.ip_da.ipv4.ipda >> 16) & 0x7F;
            new_mac_da[3] = 0x5E;
            new_mac_da[4] = 0x00;
            new_mac_da[5] = 0x01;
        }
        else if (!pkt_info->mac_da_mcast_mode
            && (PKT_TYPE_IPV6 == packet_type)
            && (0xFF == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24)))/* [127:120] */
        {
            /* newMacDa[47:0] = {16'h3333, ParserResult.ipDa[31:0]} */
            new_mac_da[0] = parser_result->l3_s.ip_da.ipv6.ipda_31_0 & 0xFF;
            new_mac_da[1] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 8) & 0xFF;
            new_mac_da[2] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 16) & 0xFF;
            new_mac_da[3] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 24) & 0xFF;
            new_mac_da[4] = 0x33;
            new_mac_da[5] = 0x33;
        }
        else
        {
            new_mac_da[0] = pkt_info->mac_31_to_0 & 0xFF;
            new_mac_da[1] = (pkt_info->mac_31_to_0 >> 8) & 0xFF;
            new_mac_da[2] = (pkt_info->mac_31_to_0 >> 16) & 0xFF;
            new_mac_da[3] = (pkt_info->mac_31_to_0 >> 24) & 0xFF;
            new_mac_da[4] = pkt_info->mac_47_to_32 & 0xFF;
            new_mac_da[5] = (pkt_info->mac_47_to_32 >> 8) & 0xFF;
        }
    }
    else
    {
        if ((PKT_TYPE_IPV4 == packet_type)
                && (0xE == (parser_result->l3_s.ip_da.ipv4.ipda >> 28))/* [31:28] */
                && ds_l2_edit_eth4_w_added->derive_mcast_mac)
        {
            /* newMacDa[47:0] = {24'h01005E, 1'b0, ParserResult.ipDa[22:0]} */
            new_mac_da[0] = parser_result->l3_s.ip_da.ipv4.ipda & 0xFF;
            new_mac_da[1] = (parser_result->l3_s.ip_da.ipv4.ipda >> 8) & 0xFF;
            new_mac_da[2] = (parser_result->l3_s.ip_da.ipv4.ipda >> 16) & 0x7F;
            new_mac_da[3] = 0x5E;
            new_mac_da[4] = 0x00;
            new_mac_da[5] = 0x01;
        }
        else if ((PKT_TYPE_IPV6 == packet_type)
                && (0xFF == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24))/* [127:120] */
                && ds_l2_edit_eth4_w_added->derive_mcast_mac)
        {
            /* newMacDa[47:0] = {16'h3333, ParserResult.ipDa[31:0]} */
            new_mac_da[0] = parser_result->l3_s.ip_da.ipv6.ipda_31_0 & 0xFF;
            new_mac_da[1] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 8) & 0xFF;
            new_mac_da[2] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 16) & 0xFF;
            new_mac_da[3] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 24) & 0xFF;
            new_mac_da[4] = 0x33;
            new_mac_da[5] = 0x33;
        }
        else if ((PKT_TYPE_MCAST_MPLS == packet_type) && ds_l2_edit_eth4_w_added->derive_mcast_mac)
        {
            /* newMacDa[47:0] = {24'h01005E, 1'b0, 23'd0} */
            new_mac_da[0] = 0x0;
            new_mac_da[1] = 0x0;
            new_mac_da[2] = 0x80;
            new_mac_da[3] = 0x5E;
            new_mac_da[4] = 0x00;
            new_mac_da[5] = 0x01;
        }
        else if ((PKT_TYPE_TRILL == packet_type) && ds_l2_edit_eth4_w_added->derive_mcast_mac)
        {
            /* newMacDa[47:0] = {24'h0180C2000040}, ALL-RBridge MAC address*/
            new_mac_da[0] = 0x40;
            new_mac_da[1] = 0x00;
            new_mac_da[2] = 0x00;
            new_mac_da[3] = 0xc2;
            new_mac_da[4] = 0x80;
            new_mac_da[5] = 0x01;
        }
        else if ((L3_TYPE_FCOE == parser_result->layer3_type) && ds_l2_edit_eth4_w_added->derive_mcast_mac)
        {
            /* newMacDa[47:0] = {16'h0EFC, PacketInfo.fcoeOutIndex[7:0], ParserResult.fcoeDid[23:0]} */
            new_mac_da[0] = parser_result->l3_s.ip_da.fcoe.fcoe_did & 0xFF;
            new_mac_da[1] = (parser_result->l3_s.ip_da.fcoe.fcoe_did >> 8) & 0xFF;
            new_mac_da[2] = (parser_result->l3_s.ip_da.fcoe.fcoe_did >> 16) & 0xFF;
            new_mac_da[3] = pkt_info->fcoe_oui_index;
            new_mac_da[4] = 0xFC;
            new_mac_da[5] = 0x0E;
        }
        else
        {
            new_mac_da[0] = ds_l2_edit_eth4_w_added->mac_da29_0 & 0xFF;
            new_mac_da[1] = (ds_l2_edit_eth4_w_added->mac_da29_0 >> 8) & 0xFF;
            new_mac_da[2] = (ds_l2_edit_eth4_w_added->mac_da29_0 >> 16) & 0xFF;
            new_mac_da[3] = (ds_l2_edit_eth4_w_added->mac_da31_30 << 6)
                            | ((ds_l2_edit_eth4_w_added->mac_da29_0 >> 24) & 0xFF);
            new_mac_da[4] = ds_l2_edit_eth4_w_added->mac_da47_32 & 0xFF;
            new_mac_da[5] = (ds_l2_edit_eth4_w_added->mac_da47_32 >> 8) & 0xFF;
        }
    }

    /* VLAN TAG */
    dot1q_en1 = FALSE;
    dot1q_en0 = FALSE;

    if (pkt_info->route_no_l2_edit)/* use DsNextHop VLAN */
    {
        if (pkt_info->interface_vlan_id_en && pkt_info->interface_svlan_tagged)
        {
            dot1q_en1 = TRUE;
            output_svlan_id = pkt_info->interface_vlan_id;
        }
        else if (pkt_info->interface_vlan_id_en && !pkt_info->interface_svlan_tagged)
        {
            dot1q_en0 = TRUE;
            output_cvlan_id = pkt_info->interface_vlan_id;
        }
    }
    else if (ds_l2_edit_eth4_w_added->output_vlan_id_valid)/* use DsL2EditEth VLAN */
    {
        if (ds_l2_edit_eth4_w_added->output_vlan_id_is_svlan)
        {
            dot1q_en1 = TRUE;
            output_svlan_id = ds_l2_edit_eth4_w_added->output_vlan_id;
        }
        else
        {
            dot1q_en0 = TRUE;
            output_cvlan_id = ds_l2_edit_eth4_w_added->output_vlan_id;
        }
    }
    else if (ds_l2_edit_eth4_w_added->output_vlan_id == 0xFFF)
    {
     /*do noting ,no vlan tag add*/
    }
    else if (pkt_info->interface_vlan_id_en)    /* use interface VLAN */
    {
        if (pkt_info->interface_svlan_tagged)
        {
            dot1q_en1 = TRUE;
            output_svlan_id = pkt_info->interface_vlan_id;
        }
        else
        {
            dot1q_en0 = TRUE;
            output_cvlan_id = pkt_info->interface_vlan_id;
        }
    }

    sal_memset(&epe_l2_tpid_ctl, 0, sizeof(epe_l2_tpid_ctl));
    cmd = DRV_IOR(EpeL2TpidCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_tpid_ctl));

    switch (pkt_info->svlan_tpid_index)
    {
        case 0:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid0;
            break;
        case 1:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid1;
            break;
        case 2:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid2;
            break;
        case 3:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid3;
            break;
        default:
            break;
    }

    untag_default_svlan = pkt_info->untag_default_vlan_id
                            && pkt_info->untag_default_svlan
                            && (output_svlan_id == pkt_info->default_vlan_id);

    svlan_tag_en = IS_BIT_SET(pkt_info->dot1_q_en, 1) && dot1q_en1 && (!untag_default_svlan);

    sal_memset(&epe_pkt_proc_ctl, 0, sizeof(epe_pkt_proc_ctl_t));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_ctl));

    if (pkt_info->replace_stag_cos)
    {
        new_stag_cos = pkt_info->mapped_cos;
        new_stag_cfi = pkt_info->mapped_cfi;
    }
    else
    {
        new_stag_cos = pkt_info->source_cos;
        new_stag_cfi = epe_pkt_proc_ctl.always_map_cfi ? pkt_info->mapped_cfi : pkt_info->source_cfi;
    }

    new_svlan_tag = (new_svlan_tpid << 16)
                        | (new_stag_cos << 13)
                        | (new_stag_cfi << 12)
                        | output_svlan_id;

    new_cvlan_tpid = epe_l2_tpid_ctl.cvlan_tpid;

    untag_default_cvlan = pkt_info->untag_default_vlan_id
                            && (!pkt_info->untag_default_svlan)
                            && (output_cvlan_id == pkt_info->default_vlan_id);

    cvlan_tag_en = IS_BIT_SET(pkt_info->dot1_q_en, 0) && dot1q_en0 && (!untag_default_cvlan);
    new_ctag_cfi = pkt_info->ctag_dei_en ? pkt_info->mapped_cfi : 0;

    if (pkt_info->replace_ctag_cos)
    {
        new_ctag_cos = pkt_info->mapped_cos;
    }
    else
    {
        new_ctag_cos = pkt_info->source_cos;
    }

    new_cvlan_tag = (new_cvlan_tpid << 16) | (new_ctag_cos << 13) | (new_ctag_cfi << 12) | output_cvlan_id;

    /* ETHERNET_TYPE_SWITCH */
    if (L2_ETH_SNAP == ds_l2_edit_eth4_w_added->type)
    {
        /* ETHER_SNAP */
        /* Not support SNAP for CAPWAP because EPE Header Edit only processing IP Header Update in first 32 bytes */
        new_snap_length = pkt_info->packet_length + 8 - (!pkt_info->non_crc ? 4 : 0);
        if (!pkt_info->packet_length_adjust_type)
        {
            new_snap_length += pkt_info->packet_length_adjust;
        }
        else
        {
            new_snap_length -= pkt_info->packet_length_adjust;
        }

        sal_memset(&epe_l2_snap_ctl, 0, sizeof(epe_l2_snap_ctl));
        cmd = DRV_IOR(EpeL2SnapCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_snap_ctl));

        mtu_msg->l3_new_header_extra[0] = new_mac_da[5];
        mtu_msg->l3_new_header_extra[1] = new_mac_da[4];
        mtu_msg->l3_new_header_extra[2] = new_mac_da[3];
        mtu_msg->l3_new_header_extra[3] = new_mac_da[2];
        mtu_msg->l3_new_header_extra[4] = new_mac_da[1];
        mtu_msg->l3_new_header_extra[5] = new_mac_da[0];

        mtu_msg->l3_new_header_extra[6] = new_mac_sa[5];
        mtu_msg->l3_new_header_extra[7] = new_mac_sa[4];
        mtu_msg->l3_new_header_extra[8] = new_mac_sa[3];
        mtu_msg->l3_new_header_extra[9] = new_mac_sa[2];
        mtu_msg->l3_new_header_extra[10] = new_mac_sa[1];
        mtu_msg->l3_new_header_extra[11] = new_mac_sa[0];

        if (svlan_tag_en)
        {
            mtu_msg->l3_new_header_extra_len = 26;
            offset = 16;
            /* l3_new_header_extra = {newMacDa[47:0], newMacSa[47:0], newSvlanTag[31:0], newSnapLength[15:0],
                              8'hAA, 9'hAA, 8'h3, EpeL2SnapCtl.ouiValue[23:0], newEtherType[15:0]} */
            mtu_msg->l3_new_header_extra[12] = (new_svlan_tag >> 24) & 0xFF;
            mtu_msg->l3_new_header_extra[13] = (new_svlan_tag >> 16) & 0xFF;
            mtu_msg->l3_new_header_extra[14] = (new_svlan_tag >> 8) & 0xFF;
            mtu_msg->l3_new_header_extra[15] = new_svlan_tag & 0xFF;
        }
        else if (cvlan_tag_en)
        {
            mtu_msg->l3_new_header_extra_len = 26;
            offset = 16;
            /* l3_new_header_extra = {newMacDa[47:0], newMacSa[47:0], newCvlanTag[31:0], newSnapLength[15:0],
                              8'hAA, 9'hAA, 8'h3, EpeL2SnapCtl.ouiValue[23:0], newEtherType[15:0]} */
            mtu_msg->l3_new_header_extra[12] = (new_cvlan_tag >> 24) & 0xFF;
            mtu_msg->l3_new_header_extra[13] = (new_cvlan_tag >> 16) & 0xFF;
            mtu_msg->l3_new_header_extra[14] = (new_cvlan_tag >> 8) & 0xFF;
            mtu_msg->l3_new_header_extra[15] = new_cvlan_tag & 0xFF;
        }
        else
        {
            /* l3_new_header_extra = {newMacDa[47:0], newMacSa[47:0], newSnapLength[15:0],
                              8'hAA, 9'hAA, 8'h3, EpeL2SnapCtl.ouiValue[23:0], newEtherType[15:0]} */
            mtu_msg->l3_new_header_extra_len = 22;
            offset = 12;
        }

        mtu_msg->l3_new_header_extra[offset] = (new_snap_length >> 8) & 0xFF;
        mtu_msg->l3_new_header_extra[offset+1] = new_snap_length & 0xFF;
        mtu_msg->l3_new_header_extra[offset+2] = 0xAA;
        mtu_msg->l3_new_header_extra[offset+3] = 0xAA;
        mtu_msg->l3_new_header_extra[offset+4] = 0x03;
        mtu_msg->l3_new_header_extra[offset+5] = (epe_l2_snap_ctl.oui_value>> 16) & 0xFF;
        mtu_msg->l3_new_header_extra[offset+6] = (epe_l2_snap_ctl.oui_value >> 8) & 0xFF;
        mtu_msg->l3_new_header_extra[offset+7] = epe_l2_snap_ctl.oui_value & 0xFF;
        mtu_msg->l3_new_header_extra[offset+8] = (new_ether_type >> 8) & 0xFF;
        mtu_msg->l3_new_header_extra[offset+9] = new_ether_type & 0xFF;

        parser_result->layer2_type = L2_TYPE_ETHSNAP;
    }
    else
    {
        /* ETHER_V2 */
        mtu_msg->l3_new_header_extra[0] = new_mac_da[5];
        mtu_msg->l3_new_header_extra[1] = new_mac_da[4];
        mtu_msg->l3_new_header_extra[2] = new_mac_da[3];
        mtu_msg->l3_new_header_extra[3] = new_mac_da[2];
        mtu_msg->l3_new_header_extra[4] = new_mac_da[1];
        mtu_msg->l3_new_header_extra[5] = new_mac_da[0];

        mtu_msg->l3_new_header_extra[6] = new_mac_sa[5];
        mtu_msg->l3_new_header_extra[7] = new_mac_sa[4];
        mtu_msg->l3_new_header_extra[8] = new_mac_sa[3];
        mtu_msg->l3_new_header_extra[9] = new_mac_sa[2];
        mtu_msg->l3_new_header_extra[10] = new_mac_sa[1];
        mtu_msg->l3_new_header_extra[11] = new_mac_sa[0];

        if (svlan_tag_en)
        {
            mtu_msg->l3_new_header_extra_len = 18;
            offset = 16;
            /* l3_new_header_extra = {newMacDa[47:0], newMacSa[47:0], newSvlanTag[31:0], newEtherType[15:0]} */
            mtu_msg->l3_new_header_extra[12] = (new_svlan_tag >> 24) & 0xFF;
            mtu_msg->l3_new_header_extra[13] = (new_svlan_tag >> 16) & 0xFF;
            mtu_msg->l3_new_header_extra[14] = (new_svlan_tag >> 8) & 0xFF;
            mtu_msg->l3_new_header_extra[15] = new_svlan_tag & 0xFF;
        }
        else if (cvlan_tag_en)
        {
            mtu_msg->l3_new_header_extra_len = 18;
            offset = 16;
            /* l3_new_header_extra = {newMacDa[47:0], newMacSa[47:0], newCvlanTag[31:0], newEtherType[15:0]} */
            mtu_msg->l3_new_header_extra[header_offset+12] = (new_cvlan_tag >> 24) & 0xFF;
            mtu_msg->l3_new_header_extra[header_offset+13] = (new_cvlan_tag >> 16) & 0xFF;
            mtu_msg->l3_new_header_extra[header_offset+14] = (new_cvlan_tag >> 8) & 0xFF;
            mtu_msg->l3_new_header_extra[header_offset+15] = new_cvlan_tag & 0xFF;
        }
        else
        {
            mtu_msg->l3_new_header_extra_len = 14;
            offset = 12;
            /* l3_new_header_extra = {newMacDa[47:0], newMacSa[47:0], newEtherType[15:0]} */
        }
        mtu_msg->l3_new_header_extra[offset] = (new_ether_type >> 8) & 0xFF;
        mtu_msg->l3_new_header_extra[offset+1] = new_ether_type & 0xFF;

        parser_result->layer2_type = L2_TYPE_ETHV2;
    }

    /* PARSER_RESULT */
    if (svlan_tag_en)
    {
        pkt_info->new_cos = new_stag_cos;
        pkt_info->new_cfi = new_stag_cfi;
    }
    else if (cvlan_tag_en)
    {
        pkt_info->new_cos = new_ctag_cos;
        pkt_info->new_cfi = new_ctag_cfi;
    }
    else
    {
        pkt_info->new_cos = 0;
        pkt_info->new_cfi = 0;
    }

    parser_result->l2_s.mac_da5 = new_mac_da[5];
    parser_result->l2_s.mac_da4 = new_mac_da[4];
    parser_result->l2_s.mac_da3 = new_mac_da[3];
    parser_result->l2_s.mac_da2 = new_mac_da[2];
    parser_result->l2_s.mac_da1 = new_mac_da[1];
    parser_result->l2_s.mac_da0 = new_mac_da[0];

    parser_result->l2_s.mac_sa5 = new_mac_sa[5];
    parser_result->l2_s.mac_sa4 = new_mac_sa[4];
    parser_result->l2_s.mac_sa3 = new_mac_sa[3];
    parser_result->l2_s.mac_sa2 = new_mac_sa[2];
    parser_result->l2_s.mac_sa1 = new_mac_sa[1];
    parser_result->l2_s.mac_sa0 = new_mac_sa[0];

    parser_result->l2_s.layer2_header_protocol = new_ether_type;

    if (svlan_tag_en)
    {
        parser_result->l2_s.svlan_id = output_svlan_id;
        parser_result->l2_s.stag_cos = new_stag_cos;
        parser_result->l2_s.stag_cfi = new_stag_cfi;
        parser_result->l2_s.svlan_id_valid = TRUE;
    }
    else
    {
        parser_result->l2_s.svlan_id = 0;
        parser_result->l2_s.stag_cos = 0;
        parser_result->l2_s.stag_cfi = 0;
        parser_result->l2_s.svlan_id_valid = FALSE;
    }

    if (cvlan_tag_en)
    {
        parser_result->l2_s.cvlan_id = output_cvlan_id;
        parser_result->l2_s.ctag_cos = new_ctag_cos;
        parser_result->l2_s.ctag_cfi = new_ctag_cfi;
        parser_result->l2_s.cvlan_id_valid = TRUE;
    }
    else
    {
        parser_result->l2_s.cvlan_id = 0;
        parser_result->l2_s.ctag_cos = 0;
        parser_result->l2_s.ctag_cfi = 0;
        parser_result->l2_s.cvlan_id_valid = FALSE;
    }

    pkt_info->packet_type = PKT_TYPE_ETHERNETV2;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_epe_layer3_editing_mtu_check
 * Purpose:    perform layer3 mtu check and check sum operations.
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *             mtu_msg  -- pointer to mtu msg struct
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_epe_layer3_editing_mtu_check(epe_in_pkt_t* ipkt, cm_epe_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_pkt_proc_ctl_t epe_pkt_proc_ctl;

    uint8 header_offset = 0;
    uint16 mtu_packet_length = 0;
    uint16 packet_length_adjust = 0;
    uint32 cmd = 0;
    uint8 l4_checksum_valid = FALSE;

    /* MTU_CHECK_AND_CHECK_SUM */
    pkt_info->new_ip_checksum = parser_result->l3_s.ip_sa.ipv4.ip_check_sum;
    mtu_msg->checksum_old_ttl = parser_result->l3_s.ttl;
    mtu_msg->checksum_old_ip_da_31_0 = parser_result->l3_s.ip_da.ipv6.ipda_31_0;
    mtu_msg->checksum_old_ip_da_63_32 = parser_result->l3_s.ip_da.ipv6.ipda_63_32;
    mtu_msg->checksum_old_ip_da_95_64 = parser_result->l3_s.ip_da.ipv6.ipda_95_64;
    mtu_msg->checksum_old_ip_da_127_96 = parser_result->l3_s.ip_da.ipv6.ipda_127_96;
    mtu_msg->checksum_old_ip_sa_31_0 = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
    mtu_msg->checksum_old_ip_sa_63_32 = parser_result->l3_s.ip_sa.ipv6.ipsa_63_32;
    mtu_msg->checksum_old_ip_sa_95_64 = parser_result->l3_s.ip_sa.ipv6.ipsa_95_64;
    mtu_msg->checksum_old_ip_sa_127_96 = parser_result->l3_s.ip_sa.ipv6.ipsa_127_96;
    mtu_msg->checksum_old_l4_dest_port = parser_result->l4_s.l4_dst_port.l4_dest_port;
    mtu_msg->checksum_old_l4_source_port = parser_result->l4_s.l4_src_port.l4_source_port;
    mtu_msg->checksum_is_old_ipv4 = (parser_result->layer3_type == L3_TYPE_IPV4);
    mtu_msg->checksum_is_new_ipv4 = mtu_msg->nat_new_header_valid?
                                    mtu_msg->nat_new_header_is_ipv4 :(parser_result->layer3_type == L3_TYPE_IPV4);

    if ((!pkt_info->discard)
        && mtu_msg->tunnel_mtu_check
        && ((mtu_msg->tunnel_packet_len + mtu_msg->l3_new_header_extra_len) > mtu_msg->tunnel_mtu_size)
        && (mtu_msg->tunnel_packet_len != 0))   /* tunnel mtu check */
    {
        if (!pkt_info->exception_en && pkt_info->mtu_exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 5;
        }

        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_TUNNEL_MTU_CHK_DISCARD;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Tunnel MTU check fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    mtu_packet_length = (pkt_info->packet_length + pkt_info->l3_new_header_len
                        + mtu_msg->l3_new_header_extra_len - (!pkt_info->non_crc ? 4 : 0));
    if (!pkt_info->packet_length_adjust_type)
    {
        mtu_packet_length += pkt_info->packet_length_adjust;
    }
    else
    {
        mtu_packet_length -= pkt_info->packet_length_adjust;
    }

    if (!pkt_info->discard
        && pkt_info->mtu_check_en
        && (mtu_packet_length > pkt_info->mtu_size))  /* interface MTU check, cut throuth */
    {
        if (!pkt_info->exception_en && pkt_info->mtu_exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 5;
        }

        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_INTERFACE_MTU_CHK_DISCARD;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE INTERFACE MTU check fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* IP Checksum for source and destination is mutual ??? */
    /* Note: when new value is equal to old value for all fields, the corresponding incremental checksum is not calcuated*/
    pkt_info->new_ip_check_sum_valid = ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_ip_sa_valid)
                                        || pkt_info->new_ttl_valid || pkt_info->new_dscp_valid || pkt_info->new_ip_da_valid;

    if (pkt_info->new_ip_da_valid)  /* DA */
    {
        pkt_info->new_ip_check_sum = _cm_reclac_ip_checksum(
                                                (mtu_msg->checksum_old_ip_da_31_0 & 0xFFFF),
                                                (pkt_info->new_ip_da & 0xFFFF),
                                                pkt_info->new_ip_check_sum);
        pkt_info->new_ip_check_sum = _cm_reclac_ip_checksum(
                                                ((mtu_msg->checksum_old_ip_da_31_0 >> 16)& 0xFFFF),
                                                ((pkt_info->new_ip_da >> 16) & 0xFFFF),
                                                pkt_info->new_ip_check_sum);
    }

    if ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_ip_sa_valid)  /* SA only IPv4 NAT */
    {
        pkt_info->new_ip_check_sum = _cm_reclac_ip_checksum(
                                                (mtu_msg->checksum_old_ip_sa_31_0 & 0xFFFF),
                                                (pkt_info->share_fields_u.nat.new_ip_sa_31_0 & 0xFFFF),
                                                pkt_info->new_ip_check_sum);
        pkt_info->new_ip_check_sum = _cm_reclac_ip_checksum(
                                                ((mtu_msg->checksum_old_ip_sa_31_0 >> 16) & 0xFFFF),
                                                ((pkt_info->share_fields_u.nat.new_ip_sa_31_0 >> 16) & 0xffff),
                                                pkt_info->new_ip_check_sum);
    }

    if (pkt_info->new_ttl_valid)
    {
        pkt_info->new_ip_check_sum = _cm_reclac_ip_checksum(
                                                MAKE_UINT16(mtu_msg->checksum_old_ttl, 0),
                                                MAKE_UINT16(pkt_info->new_ttl, 0),
                                                pkt_info->new_ip_check_sum);
    }

    if (pkt_info->new_dscp_valid)
    {
        pkt_info->new_ip_check_sum = _cm_reclac_ip_checksum(
                                                MAKE_UINT16(0, (pkt_info->checksum_old_dscp << 2)),
                                                MAKE_UINT16(0, (pkt_info->new_dscp << 2)),
                                                pkt_info->new_ip_check_sum);
    }

    /* ===== bug 4648 ECO begine ==== */
    pkt_info->new_ip_check_sum_valid |= pkt_info->congestion_valid;
    if (pkt_info->congestion_valid)
    {
        pkt_info->new_ip_check_sum = _cm_reclac_ip_checksum(
                                                MAKE_UINT16(0, (pkt_info->checksum_old_ecn << 2)),
                                                0x3,
                                                pkt_info->new_ip_check_sum);
    }
    /* ===== bug 4648 ECO end ==== */

    sal_memset(&epe_pkt_proc_ctl, 0, sizeof(epe_pkt_proc_ctl_t));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_ctl));

    /* L4 checksum */
    l4_checksum_valid = !IS_BIT_SET(parser_result->l3_s.frag_info, 1)
                        && ((parser_result->layer4_type == L4_TYPE_TCP)
                        || ((parser_result->layer4_type == L4_TYPE_UDP)
                        && (parser_result->l4_s.layer4_check_sum != 0)));

    if (((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.pt_enable)
                        && !IS_BIT_SET(parser_result->l3_s.frag_info, 1)
                        && epe_pkt_proc_ctl.pt_udp_checksum_zero_discard
                        && (parser_result->layer4_type == L4_TYPE_UDP)
                        && (parser_result->l4_s.layer4_check_sum == 0)
                        && mtu_msg->checksum_is_old_ipv4
                        && !mtu_msg->checksum_is_new_ipv4)
    {
        /* only for IPv4 to IPv6 */
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_PT_UDP_CHECKSUM_IS_ZERO;
            pkt_info->discard = TRUE;
        }

        if (!pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 7;
        }
    }

    pkt_info->new_l4_checksum_valid = pkt_info->new_l4_checksum_valid
                                      || ((((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_ip_sa_valid)
                                      || ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_l4_source_port_valid)
                                      || mtu_msg->checksum_ip_sa_valid
                                      || pkt_info->new_ip_da_valid
                                      || pkt_info->new_l4_dest_port_valid
                                      || mtu_msg->checksum_ip_da_valid)
                                      && l4_checksum_valid);

    if (mtu_msg->checksum_is_old_ipv4 && mtu_msg->checksum_is_new_ipv4)   /* IPv4(32) to IPv4(32) */
    {
        if (mtu_msg->checksum_ip_da_valid || pkt_info->new_ip_da_valid)
        {
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_da_31_0 & 0xFFFF),
                                                    (pkt_info->new_ip_da & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_da_31_0 >> 16) & 0xFFFF),
                                                    ((pkt_info->new_ip_da >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
        }

        if (mtu_msg->checksum_ip_sa_valid || ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_ip_sa_valid))
        {
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_sa_31_0 & 0xFFFF),
                                                    (pkt_info->share_fields_u.nat.new_ip_sa_31_0 & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_sa_31_0 >> 16) & 0xFFFF),
                                                    ((pkt_info->share_fields_u.nat.new_ip_sa_31_0 >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
        }
    }
    else if (mtu_msg->checksum_is_old_ipv4 && !mtu_msg->checksum_is_new_ipv4) /* IPv4(32) to IPv6(128) */
    {
        if (mtu_msg->checksum_ip_da_valid || pkt_info->new_ip_da_valid)
        {
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_da_31_0 & 0xFFFF),
                                                    (pkt_info->new_ip_da & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_da_31_0 >> 16) & 0xFFFF),
                                                    ((pkt_info->new_ip_da >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    (pkt_info->new_ip_da63_32 & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    ((pkt_info->new_ip_da63_32 >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    (pkt_info->new_ip_da95_64 & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    ((pkt_info->new_ip_da95_64 >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    (pkt_info->new_ip_da127_96 & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    ((pkt_info->new_ip_da127_96 >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
        }

        if (mtu_msg->checksum_ip_sa_valid || ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_ip_sa_valid))
        {
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_sa_31_0 & 0xFFFF),
                                                    (pkt_info->share_fields_u.nat.new_ip_sa_31_0 & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_sa_31_0 >> 16) & 0xFFFF),
                                                    ((pkt_info->share_fields_u.nat.new_ip_sa_31_0 >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    (pkt_info->new_ip_sa63_32 & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    ((pkt_info->new_ip_sa63_32 >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    (pkt_info->new_ip_sa95_64 & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    ((pkt_info->new_ip_sa95_64 >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    (pkt_info->new_ip_sa127_96 & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    0,
                                                    ((pkt_info->new_ip_sa127_96 >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
        }
    }
    else if (!mtu_msg->checksum_is_old_ipv4 && mtu_msg->checksum_is_new_ipv4) /* IPv6(128) to IPv4(32) */
    {
        if (mtu_msg->checksum_ip_da_valid || pkt_info->new_ip_da_valid)
        {
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_da_31_0 & 0xFFFF),
                                                    (pkt_info->new_ip_da & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_da_31_0 >> 16) & 0xFFFF),
                                                    ((pkt_info->new_ip_da >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_da_63_32 & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_da_63_32 >> 16) & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_da_95_64 & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_da_95_64 >> 16) & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_da_127_96 & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_da_127_96 >> 16) & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
        }

        if (mtu_msg->checksum_ip_sa_valid || ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_ip_sa_valid))
        {
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_sa_31_0 & 0xFFFF),
                                                    (pkt_info->share_fields_u.nat.new_ip_sa_31_0 & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_sa_31_0 >> 16) & 0xFFFF),
                                                    ((pkt_info->share_fields_u.nat.new_ip_sa_31_0 >> 16) & 0xFFFF),
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_sa_63_32 & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_sa_63_32 >> 16) & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_sa_95_64 & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_sa_95_64 >> 16) & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    (mtu_msg->checksum_old_ip_sa_127_96 & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
            pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    ((mtu_msg->checksum_old_ip_sa_127_96 >> 16) & 0xFFFF),
                                                    0,
                                                    pkt_info->new_l4_check_sum);
        }
    }/*  IPv6(128) to IPv6(128),not support, keep old value for PTP checksum*/


    if (pkt_info->new_l4_dest_port_valid)
    {
        pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    mtu_msg->checksum_old_l4_dest_port,
                                                    pkt_info->new_l4_dest_port,
                                                    pkt_info->new_l4_check_sum);
    }

    if ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_l4_source_port_valid)
    {
        pkt_info->new_l4_check_sum = _cm_reclac_ip_checksum(
                                                    mtu_msg->checksum_old_l4_source_port,
                                                    pkt_info->share_fields_u.nat.new_l4_source_port,
                                                    pkt_info->new_l4_check_sum);
    }

    /* update ParserResult */
    if ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_l4_source_port_valid) /* move to IPE Header Adjust */
    {
        parser_result->l4_s.l4_src_port.l4_source_port = pkt_info->share_fields_u.nat.new_l4_source_port;
    }

    if ((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.new_ip_sa_valid)
    {
        parser_result->l3_s.ip_sa.ipv4.ipsa = pkt_info->share_fields_u.nat.new_ip_sa_31_0;
    }

    if (mtu_msg->mpls_operation)
    {
        mtu_msg->l3_header_added = TRUE;
        parser_result->l3_s.ip_da.mpls.mpls_label3 = mtu_msg->mpls_label_update3;
        parser_result->l3_s.ip_da.mpls.mpls_label2 = mtu_msg->mpls_label_update2;
        parser_result->l3_s.ip_da.mpls.mpls_label1 = mtu_msg->mpls_label_update1;
        parser_result->l3_s.ip_da.mpls.mpls_label0 = mtu_msg->mpls_label_update0;
    }
    else if (mtu_msg->nat_operation)
    {
        mtu_msg->l3_header_added = TRUE;

        if (!((SHARE_TYPE_NAT == pkt_info->share_type) && pkt_info->share_fields_u.nat.pt_enable))
        {
            parser_result->l3_s.ip_da.ipv4.ipda = mtu_msg->ip_da_31_0_update;
            parser_result->l4_s.l4_dst_port.l4_dest_port = mtu_msg->l4_dest_port_update;
        }
        else if (mtu_msg->checksum_is_new_ipv4)
        {
            parser_result->l4_s.is_tcp = mtu_msg->is_tcp_update;
            parser_result->l4_s.is_udp = mtu_msg->is_udp_update;
            parser_result->layer3_type = mtu_msg->layer3_type_update;
            parser_result->l3_s.ip_options = mtu_msg->ip_options_update;
            parser_result->l3_s.ip_header_error = mtu_msg->ip_header_error_update;
            parser_result->l3_s.ip_da.ipv4.ipda = mtu_msg->ip_da_31_0_update;
            parser_result->l3_s.ip_sa.ipv4.ip_check_sum = mtu_msg->ip_checksum_update;
            parser_result->l3_s.ip_sa.ipv4.ipsa = mtu_msg->ip_sa_31_0_update;
            parser_result->l4_s.layer4_info_mapped = mtu_msg->layer4_info_mapped_update;
            /* syncup 2012-5-16 according to work copy version */
            /* parser_result->l3_s.frag_info = mtu_msg->frag_info_update; */
            parser_result->l3_s.tos.ip_tos = (parser_result->l3_s.tos.ip_tos & 0x3) | (mtu_msg->tos_update & 0xFC);
            parser_result->l4_s.l4_dst_port.l4_dest_port = mtu_msg->l4_dest_port_update;
        }
        else
        {
            parser_result->l4_s.is_tcp = mtu_msg->is_tcp_update;
            parser_result->l4_s.is_udp = mtu_msg->is_udp_update;
            /* syncup 2012-5-16 according to work copy version */
            /* parser_result->l3_s.frag_info = mtu_msg->frag_info_update; */
            parser_result->layer3_type = mtu_msg->layer3_type_update;
            parser_result->l3_s.ip_options = mtu_msg->ip_options_update;
            parser_result->l3_s.ip_header_error = mtu_msg->ip_header_error_update;
            parser_result->l3_s.ip_da.ipv6.ipda_31_0 = mtu_msg->ip_da_31_0_update;
            parser_result->l3_s.ip_da.ipv6.ipda_63_32 = mtu_msg->ip_da_63_32_update;
            parser_result->l3_s.ip_da.ipv6.ipda_95_64 = mtu_msg->ip_da_95_64_update;
            parser_result->l3_s.ip_da.ipv6.ipda_127_96 = mtu_msg->ip_da_127_96_update;
            parser_result->l3_s.ip_sa.ipv6.ipsa_31_0 = mtu_msg->ip_sa_31_0_update;
            parser_result->l3_s.ip_sa.ipv6.ipsa_63_32 = mtu_msg->ip_sa_63_32_update;
            parser_result->l3_s.ip_sa.ipv6.ipsa_95_64 = mtu_msg->ip_sa_95_64_update;
            parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 = mtu_msg->ip_sa_127_96_update;
            parser_result->l4_s.layer4_info_mapped = mtu_msg->layer4_info_mapped_update;
            parser_result->l3_s.tos.ip_tos = mtu_msg->tos_update;
            parser_result->l3_s.ipv6_flow_label = mtu_msg->ipv6_flow_label_update;
            parser_result->l4_s.l4_dst_port.l4_dest_port = mtu_msg->l4_dest_port_update;
        }
    }
    else if (mtu_msg->tunnelv4_operation)
    {
        mtu_msg->l3_header_added = TRUE;

        /* ParserResult->layer4UserType[3:0] =; */
        parser_result->l4_s.is_tcp = mtu_msg->is_tcp_update;
        parser_result->l4_s.is_udp = mtu_msg->is_udp_update;
        parser_result->layer3_type = mtu_msg->layer3_type_update;
        parser_result->l3_s.ip_options = mtu_msg->ip_options_update;
        parser_result->l3_s.ip_header_error = mtu_msg->ip_header_error_update;
        parser_result->l3_s.ip_da.ipv4.ipda = mtu_msg->ip_da_31_0_update;
        parser_result->l3_s.ip_sa.ipv4.ip_check_sum = mtu_msg->ip_checksum_update;
        parser_result->l3_s.ip_sa.ipv4.ipsa = mtu_msg->ip_sa_31_0_update;
        parser_result->l4_s.layer4_info_mapped = mtu_msg->layer4_info_mapped_update;
        parser_result->l3_s.frag_info = mtu_msg->frag_info_update;
        parser_result->l3_s.tos.ip_tos = (parser_result->l3_s.tos.ip_tos & 0x3) | (mtu_msg->tos_update & 0xFC);/* ECN ??? */
    }
    else if (mtu_msg->flex_operation)
    {
        mtu_msg->l3_header_added = TRUE;
        parser_result->layer3_type = mtu_msg->layer3_type_update;
    }
    else if (mtu_msg->tunnelv6_operation)
    {
        mtu_msg->l3_header_added = TRUE;

        parser_result->l4_s.is_tcp = mtu_msg->is_tcp_update;
        parser_result->l4_s.is_udp = mtu_msg->is_udp_update;
        parser_result->layer3_type = mtu_msg->layer3_type_update;
        parser_result->l3_s.ip_options = mtu_msg->ip_options_update;
        parser_result->l3_s.ip_header_error = mtu_msg->ip_header_error_update;
        parser_result->l3_s.ip_da.ipv6.ipda_31_0 = mtu_msg->ip_da_31_0_update;
        parser_result->l3_s.ip_da.ipv6.ipda_63_32 = mtu_msg->ip_da_63_32_update;
        parser_result->l3_s.ip_da.ipv6.ipda_95_64 = mtu_msg->ip_da_95_64_update;
        parser_result->l3_s.ip_da.ipv6.ipda_127_96 = mtu_msg->ip_da_127_96_update;
        parser_result->l3_s.ip_sa.ipv6.ipsa_31_0 = mtu_msg->ip_sa_31_0_update;
        parser_result->l3_s.ip_sa.ipv6.ipsa_63_32 = mtu_msg->ip_sa_63_32_update;
        parser_result->l3_s.ip_sa.ipv6.ipsa_95_64 = mtu_msg->ip_sa_95_64_update;
        parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 = mtu_msg->ip_sa_127_96_update;
        parser_result->l4_s.layer4_info_mapped = mtu_msg->layer4_info_mapped_update;
        parser_result->l3_s.frag_info = mtu_msg->frag_info_update;
        parser_result->l3_s.tos.ip_tos = mtu_msg->tos_update;
        parser_result->l3_s.ipv6_flow_label = mtu_msg->ipv6_flow_label_update;

    }
    else if (mtu_msg->trill_operation)
    {
        mtu_msg->l3_header_added = TRUE;

        parser_result->l3_s.ip_da.trill.trill_version = mtu_msg->trill_version_update & 0x3;
        parser_result->l3_s.ip_sa.trill.ingress_nick_name = mtu_msg->ingress_nick_name_update;
        parser_result->l3_s.ip_da.trill.egress_nick_name = mtu_msg->egress_nick_name_update;
        parser_result->l3_s.ip_da.trill.trill_multicast = mtu_msg->trill_multicast_update;
        parser_result->layer3_type = mtu_msg->layer3_type_update;
    }

    if (mtu_msg->l3_header_added)
    {
        parser_result->layer2_type = L2_TYPE_NONE;
        parser_result->l2_s.mac_da5 = 0;
        parser_result->l2_s.mac_da4 = 0;
        parser_result->l2_s.mac_da3 = 0;
        parser_result->l2_s.mac_da2 = 0;
        parser_result->l2_s.mac_da1 = 0;
        parser_result->l2_s.mac_da0 = 0;
        parser_result->l2_s.mac_sa5 = 0;
        parser_result->l2_s.mac_sa4 = 0;
        parser_result->l2_s.mac_sa3 = 0;
        parser_result->l2_s.mac_sa2 = 0;
        parser_result->l2_s.mac_sa1 = 0;
        parser_result->l2_s.mac_sa0 = 0;
        parser_result->l2_s.svlan_id_valid = FALSE;
        parser_result->l2_s.cvlan_id_valid = FALSE;
        parser_result->l2_s.stag_cos = 0;
        parser_result->l2_s.stag_cfi = 0;
        parser_result->l2_s.ctag_cos = 0;
        parser_result->l2_s.ctag_cfi = 0;
        parser_result->l2_s.layer2_header_protocol = 0;
    }

    if (pkt_info->logic_port_check )
    {
        if((pkt_info->logic_src_port == pkt_info->logic_dest_port) && !pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_LOGIC_PORT_CHK_DISCARD;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE LogicPortCheck fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }
    else if (pkt_info->port_reflective_discard)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_PORT_REFLECTIVE_CHK_DISCARD;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Port Reflective check fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (pkt_info->l3_new_header_len != 127)
    {
        header_offset = pkt_info->l3_new_header_len;
        if (mtu_msg->l3_new_header_extra_len != 0)
        {
            if (pkt_info->l3_new_header_len != 0)
            {
                sal_memcpy(pkt_info->l3_header + header_offset, mtu_msg->l3_new_header_extra, mtu_msg->l3_new_header_extra_len);
            }
            else
            {
                sal_memcpy(pkt_info->l3_header, mtu_msg->l3_new_header_extra, mtu_msg->l3_new_header_extra_len);
            }
        }

        pkt_info->l3_new_header_len += mtu_msg->l3_new_header_extra_len;

        packet_length_adjust = func_packet_length_adjust_add(ipkt, pkt_info->l3_new_header_len);
        pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
        pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;

        pkt_info->ptp_offset += pkt_info->l3_new_header_len;
    }

    return DRV_E_NONE;
}
/****************************************************************************
 * Name:      cm_epe_layer3_editing_handle
 * Purpose:   perform Layer3 editing, include NAT,MPLS switching,tunnel
              encapsulation and flexible layer3 editing.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32
cm_epe_layer3_editing_handle(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    ds_l3_edit_mpls8_w_t ds_l3_edit_mpls8_w;
    ds_l3_edit_nat8_w_t ds_l3_edit_nat8_w;
    ds_l3_edit_tunnel_v6_t ds_l3_edit_tunnel_v6;
    ds_l3_edit_tunnel_v4_t ds_l3_edit_tunnel_v4;
    ds_l3_edit_flex_t ds_l3_edit_flex;
    ds_l2_edit_eth4_w_t ds_l2_edit_eth4_w_added;
    ds_l3_edit_tunnel_v6_ipda_79_0_t ds_l3_edit_tunnel_v6_ipda_79_0;

    ds_l2_edit_eth4_w_t* p_ds_l2_edit_eth4_w = NULL;
    ds_l2_edit_eth8_w_t* p_ds_l2_edit_eth8_w = NULL;

    ds_l3_edit_mpls4_w_t* p_ds_l3_edit_mpls4_w = NULL;
    ds_l3_edit_mpls8_w_t* p_ds_l3_edit_mpls8_w = NULL;

    cm_epe_mtu_msg_t cm_epe_mtu_msg;

    uint8 l3_rewrite_type = 0, l2_rewrite_type = 0;
    uint8* p_l3edit = NULL;
    uint8* p_l2edit = NULL;
    uint32 nat_mode = 0;
    uint8 lb_enable = FALSE;
    uint8 l2_header_added = FALSE;
    uint8 extra_hdr_type = 0;
    uint8 is_end = FALSE;
    uint8 l3_new_header_extra[32] = {0};

    sal_memset(&ds_l3_edit_mpls8_w, 0, sizeof(ds_l3_edit_mpls8_w_t));
    sal_memset(&ds_l3_edit_nat8_w, 0, sizeof(ds_l3_edit_nat8_w_t));
    sal_memset(&ds_l3_edit_tunnel_v6, 0, sizeof(ds_l3_edit_tunnel_v6_t));
    sal_memset(&ds_l3_edit_tunnel_v4, 0, sizeof(ds_l3_edit_tunnel_v4_t));
    sal_memset(&ds_l3_edit_flex, 0, sizeof(ds_l3_edit_flex_t));
    sal_memset(&cm_epe_mtu_msg, 0, sizeof(cm_epe_mtu_msg));


    /* OLD_L4_CHECKSUM */
    if (pkt_info->ds_l3_edit_exist)
    {
        p_l3edit = pkt_info->l3_edit;
    }
    else
    {
        p_l3edit = pkt_info->l3_edit;
        sal_memset(p_l3edit,0,sizeof(ds_l3_edit_mpls8_w));
    }

    if (pkt_info->ds_l2_edit_exist)
    {
        p_l2edit = pkt_info->l2_edit;
    }
    else
    {
        p_l2edit = pkt_info->l2_edit;
        sal_memset(p_l2edit,0,sizeof(ds_l2_edit_eth8_w_t));
    }

    l3_rewrite_type = ((ds_l3_edit_mpls8_w_t *)p_l3edit)->l3_rewrite_type;
    pkt_info->l3_new_header_len = 0;

    /* bit number   159        80 79       0   */
    /*               |   ptr0    |    ptr1 |   */
    /*               |   ptr2    |    ptr3 |   */
    /*               |   ptr4    |    ptr5 |   */

    /* get layer3RewriteType */
    if (pkt_info->l3_edit_ptr_bit0)
    {
        p_l3edit = p_l3edit + sizeof(ds_l3_edit_mpls4_w_t);
        p_ds_l3_edit_mpls4_w = (ds_l3_edit_mpls4_w_t *)p_l3edit;
        p_ds_l3_edit_mpls8_w = (ds_l3_edit_mpls8_w_t *)p_l3edit;
        l3_rewrite_type = p_ds_l3_edit_mpls4_w->l3_rewrite_type;

        /* DsL3Edit4W: ptr is odd - [79:0] */
        switch(l3_rewrite_type)
        {
            case L3_REW_MPLS_4W:
                sal_memcpy(&ds_l3_edit_mpls8_w, p_l3edit, sizeof(ds_l3_edit_mpls4_w_t));
                break;
            case L3_REW_NAT_4W:
                sal_memcpy(&ds_l3_edit_nat8_w, p_l3edit, sizeof(ds_l3_edit_nat4_w_t));
                break;
            default:
                break;
        }
    }
    else
    {
        p_ds_l3_edit_mpls8_w = (ds_l3_edit_mpls8_w_t *)p_l3edit;
        l3_rewrite_type = p_ds_l3_edit_mpls8_w->l3_rewrite_type;

        if ((L3_REW_MPLS_8W == l3_rewrite_type)
            || (L3_REW_NAT_8W == l3_rewrite_type)
            || (L3_REW_TUNNEL_V4 == l3_rewrite_type)
            || (L3_REW_TUNNEL_V6 == l3_rewrite_type)
            || (L3_REW_FLEX == l3_rewrite_type))
        {
            /* DsL3Edit8W */
            switch (l3_rewrite_type)
            {
                case L3_REW_MPLS_8W:
                    sal_memcpy(&ds_l3_edit_mpls8_w, p_l3edit, sizeof(ds_l3_edit_mpls8_w_t));
                    break;
                case L3_REW_NAT_8W:
                    sal_memcpy(&ds_l3_edit_nat8_w, p_l3edit, sizeof(ds_l3_edit_nat8_w_t));
                    break;
                case L3_REW_TUNNEL_V4:
                    sal_memcpy(&ds_l3_edit_tunnel_v4, p_l3edit, sizeof(ds_l3_edit_tunnel_v4_t));
                    break;
                case L3_REW_TUNNEL_V6:
                    sal_memcpy(&ds_l3_edit_tunnel_v6, p_l3edit, sizeof(ds_l3_edit_tunnel_v6_t));
                    break;
                case L3_REW_FLEX:
                    sal_memcpy(&ds_l3_edit_flex, p_l3edit, sizeof(ds_l3_edit_flex_t));
                    break;
                default:
                    break;
            }
        }
        else
        {
            /* DsL3Edit4W: ptr is even - [159:80] */
            switch(l3_rewrite_type)
            {
                case L3_REW_MPLS_4W:
                    sal_memcpy(&ds_l3_edit_mpls8_w, p_l3edit, sizeof(ds_l3_edit_mpls4_w_t));
                    break;
                case L3_REW_NAT_4W:
                    sal_memcpy(&ds_l3_edit_nat8_w, p_l3edit, sizeof(ds_l3_edit_nat4_w_t));
                    break;
                default:
                    break;
            }
        }
    }

    pkt_info->l3_rewrite_type = l3_rewrite_type;

    if (!pkt_info->discard
        && (((DS_TYPE_DISCARD == p_ds_l3_edit_mpls8_w->ds_type)
        && p_ds_l3_edit_mpls8_w->etree_leaf_en
        && (pkt_info->rx_oam_type == OAM_NONE))
        || ((DS_TYPE_DISCARD == p_ds_l3_edit_mpls8_w->ds_type)
        && !p_ds_l3_edit_mpls8_w->etree_leaf_en)))
    {
        pkt_info->discard_type = EPE_DISCARD_DS_L3_EDIT_DATA_VIOLATE_1;
        pkt_info->discard = TRUE;

        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Layer3 edit discardPacket!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }

    if (!pkt_info->discard
        && (pkt_info->ds_l3_edit_exist
        && (p_ds_l3_edit_mpls8_w->is_met
        || p_ds_l3_edit_mpls8_w->is_nexthop
        || (DS_TYPE_L3EDIT != p_ds_l3_edit_mpls8_w->ds_type)))
        && !pkt_info->bypass_all)
    {
        pkt_info->discard_type = EPE_DISCARD_DS_L3_EDIT_DATA_VIOLATE_2;
        pkt_info->discard = TRUE;

        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Layer3 edit discardPacket!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }

    is_end = (pkt_info->ds_l3_edit_exist
             && (p_ds_l3_edit_mpls8_w->is_met
             || p_ds_l3_edit_mpls8_w->is_nexthop
             || (DS_TYPE_L3EDIT != p_ds_l3_edit_mpls8_w->ds_type)))
             || pkt_info->bypass_all;

    /* DS_L3_EDIT_ERROR_SWITCH */
    if (is_end)
    {
        return DRV_E_NONE;
    }

    /* DISCARD_SWITCH */
    if (!pkt_info->discard)
    {
        /* LAYER3_REWRITE_TYPE */
        if (pkt_info->from_cpu_or_oam)
        {
            pkt_info->section_lm_exp = pkt_info->source_cos;   /* default use OAMEngine MPLS Exp */
        }

        /* get layer2RewriteType */
        if (pkt_info->l2_edit_ptr_bit0)
        {
            p_ds_l2_edit_eth4_w = (ds_l2_edit_eth4_w_t *)(p_l2edit + sizeof(ds_l2_edit_eth4_w_t));
            l2_rewrite_type = p_ds_l2_edit_eth4_w->l2_rewrite_type;
        }
        else
        {
            p_ds_l2_edit_eth8_w = (ds_l2_edit_eth8_w_t *)(p_l2edit);
            l2_rewrite_type = p_ds_l2_edit_eth8_w->l2_rewrite_type;
        }

        if (L2_REW_ETH_8W == l2_rewrite_type)
        {
            extra_hdr_type = (p_ds_l2_edit_eth8_w->extra_header_type1_1 << 1)
                                | p_ds_l2_edit_eth8_w->extra_header_type0_0;

            if (EXTRA_HEADER_TYPE_ETHERNET == extra_hdr_type)
            {
                l2_header_added = TRUE;
                /* DsL2EditEth4WAdded = offset c, 10, 14 of DsL2EditEth8W */
                sal_memset(&ds_l2_edit_eth4_w_added, 0, sizeof(ds_l2_edit_eth4_w_t));
                sal_memcpy(&ds_l2_edit_eth4_w_added, p_l2edit + sizeof(ds_l2_edit_eth4_w_t),
                            sizeof(ds_l2_edit_eth4_w_t));
            }
            else if ((EXTRA_HEADER_TYPE_MPLS == extra_hdr_type)
                    && (L3_REW_MPLS_4W == l3_rewrite_type))
            {
                /* DsL3EditMpls8w = {DsL3EditMpls4w, offset c,10,14 of DsL2EditEth8W} */
                sal_memset(&ds_l3_edit_mpls8_w, 0, sizeof(ds_l3_edit_mpls8_w_t));
                sal_memcpy(&ds_l3_edit_mpls8_w, p_l3edit, sizeof(ds_l3_edit_mpls4_w_t));
                sal_memcpy(((uint8*)(&ds_l3_edit_mpls8_w)) + sizeof(ds_l3_edit_mpls4_w_t),
                            p_l2edit + sizeof(ds_l2_edit_eth4_w_t),sizeof(ds_l2_edit_eth4_w_t));
            }
            else if ((EXTRA_HEADER_TYPE_MPLS == extra_hdr_type)
                    && !pkt_info->ds_l3_edit_exist)
            {
                sal_memset(&ds_l3_edit_mpls8_w, 0, sizeof(ds_l3_edit_mpls4_w_t));
                /* used as DsL3EditMpls8W label2/3 */
                sal_memcpy(((uint8*)(&ds_l3_edit_mpls8_w)) + sizeof(ds_l3_edit_mpls4_w_t),
                            p_l2edit + sizeof(ds_l2_edit_eth4_w_t),sizeof(ds_l2_edit_eth4_w_t));
                l3_rewrite_type = L3_REW_MPLS_8W;
            }
            else if (L3_REW_TUNNEL_V6 == l3_rewrite_type)
            {
                /* combine DsL3EditTunnelV6 and IP part of DsL2EditEth8W when DsL3EditTunnelV6 and DsL2EditEth8W */
                ds_l3_edit_tunnel_v6_ipda_79_0.ipda_31_0 = p_ds_l2_edit_eth8_w->ip_da31_0;
                ds_l3_edit_tunnel_v6_ipda_79_0.ipda_63_32 = p_ds_l2_edit_eth8_w->ip_da63_32;
                ds_l3_edit_tunnel_v6_ipda_79_0.ipda_79_64 = (p_ds_l2_edit_eth8_w->ip_da79_79 << 15)
                                                                | p_ds_l2_edit_eth8_w->ip_da78_64;
                cm_epe_mtu_msg.p_ds_l3_edit_tunnel_v6_ipda_79_0 = &ds_l3_edit_tunnel_v6_ipda_79_0;
            }
        }

        cm_epe_mtu_msg.l2_header_added = l2_header_added;
        cm_epe_mtu_msg.tunnel_mtu_check = pkt_info->tunnel_mtu_check; /* temp */
        cm_epe_mtu_msg.tunnel_mtu_size = pkt_info->tunnel_mtu_size; /* temp */

        cm_epe_mtu_msg.tunnel_packet_len = pkt_info->packet_length - (!pkt_info->non_crc ? 4 : 0);
        if (!pkt_info->packet_length_adjust_type)
        {
            cm_epe_mtu_msg.tunnel_packet_len = cm_epe_mtu_msg.tunnel_packet_len + pkt_info->packet_length_adjust;
        }
        else
        {
            cm_epe_mtu_msg.tunnel_packet_len = cm_epe_mtu_msg.tunnel_packet_len - pkt_info->packet_length_adjust;
        }

        cm_epe_mtu_msg.tunnel_dont_frag = parser_result->l3_s.dont_frag; /* temp */
        cm_epe_mtu_msg.first_fragment = !IS_BIT_SET(parser_result->l3_s.frag_info, 1); /* temp */

        cm_epe_mtu_msg.l3_new_header_extra_len = 0;

        nat_mode = ds_l3_edit_nat8_w.nat_mode;
        lb_enable = ds_l3_edit_nat8_w.replace_l4_dest_port;

        pkt_info->new_ip_da_valid = FALSE;
        pkt_info->new_l4_dest_port_valid = FALSE;

        cm_epe_mtu_msg.no_operation = (L3_REW_NONE == l3_rewrite_type);
        cm_epe_mtu_msg.mpls_operation = (L3_REW_MPLS_4W == l3_rewrite_type || L3_REW_MPLS_8W == l3_rewrite_type);
        cm_epe_mtu_msg.nat_operation = ((L3_REW_NAT_4W == l3_rewrite_type || L3_REW_NAT_8W == l3_rewrite_type) && nat_mode);
        cm_epe_mtu_msg.tunnelv4_operation = (L3_REW_TUNNEL_V4 == l3_rewrite_type);
        cm_epe_mtu_msg.flex_operation = (L3_REW_FLEX == l3_rewrite_type);
        cm_epe_mtu_msg.tunnelv6_operation = (L3_REW_TUNNEL_V6 == l3_rewrite_type);
        cm_epe_mtu_msg.loopback_operation = ((L3_REW_NAT_4W == l3_rewrite_type || L3_REW_NAT_8W == l3_rewrite_type) && !nat_mode && lb_enable);
        cm_epe_mtu_msg.trill_operation = ((L3_REW_NAT_4W == l3_rewrite_type || L3_REW_NAT_8W == l3_rewrite_type) && !nat_mode && !lb_enable);
        cm_epe_mtu_msg.l3_new_header_extra_len = 0;

        if (l2_header_added)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer3 Editing Process: Add L2 Header");
            cm_epe_mtu_msg.l3_new_header_extra = l3_new_header_extra;
            DRV_IF_ERROR_RETURN(_cm_epe_layer3_editing_l2_eth_add(ipkt, &ds_l2_edit_eth4_w_added, &cm_epe_mtu_msg));
        }

        if (cm_epe_mtu_msg.no_operation)
        {
            /* to MTU_CHECK_AND_CHECKSUM */
        }
        else if (cm_epe_mtu_msg.mpls_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer3 Editing Process: MPLS Operate");
            DRV_IF_ERROR_RETURN(_cm_epe_layer3_editing_mpls(ipkt, &ds_l3_edit_mpls8_w, &cm_epe_mtu_msg));
        }
        else if (cm_epe_mtu_msg.nat_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer3 Editing Process: Nat Operate");
            DRV_IF_ERROR_RETURN(_cm_epe_layer3_editing_nat(ipkt, &ds_l3_edit_nat8_w, &cm_epe_mtu_msg));
        }
        else if (cm_epe_mtu_msg.tunnelv4_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer3 Editing Process: Tunnelv4 Operate");
            DRV_IF_ERROR_RETURN(_cm_epe_layer3_editing_tunnelv4(ipkt, &ds_l3_edit_tunnel_v4, &cm_epe_mtu_msg));
        }
        else if (cm_epe_mtu_msg.flex_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer3 Editing Process: Flex Operate");
            DRV_IF_ERROR_RETURN(_cm_epe_layer3_editing_flex(ipkt, &ds_l3_edit_flex,&cm_epe_mtu_msg));
        }
        else if (cm_epe_mtu_msg.tunnelv6_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer3 Editing Process: Tunnelv6 Operate");
            DRV_IF_ERROR_RETURN(_cm_epe_layer3_editing_tunnelv6(ipkt, &ds_l3_edit_tunnel_v6, &cm_epe_mtu_msg));
        }
        else if (cm_epe_mtu_msg.loopback_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer3 Editing Process: LoopBack Operate");
            DRV_IF_ERROR_RETURN(_cm_epe_layer3_editing_loopback(ipkt, &ds_l3_edit_nat8_w));
        }
        else if (cm_epe_mtu_msg.trill_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer3 Editing Process: Trill Operate");
            DRV_IF_ERROR_RETURN(_cm_epe_layer3_editing_trill(ipkt, &ds_l3_edit_nat8_w,&cm_epe_mtu_msg));
        }
    }

    DRV_IF_ERROR_RETURN(_cm_epe_layer3_editing_mtu_check(ipkt, &cm_epe_mtu_msg));
    return DRV_E_NONE;
}

