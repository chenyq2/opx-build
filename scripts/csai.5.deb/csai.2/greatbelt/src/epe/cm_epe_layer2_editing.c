/****************************************************************************
 * cm_epe_layer2_editing.c  Provides EPE l2edit function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-10-23.
 * Reason:       First Create.
 *
 * Revision:     V1.0.
 * Author:       JiaK.
 * Date:         2010-11-22.
 * Reason:       Sync spec Revision 5.0.0.
 *
 * Revision:     V2.0.
 * Author:       JiaK.
 * Date:         2011-04-11.
 * Reason:       Sync spec Revision 3.0.3.
 *
 * Revision:     V4.2.1
 * Author:       JiaK.
 * Date:         2011-06-30.
 * Reason:       Sync spec revision 4.2.1.
 *
 * Revision:     V4.3.0
 * Author:       JiaK.
 * Date:         2011-07-11.
 * Reason:       Sync spec revision 4.3.0.
 *
 * Revision:     V4.7.1
 * Author:       JiaK.
 * Date:         2011-07-28.
 * Reason:       Sync spec revision 4.7.1.
 *
 * Revision:     V4.28
 * Author:       JiaK.
 * Date:         2011-09-28.
 * Reason:       Sync spec revision 4.28.
 *
 * Revision:     V4.29.3
 * Author:       JiaK.
 * Date:         2011-10-10.
 * Reason:       Sync spec revision 4.29.3
 *
 * Revision:     V4.31.0
 * Author:       JiaK.
 * Date:         2011-10-22.
 * Reason:       sync spec to v4.31.0
 *
 * Revision:     V5.1.0
 * Author:       JiaK.
 * Date:         2011-12-9.
 * Reason:       sync spec to v5.1.0
 *
 * Revision:     V5.6.0
 * Author:       JiaK.
 * Date:         2012-01-7.
 * Reason:       sync spec to v5.6.0
 *
 * Revision:     V5.9.0
 * Author:       JiaK.
 * Date:         2012-01-19.
 * Reason:       sync spec to v5.9.0.
 *
 * Revision:     V5.9.1
 * Author:       Wangcy.
 * Date:         2012-02-04.
 * Reason:       sync spec to v5.9.1
 *
 * Revision:     V5.11.0
 * Author:       Wangcy.
 * Date:         2012-03-01.
 * Reason:       sync spec to v5.11.0
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/

#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"


/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
struct epe_l2_mac_sa_tmp_s
{
    uint32 rsv1                                 :16;
    uint32 mac_sa_h                             :16;

    uint32 mac_sa_l                             :24;
    uint32 rsv2                                 :8;
};
typedef struct epe_l2_mac_sa_tmp_s epe_l2_mac_sa_tmp_t;

struct epe_l2_edit_input_info_s
{
    uint32 vlan_encode_en                       :1;
    uint32 mux_length_type                      :2;
    uint32 encode_vlan_tag_63_to_32;
    uint32 encode_vlan_tag_31_to_0;
};
typedef struct epe_l2_edit_input_info_s epe_l2_edit_input_info_t;

struct cm_epe_l2_edit_mtu_msg_s
{
    uint32 layer2_type_update               :4;
    uint32 mac_da0_update                   :8;
    uint32 mac_da1_update                   :8;
    uint32 mac_da2_update                   :8;
    uint32 mac_da3_update                   :8;
    uint32 mac_da4_update                   :8;
    uint32 mac_da5_update                   :8;
    uint32 mac_sa0_update                   :8;
    uint32 mac_sa1_update                   :8;
    uint32 mac_sa2_update                   :8;
    uint32 mac_sa3_update                   :8;
    uint32 mac_sa4_update                   :8;
    uint32 mac_sa5_update                   :8;
    uint32 layer2_header_protocol_upate     :16;
    uint32 svlan_id_update                  :12;
    uint32 stag_cos_update                  :3;
    uint32 stag_cfi_update                  :1;
    uint32 cvlan_id_update                  :12;
    uint32 ctag_cos_update                  :3;
    uint32 ctag_cfi_update                  :1;
    uint32 mac_da_en_update                 :1;
    uint32 mac_sa_en_update                 :1;
    uint32 svlan_id_valid_update            :1;
    uint32 cvlan_id_valid_update            :1;
    uint32 output_svlan_id                  :12;
    uint32 output_cvlan_id                  :12;
};
typedef struct cm_epe_l2_edit_mtu_msg_s cm_epe_l2_edit_mtu_msg_t;

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
extern uint16 func_packet_length_adjust_add(epe_in_pkt_t* ipkt, uint8 a);
extern uint16 func_packet_length_adjust_subtract(epe_in_pkt_t* ipkt, uint8 a);
/****************************************************************************
 * Name:      _cm_epe_layer2_editing_loopback
 * Purpose:   perform layer2 loopback editing.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_layer2_editing_loopback(epe_in_pkt_t* ipkt, ds_l2_edit_loopback_t* p_ds_l2_edit_loopback)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;

    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* LOOPBACK_FIELDS */
    pkt_info->loopback_en = TRUE;

    /* use l2Newheader to carry the information */
    /* l2NewHeader = {DsL2EditLoopback.lbLengthAdjustType, DsL2EditLoopback.lbDsetMap[21:0]
                      DsL2EditLoopback.lbNextHopExt, DsL2EditLoopback.lbNextHopPtr[17:0]} */
    pkt_info->l2_header[0] = (p_ds_l2_edit_loopback->lb_length_adjust_type << 7)
                             | (p_ds_l2_edit_loopback->lb_dest_map >> 15);
    pkt_info->l2_header[1] = (p_ds_l2_edit_loopback->lb_dest_map >> 7) & 0xFF;
    pkt_info->l2_header[2] = ((p_ds_l2_edit_loopback->lb_dest_map & 0x7F) << 1)
                             | p_ds_l2_edit_loopback->lb_next_hop_ext;
    pkt_info->l2_header[3] = (p_ds_l2_edit_loopback->lb_next_hop_ptr >> 10) & 0xFF;
    pkt_info->l2_header[4] = (p_ds_l2_edit_loopback->lb_next_hop_ptr >> 2) & 0xFF;
    pkt_info->l2_header[5] = (p_ds_l2_edit_loopback->lb_next_hop_ptr & 0x3) << 6;

    pkt_info->l2_new_header_len = 0;  /* indicate no rewrite */
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_epe_layer2_editing_pbb
 * Purpose:    perform layer2 pbb editing operations.
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_epe_layer2_editing_pbb(epe_in_pkt_t* ipkt,
        ds_l2_edit_pbb8_w_t* p_ds_l2_edit_pbb8_w, cm_epe_l2_edit_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_l2_tpid_ctl_t epe_l2_tpid_ctl;
    epe_pbb_ctl_t  epe_pbb_ctl;
    epe_l2_port_mac_sa_t epe_l2_port_mac_sa;
    epe_l2_edit_ctl_t epe_l2_edit_ctl;

    uint8 new_mac_da[6] = {0}, new_mac_sa[6] = {0};
    uint32 new_btag_cos = 0;
    uint32 new_btag_cfi = 0;
    uint32 new_itag_cos = 0;
    uint32 new_itag_cfi = 0;
    uint32 new_bvlan_tag = 0;
    uint32 new_itag_l = 0;
    uint16 new_itag_h = 0;
    uint32 cmd = 0;
    uint32 i_sid = 0;
    uint8 untag_default_svlan = 0;
    uint8 svlan_tagged = 0;
    uint8 svlan_tag_operation = 0;
    uint8 length_adjust = 0;
    uint8 length_adjust_byte = 0;
    uint16 packet_length_adjust = 0;

    sal_memset(&epe_pbb_ctl, 0, sizeof(epe_pbb_ctl));
    cmd = DRV_IOR(EpePbbCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pbb_ctl));

    /* new I-SID */
    if (p_ds_l2_edit_pbb8_w->i_sid_valid)
    {
        i_sid = p_ds_l2_edit_pbb8_w->i_sid;
    }
    else
    {
        i_sid = (parser_result->l3_s.ip_da.cmac.itag_tci.itag_tci) & 0xFFFFFF; /* not use l3editing update result */
    }

    /* new B-MAC DA */
    if (p_ds_l2_edit_pbb8_w->mac_da_valid)          /* new B-MAC DA */
    {
        new_mac_da[0] = p_ds_l2_edit_pbb8_w->mac_da1 & 0xFF;
        new_mac_da[1] = (p_ds_l2_edit_pbb8_w->mac_da1 >> 8) & 0xFF;
        new_mac_da[2] = (p_ds_l2_edit_pbb8_w->mac_da1 >> 16) & 0xFF;
        new_mac_da[3] = (p_ds_l2_edit_pbb8_w->mac_da1 >> 24) & 0xFF;
        new_mac_da[4] = p_ds_l2_edit_pbb8_w->mac_da0 & 0xFF;
        new_mac_da[5] = (p_ds_l2_edit_pbb8_w->mac_da0 >> 8) & 0xFF;
    }
    else if (p_ds_l2_edit_pbb8_w->derive_mac_da && p_ds_l2_edit_pbb8_w->pbb_oui_type)   /* SPBM SPSourceID */
    {
        new_mac_da[0] = i_sid & 0xFF;
        new_mac_da[1] = (i_sid >> 8) & 0xFF;
        new_mac_da[2] = (i_sid >> 16) & 0xFF;
        new_mac_da[3] = epe_pbb_ctl.pbb_oui_value1 & 0xFF;
        new_mac_da[4] = (epe_pbb_ctl.pbb_oui_value1 >> 8) & 0xFF;
        new_mac_da[5] = (epe_pbb_ctl.pbb_oui_value1 >> 16)& 0xFF;
    }
    else if (p_ds_l2_edit_pbb8_w->derive_mac_da
            && (((parser_result->l2_s.mac_da5) == ((epe_pbb_ctl.pbb_oui_value0 >> 16) & 0xFF))
            && ((parser_result->l2_s.mac_da4) == ((epe_pbb_ctl.pbb_oui_value0 >> 8) & 0xFF))
            && ((parser_result->l2_s.mac_da3) == (epe_pbb_ctl.pbb_oui_value0 & 0xFF))))
    {
        new_mac_da[0] = i_sid & 0xFF;
        new_mac_da[1] = (i_sid >> 8) & 0xFF;
        new_mac_da[2] = (i_sid >> 16) & 0xFF;
        new_mac_da[3] = epe_pbb_ctl.pbb_oui_value0 & 0xFF;
        new_mac_da[4] = (epe_pbb_ctl.pbb_oui_value0 >> 8) & 0xFF;
        new_mac_da[5] = (epe_pbb_ctl.pbb_oui_value0 >> 16)& 0xFF;
    }
    else
    {
        new_mac_da[0] = parser_result->l2_s.mac_da0;
        new_mac_da[1] = parser_result->l2_s.mac_da1;
        new_mac_da[2] = parser_result->l2_s.mac_da2;
        new_mac_da[3] = parser_result->l2_s.mac_da3;
        new_mac_da[4] = parser_result->l2_s.mac_da4;
        new_mac_da[5] = parser_result->l2_s.mac_da5;
    }

    /* new B-MAC SA */
    sal_memset(&epe_l2_port_mac_sa, 0, sizeof(epe_l2_port_mac_sa_t));
    cmd = DRV_IOR(EpeL2PortMacSa_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_port_mac_sa));

    sal_memset(&epe_l2_edit_ctl, 0, sizeof(epe_l2_edit_ctl_t));
    cmd = DRV_IOR(EpeL2EditCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_edit_ctl));

    if (p_ds_l2_edit_pbb8_w->pbb_global_mac_en)
    {
        new_mac_sa[0] = epe_l2_edit_ctl.system_mac_low & 0xFF;
        new_mac_sa[1] = (epe_l2_edit_ctl.system_mac_low >> 8) & 0xFF;
        new_mac_sa[2] = (epe_l2_edit_ctl.system_mac_low >> 16) & 0xFF;
        new_mac_sa[3] = epe_l2_edit_ctl.system_mac_low >> 24;
        new_mac_sa[4] = epe_l2_edit_ctl.system_mac_high & 0xFF;
        new_mac_sa[5] = (epe_l2_edit_ctl.system_mac_high >> 8) & 0xFF;
    }
    else if (p_ds_l2_edit_pbb8_w->mac_sa_valid)
    {
        new_mac_sa[0] = pkt_info->port_mac_sa;
        if (pkt_info->port_mac_sa_type == 0)
        {
            new_mac_sa[1] = epe_l2_port_mac_sa.port_mac_sa0_31_8 & 0xFF;
            new_mac_sa[2] = (epe_l2_port_mac_sa.port_mac_sa0_31_8 >> 8) & 0xFF;
            new_mac_sa[3] = (epe_l2_port_mac_sa.port_mac_sa0_31_8 >> 16) & 0xFF;
            new_mac_sa[4] = epe_l2_port_mac_sa.port_mac_sa0_47_32 & 0xFF;
            new_mac_sa[5] = (epe_l2_port_mac_sa.port_mac_sa0_47_32 >> 8) & 0xFF;
        }
        else if (pkt_info->port_mac_sa_type == 1)
        {
            new_mac_sa[1] = epe_l2_port_mac_sa.port_mac_sa1_31_8 & 0xFF;
            new_mac_sa[2] = (epe_l2_port_mac_sa.port_mac_sa1_31_8 >> 8) & 0xFF;
            new_mac_sa[3] = (epe_l2_port_mac_sa.port_mac_sa1_31_8 >> 16) & 0xFF;
            new_mac_sa[4] = epe_l2_port_mac_sa.port_mac_sa1_47_32  & 0xFF;
            new_mac_sa[5] = (epe_l2_port_mac_sa.port_mac_sa1_47_32 >> 8) & 0xFF;
        }
        pkt_info->port_mac_sa_en = TRUE;
    }
    else
    {
        new_mac_sa[0] = parser_result->l2_s.mac_sa0;
        new_mac_sa[1] = parser_result->l2_s.mac_sa1;
        new_mac_sa[2] = parser_result->l2_s.mac_sa2;
        new_mac_sa[3] = parser_result->l2_s.mac_sa3;
        new_mac_sa[4] = parser_result->l2_s.mac_sa4;
        new_mac_sa[5] = parser_result->l2_s.mac_sa5;
    }

    /* new B-tag */
    if (p_ds_l2_edit_pbb8_w->derive_btag_co_s && p_ds_l2_edit_pbb8_w->btag_cfi)/* replaceBtagCos */
    {
        new_btag_cos = pkt_info->mapped_cos;
        new_btag_cfi = pkt_info->mapped_cfi;
    }
    else if (p_ds_l2_edit_pbb8_w->derive_btag_co_s && !p_ds_l2_edit_pbb8_w->btag_cfi)
    {
        new_btag_cos = pkt_info->source_cos;
        new_btag_cfi = pkt_info->source_cfi;
    }
    else
    {
        new_btag_cos = p_ds_l2_edit_pbb8_w->btag_cos;
        new_btag_cfi = p_ds_l2_edit_pbb8_w->btag_cfi;
    }

    if (p_ds_l2_edit_pbb8_w->b_vlan_valid)
    {
        mtu_msg->output_svlan_id = p_ds_l2_edit_pbb8_w->bvlan_id;
    }

    sal_memset(&epe_l2_tpid_ctl, 0, sizeof(epe_l2_tpid_ctl));
    cmd = DRV_IOR(EpeL2TpidCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_tpid_ctl));

    new_bvlan_tag = (epe_l2_tpid_ctl.bvlan_tpid << 16)
                    | (new_btag_cos << 13)
                    | (new_btag_cfi << 12)
                    | mtu_msg->output_svlan_id;

    /* new I-tag */
    pkt_info->itag_offset_type = parser_result->l2_s.svlan_id_valid;/* only use for itag replace */

    if (p_ds_l2_edit_pbb8_w->derive_itag_co_s && p_ds_l2_edit_pbb8_w->itag_cfi)/* replaceBtagCos */
    {
        new_itag_cos = pkt_info->mapped_cos;
        new_itag_cfi = pkt_info->mapped_cfi;
    }
    else if (p_ds_l2_edit_pbb8_w->derive_itag_co_s && !p_ds_l2_edit_pbb8_w->itag_cfi)
    {
        new_itag_cos = pkt_info->source_cos;
        new_itag_cfi = pkt_info->source_cfi;
    }
    else
    {
        new_itag_cos = p_ds_l2_edit_pbb8_w->itag_cos;
        new_itag_cfi = p_ds_l2_edit_pbb8_w->itag_cfi;
    }

    new_itag_h = epe_l2_tpid_ctl.i_tag_tpid;
    if (p_ds_l2_edit_pbb8_w->copy_nca_res && (L3_TYPE_CMAC == parser_result->layer3_type))
    {
        new_itag_l = ((new_itag_cos & 0x7) << 29)
                     | ((new_itag_cfi & 0x1) << 28)
                     | (((parser_result->l3_s.ip_da.cmac.itag_tci.itag_tci >> 24) & 0xF) << 24)
                     | p_ds_l2_edit_pbb8_w->i_sid;
    }
    else
    {
        new_itag_l = ((new_itag_cos & 0x7) << 29)
                     | ((new_itag_cfi & 0x1) << 28)
                     | (p_ds_l2_edit_pbb8_w->nca << 27)
                     | (p_ds_l2_edit_pbb8_w->res1 << 26)
                     | (p_ds_l2_edit_pbb8_w->res2 << 24)
                     | p_ds_l2_edit_pbb8_w->i_sid;
    }

    svlan_tagged = TRUE;
    untag_default_svlan = pkt_info->untag_default_vlan_id
                          && pkt_info->untag_default_svlan
                          && (mtu_msg->output_svlan_id == pkt_info->default_vlan_id);

    /* PBB header operation */
    if (p_ds_l2_edit_pbb8_w->pbb_header_operation_type)  /* add PBB Header ,l2NewHeader={DA,SA,ITAG,PAD} */
    {
        pkt_info->l2_header[0] = new_mac_da[5];
        pkt_info->l2_header[1] = new_mac_da[4];
        pkt_info->l2_header[2] = new_mac_da[3];
        pkt_info->l2_header[3] = new_mac_da[2];
        pkt_info->l2_header[4] = new_mac_da[1];
        pkt_info->l2_header[5] = new_mac_da[0];

        pkt_info->l2_header[6] = new_mac_sa[5];
        pkt_info->l2_header[7] = new_mac_sa[4];
        pkt_info->l2_header[8] = new_mac_sa[3];
        pkt_info->l2_header[9] = new_mac_sa[2];
        pkt_info->l2_header[10] = new_mac_sa[1];
        pkt_info->l2_header[11] = new_mac_sa[0];

        if (p_ds_l2_edit_pbb8_w->bvlan_tagged && IS_BIT_SET(pkt_info->dot1_q_en, 1) && !untag_default_svlan)
        {
            pkt_info->l2_header[12] = (new_bvlan_tag >> 24) & 0xFF;
            pkt_info->l2_header[13] = (new_bvlan_tag >> 16) & 0xFF;
            pkt_info->l2_header[14] = (new_bvlan_tag >> 8) & 0xFF;
            pkt_info->l2_header[15] = new_bvlan_tag & 0xFF;

            pkt_info->l2_header[16] = (new_itag_h >> 8) & 0xFF;
            pkt_info->l2_header[17] = new_itag_h & 0xFF;

            pkt_info->l2_header[18] = (new_itag_l >> 24) & 0xFF;
            pkt_info->l2_header[19] = (new_itag_l >> 16) & 0xFF;
            pkt_info->l2_header[20] = (new_itag_l >> 8) & 0xFF;
            pkt_info->l2_header[21] = new_itag_l & 0xFF;

            pkt_info->l2_new_header_len = 22 ;
        }
        else
        {
            pkt_info->l2_header[12] = (new_itag_h >> 8) & 0xFF;
            pkt_info->l2_header[13] = new_itag_h & 0xFF;

            pkt_info->l2_header[14] = (new_itag_l >> 24) & 0xFF;
            pkt_info->l2_header[15] = (new_itag_l >> 16) & 0xFF;
            pkt_info->l2_header[16] = (new_itag_l >> 8) & 0xFF;
            pkt_info->l2_header[17] = new_itag_l & 0xFF;

            pkt_info->l2_new_header_len = 18 ;
            svlan_tagged = FALSE;
            pkt_info->new_cos = new_itag_cos & 0x7;
            pkt_info->new_cfi = new_itag_cfi & 0x1;
        }
    }
    else    /* Replace PBB header */
    {
        /* Replace MAC DA */
        pkt_info->new_macda_valid = p_ds_l2_edit_pbb8_w->mac_da_valid || p_ds_l2_edit_pbb8_w->derive_mac_da;
        if (pkt_info->new_macda_valid)
        {
            pkt_info->new_macda_lower32 = (new_mac_da[3] << 24) | (new_mac_da[2] << 16)
                                        | (new_mac_da[1] << 8) | new_mac_da[0];
            pkt_info->new_macda_upper16 = (new_mac_da[5] << 8) | new_mac_da[4];
        }

        /* Replace Itag */
        pkt_info->new_itag_valid = p_ds_l2_edit_pbb8_w->i_sid_valid;
        if (pkt_info->new_itag_valid)
        {
            pkt_info->new_itag = (new_itag_l & 0xFFFFFF);
        }

        /* btag operation */
        if (p_ds_l2_edit_pbb8_w->bvlan_tag_disable)
        {
            pkt_info->svlan_tag_operation = VTAG_OP_NONE; /* no operation */
            svlan_tagged = parser_result->l2_s.svlan_id_valid;  /* ??? change from svlanTagged = 1'b1; */
            if (!parser_result->l2_s.svlan_id_valid)
            {
                pkt_info->new_cos = new_itag_cos & 0x7;
                pkt_info->new_cfi = new_itag_cfi & 0x1;
            }
        }
        else if (p_ds_l2_edit_pbb8_w->bvlan_tagged && IS_BIT_SET(pkt_info->dot1_q_en, 1) && !untag_default_svlan)
        {
            /* tag B-VLAN */
            if (parser_result->l2_s.svlan_id_valid)
            {
                pkt_info->svlan_tag_operation = VTAG_OP_REPLACE; /* Replace */
            }
            else
            {
                pkt_info->svlan_tag_operation = VTAG_OP_ADD;     /* Add */
            }
        }
        else
        {
            if (!parser_result->l2_s.svlan_id_valid)
            {
                pkt_info->svlan_tag_operation = VTAG_OP_NONE;    /* None */
            }
            else
            {
                pkt_info->svlan_tag_operation = VTAG_OP_DELETE;  /* Delete */
            }
            pkt_info->new_cos = new_itag_cos & 0x7;
            pkt_info->new_cfi = new_itag_cfi & 0x1;
            svlan_tagged = FALSE;
        }                       /* l2NewHeader = {DA,SA,ITAG,PAD} */
        pkt_info->l2_new_svlan_tag = new_bvlan_tag;
        svlan_tag_operation = pkt_info->svlan_tag_operation;
    }

    /* ParserResult update */
    pkt_info->packet_type = PKT_TYPE_ETHERNETV2;

    if (p_ds_l2_edit_pbb8_w->mac_da_valid || p_ds_l2_edit_pbb8_w->derive_mac_da)
    {
        mtu_msg->mac_da_en_update = TRUE;
        mtu_msg->mac_da0_update = new_mac_da[0];
        mtu_msg->mac_da1_update = new_mac_da[1];
        mtu_msg->mac_da2_update = new_mac_da[2];
        mtu_msg->mac_da3_update = new_mac_da[3];
        mtu_msg->mac_da4_update = new_mac_da[4];
        mtu_msg->mac_da5_update = new_mac_da[5];
    }

    if (p_ds_l2_edit_pbb8_w->mac_sa_valid)
    {
        mtu_msg->mac_sa_en_update = TRUE;
        mtu_msg->mac_sa0_update = new_mac_sa[0];
        mtu_msg->mac_sa1_update = new_mac_sa[1];
        mtu_msg->mac_sa2_update = new_mac_sa[2];
        mtu_msg->mac_sa3_update = new_mac_sa[3];
        mtu_msg->mac_sa4_update = new_mac_sa[4];
        mtu_msg->mac_sa5_update = new_mac_sa[5];
    }

    if (svlan_tagged)       /* Tag S-VLAN */
    {
        mtu_msg->svlan_id_update = (new_bvlan_tag & 0xFFF);
        mtu_msg->stag_cos_update = (new_bvlan_tag >> 13) & 0x7;
        mtu_msg->stag_cfi_update = (new_bvlan_tag >> 12) & 0x1;
    }
    else                    /* Untag S-VLAN */
    {
        mtu_msg->svlan_id_update = 0;
        mtu_msg->stag_cos_update = 0;
        mtu_msg->stag_cfi_update = 0;
    }

    /* LENGTH ADJUST */
    switch ((svlan_tag_operation & 0x3) << 2)
    {
        case 0:
            length_adjust = 0;
            break;
        case 4:
            length_adjust = 0;
            break;
        case 8:
            length_adjust = 1;
            break;
        case 12:
            length_adjust = 5;
            break;
        default:
            break;
    }

    length_adjust_byte = ((length_adjust & 0x3) << 2);

    if (!IS_BIT_SET(length_adjust, 2)) /* + */
    {
        packet_length_adjust = func_packet_length_adjust_add(ipkt, (uint8)length_adjust_byte);
        pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
        pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;

        pkt_info->ptp_offset += length_adjust_byte;
    }
    else                               /* - */
    {
        packet_length_adjust = func_packet_length_adjust_subtract(ipkt, (uint8)length_adjust_byte);
        pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
        pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;

        pkt_info->ptp_offset -= length_adjust_byte;
    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_epe_layer2_editing_flex
 * Purpose:    perform layer2 flex editing operations.
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *             mtu_msg -- pointer to cm_epe_mtu_msg_t
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_epe_layer2_editing_flex(epe_in_pkt_t* ipkt,
        ds_l2_edit_flex8_w_t* p_ds_l2_edit_flex8_w, cm_epe_l2_edit_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    uint32 rewrite0=0,rewrite1=0,rewrite2=0,rewrite3=0;
    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }
    rewrite0 = ((p_ds_l2_edit_flex8_w->rewrite_string0_31_24<<24)
                | p_ds_l2_edit_flex8_w->rewrite_string0_23_0);
    rewrite1 = ((p_ds_l2_edit_flex8_w->rewrite_string1_31_2<<2)
                |p_ds_l2_edit_flex8_w->rewrite_string1_1_0);
    rewrite2 = p_ds_l2_edit_flex8_w->rewrite_string2;
    rewrite3 = p_ds_l2_edit_flex8_w->rewrite_string3;
    /* NEW_HEADER */
    pkt_info->l2_new_header_len = p_ds_l2_edit_flex8_w->rewrite_byte_num;


    switch (pkt_info->l2_new_header_len)
    {
        case 0:
            break;
        case 1:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            break;
        case 2:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            break;
        case 3:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            break;
        case 4:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            break;
        case 5:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            break;
        case 6:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            break;
        case 7:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            pkt_info->l2_header[6] = (rewrite1>>8)&0xFF;
            break;
        case 8:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            pkt_info->l2_header[6] = (rewrite1>>8)&0xFF;
            pkt_info->l2_header[7] = rewrite1 & 0xFF;
            break;
        case 9:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            pkt_info->l2_header[6] = (rewrite1>>8)&0xFF;
            pkt_info->l2_header[7] = rewrite1 & 0xFF;
            pkt_info->l2_header[8] = (rewrite2>>24)&0xFF;
            break;
        case 10:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            pkt_info->l2_header[6] = (rewrite1>>8)&0xFF;
            pkt_info->l2_header[7] = rewrite1 & 0xFF;
            pkt_info->l2_header[8] = (rewrite2>>24)&0xFF;
            pkt_info->l2_header[9] = (rewrite2>>16)&0xFF;
            break;
        case 11:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            pkt_info->l2_header[6] = (rewrite1>>8)&0xFF;
            pkt_info->l2_header[7] = rewrite1 & 0xFF;
            pkt_info->l2_header[8] = (rewrite2>>24)&0xFF;
            pkt_info->l2_header[9] = (rewrite2>>16)&0xFF;
            pkt_info->l2_header[10] = (rewrite2>>8)&0xFF;
            break;
         case 12:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            pkt_info->l2_header[6] = (rewrite1>>8)&0xFF;
            pkt_info->l2_header[7] = rewrite1 & 0xFF;
            pkt_info->l2_header[8] = (rewrite2>>24)&0xFF;
            pkt_info->l2_header[9] = (rewrite2>>16)&0xFF;
            pkt_info->l2_header[10] = (rewrite2>>8)&0xFF;
            pkt_info->l2_header[11] = rewrite2 & 0xFF;
            break;
          case 13:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            pkt_info->l2_header[6] = (rewrite1>>8)&0xFF;
            pkt_info->l2_header[7] = rewrite1 & 0xFF;
            pkt_info->l2_header[8] = (rewrite2>>24)&0xFF;
            pkt_info->l2_header[9] = (rewrite2>>16)&0xFF;
            pkt_info->l2_header[10] = (rewrite2>>8)&0xFF;
            pkt_info->l2_header[11] = rewrite2 & 0xFF;
            pkt_info->l2_header[12] = (rewrite3>>24)& 0xFF;
            break;
         case 14:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            pkt_info->l2_header[6] = (rewrite1>>8)&0xFF;
            pkt_info->l2_header[7] = rewrite1 & 0xFF;
            pkt_info->l2_header[8] = (rewrite2>>24)&0xFF;
            pkt_info->l2_header[9] = (rewrite2>>16)&0xFF;
            pkt_info->l2_header[10] = (rewrite2>>8)&0xFF;
            pkt_info->l2_header[11] = rewrite2 & 0xFF;
            pkt_info->l2_header[12] = (rewrite3>>24)& 0xFF;
            pkt_info->l2_header[13] = (rewrite3>>16)& 0xFF;
            break;
        case 15:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            pkt_info->l2_header[6] = (rewrite1>>8)&0xFF;
            pkt_info->l2_header[7] = rewrite1 & 0xFF;
            pkt_info->l2_header[8] = (rewrite2>>24)&0xFF;
            pkt_info->l2_header[9] = (rewrite2>>16)&0xFF;
            pkt_info->l2_header[10] = (rewrite2>>8)&0xFF;
            pkt_info->l2_header[11] = rewrite2 & 0xFF;
            pkt_info->l2_header[12] = (rewrite3>>24)& 0xFF;
            pkt_info->l2_header[13] = (rewrite3>>16)& 0xFF;
            pkt_info->l2_header[14] = (rewrite3>>8)& 0xFF;
            break;
        case 16:
            pkt_info->l2_header[0]= (rewrite0>>24)&0xFF;
            pkt_info->l2_header[1] = (rewrite0>>16)&0xFF;
            pkt_info->l2_header[2] = (rewrite0>>8)&0xFF;
            pkt_info->l2_header[3] = rewrite0 & 0xFF;
            pkt_info->l2_header[4] = (rewrite1>>24)&0xFF;
            pkt_info->l2_header[5] = (rewrite1>>16)&0xFF;
            pkt_info->l2_header[6] = (rewrite1>>8)&0xFF;
            pkt_info->l2_header[7] = rewrite1 & 0xFF;
            pkt_info->l2_header[8] = (rewrite2>>24)&0xFF;
            pkt_info->l2_header[9] = (rewrite2>>16)&0xFF;
            pkt_info->l2_header[10] = (rewrite2>>8)&0xFF;
            pkt_info->l2_header[11] = rewrite2 & 0xFF;
            pkt_info->l2_header[12] = (rewrite3>>24)& 0xFF;
            pkt_info->l2_header[13] = (rewrite3>>16)& 0xFF;
            pkt_info->l2_header[14] = (rewrite3>>8)& 0xFF;
            pkt_info->l2_header[15] = rewrite3 & 0xFF;
        default:
            break;
    }

    /* REPLACE_PARSER_RESULT */
    mtu_msg->layer2_type_update = L2_TYPE_NONE;

    pkt_info->packet_type = p_ds_l2_edit_flex8_w->packet_type;
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_epe_layer2_editing_replace
 * Purpose:    perform layer2 ethernet replace editing operations.
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *             mtu_msg -- pointer to cm_epe_mtu_msg_t
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_epe_layer2_editing_mac_swap(epe_in_pkt_t* ipkt,
            ds_l2_edit_swap_t* p_ds_l2_edit_swap, cm_epe_l2_edit_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    /* LAYER2_ETHER_REPLACE */
    if (!pkt_info->discard)
    {
        pkt_info->new_macda_valid = p_ds_l2_edit_swap->derive_mcast_mac;

        if (p_ds_l2_edit_swap->type)
        {
            pkt_info->new_macda_lower32 = (p_ds_l2_edit_swap->mac_da31_30 << 30) | p_ds_l2_edit_swap->mac_da29_0;
            pkt_info->new_macda_upper16 = p_ds_l2_edit_swap->mac_da47_32;
        }
        else
        {
            pkt_info->new_macda_lower32 = MAKE_UINT32(parser_result->l2_s.mac_sa3,
                                                      parser_result->l2_s.mac_sa2,
                                                      parser_result->l2_s.mac_sa1,
                                                      parser_result->l2_s.mac_sa0);
            pkt_info->new_macda_upper16 = MAKE_UINT16(parser_result->l2_s.mac_sa5,
                                                      parser_result->l2_s.mac_sa4);
        }

        pkt_info->new_macsa_valid = p_ds_l2_edit_swap->output_vlan_id_valid;
        if(p_ds_l2_edit_swap->overwrite_ether_type)
        {
            pkt_info->new_macsa_lower32 = p_ds_l2_edit_swap->mac_sa31_0;
            pkt_info->new_macsa_upper16 = p_ds_l2_edit_swap->mac_sa47_32;
        }
        else
        {
            pkt_info->new_macsa_lower32 = MAKE_UINT32(parser_result->l2_s.mac_da3,
                                                      parser_result->l2_s.mac_da2,
                                                      parser_result->l2_s.mac_da1,
                                                      parser_result->l2_s.mac_da0);
            pkt_info->new_macsa_upper16 = MAKE_UINT16(parser_result->l2_s.mac_da5,
                                                      parser_result->l2_s.mac_da4);
        }
    }

    if (pkt_info->new_macda_valid)
    {
        mtu_msg->mac_da_en_update = TRUE;
        mtu_msg->mac_da5_update = (pkt_info->new_macda_upper16 >> 8) & 0xFF;
        mtu_msg->mac_da4_update = pkt_info->new_macda_upper16 & 0xFF;
        mtu_msg->mac_da3_update = (pkt_info->new_macda_lower32 >> 24) & 0xFF;
        mtu_msg->mac_da2_update = (pkt_info->new_macda_lower32 >> 16) & 0xFF;
        mtu_msg->mac_da1_update = (pkt_info->new_macda_lower32 >> 8) & 0xFF;
        mtu_msg->mac_da0_update = pkt_info->new_macda_lower32 & 0xFF;
    }

    if (pkt_info->new_macsa_valid)
    {
        mtu_msg->mac_sa_en_update = TRUE;
        mtu_msg->mac_sa5_update = (pkt_info->new_macsa_upper16 >> 8) & 0xFF;
        mtu_msg->mac_sa4_update = pkt_info->new_macsa_upper16 & 0xFF;
        mtu_msg->mac_sa3_update = (pkt_info->new_macsa_lower32 >> 24) & 0xFF;
        mtu_msg->mac_sa2_update = (pkt_info->new_macsa_lower32 >> 16) & 0xFF;
        mtu_msg->mac_sa1_update = (pkt_info->new_macsa_lower32 >> 8) & 0xFF;
        mtu_msg->mac_sa0_update = pkt_info->new_macsa_lower32 & 0xFF;
    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_epe_layer2_editing_eth
 * Purpose:    perform layer2  ethernet8w editing operations.
 * Parameters:
 * Input:      ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 *             mtu_msg -- pointer to cm_epe_mtu_msg_t
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
 _cm_epe_layer2_editing_eth(epe_in_pkt_t* ipkt, ds_l2_edit_eth8_w_t* p_ds_l2_edit_eth8_w,
                    epe_l2_edit_input_info_t* epe_l2_edit_input_info, cm_epe_l2_edit_mtu_msg_t* mtu_msg)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    epe_l2_port_mac_sa_t epe_l2_port_mac_sa;
    epe_l2_router_mac_sa_t epe_l2_router_mac_sa;
    epe_l2_mac_sa_tmp_t epe_l2_mac_sa_tmp;
    epe_l2_tpid_ctl_t epe_l2_tpid_ctl;
    epe_l2_snap_ctl_t epe_l2_snap_ctl;
    epe_l2_edit_ctl_t epe_l2_edit_ctl;
    epe_pkt_proc_ctl_t epe_pkt_proc_ctl;
    ds_l2_edit_eth4_w_t* p_ds_l2_edit_eth4_w = NULL;

    uint8 new_mac_sa[6] = {0}, new_mac_da[6] = {0};
    uint32 cmd = 0;
    uint32 untag_default_svlan = 0;
    uint32 new_svlan_tpid = 0, new_cvlan_tpid = 0;
    uint8 dot1q_en1 = FALSE, dot1q_en0 = FALSE;
    uint8 svlan_tag_en = FALSE, cvlan_tag_en = FALSE;
    uint32 new_stag_cos = 0, new_stag_cfi = 0;
    uint32 new_ctag_cos = 0, new_ctag_cfi = 0;
    uint32 new_svlan_tag = 0, new_cvlan_tag = 0;
    uint32 untag_default_cvlan = 0;
    uint16 new_ether_type = 0;
    uint8 packet_type = 0;
    uint16 new_snap_length = 0;
    uint32 l2_ether_field_value = 0;
    uint8 offset = 0;

    sal_memset(&epe_l2_mac_sa_tmp, 0, sizeof(epe_l2_mac_sa_tmp_t));

    /* LAYER2_ETHER */
    packet_type = pkt_info->packet_type;    /* this is the payload packet type */

    p_ds_l2_edit_eth4_w = (ds_l2_edit_eth4_w_t*)p_ds_l2_edit_eth8_w;

    if (pkt_info->discard)
    {
        return DRV_E_NONE;
    }

     /* EtherType */
    if (p_ds_l2_edit_eth8_w->overwrite_ether_type)
    {
        packet_type = p_ds_l2_edit_eth8_w->packet_type;
    }
    else
    {
        packet_type = pkt_info->packet_type;
    }

    /* PREPARE_FIELDS */
    /* MAC SA */

    sal_memset(&epe_l2_edit_ctl, 0, sizeof(epe_l2_edit_ctl_t));
    cmd = DRV_IOR(EpeL2EditCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_edit_ctl));

    if ((L3_TYPE_FCOE == parser_result->layer3_type)
                && p_ds_l2_edit_eth4_w->fcoe_over_trill_mac_sa_en)
    {
        new_mac_sa[0] = epe_l2_edit_ctl.system_mac_low & 0xFF;
        new_mac_sa[1] = (epe_l2_edit_ctl.system_mac_low >> 8) & 0xFF;
        new_mac_sa[2] = (epe_l2_edit_ctl.system_mac_low >> 16) & 0xFF;
        new_mac_sa[3] = (epe_l2_edit_ctl.system_mac_low >> 24) & 0xFF;
        new_mac_sa[4] = epe_l2_edit_ctl.system_mac_high & 0xFF;
        new_mac_sa[5] = (epe_l2_edit_ctl.system_mac_high >> 8) & 0xFF;
    }
    else if ((PKT_TYPE_TRILL == packet_type)
                || ((L3_TYPE_FCOE == parser_result->layer3_type)
                && !p_ds_l2_edit_eth4_w->derive_fcoe_mac_sa))
    {
        sal_memset(&epe_l2_port_mac_sa, 0, sizeof(epe_l2_port_mac_sa_t));
        cmd = DRV_IOR(EpeL2PortMacSa_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_port_mac_sa));

        switch (pkt_info->port_mac_sa_type)
        {
            case 0:
                epe_l2_mac_sa_tmp.mac_sa_h = epe_l2_port_mac_sa.port_mac_sa0_47_32;
                epe_l2_mac_sa_tmp.mac_sa_l = epe_l2_port_mac_sa.port_mac_sa0_31_8;
                break;
            case 1:
                epe_l2_mac_sa_tmp.mac_sa_h = epe_l2_port_mac_sa.port_mac_sa1_47_32;
                epe_l2_mac_sa_tmp.mac_sa_l = epe_l2_port_mac_sa.port_mac_sa1_31_8;
                break;
            default:
                break;
        }

        new_mac_sa[0] = pkt_info->port_mac_sa;
        new_mac_sa[1] = epe_l2_mac_sa_tmp.mac_sa_l & 0xFF;
        new_mac_sa[2] = (epe_l2_mac_sa_tmp.mac_sa_l >> 8) & 0xFF;
        new_mac_sa[3] = (epe_l2_mac_sa_tmp.mac_sa_l >> 16) & 0xFF;
        new_mac_sa[4] = epe_l2_mac_sa_tmp.mac_sa_h & 0xFF;
        new_mac_sa[5] = (epe_l2_mac_sa_tmp.mac_sa_h >> 8) & 0xFF;

        pkt_info->port_mac_sa_en = TRUE;
    }
    else if ((parser_result->layer3_type == L3_TYPE_FCOE)
        && p_ds_l2_edit_eth4_w->derive_fcoe_mac_sa)
    {
        new_mac_sa[0] = parser_result->l3_s.ip_sa.fcoe.fcoe_sid & 0xFF;
        new_mac_sa[1] = (parser_result->l3_s.ip_sa.fcoe.fcoe_sid >> 8) & 0xFF;
        new_mac_sa[2] = (parser_result->l3_s.ip_sa.fcoe.fcoe_sid >> 16) & 0xFF;
        new_mac_sa[3] = pkt_info->fcoe_oui_index;
        new_mac_sa[4] = 0xFC;
        new_mac_sa[5] = 0xE;
    }
    else
    {
        sal_memset(&epe_l2_router_mac_sa, 0, sizeof(epe_l2_router_mac_sa));
        cmd = DRV_IOR(EpeL2RouterMacSa_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_router_mac_sa));

        switch (pkt_info->mac_sa_type)
        {
            case 0:
                epe_l2_mac_sa_tmp.mac_sa_h = epe_l2_router_mac_sa.router_mac_sa0_47_32;
                epe_l2_mac_sa_tmp.mac_sa_l = epe_l2_router_mac_sa.router_mac_sa0_31_8;
                break;
            case 1:
                epe_l2_mac_sa_tmp.mac_sa_h = epe_l2_router_mac_sa.router_mac_sa1_47_32;
                epe_l2_mac_sa_tmp.mac_sa_l = epe_l2_router_mac_sa.router_mac_sa1_31_8;
                break;
            case 2:
                epe_l2_mac_sa_tmp.mac_sa_h = epe_l2_router_mac_sa.router_mac_sa2_47_32;
                epe_l2_mac_sa_tmp.mac_sa_l = epe_l2_router_mac_sa.router_mac_sa2_31_8;
                break;
            default:
                break;
        }

        new_mac_sa[0] = pkt_info->mac_sa;
        new_mac_sa[1] = epe_l2_mac_sa_tmp.mac_sa_l & 0xFF;
        new_mac_sa[2] = (epe_l2_mac_sa_tmp.mac_sa_l >> 8) & 0xFF;
        new_mac_sa[3] = (epe_l2_mac_sa_tmp.mac_sa_l >> 16) & 0xFF;
        new_mac_sa[4] = epe_l2_mac_sa_tmp.mac_sa_h & 0xFF;
        new_mac_sa[5] = (epe_l2_mac_sa_tmp.mac_sa_h >> 8) & 0xFF;

    }


    if (PKT_TYPE_IPV4 == packet_type)
    {
        new_ether_type = 0x0800;
    }
    else if (PKT_TYPE_MPLS == packet_type)
    {
        new_ether_type = 0x8847;
    }
    else if (PKT_TYPE_IPV6 == packet_type)
    {
        new_ether_type = 0x86DD;
    }
    else if (PKT_TYPE_MCAST_MPLS == packet_type)
    {
        new_ether_type = 0x8848;
    }
    else if (PKT_TYPE_TRILL == packet_type)
    {
        new_ether_type = 0x22F3;
    }
    else if (L3_TYPE_FCOE == parser_result->layer3_type)
    {
        new_ether_type = 0x8906;
    }
    else
    {
        cmd = DRV_IOR(EpeL2EtherType_t, EpeL2EtherType_EtherType0_f + (packet_type - 6));
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &l2_ether_field_value));

        new_ether_type = l2_ether_field_value;
    }

    /* MAC DA */
    if (pkt_info->route_no_l2_edit)
    {
        if (!pkt_info->mac_da_mcast_mode
                    && (PKT_TYPE_IPV4 == packet_type)
                    && (0xE == (parser_result->l3_s.ip_da.ipv4.ipda >> 28)))
        {
            new_mac_da[0] = parser_result->l3_s.ip_da.ipv4.ipda & 0xFF;
            new_mac_da[1] = (parser_result->l3_s.ip_da.ipv4.ipda >> 8) & 0xFF;
            new_mac_da[2] = (parser_result->l3_s.ip_da.ipv4.ipda >> 16) & 0x7F;
            new_mac_da[3] = 0x5E;
            new_mac_da[4] = 0x00;
            new_mac_da[5] = 0x01;
        }
        else if (!pkt_info->mac_da_mcast_mode
                    && (PKT_TYPE_IPV6 == packet_type)
                    && (0xFF == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24)))
        {
            new_mac_da[0] = parser_result->l3_s.ip_da.ipv6.ipda_31_0 & 0xFF;
            new_mac_da[1] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 8) & 0xFF;
            new_mac_da[2] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 16) & 0xFF;
            new_mac_da[3] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 24) & 0xFF;
            new_mac_da[4] = 0x33;
            new_mac_da[5] = 0x33;
        }
        else
        {
            new_mac_da[0] = pkt_info->mac_31_to_0 & 0xFF;
            new_mac_da[1] = (pkt_info->mac_31_to_0 >> 8) & 0xFF;
            new_mac_da[2] = (pkt_info->mac_31_to_0 >> 16) & 0xFF;
            new_mac_da[3] = (pkt_info->mac_31_to_0 >> 24) & 0xFF;
            new_mac_da[4] = pkt_info->mac_47_to_32 & 0xFF;
            new_mac_da[5] = (pkt_info->mac_47_to_32 >> 8) & 0xFF;
        }
    }
    else
    {
        if ((PKT_TYPE_IPV4 == packet_type)
            && (0xE == (parser_result->l3_s.ip_da.ipv4.ipda >> 28))
            && p_ds_l2_edit_eth8_w->derive_mcast_mac)
        {
            new_mac_da[0] = parser_result->l3_s.ip_da.ipv4.ipda & 0xFF;
            new_mac_da[1] = (parser_result->l3_s.ip_da.ipv4.ipda >> 8) & 0xFF;
            new_mac_da[2] = (parser_result->l3_s.ip_da.ipv4.ipda >> 16) & 0x7F;
            new_mac_da[3] = 0x5E;
            new_mac_da[4] = 0x00;
            new_mac_da[5] = 0x01;
        }
        else if ((PKT_TYPE_IPV6 == packet_type)
                && (0xFF == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24))
                && p_ds_l2_edit_eth8_w->derive_mcast_mac)
        {
            new_mac_da[0] = parser_result->l3_s.ip_da.ipv6.ipda_31_0 & 0xFF;
            new_mac_da[1] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 8) & 0xFF;
            new_mac_da[2] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 16) & 0xFF;
            new_mac_da[3] = (parser_result->l3_s.ip_da.ipv6.ipda_31_0 >> 24) & 0xFF;
            new_mac_da[4] = 0x33;
            new_mac_da[5] = 0x33;
        }
        else if ((PKT_TYPE_MCAST_MPLS== packet_type) && p_ds_l2_edit_eth8_w->derive_mcast_mac)
        {
            new_mac_da[0] = 0x0;
            new_mac_da[1] = 0x0;
            new_mac_da[2] = 0x80;
            new_mac_da[3] = 0x5E;
            new_mac_da[4] = 0x00;
            new_mac_da[5] = 0x01;
        }
        else if ((PKT_TYPE_TRILL == packet_type) && p_ds_l2_edit_eth8_w->derive_mcast_mac)
        {
            new_mac_da[0] = 0x40;
            new_mac_da[1] = 0x0;
            new_mac_da[2] = 0x0;
            new_mac_da[3] = 0xc2;
            new_mac_da[4] = 0x80;
            new_mac_da[5] = 0x01;
        }
        else if ((L3_TYPE_FCOE == parser_result->layer3_type)
            && p_ds_l2_edit_eth8_w->derive_mcast_mac) /*use as deriveFcoeMac*/
        {
            new_mac_da[0] = parser_result->l3_s.ip_da.fcoe.fcoe_did & 0xFF;
            new_mac_da[1] = (parser_result->l3_s.ip_da.fcoe.fcoe_did >> 8) & 0xFF;
            new_mac_da[2] = (parser_result->l3_s.ip_da.fcoe.fcoe_did >> 16) & 0xFF;
            new_mac_da[3] = pkt_info->fcoe_oui_index;
            new_mac_da[4] = 0xFC;
            new_mac_da[5] = 0x0E;
        }
        else
        {
            new_mac_da[0] = p_ds_l2_edit_eth8_w->mac_da29_0 & 0xFF;
            new_mac_da[1] = (p_ds_l2_edit_eth8_w->mac_da29_0 >> 8) & 0xFF;
            new_mac_da[2] = (p_ds_l2_edit_eth8_w->mac_da29_0 >> 16) & 0xFF;
            new_mac_da[3] = (p_ds_l2_edit_eth8_w->mac_da31_30 << 6)
                            | ((p_ds_l2_edit_eth8_w->mac_da29_0 >> 24) & 0x3F);
            new_mac_da[4] = p_ds_l2_edit_eth8_w->mac_da47_32 & 0xFF;
            new_mac_da[5] = (p_ds_l2_edit_eth8_w->mac_da47_32 >> 8) & 0xFF;
        }
    }

    /* VLAN TAG */
    dot1q_en1 = FALSE;
    dot1q_en0 = FALSE;

    if (pkt_info->route_no_l2_edit)     /* use DsNextHop VLAN */
    {
        if (pkt_info->interface_vlan_id_en && pkt_info->interface_svlan_tagged)
        {
            dot1q_en1 = TRUE;
            mtu_msg->output_svlan_id = pkt_info->interface_vlan_id;
        }
        else if (pkt_info->interface_vlan_id_en && !pkt_info->interface_svlan_tagged)
        {
            dot1q_en0 = TRUE;
            mtu_msg->output_cvlan_id = pkt_info->interface_vlan_id;
        }
    }
    else if (p_ds_l2_edit_eth8_w->output_vlan_id_valid)      /* use DsL2EditEth VLAN */
    {
        if (p_ds_l2_edit_eth8_w->output_vlan_id_is_svlan)
        {
            dot1q_en1 = TRUE;
            mtu_msg->output_svlan_id = p_ds_l2_edit_eth8_w->output_vlan_id;
        }
        else
        {
            dot1q_en0 = TRUE;
            mtu_msg->output_cvlan_id = p_ds_l2_edit_eth8_w->output_vlan_id;
        }
    }
    else if (p_ds_l2_edit_eth8_w->output_vlan_id == 0xFFF)
    {
     /*do noting ,no vlan tag add*/
    }
    else if (pkt_info->interface_vlan_id_en)    /* use interface vlan */
    {
        if (pkt_info->interface_svlan_tagged)
        {
            dot1q_en1 = TRUE;
            mtu_msg->output_svlan_id = pkt_info->interface_vlan_id;
        }
        else
        {
            dot1q_en0 = TRUE;
            mtu_msg->output_cvlan_id = pkt_info->interface_vlan_id;
        }
    }

    sal_memset(&epe_l2_tpid_ctl, 0, sizeof(epe_l2_tpid_ctl));
    cmd = DRV_IOR(EpeL2TpidCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_tpid_ctl));

    switch (pkt_info->svlan_tpid_index)
    {
        case 0:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid0;
            break;
        case 1:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid1;
            break;
        case 2:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid2;
            break;
        case 3:
            new_svlan_tpid = epe_l2_tpid_ctl.svlan_tpid3;
            break;
        default:
            break;
    }

    untag_default_svlan = pkt_info->untag_default_vlan_id
                          && pkt_info->untag_default_svlan
                          && (mtu_msg->output_svlan_id == pkt_info->default_vlan_id);

    svlan_tag_en = IS_BIT_SET(pkt_info->dot1_q_en, 1) && dot1q_en1 && (!untag_default_svlan);

    sal_memset(&epe_pkt_proc_ctl, 0, sizeof(epe_pkt_proc_ctl_t));
    cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_ctl));


    if (pkt_info->replace_stag_cos)
    {
        new_stag_cos = pkt_info->mapped_cos;
        new_stag_cfi = pkt_info->mapped_cfi;
    }
    else
    {
        new_stag_cos = pkt_info->source_cos;
        new_stag_cfi = epe_pkt_proc_ctl.always_map_cfi ? pkt_info->mapped_cfi : pkt_info->source_cfi;
    }

    new_svlan_tag = (new_svlan_tpid << 16)
                    | (new_stag_cos << 13)
                    | (new_stag_cfi << 12)
                    | mtu_msg->output_svlan_id;

    new_cvlan_tpid = epe_l2_tpid_ctl.cvlan_tpid;

    untag_default_cvlan = pkt_info->untag_default_vlan_id
                          && (!pkt_info->untag_default_svlan)
                          && (mtu_msg->output_cvlan_id == pkt_info->default_vlan_id);

    cvlan_tag_en = IS_BIT_SET(pkt_info->dot1_q_en, 0) && dot1q_en0 && (!untag_default_cvlan);
    new_ctag_cfi = pkt_info->ctag_dei_en ? pkt_info->mapped_cfi : 0;

    if (pkt_info->replace_ctag_cos)
    {
        new_ctag_cos = pkt_info->mapped_cos;
    }
    else
    {
        new_ctag_cos = pkt_info->source_cos;
    }

    new_cvlan_tag = (new_cvlan_tpid << 16)
                    | (new_ctag_cos << 13)
                    | (new_ctag_cfi << 12)
                    | mtu_msg->output_cvlan_id;

    pkt_info->l2_header[0] = new_mac_da[5];
    pkt_info->l2_header[1] = new_mac_da[4];
    pkt_info->l2_header[2] = new_mac_da[3];
    pkt_info->l2_header[3] = new_mac_da[2];
    pkt_info->l2_header[4] = new_mac_da[1];
    pkt_info->l2_header[5] = new_mac_da[0];

    pkt_info->l2_header[6] = new_mac_sa[5];
    pkt_info->l2_header[7] = new_mac_sa[4];
    pkt_info->l2_header[8] = new_mac_sa[3];
    pkt_info->l2_header[9] = new_mac_sa[2];
    pkt_info->l2_header[10] = new_mac_sa[1];
    pkt_info->l2_header[11] = new_mac_sa[0];

    if (L2_ETH_SNAP == p_ds_l2_edit_eth8_w->type)
    {
        /* ETHER_SNAP */

        new_snap_length = pkt_info->packet_length + 8 - (!pkt_info->non_crc ? 4 : 0);
        if (!pkt_info->packet_length_adjust_type)
        {
            new_snap_length += pkt_info->packet_length_adjust;
        }
        else
        {
            new_snap_length -= pkt_info->packet_length_adjust;
        }

        sal_memset(&epe_l2_snap_ctl, 0, sizeof(epe_l2_snap_ctl));
        cmd = DRV_IOR(EpeL2SnapCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_snap_ctl));

        if (svlan_tag_en)
        {
            pkt_info->l2_new_header_len = 26;
            offset = 16;
            /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], newSvlanTag[31:0], newSnapLength[15:0], 8'hAA, 8'hAA,
                              8'h3, epeL2SnapCtl.ouiValue[23:0], newEtherType[15:0]} */
            pkt_info->l2_header[12] = (new_svlan_tag >> 24) & 0xFF;
            pkt_info->l2_header[13] = (new_svlan_tag >> 16) & 0xFF;
            pkt_info->l2_header[14] = (new_svlan_tag >> 8) & 0xFF;
            pkt_info->l2_header[15] = new_svlan_tag & 0xFF;
        }
        else if (cvlan_tag_en)
        {
            pkt_info->l2_new_header_len = 26;
            offset = 16;
            /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], newCvlanTag[31:0], newSnapLength[15:0], 8'hAA, 8'hAA,
                              8'h3, epeL2SnapCtl.ouiValue[23:0], newEtherType[15:0]} */
            pkt_info->l2_header[12] = (new_cvlan_tag >> 24) & 0xFF;
            pkt_info->l2_header[13] = (new_cvlan_tag >> 16) & 0xFF;
            pkt_info->l2_header[14] = (new_cvlan_tag >> 8) & 0xFF;
            pkt_info->l2_header[15] = new_cvlan_tag & 0xFF;
        }
        else
        {
            pkt_info->l2_new_header_len = 22;
            offset = 12;
            /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], newSnapLength[15:0], 8'hAA, 8'hAA,
                              8'h3, epeL2SnapCtl.ouiValue[23:0], newEtherType[15:0]} */
        }

        pkt_info->l2_header[offset] = (new_snap_length >> 8) & 0xFF;
        pkt_info->l2_header[offset+1] = new_snap_length & 0xFF;
        pkt_info->l2_header[offset+2] = 0xAA;
        pkt_info->l2_header[offset+3] = 0xAA;
        pkt_info->l2_header[offset+4] = 0x03;
        pkt_info->l2_header[offset+5] = (epe_l2_snap_ctl.oui_value >> 16) & 0xFF;
        pkt_info->l2_header[offset+6] = (epe_l2_snap_ctl.oui_value >> 8) & 0xFF;
        pkt_info->l2_header[offset+7] = epe_l2_snap_ctl.oui_value & 0xFF;
        pkt_info->l2_header[offset+8] = (new_ether_type >> 8) & 0xFF;
        pkt_info->l2_header[offset+9] = new_ether_type & 0xFF;

        mtu_msg->layer2_type_update = L2_TYPE_ETHSNAP;

        if (epe_l2_edit_input_info->vlan_encode_en)
        {
            pkt_info->dest_mux_port_type = 0;
        }
    }
    else
    {
        /* ETHER_V2 */
        if (svlan_tag_en)
        {
            if (epe_l2_edit_input_info->mux_length_type == MUX_LENGTH_TYPE1)
            {
                offset = 20;
                pkt_info->l2_new_header_len = 18 + 4;
                /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], encodeVlanTag[63:32],
                                  newSvlanTag[31:0], newEtherType[15:0]} */
                pkt_info->l2_header[12] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 24) & 0xFF;
                pkt_info->l2_header[13] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 16) & 0xFF;
                pkt_info->l2_header[14] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 8) & 0xFF;
                pkt_info->l2_header[15] = epe_l2_edit_input_info->encode_vlan_tag_63_to_32 & 0xFF;
                pkt_info->l2_header[16] = (new_svlan_tag >> 24) & 0xFF;
                pkt_info->l2_header[17] = (new_svlan_tag >> 16) & 0xFF;
                pkt_info->l2_header[18] = (new_svlan_tag >> 8) & 0xFF;
                pkt_info->l2_header[19] = new_svlan_tag & 0xFF;
            }
            else if (epe_l2_edit_input_info->mux_length_type == MUX_LENGTH_TYPE2)
            {
                offset = 24;
                pkt_info->l2_new_header_len = 18 + 8;
                /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], encodeVlanTag[63:0],
                                  newSvlanTag[31:0], newEtherType[15:0]} */
                pkt_info->l2_header[12] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 24) & 0xFF;
                pkt_info->l2_header[13] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 16) & 0xFF;
                pkt_info->l2_header[14] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 8) & 0xFF;
                pkt_info->l2_header[15] = epe_l2_edit_input_info->encode_vlan_tag_63_to_32 & 0xFF;
                pkt_info->l2_header[16] = (epe_l2_edit_input_info->encode_vlan_tag_31_to_0 >> 24) & 0xFF;
                pkt_info->l2_header[17] = (epe_l2_edit_input_info->encode_vlan_tag_31_to_0 >> 16) & 0xFF;
                pkt_info->l2_header[18] = (epe_l2_edit_input_info->encode_vlan_tag_31_to_0 >> 8) & 0xFF;
                pkt_info->l2_header[19] = epe_l2_edit_input_info->encode_vlan_tag_31_to_0 & 0xFF;
                pkt_info->l2_header[20] = (new_svlan_tag >> 24) & 0xFF;
                pkt_info->l2_header[21] = (new_svlan_tag >> 16) & 0xFF;
                pkt_info->l2_header[22] = (new_svlan_tag >> 8) & 0xFF;
                pkt_info->l2_header[23] = new_svlan_tag & 0xFF;
            }
            else
            {
                offset = 16;
                pkt_info->l2_new_header_len = 18;
                /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], newSvlanTag[31:0], newEtherType[15:0]} */
                pkt_info->l2_header[12] = (new_svlan_tag >> 24) & 0xFF;
                pkt_info->l2_header[13] = (new_svlan_tag >> 16) & 0xFF;
                pkt_info->l2_header[14] = (new_svlan_tag >> 8) & 0xFF;
                pkt_info->l2_header[15] = new_svlan_tag & 0xFF;
            }
        }
        else if (cvlan_tag_en)
        {
            if (epe_l2_edit_input_info->mux_length_type == MUX_LENGTH_TYPE1)
            {
                offset = 20;
                pkt_info->l2_new_header_len = 18 + 4;
                /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], encodeVlanTag[63:32],
                                  newCvlanTag[31:0], newEtherType[15:0]} */
                pkt_info->l2_header[12] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 24) & 0xFF;
                pkt_info->l2_header[13] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 16) & 0xFF;
                pkt_info->l2_header[14] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 8) & 0xFF;
                pkt_info->l2_header[15] = epe_l2_edit_input_info->encode_vlan_tag_63_to_32 & 0xFF;
                pkt_info->l2_header[16] = (new_cvlan_tag >> 24) & 0xFF;
                pkt_info->l2_header[17] = (new_cvlan_tag >> 16) & 0xFF;
                pkt_info->l2_header[18] = (new_cvlan_tag >> 8) & 0xFF;
                pkt_info->l2_header[19] = new_cvlan_tag & 0xFF;
            }
            else if (epe_l2_edit_input_info->mux_length_type == MUX_LENGTH_TYPE2)
            {
                offset = 24;
                pkt_info->l2_new_header_len = 18 + 8;
                /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], encodeVlanTag[63:0],
                                  newCvlanTag[31:0], newEtherType[15:0]} */
                pkt_info->l2_header[12] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 24) & 0xFF;
                pkt_info->l2_header[13] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 16) & 0xFF;
                pkt_info->l2_header[14] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 8) & 0xFF;
                pkt_info->l2_header[15] = epe_l2_edit_input_info->encode_vlan_tag_63_to_32 & 0xFF;
                pkt_info->l2_header[16] = (epe_l2_edit_input_info->encode_vlan_tag_31_to_0 >> 24) & 0xFF;
                pkt_info->l2_header[17] = (epe_l2_edit_input_info->encode_vlan_tag_31_to_0 >> 16) & 0xFF;
                pkt_info->l2_header[18] = (epe_l2_edit_input_info->encode_vlan_tag_31_to_0 >> 8) & 0xFF;
                pkt_info->l2_header[19] = epe_l2_edit_input_info->encode_vlan_tag_31_to_0 & 0xFF;
                pkt_info->l2_header[20] = (new_cvlan_tag >> 24) & 0xFF;
                pkt_info->l2_header[21] = (new_cvlan_tag >> 16) & 0xFF;
                pkt_info->l2_header[22] = (new_cvlan_tag >> 8) & 0xFF;
                pkt_info->l2_header[23] = new_cvlan_tag & 0xFF;
            }
            else
            {
                pkt_info->l2_new_header_len = 18;
                offset = 16;
                /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], newCvlanTag[31:0], newEtherType[15:0]} */
                pkt_info->l2_header[12] = (new_cvlan_tag >> 24) & 0xFF;
                pkt_info->l2_header[13] = (new_cvlan_tag >> 16) & 0xFF;
                pkt_info->l2_header[14] = (new_cvlan_tag >> 8) & 0xFF;
                pkt_info->l2_header[15] = new_cvlan_tag & 0xFF;
            }
        }
        else
        {
            if (epe_l2_edit_input_info->mux_length_type == MUX_LENGTH_TYPE1)
            {
                offset = 16;
                pkt_info->l2_new_header_len = 14 + 4;
                /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], encodeVlanTag[63:32], newEtherType[15:0]} */
                pkt_info->l2_header[12] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 24) & 0xFF;
                pkt_info->l2_header[13] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 16) & 0xFF;
                pkt_info->l2_header[14] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 8) & 0xFF;
                pkt_info->l2_header[15] = epe_l2_edit_input_info->encode_vlan_tag_63_to_32 & 0xFF;
            }
            else if (epe_l2_edit_input_info->mux_length_type == MUX_LENGTH_TYPE2)
            {
                offset = 20;
                pkt_info->l2_new_header_len = 14 + 8;
                /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], encodeVlanTag[63:0], newEtherType[15:0]} */
                pkt_info->l2_header[12] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 24) & 0xFF;
                pkt_info->l2_header[13] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 16) & 0xFF;
                pkt_info->l2_header[14] = (epe_l2_edit_input_info->encode_vlan_tag_63_to_32 >> 8) & 0xFF;
                pkt_info->l2_header[15] = epe_l2_edit_input_info->encode_vlan_tag_63_to_32 & 0xFF;
                pkt_info->l2_header[16] = (epe_l2_edit_input_info->encode_vlan_tag_31_to_0 >> 24) & 0xFF;
                pkt_info->l2_header[17] = (epe_l2_edit_input_info->encode_vlan_tag_31_to_0 >> 16) & 0xFF;
                pkt_info->l2_header[18] = (epe_l2_edit_input_info->encode_vlan_tag_31_to_0 >> 8) & 0xFF;
                pkt_info->l2_header[19] = epe_l2_edit_input_info->encode_vlan_tag_31_to_0 & 0xFF;
            }
            else
            {
                pkt_info->l2_new_header_len = 14;
                offset = 12;
                /* l2NewHeader = {newMacDa[47:0], newMacSa[47:0], newEtherType[15:0]} */
            }
        }
        pkt_info->l2_header[offset] = (new_ether_type >> 8) & 0xFF;
        pkt_info->l2_header[offset+1] = new_ether_type & 0xFF;

        mtu_msg->layer2_type_update = L2_TYPE_ETHV2;

        if (epe_l2_edit_input_info->vlan_encode_en)
        {
            pkt_info->dest_mux_port_type = 0;
        }
    }

    /* PARSER_RESULT */
    if (svlan_tag_en)
    {
        pkt_info->new_cos = new_stag_cos & 0x7;
        pkt_info->new_cfi = new_stag_cfi & 0x1;
    }
    else if (cvlan_tag_en)
    {
        pkt_info->new_cos = new_ctag_cos & 0x7;
        pkt_info->new_cfi = new_ctag_cfi & 0x1;
    }
    else
    {
        pkt_info->new_cos = 0;
        pkt_info->new_cfi = 0;
    }

    mtu_msg->mac_da0_update = new_mac_da[0];
    mtu_msg->mac_da1_update = new_mac_da[1];
    mtu_msg->mac_da2_update = new_mac_da[2];
    mtu_msg->mac_da3_update = new_mac_da[3];
    mtu_msg->mac_da4_update = new_mac_da[4];
    mtu_msg->mac_da5_update = new_mac_da[5];

    mtu_msg->mac_sa0_update = new_mac_sa[0];
    mtu_msg->mac_sa1_update = new_mac_sa[1];
    mtu_msg->mac_sa2_update = new_mac_sa[2];
    mtu_msg->mac_sa3_update = new_mac_sa[3];
    mtu_msg->mac_sa4_update = new_mac_sa[4];
    mtu_msg->mac_sa5_update = new_mac_sa[5];

    mtu_msg->layer2_header_protocol_upate = new_ether_type;

    if (svlan_tag_en)
    {
        mtu_msg->svlan_id_update = mtu_msg->output_svlan_id;
        mtu_msg->stag_cos_update = new_stag_cos & 0x7;
        mtu_msg->stag_cfi_update = new_stag_cfi & 0x1;
        mtu_msg->svlan_id_valid_update = TRUE;
    }
    else
    {
        mtu_msg->svlan_id_update = 0;
        mtu_msg->stag_cos_update = 0;
        mtu_msg->stag_cfi_update = 0;
        mtu_msg->svlan_id_valid_update = FALSE;
    }

    if (cvlan_tag_en)
    {
        mtu_msg->cvlan_id_update = mtu_msg->output_cvlan_id;
        mtu_msg->ctag_cos_update = new_ctag_cos & 0x7;
        mtu_msg->ctag_cfi_update = new_ctag_cfi & 0x1;
        mtu_msg->cvlan_id_valid_update = TRUE;
    }
    else
    {
        mtu_msg->cvlan_id_update = 0;
        mtu_msg->ctag_cos_update = 0;
        mtu_msg->ctag_cfi_update = 0;
        mtu_msg->cvlan_id_valid_update = FALSE;
    }

    pkt_info->packet_type = PKT_TYPE_ETHERNETV2;
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      cm_epe_layer2_editing_handle
 * Purpose:   perform all Layer2 editing operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing information
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32
cm_epe_layer2_editing_handle(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    ds_l2_edit_eth8_w_t ds_l2_edit_eth8_w;
    ds_l2_edit_eth4_w_t ds_l2_edit_eth4_w_temp;
    ds_l2_edit_flex8_w_t ds_l2_edit_flex8_w;
    ds_l2_edit_pbb8_w_t ds_l2_edit_pbb8_w;
    ds_l2_edit_loopback_t ds_l2_edit_loopback;
    epe_l2_edit_input_info_t epe_l2_edit_input_info;
    epe_l2_port_mac_sa_t epe_l2_port_mac_sa;
    epe_l2_router_mac_sa_t epe_l2_router_mac_sa;
    epe_l2_edit_ctl_t epe_l2_edit_ctl;
    epe_l2_mac_sa_tmp_t epe_l2_mac_sa_tmp;
    epe_pkt_hdr_ctl_t epe_pkt_hdr_ctl;
    epe_pkt_proc_ctl_t epe_pkt_proc_ctl;
    epe_pkt_proc_mux_ctl_t epe_pkt_proc_mux_ctl;
    epe_hdr_proc_phy_port_map_t epe_hdr_proc_phy_port_map;
    epe_next_hop_ctl_t epe_next_hop_ctl;
    ds_port_link_agg_t ds_src_port_link_agg;
    ds_port_link_agg_t ds_dest_port_link_agg;
    ds_l2_edit_eth8_w_t* p_ds_l2_edit_eth8_w = NULL;
    ds_l2_edit_swap_t* p_ds_l2_edit_swap = NULL;
    ds_l2_edit_eth4_w_t* p_ds_l2_edit_eth4_w = NULL;
    ds_l2_edit_flex8_w_t* p_ds_l2_edit_flex8_w = NULL;
    ds_l2_edit_loopback_t* p_ds_l2_edit_loopback = NULL;
    ds_l2_edit_pbb8_w_t* p_ds_l2_edit_pbb8_w = NULL;
    ds_l3_edit_tunnel_v6_t* p_ds_l3_edit_tunnel_v6 = NULL;
    cm_epe_l2_edit_mtu_msg_t cm_epe_l2_edit_mtu_msg;

    uint32 cmd = 0;
    uint8 l2_rewrite_type = 0, l3_rewrite_type = 0;
    uint8* p_l2edit = NULL;
    uint8 mac_da_match0 = FALSE, mac_da_match1 = FALSE;
    uint8 vlan_encode_en = FALSE, vlan_encode_type = 0;
    uint16 mux_vlan_id = 0;
    uint8 mux_length_type = 0;
    uint8 channel_id_match = FALSE;
    uint16 source_ecid = 0;
    uint16 ecid = 0;
    uint32 encode_vlan_tag_63_to_32 = 0, encode_vlan_tag_31_to_0 = 0;
    uint16 source_port = 0;
    uint8 extra_header_type = 0;
    uint16 port_extender_source_port = 0;
    uint16 port_extender_port_vlan_base = 0;
    uint8 is_end = FALSE;
    uint16 packet_length_adjust = 0;
    uint8 symbol = 0;
    uint8 no_operation = FALSE, eth_operation = FALSE, flex_operation = FALSE, loop_operation = FALSE;
    uint8 pbb_operation = FALSE, swap_operation = FALSE;

    sal_memset(&ds_l2_edit_eth4_w_temp, 0, sizeof(ds_l2_edit_eth4_w_t));
    sal_memset(&ds_l2_edit_eth8_w, 0, sizeof(ds_l2_edit_eth8_w_t));
    sal_memset(&ds_l2_edit_flex8_w, 0, sizeof(ds_l2_edit_flex8_w_t));
    sal_memset(&ds_l2_edit_pbb8_w, 0, sizeof(ds_l2_edit_pbb8_w_t));
    sal_memset(&ds_l2_edit_loopback, 0, sizeof(ds_l2_edit_loopback_t));
    sal_memset(&epe_l2_edit_input_info, 0, sizeof(epe_l2_edit_input_info_t));

    /* INIT */
    sal_memset(&epe_next_hop_ctl, 0, sizeof(epe_next_hop_ctl_t));
    cmd = DRV_IOR(EpeNextHopCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_next_hop_ctl));

    source_port = pkt_info->source_port & 0x3FFF;

    if (epe_next_hop_ctl.stacking_en)
    {
        if ((pkt_info->source_port >> 9) == 0x1F)
        {
            source_port &= 0xFE3F; /* sourcePort[8:6] = 3b'000 */
        }
    }

    sal_memset(&ds_dest_port_link_agg, 0, sizeof(ds_port_link_agg_t));
    cmd = DRV_IOR(DsPortLinkAgg_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, pkt_info->local_phy_port, cmd, &ds_dest_port_link_agg));

    sal_memset(&ds_src_port_link_agg, 0, sizeof(ds_port_link_agg_t));
    cmd = DRV_IOR(DsPortLinkAgg_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, (source_port & 0x7F), cmd, &ds_src_port_link_agg));

    sal_memset(&epe_pkt_hdr_ctl, 0, sizeof(epe_pkt_hdr_ctl_t));
    cmd = DRV_IOR(EpePktHdrCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_hdr_ctl));

    sal_memset(&epe_l2_port_mac_sa, 0, sizeof(epe_l2_port_mac_sa_t));
    cmd = DRV_IOR(EpeL2PortMacSa_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_port_mac_sa));

    sal_memset(&epe_l2_router_mac_sa, 0, sizeof(epe_l2_router_mac_sa_t));
    cmd = DRV_IOR(EpeL2PortMacSa_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_router_mac_sa));

    sal_memset(&epe_l2_edit_ctl, 0, sizeof(epe_l2_edit_ctl_t));
    cmd = DRV_IOR(EpeL2EditCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_l2_edit_ctl));

    sal_memset(&cm_epe_l2_edit_mtu_msg, 0, sizeof(cm_epe_l2_edit_mtu_msg_t));

    pkt_info->source_channel_link_aggregate_en = ds_src_port_link_agg.channel_link_aggregate_en;
    pkt_info->source_channel_link_aggregate = ds_src_port_link_agg.channel_link_aggregate;
    pkt_info->dest_channel_link_aggregate_en = ds_dest_port_link_agg.channel_link_aggregate_en;
    pkt_info->dest_channel_link_aggregate = ds_dest_port_link_agg.channel_link_aggregate;

    /* DS_L2_EDIT_CHECK */
    if (pkt_info->l2_edit_ptr_bit0)
    {
        /* [78:0] */
        p_l2edit = pkt_info->l2_edit + sizeof(ds_l2_edit_eth4_w_t);
        p_ds_l2_edit_eth4_w = (ds_l2_edit_eth4_w_t*)p_l2edit;
        l2_rewrite_type = p_ds_l2_edit_eth4_w->l2_rewrite_type; /* shared l2RewriteType[2:0] (DsL2EditBits[157:155]) ??? */
        p_ds_l2_edit_eth8_w = (ds_l2_edit_eth8_w_t*)p_l2edit;
    }
    else
    {
        p_l2edit = pkt_info->l2_edit;
        p_ds_l2_edit_eth8_w = (ds_l2_edit_eth8_w_t*)p_l2edit;
        l2_rewrite_type = p_ds_l2_edit_eth8_w->l2_rewrite_type;

        if ((L2_REW_ETH_8W == l2_rewrite_type) || (L2_REW_MAC_SWAP == l2_rewrite_type)
            || (L2_REW_PBB_8W == l2_rewrite_type) || (L2_REW_FLEX_8W == l2_rewrite_type))
        {
            /* [157:0] */
        }
        else
        {
            /* [157:80] */
            sal_memset(pkt_info->l2_edit + sizeof(ds_l2_edit_eth4_w_t), 0, sizeof(ds_l2_edit_eth4_w_t));
        }

        extra_header_type = (p_ds_l2_edit_eth8_w->extra_header_type1_1 << 1)
                                | p_ds_l2_edit_eth8_w->extra_header_type0_0;
    }

    pkt_info->l2_new_header_len = 0;
    p_ds_l3_edit_tunnel_v6 = (ds_l3_edit_tunnel_v6_t*)pkt_info->l3_edit;
    l3_rewrite_type = p_ds_l3_edit_tunnel_v6->l3_rewrite_type;

    if (!pkt_info->discard
        && (((DS_TYPE_DISCARD == p_ds_l2_edit_eth8_w->ds_type)
        && p_ds_l2_edit_eth8_w->ip_da79_79  /* used as discardType */
        && (pkt_info->rx_oam_type == OAM_NONE))
        || ((DS_TYPE_DISCARD == p_ds_l2_edit_eth8_w->ds_type)
        && (!p_ds_l2_edit_eth8_w->ip_da79_79))))   /* used as discardType */
    {
        pkt_info->discard_type = EPE_DISCARD_DS_L2_EDIT_DATA_VIOLATE_1;
        pkt_info->discard = TRUE;   /* DsMpls,DsVlan,etc,.need add this control ??? */
        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Layer2 edit discardPacket!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }

    if (!pkt_info->discard
        && (pkt_info->ds_l2_edit_exist
        && (p_ds_l2_edit_eth8_w->is_met
        || p_ds_l2_edit_eth8_w->is_nexthop
        || (DS_TYPE_L2EDIT != p_ds_l2_edit_eth8_w->ds_type)))
        && !pkt_info->bypass_all)
    {
        pkt_info->discard_type = EPE_DISCARD_DS_L2_EDIT_DATA_VIOLATE_2;
        pkt_info->discard = TRUE;
        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE Layer2 edit discardPacket!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }

    is_end = (pkt_info->ds_l2_edit_exist
             && (p_ds_l2_edit_eth8_w->is_met
             || p_ds_l2_edit_eth8_w->is_nexthop
             || (DS_TYPE_L2EDIT != p_ds_l2_edit_eth8_w->ds_type)))
             || pkt_info->bypass_all;

    /* DS_L2_EDIT_ERROR_SWITCH */
    if (is_end)
    {
        pkt_info->frag_info =parser_result->l3_s.frag_info;
        pkt_info->layer3_offset = parser_result->l2_s.layer3_offset;
        pkt_info->layer4_offset = parser_result->l3_s.layer4_offset;
        return DRV_E_NONE;
    }

    /* DISCARD_SWITCH */
    if (!pkt_info->discard)
    {
        /* LAYER2_REWRITE_TYPE */
        if (L2_REW_ETH_8W == l2_rewrite_type)
        {
            if ((extra_header_type & 0x3) == EXTRA_HEADER_TYPE_NO_L2_EDIT)
            {
                l2_rewrite_type = L2_REW_NONE;
            }
            else
            {
                /* use DsL2EditEth4W */
            }
        }

        sal_memset(&ds_l2_edit_eth4_w_temp, 0, sizeof(ds_l2_edit_eth4_w_t));
        sal_memcpy(&ds_l2_edit_eth4_w_temp, p_l2edit, sizeof(ds_l2_edit_eth4_w_t));

        no_operation = (l2_rewrite_type == L2_REW_NONE) && (!pkt_info->route_no_l2_edit);
        eth_operation = ((l2_rewrite_type == L2_REW_ETH_4W) || (l2_rewrite_type == L2_REW_ETH_8W))
                        || pkt_info->route_no_l2_edit;
        flex_operation = (l2_rewrite_type == L2_REW_FLEX_8W);
        loop_operation = (l2_rewrite_type == L2_REW_LOOPBACK);
        pbb_operation = ((l2_rewrite_type == L2_REW_PBB_4W) || (l2_rewrite_type == L2_REW_PBB_8W));
        swap_operation = (l2_rewrite_type == L2_REW_MAC_SWAP);

        sal_memset(&epe_pkt_proc_mux_ctl, 0, sizeof(epe_pkt_proc_mux_ctl_t));
        cmd = DRV_IOR(EpePktProcMuxCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_mux_ctl));

        sal_memset(&epe_hdr_proc_phy_port_map, 0, sizeof(epe_hdr_proc_phy_port_map_t));

        switch (pkt_info->dest_mux_port_type)
        {
            case 2:
                vlan_encode_en = TRUE;
                vlan_encode_type = 0;     /* old MUX/DEMUX */
                cmd = DRV_IOR(EpeHdrProcPhyPortMap_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_hdr_proc_phy_port_map));
                mux_vlan_id = epe_hdr_proc_phy_port_map.symbol ?
                              (pkt_info->local_phy_port - (epe_hdr_proc_phy_port_map.port_vlan_base & 0x1FF)) :
                              (pkt_info->local_phy_port + (epe_hdr_proc_phy_port_map.port_vlan_base & 0xFFF));
                break;
            case 4:                       /* EVB */
                if (!pkt_info->use_logic_port)  /* use localPhyPort */
                {
                    if (!pkt_info->evb_default_local_phy_port_valid)
                    {
                        vlan_encode_en = TRUE;
                        vlan_encode_type = 1;
                        cmd = DRV_IOR(EpeHdrProcPhyPortMap_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_hdr_proc_phy_port_map));
                        mux_vlan_id = epe_hdr_proc_phy_port_map.symbol ?
                                      (pkt_info->local_phy_port - (epe_hdr_proc_phy_port_map.port_vlan_base & 0x1FF)) :
                                      (pkt_info->local_phy_port + (epe_hdr_proc_phy_port_map.port_vlan_base & 0xFFF));
                    }
                    else
                    {
                        vlan_encode_en = FALSE;   /* priority EVB tagged not support ??? */
                    }
                }
                else                      /* use logicDestPort */
                {
                    if (!pkt_info->evb_default_logic_port_valid)
                    {
                        vlan_encode_en = TRUE;
                        vlan_encode_type = 1;
                        cmd = DRV_IOR(EpeHdrProcPhyPortMap_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_hdr_proc_phy_port_map));
                        mux_vlan_id = epe_hdr_proc_phy_port_map.symbol ?
                                      (pkt_info->logic_dest_port - epe_hdr_proc_phy_port_map.port_vlan_base) :
                                      (pkt_info->logic_dest_port + epe_hdr_proc_phy_port_map.port_vlan_base);
                    }
                    else
                    {
                        vlan_encode_en = FALSE;   /* priority EVB tagged not support ??? */
                    }
                }
                break;
            case 5:                       /* Controlling bridge */
                /* only support channel linkagg in same chip for memory saving.
                   not support localPhyPort based linkagg for PE/CB multicast replication interaction with linkagg
                */
                if (IS_BIT_SET(pkt_info->dest_map, 21))   /* multicast */
                {
                    channel_id_match = ((pkt_info->dest_channel_link_aggregate_en == pkt_info->source_channel_link_aggregate_en)
                                       && (pkt_info->dest_channel_link_aggregate == pkt_info->source_channel_link_aggregate));

                    port_extender_source_port = pkt_info->use_logic_port ? pkt_info->logic_src_port : (source_port & 0x1FF);
                    cmd = DRV_IOR(EpeHdrProcPhyPortMap_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_hdr_proc_phy_port_map));
                    port_extender_port_vlan_base = epe_hdr_proc_phy_port_map.port_vlan_base;
                    symbol = epe_hdr_proc_phy_port_map.symbol;
                    source_ecid = !channel_id_match ? 0 : (symbol ?
                                  (port_extender_source_port - port_extender_port_vlan_base) :
                                  (port_extender_source_port + port_extender_port_vlan_base));
                    ecid = (pkt_info->mcast_id - ((epe_pkt_proc_mux_ctl.port_extender_met_base & 0xFF) << 6)) + 4096;
                    vlan_encode_en = TRUE;
                    vlan_encode_type = 2;   /* port extender */
                }
                else    /* unicast */
                {
                    source_ecid = 0;

                    if (!pkt_info->use_logic_port)  /* use localPhyPort */
                    {
                        if (!pkt_info->evb_default_local_phy_port_valid)
                        {
                            vlan_encode_en = TRUE;
                            vlan_encode_type = 2;
                            /* same localPhyPort for different linkagg member port */

                            cmd = DRV_IOR(EpeHdrProcPhyPortMap_t, DRV_ENTRY_FLAG);
                            DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_hdr_proc_phy_port_map));
                            ecid = ecid & 0xFFF;
                            ecid = epe_hdr_proc_phy_port_map.symbol ?
                                      (pkt_info->local_phy_port - (epe_hdr_proc_phy_port_map.port_vlan_base & 0x1FF)) :
                                      (pkt_info->local_phy_port + (epe_hdr_proc_phy_port_map.port_vlan_base & 0xFFF));
                        }
                        else
                        {
                            vlan_encode_en = FALSE;
                        }
                    }
                    else    /* use logicDestPort */
                    {
                        if (!pkt_info->evb_default_logic_port_valid)
                        {
                            vlan_encode_en = TRUE;
                            vlan_encode_type = 2;

                            cmd = DRV_IOR(EpeHdrProcPhyPortMap_t, DRV_ENTRY_FLAG);
                            DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_hdr_proc_phy_port_map));
                            ecid = ecid & 0xFFF;
                            ecid = epe_hdr_proc_phy_port_map.symbol ?
                                   (pkt_info->logic_src_port - epe_hdr_proc_phy_port_map.port_vlan_base) :
                                   (pkt_info->logic_src_port + epe_hdr_proc_phy_port_map.port_vlan_base);
                        }
                        else
                        {
                            vlan_encode_en = FALSE;
                        }
                    }
                }
                break;
             case 6:                      /* PE Uplink */
                source_ecid = 0;

                if (!pkt_info->use_logic_port)  /* use localPhyPort */
                {
                    if (((source_port & 0x3FFF) != pkt_info->global_dest_port) && !pkt_info->source_port_extender)
                    {
                        vlan_encode_en = TRUE;
                        vlan_encode_type = 2;   /* port extender */

                        cmd = DRV_IOR(EpeHdrProcPhyPortMap_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_hdr_proc_phy_port_map));
                        ecid = ecid & 0xFFF;
                        ecid = epe_hdr_proc_phy_port_map.symbol ?
                               ((source_port & 0x1FF) - (epe_hdr_proc_phy_port_map.port_vlan_base & 0x1FF)) :
                               ((source_port & 0x1FF) + (epe_hdr_proc_phy_port_map.port_vlan_base & 0xFFF));
                    }
                    else
                    {
                        vlan_encode_en = FALSE;
                    }
                }
                else
                {
                    if ((pkt_info->logic_src_port != pkt_info->logic_dest_port) && !pkt_info->source_port_extender)
                    {
                        vlan_encode_en = TRUE;
                        vlan_encode_type = 2;   /* port extender */
                        cmd = DRV_IOR(EpeHdrProcPhyPortMap_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, ipkt->chan_id, cmd, &epe_hdr_proc_phy_port_map));
                        ecid = ecid & 0xFFF;
                        ecid = epe_hdr_proc_phy_port_map.symbol ?
                               (pkt_info->logic_dest_port - epe_hdr_proc_phy_port_map.port_vlan_base) :
                               (pkt_info->logic_dest_port + epe_hdr_proc_phy_port_map.port_vlan_base);
                    }
                    else
                    {
                        vlan_encode_en = FALSE;
                    }
                }
                break;
             default:
                break;
        }

        mux_length_type = MUX_LENGTH_TYPE0;

        if (vlan_encode_en)
        {
            sal_memset(&epe_pkt_proc_ctl, 0, sizeof(epe_pkt_proc_ctl_t));
            cmd = DRV_IOR(EpePktProcCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_pkt_proc_ctl));

            switch (vlan_encode_type)   /* use outer vlan cos/cfi */
            {
                case 0:
                    encode_vlan_tag_63_to_32 = (0x8100 << 16)
                                               | (pkt_info->mapped_cos << 13)
                                               | (pkt_info->mapped_cfi << 12)
                                               | (mux_vlan_id & 0xFFF);
                    mux_length_type = MUX_LENGTH_TYPE1;
                    break;
                case 1:
                    encode_vlan_tag_63_to_32 = (epe_pkt_proc_ctl.evb_tpid << 16)
                                               | (pkt_info->mapped_cos << 13)
                                               | (pkt_info->mapped_cfi << 12)
                                               | (mux_vlan_id & 0xFFF);
                    mux_length_type = MUX_LENGTH_TYPE1;
                    break;
                case 2:
                    encode_vlan_tag_63_to_32 = (epe_pkt_proc_ctl.port_extender_tpid << 16)
                                               | (pkt_info->mapped_cos << 13)
                                               | (pkt_info->mapped_cfi << 12)
                                               | (source_ecid & 0xFFF);
                    encode_vlan_tag_31_to_0 = ((ecid & 0x3FFF) << 16);
                    mux_length_type = MUX_LENGTH_TYPE2;
                    break;
                default:
                    break;
            }
        }

        /* some temp var */
        epe_l2_edit_input_info.vlan_encode_en = (vlan_encode_en & 0x1);
        epe_l2_edit_input_info.mux_length_type = (mux_length_type & 0x3);
        epe_l2_edit_input_info.encode_vlan_tag_63_to_32 = encode_vlan_tag_63_to_32;
        epe_l2_edit_input_info.encode_vlan_tag_31_to_0 = encode_vlan_tag_31_to_0;

        if (pkt_info->port_mac_sa_en)
        {
            pkt_info->new_macsa_valid = TRUE;

            switch (pkt_info->port_mac_sa_type)
            {
            case 0:
                pkt_info->new_macsa_lower32 = (epe_l2_port_mac_sa.port_mac_sa0_31_8 << 8) | (pkt_info->port_mac_sa);
                pkt_info->new_macsa_upper16 = epe_l2_port_mac_sa.port_mac_sa0_47_32;

                break;
            case 1:
                pkt_info->new_macsa_lower32 = (epe_l2_port_mac_sa.port_mac_sa1_31_8 << 8) | (pkt_info->port_mac_sa);
                pkt_info->new_macsa_upper16 = epe_l2_port_mac_sa.port_mac_sa1_47_32;

                break;
            default:
                break;
            }
        }

        if (no_operation)
        {
            /* to LENGTH_ADJUST */
        }
        else if (eth_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer2 Editing Process: Eth Operate");
            /* L2_ETHERNET_EDITING */
            p_ds_l2_edit_eth8_w = (ds_l2_edit_eth8_w_t*)p_l2edit;
            if (((L2_REW_ETH_8W == l2_rewrite_type)
                && (((p_ds_l2_edit_eth8_w->extra_header_type1_1 << 1)
                | p_ds_l2_edit_eth8_w->extra_header_type0_0) == EXTRA_HEADER_TYPE_MPLS)
                && ((pkt_info->l3_rewrite_type == L3_REW_MPLS_4W)
                || (!pkt_info->ds_l3_edit_exist)))
                || ((L3_REW_TUNNEL_V6 == l3_rewrite_type) && (L2_REW_ETH_8W == l2_rewrite_type)))     /* the condition is not show on SPEC */
            {
                sal_memset(pkt_info->l2_edit + sizeof(ds_l2_edit_eth4_w_t), 0, sizeof(ds_l2_edit_eth4_w_t));
            }
            DRV_IF_ERROR_RETURN(_cm_epe_layer2_editing_eth(ipkt, p_ds_l2_edit_eth8_w,
                            &epe_l2_edit_input_info, &cm_epe_l2_edit_mtu_msg));
        }
        else if (flex_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer2 Editing Process: Flex Operate");
            /* L2_FLEX_EDITING */
            p_ds_l2_edit_flex8_w = (ds_l2_edit_flex8_w_t*)p_l2edit;
            DRV_IF_ERROR_RETURN(_cm_epe_layer2_editing_flex(ipkt, p_ds_l2_edit_flex8_w, &cm_epe_l2_edit_mtu_msg));
        }
        else if (loop_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer2 Editing Process: Loopback Operate");
            /* L2_LOOPBACK_EDITING */
            p_ds_l2_edit_loopback = (ds_l2_edit_loopback_t*)p_l2edit;
            DRV_IF_ERROR_RETURN(_cm_epe_layer2_editing_loopback(ipkt, p_ds_l2_edit_loopback));
        }
        else if (pbb_operation)
        {
            /* L2_PBB_EDITING */
            p_ds_l2_edit_pbb8_w = (ds_l2_edit_pbb8_w_t*)p_l2edit;
            DRV_IF_ERROR_RETURN(_cm_epe_layer2_editing_pbb(ipkt, p_ds_l2_edit_pbb8_w, &cm_epe_l2_edit_mtu_msg));
        }
        else if (swap_operation)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE Layer2 Editing Process: Swap Operate");
            /* L2_MAC_SWAP_EDITING */
            p_ds_l2_edit_swap = (ds_l2_edit_swap_t*)p_l2edit;
            DRV_IF_ERROR_RETURN(_cm_epe_layer2_editing_mac_swap(ipkt, p_ds_l2_edit_swap, &cm_epe_l2_edit_mtu_msg));
        }
    }

    /* LENGTH_ADJUST */
    pkt_info->ptp_offset = pkt_info->ptp_offset + pkt_info->l2_new_header_len;

    packet_length_adjust = func_packet_length_adjust_add(ipkt, pkt_info->l2_new_header_len);
    pkt_info->packet_length_adjust_type = (packet_length_adjust >> 8) & 0x1;
    pkt_info->packet_length_adjust = packet_length_adjust & 0xFF;

    /* ParserResult */
    if (eth_operation)
    {
        parser_result->layer2_type = cm_epe_l2_edit_mtu_msg.layer2_type_update;
        parser_result->l2_s.mac_da0 = cm_epe_l2_edit_mtu_msg.mac_da0_update;
        parser_result->l2_s.mac_da1 = cm_epe_l2_edit_mtu_msg.mac_da1_update;
        parser_result->l2_s.mac_da2 = cm_epe_l2_edit_mtu_msg.mac_da2_update;
        parser_result->l2_s.mac_da3 = cm_epe_l2_edit_mtu_msg.mac_da3_update;
        parser_result->l2_s.mac_da4 = cm_epe_l2_edit_mtu_msg.mac_da4_update;
        parser_result->l2_s.mac_da5 = cm_epe_l2_edit_mtu_msg.mac_da5_update;
        parser_result->l2_s.mac_sa0 = cm_epe_l2_edit_mtu_msg.mac_sa0_update;
        parser_result->l2_s.mac_sa1 = cm_epe_l2_edit_mtu_msg.mac_sa1_update;
        parser_result->l2_s.mac_sa2 = cm_epe_l2_edit_mtu_msg.mac_sa2_update;
        parser_result->l2_s.mac_sa3 = cm_epe_l2_edit_mtu_msg.mac_sa3_update;
        parser_result->l2_s.mac_sa4 = cm_epe_l2_edit_mtu_msg.mac_sa4_update;
        parser_result->l2_s.mac_sa5 = cm_epe_l2_edit_mtu_msg.mac_sa5_update;
        parser_result->l2_s.layer2_header_protocol = cm_epe_l2_edit_mtu_msg.layer2_header_protocol_upate;
        parser_result->l2_s.svlan_id = cm_epe_l2_edit_mtu_msg.svlan_id_update;
        parser_result->l2_s.stag_cos = cm_epe_l2_edit_mtu_msg.stag_cos_update;
        parser_result->l2_s.stag_cfi = cm_epe_l2_edit_mtu_msg.stag_cfi_update;
        parser_result->l2_s.svlan_id_valid = cm_epe_l2_edit_mtu_msg.svlan_id_valid_update;
        parser_result->l2_s.cvlan_id = cm_epe_l2_edit_mtu_msg.cvlan_id_update;
        parser_result->l2_s.ctag_cos = cm_epe_l2_edit_mtu_msg.ctag_cos_update;
        parser_result->l2_s.ctag_cfi = cm_epe_l2_edit_mtu_msg.ctag_cfi_update;
        parser_result->l2_s.cvlan_id_valid = cm_epe_l2_edit_mtu_msg.cvlan_id_valid_update;
    }
    else if (flex_operation)
    {
        parser_result->layer2_type = cm_epe_l2_edit_mtu_msg.layer2_type_update;
    }
    else if (pbb_operation)
    {
        if (cm_epe_l2_edit_mtu_msg.mac_da_en_update)
        {
            parser_result->l2_s.mac_da0 = cm_epe_l2_edit_mtu_msg.mac_da0_update;
            parser_result->l2_s.mac_da1 = cm_epe_l2_edit_mtu_msg.mac_da1_update;
            parser_result->l2_s.mac_da2 = cm_epe_l2_edit_mtu_msg.mac_da2_update;
            parser_result->l2_s.mac_da3 = cm_epe_l2_edit_mtu_msg.mac_da3_update;
            parser_result->l2_s.mac_da4 = cm_epe_l2_edit_mtu_msg.mac_da4_update;
            parser_result->l2_s.mac_da5 = cm_epe_l2_edit_mtu_msg.mac_da5_update;
        }

        if (cm_epe_l2_edit_mtu_msg.mac_sa_en_update)
        {
            parser_result->l2_s.mac_sa0 = cm_epe_l2_edit_mtu_msg.mac_sa0_update;
            parser_result->l2_s.mac_sa1 = cm_epe_l2_edit_mtu_msg.mac_sa1_update;
            parser_result->l2_s.mac_sa2 = cm_epe_l2_edit_mtu_msg.mac_sa2_update;
            parser_result->l2_s.mac_sa3 = cm_epe_l2_edit_mtu_msg.mac_sa3_update;
            parser_result->l2_s.mac_sa4 = cm_epe_l2_edit_mtu_msg.mac_sa4_update;
            parser_result->l2_s.mac_sa5 = cm_epe_l2_edit_mtu_msg.mac_sa5_update;
        }
            parser_result->l2_s.svlan_id = cm_epe_l2_edit_mtu_msg.svlan_id_update;
            parser_result->l2_s.stag_cos = cm_epe_l2_edit_mtu_msg.stag_cos_update;
            parser_result->l2_s.stag_cfi = cm_epe_l2_edit_mtu_msg.stag_cfi_update;
    }
    else if (swap_operation)
    {
        if (cm_epe_l2_edit_mtu_msg.mac_da_en_update)
        {
            parser_result->l2_s.mac_da0 = cm_epe_l2_edit_mtu_msg.mac_da0_update;
            parser_result->l2_s.mac_da1 = cm_epe_l2_edit_mtu_msg.mac_da1_update;
            parser_result->l2_s.mac_da2 = cm_epe_l2_edit_mtu_msg.mac_da2_update;
            parser_result->l2_s.mac_da3 = cm_epe_l2_edit_mtu_msg.mac_da3_update;
            parser_result->l2_s.mac_da4 = cm_epe_l2_edit_mtu_msg.mac_da4_update;
            parser_result->l2_s.mac_da5 = cm_epe_l2_edit_mtu_msg.mac_da5_update;
        }

        if (cm_epe_l2_edit_mtu_msg.mac_sa_en_update)
        {
            parser_result->l2_s.mac_sa0 = cm_epe_l2_edit_mtu_msg.mac_sa0_update;
            parser_result->l2_s.mac_sa1 = cm_epe_l2_edit_mtu_msg.mac_sa1_update;
            parser_result->l2_s.mac_sa2 = cm_epe_l2_edit_mtu_msg.mac_sa2_update;
            parser_result->l2_s.mac_sa3 = cm_epe_l2_edit_mtu_msg.mac_sa3_update;
            parser_result->l2_s.mac_sa4 = cm_epe_l2_edit_mtu_msg.mac_sa4_update;
            parser_result->l2_s.mac_sa5 = cm_epe_l2_edit_mtu_msg.mac_sa5_update;
        }
    }

    sal_memset(&epe_l2_mac_sa_tmp, 0, sizeof(epe_l2_mac_sa_tmp_t));

    switch (pkt_info->port_mac_sa_type)
    {
        case 0:
            epe_l2_mac_sa_tmp.mac_sa_h = epe_l2_port_mac_sa.port_mac_sa0_47_32;
            epe_l2_mac_sa_tmp.mac_sa_l = epe_l2_port_mac_sa.port_mac_sa0_31_8;
            break;
        case 1:
            epe_l2_mac_sa_tmp.mac_sa_h = epe_l2_port_mac_sa.port_mac_sa1_47_32;
            epe_l2_mac_sa_tmp.mac_sa_l = epe_l2_port_mac_sa.port_mac_sa1_31_8;
            break;
        default:
            break;
    }

    mac_da_match0 = (parser_result->l2_s.mac_da1 == (epe_l2_mac_sa_tmp.mac_sa_l & 0xFF))
                && (parser_result->l2_s.mac_da2 == ((epe_l2_mac_sa_tmp.mac_sa_l >> 8) & 0xFF))
                && (parser_result->l2_s.mac_da3 == ((epe_l2_mac_sa_tmp.mac_sa_l >> 16) & 0xFF))
                && (parser_result->l2_s.mac_da4 == (epe_l2_mac_sa_tmp.mac_sa_h & 0xFF))
                && (parser_result->l2_s.mac_da5 == ((epe_l2_mac_sa_tmp.mac_sa_h >> 8) & 0xFF));

    mac_da_match1 = (parser_result->l2_s.mac_da0 == (epe_l2_edit_ctl.system_mac_low & 0xFF))
                && (parser_result->l2_s.mac_da1 == ((epe_l2_edit_ctl.system_mac_low >> 8) & 0xFF))
                && (parser_result->l2_s.mac_da2 == ((epe_l2_edit_ctl.system_mac_low >> 16) & 0xFF))
                && (parser_result->l2_s.mac_da3 == ((epe_l2_edit_ctl.system_mac_low >> 24) & 0xFF))
                && (parser_result->l2_s.mac_da4 == (epe_l2_edit_ctl.system_mac_high & 0xFF))
                && (parser_result->l2_s.mac_da5 == ((epe_l2_edit_ctl.system_mac_high >> 8) & 0xFF));

    if ((mac_da_match0 && (parser_result->l2_s.mac_da0 == pkt_info->port_mac_sa))
        || (mac_da_match1 && epe_l2_edit_ctl.system_mac_en))
    {
        pkt_info->is_port_mac = TRUE;
    }
    pkt_info->frag_info =parser_result->l3_s.frag_info;

    pkt_info->layer3_offset = parser_result->l2_s.layer3_offset;
    pkt_info->layer4_offset = parser_result->l3_s.layer4_offset;


    return DRV_E_NONE;
}

