/****************************************************************************
 * sim_interface.c
 *
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jack Xu
 * Date:         2011-10-13
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sim_interface.h"
#include "sim_ipe_interface.h"
#include "sim_epe_interface.h"
#include "sim_bsr_interface.h"
#include "sim_oam_interface.h"
#include "sim_table_chk_interface.h"
#include "sim_key_chk_interface.h"
#include "sram_model.h"
#include "tcam_model.h"
#include "cm_com_cfg_kit.h"

/* dump file directory: /dump_cmodel_linklist_file.txt" */
#define DUMP_CMODEL_LINKLIST_FILE_NAME "/dump_cmodel_linklist_file.txt"

bool sim_interface_initialize = FALSE;

cosim_cm_db_t cosim_db;
cosim_discard_info_t cosim_discard_info;
cosim_api_callback_fun_t cosim_api;

char* sim_module_name[] = {"ipe", "epe", "oam", "bsr", NULL};

char* sim_ipe_bus_name[] = {"ha2pr", "ha2im", "im2pp", "ilreq", "olreq","impi2lm",
                             "impr2lm", "lr2fw", "lm2pp", "om2fw",
                             "pr2im", "pr2lm", "rt2fw", "ui2pp", "excp",
                             "om2fwd_sh_lm", "om2fwd_sh_nat", "om2fwd_sh_oam", "om2fwd_sh_ptp", "om2fwd_sh_dm", NULL};

char* sim_bsr_bus_name[] = {"metfifo", "enqueue", "dequeue", NULL};

char* sim_epe_bus_name[] = {"aq2cs", "cs2om", "ha2hp", "ha2nh",
                             "ha2pr", "hp2aq", "hp2he", "hp2om",
                             "nh2hp", "om2he", "pr2hp", "nettx", "excp",
                             "ha2nh_sh_lm", "ha2nh_sh_nat", "ha2nh_sh_oam", "ha2nh_sh_ptp", "ha2nh_sh_dm",
                             "hp2om_sh_lm", "ha2nh_sh_nat", "ha2nh_sh_oam", "ha2nh_sh_ptp", "ha2nh_sh_dm",
                             "nh2hp_sh_lm", "nh2hp_sh_nat", "nh2hp_sh_oam", "nh2hp_sh_ptp", "nh2hp_sh_dm",
                             "om2he_sh_lm", "om2he_sh_nat", "om2he_sh_oam", "om2he_sh_ptp", "om2he_sh_dm",
                             NULL};

char* sim_oam_bus_name[] = {"ha2pp", "pp2fw", "pr2pp", NULL};

char** sim_x_bus[SIM_MODULE_NUM] = {sim_ipe_bus_name, sim_epe_bus_name, sim_oam_bus_name, sim_bsr_bus_name};

list_head_t* sim_x_moduel_list[SIM_MODULE_NUM] = {cosim_db.sim_ipe_list, cosim_db.sim_epe_list,
                                                  cosim_db.sim_oam_list, cosim_db.sim_fwd_list};

/*---- Parser memory allocation using on cosim -----*/
enum sim_alloc_mem_type_e
{
    SIM_MEM_DYNIC_TBL,
    SIM_MEM_TCAM_KEY_INIT,
    SIM_MEM_TCAM_KEY,
    SIM_MEM_TCAM_AD,
    SIM_MEM_LPM_TCAM_KEY,
    SIM_MEM_PROFILE_INIT,
    SIM_MEM_LPM_TCAM_AD,
    SIM_MAX_MEM_TYPE,
};
typedef enum sim_alloc_mem_type_e sim_alloc_mem_type_t;

/* Record the relation between tableString in profile with tableId */
struct allocation_profile_prefix_s
{
    char prefix_string[128];
    sim_alloc_mem_type_t alloc_mem_type;
    uint32 start_index;
    uint32 end_index;
};
typedef struct allocation_profile_prefix_s allocation_profile_prefix_t;

static allocation_profile_prefix_t _alloc_profile_match_string[] =
{
    {"do allocation",            SIM_MEM_DYNIC_TBL, 0, 0},
    {"tcam-key initialize",      SIM_MEM_TCAM_KEY_INIT, 0, 0},
    {"tcam-key allocation",      SIM_MEM_TCAM_KEY, 9, 45},
    {"tcam-ad allocation",       SIM_MEM_TCAM_AD, 46, 84},
    {"lpm-tcam-key allocation",  SIM_MEM_LPM_TCAM_KEY, 85, 85},
    {"mem-profile init",         SIM_MEM_PROFILE_INIT, 0, 0},
    {"lpm-tcam-ad allocation",   SIM_MEM_LPM_TCAM_AD, 86, 86},
};

/* Record the relation between tableString in profile with tableId */
struct allocation_profile_database_s
{
    char table_string[128];
    tbls_id_t table_id;
};
typedef struct allocation_profile_database_s allocation_profile_database_t;

static allocation_profile_database_t _alloc_tablestring_and_id[] =
{
    /* Dynimic table */
    {"fwd",           DsFwd_t},
    {"met-entry",     DsMetEntry_t},
    {"mpls",          DsMpls_t},
    {"ds-ma",         DsMa_t},
    {"ma-name",       DsMaName_t},
    {"l2-edit",       DsL2EditEth4W_t},
    {"l3-edit",       DsL3EditMpls4W_t},
    {"oam-mep",       DsEthMep_t},
    {"next-hop",      DsNextHop4W_t},

    /* Tcam key */
    {"acl-mac-key0",  DsAclMacKey0_t},
    {"acl-mac-key1",  DsAclMacKey1_t},
    {"acl-mac-key2",  DsAclMacKey2_t},
    {"acl-mac-key3",  DsAclMacKey3_t},
    {"acl-ipv4-key0", DsAclIpv4Key0_t},
    {"acl-ipv4-key1", DsAclIpv4Key1_t},
    {"acl-ipv4-key2", DsAclIpv4Key2_t},
    {"acl-ipv4-key3", DsAclIpv4Key3_t},
    {"acl-mpls-key0",  DsAclMplsKey0_t},
    {"acl-mpls-key1", DsAclMplsKey1_t},
    {"acl-mpls-key2", DsAclMplsKey2_t},
    {"acl-mpls-key3", DsAclMplsKey3_t},
    {"acl-ipv6-key0", DsAclIpv6Key0_t},
    {"acl-ipv6-key1", DsAclIpv6Key1_t},
    {"ipv4-ucast-route-key",  DsIpv4UcastRouteKey_t},
    {"ipv4-mcast-route-key",  DsIpv4McastRouteKey_t},
    {"ipv4-nat-key",          DsIpv4NatKey_t},
    {"ipv4-pbr-key",          DsIpv4PbrKey_t},
    {"ipv6-ucast-route-key",  DsIpv6UcastRouteKey_t},
    {"ipv6-mcast-route-key",  DsIpv6McastRouteKey_t},
    {"ipv6-nat-key",          DsIpv6NatKey_t},
    {"ipv6-pbr-key",          DsIpv6PbrKey_t},
    {"mac-bridge-key",        DsMacBridgeKey_t},
    {"fcoe-route-key",        DsFcoeRouteKey_t},
    {"trill-ucast-key",       DsTrillUcastRouteKey_t},
    {"trill-mcast-key",       DsTrillMcastRouteKey_t},
    {"user-id-mac-key",       DsUserIdMacKey_t},
    {"user-id-vlan-key",      DsUserIdVlanKey_t},
    {"user-id-ipv4-key",      DsUserIdIpv4Key_t},
    {"user-id-ipv6-key",      DsUserIdIpv6Key_t},
    {"tunnel-id-ipv4-key",    DsTunnelIdIpv4Key_t},
    {"tunnel-id-ipv6-key",    DsTunnelIdIpv6Key_t},
    {"tunnel-id-capwap-key",  DsTunnelIdCapwapKey_t},
    {"tunnel-id-pbb-key",     DsTunnelIdPbbKey_t},
    {"tunnel-id-trill-key",   DsTunnelIdTrillKey_t},
    {"mac-ipv4-key",          DsMacIpv4Key_t},
    {"mac-ipv6-key",          DsMacIpv6Key_t},

    /* Tcam AD */
    {"mac-acl0", DsMacAcl0Tcam_t},
    {"mac-acl1", DsMacAcl1Tcam_t},
    {"mac-acl2", DsMacAcl2Tcam_t},
    {"mac-acl3", DsMacAcl3Tcam_t},
    {"ipv4-acl0", DsIpv4Acl0Tcam_t},
    {"ipv4-acl1", DsIpv4Acl1Tcam_t},
    {"ipv4-acl2", DsIpv4Acl2Tcam_t},
    {"ipv4-acl3", DsIpv4Acl3Tcam_t},
    {"ipv6-acl0", DsIpv6Acl0Tcam_t},
    {"ipv6-acl1", DsIpv6Acl1Tcam_t},
    {"ipv4-ucast-da", DsIpv4UcastDaTcam_t},
    {"ipv4-mcast-da", DsIpv4McastDaTcam_t},
    {"ipv6-ucast-da", DsIpv6UcastDaTcam_t},
    {"ipv6-mcast-da", DsIpv6McastDaTcam_t},
    {"ipv4-sa-nat", DsIpv4SaNatTcam_t},
    {"ipv6-sa-nat", DsIpv6SaNatTcam_t},
    {"ipv4-ucast-pbr-dual-da", DsIpv4UcastPbrDualDaTcam_t},
    {"ipv6-ucast-pbr-dual-da", DsIpv6UcastPbrDualDaTcam_t},
    {"user-id-mac", DsUserIdMacTcam_t},
    {"user-id-ipv4", DsUserIdIpv4Tcam_t},
    {"user-id-ipv6", DsUserIdIpv6Tcam_t},
    {"user-id-vlan", DsUserIdVlanTcam_t},
    {"mac-tcam", DsMacTcam_t},
    {"fcoe-da", DsFcoeDaTcam_t},
    {"fcoe-sa", DsFcoeSaTcam_t},
    {"trill-ucast-da", DsTrillDaUcastTcam_t},
    {"trill-mcast-da", DsTrillDaMcastTcam_t},
    {"tunnel-id-ipv6", DsTunnelIdIpv6Tcam_t},
    {"tunnel-id-ipv4", DsTunnelIdIpv4Tcam_t},
    {"tunnel-id-pbb", DsTunnelIdPbbTcam_t},
    {"tunnel-id-capwap", DsTunnelIdCapwapTcam_t},
    {"tunnel-id-trill", DsTunnelIdTrillTcam_t},
    {"eth-oam-chan", DsEthOamTcamChan_t},
    {"bfd-oam-chan", DsBfdOamChanTcam_t},
    {"mpls-oam-chan", DsMplsOamChanTcam_t},
    {"pbt-oam-chan", DsPbtOamChanTcam_t},
    {"eth-rmep-chan", DsEthRmepChan_t},
    {"mac-ipv4-ad", DsMacIpv4Tcam_t},
    {"mac-ipv6-ad", DsMacIpv6Tcam_t},

    /* lpm */
    {"lpm-tcam-key", DsLpmTcam80Key_t},
    /* lpm tcam ad*/
    {"lpm-tcam-ad", LpmTcamAdMem_t},
};
/****************************************/

/*---- Parser config using on cosim -----*/
struct sw_model_write_s
{
    uint8 chip_id;
    uintptr sw_model_address;
    uint32 value;
    bool is_tcam;
    uint32 hw_addr;
};
typedef struct sw_model_write_s sw_model_write_t;
/****************************************/

static int32
_sim_interface_check_sim_bus(sim_module_t sim_module, uint32 sim_bus)
{
    if (sim_module >= SIM_MODULE_NUM)
    {
        return DRV_E_INVALID_SIM_MODULE;
    }

    if ((SIM_MODULE_IPE == sim_module) && (sim_bus >= SIM_IPE_NUM))
    {
        return DRV_E_INVALID_SIM_BUS;
    }
    else if ((SIM_MODULE_FWD == sim_module) && (sim_bus >= SIM_BSR_NUM))
    {
        return DRV_E_INVALID_SIM_BUS;
    }
    else if ((SIM_MODULE_EPE == sim_module) && (sim_bus >= SIM_EPE_NUM))
    {
        return DRV_E_INVALID_SIM_BUS;
    }

    return DRV_E_NONE;
}

static int32
_sim_interface_set_debug_flag(sim_module_t sim_module, uint8 bus_index, uint8 is_set)
{
    DRV_IF_ERROR_RETURN(_sim_interface_check_sim_bus(sim_module, bus_index));

    if (is_set)
    {
        SET_BIT(cosim_db.sim_cosim_bus_flag[sim_module], bus_index);
    }
    else
    {
        CLEAR_BIT(cosim_db.sim_cosim_bus_flag[sim_module], bus_index);
    }

    return DRV_E_NONE;
}

int32 sim_interface_load_debug_bus_cfg(char* p_file_name)
{
    FILE*  fp = NULL;
    char   string[LINE_LEN_MAX];
    char   line[LINE_LEN_MAX];
    int32  ret = 0;
    uint8  module_index = 0;
    uint8  bus_index = 0;
    uint8  is_set = FALSE;
    uint8  module_debug_flag[SIM_MODULE_NUM] = {FALSE};

    fp = fopen(p_file_name, "r");

    DRV_PTR_VALID_CHECK(fp);

    while (!feof(fp))
    {
        sal_memset(string, 0, sizeof(string));
        fgets(string, LINE_LEN_MAX, fp);

        if ('#' == string[0])
        {
            continue;
        }
        /* trim left and right space */
        sal_memset(line, 0, sizeof(line));
        ret = swemu_read_profile_string_atrim(line, string);
        if (ret < DRV_E_NONE)
        {
            CMODEL_DEBUG_OUT_INFO("%s %d: ERROR read profile!\n", __FUNCTION__, __LINE__);
            return ret;
        }
        /* check NULL line */
        if (EMPTY_LINE(line[0]))
        {
            continue;
        }

        for (module_index = SIM_MODULE_IPE; NULL != sim_module_name[module_index]; module_index++)
        {
            if (0 == sal_strncmp(line, sim_module_name[module_index], sal_strlen(sim_module_name[module_index])))
            {
                break;
            }
        }

        if ((SIM_MODULE_NUM == module_index) || module_debug_flag[module_index])
        {
            continue;
        }

        for (bus_index = 0; NULL != sim_x_bus[module_index][bus_index]; bus_index++)
        {
            if (sal_strstr(line, sim_x_bus[module_index][bus_index]))
            {
                if (sal_strstr(line, "TRUE"))
                {
                    is_set = TRUE;
                }
                else
                {
                    is_set = FALSE;;
                }
                DRV_IF_ERROR_RETURN(_sim_interface_set_debug_flag(module_index, bus_index, is_set));
                break;
            }
        }

        if ((NULL == sim_x_bus[module_index][bus_index]) && sal_strstr(line, sim_module_name[module_index]))
        {
            module_debug_flag[module_index] = TRUE;
            if (sal_strstr(line, "TRUE"))
            {
                is_set = TRUE;
            }
            else
            {
                is_set = FALSE;;
            }

            for (bus_index = 0; NULL != sim_x_bus[module_index][bus_index]; bus_index++)
            {
                DRV_IF_ERROR_RETURN(_sim_interface_set_debug_flag(module_index, bus_index, is_set));
            }
        }
        else
        {
            sal_printf("Read config file error %s.\n", line);
            continue;
        }
    }

    sal_printf("%s %d IPE = 0x%X, EPE = 0x%X, OAM = 0x%X, BSR = 0x%X\n",
               __FUNCTION__, __LINE__,
               cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE],
               cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE],
               cosim_db.sim_cosim_bus_flag[SIM_MODULE_OAM],
               cosim_db.sim_cosim_bus_flag[SIM_MODULE_FWD]);

    return DRV_E_NONE;
}

#if COSIM_DBG_FLAG
static int32 _sim_interface_parser_cfg_write_wbit_for_dump(char *line)
{

    char buf[128] = {0}, table_name[128] = {0};
    uint8 chip_id_base = 0, chip_id_offset = 0;
    tbls_id_t table_id = MaxTblId_t;
    uint32 hw_addr = 0, value = 0, chipid = 0;
//    uint32 entry_index = 0;
    uint32 index = 0;
    uint32 rubbish_num = 0;
    char rubbish_name[128] = {0};
    uint32 *model_wbit_base = NULL;

    sal_sscanf(line, "%d %x %x #%s [%d/ ", &chipid, &hw_addr, &value, table_name, &index);
    if ((sal_strcmp(table_name, "TcamAdMem") == 0))
    {
        sal_sscanf(line, "%d %x %x #%s [%d/0x%x] %s [%d", &chipid, &hw_addr, &value, rubbish_name,&rubbish_num, &rubbish_num, table_name, &index);
    }

    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chip_id_base));
    chip_id_offset = chipid - chip_id_base;

    if (DRV_ADDR_IN_DYNAMIC_SRAM_4W_RANGE(hw_addr))
    {
        *(sram_info[chip_id_offset].dynamic_mem_wbit + index) = TRUE;
    }
    else if (DRV_ADDR_IN_TCAMAD_SRAM_4W_RANGE(hw_addr))
    {
         drv_get_tbl_id_by_string(&table_id, table_name);
         *(sram_info[chip_id_offset].sram_model_wbit[table_id] + index) = TRUE;
    }
    else if (DRV_ADDR_IN_LPM_TCAM_AD_RANGE(hw_addr))
    {
         drv_get_tbl_id_by_string(&table_id, table_name);
         *(sram_info[chip_id_offset].sram_model_wbit[table_id] + index) = TRUE;
    }
    else if (DRV_ADDR_IN_TCAM_DATA_RANGE(hw_addr))
    {
        model_wbit_base = tcam_info.int_tcam_wbit[chip_id_offset];

        SET_BIT(model_wbit_base[index/DRV_BITS_PER_WORD], index%DRV_BITS_PER_WORD);

    }
    else if (DRV_ADDR_IN_TCAM_MASK_RANGE(hw_addr))
    {
        model_wbit_base = tcam_info.int_tcam_wbit[chip_id_offset];

        SET_BIT(model_wbit_base[index/DRV_BITS_PER_WORD], index%DRV_BITS_PER_WORD);

    }
    else if (DRV_ADDR_IN_LPM_TCAM_DATA_RANGE(hw_addr))
    {
        model_wbit_base = tcam_info.int_lpm_tcam_wbit[chip_id_offset];

        SET_BIT(model_wbit_base[index/DRV_BITS_PER_WORD], index%DRV_BITS_PER_WORD);
    }
    else if (DRV_ADDR_IN_LPM_TCAM_MASK_RANGE(hw_addr))
    {
        model_wbit_base = tcam_info.int_lpm_tcam_wbit[chip_id_offset];

        SET_BIT(model_wbit_base[index/DRV_BITS_PER_WORD], index%DRV_BITS_PER_WORD);
    }
    else if ((DRV_ADDR_IN_DYNAMIC_SRAM_8W_RANGE(hw_addr))
        || (DRV_ADDR_IN_TCAMAD_SRAM_8W_RANGE(hw_addr)))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ERROR! Fail to conver the 8Word dynamic/TcamAD address 0x%8x!\n", hw_addr);
        ASIC_DEBUG_BUS_CMP(buf, "Config.txt can not exist the type address because of per-4word dumping!\n");
        return DRV_E_INVALID_PARAMETER;
    }
    else
    {
        drv_get_tbl_id_by_string(&table_id, table_name);
        if (CHK_IS_REGISTER(table_id))
        {
            *(sram_info[chip_id_offset].sram_model_wbit[table_id] + index) = TRUE;
        }
        else
        {
            *(sram_info[chip_id_offset].sram_model_wbit[table_id] + index) = TRUE;
        }
    }

    return DRV_E_NONE;
}

#endif
static bool
_sim_bus_field_compare(uint32 c_field, uint32 v_field, char *name)
{
   char buf[COSIM_PRINT_BUF_MAX_SIZE] = {};
   if (c_field != v_field)
   {
      ASIC_DEBUG_BUS_CMP(buf,"%s mismatch <Cmodel = 0x%x, ASIC = 0x%x>\n", name, c_field, v_field);
      return FALSE;
   }

   return TRUE;
}

static int32
_sim_interface_parser_cfg_file(char *line, sw_model_write_t *write_info)
{
    char buf[128] = {0}, table_name[128] = {0};
    uint8 chip_id_base = 0, chip_id_offset = 0;
    tbls_id_t table_id = MaxTblId_t;
    uint32 index0_hw_addr = 0, index1_hw_addr= 0, hw_addr = 0, value = 0, chipid = 0;
    uint32 entry_index = 0;
    uint32 index = 0;

    sal_sscanf(line, "%d %x %x #%s [%d/ ", &chipid, &hw_addr, &value, table_name, &index);

    write_info->chip_id = chipid;
    write_info->value = value;
    write_info->is_tcam = FALSE;
    write_info->hw_addr = hw_addr;

    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chip_id_base));
    chip_id_offset = chipid - chip_id_base;

    if (DRV_ADDR_IN_DYNAMIC_SRAM_4W_RANGE(hw_addr))
    {
        write_info->sw_model_address = sram_info[chip_id_offset].dynamic_mem_base
            + ((hw_addr - DRV_MEMORY0_BASE_4W)/DRV_ADDR_BYTES_PER_ENTRY*DRV_BYTES_PER_ENTRY)
            + (hw_addr - DRV_MEMORY0_BASE_4W)%DRV_ADDR_BYTES_PER_ENTRY;
    }
    else if (DRV_ADDR_IN_TCAMAD_SRAM_4W_RANGE(hw_addr))
    {
        write_info->sw_model_address = sram_info[chip_id_offset].tcam_ad_mem_base
            + ((hw_addr - DRV_INT_TCAM_AD_MEM_4W_BASE)/DRV_ADDR_BYTES_PER_ENTRY*DRV_BYTES_PER_ENTRY)
            + (hw_addr - DRV_INT_TCAM_AD_MEM_4W_BASE)%DRV_ADDR_BYTES_PER_ENTRY;
    }
    else if (DRV_ADDR_IN_LPM_TCAM_AD_RANGE(hw_addr))
    {
        /* per 160bit, so the granularity */
         write_info->sw_model_address = sram_info[chip_id_offset].lpm_tcam_ad_mem_base
            + ((hw_addr - DRV_INT_LPM_TCAM_AD_ASIC_BASE)/(2*DRV_ADDR_BYTES_PER_ENTRY)*2*DRV_BYTES_PER_ENTRY)
            + (hw_addr - DRV_INT_LPM_TCAM_AD_ASIC_BASE)%(2*DRV_ADDR_BYTES_PER_ENTRY);
    }
    else if (DRV_ADDR_IN_TCAM_DATA_RANGE(hw_addr))
    {
        write_info->is_tcam = TRUE;
        entry_index = (hw_addr - DRV_INT_TCAM_KEY_DATA_ASIC_BASE) / DRV_ADDR_BYTES_PER_ENTRY;
        write_info->sw_model_address = (uintptr)tcam_info.int_tcam_data_base[chip_id_offset]
                                       + (entry_index * DRV_BYTES_PER_ENTRY)
                                       + ((hw_addr - DRV_INT_TCAM_KEY_DATA_ASIC_BASE)%DRV_ADDR_BYTES_PER_ENTRY);
    }
    else if (DRV_ADDR_IN_TCAM_MASK_RANGE(hw_addr))
    {
        write_info->is_tcam = TRUE;
        entry_index = (hw_addr - DRV_INT_TCAM_KEY_MASK_ASIC_BASE) / DRV_ADDR_BYTES_PER_ENTRY;
        write_info->sw_model_address = (uintptr)tcam_info.int_tcam_mask_base[chip_id_offset]
                                       + (entry_index * DRV_BYTES_PER_ENTRY)
                                       + ((hw_addr - DRV_INT_TCAM_KEY_MASK_ASIC_BASE)%DRV_ADDR_BYTES_PER_ENTRY);
    }
    else if (DRV_ADDR_IN_LPM_TCAM_DATA_RANGE(hw_addr))
    {
        write_info->is_tcam = TRUE;
        entry_index = (hw_addr - DRV_INT_LPM_TCAM_DATA_ASIC_BASE) / DRV_ADDR_BYTES_PER_ENTRY;
        write_info->sw_model_address = (uintptr)tcam_info.int_lpm_tcam_data_base[chip_id_offset]
                                       + (entry_index * DRV_BYTES_PER_ENTRY)
                                       + ((hw_addr - DRV_INT_LPM_TCAM_DATA_ASIC_BASE)%DRV_ADDR_BYTES_PER_ENTRY);
    }
    else if (DRV_ADDR_IN_LPM_TCAM_MASK_RANGE(hw_addr))
    {
        write_info->is_tcam = TRUE;
        entry_index = (hw_addr - DRV_INT_LPM_TCAM_MASK_ASIC_BASE) / DRV_ADDR_BYTES_PER_ENTRY;
        write_info->sw_model_address = (uintptr)tcam_info.int_lpm_tcam_mask_base[chip_id_offset]
                                       + (entry_index * DRV_BYTES_PER_ENTRY)
                                       + ((hw_addr - DRV_INT_LPM_TCAM_MASK_ASIC_BASE)%DRV_ADDR_BYTES_PER_ENTRY);
    }
    else if ((DRV_ADDR_IN_DYNAMIC_SRAM_8W_RANGE(hw_addr))
        || (DRV_ADDR_IN_TCAMAD_SRAM_8W_RANGE(hw_addr)))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ERROR! Fail to conver the 8Word dynamic/TcamAD address 0x%8x!\n", hw_addr);
        ASIC_DEBUG_BUS_CMP(buf, "Config.txt can not exist the type address because of per-4word dumping!\n");
        return DRV_E_INVALID_PARAMETER;
    }
    else
    {
        if (DRV_E_NONE != drv_get_tbl_id_by_string(&table_id, table_name))
        {
            ASIC_DEBUG_BUS_CMP(buf,"ERROR! Fail to conver the tableName and the tbl_id!\n");
            ASIC_DEBUG_BUS_CMP(buf,"The tblId %d, name %s !\n", table_id, table_name);
            return DRV_E_INVALID_TBL;
        }

        if (CHK_IS_REGISTER(table_id))
        {
            write_info->sw_model_address
                = (cmodel_tbls_info[chip_id_offset][table_id].sw_data_base) + (hw_addr-TABLE_DATA_BASE(table_id));
        }
        else
        {
            DRV_IF_ERROR_RETURN(drv_table_get_hw_addr(table_id, 0, &index0_hw_addr));
            DRV_IF_ERROR_RETURN(drv_table_get_hw_addr(table_id, 1, &index1_hw_addr));

            write_info->sw_model_address
                = (cmodel_tbls_info[chip_id_offset][table_id].sw_data_base)
                  +(hw_addr-TABLE_DATA_BASE(table_id))/(index1_hw_addr-index0_hw_addr)*TABLE_ENTRY_SIZE(table_id)
                  +(hw_addr-TABLE_DATA_BASE(table_id))%(index1_hw_addr-index0_hw_addr);
        }
    }

    return DRV_E_NONE;
}

static int32
_sim_interface_parser_alloc_file(char *line, cm_table_allocation_info_t *alloc_info,
                                            sim_alloc_mem_type_t *alloc_type, cm_mem_profile_t *profile_index)
{
    char tbl_name[128] = {0};
    char buf[128] = {0};
    int32 ret;
    uint32 i = 0, match_max_num = 0, tbl_index = 0, start_index = 0, end_index = 0;
    allocation_profile_database_t id_and_name_profile;

    sal_memset(tbl_name, 0, sizeof(tbl_name));
    sal_memset(alloc_info, 0, sizeof(cm_table_allocation_info_t));
    sal_memset(&id_and_name_profile, 0, sizeof(id_and_name_profile));

    match_max_num = sizeof(_alloc_profile_match_string)/sizeof(allocation_profile_prefix_t);
    for (i = 0; i < match_max_num; i++)
    {
        if (0 == sal_strncmp(line, _alloc_profile_match_string[i].prefix_string,
                              sal_strlen(_alloc_profile_match_string[i].prefix_string)))
        {
            *alloc_type = _alloc_profile_match_string[i].alloc_mem_type;

            if (*alloc_type != SIM_MAX_MEM_TYPE)
            {
                switch (*alloc_type)
                {
                    case SIM_MEM_TCAM_AD:
                        ret = sal_sscanf(line+sal_strlen(_alloc_profile_match_string[i].prefix_string),
                                        " %s %d", tbl_name,
                                        &(alloc_info->index_num));
                        if (2 != ret)
                        {
                            ASIC_DEBUG_BUS_CMP(buf, "%% Error! Fail to Parser allocation file, %s!\n",
                                               _alloc_profile_match_string[i].prefix_string);

                            ASIC_DEBUG_BUS_CMP(buf, "%% The line is %s, paser out PARA_number %d value! expect 2!\n",
                                               line, ret);
                            return DRV_E_INVALID_PARAMETER;
                        }
                        break;
                    case SIM_MEM_TCAM_KEY:
                        ret  = sal_sscanf(line+sal_strlen(_alloc_profile_match_string[i].prefix_string),
                                          " %s %d %d", tbl_name,
                                          &(alloc_info->index_num), &(alloc_info->key_size));
                        if (3 != ret)
                        {
                            ASIC_DEBUG_BUS_CMP(buf, "%% Error! Parser allocation file %s!\n",
                                               _alloc_profile_match_string[i].prefix_string);

                            ASIC_DEBUG_BUS_CMP(buf, "%% The line is %s, paser out PARA_number %d value! expect 3!\n",
                                               line, ret);
                            return DRV_E_INVALID_PARAMETER;
                        }
                        break;
                    case SIM_MEM_LPM_TCAM_KEY:
                        ret = sal_sscanf(line, "%s allocation %d", tbl_name, &(alloc_info->index_num));
                        if (2 != ret)
                        {
                            ASIC_DEBUG_BUS_CMP(buf, "ERROR! Parser allocation file %s!\n",
                                               _alloc_profile_match_string[i].prefix_string);

                            ASIC_DEBUG_BUS_CMP(buf, "The line is %s, paser out PARA_number %d value! expect 2!\n",
                                               line, ret);
                            return DRV_E_INVALID_PARAMETER;
                        }
                        break;
                    case SIM_MEM_LPM_TCAM_AD:
                        ret = sal_sscanf(line, "%s allocation %d", tbl_name, &(alloc_info->index_num));
                        if (2 != ret)
                        {
                            ASIC_DEBUG_BUS_CMP(buf, "ERROR! Parser allocation file %s!\n",
                                               _alloc_profile_match_string[i].prefix_string);

                            ASIC_DEBUG_BUS_CMP(buf, "The line is %s, paser out PARA_number %d value! expect 2!\n",
                                               line, ret);
                            return DRV_E_INVALID_PARAMETER;
                        }
                        break;
                    case SIM_MEM_PROFILE_INIT:
                        ret = sal_sscanf(line+sal_strlen(_alloc_profile_match_string[i].prefix_string),
                                        " %d", (uint32 *)profile_index);
                        if (1 != ret)
                        {
                            ASIC_DEBUG_BUS_CMP(buf, "%% Error! Fail to Parser allocation file, %s!\n",
                                               _alloc_profile_match_string[i].prefix_string);

                            ASIC_DEBUG_BUS_CMP(buf, "%% The line is %s, paser out PARA_number %d value! expect 1!\n",
                                               line, ret);
                            return DRV_E_INVALID_PARAMETER;
                        }
                        else
                        {
                            return DRV_E_NONE;
                        }
                        break;


                    default:
                        return DRV_E_NONE;
                }

                start_index = _alloc_profile_match_string[i].start_index;
                end_index = _alloc_profile_match_string[i].end_index;
                for (tbl_index = start_index; tbl_index <= end_index; tbl_index++)
                {
                    id_and_name_profile = _alloc_tablestring_and_id[tbl_index];
                    if (0 == sal_strncmp(tbl_name, id_and_name_profile.table_string,
                                         sal_strlen(id_and_name_profile.table_string)))
                    {
                        alloc_info->table_id = id_and_name_profile.table_id;
                        return DRV_E_NONE;
                    }
                    else
                    {
                        continue;
                    }
                }
                ASIC_DEBUG_BUS_CMP(buf, "ERROR! Can not find the table %s!!\n", tbl_name);
                return DRV_E_INVALID_PARAMETER;
            }
            else
            {
                ASIC_DEBUG_BUS_CMP(buf, "ERROR! Invalid allocation dataBase! %s!!\n", line);
                return DRV_E_INVALID_PARAMETER;
            }
        }
    }

    return DRV_E_NONE;
}

static void
_sim_interface_all_linklist_operation(sim_all_linklist_opcode_t opcode)
{
#define LIST_HEAD_OP(ptr, opcode) \
    if ((opcode) == SIM_LINKLIST_OP_CREAT) \
        INIT_LIST_HEAD((ptr));\
    else \
        list_del_all_and_free((ptr));\

    uint32 i = 0;
    uint32 module_index = 0;
    uint32 bus_index = 0;

    for (module_index = 0; module_index < SIM_MODULE_NUM; module_index++)
    {
        for (bus_index = 0; NULL != sim_x_bus[module_index][bus_index]; bus_index++)
        {
            if (IS_BIT_SET(cosim_db.sim_cosim_bus_flag[module_index], bus_index))
            {
                LIST_HEAD_OP(&sim_x_moduel_list[module_index][bus_index], opcode)

                if (SIM_MODULE_FWD == module_index)
                {
                    if (SIM_FWD_MS_ENQUEUE == bus_index)
                    {
                        LIST_HEAD_OP(&cosim_db.enq_simular_list, opcode)
                    }
                    else if (SIM_FWD_MS_DEQUEUE == bus_index)
                    {
                        LIST_HEAD_OP(&cosim_db.deq_simular_list, opcode)
                    }
                    LIST_HEAD_OP(&cosim_db.hdr_simular_list, opcode)
                }
            }
        }
        /* init each module channel outpkt linklist */
        for (i = 0; i < SIM_MAX_CHANN_NUM; i++)
        {
            LIST_HEAD_OP(&cosim_db.sim_outpkt_list[module_index][i], opcode)
        }
        LIST_HEAD_OP(&cosim_db.pkt_simular_list[module_index], opcode)
        LIST_HEAD_OP(&cosim_db.sim_bheader_list[module_index], opcode)

    }

    if (cosim_db.sim_read_tbl_cosim_flag)
    {
        /* init each table's linklist */
        for (i = 0; i < MaxTblId_t; i++)
        {
            if (!CHK_IS_REGISTER(i)) /* do not include register(reg do not compare) */
            {
                LIST_HEAD_OP(&cosim_db.sim_table_info_list[i], opcode)
            }
        }
    }

    for (i = 0; i < SIM_KEY_TYPE_NUM; i++)
    {
        if (cosim_db.sim_key_cosim_flag[i])
        {
            LIST_HEAD_OP(&cosim_db.sim_key_list[i], opcode)
        }
    }

    if (cosim_db.sim_write_tbl_cosim_flag)
    {
        for (i = 0; i < SIM_DSOAM_MAX; i++)
        {
            LIST_HEAD_OP(&cosim_db.sim_oam_wt_table_info_list[i], opcode)
        }
    }
}

static int32
_sim_interface_compare_pkt_content(uint8 *rtl_pkt, sim_pkt_cmp_t *sim_pkt, uint32 pkt_len, uint32 chipid, uint32 chanid)
{
    int32 not_equal = 0;
    uint32 i,j,n,len;
    uint8 *cmodel_pkt = NULL;
    char buf[128] = {0};
    char line[] = "----------------------------------------------";

    if (NULL == rtl_pkt)
    {
        ASIC_DEBUG_BUS_CMP(buf, "ASIC packet is empty:!\n");
    }

    if (NULL == sim_pkt)
    {
        ASIC_DEBUG_BUS_CMP(buf, "CMODEL packet is empty:!\n");
    }

    cmodel_pkt = sim_pkt->pkt;

    len = pkt_len -CRC_LEN;
    for (i=0;i<len;i+=32)
    {
        if (len-i>32)
        {
            j=32;
            not_equal = sal_memcmp(&rtl_pkt[i],&cmodel_pkt[i],j);
        }
        else
        {
            j=len%32;
            not_equal = sal_memcmp(&rtl_pkt[i],&cmodel_pkt[i],j);
        }
        if (not_equal != 0)
        {
            ASIC_DEBUG_BUS_CMP(buf, "ERROR! OutPkt Mismatch, The %d of 32 Byte Mismatch\n", i);
            ASIC_DEBUG_BUS_CMP(buf, "RTL OutPkt ChipId: %d \n", chipid);
            ASIC_DEBUG_BUS_CMP(buf, "RTL OutPkt ChannelId: %d \n", chanid);
            ASIC_DEBUG_BUS_CMP(buf, "RTL OutPkt Length: %d \n", pkt_len);
            ASIC_DEBUG_BUS_CMP(buf, "ASIC packet is :\n");
            ASIC_DEBUG_BUS_CMP(buf, "%s\n", line);
            for (n=0;n<j;n++)
            {
                ASIC_DEBUG_BUS_CMP(buf, "%02x",rtl_pkt[i+n]);
            }
            ASIC_DEBUG_BUS_CMP(buf, "\n");
            ASIC_DEBUG_BUS_CMP(buf, "CModel OutPkt ChipId: %d \n", sim_pkt->chip_id);
            ASIC_DEBUG_BUS_CMP(buf, "CModel OutPkt ChannelId: %d \n", sim_pkt->chan_id);
            ASIC_DEBUG_BUS_CMP(buf, "CModel OutPkt Length: %d \n", sim_pkt->packet_length);
            ASIC_DEBUG_BUS_CMP(buf, "CMODEL packet is :\n");
            ASIC_DEBUG_BUS_CMP(buf, "%s\n", line);
            for (n=0;n<j;n++)
            {
                ASIC_DEBUG_BUS_CMP(buf, "%02x",cmodel_pkt[i+n]);
            }
            ASIC_DEBUG_BUS_CMP(buf, "\n");

            return DRV_E_PKT_MISMATCH;
        }
        else
        {
            continue;
        }
    }

    return DRV_E_NONE;
}

/* packet info compare fail, dump the debug information */
static int32
_sim_interface_dump_pkt_content(uint8 *pkt, uint32 pkt_len)
{
    uint32 j;
    char buf[128] = {0};

    if(NULL == pkt)
    {
        return DRV_E_INVALID_PTR;
    }

    for(j = 0; j < pkt_len; j++)
    {
        ASIC_DEBUG_BUS_CMP(buf, "%02x", pkt[j]);
        if((j + 1) % 32 == 0)
        {
            ASIC_DEBUG_BUS_CMP(buf, "\n");
        }
    }

    ASIC_DEBUG_BUS_CMP(buf, "\n");

    return DRV_E_NONE;
}

static void
_sim_interface_store_dsicard_info(uint8 discard, uint32 discard_type)
{
    cosim_discard_info.discard = discard;
    cosim_discard_info.discard_type = discard_type;
}

/* Each module's out packet compare interface */
static int32
_sim_interface_store_out_pkt(uint32 chipid, uint32 chanid,
                        uint32 packet_length, uint8 *pkt, uint8 mod_id,
                        uint8 discard, uint32 discard_type)
{
    sim_pkt_cmp_t *sim_pkt = NULL;

    if (FALSE == sim_interface_initialize)
    {
        return DRV_E_NONE;
    }

    sim_pkt = sal_malloc(sizeof(sim_pkt_cmp_t));
    if (NULL == sim_pkt)
    {
        return DRV_E_NO_MEMORY;
    }

    sal_memset(sim_pkt, 0, sizeof(sim_pkt_cmp_t));

    sim_pkt->chan_id = chanid;
    sim_pkt->chip_id = chipid;
    sim_pkt->packet_length = packet_length;
    sal_memcpy(sim_pkt->pkt, pkt, packet_length);

    /* Only for IPE and EPE */
    if ((mod_id == SIM_MODULE_IPE) && (mod_id == SIM_MODULE_EPE))
    {
        sim_pkt->discard = discard;
        sim_pkt->discard_type = discard_type;
    }

    list_add_tail(&sim_pkt->head, &(cosim_db.sim_outpkt_list[mod_id][chanid]));

    return DRV_E_NONE;
}
static void
_sim_interface_fwd_show_rtl_pkt_hdr_ms(ms_pkt_hdr_t *ms)
{
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};

    ASIC_DEBUG_BUS_CMP(buf,"source_port15_14:0x%x\n",ms->source_port15_14);
    ASIC_DEBUG_BUS_CMP(buf,"packet_offset:0x%x\n",ms->packet_offset);
    ASIC_DEBUG_BUS_CMP(buf,"dest_map:0x%x\n",ms->dest_map);
    ASIC_DEBUG_BUS_CMP(buf,"priority:0x%x\n",ms->priority);
    ASIC_DEBUG_BUS_CMP(buf,"packet_type:0x%x\n",ms->packet_type);
    ASIC_DEBUG_BUS_CMP(buf,"source_cos:0x%x\n",ms->source_cos);
    ASIC_DEBUG_BUS_CMP(buf,"src_queue_select:0x%x\n",ms->src_queue_select);
    ASIC_DEBUG_BUS_CMP(buf,"header_hash2_0:0x%x\n",ms->header_hash2_0);
    ASIC_DEBUG_BUS_CMP(buf,"logic_port_type:0x%x\n",ms->logic_port_type);
    ASIC_DEBUG_BUS_CMP(buf,"src_ctag_offset_type:0x%x\n",ms->src_ctag_offset_type);
    ASIC_DEBUG_BUS_CMP(buf,"source_port:0x%x\n",ms->source_port);
    ASIC_DEBUG_BUS_CMP(buf,"src_vlan_id:0x%x\n",ms->src_vlan_id);
    ASIC_DEBUG_BUS_CMP(buf,"color:0x%x\n",ms->color);
    ASIC_DEBUG_BUS_CMP(buf,"bridge_operation:0x%x\n",ms->bridge_operation);
    ASIC_DEBUG_BUS_CMP(buf,"next_hop_ptr:0x%x\n",ms->next_hop_ptr);
    ASIC_DEBUG_BUS_CMP(buf,"length_adjust_type:0x%x\n",ms->length_adjust_type);
    ASIC_DEBUG_BUS_CMP(buf,"critical_packet:0x%x\n",ms->critical_packet);
    ASIC_DEBUG_BUS_CMP(buf,"rxtx_fcl22_17:0x%x\n",ms->rxtx_fcl22_17);
    ASIC_DEBUG_BUS_CMP(buf,"flow:0x%x\n",ms->flow);
    ASIC_DEBUG_BUS_CMP(buf,"ttl:0x%x\n",ms->ttl);
    ASIC_DEBUG_BUS_CMP(buf,"from_fabric:0x%x\n",ms->from_fabric);
    ASIC_DEBUG_BUS_CMP(buf,"bypass_ingress_edit:0x%x\n",ms->bypass_ingress_edit);
    ASIC_DEBUG_BUS_CMP(buf,"source_port_extender:0x%x\n",ms->source_port_extender);
    ASIC_DEBUG_BUS_CMP(buf,"loopback_discard:0x%x\n",ms->loopback_discard);
    ASIC_DEBUG_BUS_CMP(buf,"header_crc:0x%x\n",ms->header_crc);
    ASIC_DEBUG_BUS_CMP(buf,"source_port_isolate_id:0x%x\n",ms->source_port_isolate_id);
    ASIC_DEBUG_BUS_CMP(buf,"pbb_src_port_type:0x%x\n",ms->pbb_src_port_type);
    ASIC_DEBUG_BUS_CMP(buf,"svlan_tag_operation_valid:0x%x\n",ms->svlan_tag_operation_valid);
    ASIC_DEBUG_BUS_CMP(buf,"source_cfi:0x%x\n",ms->source_cfi);
    ASIC_DEBUG_BUS_CMP(buf,"next_hop_ext:0x%x\n",ms->next_hop_ext);
    ASIC_DEBUG_BUS_CMP(buf,"non_crc:0x%x\n",ms->non_crc);
    ASIC_DEBUG_BUS_CMP(buf,"from_cpu_or_oam:0x%x\n",ms->from_cpu_or_oam);
    ASIC_DEBUG_BUS_CMP(buf,"svlan_tpid_index:0x%x\n",ms->svlan_tpid_index);
    ASIC_DEBUG_BUS_CMP(buf,"stag_action:0x%x\n",ms->stag_action);
    ASIC_DEBUG_BUS_CMP(buf,"src_svlan_id_valid:0x%x\n",ms->src_svlan_id_valid);
    ASIC_DEBUG_BUS_CMP(buf,"src_cvlan_id_valid:0x%x\n",ms->src_cvlan_id_valid);
    if (ms->src_cvlan_id_valid)
    {
        ASIC_DEBUG_BUS_CMP(buf,"src_cvlan_id:0x%x\n",ms->src_cvlan_id);
    }
    ASIC_DEBUG_BUS_CMP(buf,"src_vlan_ptr:0x%x\n",ms->src_vlan_ptr);
    ASIC_DEBUG_BUS_CMP(buf,"fid:0x%x\n",ms->fid);
    ASIC_DEBUG_BUS_CMP(buf,"logic_src_port:0x%x\n",ms->logic_src_port);
    ASIC_DEBUG_BUS_CMP(buf,"rxtx_fcl3:0x%x\n",ms->rxtx_fcl3);
    ASIC_DEBUG_BUS_CMP(buf,"cut_through:0x%x\n",ms->cut_through);
    ASIC_DEBUG_BUS_CMP(buf,"rxtx_fcl2_1:0x%x\n",ms->rxtx_fcl2_1);
    ASIC_DEBUG_BUS_CMP(buf,"mux_length_type:0x%x\n",ms->mux_length_type);
    ASIC_DEBUG_BUS_CMP(buf,"oam_tunnel_en:0x%x\n",ms->oam_tunnel_en);
    ASIC_DEBUG_BUS_CMP(buf,"rxtx_fcl0:0x%x\n",ms->rxtx_fcl0);
    ASIC_DEBUG_BUS_CMP(buf,"operation_type:0x%x\n",ms->operation_type);
    ASIC_DEBUG_BUS_CMP(buf,"header_hash7_3:0x%x\n",ms->header_hash7_3);
    ASIC_DEBUG_BUS_CMP(buf,"ip_sa:0x%x\n",ms->ip_sa);
}

static void
_sim_interface_bsr_show_mismatch_pkt_hdr_ms(ms_pkt_hdr_t *c_bus, ms_pkt_hdr_t *s_bus)
{

    _sim_bus_field_compare(c_bus->source_port15_14 , s_bus->source_port15_14, "source_port15_14");
    _sim_bus_field_compare(c_bus->packet_offset , s_bus->packet_offset, "packet_offset");
    _sim_bus_field_compare(c_bus->dest_map , s_bus->dest_map, "dest_map");
    _sim_bus_field_compare(c_bus->priority , s_bus->priority, "priority");
    _sim_bus_field_compare(c_bus->packet_type , s_bus->packet_type, "packet_type");
    _sim_bus_field_compare(c_bus->source_cos , s_bus->source_cos, "source_cos");
    _sim_bus_field_compare(c_bus->src_queue_select , s_bus->src_queue_select, "src_queue_select");
    _sim_bus_field_compare(c_bus->header_hash2_0 , s_bus->header_hash2_0, "header_hash2_0");
    _sim_bus_field_compare(c_bus->logic_port_type , s_bus->logic_port_type, "logic_port_type");
    _sim_bus_field_compare(c_bus->src_ctag_offset_type , s_bus->src_ctag_offset_type, "src_ctag_offset_type");
    _sim_bus_field_compare(c_bus->source_port , s_bus->source_port, "source_port");
    _sim_bus_field_compare(c_bus->src_vlan_id , s_bus->src_vlan_id, "src_vlan_id");
    _sim_bus_field_compare(c_bus->color , s_bus->color, "color");
    _sim_bus_field_compare(c_bus->bridge_operation , s_bus->bridge_operation, "bridge_operation");
    _sim_bus_field_compare(c_bus->next_hop_ptr , s_bus->next_hop_ptr, "next_hop_ptr");
    _sim_bus_field_compare(c_bus->length_adjust_type , s_bus->length_adjust_type, "length_adjust_type");
    _sim_bus_field_compare(c_bus->critical_packet , s_bus->critical_packet, "critical_packet");
    _sim_bus_field_compare(c_bus->rxtx_fcl22_17 , s_bus->rxtx_fcl22_17, "rxtx_fcl22_17");
    _sim_bus_field_compare(c_bus->flow , s_bus->flow, "flow");
    _sim_bus_field_compare(c_bus->ttl , s_bus->ttl, "ttl");
    _sim_bus_field_compare(c_bus->from_fabric , s_bus->from_fabric, "from_fabric");
    _sim_bus_field_compare(c_bus->bypass_ingress_edit , s_bus->bypass_ingress_edit, "bypass_ingress_edit");
    _sim_bus_field_compare(c_bus->source_port_extender , s_bus->source_port_extender, "source_port_extender");
    _sim_bus_field_compare(c_bus->loopback_discard , s_bus->loopback_discard, "loopback_discard");
    _sim_bus_field_compare(c_bus->header_crc , s_bus->header_crc, "header_crc");
    _sim_bus_field_compare(c_bus->source_port_isolate_id , s_bus->source_port_isolate_id, "source_port_isolate_id");
    _sim_bus_field_compare(c_bus->pbb_src_port_type , s_bus->pbb_src_port_type, "pbb_src_port_type");
    _sim_bus_field_compare(c_bus->svlan_tag_operation_valid , s_bus->svlan_tag_operation_valid, "svlan_tag_operation_valid");
    _sim_bus_field_compare(c_bus->source_cfi , s_bus->source_cfi, "source_cfi");
    _sim_bus_field_compare(c_bus->next_hop_ext , s_bus->next_hop_ext, "next_hop_ext");
    _sim_bus_field_compare(c_bus->non_crc , s_bus->non_crc, "non_crc");
    _sim_bus_field_compare(c_bus->from_cpu_or_oam , s_bus->from_cpu_or_oam, "from_cpu_or_oam,");
    _sim_bus_field_compare(c_bus->svlan_tpid_index , s_bus->svlan_tpid_index, "svlan_tpid_index");
    _sim_bus_field_compare(c_bus->stag_action , s_bus->stag_action, "stag_action");
    _sim_bus_field_compare(c_bus->src_svlan_id_valid , s_bus->src_svlan_id_valid, "src_svlan_id_valid");
    _sim_bus_field_compare(c_bus->src_cvlan_id_valid , s_bus->src_cvlan_id_valid, "src_cvlan_id_valid");
    if (s_bus->src_cvlan_id_valid)
    {
        _sim_bus_field_compare(c_bus->src_cvlan_id, s_bus->src_cvlan_id, "src_cvlan_id");
    }

    _sim_bus_field_compare(c_bus->src_vlan_ptr , s_bus->src_vlan_ptr, "src_vlan_ptr");
    _sim_bus_field_compare(c_bus->fid , s_bus->fid, "fid");
    _sim_bus_field_compare(c_bus->logic_src_port , s_bus->logic_src_port, "logic_src_port");
    _sim_bus_field_compare(c_bus->rxtx_fcl3 , s_bus->rxtx_fcl3, "rxtx_fcl3");
    _sim_bus_field_compare(c_bus->cut_through , s_bus->cut_through, "cut_through");
    _sim_bus_field_compare(c_bus->rxtx_fcl2_1 , s_bus->rxtx_fcl2_1, "rxtx_fcl2_1");
    _sim_bus_field_compare(c_bus->mux_length_type , s_bus->mux_length_type, "mux_length_type");
    _sim_bus_field_compare(c_bus->oam_tunnel_en , s_bus->oam_tunnel_en, "oam_tunnel_en");
    _sim_bus_field_compare(c_bus->rxtx_fcl0 , s_bus->rxtx_fcl0, "rxtx_fcl0");
    _sim_bus_field_compare(c_bus->operation_type , s_bus->operation_type, "operation_type");
    _sim_bus_field_compare(c_bus->header_hash7_3 , s_bus->header_hash7_3, "header_hash7_3");
    _sim_bus_field_compare(c_bus->ip_sa , s_bus->ip_sa, "ip_sa");
}

static int32
_sim_interface_store_pkt_hdr(void *bridge_header, uint8 mod_id)
{
    cosim_brg_header_t *brg_header_node = NULL;
    ms_pkt_hdr_t *new_node = NULL;
    ms_packet_header_t *bheader = NULL;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};
    uint8 gb_header[GREAT_BELT_HEADER_LEN] = {0};

    if (!sim_interface_initialize)
    {
        return DRV_E_NONE;
    }

    if (bridge_header == NULL)
    {
        ASIC_DEBUG_BUS_CMP(buf, "ERROR! Invalid Para, NULL pointer during store modId %d bridgeHeader\n", mod_id);
        return DRV_E_INVALID_PARAMETER;
    }

    sal_memcpy(gb_header, bridge_header, sizeof(ms_packet_header_t));
    if (mod_id == SIM_MODULE_FWD)
    {
        swap32((uint32 *)gb_header, GREAT_BELT_HEADER_LEN, NETWORK_TO_HOST);
    }

    bheader = (ms_packet_header_t *)gb_header;

    brg_header_node = sal_malloc(sizeof(cosim_brg_header_t));
    if(NULL == brg_header_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(brg_header_node,0,sizeof(cosim_brg_header_t));

    new_node = sal_malloc(sizeof(ms_pkt_hdr_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ms_pkt_hdr_t));

    new_node->source_port15_14 = bheader->source_port15_14;
    new_node->packet_offset = bheader->packet_offset;
    new_node->dest_map = bheader->dest_map;
    new_node->priority = bheader->priority;
    new_node->packet_type = bheader->packet_type;
    new_node->source_cos = bheader->source_cos;
    new_node->src_queue_select = bheader->src_queue_select;
    new_node->header_hash2_0 = bheader->header_hash2_0;
    new_node->logic_port_type = bheader->logic_port_type;
    new_node->src_ctag_offset_type = bheader->src_ctag_offset_type;
    new_node->source_port = bheader->source_port;
    new_node->src_vlan_id = bheader->src_vlan_id;
    new_node->color = bheader->color;
    new_node->bridge_operation = bheader->bridge_operation;
    new_node->next_hop_ptr = bheader->next_hop_ptr;
    new_node->length_adjust_type = bheader->length_adjust_type;
    new_node->critical_packet = bheader->critical_packet;
    new_node->rxtx_fcl22_17 = bheader->rxtx_fcl22_17;
    new_node->flow = bheader->flow;
    new_node->ttl = bheader->ttl;
    new_node->from_fabric = bheader->from_fabric;
    new_node->bypass_ingress_edit = bheader->bypass_ingress_edit;
    new_node->source_port_extender = bheader->source_port_extender;
    new_node->loopback_discard = bheader->loopback_discard;
    new_node->header_crc = bheader->header_crc;
    new_node->source_port_isolate_id = bheader->source_port_isolate_id;
    new_node->pbb_src_port_type = bheader->pbb_src_port_type;
    new_node->svlan_tag_operation_valid = bheader->svlan_tag_operation_valid;
    new_node->source_cfi = bheader->source_cfi;
    new_node->next_hop_ext = bheader->next_hop_ext;
    new_node->non_crc = bheader->non_crc;
    new_node->from_cpu_or_oam = bheader->from_cpu_or_oam;
    new_node->svlan_tpid_index = bheader->svlan_tpid_index;
    new_node->stag_action = bheader->stag_action;
    new_node->src_svlan_id_valid = bheader->src_svlan_id_valid;
    new_node->src_cvlan_id_valid = bheader->src_cvlan_id_valid;
    new_node->src_cvlan_id = bheader->src_cvlan_id;
    new_node->src_vlan_ptr = bheader->src_vlan_ptr;
    new_node->fid = bheader->fid;
    new_node->logic_src_port = bheader->logic_src_port;
    new_node->rxtx_fcl3 = bheader->rxtx_fcl3;
    new_node->cut_through = bheader->cut_through;
    new_node->rxtx_fcl2_1 = bheader->rxtx_fcl2_1;
    new_node->mux_length_type = bheader->mux_length_type;
    new_node->oam_tunnel_en = bheader->oam_tunnel_en;
    new_node->rxtx_fcl0 = bheader->rxtx_fcl0;
    new_node->operation_type = bheader->operation_type;
    new_node->header_hash7_3 = bheader->header_hash7_3;
    new_node->ip_sa = bheader->ip_sa;


    brg_header_node->pkt_header = new_node;
    brg_header_node->discard = cosim_discard_info.discard;
    brg_header_node->discard_type = cosim_discard_info.discard_type;

    list_add_tail(&(brg_header_node->head), &(cosim_db.sim_bheader_list[mod_id]));

    return DRV_E_NONE;
}

static int32
_cosim_pkt_hdr_verify(void *bus, uint8 mod_id, bool *succ, bool *is_discard)
{
    list_head_t *pos = NULL;
    cosim_brg_header_t *brg_header_node = NULL;
    ms_pkt_hdr_t *s_ms_pkt_hdr = NULL,*c_ms_pkt_hdr = NULL,v_ms_pkt_hdr;
    bool match=FALSE, simular=FALSE;
    uint32 cnt = 0;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (!sim_interface_initialize)
    {
        return DRV_E_NONE;
    }

    DRV_PTR_VALID_CHECK(bus);
    DRV_PTR_VALID_CHECK(succ);

    *is_discard = FALSE;
    if ((mod_id==SIM_MODULE_FWD) ||(mod_id==SIM_MODULE_EPE))
    {
        sal_memset(&v_ms_pkt_hdr, 0, sizeof(v_ms_pkt_hdr));
        if (list_empty(&(cosim_db.sim_bheader_list[mod_id])))
        {
            ASIC_DEBUG_BUS_CMP(buf, "%% ERROR!  BridgeHeader verify error! <CModel BridgeHeader List is empty, but RTL is not>\n");
            *succ = FALSE;
            return DRV_E_NONE;
        }

        ret = ms_pkt_hdr_bus_decode(bus, &v_ms_pkt_hdr);
        if (ret)
        {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf, "%% ERROR!  BridgeHeader bus decode error!\n");
            return ret;
        }

        *succ = FALSE;

        list_for_each(pos, &(cosim_db.sim_bheader_list[mod_id]))
        {
            brg_header_node = list_entry(pos, cosim_brg_header_t, head);
            c_ms_pkt_hdr = brg_header_node->pkt_header;
            match = ms_fwd_pkt_hdr_bus_compare(c_ms_pkt_hdr, &v_ms_pkt_hdr, &simular);

            if (match)
            {
                *succ = TRUE;
                list_del_all_and_free(&(cosim_db.hdr_simular_list));
                return DRV_E_NONE;
            }

            if (!match && simular)
            {
                /* if simular, add the simular entry into simular list */
                s_ms_pkt_hdr = sal_malloc(sizeof(ms_pkt_hdr_t));
                if (NULL == s_ms_pkt_hdr)
                {
                    return DRV_E_NO_MEMORY;
                }

                sal_memcpy(s_ms_pkt_hdr, c_ms_pkt_hdr, sizeof(ms_pkt_hdr_t));
                list_add_tail(&s_ms_pkt_hdr->head, &(cosim_db.hdr_simular_list));
            }
        }

        if(!(*succ))
        {
            ASIC_DEBUG_BUS_CMP(buf, "=====================BridgeHeader Msg Mismatch=====================\n");
            ASIC_DEBUG_BUS_CMP(buf, "ASIC BridgeHeader Msg:\n");
            _sim_interface_fwd_show_rtl_pkt_hdr_ms(&v_ms_pkt_hdr);
            ASIC_DEBUG_BUS_CMP(buf, "\n");

            list_for_each(pos, &(cosim_db.hdr_simular_list))
            {
                s_ms_pkt_hdr = list_entry(pos, ms_pkt_hdr_t, head);

                ASIC_DEBUG_BUS_CMP(buf, "CModel Simular BridgeHeader Msg:<NO. %d>\n", cnt);
                _sim_interface_bsr_show_mismatch_pkt_hdr_ms(s_ms_pkt_hdr, &v_ms_pkt_hdr);
                cnt++;

                ASIC_DEBUG_BUS_CMP(buf, "\n");
            }
        }

        list_del_all_and_free(&(cosim_db.hdr_simular_list));

        return DRV_E_NONE;
    }
    else
    {
        if (list_empty(&(cosim_db.sim_bheader_list[mod_id])))
        {
            ASIC_DEBUG_BUS_CMP(buf, "ms pkt_hdr verify error! <pkt_hdr list is empty>\n");
            *succ = FALSE;
            return DRV_E_NONE;
        }

        if (bus == NULL)
        {
            ASIC_DEBUG_BUS_CMP(buf, "ERROR! Invalid Para, NULL pointer during compare modId %d bridgeHeader\n", mod_id);
            return DRV_E_INVALID_PARAMETER;
        }

        sal_memset(&v_ms_pkt_hdr,0,sizeof(v_ms_pkt_hdr));
        ret = ms_pkt_hdr_bus_decode(bus, &v_ms_pkt_hdr);
        if (ret)
        {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"ms pkt_hdr bus decode error!\n");
            goto RELEASE;
        }

        brg_header_node = list_entry(cosim_db.sim_bheader_list[mod_id].next, cosim_brg_header_t, head);
        c_ms_pkt_hdr = brg_header_node->pkt_header;

        *succ = ms_pkt_hdr_bus_compare(c_ms_pkt_hdr, &v_ms_pkt_hdr);
        if ((brg_header_node->discard != FALSE) && (*succ == FALSE))
        {
            *is_discard = TRUE;
            if (mod_id == SIM_MODULE_IPE)
            {
                ASIC_DEBUG_BUS_CMP(buf, "Mismatch cmp IPE BridgeHeader!!!\n");
                ASIC_DEBUG_BUS_CMP(buf, "ERROR! IPE Moduel happen Discard, and DiscardType = %d\n",
                                brg_header_node->discard_type);
            }
            else if (mod_id == SIM_MODULE_EPE)
            {
                ASIC_DEBUG_BUS_CMP(buf, "Mismatch cmp EPE BridgeHeader!!!\n");
                ASIC_DEBUG_BUS_CMP(buf, "ERROR! EPE Moduel happen Discard, and DiscardType = %d\n",
                                brg_header_node->discard_type);
            }
        }

RELEASE:
        list_del(&brg_header_node->head);
        sal_free(brg_header_node->pkt_header);
        brg_header_node = NULL;
        sal_free(brg_header_node);
        brg_header_node = NULL;
        return ret;
    }
}


static int32
_sim_interface_do_module(uint32 chipid, uint32 chanid, uint32 pkt_len,
                    uint8 *pkt, uint8 mod_id, void *ext_info)
{
    int32 ret = 0;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};

    switch (mod_id)
    {
        case SIM_MODULE_IPE:  /* IPE */
            ret = cosim_do_ipe(chipid, chanid, pkt_len, *((uint8 *)ext_info), pkt); /* ext_info : ptpEn */
            break;
        case SIM_MODULE_EPE:  /* EPE */
            ret = cosim_do_epe(chipid, chanid, pkt_len, pkt);
            break;
        case SIM_MODULE_OAM:  /* OAM */
            ret = cosim_do_oam(chipid, chanid, pkt_len, pkt);
            break;
        case SIM_MODULE_FWD:  /* BSR */
            ret = cosim_do_bsr(chipid, chanid, pkt_len, pkt, (uint8*)ext_info);    /* ext_info : exception */
            break;
        default:
            ASIC_DEBUG_BUS_CMP(buf, "ERROR! sim_interface_do_module excute fail, invalid mod_id = %d!\n", mod_id);
            ret = DRV_E_INVALID_PARAMETER;
            break;
    }

    return ret;
}

/* Each module's out packet conpare interface */
/* Each module's out packet conpare interface */
static int32
_cosim_cmp_out_pkt(uint32 chipid, uint32 chanid, uint32 packet_length,
                            uint8 *pkt, uint8 mod_id, bool *succ)
{
    uint32 i;
    sim_pkt_cmp_t *sim_pkt = NULL,*dump_c_pkt=NULL,*simular_pkt = NULL;
    int32 ret = -1;
    *succ = FALSE;
    uint8 *cm_pkt = NULL;
    uint8 cnt=0;
    list_head_t *pos=NULL;
    bool match=FALSE, simular=FALSE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};
    char line[] = "----------------------------------------------";

    list_head_t *temp_list = cosim_db.sim_outpkt_list[mod_id];

    if(list_empty(&(temp_list[chanid])))
    {
        ASIC_DEBUG_BUS_CMP(buf,"CMODEL module %s no OutPacket, but RTL have packet!\n", sim_module_name[mod_id]);
        return DRV_E_CMODEL_AND_RTL_PKT_NOT_EQUAL;
    }

    if (mod_id==SIM_MODULE_FWD ||mod_id==SIM_MODULE_EPE)
    {
        *succ = FALSE;
        //list_for_each(temp_list[chanid].next, &(temp_list[chanid]))
        list_for_each(pos, &(temp_list[chanid]))
        {
            //sim_pkt = list_entry(temp_list[chanid].next, sim_pkt_cmp_t, head);
            sim_pkt = list_entry(pos, sim_pkt_cmp_t, head);
            cm_pkt = sim_pkt->pkt;
            if (chipid != sim_pkt->chip_id)
            {
                ASIC_DEBUG_BUS_CMP(buf,"%s\n",line);
                ASIC_DEBUG_BUS_CMP(buf,"chipid is not equal!\n");
                ASIC_DEBUG_BUS_CMP(buf,"ASIC chipid is :0x%x\n",chipid);
                ASIC_DEBUG_BUS_CMP(buf,"CMODEL chipid is :0x%x\n",sim_pkt->chip_id);
                goto ERROR;
            }
            if (mod_id==SIM_MODULE_FWD )
            {
            match = (0 == sal_memcmp(pkt+GREAT_BELT_HEADER_LEN, cm_pkt, packet_length - CRC_LEN));
            }
            else
            {
                match = (0 == sal_memcmp(pkt, cm_pkt, packet_length - CRC_LEN));
            }
            match &= (packet_length == sim_pkt->packet_length );
            simular = (chanid == sim_pkt->chan_id);
            if (match)
            {
                list_del(&sim_pkt->head);
                sal_free(sim_pkt);
                sim_pkt = NULL;
                *succ = TRUE;
                return DRV_E_NONE;
            }

            if ((!match) && simular)
            {
                /* if simular, add the simular entry into simular list*/
                simular_pkt = sal_malloc(sizeof(sim_pkt_cmp_t));
                if (NULL == simular_pkt)
                {
                    ASIC_DEBUG_BUS_CMP(buf,"Error!No memory mallco!\n");
                    return DRV_E_NO_MEMORY;
                }
                sal_memset(simular_pkt,0,sizeof(simular_pkt));
                sal_memcpy(simular_pkt, sim_pkt, sizeof(sim_pkt_cmp_t));

                list_add_tail(&(simular_pkt->head), &(cosim_db.pkt_simular_list[mod_id]));
            }
        }

        if (!(*succ))
        {
            if (mod_id==SIM_MODULE_FWD)
            {
                ASIC_DEBUG_BUS_CMP(buf, "=====================channel Id = %d,Pkt Mismatch=====================\n",chanid);
            ASIC_DEBUG_BUS_CMP(buf, "RTL OutPut Pkt ChipId:%d\n",chipid);
            ASIC_DEBUG_BUS_CMP(buf, "RTL OutPut PktLength:%d\n",packet_length);
            ASIC_DEBUG_BUS_CMP(buf, "RTL OutPut Pkt:\n");
            ret = _sim_interface_dump_pkt_content(pkt + GREAT_BELT_HEADER_LEN, packet_length);
            ASIC_DEBUG_BUS_CMP(buf, "\n");

            if(ret < 0)
            {
                ASIC_DEBUG_BUS_CMP(buf, "ASIC packet is empty!\n");
            }

            list_for_each(pos, &(cosim_db.pkt_simular_list[mod_id]))
            {
                dump_c_pkt = list_entry(pos, sim_pkt_cmp_t, head);
                    ASIC_DEBUG_BUS_CMP(buf, "=====================channel Id = %d,Pkt Mismatch=====================\n",dump_c_pkt->chan_id);
                ASIC_DEBUG_BUS_CMP(buf, "CModel OutPut Pkt ChipId:%d\n",dump_c_pkt->chip_id);
                ASIC_DEBUG_BUS_CMP(buf, "CModel OutPut PktLength:%d\n",dump_c_pkt->packet_length);
                ASIC_DEBUG_BUS_CMP(buf, "CModel OutPut Pkt :<NO. %d>\n", cnt);
                ret = _sim_interface_dump_pkt_content(dump_c_pkt->pkt, dump_c_pkt->packet_length);
                ASIC_DEBUG_BUS_CMP(buf, "\n");
                cnt ++;
            }
        }
            else
            {
                ASIC_DEBUG_BUS_CMP(buf, "=====================channel Id = %d,Pkt Mismatch=====================\n",chanid);
                ASIC_DEBUG_BUS_CMP(buf, "RTL OutPut Pkt ChipId:%d\n",chipid);
                ASIC_DEBUG_BUS_CMP(buf, "RTL OutPut PktLength:%d\n",packet_length);
                ASIC_DEBUG_BUS_CMP(buf, "RTL OutPut Pkt:\n");
                ret = _sim_interface_dump_pkt_content(pkt, packet_length);
                ASIC_DEBUG_BUS_CMP(buf, "\n");
                if(ret < 0)
                {
                    ASIC_DEBUG_BUS_CMP(buf, "ASIC packet is empty!\n");
                }
                list_for_each(pos, &(cosim_db.pkt_simular_list[mod_id]))
                {
                    dump_c_pkt = list_entry(pos, sim_pkt_cmp_t, head);
                    ASIC_DEBUG_BUS_CMP(buf, "=====================channel Id = %d,Pkt Mismatch=====================\n",dump_c_pkt->chan_id);
                    ASIC_DEBUG_BUS_CMP(buf, "CModel OutPut Pkt ChipId:%d\n",dump_c_pkt->chip_id);
                    ASIC_DEBUG_BUS_CMP(buf, "CModel OutPut PktLength:%d\n",dump_c_pkt->packet_length);
                    ASIC_DEBUG_BUS_CMP(buf, "CModel OutPut Pkt :<NO. %d>\n", cnt);
                    ret = _sim_interface_dump_pkt_content(dump_c_pkt->pkt, dump_c_pkt->packet_length);
                    ASIC_DEBUG_BUS_CMP(buf, "\n");
                    cnt ++;
                }
            }
        list_del_all_and_free(&(cosim_db.pkt_simular_list[mod_id]));
            ret = DRV_E_PKT_MISMATCH;
            goto ERROR;
        }
        else
        {
            list_del_all_and_free(&(cosim_db.pkt_simular_list[mod_id]));

        list_del(&sim_pkt->head);
        sal_free(sim_pkt);
        sim_pkt = NULL;
        *succ = TRUE;

        return DRV_E_NONE;
        }
    }
    else
    {
        sim_pkt = list_entry(temp_list[chanid].next, sim_pkt_cmp_t, head);

        if (chipid != sim_pkt->chip_id)
        {
            ASIC_DEBUG_BUS_CMP(buf,"%s\n",line);
            ASIC_DEBUG_BUS_CMP(buf,"chipid is not equal!\n");
            ASIC_DEBUG_BUS_CMP(buf,"ASIC chipid is :0x%x\n",chipid);
            ASIC_DEBUG_BUS_CMP(buf,"CMODEL chipid is :0x%x\n",sim_pkt->chip_id);
            goto ERROR;
        }
        else if (packet_length != sim_pkt->packet_length)
        {
            ASIC_DEBUG_BUS_CMP(buf,"%s\n",line);
            ASIC_DEBUG_BUS_CMP(buf,"pktlen is not equal!\n");
            ASIC_DEBUG_BUS_CMP(buf,"ASIC pktlen is :0x%x\n",packet_length);
            ASIC_DEBUG_BUS_CMP(buf,"CMODEL pktlen is :0x%x\n",sim_pkt->packet_length);
            goto ERROR;
        }
        else
        {
            if (SIM_MODULE_IPE == mod_id)
            {
                ret = _sim_interface_compare_pkt_content(pkt + GREAT_BELT_HEADER_LEN,
                                                         sim_pkt,
                                                         packet_length,chipid,chanid);
            }
            else
            {
                ret = _sim_interface_compare_pkt_content(pkt,sim_pkt, packet_length,chipid,chanid);
            }
            if(ret < 0)
            {
                goto ERROR;
            }
        }

        list_del(&sim_pkt->head);
        sal_free(sim_pkt);
        sim_pkt = NULL;
        *succ = TRUE;

        return DRV_E_NONE;
    }


ERROR:
    for (i = 0; i < SIM_MAX_CHANN_NUM; i++)
    {
        list_del_all_and_free(&temp_list[i]);
    }

    return ret;
}

/* Convert tableName to tableID */
static int32
_sim_interface_get_tblid_by_tblname(uint32 *tbl_id, char *name)
{
    tbls_id_t temp_table_id = MaxTblId_t;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};

    ret = drv_get_tbl_id_by_string(&temp_table_id, name);
    if (ret < 0)
    {
        ASIC_DEBUG_BUS_CMP(buf, "%% ERROR!, fail to conver tableName %s to tableId, please check the tableName!!\n", name);
    }
    else
    {
        *tbl_id = temp_table_id;
    }

    return ret;
}


/* Check whether cmodel all linklist is empty or not */
static int32
_sim_interface_check_cmodel_all_list_empty(void)
{
    int32 ret = DRV_E_NONE;;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};
    uint32 mod_id = 0;
    char glb_dump_file_path[256] = {0};
    FILE *fp = NULL;

    if (cosim_db.sim_dump_flag)
    {
        /* open dump file process */
        getcwd(glb_dump_file_path, sizeof(glb_dump_file_path));
        //strcpy(glb_dump_file_path, getenv("HOME"));
        sal_strcat(glb_dump_file_path, DUMP_CMODEL_LINKLIST_FILE_NAME);

        fp = fopen(glb_dump_file_path, "w");

        if ((NULL == fp) || feof(fp))
        {
            return DRV_E_FILE_OPEN_FAILED;
        }
    }

    /* now only check outpkt */
    for (mod_id = 0; mod_id < SIM_MODULE_NUM; mod_id++)
    {
        ret = cosim_chk_outpkt_empty(fp, mod_id);
        if(DRV_E_NONE != ret)
        {
            ASIC_DEBUG_BUS_CMP(buf, "Error! Check cmodel %s outpkt linkList is not empty!!\n", sim_module_name[mod_id]);
            ASIC_DEBUG_BUS_CMP(buf, "But then RTL has no outpkt!!\n");
            goto RELEASE;
        }
    }

    /* here only check the write table */
    ret = cosim_chk_table_empty(fp);
    if(DRV_E_NONE != ret)
    {
        goto RELEASE;
    }

RELEASE:
    if (cosim_db.sim_dump_flag)
    {
        if (fp)
        {
            fclose(fp);
            fp = NULL;
        }
    }

    return ret;
}

/* install cmodel cosim using store bus interface */
static int32
_sim_interface_install_cmodel_cosim_db_intrf(void)
{
    if (sim_interface_initialize)
    {
        return DRV_E_NONE;
    }

    /* append BSR store interfaces (cmodel using during cosim) */
    cosim_db.store_bsr_bus[SIM_FWD_MS_MET_FIFO] = sim_store_fwd_met_fifo_bus;
    cosim_db.store_bsr_bus[SIM_FWD_MS_ENQUEUE] = sim_store_fwd_enqueue_bus;
    cosim_db.store_bsr_bus[SIM_FWD_MS_DEQUEUE] = sim_store_fwd_dequeue_bus;

    /* append IPE store interfaces */
    cosim_db.store_ipe_bus[SIM_IPE_HA2PR] = sim_store_ipe_ha2pr_bus;
    cosim_db.store_ipe_bus[SIM_IPE_HA2IM] = sim_store_ipe_ha2im_bus;
    cosim_db.store_ipe_bus[SIM_IPE_IM2PP] = sim_store_ipe_im2pp_bus;
    cosim_db.store_ipe_bus[SIM_IPE_ILREQ] = sim_store_ipe_ilreq_bus;
    cosim_db.store_ipe_bus[SIM_IPE_OLREQ] = sim_store_ipe_olreq_bus;
    cosim_db.store_ipe_bus[SIM_IPE_IMPI2LM] = sim_store_ipe_impi2lm_bus;
    cosim_db.store_ipe_bus[SIM_IPE_IMPR2LM] = sim_store_ipe_impr2lm_bus;
    cosim_db.store_ipe_bus[SIM_IPE_LR2FW] = sim_store_ipe_lr2fw_bus;
    cosim_db.store_ipe_bus[SIM_IPE_LM2PP] = sim_store_ipe_lm2pp_bus;
    cosim_db.store_ipe_bus[SIM_IPE_OM2FW] = sim_store_ipe_om2fw_bus;
    cosim_db.store_ipe_bus[SIM_IPE_PR2IM] = sim_store_ipe_pr2im_bus;
    cosim_db.store_ipe_bus[SIM_IPE_PR2LM] = sim_store_ipe_pr2lm_bus;
    cosim_db.store_ipe_bus[SIM_IPE_RT2FW] = sim_store_ipe_rt2fw_bus;
    cosim_db.store_ipe_bus[SIM_IPE_UI2PP] = sim_store_ipe_ui2pp_bus;
    cosim_db.store_ipe_bus[SIM_IPE_EXCP] = sim_store_ipe_excp_bus;
    cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_LM_BUS] = sim_store_ipe_oam2fwd_sharelm_bus;
    cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_NAT_BUS] = sim_store_ipe_oam2fwd_sharenat_bus;
    cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_OAM_BUS] = sim_store_ipe_oam2fwd_shareoam_bus;
    cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_PTP_BUS] = sim_store_ipe_oam2fwd_shareptp_bus;
    cosim_db.store_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_DMTX_BUS] = sim_store_ipe_oam2fwd_sharedm_bus;

    /* append EPE store interfaces (waitting to add code) */
    cosim_db.store_epe_bus[SIM_EPE_AQ2CS] = sim_store_epe_aq2cs_bus;
    cosim_db.store_epe_bus[SIM_EPE_CS2OM] = sim_store_epe_cs2om_bus;
    cosim_db.store_epe_bus[SIM_EPE_HA2HP] = sim_store_epe_ha2hp_bus;
    cosim_db.store_epe_bus[SIM_EPE_HA2NH] = sim_store_epe_ha2nh_bus;
    cosim_db.store_epe_bus[SIM_EPE_HA2PR] = sim_store_epe_ha2pr_bus;
    cosim_db.store_epe_bus[SIM_EPE_HP2AQ] = sim_store_epe_hp2aq_bus;
    cosim_db.store_epe_bus[SIM_EPE_HP2HE] = sim_store_epe_hp2he_bus;
    cosim_db.store_epe_bus[SIM_EPE_HP2OM] = sim_store_epe_hp2om_bus;
    cosim_db.store_epe_bus[SIM_EPE_NH2HP] = sim_store_epe_nh2hp_bus;
    cosim_db.store_epe_bus[SIM_EPE_OM2HE] = sim_store_epe_om2he_bus;
    cosim_db.store_epe_bus[SIM_EPE_PR2HP] = sim_store_epe_pr2hp_bus;
    cosim_db.store_epe_bus[SIM_EPE_NETTX] = sim_store_epe_nettx_bus;
    cosim_db.store_epe_bus[SIM_EPE_EXCP] = sim_store_epe_excp_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_LM_BUS] = sim_store_epe_ha2nh_sharelm_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_NAT_BUS] = sim_store_epe_ha2nh_sharenat_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_OAM_BUS] = sim_store_epe_ha2nh_shareoam_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_PTP_BUS] = sim_store_epe_ha2nh_shareptp_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HA2NH_DMTX_BUS] = sim_store_epe_ha2nh_sharedm_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_LM_BUS] = sim_store_epe_hp2oam_sharelm_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_NAT_BUS] = sim_store_epe_hp2oam_sharenat_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_OAM_BUS] = sim_store_epe_hp2oam_shareoam_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_PTP_BUS] = sim_store_epe_hp2oam_shareptp_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_HP2OM_DMTX_BUS] = sim_store_epe_hp2oam_sharedm_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_LM_BUS] = sim_store_epe_np2hp_sharelm_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_NAT_BUS] = sim_store_epe_np2hp_sharenat_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_OAM_BUS] = sim_store_epe_np2hp_shareoam_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_PTP_BUS] = sim_store_epe_np2hp_shareptp_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_NH2HP_DMTX_BUS] = sim_store_epe_np2hp_sharedm_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_LM_BUS] = sim_store_epe_oam2he_sharelm_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_NAT_BUS] = sim_store_epe_oam2he_sharenat_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_OAM_BUS] = sim_store_epe_oam2he_shareoam_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_PTP_BUS] = sim_store_epe_oam2he_shareptp_bus;
    cosim_db.store_epe_bus[SIM_EPE_SHA_FLD_OM2HE_DMTX_BUS] = sim_store_epe_oam2he_sharedm_bus;

    /* append OAM store interfaces (waitting to add code) */
    cosim_db.store_oam_bus[SIM_OAM_HA2PP] = sim_store_oam_ha2pp_bus;
    cosim_db.store_oam_bus[SIM_OAM_PP2FW] = sim_store_oam_pp2fw_bus;
    cosim_db.store_oam_bus[SIM_OAM_PR2PP] = sim_store_oam_pr2pp_bus;

    /* append store key interface */
    cosim_db.store_key = sim_store_hash_tcam_key;

    cosim_db.store_table = sim_store_table_info;

    cosim_db.store_bheader = _sim_interface_store_pkt_hdr;

    cosim_db.store_outpkt = _sim_interface_store_out_pkt;

    cosim_db.store_discard_type = _sim_interface_store_dsicard_info;

    return DRV_E_NONE;
}

static int32
_sim_interface_install_cosim_api(void)
{
    cosim_api.chk_linklist = _sim_interface_check_cmodel_all_list_empty;
    cosim_api.do_module = _sim_interface_do_module;
    cosim_api.do_tail_drop = cosim_bsr_enqueue_taildrop;
    cosim_api.get_buf_info = cosim_get_bufstore_info;
    cosim_api.tblname_to_id = _sim_interface_get_tblid_by_tblname;

    cosim_api.cmp_bsr_bus[SIM_FWD_MS_MET_FIFO] = cosim_fwd_met_fifo_verify;
    cosim_api.cmp_bsr_bus[SIM_FWD_MS_ENQUEUE] = cosim_fwd_enqueue_verify;
    cosim_api.cmp_bsr_bus[SIM_FWD_MS_DEQUEUE] = cosim_fwd_dequeue_verify;

    cosim_api.cmp_ipe_bus[SIM_IPE_HA2PR] = cosim_ipe_ha2pr_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_HA2IM] = cosim_ipe_ha2im_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_IM2PP] = cosim_ipe_im2pp_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_ILREQ] = cosim_ipe_ilreq_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_OLREQ] = cosim_ipe_olreq_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_IMPI2LM] = cosim_ipe_impi2lm_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_IMPR2LM] = cosim_ipe_impr2lm_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_LR2FW] = cosim_ipe_lr2fw_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_LM2PP] = cosim_ipe_lm2pp_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_OM2FW] = cosim_ipe_om2fw_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_PR2IM] = cosim_ipe_pr2im_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_PR2LM] = cosim_ipe_pr2lm_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_RT2FW] = cosim_ipe_rt2fw_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_UI2PP] = cosim_ipe_ui2pp_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_EXCP] = cosim_ipe_excp_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_LM_BUS] = cosim_ipe_oam2fwd_sharelm_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_NAT_BUS] = cosim_ipe_oam2fwd_sharenat_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_OAM_BUS] = cosim_ipe_oam2fwd_shareoam_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_PTP_BUS] = cosim_ipe_oam2fwd_shareptp_verify;
    cosim_api.cmp_ipe_bus[SIM_IPE_SHA_FLD_OM2FW_DMTX_BUS] = cosim_ipe_oam2fwd_sharedm_verify;

    cosim_api.cmp_epe_bus[SIM_EPE_AQ2CS] = cosim_epe_aq2cs_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_CS2OM] = cosim_epe_cs2om_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_HA2HP] = cosim_epe_ha2hp_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_HA2NH] = cosim_epe_ha2nh_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_HA2PR] = cosim_epe_ha2pr_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_HP2AQ] = cosim_epe_hp2aq_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_HP2HE] = cosim_epe_hp2he_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_HP2OM] = cosim_epe_hp2om_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_NH2HP] = cosim_epe_nh2hp_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_OM2HE] = cosim_epe_om2he_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_PR2HP] = cosim_epe_pr2hp_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_NETTX] = cosim_epe_nettx_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_EXCP] = cosim_epe_excp_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_HA2NH_LM_BUS] = cosim_epe_ha2nh_sharelm_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_HA2NH_NAT_BUS] = cosim_epe_ha2nh_sharenat_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_HA2NH_OAM_BUS] = cosim_epe_ha2nh_shareoam_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_HA2NH_PTP_BUS] = cosim_epe_ha2nh_shareptp_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_HA2NH_DMTX_BUS] = cosim_epe_ha2nh_sharedm_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_HP2OM_LM_BUS] = cosim_epe_hp2oam_sharelm_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_HP2OM_NAT_BUS] = cosim_epe_hp2oam_sharenat_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_HP2OM_OAM_BUS] = cosim_epe_hp2oam_shareoam_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_HP2OM_PTP_BUS] = cosim_epe_hp2oam_shareptp_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_HP2OM_DMTX_BUS] = cosim_epe_hp2oam_sharedm_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_NH2HP_LM_BUS] = cosim_epe_np2hp_sharelm_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_NH2HP_NAT_BUS] = cosim_epe_np2hp_sharenat_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_NH2HP_OAM_BUS] = cosim_epe_np2hp_shareoam_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_NH2HP_PTP_BUS] = cosim_epe_np2hp_shareptp_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_NH2HP_DMTX_BUS] = cosim_epe_np2hp_sharedm_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_OM2HE_LM_BUS] = cosim_epe_oam2he_sharelm_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_OM2HE_NAT_BUS] = cosim_epe_oam2he_sharenat_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_OM2HE_OAM_BUS] = cosim_epe_oam2he_shareoam_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_OM2HE_PTP_BUS] = cosim_epe_oam2he_shareptp_verify;
    cosim_api.cmp_epe_bus[SIM_EPE_SHA_FLD_OM2HE_DMTX_BUS] = cosim_epe_oam2he_sharedm_verify;

    cosim_api.cmp_oam_bus[SIM_OAM_HA2PP] = cosim_oam_ha2pp_verify;
    cosim_api.cmp_oam_bus[SIM_OAM_PP2FW] = cosim_oam_pp2fw_verify;
    cosim_api.cmp_oam_bus[SIM_OAM_PR2PP] = cosim_oam_pr2pp_verify;

    cosim_api.cmp_outpkt = _cosim_cmp_out_pkt;
    cosim_api.cmp_key = cosim_hash_tcam_key_verify;
    cosim_api.cmp_table = cosim_cmp_table;
    cosim_api.cmp_bhdr = _cosim_pkt_hdr_verify;

    cosim_api.oam_update = cosim_oam_engine_update;

    return DRV_E_NONE;
}


int32
sim_interface_init(char* config_filename, char* alloc_filename, bool rtl_dump_flag)
{
    FILE *fp_config = NULL, *fp_alloc = NULL;
    char buf[128] = {0}, line[128] = {0};
    int32 ret = DRV_E_NONE;
    uint8 chip_num = 1, chip_id_base = 2, chip_id = 0, chip_id_offset = 0;
    cm_mem_profile_t profile_index = CM_MEM_PROFILE_DEFAULT;
    cm_table_allocation_info_t alloc_info;
    sim_alloc_mem_type_t alloc_type = SIM_MAX_MEM_TYPE;
    sw_model_write_t write_info;

    if (sim_interface_initialize)
    {
        return DRV_E_NONE;
    }

    /* check input parameter */
    if ((config_filename == NULL) || (alloc_filename == NULL))
    {
        ret = DRV_E_INVALID_PARAMETER;
        goto ERROR;
    }

    cosim_db.sim_dump_flag = rtl_dump_flag;

    /* append cmodel store interface */
    DRV_IF_ERROR_RETURN(_sim_interface_install_cosim_api());
    DRV_IF_ERROR_RETURN(_sim_interface_install_cmodel_cosim_db_intrf());

#if 1
    cosim_db.sim_read_tbl_cosim_flag = TRUE;
    cosim_db.sim_write_tbl_cosim_flag = TRUE;
    cosim_db.sim_chk_read_tbl_flag = TRUE;
    cosim_db.sim_chk_write_tbl_flag = TRUE;
    cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE] = 0xFFFFFFFF;
    cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE] = 0xFFFFFFFF;
    cosim_db.sim_cosim_bus_flag[SIM_MODULE_FWD] = 0xFFFFFFFF;
    cosim_db.sim_cosim_bus_flag[SIM_MODULE_OAM] = 0xFFFFFFFF;
    cosim_db.sim_key_cosim_flag[SIM_KEY_TYPE_HASH] = TRUE;
    cosim_db.sim_key_cosim_flag[SIM_KEY_TYPE_TCAM] = TRUE;
#else
    /* temp code, should read control profile */
    DRV_IF_ERROR_RETURN(sim_interface_load_debug_bus_cfg(COSIM_DEBUG_CFG));
#endif

    /* 0) creat all linklist */
    _sim_interface_all_linklist_operation(SIM_LINKLIST_OP_CREAT);

    /* 1) init driver */
    DRV_IF_ERROR_RETURN(drv_init(chip_num, chip_id_base));

    /* 2) init model */

    for (chip_id = chip_id_base; chip_id < chip_id_base + chip_num; chip_id++)
    {
        chip_id_offset = chip_id - chip_id_base;

        ret = sram_model_initialize(chip_id_offset);
        if (ret < DRV_E_NONE)
        {
            ASIC_DEBUG_BUS_CMP(buf, "ERROR! co-sim fail to init sram model, chip_id = %d\n", chip_id);
            goto ERROR;
        }

        ret = tcam_model_initialize(chip_id_offset);
        if (ret < DRV_E_NONE)
        {
            ASIC_DEBUG_BUS_CMP(buf, "ERROR! co-sim fail to init tcam model, chip_id = %d\n", chip_id);
            goto ERROR;
        }
    }

    /* 3) Load Allocation profile */
    fp_alloc = fopen(alloc_filename, "r");
    if (NULL == fp_alloc)
    {
        ret = DRV_E_FILE_OPEN_FAILED;
        ASIC_DEBUG_BUS_CMP(buf, "ERROR! Can not find the allocation file %s!\n", alloc_filename);
        goto ERROR;
    }
    while(NULL != fgets(line, 128, fp_alloc)) /* start parser allocation configuration */
    {
        /* jump Note and NULL lines */
        if ('#' == line[0] || line[0] == '\0' || line[0] == '\r' || line[0] == '\n')
        {
            continue;
        }

        if (0 == sal_strncmp(line, "source quiet",  sal_strlen("source quiet")))
        {
            continue;
        }

        sal_memset(&alloc_info, 0, sizeof(alloc_info));
        DRV_IF_ERROR_RETURN(_sim_interface_parser_alloc_file(line, &alloc_info, &alloc_type, &profile_index));

        switch (alloc_type)
        {
            case SIM_MEM_DYNIC_TBL:
                ret = cm_sim_cfg_kit_allocate_process();
                if (ret < DRV_E_NONE)
                {
                    ASIC_DEBUG_BUS_CMP(buf, "ERROR! Dynamic table allocation failed, ret %d, ID %d!\n",
                                        ret, alloc_info.table_id);
                    goto ERROR;
                }
                break;
            case SIM_MEM_TCAM_KEY_INIT:
                cm_sim_allocate_tcam_key_extend_info();
                break;
            case SIM_MEM_TCAM_KEY:
                ret = cm_sim_cfg_kit_allocate_tcam_key_process(&alloc_info);
                if (ret < DRV_E_NONE)
                {
                    ASIC_DEBUG_BUS_CMP(buf, "ERROR! Tcam key allocation failed, ret %d, ID %d!\n",
                                        ret, alloc_info.table_id);
                    goto ERROR;
                }
                break;
            case SIM_MEM_TCAM_AD:
                ret = cm_sim_cfg_kit_allocate_tcam_ad_process(&alloc_info);
                if (ret < DRV_E_NONE)
                {
                    ASIC_DEBUG_BUS_CMP(buf, "ERROR! Tcam AD allocation failed, ret %d, ID %d!\n",
                                        ret, alloc_info.table_id);
                    goto ERROR;
                }
                break;
            case SIM_MEM_LPM_TCAM_KEY:
                ret = cm_sim_cfg_kit_allocate_lpm_tcam_key_process(&alloc_info);
                if (ret < DRV_E_NONE)
                {
                    ASIC_DEBUG_BUS_CMP(buf, "ERROR! LPM key allocation failed, ret %d, ID %d!\n",
                                        ret, alloc_info.table_id);
                    goto ERROR;
                }
                break;
            case SIM_MEM_LPM_TCAM_AD:
                ret = cm_sim_cfg_kit_allocate_lpm_tcam_ad_process(&alloc_info);
                if (ret < DRV_E_NONE)
                {
                    ASIC_DEBUG_BUS_CMP(buf, "ERROR! LPM tcam ad allocation failed, ret %d, ID %d!\n",
                                        ret, alloc_info.table_id);
                    goto ERROR;
                }
                break;
            case SIM_MEM_PROFILE_INIT:
                ret = cm_sim_cfg_kit_init_mem_allocation_profile(profile_index);
                if (ret < DRV_E_NONE)
                {
                    ASIC_DEBUG_BUS_CMP(buf, "ERROR! Profile init failed, ret %d!\n", ret);
                    goto ERROR;
                }
                break;
            default:
                ASIC_DEBUG_BUS_CMP(buf, "ERROR! Invalid Alloc type %d!\n", alloc_type);
                goto ERROR;
        }

        sal_memset(line, 0, sizeof(line));
    }

    /* 4) Init cmodel */
    DRV_IF_ERROR_RETURN(sim_model_init(UM_EMU_MODE_CMODEL));

    /* 5) Parser config file and load cfg into CModel */
    /* load asic configuration */
    fp_config= fopen(config_filename, "r");
    if (NULL == fp_config)
    {
        ret = DRV_E_FILE_OPEN_FAILED;
        goto ERROR;
    }

    sal_memset(line, 0, 128);
    while(NULL != fgets(line, 128, fp_config))
    {
        sal_memset(&write_info, 0, sizeof(write_info));

        ret = _sim_interface_parser_cfg_file(line, &write_info);

        if (ret < 0)
        {
            ASIC_DEBUG_BUS_CMP(buf, "%s %d, line = %s!\n", __FUNCTION__, __LINE__, line);
            return ret;
        }

        if (write_info.is_tcam)
        {
            DRV_IF_ERROR_RETURN(tcam_model_write(write_info.chip_id-chip_id_base,
                                                 write_info.sw_model_address,
                                                 &(write_info.value), 4));
        }
        else
        {
            DRV_IF_ERROR_RETURN(sram_model_write(write_info.chip_id-chip_id_base,
                                                 write_info.sw_model_address,
                                                 &(write_info.value), 4));
#if 0
            if (DRV_ADDR_IN_DYNAMIC_SRAM_4W_RANGE(write_info.hw_addr))
            {
                uint32 index = (write_info.sw_model_address - sram_info[0].dynamic_mem_base)/DRV_BYTES_PER_ENTRY;
                sram_info[0].dynamic_mem_wbit[index] = TRUE;
            }
            else if (DRV_ADDR_IN_TCAMAD_SRAM_4W_RANGE(write_info.hw_addr))
            {
                uint32 index = (write_info.sw_model_address - sram_info[0].tcam_ad_mem_base)/DRV_BYTES_PER_ENTRY;
                sram_info[0].tcam_ad_mem_wbit[index] = TRUE;
            }
            else if (DRV_ADDR_IN_TCAM_DATA_RANGE(write_info.hw_addr))
            {
                uint32 index = (write_info.sw_model_address - (uint32)tcam_info.int_tcam_data_base[0])/DRV_BYTES_PER_ENTRY;
                SET_BIT(tcam_info.int_tcam_wbit[0][index/DRV_BITS_PER_WORD], index%DRV_BITS_PER_WORD);
            }
            else if (DRV_ADDR_IN_TCAM_MASK_RANGE(write_info.hw_addr))
            {
                uint32 index = (write_info.sw_model_address - (uint32)tcam_info.int_tcam_mask_base[0])/DRV_BYTES_PER_ENTRY;
                SET_BIT(tcam_info.int_tcam_wbit[0][index/DRV_BITS_PER_WORD], index%DRV_BITS_PER_WORD);
            }
            else if (DRV_ADDR_IN_LPM_TCAM_DATA_RANGE(write_info.hw_addr))
            {
                uint32 index = (write_info.sw_model_address - (uint32)tcam_info.int_lpm_tcam_data_base[0])/DRV_BYTES_PER_ENTRY;
                SET_BIT(tcam_info.int_lpm_tcam_wbit[0][index/DRV_BITS_PER_WORD], index%DRV_BITS_PER_WORD);
            }
            else if (DRV_ADDR_IN_LPM_TCAM_MASK_RANGE(write_info.hw_addr))
            {
                uint32 index = (write_info.sw_model_address - (uint32)tcam_info.int_lpm_tcam_mask_base[0])/DRV_BYTES_PER_ENTRY;
                SET_BIT(tcam_info.int_lpm_tcam_wbit[0][index/DRV_BITS_PER_WORD], index%DRV_BITS_PER_WORD);
            }
#endif
        }
#if COSIM_DBG_FLAG
        _sim_interface_parser_cfg_write_wbit_for_dump(line);
#endif

    }

    sim_interface_initialize = TRUE;

ERROR:
    if (NULL != fp_alloc)
    {
        fclose(fp_alloc);
        fp_alloc = NULL;
    }
    else
    {
        ASIC_DEBUG_BUS_CMP(buf, "Error! Can not find the Memory alloc src file path: %s!\n", alloc_filename);
    }

    if (NULL != fp_config)
    {
        fclose(fp_config);
        fp_config = NULL;
    }
    else
    {
        ASIC_DEBUG_BUS_CMP(buf, "Error! Can not find the config file path: %s!\n", config_filename);
    }

    return ret;
}


int32
sim_interface_release(void)
{
    uint8 chip_num = 1, chip_id_base = 2, chip_id = 0, chip_id_offset = 0;
    if (!sim_interface_initialize)
    {
        return DRV_E_NONE;
    }

#if 0
    int32 ret = DRV_E_NONE;
    char buf[128] = {0};
    ret = cosim_chk_table_empty();
    if (ret < 0)
    {
        ASIC_DEBUG_BUS_CMP(buf, "%% Check each table remained information error! Error Code: %d\n", ret);
    }
#endif

    _sim_interface_all_linklist_operation(SIM_LINKLIST_OP_DELETE);
    sal_memset(&cosim_db, 0, sizeof(cosim_db));

    sim_interface_initialize = FALSE;

    DRV_IF_ERROR_RETURN(drv_get_chipnum(&chip_num));
    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chip_id_base));

    for (chip_id = chip_id_base; chip_id < chip_id_base + chip_num; chip_id++)
    {
        chip_id_offset = chip_id - chip_id_base;

        sram_model_release(chip_id_offset);


        tcam_model_release(chip_id_offset);

    }




    DRV_IF_ERROR_RETURN(sim_model_release());

    return DRV_E_NONE;
}

bool
sim_field_compare(uint32 c_field, uint32 v_field, char *name)
{
   char buf[128];
   if (c_field != v_field)
   {
      ASIC_DEBUG_BUS_CMP(buf,"%s mismatch <Cmodel = 0x%x, ASIC = 0x%x>\n", name, c_field, v_field);
      return FALSE;
   }

   return TRUE;
}

int32
sim_check_key(uint32 tbls_id, uint32* p_src_key, uint32* p_dst_key, bool* p_pass)
{
    uint8 filed_index = 0;
    uint32 src_field_value = 0;
    uint32 dst_field_value = 0;
    tables_info_t* p_tables_info = &drv_tbls_list[tbls_id];
    uint8 match = TRUE;
    uint32 rtl_key_size = TABLE_ENTRY_SIZE(tbls_id)/4;
    uint32 rtl_key = 0, i =0;

    for (i = 0; i < rtl_key_size/2; i++)
    {
        rtl_key = p_dst_key[i];
        p_dst_key[i]=p_dst_key[rtl_key_size - i -1] ;
        p_dst_key[rtl_key_size - i -1] = rtl_key;
    }

    for (filed_index = 0; filed_index < p_tables_info->num_fields; filed_index++)
    {
        DRV_IF_ERROR_RETURN(drv_get_field(tbls_id, filed_index, p_src_key, &src_field_value));
        DRV_IF_ERROR_RETURN(drv_get_field(tbls_id, filed_index, p_dst_key, &dst_field_value));

        match &= sim_field_compare(src_field_value,
                                   dst_field_value,
                                   p_tables_info->ptr_fields[filed_index].ptr_field_name);
    }
    *p_pass = match;

    return DRV_E_NONE;
}


