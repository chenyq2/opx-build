/****************************************************************************
 * sim_epe_interface.c
 *
 * Copyright:    (c)2007 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Xiaobo Yan
 * Date:         2007-4-14
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sim_epe_interface.h"
#include "cm_lib.h"

int32
cosim_do_epe(uint32 chipid, uint32 chanid, uint32 pkt_len, uint8 *pkt)
{
    epe_in_pkt_t in_pkt;
    list_head_t out_pkt, *pos = NULL;
    int ret;
    out_pkt_t *output=NULL;

    if (pkt == NULL)
    {
        return DRV_E_INVALID_PTR;
    }

    sal_memset(&in_pkt, 0, sizeof(epe_in_pkt_t));
    INIT_LIST_HEAD(&out_pkt);

    in_pkt.chip_id = chipid;
    in_pkt.chan_id = chanid;
    in_pkt.pkt = (uint8*)sal_malloc(MTU);
    if (NULL == in_pkt.pkt)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(in_pkt.pkt, 0, MTU);
    sal_memcpy(in_pkt.pkt, pkt+GREAT_BELT_HEADER_LEN, pkt_len); /* only raw packet, do not include bheader */
    in_pkt.packet_length = pkt_len;         /* do not include bheader len */
    in_pkt.pkt_info = NULL;

    in_pkt.module_bus.dest_id_discard = 0;  /* cmodel mustbe 0 */
    in_pkt.module_bus.pkt_len = pkt_len;    /* cmodel epe can not support cutThrough */
    sal_memcpy(in_pkt.module_bus.packet_header, pkt, GREAT_BELT_HEADER_LEN);

    ret = cm_do_epe(&in_pkt, &out_pkt);
    if (ret < 0)
    {
        return ret;
    }

    list_for_each(pos, &out_pkt)
    {
        output = list_entry(pos, out_pkt_t, head);
        if (cosim_db.store_outpkt)
        {
            ret = cosim_db.store_outpkt(output->chip_id,
                                        output->chan_id,
                                        output->packet_length,
                                        output->pkt,
                                        SIM_MODULE_EPE,
                                        cosim_discard_info.discard,
                                        cosim_discard_info.discard_type);
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("CoSIM: EPE engine store outpkt error ! ret = %d\n", ret);
            }
        }
    }

    list_del_all_and_free(&out_pkt);

    return DRV_E_NONE;
}
int32
sim_store_epe_aq2cs_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_aq2cs_t *new_node;
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_result;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_AQ2CS))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_aq2cs_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_aq2cs_t));

    new_node->pi_packet_length_adjust_type = pkt_info->packet_length_adjust_type;
    new_node->pi_packet_length_adjust = pkt_info->packet_length_adjust;
    new_node->pi_channel_id = inpkt->chan_id;
    new_node->pi_priority = pkt_info->priority;
    new_node->pi_color = pkt_info->color;
    new_node->pi_packet_length = pkt_info->packet_length;
    new_node->pi_rx_oam_type = pkt_info->rx_oam_type;
    new_node->pi_from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    new_node->pi_discard_type = pkt_info->discard_type;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_service_policer_valid = pkt_info->service_policer_valid;
    new_node->pi_dest_vlan_ptr = pkt_info->dest_vlan_ptr;
    new_node->pi_logic_dest_port = pkt_info->logic_dest_port;
    new_node->pi_port_policer_valid = pkt_info->port_policer_valid;
    new_node->pi_ipg_index = pkt_info->ipg_index;
    new_node->pi_flow_stats0_valid = pkt_info->flow_stats0_valid;
    new_node->pi_flow_stats0_ptr = pkt_info->flow_stats0_ptr;
    new_node->pi_flow_stats1_valid = pkt_info->flow_stats1_valid;
    new_node->pi_flow_stats1_ptr = pkt_info->flow_stats1_ptr;
    new_node->pi_flow_policer_valid = pkt_info->flow_policer_valid;
    new_node->pi_flow_policer_ptr = pkt_info->flow_policer_ptr;
    new_node->pi_agg_flow_policer_valid = pkt_info->agg_flow_policer_valid;
    new_node->pi_agg_flow_policer_ptr = pkt_info->agg_flow_policer_ptr;
    new_node->pi_acl_log_en0 = pkt_info->acl_log_en0;
    new_node->pi_acl_log_id0 = pkt_info->acl_log_id0;
    new_node->pi_acl_log_en1 = pkt_info->acl_log_en1;
    new_node->pi_acl_log_id1 = pkt_info->acl_log_id1;
    new_node->pi_acl_log_en2 = pkt_info->acl_log_en2;
    new_node->pi_acl_log_id2 = pkt_info->acl_log_id2;
    new_node->pi_acl_log_en3 = pkt_info->acl_log_en3;
    new_node->pi_acl_log_id3 = pkt_info->acl_log_id3;
    new_node->pi_hard_error = 0;
    new_node->pi_oam_lookup_en = pkt_info->oam_lookup_en;
    new_node->pi_lm_lookup_type = pkt_info->lm_lookup_type;
    new_node->pi_lm_lookup_en0 = pkt_info->lm_lookup_en0;
    new_node->pi_packet_cos0 = pkt_info->packet_cos0;
    new_node->pi_lm_lookup_en1 = pkt_info->lm_lookup_en1;
    new_node->pi_packet_cos1 = pkt_info->packet_cos1;
    new_node->pi_lm_lookup_en2 = pkt_info->lm_lookup_en2;
    new_node->pi_packet_cos2 = pkt_info->packet_cos2;
    new_node->pi_oam_lookup_num = pkt_info->oam_lookup_num;
    new_node->pi_is_tcp = pkt_info->is_tcp;
    new_node->pi_is_udp = pkt_info->is_udp;
    new_node->pi_global_dest_port = pkt_info->global_dest_port;
    new_node->pi_fid = pkt_info->fid;
    new_node->pi_packet_header_en = pkt_info->packet_header_en;
    new_node->pi_packet_header_en_egress = pkt_info->packet_header_en_egress;
    new_node->pr_layer3_type = pas_rslt->layer3_type;
    new_node->pr_layer4_type = pas_rslt->layer4_type;


    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_AQ2CS]));


    return DRV_E_NONE;
}
int32
sim_store_epe_cs2om_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_cs2om_t *new_node;
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_result;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_CS2OM))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_cs2om_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_cs2om_t));

    new_node->pi_is_udp = pkt_info->is_udp;
    new_node->pi_packet_header_en = pkt_info->packet_header_en;
    new_node->pi_packet_header_en_egress = pkt_info->packet_header_en_egress;
    new_node->pi_channel_id = inpkt->chan_id;
    new_node->pi_packet_length = pkt_info->packet_length;
    new_node->pi_rx_oam_type = pkt_info->rx_oam_type;
    new_node->pi_color = pkt_info->color;
    new_node->pi_from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_discard_type = pkt_info->discard_type;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_lm_lookup_type = pkt_info->lm_lookup_type;
    new_node->pi_oam_lookup_en = pkt_info->oam_lookup_en;
    new_node->pi_lm_lookup_en0 = pkt_info->lm_lookup_en0;
    new_node->pi_packet_cos0 = pkt_info->packet_cos0;
    new_node->pi_oam_lookup_num = pkt_info->oam_lookup_num;
    new_node->pi_lm_lookup_en1 = pkt_info->lm_lookup_en1;
    new_node->pi_lm_lookup_en2 = pkt_info->lm_lookup_en2;
    new_node->pi_packet_cos1 = pkt_info->packet_cos1;
    new_node->pi_packet_cos2 = pkt_info->packet_cos2;
    new_node->pi_priority = pkt_info->priority;
    new_node->pi_hard_error = 0;
    new_node->pi_global_dest_port = pkt_info->global_dest_port;
    new_node->pi_flow_stats1_valid = pkt_info->flow_stats1_valid;
    new_node->pi_flow_stats1_ptr = pkt_info->flow_stats1_ptr;
    new_node->pi_flow_stats0_valid = pkt_info->flow_stats0_valid;
    new_node->pi_flow_stats0_ptr = pkt_info->flow_stats0_ptr;
    new_node->pi_acl_log_en0 = pkt_info->acl_log_en0;
    new_node->pi_acl_log_id0 = pkt_info->acl_log_id0;
    new_node->pi_acl_log_en1 = pkt_info->acl_log_en1;
    new_node->pi_acl_log_id1 = pkt_info->acl_log_id1;
    new_node->pi_acl_log_en2 = pkt_info->acl_log_en2;
    new_node->pi_acl_log_id2 = pkt_info->acl_log_id2;
    new_node->pi_acl_log_en3 = pkt_info->acl_log_en3;
    new_node->pi_acl_log_id3 = pkt_info->acl_log_id3;
    new_node->pi_fid = pkt_info->fid;
    new_node->pi_dest_vlan_ptr = pkt_info->dest_vlan_ptr;
    new_node->pi_is_tcp = pkt_info->is_tcp;
    new_node->pr_layer3_type = pas_rslt->layer3_type;
    new_node->pr_layer4_type = pas_rslt->layer4_type;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_CS2OM]));


    return DRV_E_NONE;
}
int32
sim_store_epe_excp_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    ms_epe_excp_info_t *new_node;
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)inpkt->pkt_info;
    greatbelt_exception_info_t *bexception = (greatbelt_exception_info_t *)pkt_info->bexception;


   if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_EXCP))
    {
        return DRV_E_NONE;
    }

    if (pkt_info->tmp_complete_discard )
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(ms_epe_excp_info_t));


    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ms_epe_excp_info_t));


    new_node->dest_id_discard = bexception->dest_id_discard;
    new_node->l2_span_id = bexception->l2_span_id;
    new_node->l3_span_id = bexception->l3_span_id;
    new_node->acl_log_id1 = bexception->acl_log_id1;
    new_node->acl_log_id0 = bexception->acl_log_id0;
    new_node->egress_excp = bexception->egress_exception;
    new_node->excp_pkt_type = bexception->exception_packet_type;
    new_node->excp_vector = bexception->exception_vector;
    new_node->excp_from_sgmac = bexception->exception_from_sgmac;
    new_node->excp_number = bexception->exception_number;
    new_node->acl_log_id3 = bexception->acl_log_id3;
    new_node->acl_log_id2 = bexception->acl_log_id2;
    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_EXCP]));


    return DRV_E_NONE;
}

int32
sim_store_epe_nettx_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    ms_net_tx_t *pkt_info = (ms_net_tx_t *)(&inpkt->ms_net_tx);
    epe_packet_info_t *pktinfo = (epe_packet_info_t *)inpkt->pkt_info;
    ms_nettx_t *new_node;

   if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_NETTX))
    {
        return DRV_E_NONE;
    }

    if (pktinfo->tmp_complete_discard)
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(ms_nettx_t));


    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ms_nettx_t));

    new_node->loopback_valid = pkt_info->loopback_en;
    new_node->mac_valid = pkt_info->mac_valid;
    new_node->udp_ptp = pkt_info->udp_ptp;
    new_node->frag_info1 = pkt_info->frag_info1;
    new_node->ptp_offset = pkt_info->ptp_offset;
    new_node->layer4_check_sum = pkt_info->layer4_check_sum;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_NETTX]));


    return DRV_E_NONE;
}

int32
sim_store_epe_ha2hp_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_ha2hp_t *new_node;
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)inpkt->pkt_info;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_HA2HP))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_ha2hp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_ha2hp_t));

    new_node->pi_from_cpu_lm_up_disable = pkt_info->from_cpu_lm_up_disable;
    new_node->pi_from_cpu_lm_down_disable = pkt_info->from_cpu_lm_down_disable;
    new_node->pi_oam_use_fid = pkt_info->oam_use_fid;
    new_node->pi_congestion_valid = pkt_info->congestion_valid;
    new_node->pi_tx_dm_en = pkt_info->tx_dm_en;
    new_node->pi_header_hash = pkt_info->header_hash;
    new_node->pi_port_mac_sa_en = pkt_info->port_mac_sa_en;
    new_node->pi_roaming_state = pkt_info->roaming_state;
    new_node->pi_mcast_id = pkt_info->mcast_id;
    new_node->pi_non_crc = pkt_info->non_crc;
    new_node->pi_cw_added = pkt_info->cw_add;
    new_node->pi_mpls_label_disable = pkt_info->mpls_label_disable;
    new_node->pi_source_port_extender = pkt_info->source_port_extender;
    new_node->pi_fid = pkt_info->fid;
    new_node->pi_packet_length = pkt_info->packet_length;
    new_node->pi_next_hop_ptr = pkt_info->next_hop_ptr;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_HA2HP]));


    return DRV_E_NONE;
}
int32
sim_store_epe_ha2nh_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_ha2nh_t *new_node;
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)inpkt->pkt_info;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_HA2NH))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_ha2nh_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_ha2nh_t));

    new_node->pi_bypass_all = pkt_info->bypass_all;
    new_node->pi_next_hop_ptr1_to0 = (pkt_info->next_hop_ptr&3);
    new_node->pi_ds_next_hop_dot_bypass = pkt_info->ds_nexthop_dot_bypass_all;
    new_node->pi_channel_id = inpkt->chan_id;
    new_node->pi_source_port_isolate_id = pkt_info->source_port_isolate_id;
    new_node->pi_dest_map = pkt_info->dest_map;
    new_node->pi_oam_tunnel_en = pkt_info->oam_tunnel_en;
    new_node->pi_rx_oam_type = pkt_info->rx_oam_type;
    new_node->pi_is_up = pkt_info->is_up;
    new_node->pi_priority = pkt_info->priority;
    new_node->pi_color = pkt_info->color;
    new_node->pi_source_port = pkt_info->source_port;
    new_node->pi_source_cos = pkt_info->source_cos;
    new_node->pi_logic_port_type = pkt_info->logic_port_type;
    new_node->pi_next_hop_ext = pkt_info->next_hop_ext;
    new_node->pi_src_svlan_id_valid = pkt_info->src_svlan_id_valid;
    new_node->pi_src_vlan_ptr = pkt_info->src_vlan_ptr;
    new_node->pi_src_cvlan_id_valid = pkt_info->src_cvlan_id_valid;
    new_node->pi_from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    new_node->pi_c_tag_action = pkt_info->ctag_action;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_discard_type = pkt_info->discard_type;
    new_node->pi_src_leaf = pkt_info->src_leaf;
    new_node->pi_packet_ttl = pkt_info->packet_ttl;
    new_node->pi_src_dscp = pkt_info->src_dscp;
    new_node->pi_packet_length_adjust_type = pkt_info->packet_length_adjust_type;
    new_node->pi_packet_length_adjust = pkt_info->packet_length_adjust;
    new_node->pi_mac_known = pkt_info->mac_known;
    new_node->pi_s_tag_action = pkt_info->stag_action;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_hard_error = 0;
    new_node->pi_source_cfi = pkt_info->source_cfi;
    new_node->pi_parser_offset = pkt_info->parser_offset;
    new_node->pi_pbb_check_discard = pkt_info->pbb_check_discard;
    new_node->pi_link_or_section_oam = pkt_info->link_or_section_oam;
    new_node->pi_gal_exist = pkt_info->gal_exist;
    new_node->pi_entropy_label_exist = pkt_info->entropy_label_exist;
    new_node->pi_acl_dscp_valid = pkt_info->acl_dscp_valid;
    new_node->pi_svlan_tpid_index = pkt_info->svlan_tpid_index;
    new_node->pi_share_type = pkt_info->share_type;
/*    new_node->pi_share_fields0 = pkt_info->share_fields_u;
    new_node->pi_share_fields1 = pkt_info->share_fields1;
    new_node->pi_share_fields2 = pkt_info->share_fields2;
    new_node->pi_share_fields3 = pkt_info->share_fields3;*/
    new_node->pi_ingress_edit_next_hop_bypass_all = pkt_info->ingress_edit_nexthop_bypass_all;
    new_node->pi_ingress_edit_en = pkt_info->ingress_edit_en;
    new_node->pi_bridge_operation = pkt_info->bridge_operation;
    new_node->pi_ptp_offset = pkt_info->ptp_offset;
    new_node->pi_from_fabric = pkt_info->from_fabric;
    new_node->pi_packet_header_en = pkt_info->packet_header_en;
    new_node->pi_packet_header_en_egress = pkt_info->packet_header_en_egress;
    new_node->pi_logic_src_port = pkt_info->logic_src_port;
    new_node->pi_packet_type = pkt_info->packet_type;


    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_HA2NH]));


    return DRV_E_NONE;
}
int32
sim_store_epe_ha2pr_bus(void *pars_info)
{
    parser_info_t * parser_info = (parser_info_t *) pars_info;
    epe_ha2pr_t *new_node;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_HA2PR))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_ha2pr_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_ha2pr_t));


    new_node->pi_layer4_type = parser_info->parser_layer4_type;
    new_node->pi_mux_length_type = parser_info->mux_length_type;
    new_node->pi_non_crc = parser_info->non_crc;
    new_node->pi_outer_vlan_is_cvlan = parser_info->outer_vlan_is_cvlan;
    new_node->pi_packet_type =  parser_info->packet_type;
    new_node->pi_port_id = parser_info->port_id;
    new_node->pi_ptp_extra_offset = parser_info->payload_offset&0x1f;
    new_node->pi_svlan_tpid_index = parser_info->svlan_tpid_index;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_HA2PR]));


    return DRV_E_NONE;
}
int32
sim_store_epe_hp2aq_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_hp2aq_t *new_node;
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_result;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_HP2AQ))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_hp2aq_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_hp2aq_t));
    new_node->pi_rx_oam_type = pkt_info->rx_oam_type;
    new_node->pi_oam_use_fid = pkt_info->oam_use_fid;
    new_node->pi_from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_discard_type = pkt_info->discard_type;
    new_node->pi_hard_error = 0;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_payload_operation = pkt_info->payload_operation;
    new_node->pi_service_acl_qos_en = pkt_info->service_acl_qos_en;
    new_node->pi_logic_dest_port = pkt_info->logic_dest_port;
    new_node->pi_l2_acl_en0 = pkt_info->l2_acl_en0;
    new_node->pi_l2_acl_en1 = pkt_info->l2_acl_en1;
    new_node->pi_l2_acl_en2 = pkt_info->l2_acl_en2;
    new_node->pi_l2_acl_en3 = pkt_info->l2_acl_en3;
    new_node->pi_l2_acl_label = pkt_info->l2_acl_label;
    new_node->pi_default_pcp = pkt_info->default_pcp;
    new_node->pi_mpls_key_use_label = pkt_info->mpls_key_use_label;
    new_node->pi_acl_port_num = pkt_info->acl_port_num;
    new_node->pi_mac_key_use_label = pkt_info->mac_key_use_label;
    new_node->pi_ipv6_key_use_label = pkt_info->ipv6_key_use_label;
    new_node->pi_l2_ipv6_acl_en0 = pkt_info->l2_ipv6_acl_en0;
    new_node->pi_l2_ipv6_acl_en1 = pkt_info->l2_ipv6_acl_en1;
    new_node->pi_force_ipv4_to_mac_key = pkt_info->force_ipv4_to_mackey;
    new_node->pi_force_ipv6_to_mac_key = pkt_info->force_ipv6_to_mackey;
    new_node->pi_l3_acl_routed_only = pkt_info->l3_acl_routed_only;
    new_node->pi_l3_acl_en0 = pkt_info->l3_acl_en0;
    new_node->pi_l3_acl_en1 = pkt_info->l3_acl_en1;
    new_node->pi_l3_acl_en2 = pkt_info->l3_acl_en2;
    new_node->pi_l3_acl_en3 = pkt_info->l3_acl_en3;
    new_node->pi_l3_acl_label = pkt_info->l3_acl_label;
    new_node->pi_l3_ipv6_acl_en0 = pkt_info->l3_ipv6_acl_en0;
    new_node->pi_l3_ipv6_acl_en1 = pkt_info->l3_ipv6_acl_en1;
    new_node->pi_interface_id = pkt_info->interface_id;
    new_node->pi_mpls_section_lm_en = pkt_info->mpls_section_lm_en;
    new_node->pi_flow_stats1_valid = pkt_info->flow_stats1_valid;
    new_node->pi_flow_stats1_ptr = pkt_info->flow_stats1_ptr;
    new_node->pi_ipv4_key_use_label = pkt_info->ipv4_key_use_label;
    new_node->pi_section_lm_exp = pkt_info->section_lm_exp;
    new_node->pi_mpls_lm_valid2 = pkt_info->mpls_lm_valid2;
    new_node->pi_mpls_lm_exp2 = pkt_info->mpls_lm_exp2;
    new_node->pi_mpls_lm_label2 = pkt_info->mpls_lm_label2;
    new_node->pi_mpls_lm_valid1 = pkt_info->mpls_lm_valid1;
    new_node->pi_mpls_lm_exp1 = pkt_info->mpls_lm_exp1;
    new_node->pi_mpls_lm_label1 = pkt_info->mpls_lm_label1;
    new_node->pi_mpls_lm_valid0 = pkt_info->mpls_lm_valid0;
    new_node->pi_mpls_lm_exp0 = pkt_info->mpls_lm_exp0;
    new_node->pi_mpls_lm_label0 = pkt_info->mpls_lm_label0;
    new_node->pi_mpls_label_space = pkt_info->mpls_label_space;
    new_node->pi_packet_length_adjust_type = pkt_info->packet_length_adjust_type;
    new_node->pi_packet_length_adjust = pkt_info->packet_length_adjust;
    new_node->pi_channel_id = inpkt->chan_id;
    new_node->pi_packet_length = pkt_info->packet_length;
    new_node->pi_color = pkt_info->color;
    new_node->pi_priority = pkt_info->priority;
    new_node->pi_service_policer_valid = pkt_info->service_policer_valid;
    new_node->pi_dest_vlan_ptr = pkt_info->dest_vlan_ptr;
    new_node->pi_port_policer_valid = pkt_info->port_policer_valid;
    new_node->pi_ipg_index = pkt_info->ipg_index;
    new_node->pi_global_dest_port = pkt_info->global_dest_port;
    new_node->pi_fid = pkt_info->fid;
    new_node->pi_oam_lookup_num = pkt_info->oam_lookup_num;
    new_node->pi_ether_lm_valid = pkt_info->ether_lm_valid;
    new_node->pi_packet_header_en = pkt_info->packet_header_en;
    new_node->pi_packet_header_en_egress = pkt_info->packet_header_en_egress;
    new_node->pi_force_ipv6_key = pkt_info->force_ipv6_key;
    new_node->pi_link_or_section_oam = pkt_info->link_or_section_oam;
    new_node->pi_oam_vlan = pkt_info->oam_vlan;
    new_node->pr_layer3_type = pas_rslt->layer3_type;
    new_node->pr_layer4_type = pas_rslt->layer4_type;
    new_node->pr_layer2_type = pas_rslt->layer2_type;
    new_node->pr_svlan_id_valid = pas_rslt->l2_s.svlan_id_valid;
    new_node->pr_cvlan_id_valid = pas_rslt->l2_s.cvlan_id_valid;
    new_node->pr_svlan_id = pas_rslt->l2_s.svlan_id;
    new_node->pr_cvlan_id = pas_rslt->l2_s.cvlan_id;
    new_node->pr_layer2_header_protocol = pas_rslt->l2_s.layer2_header_protocol;
    new_node->pr_stag_cos = pas_rslt->l2_s.stag_cos;
    new_node->pr_stag_cfi = pas_rslt->l2_s.stag_cfi;
    new_node->pr_ctag_cos = pas_rslt->l2_s.ctag_cos;
    new_node->pr_ctag_cfi = pas_rslt->l2_s.ctag_cfi;
    new_node->pr_l4_source_port = pas_rslt->l4_s.l4_src_port.l4_source_port;
    new_node->pr_l4_dest_port = pas_rslt->l4_s.l4_dst_port.l4_dest_port;
    new_node->pr_l4_info_mapped = pas_rslt->l4_s.layer4_info_mapped;
    new_node->pr_ip_da0 = pas_rslt->l3_s.ip_da.ipv6.ipda_31_0;
    new_node->pr_ip_da1 = pas_rslt->l3_s.ip_da.ipv6.ipda_63_32;
    new_node->pr_ip_da2 = pas_rslt->l3_s.ip_da.ipv6.ipda_95_64;
    new_node->pr_ip_da3 = pas_rslt->l3_s.ip_da.ipv6.ipda_127_96;
    new_node->pr_ip_sa0 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_31_0;
    new_node->pr_ip_sa1 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_63_32;
    new_node->pr_ip_sa2 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_95_64;
    new_node->pr_ip_sa3 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_127_96;
    new_node->pr_ipv6_flow_label = pas_rslt->l3_s.ipv6_flow_label;
    new_node->pr_mac_da0 = (pas_rslt->l2_s.mac_da3 << 24) | (pas_rslt->l2_s.mac_da2 << 16) | (pas_rslt->l2_s.mac_da1 << 8) | (pas_rslt->l2_s.mac_da0);
    new_node->pr_mac_da1 = (pas_rslt->l2_s.mac_da5 << 8) | (pas_rslt->l2_s.mac_da4);
    new_node->pr_mac_sa0 = (pas_rslt->l2_s.mac_sa3 << 24) | (pas_rslt->l2_s.mac_sa2 << 16) | (pas_rslt->l2_s.mac_sa1 << 8) | (pas_rslt->l2_s.mac_sa0);
    new_node->pr_mac_sa1 = (pas_rslt->l2_s.mac_sa5 << 8) | (pas_rslt->l2_s.mac_sa4);
    new_node->pr_ip_header_error = pas_rslt->l3_s.ip_header_error;
    new_node->pr_is_tcp = pas_rslt->l4_s.is_tcp;
    new_node->pr_is_udp = pas_rslt->l4_s.is_udp;
    new_node->pr_ip_options = pas_rslt->l3_s.ip_options;
    new_node->pr_frag_info = pas_rslt->l3_s.frag_info;
    new_node->pr_dscp = pas_rslt->l3_s.tos.ip_tos>>2;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_HP2AQ]));


    return DRV_E_NONE;
}
int32
sim_store_epe_hp2he_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_hp2he_t *new_node;
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_result;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_HP2HE))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_hp2he_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_hp2he_t));

new_node->pi_source_port_isolate_id = pkt_info->source_port_isolate_id;
    new_node->pi_dest_map = pkt_info->dest_map;
    new_node->pi_roaming_state = pkt_info->roaming_state;
    new_node->pi_mcast_id = pkt_info->mcast_id;
    new_node->pi_source_port = pkt_info->source_port;
    new_node->pi_next_hop_ptr = pkt_info->next_hop_ptr;
    new_node->pi_next_hop_ext = pkt_info->next_hop_ext;
    new_node->pi_congestion_valid = pkt_info->congestion_valid;
    new_node->pi_flow_stats2_valid = pkt_info->flow_stats2_valid;
    new_node->pi_flow_stats2_ptr = pkt_info->flow_stats2_ptr;
    new_node->pi_dest_mux_port_type = pkt_info->dest_mux_port_type;
    new_node->pi_port_log_en = pkt_info->port_log_en;
    new_node->pi_evb_default_local_phy_port_valid = pkt_info->evb_default_local_phy_port_valid;
    new_node->pi_evb_default_logic_port_valid = pkt_info->evb_default_logic_port_valid;
    new_node->pi_l2_span_id = pkt_info->l2_span_id;
    new_node->pi_l2_span_en = pkt_info->l2_span_en;
    new_node->pi_random_log_en = pkt_info->random_log_en;
    new_node->pi_new_itag_valid = pkt_info->new_itag_valid;
    new_node->pi_new_itag = pkt_info->new_itag;
    new_node->pi_l3_span_en = pkt_info->l3_span_en;
    new_node->pi_l3_span_id = pkt_info->l3_span_id;
    new_node->pi_mapped_cfi = pkt_info->mapped_cfi;
    new_node->pi_udp_ptp = pkt_info->udp_ptp;
    new_node->pi_ptp_offset_type = pkt_info->ptp_offset_type;
    new_node->pi_new_l4_check_sum_valid = pkt_info->new_l4_checksum_valid;
    new_node->pi_new_cos = pkt_info->new_cos;
    new_node->pi_new_cfi = pkt_info->new_cfi;
    new_node->pi_strip_offset = pkt_info->strip_offset;
    new_node->pi_new_ttl = pkt_info->new_ttl;
    new_node->pi_new_ttl_valid = pkt_info->new_ttl_valid;
    new_node->pi_new_ttl_packet_type = pkt_info->new_ttl_packet_type;
    new_node->pi_new_ip_da_valid = pkt_info->new_ip_da_valid;
    new_node->pi_new_l4_dest_port_valid = pkt_info->new_l4_dest_port_valid;
    new_node->pi_new_l4_dest_port = pkt_info->new_l4_dest_port;
    new_node->pi_loopback_en = pkt_info->loopback_en;
    new_node->pi_i_tag_offset_type = pkt_info->itag_offset_type;
    new_node->pi_new_mac_da_valid = pkt_info->new_macda_valid;
    new_node->pi_new_mac_da0 = pkt_info->new_macda_lower32;
    new_node->pi_new_mac_da1 = pkt_info->new_macda_upper16;
    new_node->pi_new_mac_sa_valid = pkt_info->new_macsa_valid;
    new_node->pi_new_mac_sa0 = pkt_info->new_macsa_lower32;
    new_node->pi_new_mac_sa1 = pkt_info->new_macsa_upper16;
    new_node->pi_new_ip_da = pkt_info->new_ip_da;
    new_node->pi_new_l4_check_sum = pkt_info->new_l4_check_sum;
    new_node->pi_l2_new_hdr_len = pkt_info->l2_new_header_len;
    new_node->pi_l3_new_hdr_len = pkt_info->l3_new_header_len;
    new_node->pi_source_port_extender = pkt_info->source_port_extender;
    new_node->pi_logic_dest_port = pkt_info->logic_dest_port;
    new_node->pi_use_logic_port = pkt_info->use_logic_port;
    new_node->pi_frag_info = IS_BIT_SET(pkt_info->frag_info,1);
    new_node->pi_dest_channel_link_aggregate_en = pkt_info->dest_channel_link_aggregate_en;
    new_node->pi_source_channel_link_aggregate_en = pkt_info->source_channel_link_aggregate_en;
    new_node->pi_dest_channel_link_aggregate = pkt_info->dest_channel_link_aggregate;
    new_node->pi_source_channel_link_aggregate = pkt_info->source_channel_link_aggregate;
    new_node->pr_layer4_check_sum = pas_rslt->l4_s.layer4_check_sum;
    new_node->pi_svlan_tag_operation = pkt_info->svlan_tag_operation;
    new_node->pi_l2_new_svlan_tag = pkt_info->l2_new_svlan_tag;
    new_node->pi_cvlan_tag_operation = pkt_info->cvlan_tag_operation;
    new_node->pi_l2_new_cvlan_tag = pkt_info->l2_new_cvlan_tag;
    new_node->pi_cvlan_id_offset_type = pkt_info->cvlan_id_offset_type;
    new_node->pi_new_ip_check_sum_valid = pkt_info->new_ip_check_sum_valid;
    new_node->pi_new_ip_check_sum = pkt_info->new_ip_check_sum;
    new_node->pi_new_dscp_valid = pkt_info->new_dscp_valid;
    new_node->pi_new_dscp = pkt_info->new_dscp;
    new_node->pi_port_loopback_index = pkt_info->port_loopback_index;
    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_HP2HE]));


    return DRV_E_NONE;
}
int32
sim_store_epe_hp2om_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_hp2om_t *new_node;
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_result;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_HP2OM))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_hp2om_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_hp2om_t));
    new_node->pi_share_type = pkt_info->share_type;
    //new_node->pi_share_fields0 = pkt_info->share_fields0;
    //new_node->pi_share_fields1 = pkt_info->share_fields1;
    //new_node->pi_share_fields2 = pkt_info->share_fields2;
    //new_node->pi_share_fields3 = pkt_info->share_fields3;
    new_node->pi_ether_oam_edge_port = pkt_info->ether_oam_edge_port;
    new_node->pi_l2_match = pkt_info->l2_match;
    new_node->pi_exception_en = pkt_info->exception_en;
    new_node->pi_exception_index = pkt_info->exception_index;
    new_node->pi_ether_oam_discard = pkt_info->ether_oam_discard;
    new_node->pi_is_port_mac = pkt_info->is_port_mac;
    new_node->pi_layer3_offset = pkt_info->layer3_offset;
    new_node->pi_layer4_offset = pkt_info->layer4_offset;
    new_node->pi_logic_src_port = pkt_info->logic_src_port;
    new_node->pi_link_lm_type = pkt_info->link_lm_type;
    new_node->pi_link_lm_index_base = pkt_info->link_lm_index_base;
    new_node->pi_link_lm_cos_type = pkt_info->link_lm_cos_type;
    new_node->pi_link_lm_cos = pkt_info->link_lm_cos;
    new_node->pi_is_up = pkt_info->is_up;
    new_node->pi_gal_exist = pkt_info->gal_exist;
    new_node->pi_entropy_label_exist = pkt_info->entropy_label_exist;
    new_node->pi_link_or_section_oam = pkt_info->link_or_section_oam;
    new_node->pi_from_cpu_lm_up_disable = pkt_info->from_cpu_lm_up_disable;
    new_node->pi_from_cpu_lm_down_disable = pkt_info->from_cpu_lm_down_disable;
    new_node->pr_layer4_user_type = pas_rslt->l4_s.layer4_user_type;
    new_node->pr_ether_oam_level = pas_rslt->l3_s.ip_da.eth_oam.eth_oam_level;
    new_node->pr_ether_oam_op_code = pas_rslt->l3_s.ip_da.eth_oam.eth_oam_op_code;
    new_node->pr_y1731_oam_op_code = pas_rslt->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code;
    new_node->pr_tx_fcf = pas_rslt->l3_s.ip_sa.eth_oam.tx_fcf;
    new_node->pr_rx_fcb = pas_rslt->l3_s.ip_sa.eth_oam.rx_fcb;
    new_node->pr_tx_fcb = pas_rslt->l3_s.ip_sa.eth_oam.tx_fcb;


    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_HP2OM]));


    return DRV_E_NONE;
}
int32
sim_store_epe_nh2hp_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_nh2hp_t *new_node;
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_result;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_NH2HP))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_nh2hp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_nh2hp_t));

new_node->pi_hard_error = 0;
    new_node->pi_source_port_isolate_id = pkt_info->source_port_isolate_id;
    new_node->pi_dest_map = pkt_info->dest_map;
    new_node->pi_rx_oam_type = pkt_info->rx_oam_type;
    new_node->pi_priority = pkt_info->priority;
    new_node->pi_color = pkt_info->color;
    new_node->pi_source_port = pkt_info->source_port;
    new_node->pi_source_cos = pkt_info->source_cos;
    new_node->pi_logic_port_type = pkt_info->logic_port_type;
    new_node->pi_next_hop_ext = pkt_info->next_hop_ext;
    new_node->pi_from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    new_node->pi_c_tag_action = pkt_info->ctag_action;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_discard_type = pkt_info->discard_type;
    new_node->pi_src_leaf = pkt_info->src_leaf;
    new_node->pi_packet_ttl = pkt_info->packet_ttl;
    new_node->pi_src_dscp = pkt_info->src_dscp;
    new_node->pi_packet_length_adjust_type = pkt_info->packet_length_adjust_type;
    new_node->pi_packet_length_adjust = pkt_info->packet_length_adjust;
    new_node->pi_s_tag_action = pkt_info->stag_action;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_payload_operation = pkt_info->payload_operation;
    new_node->pi_vlan_xlate_mode = pkt_info->vlan_xlate_mode;
    new_node->pi_svlan_tag_disable = pkt_info->svlan_tag_disable;
    new_node->pi_cvlan_tag_disable = pkt_info->cvlan_tag_disable;
    new_node->pi_mac0 = pkt_info->mac_31_to_0;
    new_node->pi_mac1 = pkt_info->mac_47_to_32;
    new_node->pi_route_no_l2_edit = pkt_info->route_no_l2_edit;
    new_node->pi_copy_dscp = pkt_info->copy_dscp;
    new_node->pi_replace_dscp = pkt_info->replace_dscp;
    new_node->pi_service_policer_valid = pkt_info->service_policer_valid;
    new_node->pi_dest_vlan_ptr = pkt_info->dest_vlan_ptr;
    new_node->pi_mirror_tag_add = pkt_info->mirror_tag_add;
    new_node->pi_service_acl_qos_en = pkt_info->service_acl_qos_en;
    new_node->pi_svlan_tagged = pkt_info->svlan_tagged;
    new_node->pi_stag_cfi = pkt_info->stag_cfi;
    new_node->pi_copy_ctag_cos = pkt_info->copy_ctag_cos;
    new_node->pi_stag_cos = pkt_info->stag_cos;
    new_node->pi_replace_ctag_cos = pkt_info->replace_ctag_cos;
    new_node->pi_tagged_mode = pkt_info->tagged_mode;
    new_node->pi_tpid_swap = pkt_info->tpid_swap;
    new_node->pi_cos_swap = pkt_info->cos_swap;
    new_node->pi_derive_stag_cos = pkt_info->derive_stag_cos;
    new_node->pi_replace_stag_cos = pkt_info->replace_stag_cos;
    new_node->pi_inner_svlan_tpid_index = pkt_info->inner_svlan_tpid_index;
    new_node->pi_inner_svlan_tpid_en = pkt_info->inner_svlan_tpid_en;
    new_node->pi_logic_port_check = pkt_info->logic_port_check;
    new_node->pi_logic_dest_port = pkt_info->logic_dest_port;
    new_node->pi_output_svlan_id = pkt_info->output_svlan_id;
    new_node->pi_output_svlan_id_valid = pkt_info->output_svlan_id_valid;
    new_node->pi_output_cvlan_id = pkt_info->output_cvlan_id;
    new_node->pi_output_cvlan_id_valid = pkt_info->output_cvlan_id_valid;
    new_node->pi_dest_mux_port_type = pkt_info->dest_mux_port_type;
    new_node->pi_port_log_en = pkt_info->port_log_en;
    new_node->pi_svlan_tpid_index = pkt_info->svlan_tpid_index;
    new_node->pi_evb_default_local_phy_port_valid = pkt_info->evb_default_local_phy_port_valid;
    new_node->pi_l2_span_id = pkt_info->l2_span_id;
    new_node->pi_l2_span_en = pkt_info->l2_span_en;
    new_node->pi_global_dest_port = pkt_info->global_dest_port;
    new_node->pi_random_log_en = pkt_info->random_log_en;
    new_node->pi_untag_default_vlan_id = pkt_info->untag_default_vlan_id;
    new_node->pi_port_policer_valid = pkt_info->port_policer_valid;
    new_node->pi_l2_acl_en0 = pkt_info->l2_acl_en0;
    new_node->pi_l2_acl_en1 = pkt_info->l2_acl_en1;
    new_node->pi_l2_acl_en2 = pkt_info->l2_acl_en2;
    new_node->pi_l2_acl_en3 = pkt_info->l2_acl_en3;
    new_node->pi_untag_default_svlan = pkt_info->untag_default_svlan;
    new_node->pi_bridge_en = pkt_info->bridge_en;
    new_node->pi_dot1_q_en = pkt_info->dot1_q_en;
    new_node->pi_ipg_index = pkt_info->ipg_index;
    new_node->pi_port_mac_sa = pkt_info->port_mac_sa;
    new_node->pi_l2_acl_label = pkt_info->l2_acl_label;
    new_node->pi_fcoe_oui_index = pkt_info->fcoe_oui_index;
    new_node->pi_ctag_dei_en = pkt_info->ctag_dei_en;
    new_node->pi_port_mac_sa_type = pkt_info->port_mac_sa_type;
    new_node->pi_ether_oam_edge_port = pkt_info->ether_oam_edge_port;
    new_node->pi_default_pcp = pkt_info->default_pcp;
    new_node->pi_stag_operation_disable = pkt_info->stag_operation_disable;
    new_node->pi_ctag_operation_disable = pkt_info->ctag_operation_disable;
    new_node->pi_mpls_key_use_label = pkt_info->mpls_key_use_label;
    new_node->pi_acl_port_num = pkt_info->acl_port_num;
    new_node->pi_mac_key_use_label = pkt_info->mac_key_use_label;
    new_node->pi_ipv4_key_use_label = pkt_info->ipv4_key_use_label;
    new_node->pi_ipv6_key_use_label = pkt_info->ipv6_key_use_label;
    new_node->pi_l2_ipv6_acl_en0 = pkt_info->l2_ipv6_acl_en0;
    new_node->pi_l2_ipv6_acl_en1 = pkt_info->l2_ipv6_acl_en1;
    new_node->pi_force_ipv4_to_mac_key = pkt_info->force_ipv4_to_mackey;
    new_node->pi_force_ipv6_to_mac_key = pkt_info->force_ipv6_to_mackey;
    new_node->pi_svlan_xlate_valid = pkt_info->svlan_xlate_valid;
    new_node->pi_cvlan_xlate_valid = pkt_info->cvlan_xlate_valid;
    new_node->pi_xlate_svlan_tpid_en = pkt_info->xlate_svlan_tpid_index_en;
    new_node->pi_xlate_svlan_tpid_index = pkt_info->xlate_svlan_tpid_index;
    new_node->pi_ctag_add_mode = pkt_info->ctag_add_mode;
    new_node->pi_new_itag_valid = pkt_info->new_itag_valid;
    new_node->pi_new_itag = pkt_info->new_itag;
    new_node->pi_s_vlan_id_action = pkt_info->svlan_id_action;
    new_node->pi_c_vlan_id_action = pkt_info->cvlan_id_action;
    new_node->pi_s_cos_action = pkt_info->stag_cos_action;
    new_node->pi_c_cos_action = pkt_info->ctag_cos_action;
    new_node->pi_s_cfi_action = pkt_info->s_cfi_action;
    new_node->pi_c_cfi_action = pkt_info->c_cfi_action;
    new_node->pi_xlate_svlan_id = pkt_info->xlate_svlan_id;
    new_node->pi_xlate_stag_cos = pkt_info->xlate_stag_cos;
    new_node->pi_xlate_stag_cfi = pkt_info->xlate_stag_cfi;
    new_node->pi_xlate_cvlan_id = pkt_info->xlate_cvlan_id;
    new_node->pi_xlate_ctag_cos = pkt_info->xlate_ctag_cos;
    new_node->pi_xlate_ctag_cfi = pkt_info->xlate_ctag_cfi;
    new_node->pi_l3_acl_routed_only = pkt_info->l3_acl_routed_only;
    new_node->pi_l3_acl_en0 = pkt_info->l3_acl_en0;
    new_node->pi_l3_acl_en1 = pkt_info->l3_acl_en1;
    new_node->pi_l3_acl_en2 = pkt_info->l3_acl_en2;
    new_node->pi_l3_acl_en3 = pkt_info->l3_acl_en3;
    new_node->pi_l3_span_en = pkt_info->l3_span_en;
    new_node->pi_l3_span_id = pkt_info->l3_span_id;
    new_node->pi_l3_acl_label = pkt_info->l3_acl_label;
    new_node->pi_l3_ipv6_acl_en0 = pkt_info->l3_ipv6_acl_en0;
    new_node->pi_l3_ipv6_acl_en1 = pkt_info->l3_ipv6_acl_en1;
    new_node->pi_interface_id = pkt_info->interface_id;
    new_node->pi_interface_vlan_id_en = pkt_info->interface_vlan_id_en;
    new_node->pi_mtu_exception_en = pkt_info->mtu_exception_en;
    new_node->pi_mcast_ttl_threshold = pkt_info->mcast_ttl_threshold;
    new_node->pi_mac_sa_type = pkt_info->mac_sa_type;
    new_node->pi_mac_sa = pkt_info->mac_sa;
    new_node->pi_mpls_section_lm_en = pkt_info->mpls_section_lm_en;
    new_node->pi_interface_svlan_tagged = pkt_info->interface_svlan_tagged;
    new_node->pi_interface_vlan_id = pkt_info->interface_vlan_id;
    new_node->pi_mcast = pkt_info->mcast;
    new_node->pi_l3_edit_ptr_bit0 = pkt_info->l3_edit_ptr_bit0;
    new_node->pi_l2_edit_ptr_bit0 = pkt_info->l2_edit_ptr_bit0;
    new_node->pi_mapped_dscp = pkt_info->mapped_dscp;
    new_node->pi_mapped_cos = pkt_info->mapped_cos;
    new_node->pi_mapped_exp = pkt_info->mapped_exp;
    new_node->pi_mapped_cfi = pkt_info->mapped_cfi;
    new_node->pi_l2_match = pkt_info->l2_match;
    new_node->pi_port_reflective_discard = pkt_info->port_reflective_discard;
    new_node->pi_ptp_offset = pkt_info->ptp_offset;
    new_node->pi_udp_ptp = pkt_info->udp_ptp;
    new_node->pi_exception_en = pkt_info->exception_en;
    new_node->pi_exception_index = pkt_info->exception_index;
    new_node->pi_ether_oam_discard = pkt_info->ether_oam_discard;
    new_node->pi_default_vlan_id = pkt_info->default_vlan_id;
    new_node->pi_priority_tag_en = pkt_info->priority_tag_en;
    new_node->pi_tunnel_mtu_check = pkt_info->tunnel_mtu_check;
    new_node->pi_tunnel_mtu_size = pkt_info->tunnel_mtu_size;
    new_node->pi_link_lm_cos = pkt_info->link_lm_cos;
    new_node->pi_mpls_label_space = pkt_info->mpls_label_space;
    new_node->pi_ptp_offset_type = pkt_info->ptp_offset_type;
    new_node->pi_new_l4_check_sum_valid = pkt_info->new_l4_checksum_valid;
    new_node->pi_new_l4_check_sum = pkt_info->new_l4_check_sum;
    new_node->pi_ds_l3_edit_exist = pkt_info->ds_l3_edit_exist;
    new_node->pi_ds_l2_edit_exist = pkt_info->ds_l2_edit_exist;
    new_node->pi_channel_id = inpkt->chan_id;
    new_node->pi_flow_stats2_valid = pkt_info->flow_stats2_valid;
    new_node->pi_flow_stats2_ptr = pkt_info->flow_stats2_ptr;
    new_node->pi_source_cfi = pkt_info->source_cfi;
    new_node->pi_evb_default_logic_port_valid = pkt_info->evb_default_logic_port_valid;
    new_node->pi_link_lm_type = pkt_info->link_lm_type;
    new_node->pi_link_lm_cos_type = pkt_info->link_lm_cos_type;
    new_node->pi_link_lm_index_base = pkt_info->link_lm_index_base;
    new_node->pi_i_tag_offset_type = pkt_info->itag_offset_type;
    new_node->pi_mtu_check_en = pkt_info->mtu_check_en;
    new_node->pi_ether_lm_valid = pkt_info->ether_lm_valid;
    new_node->pi_use_logic_port = pkt_info->use_logic_port;
    new_node->pi_mtu_size = pkt_info->mtu_size;
    new_node->pi_gal_exist = pkt_info->gal_exist;
    new_node->pi_entropy_label_exist = pkt_info->entropy_label_exist;
    new_node->pi_ttl_no_decrease = pkt_info->ttl_no_decrease;
    new_node->pi_mac_da_mcast_mode = pkt_info->mac_da_mcast_mode;
    new_node->pi_cvlan_space = pkt_info->cvlan_space;
    new_node->pi_force_ipv6_key = pkt_info->force_ipv6_key;
    new_node->pi_bypass_all = pkt_info->bypass_all;
    new_node->pi_link_or_section_oam = pkt_info->link_or_section_oam;
    new_node->pi_is_up = pkt_info->is_up;
    new_node->pi_acl_dscp_valid = pkt_info->acl_dscp_valid;
    new_node->pi_ingress_edit_en = pkt_info->ingress_edit_en;
    new_node->pi_from_fabric = pkt_info->from_fabric;
    new_node->pi_packet_header_en = pkt_info->packet_header_en;
    new_node->pi_packet_header_en_egress = pkt_info->packet_header_en_egress;
    new_node->pi_logic_src_port = pkt_info->logic_src_port;
    new_node->pi_port_loopback_index = pkt_info->port_loopback_index;
    new_node->pi_share_type = pkt_info->share_type;
    new_node->pi_bridge_operation = pkt_info->bridge_operation;
/*    new_node->pi_share_fields0 = pkt_info->share_fields0;
    new_node->pi_share_fields1 = pkt_info->share_fields1;
    new_node->pi_share_fields2 = pkt_info->share_fields2;
    new_node->pi_share_fields3 = pkt_info->share_fields3;*/
    new_node->pi_packet_type = pkt_info->packet_type;
    new_node->pi_ds_next_hop_dot_bypass = pkt_info->ds_nexthop_dot_bypass_all;
    new_node->pr_layer2_type = pas_rslt->layer2_type;
    new_node->pr_mac_da0 = (pas_rslt->l2_s.mac_da3 << 24) | (pas_rslt->l2_s.mac_da2 << 16) | (pas_rslt->l2_s.mac_da1 << 8) | (pas_rslt->l2_s.mac_da0);
    new_node->pr_mac_da1 = (pas_rslt->l2_s.mac_da5 << 8) | (pas_rslt->l2_s.mac_da4);
    new_node->pr_mac_sa0 = (pas_rslt->l2_s.mac_sa3 << 24) | (pas_rslt->l2_s.mac_sa2 << 16) | (pas_rslt->l2_s.mac_sa1 << 8) | (pas_rslt->l2_s.mac_sa0);
    new_node->pr_mac_sa1 = (pas_rslt->l2_s.mac_sa5 << 8) | (pas_rslt->l2_s.mac_sa4);
    new_node->pr_svlan_id_valid = pas_rslt->l2_s.svlan_id_valid;
    new_node->pr_cvlan_id_valid = pas_rslt->l2_s.cvlan_id_valid;
    new_node->pr_svlan_id = pas_rslt->l2_s.svlan_id;
    new_node->pr_cvlan_id = pas_rslt->l2_s.cvlan_id;
    new_node->pr_stag_cos = pas_rslt->l2_s.stag_cos;
    new_node->pr_ctag_cos = pas_rslt->l2_s.ctag_cos;
    new_node->pr_stag_cfi = pas_rslt->l2_s.stag_cfi;
    new_node->pr_ctag_cfi = pas_rslt->l2_s.ctag_cfi;
    new_node->pr_layer3_offset = pas_rslt->l2_s.layer3_offset;
    new_node->pr_layer3_type = pas_rslt->layer3_type;
    new_node->pr_ip_da0 = pas_rslt->l3_s.ip_da.ipv6.ipda_31_0;
    new_node->pr_ip_da1 = pas_rslt->l3_s.ip_da.ipv6.ipda_63_32;
    new_node->pr_ip_da2 = pas_rslt->l3_s.ip_da.ipv6.ipda_95_64;
    new_node->pr_ip_da3 = pas_rslt->l3_s.ip_da.ipv6.ipda_127_96;
    new_node->pr_ip_sa0 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_31_0;
    new_node->pr_ip_sa1 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_63_32;
    new_node->pr_ip_sa2 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_95_64;
    new_node->pr_ip_sa3 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_127_96;
    new_node->pr_tos = pas_rslt->l3_s.tos.ip_tos;
    new_node->pr_ttl = pas_rslt->l3_s.ttl;
    new_node->pr_layer4_offset = pas_rslt->l3_s.layer4_offset;
    new_node->pr_y1731_oam_op_code = pas_rslt->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code;
    new_node->pr_layer4_type = pas_rslt->layer4_type;
    new_node->pr_layer4_user_type = pas_rslt->l4_s.layer4_user_type;
    new_node->pr_layer4_check_sum = pas_rslt->l4_s.layer4_check_sum;


    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_NH2HP]));


    return DRV_E_NONE;
}
int32
sim_store_epe_om2he_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_om2he_t *new_node;
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_result;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_OM2HE))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_om2he_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_om2he_t));

    new_node->pi_share_type = pkt_info->share_type;
    //new_node->pi_share_fields0 = pkt_info->share_fields0;
    //new_node->pi_share_fields1 = pkt_info->share_fields1;
    //new_node->pi_share_fields2 = pkt_info->share_fields2;
    //new_node->pi_share_fields3 = pkt_info->share_fields3;
    new_node->pi_logic_src_port = pkt_info->logic_src_port;
    new_node->pi_fid = pkt_info->fid;
    new_node->pi_priority = pkt_info->priority;
    new_node->pi_color = pkt_info->color;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_discard_type = pkt_info->discard_type;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_global_dest_port = pkt_info->global_dest_port;
    new_node->pi_exception_en = pkt_info->exception_en;
    new_node->pi_exception_index = pkt_info->exception_index;
    new_node->pi_flow_stats1_valid = pkt_info->flow_stats1_valid;
    new_node->pi_flow_stats1_ptr = pkt_info->flow_stats1_ptr;
    new_node->pi_is_tcp = pkt_info->is_tcp;
    new_node->pi_layer3_offset = pas_rslt->l2_s.layer3_offset;
    new_node->pi_layer4_offset = pas_rslt->l3_s.layer4_offset;
    new_node->pi_flow_stats0_valid = pkt_info->flow_stats0_valid;
    new_node->pi_flow_stats0_ptr = pkt_info->flow_stats0_ptr;
    new_node->pi_acl_log_en0 = pkt_info->acl_log_en0;
    new_node->pi_acl_log_id0 = pkt_info->acl_log_id0;
    new_node->pi_acl_log_en1 = pkt_info->acl_log_en1;
    new_node->pi_acl_log_id1 = pkt_info->acl_log_id1;
    new_node->pi_acl_log_en2 = pkt_info->acl_log_en2;
    new_node->pi_acl_log_id2 = pkt_info->acl_log_id2;
    new_node->pi_acl_log_en3 = pkt_info->acl_log_en3;
    new_node->pi_acl_log_id3 = pkt_info->acl_log_id3;
    new_node->pi_hard_error = 0;
    new_node->pi_is_udp = pkt_info->is_udp;
    new_node->pi_from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    new_node->pi_packet_header_en = pkt_info->packet_header_en;
    new_node->pi_packet_header_en_egress = pkt_info->packet_header_en_egress;
    new_node->pi_packet_length = pkt_info->packet_length;
    new_node->pi_dest_vlan_ptr = pkt_info->dest_vlan_ptr;
    new_node->pi_channel_id = inpkt->chan_id;
    new_node->pi_from_cpu_lm_up_disable = pkt_info->from_cpu_lm_up_disable;
    new_node->pi_from_cpu_lm_down_disable = pkt_info->from_cpu_lm_down_disable;
    new_node->pi_is_up = pkt_info->is_up;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_OM2HE]));


    return DRV_E_NONE;
}
int32
sim_store_epe_pr2hp_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_pr2hp_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_result;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_PR2HP))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(epe_pr2hp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_pr2hp_t));


    new_node->pr_parser_length_error = pas_rslt->parser_length_error;
    new_node->pr_layer2_type = pas_rslt->layer2_type;
    new_node->pr_mac_da0 = (pas_rslt->l2_s.mac_da3 << 24) | (pas_rslt->l2_s.mac_da2 << 16) | (pas_rslt->l2_s.mac_da1 << 8) | (pas_rslt->l2_s.mac_da0);
    new_node->pr_mac_da1 = (pas_rslt->l2_s.mac_da5 << 8) | (pas_rslt->l2_s.mac_da4);
    new_node->pr_mac_sa0 = (pas_rslt->l2_s.mac_sa3 << 24) | (pas_rslt->l2_s.mac_sa2 << 16) | (pas_rslt->l2_s.mac_sa1 << 8) | (pas_rslt->l2_s.mac_sa0);
    new_node->pr_mac_sa1 = (pas_rslt->l2_s.mac_sa5 << 8) | (pas_rslt->l2_s.mac_sa4);
    new_node->pr_svlan_id_valid = pas_rslt->l2_s.svlan_id_valid;
    new_node->pr_cvlan_id_valid = pas_rslt->l2_s.cvlan_id_valid;
    new_node->pr_svlan_id = pas_rslt->l2_s.svlan_id;
    new_node->pr_cvlan_id = pas_rslt->l2_s.cvlan_id;
    new_node->pr_stag_cos = pas_rslt->l2_s.stag_cos;
    new_node->pr_ctag_cos = pas_rslt->l2_s.ctag_cos;
    new_node->pr_stag_cfi = pas_rslt->l2_s.stag_cfi;
    new_node->pr_ctag_cfi = pas_rslt->l2_s.ctag_cfi;
    new_node->pr_layer2_header_protocol = pas_rslt->l2_s.layer2_header_protocol;
    new_node->pr_layer3_offset = pas_rslt->l2_s.layer3_offset;
    new_node->pr_layer3_type = pas_rslt->layer3_type;
    new_node->pr_ip_da0 = pas_rslt->l3_s.ip_da.ipv6.ipda_31_0;
    new_node->pr_ip_da1 = pas_rslt->l3_s.ip_da.ipv6.ipda_63_32;
    new_node->pr_ip_da2 = pas_rslt->l3_s.ip_da.ipv6.ipda_95_64;
    new_node->pr_ip_da3 = pas_rslt->l3_s.ip_da.ipv6.ipda_127_96;
    new_node->pr_ip_sa0 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_31_0;
    new_node->pr_ip_sa1 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_63_32;
    new_node->pr_ip_sa2 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_95_64;
    new_node->pr_ip_sa3 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_127_96;
    new_node->pr_tos = pas_rslt->l3_s.tos.ip_tos;
    new_node->pr_ttl = pas_rslt->l3_s.ttl;
    new_node->pr_ipv6_flow_label = pas_rslt->l3_s.ipv6_flow_label;
    new_node->pr_ip_header_error = pas_rslt->l3_s.ip_header_error;
    new_node->pr_ip_options = pas_rslt->l3_s.ip_options;
    new_node->pr_dont_frag = pas_rslt->l3_s.dont_frag;
    new_node->pr_frag_info = pas_rslt->l3_s.frag_info;
    new_node->pr_layer4_offset = pas_rslt->l3_s.layer4_offset;
    new_node->pr_layer4_type = pas_rslt->layer4_type;
    new_node->pr_is_tcp = pas_rslt->l4_s.is_tcp;
    new_node->pr_is_udp = pas_rslt->l4_s.is_udp;
    new_node->pr_layer4_info_mapped = pas_rslt->l4_s.layer4_info_mapped;
    new_node->pr_l4_source_port = pas_rslt->l4_s.l4_src_port.l4_source_port;
    new_node->pr_l4_dest_port = pas_rslt->l4_s.l4_dst_port.l4_dest_port;
    new_node->pr_layer4_check_sum = pas_rslt->l4_s.layer4_check_sum;
    new_node->pr_is_isatap_interface = pas_rslt->l4_s.isatap_ptp_ver.is_isatap_interface;
    new_node->pr_layer4_user_type = pas_rslt->l4_s.layer4_user_type;
    new_node->pr_rid = pas_rslt->l4_s.rid_ptp_bfd.rid_t.rid;
    new_node->pr_gre_key = pas_rslt->l4_s.gre_bfd_ptp.gre_key;
    new_node->pr_udp_ptp_correction_field = pas_rslt->l4_s.ptp_oam_ach.udp_ptp_correction_field_63_32;
    new_node->pr_udp_ptp_timestamp0 = pas_rslt->l4_s.udp_ptp_timestamp_31_to_0;
    new_node->pr_udp_ptp_timestamp1 = pas_rslt->l4_s.udp_ptp_timestamp_63_to_32;
    new_node->pr_layer3_header_protocol = pas_rslt->l3_s.layer3_header_protocol;
    new_node->pr_ip_identification = pas_rslt->l3_s.ip_identification;
    new_node->pr_more_frag = pas_rslt->l3_s.more_frag;
    new_node->pr_frag_offset = pas_rslt->l3_s.frag_offset;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_PR2HP]));

    return DRV_E_NONE;
}

int32 sim_store_epe_ha2nh_sharelm_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharelm_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_HA2NH_LM_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharelm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharelm_t));

    new_node->pi_lm_packet_type = pkt_info->share_fields_u.lmtx.lm_packet_type;
    new_node->pi_tx_fcb = pkt_info->share_fields_u.lmtx.tx_fcb;
    new_node->pi_rx_fcb_lm = pkt_info->share_fields_u.lmtx.rx_fcb;
    new_node->pi_rx_tx_fcl_lm = pkt_info->share_fields_u.lmtx.rxtx_fcl;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_LM_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_ha2nh_sharenat_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharenat_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_HA2NH_NAT_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharenat_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharenat_t));

    new_node->pi_new_ip_sa0 = pkt_info->share_fields_u.nat.new_ip_sa_31_0;
    new_node->pi_new_ip_sa1 = pkt_info->share_fields_u.nat.new_ip_sa_39_32;
    new_node->pi_new_l4_source_port = pkt_info->share_fields_u.nat.new_l4_source_port;
    new_node->pi_new_ip_sa_valid = pkt_info->share_fields_u.nat.new_ip_sa_valid;
    new_node->pi_new_l4_source_port_valid = pkt_info->share_fields_u.nat.new_l4_source_port_valid;
    new_node->pi_pt_enable = pkt_info->share_fields_u.nat.pt_enable;
    new_node->pi_ipv4_src_embeded_mode = pkt_info->share_fields_u.nat.ipv4_src_embeded_mode;
    new_node->pi_ip_sa_mode = pkt_info->share_fields_u.nat.ip_sa_mode;
    new_node->pi_src_address_mode = pkt_info->share_fields_u.nat.src_address_mode;
    new_node->pi_ip_sa_prefix_length = pkt_info->share_fields_u.nat.ip_sa_prefix_length;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_NAT_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_ha2nh_shareoam_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_shareoam_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_HA2NH_OAM_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_shareoam_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_shareoam_t));

    new_node->pi_gal_exist = pkt_info->share_fields_u.oam.gal_exist;
    new_node->pi_entropy_label_exist = pkt_info->share_fields_u.oam.entropy_label_exist;
    new_node->pi_oam_dest_chip_id = pkt_info->share_fields_u.oam.oam_dest_chip_id;
    new_node->pi_mep_index = pkt_info->share_fields_u.oam.mep_index;
    new_node->pi_rx_oam_type = pkt_info->share_fields_u.oam.rx_oam_type;
    new_node->pi_mip_en = pkt_info->share_fields_u.oam.mip_en;
    new_node->pi_link_or_section_oam = pkt_info->share_fields_u.oam.link_or_section_oam;
    new_node->pi_lm_received_packet = pkt_info->share_fields_u.oam.lm_received_packet;
    new_node->pi_dm_en = pkt_info->share_fields_u.oam.dm_en;
    new_node->pi_rx_fcb_oam = pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32;
    new_node->pi_rx_tx_fcl_oam = pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_OAM_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_ha2nh_shareptp_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_shareptp_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_HA2NH_PTP_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_shareptp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_shareptp_t));

    new_node->pi_ptp_edit_type = pkt_info->share_fields_u.ptp.ptp_edit_type;
    new_node->pi_ptp_sequence_id = pkt_info->share_fields_u.ptp.ptp_sequence_id;
    new_node->pi_ptp_extra_offset = pkt_info->share_fields_u.ptp.ptp_extra_offset;
    new_node->pi_time_stamp_ptp0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;
    new_node->pi_time_stamp_ptp1 = pkt_info->share_fields_u.ptp.time_stamp_61_32;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_PTP_BUS]));

    return DRV_E_NONE;
}
int32 sim_store_epe_ha2nh_sharedm_bus(void *in_pkt)
{
#if 0
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharedm_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_HA2NH_DMTX_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharedm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharedm_t));

    new_node->pi_dm_offset = pkt_info->share_fields_u.dmtx.dm_offset;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_DMTX_BUS]));
#endif
    return DRV_E_NONE;
}

int32 sim_store_epe_hp2oam_sharelm_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharelm_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_HP2OM_LM_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharelm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharelm_t));

    new_node->pi_lm_packet_type = pkt_info->share_fields_u.lmtx.lm_packet_type;
    new_node->pi_tx_fcb = pkt_info->share_fields_u.lmtx.tx_fcb;
    new_node->pi_rx_fcb_lm = pkt_info->share_fields_u.lmtx.rx_fcb;
    new_node->pi_rx_tx_fcl_lm = pkt_info->share_fields_u.lmtx.rxtx_fcl;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_LM_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_hp2oam_sharenat_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharenat_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_HP2OM_NAT_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharenat_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharenat_t));

    new_node->pi_new_ip_sa0 = pkt_info->share_fields_u.nat.new_ip_sa_31_0;
    new_node->pi_new_ip_sa1 = pkt_info->share_fields_u.nat.new_ip_sa_39_32;
    new_node->pi_new_l4_source_port = pkt_info->share_fields_u.nat.new_l4_source_port;
    new_node->pi_new_ip_sa_valid = pkt_info->share_fields_u.nat.new_ip_sa_valid;
    new_node->pi_new_l4_source_port_valid = pkt_info->share_fields_u.nat.new_l4_source_port_valid;
    new_node->pi_pt_enable = pkt_info->share_fields_u.nat.pt_enable;
    new_node->pi_ipv4_src_embeded_mode = pkt_info->share_fields_u.nat.ipv4_src_embeded_mode;
    new_node->pi_ip_sa_mode = pkt_info->share_fields_u.nat.ip_sa_mode;
    new_node->pi_src_address_mode = pkt_info->share_fields_u.nat.src_address_mode;
    new_node->pi_ip_sa_prefix_length = pkt_info->share_fields_u.nat.ip_sa_prefix_length;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_NAT_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_hp2oam_shareoam_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_shareoam_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_HP2OM_OAM_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_shareoam_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_shareoam_t));

    new_node->pi_gal_exist = pkt_info->share_fields_u.oam.gal_exist;
    new_node->pi_entropy_label_exist = pkt_info->share_fields_u.oam.entropy_label_exist;
    new_node->pi_oam_dest_chip_id = pkt_info->share_fields_u.oam.oam_dest_chip_id;
    new_node->pi_mep_index = pkt_info->share_fields_u.oam.mep_index;
    new_node->pi_rx_oam_type = pkt_info->share_fields_u.oam.rx_oam_type;
    new_node->pi_mip_en = pkt_info->share_fields_u.oam.mip_en;
    new_node->pi_link_or_section_oam = pkt_info->share_fields_u.oam.link_or_section_oam;
    new_node->pi_lm_received_packet = pkt_info->share_fields_u.oam.lm_received_packet;
    new_node->pi_dm_en = pkt_info->share_fields_u.oam.dm_en;
    new_node->pi_rx_fcb_oam = pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32;
    new_node->pi_rx_tx_fcl_oam = pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_OAM_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_hp2oam_shareptp_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_shareptp_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_HP2OM_PTP_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_shareptp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_shareptp_t));

    new_node->pi_ptp_edit_type = pkt_info->share_fields_u.ptp.ptp_edit_type;
    new_node->pi_ptp_sequence_id = pkt_info->share_fields_u.ptp.ptp_sequence_id;
    new_node->pi_ptp_extra_offset = pkt_info->share_fields_u.ptp.ptp_extra_offset;
    new_node->pi_time_stamp_ptp0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;
    new_node->pi_time_stamp_ptp1 = pkt_info->share_fields_u.ptp.time_stamp_61_32;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_PTP_BUS]));

    return DRV_E_NONE;
}
int32 sim_store_epe_hp2oam_sharedm_bus(void *in_pkt)
{
#if 0
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharedm_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_HP2OM_DMTX_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharedm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharedm_t));

    new_node->pi_dm_offset = pkt_info->share_fields_u.dmtx.dm_offset;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_DMTX_BUS]));
#endif
    return DRV_E_NONE;
}

int32 sim_store_epe_np2hp_sharelm_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharelm_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_NH2HP_LM_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharelm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharelm_t));

    new_node->pi_lm_packet_type = pkt_info->share_fields_u.lmtx.lm_packet_type;
    new_node->pi_tx_fcb = pkt_info->share_fields_u.lmtx.tx_fcb;
    new_node->pi_rx_fcb_lm = pkt_info->share_fields_u.lmtx.rx_fcb;
    new_node->pi_rx_tx_fcl_lm = pkt_info->share_fields_u.lmtx.rxtx_fcl;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_LM_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_np2hp_sharenat_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharenat_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_NH2HP_NAT_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharenat_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharenat_t));

    new_node->pi_new_ip_sa0 = pkt_info->share_fields_u.nat.new_ip_sa_31_0;
    new_node->pi_new_ip_sa1 = pkt_info->share_fields_u.nat.new_ip_sa_39_32;
    new_node->pi_new_l4_source_port = pkt_info->share_fields_u.nat.new_l4_source_port;
    new_node->pi_new_ip_sa_valid = pkt_info->share_fields_u.nat.new_ip_sa_valid;
    new_node->pi_new_l4_source_port_valid = pkt_info->share_fields_u.nat.new_l4_source_port_valid;
    new_node->pi_pt_enable = pkt_info->share_fields_u.nat.pt_enable;
    new_node->pi_ipv4_src_embeded_mode = pkt_info->share_fields_u.nat.ipv4_src_embeded_mode;
    new_node->pi_ip_sa_mode = pkt_info->share_fields_u.nat.ip_sa_mode;
    new_node->pi_src_address_mode = pkt_info->share_fields_u.nat.src_address_mode;
    new_node->pi_ip_sa_prefix_length = pkt_info->share_fields_u.nat.ip_sa_prefix_length;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_NAT_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_np2hp_shareoam_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_shareoam_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_NH2HP_OAM_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_shareoam_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_shareoam_t));

    new_node->pi_gal_exist = pkt_info->share_fields_u.oam.gal_exist;
    new_node->pi_entropy_label_exist = pkt_info->share_fields_u.oam.entropy_label_exist;
    new_node->pi_oam_dest_chip_id = pkt_info->share_fields_u.oam.oam_dest_chip_id;
    new_node->pi_mep_index = pkt_info->share_fields_u.oam.mep_index;
    new_node->pi_rx_oam_type = pkt_info->share_fields_u.oam.rx_oam_type;
    new_node->pi_mip_en = pkt_info->share_fields_u.oam.mip_en;
    new_node->pi_link_or_section_oam = pkt_info->share_fields_u.oam.link_or_section_oam;
    new_node->pi_lm_received_packet = pkt_info->share_fields_u.oam.lm_received_packet;
    new_node->pi_dm_en = pkt_info->share_fields_u.oam.dm_en;
    new_node->pi_rx_fcb_oam = pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32;
    new_node->pi_rx_tx_fcl_oam = pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_OAM_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_np2hp_shareptp_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_shareptp_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_NH2HP_PTP_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_shareptp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_shareptp_t));

    new_node->pi_ptp_edit_type = pkt_info->share_fields_u.ptp.ptp_edit_type;
    new_node->pi_ptp_sequence_id = pkt_info->share_fields_u.ptp.ptp_sequence_id;
    new_node->pi_ptp_extra_offset = pkt_info->share_fields_u.ptp.ptp_extra_offset;
    new_node->pi_time_stamp_ptp0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;
    new_node->pi_time_stamp_ptp1 = pkt_info->share_fields_u.ptp.time_stamp_61_32;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_PTP_BUS]));

    return DRV_E_NONE;
}
int32 sim_store_epe_np2hp_sharedm_bus(void *in_pkt)
{
#if 0
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharedm_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_NH2HP_DMTX_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharedm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharedm_t));

    new_node->pi_dm_offset = pkt_info->share_fields_u.dmtx.dm_offset;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_DMTX_BUS]));
#endif
    return DRV_E_NONE;
}

int32 sim_store_epe_oam2he_sharelm_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharelm_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_OM2HE_LM_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharelm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharelm_t));

    new_node->pi_lm_packet_type = pkt_info->share_fields_u.lmtx.lm_packet_type;
    new_node->pi_tx_fcb = pkt_info->share_fields_u.lmtx.tx_fcb;
    new_node->pi_rx_fcb_lm = pkt_info->share_fields_u.lmtx.rx_fcb;
    new_node->pi_rx_tx_fcl_lm = pkt_info->share_fields_u.lmtx.rxtx_fcl;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_LM_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_oam2he_sharenat_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharenat_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_OM2HE_NAT_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharenat_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharenat_t));

    new_node->pi_new_ip_sa0 = pkt_info->share_fields_u.nat.new_ip_sa_31_0;
    new_node->pi_new_ip_sa1 = pkt_info->share_fields_u.nat.new_ip_sa_39_32;
    new_node->pi_new_l4_source_port = pkt_info->share_fields_u.nat.new_l4_source_port;
    new_node->pi_new_ip_sa_valid = pkt_info->share_fields_u.nat.new_ip_sa_valid;
    new_node->pi_new_l4_source_port_valid = pkt_info->share_fields_u.nat.new_l4_source_port_valid;
    new_node->pi_pt_enable = pkt_info->share_fields_u.nat.pt_enable;
    new_node->pi_ipv4_src_embeded_mode = pkt_info->share_fields_u.nat.ipv4_src_embeded_mode;
    new_node->pi_ip_sa_mode = pkt_info->share_fields_u.nat.ip_sa_mode;
    new_node->pi_src_address_mode = pkt_info->share_fields_u.nat.src_address_mode;
    new_node->pi_ip_sa_prefix_length = pkt_info->share_fields_u.nat.ip_sa_prefix_length;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_NAT_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_oam2he_shareoam_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_shareoam_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_OM2HE_OAM_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_shareoam_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_shareoam_t));

    new_node->pi_gal_exist = pkt_info->share_fields_u.oam.gal_exist;
    new_node->pi_entropy_label_exist = pkt_info->share_fields_u.oam.entropy_label_exist;
    new_node->pi_oam_dest_chip_id = pkt_info->share_fields_u.oam.oam_dest_chip_id;
    new_node->pi_mep_index = pkt_info->share_fields_u.oam.mep_index;
    new_node->pi_rx_oam_type = pkt_info->share_fields_u.oam.rx_oam_type;
    new_node->pi_mip_en = pkt_info->share_fields_u.oam.mip_en;
    new_node->pi_link_or_section_oam = pkt_info->share_fields_u.oam.link_or_section_oam;
    new_node->pi_lm_received_packet = pkt_info->share_fields_u.oam.lm_received_packet;
    new_node->pi_dm_en = pkt_info->share_fields_u.oam.dm_en;
    new_node->pi_rx_fcb_oam = pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32;
    new_node->pi_rx_tx_fcl_oam = pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_OAM_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_epe_oam2he_shareptp_bus(void *in_pkt)
{
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_shareptp_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_OM2HE_PTP_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_shareptp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_shareptp_t));

    new_node->pi_ptp_edit_type = pkt_info->share_fields_u.ptp.ptp_edit_type;
    new_node->pi_ptp_sequence_id = pkt_info->share_fields_u.ptp.ptp_sequence_id;
    new_node->pi_ptp_extra_offset = pkt_info->share_fields_u.ptp.ptp_extra_offset;
    new_node->pi_time_stamp_ptp0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;
    new_node->pi_time_stamp_ptp1 = pkt_info->share_fields_u.ptp.time_stamp_61_32;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_PTP_BUS]));

    return DRV_E_NONE;
}
int32 sim_store_epe_oam2he_sharedm_bus(void *in_pkt)
{
#if 0
    epe_in_pkt_t *inpkt = (epe_in_pkt_t *)in_pkt;
    epe_sharedm_t *new_node;
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_EPE], SIM_EPE_SHA_FLD_OM2HE_DMTX_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(epe_sharedm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(epe_sharedm_t));

    new_node->pi_dm_offset = pkt_info->share_fields_u.dmtx.dm_offset;

    list_add_tail(&(new_node->head), &(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_DMTX_BUS]));
#endif

    return DRV_E_NONE;
}

int32
cosim_epe_aq2cs_verify(void *bus,bool *succ)
{
    epe_aq2cs_t *c_epe_aq2cs,v_epe_aq2cs;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_AQ2CS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe aq2cs verify error! <aq2cs list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_aq2cs = list_entry(cosim_db.sim_epe_list[SIM_EPE_AQ2CS].next,epe_aq2cs_t,head);
    sal_memset(&v_epe_aq2cs,0,sizeof(epe_aq2cs_t));
    ret = epe_aq2cs_bus_decode(bus, &v_epe_aq2cs);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe aq2cs bus decode error!\n");
        goto RELEASE;
    }


    if (c_epe_aq2cs->pi_discard != v_epe_aq2cs.pi_discard)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe aq2cs discard is not match!\n");
        ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_aq2cs.pi_discard, c_epe_aq2cs->pi_discard);
    }
    else if (c_epe_aq2cs->pi_discard == TRUE)
    {
        if (c_epe_aq2cs->pi_discard_type != v_epe_aq2cs.pi_discard_type)
       {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"epe aq2cs discard type is not match!\n");
            ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_aq2cs.pi_discard_type, c_epe_aq2cs->pi_discard_type);
        }
        else
        {
        /* Cmodel and RTL are both discard the packet, their discard types are the same. */
        *succ = TRUE;
        }
    }
    else
    {
        *succ = epe_aq2cs_bus_compare(c_epe_aq2cs,&v_epe_aq2cs);
    }


    list_del(&c_epe_aq2cs->head);
    sal_free(c_epe_aq2cs);
    c_epe_aq2cs = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_aq2cs->head);
    sal_free(c_epe_aq2cs);
    c_epe_aq2cs = NULL;
    return ret;
}
int32
cosim_epe_cs2om_verify(void *bus,bool *succ)
{
    epe_cs2om_t *c_epe_cs2om,v_epe_cs2om;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_CS2OM])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe cs2om verify error! <cs2om list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_cs2om = list_entry(cosim_db.sim_epe_list[SIM_EPE_CS2OM].next,epe_cs2om_t,head);
    sal_memset(&v_epe_cs2om,0,sizeof(epe_cs2om_t));
    ret = epe_cs2om_bus_decode(bus, &v_epe_cs2om);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe cs2om bus decode error!\n");
        goto RELEASE;
    }


    if (c_epe_cs2om->pi_discard != v_epe_cs2om.pi_discard)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe cs2om discard is not match!\n");
        ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_cs2om.pi_discard, c_epe_cs2om->pi_discard);
    }
    else if (c_epe_cs2om->pi_discard == TRUE)
    {
        if (c_epe_cs2om->pi_discard_type != v_epe_cs2om.pi_discard_type)
       {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"epe cs2om discard type is not match!\n");
            ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_cs2om.pi_discard_type, c_epe_cs2om->pi_discard_type);
        }
        else
        {
        /* Cmodel and RTL are both discard the packet, their discard types are the same. */
        *succ = TRUE;
        }
    }
    else
    {
        *succ = epe_cs2om_bus_compare(c_epe_cs2om,&v_epe_cs2om);
    }


    list_del(&c_epe_cs2om->head);
    sal_free(c_epe_cs2om);
    c_epe_cs2om = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_cs2om->head);
    sal_free(c_epe_cs2om);
    c_epe_cs2om = NULL;
    return ret;
}
int32
cosim_epe_excp_verify(void *bus,bool *succ)
{
    ms_epe_excp_info_t *c_epe_excp,v_epe_excp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};
    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_EXCP])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe excp verify error! <excp list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }
    c_epe_excp = list_entry(cosim_db.sim_epe_list[SIM_EPE_EXCP].next,ms_epe_excp_info_t,head);
    sal_memset(&v_epe_excp,0,sizeof(ms_epe_excp_info_t));
    ret = ms_epe_excp_info_bus_decode(bus, &v_epe_excp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe excp bus decode error!\n");
        goto RELEASE;
    }
    *succ = ms_epe_excp_info_bus_compare(c_epe_excp,&v_epe_excp);
    list_del(&c_epe_excp->head);
    sal_free(c_epe_excp);
    c_epe_excp = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_excp->head);
    sal_free(c_epe_excp);
    c_epe_excp = NULL;
    return ret;
}
int32
cosim_epe_ha2hp_verify(void *bus,bool *succ)
{
    epe_ha2hp_t *c_epe_ha2hp,v_epe_ha2hp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_HA2HP])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe ha2hp verify error! <ha2hp list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_ha2hp = list_entry(cosim_db.sim_epe_list[SIM_EPE_HA2HP].next,epe_ha2hp_t,head);
    sal_memset(&v_epe_ha2hp,0,sizeof(epe_ha2hp_t));
    ret = epe_ha2hp_bus_decode(bus, &v_epe_ha2hp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe ha2hp bus decode error!\n");
        goto RELEASE;
    }


    *succ = epe_ha2hp_bus_compare(c_epe_ha2hp,&v_epe_ha2hp);


    list_del(&c_epe_ha2hp->head);
    sal_free(c_epe_ha2hp);
    c_epe_ha2hp = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_ha2hp->head);
    sal_free(c_epe_ha2hp);
    c_epe_ha2hp = NULL;
    return ret;
}
int32
cosim_epe_ha2nh_verify(void *bus,bool *succ)
{
    epe_ha2nh_t *c_epe_ha2nh,v_epe_ha2nh;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_HA2NH])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe ha2nh verify error! <ha2nh list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_ha2nh = list_entry(cosim_db.sim_epe_list[SIM_EPE_HA2NH].next,epe_ha2nh_t,head);
    sal_memset(&v_epe_ha2nh,0,sizeof(epe_ha2nh_t));
    ret = epe_ha2nh_bus_decode(bus, &v_epe_ha2nh);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe ha2nh bus decode error!\n");
        goto RELEASE;
    }


    if (c_epe_ha2nh->pi_discard != v_epe_ha2nh.pi_discard)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe ha2nh discard is not match!\n");
        ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_ha2nh.pi_discard, c_epe_ha2nh->pi_discard);
    }
    else if (c_epe_ha2nh->pi_discard == TRUE)
    {
        if (c_epe_ha2nh->pi_discard_type != v_epe_ha2nh.pi_discard_type)
       {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"epe ha2nh discard type is not match!\n");
            ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_ha2nh.pi_discard_type, c_epe_ha2nh->pi_discard_type);
        }
			else
			{
			/* Cmodel and RTL are both discard the packet, their discard types are the same. */
			*succ = TRUE;
			}
    }
    else
    {
        *succ = epe_ha2nh_bus_compare(c_epe_ha2nh,&v_epe_ha2nh);
    }


    list_del(&c_epe_ha2nh->head);
    sal_free(c_epe_ha2nh);
    c_epe_ha2nh = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_ha2nh->head);
    sal_free(c_epe_ha2nh);
    c_epe_ha2nh = NULL;
    return ret;
}
int32
cosim_epe_ha2pr_verify(void *bus,bool *succ)
{
    epe_ha2pr_t *c_epe_ha2pr,v_epe_ha2pr;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_HA2PR])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe ha2pr verify error! <ha2pr list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_ha2pr = list_entry(cosim_db.sim_epe_list[SIM_EPE_HA2PR].next,epe_ha2pr_t,head);
    sal_memset(&v_epe_ha2pr,0,sizeof(epe_ha2pr_t));
    ret = epe_ha2pr_bus_decode(bus, &v_epe_ha2pr);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe ha2pr bus decode error!\n");
        goto RELEASE;
    }


    *succ = epe_ha2pr_bus_compare(c_epe_ha2pr,&v_epe_ha2pr);


    list_del(&c_epe_ha2pr->head);
    sal_free(c_epe_ha2pr);
    c_epe_ha2pr = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_ha2pr->head);
    sal_free(c_epe_ha2pr);
    c_epe_ha2pr = NULL;
    return ret;
}
int32
cosim_epe_hp2aq_verify(void *bus,bool *succ)
{
    epe_hp2aq_t *c_epe_hp2aq,v_epe_hp2aq;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_HP2AQ])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe hp2aq verify error! <hp2aq list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_hp2aq = list_entry(cosim_db.sim_epe_list[SIM_EPE_HP2AQ].next,epe_hp2aq_t,head);
    sal_memset(&v_epe_hp2aq,0,sizeof(epe_hp2aq_t));
    ret = epe_hp2aq_bus_decode(bus, &v_epe_hp2aq);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe hp2aq bus decode error!\n");
        goto RELEASE;
    }


    if (c_epe_hp2aq->pi_discard != v_epe_hp2aq.pi_discard)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe hp2aq discard is not match!\n");
        ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_hp2aq.pi_discard, c_epe_hp2aq->pi_discard);
    }
    else if (c_epe_hp2aq->pi_discard == TRUE)
    {
        if (c_epe_hp2aq->pi_discard_type != v_epe_hp2aq.pi_discard_type)
       {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"epe hp2aq discard type is not match!\n");
            ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_hp2aq.pi_discard_type, c_epe_hp2aq->pi_discard_type);
        }
			else
			{
			/* Cmodel and RTL are both discard the packet, their discard types are the same. */
			*succ = TRUE;
			}
    }
    else
    {
        *succ = epe_hp2aq_bus_compare(c_epe_hp2aq,&v_epe_hp2aq);
    }


    list_del(&c_epe_hp2aq->head);
    sal_free(c_epe_hp2aq);
    c_epe_hp2aq = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_hp2aq->head);
    sal_free(c_epe_hp2aq);
    c_epe_hp2aq = NULL;
    return ret;
}
int32
cosim_epe_hp2he_verify(void *bus,bool *succ)
{
    epe_hp2he_t *c_epe_hp2he,v_epe_hp2he;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_HP2HE])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe hp2he verify error! <hp2he list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_hp2he = list_entry(cosim_db.sim_epe_list[SIM_EPE_HP2HE].next,epe_hp2he_t,head);
    sal_memset(&v_epe_hp2he,0,sizeof(epe_hp2he_t));
    ret = epe_hp2he_bus_decode(bus, &v_epe_hp2he);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe hp2he bus decode error!\n");
        goto RELEASE;
    }


    *succ = epe_hp2he_bus_compare(c_epe_hp2he,&v_epe_hp2he);


    list_del(&c_epe_hp2he->head);
    sal_free(c_epe_hp2he);
    c_epe_hp2he = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_hp2he->head);
    sal_free(c_epe_hp2he);
    c_epe_hp2he = NULL;
    return ret;
}
int32
cosim_epe_hp2om_verify(void *bus,bool *succ)
{
    epe_hp2om_t *c_epe_hp2om,v_epe_hp2om;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_HP2OM])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe hp2om verify error! <hp2om list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_hp2om = list_entry(cosim_db.sim_epe_list[SIM_EPE_HP2OM].next,epe_hp2om_t,head);
    sal_memset(&v_epe_hp2om,0,sizeof(epe_hp2om_t));
    ret = epe_hp2om_bus_decode(bus, &v_epe_hp2om);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe hp2om bus decode error!\n");
        goto RELEASE;
    }


    *succ = epe_hp2om_bus_compare(c_epe_hp2om,&v_epe_hp2om);


    list_del(&c_epe_hp2om->head);
    sal_free(c_epe_hp2om);
    c_epe_hp2om = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_hp2om->head);
    sal_free(c_epe_hp2om);
    c_epe_hp2om = NULL;
    return ret;
}
int32
cosim_epe_nh2hp_verify(void *bus,bool *succ)
{
    epe_nh2hp_t *c_epe_nh2hp,v_epe_nh2hp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_NH2HP])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe nh2hp verify error! <nh2hp list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_nh2hp = list_entry(cosim_db.sim_epe_list[SIM_EPE_NH2HP].next,epe_nh2hp_t,head);
    sal_memset(&v_epe_nh2hp,0,sizeof(epe_nh2hp_t));
    ret = epe_nh2hp_bus_decode(bus, &v_epe_nh2hp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe nh2hp bus decode error!\n");
        goto RELEASE;
    }


    if (c_epe_nh2hp->pi_discard != v_epe_nh2hp.pi_discard)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe nh2hp discard is not match!\n");
        ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_nh2hp.pi_discard, c_epe_nh2hp->pi_discard);
    }
    else if (c_epe_nh2hp->pi_discard == TRUE)
    {
        if (c_epe_nh2hp->pi_discard_type != v_epe_nh2hp.pi_discard_type)
       {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"epe nh2hp discard type is not match!\n");
            ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_nh2hp.pi_discard_type, c_epe_nh2hp->pi_discard_type);
        }
			else
			{
			/* Cmodel and RTL are both discard the packet, their discard types are the same. */
			*succ = TRUE;
			}
    }
    else
    {
        *succ = epe_nh2hp_bus_compare(c_epe_nh2hp,&v_epe_nh2hp);
    }


    list_del(&c_epe_nh2hp->head);
    sal_free(c_epe_nh2hp);
    c_epe_nh2hp = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_nh2hp->head);
    sal_free(c_epe_nh2hp);
    c_epe_nh2hp = NULL;
    return ret;
}
int32
cosim_epe_om2he_verify(void *bus,bool *succ)
{
    epe_om2he_t *c_epe_om2he,v_epe_om2he;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_OM2HE])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe om2he verify error! <om2he list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_om2he = list_entry(cosim_db.sim_epe_list[SIM_EPE_OM2HE].next,epe_om2he_t,head);
    sal_memset(&v_epe_om2he,0,sizeof(epe_om2he_t));
    ret = epe_om2he_bus_decode(bus, &v_epe_om2he);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe om2he bus decode error!\n");
        goto RELEASE;
    }


    if (c_epe_om2he->pi_discard != v_epe_om2he.pi_discard)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe om2he discard is not match!\n");
        ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_om2he.pi_discard, c_epe_om2he->pi_discard);
    }
    else if (c_epe_om2he->pi_discard == TRUE)
    {
        if (c_epe_om2he->pi_discard_type != v_epe_om2he.pi_discard_type)
       {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"epe om2he discard type is not match!\n");
            ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_epe_om2he.pi_discard_type, c_epe_om2he->pi_discard_type);
        }
			else
			{
			/* Cmodel and RTL are both discard the packet, their discard types are the same. */
			*succ = TRUE;
			}
    }
    else
    {
        *succ = epe_om2he_bus_compare(c_epe_om2he,&v_epe_om2he);
    }


    list_del(&c_epe_om2he->head);
    sal_free(c_epe_om2he);
    c_epe_om2he = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_om2he->head);
    sal_free(c_epe_om2he);
    c_epe_om2he = NULL;
    return ret;
}
int32
cosim_epe_pr2hp_verify(void *bus,bool *succ)
{
    epe_pr2hp_t *c_epe_pr2hp,v_epe_pr2hp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_PR2HP])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe pr2hp verify error! <pr2hp list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_epe_pr2hp = list_entry(cosim_db.sim_epe_list[SIM_EPE_PR2HP].next,epe_pr2hp_t,head);
    sal_memset(&v_epe_pr2hp,0,sizeof(epe_pr2hp_t));
    ret = epe_pr2hp_bus_decode(bus, &v_epe_pr2hp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe pr2hp bus decode error!\n");
        goto RELEASE;
    }


    *succ = epe_pr2hp_bus_compare(c_epe_pr2hp,&v_epe_pr2hp);


    list_del(&c_epe_pr2hp->head);
    sal_free(c_epe_pr2hp);
    c_epe_pr2hp = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_epe_pr2hp->head);
    sal_free(c_epe_pr2hp);
    c_epe_pr2hp = NULL;
    return ret;
}

int32
cosim_epe_nettx_verify(void *bus,bool *succ)
{
    ms_nettx_t *c_ms_nettx,v_ms_nettx;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_NETTX])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ms nettx verify error! <nettx list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ms_nettx = list_entry(cosim_db.sim_epe_list[SIM_EPE_NETTX].next,ms_nettx_t,head);
    sal_memset(&v_ms_nettx,0,sizeof(ms_nettx_t));
    ret = ms_nettx_bus_decode(bus, &v_ms_nettx);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ms nettx bus decode error!\n");
        goto RELEASE;
    }


    *succ = ms_nettx_bus_compare(c_ms_nettx,&v_ms_nettx);


    list_del(&c_ms_nettx->head);
    sal_free(c_ms_nettx);
    c_ms_nettx = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ms_nettx->head);
    sal_free(c_ms_nettx);
    c_ms_nettx = NULL;
    return ret;
}

int32 cosim_epe_ha2nh_sharelm_verify(void *bus, bool *succ)
{
    epe_sharelm_t *c_epe_sharelm,v_epe_sharelm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_LM_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe HA2NH shareLM verify error! <shareLM list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharelm = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_LM_BUS].next,epe_sharelm_t,head);
    sal_memset(&v_epe_sharelm,0,sizeof(v_epe_sharelm));
    ret = epe_sharelm_bus_decode(bus, &v_epe_sharelm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe HA2NH shareLM bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharelm_bus_compare(c_epe_sharelm,&v_epe_sharelm);

    list_del(&c_epe_sharelm->head);
    sal_free(c_epe_sharelm);
    c_epe_sharelm = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharelm->head);
    sal_free(c_epe_sharelm);
    c_epe_sharelm = NULL;
    return ret;

}

int32 cosim_epe_ha2nh_sharenat_verify(void *bus, bool *succ)
{
    epe_sharenat_t *c_epe_sharenat,v_epe_sharenat;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_NAT_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe HA2NH shareNAT verify error! <shareNAT list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharenat = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_NAT_BUS].next,epe_sharenat_t,head);
    sal_memset(&v_epe_sharenat,0,sizeof(v_epe_sharenat));
    ret = epe_sharenat_bus_decode(bus, &v_epe_sharenat);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"Epe HA2NH shareNAT bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharenat_bus_compare(c_epe_sharenat,&v_epe_sharenat);

    list_del(&c_epe_sharenat->head);
    sal_free(c_epe_sharenat);
    c_epe_sharenat = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharenat->head);
    sal_free(c_epe_sharenat);
    c_epe_sharenat = NULL;
    return ret;
}

int32 cosim_epe_ha2nh_shareoam_verify(void *bus,bool *succ)
{
    epe_shareoam_t *c_epe_shareoam,v_epe_shareoam;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_OAM_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe HA2NH shareNAT verify error! <shareNAT list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_shareoam = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_OAM_BUS].next,epe_shareoam_t,head);
    sal_memset(&v_epe_shareoam,0,sizeof(v_epe_shareoam));
    ret = epe_shareoam_bus_decode(bus, &v_epe_shareoam);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe HA2NH shareNAT bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_shareoam_bus_compare(c_epe_shareoam,&v_epe_shareoam);

    list_del(&c_epe_shareoam->head);
    sal_free(c_epe_shareoam);
    c_epe_shareoam = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_shareoam->head);
    sal_free(c_epe_shareoam);
    c_epe_shareoam = NULL;
    return ret;
}

int32 cosim_epe_ha2nh_shareptp_verify(void *bus, bool *succ)
{
    epe_shareptp_t *c_epe_shareptp,v_epe_shareptp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_PTP_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe HA2NH sharePTP verify error! <sharePTP list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_shareptp = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_PTP_BUS].next,epe_shareptp_t,head);
    sal_memset(&v_epe_shareptp,0,sizeof(v_epe_shareptp));
    ret = epe_shareptp_bus_decode(bus, &v_epe_shareptp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe HA2NH sharePTP bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_shareptp_bus_compare(c_epe_shareptp,&v_epe_shareptp);

    list_del(&c_epe_shareptp->head);
    sal_free(c_epe_shareptp);
    c_epe_shareptp = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_shareptp->head);
    sal_free(c_epe_shareptp);
    c_epe_shareptp = NULL;
    return ret;
}
int32 cosim_epe_ha2nh_sharedm_verify(void *bus, bool *succ)
{
    epe_sharedm_t *c_epe_sharedm,v_epe_sharedm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_DMTX_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe HA2NH shareDM verify error! <shareDM list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharedm = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HA2NH_DMTX_BUS].next,epe_sharedm_t,head);
    sal_memset(&v_epe_sharedm,0,sizeof(v_epe_sharedm));
    ret = epe_sharedm_bus_decode(bus, &v_epe_sharedm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe HA2NH shareDM bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharedm_bus_compare(c_epe_sharedm,&v_epe_sharedm);

    list_del(&c_epe_sharedm->head);
    sal_free(c_epe_sharedm);
    c_epe_sharedm = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharedm->head);
    sal_free(c_epe_sharedm);
    c_epe_sharedm = NULL;
    return ret;
}

int32 cosim_epe_hp2oam_sharelm_verify(void *bus, bool *succ)
{
    epe_sharelm_t *c_epe_sharelm,v_epe_sharelm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_LM_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe HP2OM shareLM verify error! <shareLM list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharelm = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_LM_BUS].next,epe_sharelm_t,head);
    sal_memset(&v_epe_sharelm,0,sizeof(v_epe_sharelm));
    ret = epe_sharelm_bus_decode(bus, &v_epe_sharelm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe HP2OM shareLM bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharelm_bus_compare(c_epe_sharelm,&v_epe_sharelm);

    list_del(&c_epe_sharelm->head);
    sal_free(c_epe_sharelm);
    c_epe_sharelm = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharelm->head);
    sal_free(c_epe_sharelm);
    c_epe_sharelm = NULL;
    return ret;

}

int32 cosim_epe_hp2oam_sharenat_verify(void *bus, bool *succ)
{
    epe_sharenat_t *c_epe_sharenat,v_epe_sharenat;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_NAT_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe HP2OM shareNAT verify error! <shareNAT list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharenat = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_NAT_BUS].next,epe_sharenat_t,head);
    sal_memset(&v_epe_sharenat,0,sizeof(v_epe_sharenat));
    ret = epe_sharenat_bus_decode(bus, &v_epe_sharenat);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"Epe HP2OM shareNAT bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharenat_bus_compare(c_epe_sharenat,&v_epe_sharenat);

    list_del(&c_epe_sharenat->head);
    sal_free(c_epe_sharenat);
    c_epe_sharenat = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharenat->head);
    sal_free(c_epe_sharenat);
    c_epe_sharenat = NULL;
    return ret;
}

int32 cosim_epe_hp2oam_shareoam_verify(void *bus,bool *succ)
{
    epe_shareoam_t *c_epe_shareoam,v_epe_shareoam;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_OAM_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe HP2OM shareNAT verify error! <shareNAT list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_shareoam = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_OAM_BUS].next,epe_shareoam_t,head);
    sal_memset(&v_epe_shareoam,0,sizeof(v_epe_shareoam));
    ret = epe_shareoam_bus_decode(bus, &v_epe_shareoam);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe HP2OM shareNAT bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_shareoam_bus_compare(c_epe_shareoam,&v_epe_shareoam);

    list_del(&c_epe_shareoam->head);
    sal_free(c_epe_shareoam);
    c_epe_shareoam = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_shareoam->head);
    sal_free(c_epe_shareoam);
    c_epe_shareoam = NULL;
    return ret;
}

int32 cosim_epe_hp2oam_shareptp_verify(void *bus, bool *succ)
{
    epe_shareptp_t *c_epe_shareptp,v_epe_shareptp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_PTP_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe HP2OM sharePTP verify error! <sharePTP list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_shareptp = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_PTP_BUS].next,epe_shareptp_t,head);
    sal_memset(&v_epe_shareptp,0,sizeof(v_epe_shareptp));
    ret = epe_shareptp_bus_decode(bus, &v_epe_shareptp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe HP2OM sharePTP bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_shareptp_bus_compare(c_epe_shareptp,&v_epe_shareptp);

    list_del(&c_epe_shareptp->head);
    sal_free(c_epe_shareptp);
    c_epe_shareptp = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_shareptp->head);
    sal_free(c_epe_shareptp);
    c_epe_shareptp = NULL;
    return ret;
}
int32 cosim_epe_hp2oam_sharedm_verify(void *bus, bool *succ)
{
    epe_sharedm_t *c_epe_sharedm,v_epe_sharedm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_DMTX_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe HP2OM shareDM verify error! <shareDM list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharedm = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_HP2OM_DMTX_BUS].next,epe_sharedm_t,head);
    sal_memset(&v_epe_sharedm,0,sizeof(v_epe_sharedm));
    ret = epe_sharedm_bus_decode(bus, &v_epe_sharedm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe HP2OM shareDM bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharedm_bus_compare(c_epe_sharedm,&v_epe_sharedm);

    list_del(&c_epe_sharedm->head);
    sal_free(c_epe_sharedm);
    c_epe_sharedm = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharedm->head);
    sal_free(c_epe_sharedm);
    c_epe_sharedm = NULL;
    return ret;
}

int32 cosim_epe_np2hp_sharelm_verify(void *bus, bool *succ)
{
    epe_sharelm_t *c_epe_sharelm,v_epe_sharelm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_LM_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe NH2HP shareLM verify error! <shareLM list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharelm = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_LM_BUS].next,epe_sharelm_t,head);
    sal_memset(&v_epe_sharelm,0,sizeof(v_epe_sharelm));
    ret = epe_sharelm_bus_decode(bus, &v_epe_sharelm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe NH2HP shareLM bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharelm_bus_compare(c_epe_sharelm,&v_epe_sharelm);

    list_del(&c_epe_sharelm->head);
    sal_free(c_epe_sharelm);
    c_epe_sharelm = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharelm->head);
    sal_free(c_epe_sharelm);
    c_epe_sharelm = NULL;
    return ret;

}

int32 cosim_epe_np2hp_sharenat_verify(void *bus, bool *succ)
{
    epe_sharenat_t *c_epe_sharenat,v_epe_sharenat;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_NAT_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe NH2HP shareNAT verify error! <shareNAT list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharenat = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_NAT_BUS].next,epe_sharenat_t,head);
    sal_memset(&v_epe_sharenat,0,sizeof(v_epe_sharenat));
    ret = epe_sharenat_bus_decode(bus, &v_epe_sharenat);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"Epe NH2HP shareNAT bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharenat_bus_compare(c_epe_sharenat,&v_epe_sharenat);

    list_del(&c_epe_sharenat->head);
    sal_free(c_epe_sharenat);
    c_epe_sharenat = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharenat->head);
    sal_free(c_epe_sharenat);
    c_epe_sharenat = NULL;
    return ret;
}

int32 cosim_epe_np2hp_shareoam_verify(void *bus,bool *succ)
{
    epe_shareoam_t *c_epe_shareoam,v_epe_shareoam;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_OAM_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe NH2HP shareNAT verify error! <shareNAT list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_shareoam = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_OAM_BUS].next,epe_shareoam_t,head);
    sal_memset(&v_epe_shareoam,0,sizeof(v_epe_shareoam));
    ret = epe_shareoam_bus_decode(bus, &v_epe_shareoam);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe NH2HP shareNAT bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_shareoam_bus_compare(c_epe_shareoam,&v_epe_shareoam);

    list_del(&c_epe_shareoam->head);
    sal_free(c_epe_shareoam);
    c_epe_shareoam = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_shareoam->head);
    sal_free(c_epe_shareoam);
    c_epe_shareoam = NULL;
    return ret;
}

int32 cosim_epe_np2hp_shareptp_verify(void *bus, bool *succ)
{
    epe_shareptp_t *c_epe_shareptp,v_epe_shareptp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_PTP_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe NH2HP sharePTP verify error! <sharePTP list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_shareptp = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_PTP_BUS].next,epe_shareptp_t,head);
    sal_memset(&v_epe_shareptp,0,sizeof(v_epe_shareptp));
    ret = epe_shareptp_bus_decode(bus, &v_epe_shareptp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe NH2HP sharePTP bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_shareptp_bus_compare(c_epe_shareptp,&v_epe_shareptp);

    list_del(&c_epe_shareptp->head);
    sal_free(c_epe_shareptp);
    c_epe_shareptp = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_shareptp->head);
    sal_free(c_epe_shareptp);
    c_epe_shareptp = NULL;
    return ret;
}
int32 cosim_epe_np2hp_sharedm_verify(void *bus, bool *succ)
{
    epe_sharedm_t *c_epe_sharedm,v_epe_sharedm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_DMTX_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe NH2HP shareDM verify error! <shareDM list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharedm = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_NH2HP_DMTX_BUS].next,epe_sharedm_t,head);
    sal_memset(&v_epe_sharedm,0,sizeof(v_epe_sharedm));
    ret = epe_sharedm_bus_decode(bus, &v_epe_sharedm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe NH2HP shareDM bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharedm_bus_compare(c_epe_sharedm,&v_epe_sharedm);

    list_del(&c_epe_sharedm->head);
    sal_free(c_epe_sharedm);
    c_epe_sharedm = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharedm->head);
    sal_free(c_epe_sharedm);
    c_epe_sharedm = NULL;
    return ret;
}

int32 cosim_epe_oam2he_sharelm_verify(void *bus, bool *succ)
{
    epe_sharelm_t *c_epe_sharelm,v_epe_sharelm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_LM_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe OM2HE shareLM verify error! <shareLM list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharelm = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_LM_BUS].next,epe_sharelm_t,head);
    sal_memset(&v_epe_sharelm,0,sizeof(v_epe_sharelm));
    ret = epe_sharelm_bus_decode(bus, &v_epe_sharelm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe OM2HE shareLM bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharelm_bus_compare(c_epe_sharelm,&v_epe_sharelm);

    list_del(&c_epe_sharelm->head);
    sal_free(c_epe_sharelm);
    c_epe_sharelm = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharelm->head);
    sal_free(c_epe_sharelm);
    c_epe_sharelm = NULL;
    return ret;

}

int32 cosim_epe_oam2he_sharenat_verify(void *bus, bool *succ)
{
    epe_sharenat_t *c_epe_sharenat,v_epe_sharenat;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_NAT_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe OM2HE shareNAT verify error! <shareNAT list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharenat = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_NAT_BUS].next,epe_sharenat_t,head);
    sal_memset(&v_epe_sharenat,0,sizeof(v_epe_sharenat));
    ret = epe_sharenat_bus_decode(bus, &v_epe_sharenat);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"Epe OM2HE shareNAT bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharenat_bus_compare(c_epe_sharenat,&v_epe_sharenat);

    list_del(&c_epe_sharenat->head);
    sal_free(c_epe_sharenat);
    c_epe_sharenat = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharenat->head);
    sal_free(c_epe_sharenat);
    c_epe_sharenat = NULL;
    return ret;
}

int32 cosim_epe_oam2he_shareoam_verify(void *bus,bool *succ)
{
    epe_shareoam_t *c_epe_shareoam,v_epe_shareoam;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_OAM_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe OM2HE shareNAT verify error! <shareNAT list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_shareoam = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_OAM_BUS].next,epe_shareoam_t,head);
    sal_memset(&v_epe_shareoam,0,sizeof(v_epe_shareoam));
    ret = epe_shareoam_bus_decode(bus, &v_epe_shareoam);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe OM2HE shareNAT bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_shareoam_bus_compare(c_epe_shareoam,&v_epe_shareoam);

    list_del(&c_epe_shareoam->head);
    sal_free(c_epe_shareoam);
    c_epe_shareoam = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_shareoam->head);
    sal_free(c_epe_shareoam);
    c_epe_shareoam = NULL;
    return ret;
}

int32 cosim_epe_oam2he_shareptp_verify(void *bus, bool *succ)
{
    epe_shareptp_t *c_epe_shareptp,v_epe_shareptp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_PTP_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe OM2HE sharePTP verify error! <sharePTP list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_shareptp = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_PTP_BUS].next,epe_shareptp_t,head);
    sal_memset(&v_epe_shareptp,0,sizeof(v_epe_shareptp));
    ret = epe_shareptp_bus_decode(bus, &v_epe_shareptp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe OM2HE sharePTP bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_shareptp_bus_compare(c_epe_shareptp,&v_epe_shareptp);

    list_del(&c_epe_shareptp->head);
    sal_free(c_epe_shareptp);
    c_epe_shareptp = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_shareptp->head);
    sal_free(c_epe_shareptp);
    c_epe_shareptp = NULL;
    return ret;
}
int32 cosim_epe_oam2he_sharedm_verify(void *bus, bool *succ)
{
    epe_sharedm_t *c_epe_sharedm,v_epe_sharedm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_DMTX_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "epe OM2HE shareDM verify error! <shareDM list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_epe_sharedm = list_entry(cosim_db.sim_epe_list[SIM_EPE_SHA_FLD_OM2HE_DMTX_BUS].next,epe_sharedm_t,head);
    sal_memset(&v_epe_sharedm,0,sizeof(v_epe_sharedm));
    ret = epe_sharedm_bus_decode(bus, &v_epe_sharedm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"epe OM2HE shareDM bus decode error!\n");
        goto RELEASE;
    }

    *succ = epe_sharedm_bus_compare(c_epe_sharedm,&v_epe_sharedm);

    list_del(&c_epe_sharedm->head);
    sal_free(c_epe_sharedm);
    c_epe_sharedm = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_epe_sharedm->head);
    sal_free(c_epe_sharedm);
    c_epe_sharedm = NULL;
    return ret;
}

