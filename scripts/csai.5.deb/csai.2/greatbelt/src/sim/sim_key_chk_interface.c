/****************************************************************************
 * sim_check_tcam_and_hash_key.c
 *
 * Copyright:    (c)2008 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jack.Xu
 * Date:         2011-11-08
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "sim_interface.h"
#include "sim_key_chk_interface.h"

/*store hash key*/
int32 sim_store_hash_tcam_key(void *key, tbls_id_t tbls_id)
{
    store_key_info_t *new_node = NULL;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};
    uint8 key_size = 0;
    list_head_t *data_base_linklist = NULL;
    uint8 cosim_flag = FALSE;
    uint8 key_type = 0;

    DRV_PTR_VALID_CHECK(key);

    if (drv_table_is_tcam_key(tbls_id))
    {
        key_type = SIM_KEY_TYPE_TCAM;
    }
    else
    {
        key_type = SIM_KEY_TYPE_HASH;
    }

    cosim_flag = cosim_db.sim_key_cosim_flag[key_type];
    data_base_linklist = &cosim_db.sim_key_list[key_type];

    if (!sim_interface_initialize || !cosim_flag)
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(store_key_info_t));
    if (NULL == new_node)
    {
        ASIC_DEBUG_BUS_CMP(buf, "FAILED! No memory, fail to creat new node during store table %d hash/tcam key!\n",
                           tbls_id);
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node, 0, sizeof(store_key_info_t));

    key_size = TABLE_ENTRY_SIZE(tbls_id); /* ??? keysize */

    new_node->tblid= tbls_id;
    sal_memcpy(new_node->key, key, key_size);

    /* insert the node into the corresponding linklist */
    list_add_tail(&new_node->head, data_base_linklist);

    return DRV_E_NONE;

}

int32 cosim_hash_tcam_key_verify(uint32 tbls_id, uint8 *key,  bool *succ)
{
    store_key_info_t *c_hash_key = NULL;
    list_head_t *pos = NULL;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};
    uint8 cosim_flag = FALSE;
    list_head_t *data_base_linklist = NULL;
    uint32 key_type = 0;
    char table_name[128] = {0};
    bool tablid_hit = FALSE;

    sal_memset(table_name, 0, sizeof(table_name));
    drv_get_tbl_string_by_id(tbls_id, table_name);

    if (!key)
    {
        ASIC_DEBUG_BUS_CMP(buf,
                           "FAILED! when Compare table %s hash/tcam key, input RTL_key is NULL pointer!\n",
                           table_name);
        return DRV_E_INVALID_PTR;
    }

    if (drv_table_is_tcam_key(tbls_id))
    {
        key_type = SIM_KEY_TYPE_TCAM;
    }
    else
    {
        key_type = SIM_KEY_TYPE_HASH;
    }

    cosim_flag = cosim_db.sim_key_cosim_flag[key_type];
    data_base_linklist = &cosim_db.sim_key_list[key_type];

    if (!sim_interface_initialize || !cosim_flag)
    {
        return DRV_E_NONE;
    }

    list_for_each(pos, data_base_linklist)
    {
        c_hash_key = list_entry(pos, store_key_info_t, head);

        if (c_hash_key->tblid == tbls_id)
        {
            tablid_hit = TRUE;
            DRV_IF_ERROR_RETURN(sim_check_key(tbls_id, (uint32*)c_hash_key->key, (uint32*)key, succ));

            if (*succ != TRUE)
            {
                ASIC_DEBUG_BUS_CMP(buf,"FAILED! Hash/Tcam key mismatch!\n");
                break;
            }
            else
            {
                /*ASIC_DEBUG_BUS_CMP(buf, "PASSED: key %s compare is ok!!!\n", table_name);*/
                list_del(&c_hash_key->head);
                sal_free(c_hash_key);
                c_hash_key = NULL;
                break;
            }
        }
        else
        {
            continue;
        }
    }

    if (!tablid_hit)
    {
        ASIC_DEBUG_BUS_CMP(buf, "FAILED! CModel do not read tableName %s when compare hash/tcam key!\n", table_name);
    }

    return DRV_E_NONE;
}

