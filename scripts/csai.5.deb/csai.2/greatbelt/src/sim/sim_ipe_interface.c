/****************************************************************************
 * sim_ipe_interface.c
 * Copyright:    (c)2007 Centec Networks Inc.  All rights reserved.
 *
 * Revision:      V1.0.
 * Author:       Xiaobo Yan
 * Date:         2007-4-14
 * Reason:       First Create.
 *
 * Modify History:
****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sim_ipe_interface.h"
#include "cm_lib.h"

int32
cosim_do_ipe(uint32 chipid, uint32 chanid, uint32 pkt_len, bool ptp_en, uint8 *pkt)
{
    ipe_in_pkt_t in_pkt;
    list_head_t out_pkt, *pos = NULL;
    int ret;
    out_pkt_t *output=NULL;

    if (pkt == NULL)
    {
        return DRV_E_INVALID_PTR;
    }

    sal_memset(&in_pkt, 0, sizeof(ipe_in_pkt_t));
    INIT_LIST_HEAD(&out_pkt);

    in_pkt.chip_id = chipid;
    in_pkt.chan_id = chanid;

    in_pkt.pkt = sal_malloc(MTU);

    if (NULL == in_pkt.pkt)
    {
        return DRV_E_NO_MEMORY;
    }

    sal_memset(in_pkt.pkt, 0, MTU);
    if (chanid == I_LOOPBACK_CHANID)
    {
        sal_memcpy(in_pkt.pkt, pkt+GREAT_BELT_HEADER_LEN, pkt_len); /* only raw packet, do not include bheader */
    }
    else
    {
        sal_memcpy(in_pkt.pkt, pkt, pkt_len);
    }
    in_pkt.packet_length = pkt_len;         /* do not include bheader len */
    in_pkt.pkt_info = NULL;
    in_pkt.channelinfo_ptpen = ptp_en;
    in_pkt.module_bus.dest_id_discard = 0;  /* cmodel mustbe 0 */
    in_pkt.module_bus.pkt_len = pkt_len;    /* cmodel IPE can not support cutThrough */
    if (chanid == I_LOOPBACK_CHANID)
    {
        sal_memcpy(in_pkt.module_bus.packet_header, pkt, GREAT_BELT_HEADER_LEN);
    }

    ret = cm_do_ipe(&in_pkt, &out_pkt);
    if (ret < 0)
    {
        return ret;
    }

    list_for_each(pos, &out_pkt)
    {
        output = list_entry(pos, out_pkt_t, head);
        if (cosim_db.store_outpkt)
        {
            ret = cosim_db.store_outpkt(output->chip_id,
                                        output->chan_id,
                                        output->packet_length,
                                        output->pkt,
                                        SIM_MODULE_IPE,
                                        cosim_discard_info.discard,
                                        cosim_discard_info.discard_type);
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("CoSIM: IPE engine store outpkt error ! ret = %d\n", ret);
            }
        }
    }

    list_del_all_and_free(&out_pkt);

    return DRV_E_NONE;
}

int32
sim_store_ipe_excp_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ms_ipe_excp_info_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;
    greatbelt_exception_info_t *bexception = (greatbelt_exception_info_t *)pkt_info->bexception;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_EXCP))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ms_ipe_excp_info_t));


    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ms_ipe_excp_info_t));

    new_node->excp_sub_index = bexception->exception_sub_index;
    new_node->dest_id_discard = bexception->dest_id_discard;
    new_node->l2_span_id = bexception->l2_span_id;
    new_node->l3_span_id = bexception->l3_span_id;
    new_node->acl_log_id1 = bexception->acl_log_id1;
    new_node->acl_log_id0 = bexception->acl_log_id0;
    new_node->egress_excp = bexception->egress_exception;
    new_node->excp_pkt_type = bexception->exception_packet_type;
    new_node->excp_vector = bexception->exception_vector;
    new_node->excp_from_sgmac = bexception->exception_from_sgmac;
    new_node->excp_number = bexception->exception_number;
    new_node->acl_log_id3 = bexception->acl_log_id3;
    new_node->acl_log_id2 = bexception->acl_log_id2;


    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_EXCP]));


    return DRV_E_NONE;
}
int32
sim_store_ipe_ha2pr_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_ha2pr_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_HA2PR))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_ha2pr_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_ha2pr_t));

    new_node->pi_layer4_type = L4_TYPE_NONE;
    new_node->pi_mux_length_type = pkt_info->mux_length_type;
    new_node->pi_non_crc = pkt_info->non_crc;
    new_node->pi_outer_vlan_is_cvlan = pkt_info->outer_vlan_is_cvlan;
    new_node->pi_packet_type = pkt_info->packet_type;
    new_node->pi_port_id = pkt_info->local_phy_port;
    new_node->pi_svlan_tpid_index = pkt_info->svlan_tpid_index;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_HA2PR]));


    return DRV_E_NONE;
}
int32
sim_store_ipe_ha2im_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_ha2im_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_HA2IM))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_ha2im_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_ha2im_t));

    new_node->pi_non_crc = pkt_info->non_crc;
    new_node->pi_mux_length_type = pkt_info->mux_length_type;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_packet_type = pkt_info->packet_type;
    new_node->pi_outer_priority = pkt_info->outer_priority;
    new_node->pi_outer_color = pkt_info->outer_color;
    new_node->pi_from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    new_node->pi_from_sgmac = pkt_info->from_sgmac;
    new_node->pi_outer_ttl = pkt_info->outer_ttl;
    new_node->pi_customer_id_valid = pkt_info->customer_id_valid;
    new_node->pi_customer_id = pkt_info->customer_id;
    new_node->pi_source_port_isolate_id = pkt_info->src_port_isolate_id;
    new_node->pi_is_loop = pkt_info->is_loop;
    new_node->pi_user_vlan_ptr_valid = pkt_info->user_vlan_ptr_valid;
    new_node->pi_user_vlan_ptr = pkt_info->user_vlan_ptr;
    new_node->pi_logic_src_port = pkt_info->logic_src_port;
    new_node->pi_logic_src_port_valid = pkt_info->logic_src_port_valid;
    new_node->pi_src_dscp_valid = pkt_info->src_dscp_valid;
    new_node->pi_src_dscp = pkt_info->src_dscp;
    new_node->pi_oam_use_fid = pkt_info->oam_use_fid;
    new_node->pi_capwap_tunnel_valid = pkt_info->capwap_tunnel_valid;
    new_node->pi_capwap_tunnel_type = pkt_info->capwap_tunnel_type;
    new_node->pi_roaming_state = pkt_info->roaming_state;
    new_node->pi_logic_port_type = pkt_info->logic_port_type;
    new_node->pi_user_default_vlan_tag_valid = pkt_info->use_default_vlan_tag_valid;
    new_node->pi_user_default_vlan_id = pkt_info->user_default_vlan_id;
    new_node->pi_user_default_cos = pkt_info->user_default_cos;
    new_node->pi_user_default_cfi = pkt_info->user_default_cfi;
    new_node->pi_rx_oam_type = pkt_info->rx_oam_type;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_discard_type = pkt_info->discard_type;
    new_node->pi_packet_length = pkt_info->packet_length;
    new_node->pi_bypass_all = pkt_info->bypass_all;
    new_node->pi_payload_offset = pkt_info->payload_offset;
    new_node->pi_packet_length_adjust = pkt_info->packet_length_adjust;
    new_node->pi_mux_destination = pkt_info->mux_destination;
    new_node->pi_mux_destination_type = pkt_info->mux_destination_type;
    new_node->pi_mux_destination_valid = pkt_info->mux_destination_valid;
    new_node->pi_hard_error = 0;
    new_node->pi_outer_vlan_is_cvlan = pkt_info->outer_vlan_is_cvlan;
    new_node->pi_pbb_src_port_type = pkt_info->pbb_src_port_type;
    new_node->pi_svlan_tpid_index = pkt_info->svlan_tpid_index;
    new_node->pi_time_stamp_valid = pkt_info->time_stamp_valid;
    new_node->pi_time_stamp0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;
    new_node->pi_time_stamp1 = pkt_info->share_fields_u.ptp.time_stamp_61_32;
    new_node->pi_channel_id = inpkt->chan_id;
    new_node->pi_mpls_label_space_valid = pkt_info->mpls_label_space_valid;
    new_node->pi_fid = pkt_info->fid;
    new_node->pi_source_port_extender = pkt_info->source_port_extender;
    new_node->pi_tx_dm_en = pkt_info->tx_dm_en;
    new_node->pi_port_mac_type = pkt_info->port_mac_type;
    new_node->pi_port_mac_label = pkt_info->port_mac_label;
    new_node->pi_vlan_range_type = pkt_info->vlan_range_type;
    new_node->pi_vlan_range_profile = pkt_info->vlan_range_profile;
    new_node->pi_vlan_range_profile_en = pkt_info->vlan_range_profile_en;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_HA2IM]));


    return DRV_E_NONE;
}

int32
sim_store_ipe_im2pp_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_im2pp_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_rslt1;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_IM2PP))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_im2pp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_im2pp_t));
    new_node->pi_mpls_label_space_valid = pkt_info->mpls_label_space_valid;
    new_node->pi_mpls_label_space = pkt_info->mpls_label_space;
    new_node->pi_next_hop_ptr_valid = pkt_info->next_hop_ptr_valid;
    new_node->pi_ad_next_hop_ptr = pkt_info->ad_next_hop_ptr;
    new_node->pi_ad_dest_map = pkt_info->ad_dest_map;
    new_node->pi_ad_length_adjust_type = pkt_info->ad_length_adjust_type;
    new_node->pi_ad_critical_packet = pkt_info->ad_critical_packet;
    new_node->pi_ad_next_hop_ext = pkt_info->ad_next_hop_ext;
    new_node->pi_ad_send_local_phy_port = pkt_info->ad_send_local_phy_port;
    new_node->pi_ad_aps_type = pkt_info->ad_aps_type;
    new_node->pi_ad_speed = pkt_info->ad_speed;
    new_node->pi_mpls_extra_payload_offset = pkt_info->mpls_extra_payload_offset;
    new_node->pi_is_mpls_ttl_one = pkt_info->is_mpls_ttl_one;
    new_node->pi_fast_learning_en = pkt_info->fast_learning_en;
    new_node->pi_rpf_permit_default = pkt_info->rpf_permit_default;
    new_node->pi_pbb_outer_learning_enable = pkt_info->pbb_outer_learning_enable;
    new_node->pi_pbb_outer_learning_disable = pkt_info->pbb_outer_learning_disable;
    new_node->pi_mpls_mep_check = pkt_info->mpls_mep_check;
    new_node->pi_non_crc = pkt_info->non_crc;
    new_node->pi_src_dscp_valid = pkt_info->src_dscp_valid;
    new_node->pi_src_dscp = pkt_info->src_dscp;
    new_node->pi_packet_type = pkt_info->packet_type;
    new_node->pi_capwap_tunnel_valid = pkt_info->capwap_tunnel_valid;
    new_node->pi_logic_port_type = pkt_info->logic_port_type;
    new_node->pi_roaming_state = pkt_info->roaming_state;
    new_node->pi_capwap_tunnel_type = pkt_info->capwap_tunnel_type;
    new_node->pi_outer_vlan_is_cvlan = pkt_info->outer_vlan_is_cvlan;
    new_node->pi_svlan_tpid_index = pkt_info->svlan_tpid_index;
    new_node->pi_l2_span_en = pkt_info->l2_span_en;
    new_node->pi_l2_span_id = pkt_info->l2_span_id;
    new_node->pi_random_log_en = pkt_info->random_log_en;
    new_node->pi_port_log_en = pkt_info->port_log_en;
    new_node->pi_ds_fwd_ptr_valid = pkt_info->ds_fwd_ptr_valid;
    new_node->pi_ds_fwd_ptr = pkt_info->ds_fwd_ptr;
    new_node->pi_default_vlan_id = pkt_info->default_vlan_id;
    new_node->pi_deny_learning = pkt_info->deny_learning;
    new_node->pi_oam_tunnel_en = pkt_info->oam_tunnel_en;
    new_node->pi_svlan_tag_operation_valid = pkt_info->svlan_tag_operation_valid;
    new_node->pi_cvlan_tag_operation_valid = pkt_info->cvlan_tag_operation_valid;
    new_node->pi_flow_stats2_valid = pkt_info->flow_stats2_valid;
    new_node->pi_user_priority_valid = pkt_info->user_priority_valid;
    new_node->pi_src_queue_select = pkt_info->src_queue_select;
    new_node->pi_user_priority = pkt_info->user_priority;
    new_node->pi_user_color = pkt_info->user_color;
    new_node->pi_stag_action = pkt_info->stag_action;
    new_node->pi_ctag_action = pkt_info->ctag_action;
    new_node->pi_flow_stats2_ptr = pkt_info->flow_stats2_ptr;
    new_node->pi_aps_select_valid0 = pkt_info->aps_select_valid0;
    new_node->pi_aps_select_group_id0 = pkt_info->aps_select_group_id0;
    new_node->pi_igmp_snoop_en = pkt_info->igmp_snoop_en;
    new_node->pi_mac_security_vsi_discard = pkt_info->mac_security_vsi_discard;
    new_node->pi_service_policer_valid = pkt_info->service_policer_valid;
    new_node->pi_service_policer_mode = pkt_info->service_policer_mode;
    new_node->pi_service_policer_ptr = pkt_info->service_policer_ptr;
    new_node->pi_flow_policer_valid = pkt_info->flow_policer_valid;
    new_node->pi_flow_policer_ptr = pkt_info->flow_policer_ptr;
    new_node->pi_is_leaf = pkt_info->is_leaf;
    new_node->pi_mac_security_discard = pkt_info->mac_security_discard;
    new_node->pi_port_policer_valid = pkt_info->port_policer_valid;
    new_node->pi_qos_policy = pkt_info->qos_policy;
    new_node->pi_ipg_index = pkt_info->ipg_index;
    new_node->pi_qos_domain = pkt_info->qos_domain;
    new_node->pi_port_security_en = pkt_info->port_security_en;
    new_node->pi_port_check_en = pkt_info->port_check_en;
    new_node->pi_speed = pkt_info->speed;
    new_node->pi_port_storm_ctl_ptr = pkt_info->port_storm_ctl_ptr;
    new_node->pi_port_storm_ctl_en = pkt_info->port_storm_ctl_en;
    new_node->pi_mcast_mac_address = pkt_info->mcast_mac_address;
    new_node->pi_mcast_discard = pkt_info->mcast_discard;
    new_node->pi_ucast_discard = pkt_info->ucast_discard;
    new_node->pi_is_esadi = pkt_info->is_esadi;
    new_node->pi_ctag_cos = pkt_info->ctag_cos;
    new_node->pi_ctag_cfi = pkt_info->ctag_cfi;
    new_node->pi_svlan_id_valid = pkt_info->svlan_id_valid;
    new_node->pi_cvlan_id_valid = pkt_info->cvlan_id_valid;
    new_node->pi_src_ctag_offset_type = pkt_info->src_ctag_offset_type;
    new_node->pi_mac_security_vlan_discard = pkt_info->mac_security_vlan_discard;
    new_node->pi_vlan_storm_ctl_ptr = pkt_info->vlan_storm_ctl_ptr;
    new_node->pi_vlan_storm_ctl_en = pkt_info->vlan_storm_ctl_en;
    new_node->pi_l3_span_en = pkt_info->l3_span_en;
    new_node->pi_l3_span_id = pkt_info->l3_span_id;
    new_node->pi_rpf_type = pkt_info->rpf_type;
    new_node->pi_isid_translate_en = pkt_info->isid_translate_en;
    new_node->pi_new_isid = pkt_info->new_isid;
    new_node->pi_fatal_exception = pkt_info->fatal_exception;
    new_node->pi_flow_stats1_valid = pkt_info->flow_stats1_valid;
    new_node->pi_flow_stats1_ptr = pkt_info->flow_stats1_ptr;
    new_node->pi_aps_select_valid1 = pkt_info->aps_select_valid1;
    new_node->pi_aps_select_group_id1 = pkt_info->aps_select_group_id1;
    new_node->pi_aps_select_valid2 = pkt_info->aps_select_valid2;
    new_node->pi_aps_select_group_id2 = pkt_info->aps_select_group_id2;
    new_node->pi_gal_exist = pkt_info->gal_exist;
    new_node->pi_entropy_label_exist = pkt_info->entropy_label_exist;
    new_node->pi_mpls_mep_index = pkt_info->mpls_mep_index;
    new_node->pi_mpls_overwrite_priority = pkt_info->mpls_overwrite_priority;
    new_node->pi_color = pkt_info->color;
    new_node->pi_priority = pkt_info->priority;
    new_node->pi_aps_select_protecting_path0 = pkt_info->aps_select_protecting_path0;
    new_node->pi_aps_select_protecting_path1 = pkt_info->aps_select_protecting_path1;
    new_node->pi_aps_select_protecting_path2 = pkt_info->aps_select_protecting_path2;
    new_node->pi_pbb_check_discard = pkt_info->pbb_check_discard;
    new_node->pi_link_lm_cos_type = pkt_info->link_lm_cos_type;
    new_node->pi_link_lm_type = pkt_info->link_lm_type;
    new_node->pi_link_lm_index_base = pkt_info->link_lm_index_base;
    new_node->pi_link_oam_mep_index = pkt_info->link_oam_mep_index;
    new_node->pi_lm_type0 = pkt_info->lm_type0;
    new_node->pi_lm_type1 = pkt_info->lm_type1;
    new_node->pi_lm_type2 = pkt_info->lm_type2;
    new_node->pi_mpls_lm_cos_type0 = pkt_info->mpls_lm_cos_type0;
    new_node->pi_mpls_lm_cos_type1 = pkt_info->mpls_lm_cos_type1;
    new_node->pi_mpls_lm_cos_type2 = pkt_info->mpls_lm_cos_type2;
    new_node->pi_mpls_lm_cos0 = pkt_info->mpls_lm_cos0;
    new_node->pi_mpls_lm_cos1 = pkt_info->mpls_lm_cos1;
    new_node->pi_mpls_lm_cos2 = pkt_info->mpls_lm_cos2;
    new_node->pi_mpls_lm_base0 = pkt_info->mpls_lm_base0;
    new_node->pi_mpls_lm_base1 = pkt_info->mpls_lm_base1;
    new_node->pi_mpls_lm_base2 = pkt_info->mpls_lm_base2;
    new_node->pi_packet_cos1 = pkt_info->packet_cos1;
    new_node->pi_packet_cos2 = pkt_info->packet_cos2;
    new_node->pi_mpls_lm_type0 = pkt_info->mpls_lm_type0;
    new_node->pi_mpls_lm_type1 = pkt_info->mpls_lm_type1;
    new_node->pi_mpls_lm_type2 = pkt_info->mpls_lm_type2;
    new_node->pi_source_port_isolate_id = pkt_info->src_port_isolate_id;
    new_node->pi_mpls_oam_dest_chip_id = pkt_info->mpls_oam_dest_chipid;
    new_node->pi_link_lm_cos = pkt_info->link_lm_cos;
    new_node->pi_oam_lookup_num = pkt_info->oam_lookup_num;
    new_node->pi_aps_level_for_oam = pkt_info->aps_level_for_oam;
    new_node->pi_mac_isolated_group_id = pkt_info->mac_isolated_groupid;
    new_node->pi_ether_oam_edge_port = pkt_info->ether_oam_edge_port;
    new_node->pi_ecmp_hash = pkt_info->ecmp_hash;
    new_node->pi_ptp_extra_offset = pkt_info->ptp_extra_offset;
    new_node->pi_port_security_exception_en = pkt_info->port_security_exception_en;
    new_node->pr_outer_mac_sa0 = (pas_rslt->l2_s.mac_sa3<<24) | (pas_rslt->l2_s.mac_sa2<<16) | (pas_rslt->l2_s.mac_sa1<<8) | (pas_rslt->l2_s.mac_sa0);
    new_node->pr_outer_mac_sa1 = (pas_rslt->l2_s.mac_sa5<<8) | (pas_rslt->l2_s.mac_sa4);
    new_node->pr_outer_svlan_id = pas_rslt->l2_s.svlan_id;
    new_node->pr_outer_cvlan_id = pas_rslt->l2_s.cvlan_id;
    new_node->pi_exception2_lm_en = pkt_info->exception2_lm_en;
    new_node->pi_exception2_lm_up_en = pkt_info->exception2_lm_up_en;
    new_node->pi_exception2_lm_down_en = pkt_info->exception2_lm_down_en;
    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_IM2PP]));


    return DRV_E_NONE;
}
int32
sim_store_ipe_impi2lm_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_impi2lm_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_rslt1;

     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_IMPI2LM))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_impi2lm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_impi2lm_t));

    new_node->pi_channel_id = inpkt->chan_id;
    new_node->pi_mpls_section_lm_en = pkt_info->mpls_section_lm_en;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    new_node->pi_logic_src_port = pkt_info->logic_src_port;
    new_node->pi_payload_offset = pkt_info->payload_offset;
    new_node->pi_rx_oam_type = pkt_info->rx_oam_type;
    new_node->pi_oam_use_fid = pkt_info->oam_use_fid;
    new_node->pi_user_default_vlan_id = pkt_info->user_default_vlan_id;
    new_node->pi_user_default_cos = pkt_info->user_default_cos;
    new_node->pi_user_default_cfi = pkt_info->user_default_cfi;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_discard_type = pkt_info->discard_type;
    new_node->pi_hard_error = 0;
    new_node->pi_pbb_src_port_type = pkt_info->pbb_src_port_type;
    new_node->pi_exception_en = pkt_info->exception_en;
    new_node->pi_exception_index = pkt_info->exception_index;
    new_node->pi_exception_sub_index = pkt_info->exception_sub_index;
    new_node->pi_default_pcp = pkt_info->default_pcp;
    new_node->pi_default_dei = pkt_info->default_dei;
    new_node->pi_classify_stag_cos = pkt_info->classify_stag_cos;
    new_node->pi_classify_stag_cfi = pkt_info->classify_stag_cfi;
    new_node->pi_classify_ctag_cos = pkt_info->classify_ctag_cos;
    new_node->pi_classify_ctag_cfi = pkt_info->classify_ctag_cfi;
    new_node->pi_global_src_port = pkt_info->global_src_port;
    new_node->pi_deny_bridge = pkt_info->deny_bridge;
    new_node->pi_route_disable = pkt_info->route_disable;
    new_node->pi_payload_packet_type = pkt_info->payload_packet_type;
    new_node->pi_learning_disable = pkt_info->learning_disable;
    new_node->pi_service_acl_qos_en = pkt_info->service_acl_qos_en;
    new_node->pi_vlan_ptr = pkt_info->vlan_ptr;
    new_node->pi_vsi_id = pkt_info->vsi_id;
    new_node->pi_l2_acl_en0 = pkt_info->l2_acl_en0;
    new_node->pi_l2_acl_en1 = pkt_info->l2_acl_en1;
    new_node->pi_l2_acl_en2 = pkt_info->l2_acl_en2;
    new_node->pi_l2_acl_en3 = pkt_info->l2_acl_en3;
    new_node->pi_bridge_en = pkt_info->bridge_en;
    new_node->pi_interface_id = pkt_info->interface_id;
    new_node->pi_l2_acl_label = pkt_info->l2_acl_label;
    new_node->pi_routed_port = pkt_info->routed_port;
    new_node->pi_ttl_update = pkt_info->ttl_update;
    new_node->pi_force_ipv4_lookup = pkt_info->force_ipv4_lookup;
    new_node->pi_force_ipv6_lookup = pkt_info->force_ipv6_lookup;
    new_node->pi_force_acl_qos_ipv4_to_mac_key = pkt_info->force_acl_qos_ipv4_to_mac_key;
    new_node->pi_force_acl_qos_ipv6_to_mac_key = pkt_info->force_acl_qos_ipv6_to_mac_key;
    new_node->pi_trill_en = pkt_info->trill_en;
    new_node->pi_fcoe_en = pkt_info->fcoe_en;
    new_node->pi_fcoe_rpf_en = pkt_info->fcoe_rpf_en;
    new_node->pi_acl_port_num = pkt_info->acl_port_num;
    new_node->pi_l2_ipv6_acl_en0 = pkt_info->l2_ipv6_acl_en0;
    new_node->pi_l2_ipv6_acl_en1 = pkt_info->l2_ipv6_acl_en1;
    new_node->pi_mac_key_use_label = pkt_info->mac_key_use_label;
    new_node->pi_ipv4_key_use_label = pkt_info->ipv4_key_use_label;
    new_node->pi_ipv6_key_use_label = pkt_info->ipv6_key_use_label;
    new_node->pi_mpls_key_use_label = pkt_info->mpls_key_use_label;
    new_node->pi_bcast_mac_address = pkt_info->bcast_mac_address;
    new_node->pi_is_port_mac = pkt_info->is_port_mac;
    new_node->pi_source_cos = pkt_info->source_cos;
    new_node->pi_source_cfi = pkt_info->source_cfi;
    new_node->pi_svlan_id = pkt_info->svlan_id;
    new_node->pi_cvlan_id = pkt_info->cvlan_id;
    new_node->pi_l3_acl_label = pkt_info->l3_acl_label;
    new_node->pi_ptp_en = pkt_info->ptp_en;
    new_node->pi_l3_acl_routed_only = pkt_info->l3_acl_routed_only;
    new_node->pi_l3_acl_en0 = pkt_info->l3_acl_en0;
    new_node->pi_l3_acl_en1 = pkt_info->l3_acl_en1;
    new_node->pi_l3_acl_en2 = pkt_info->l3_acl_en2;
    new_node->pi_l3_acl_en3 = pkt_info->l3_acl_en3;
    new_node->pi_l3_ipv6_acl_en0 = pkt_info->l3_ipv6_acl_en0;
    new_node->pi_l3_ipv6_acl_en1 = pkt_info->l3_ipv6_acl_en1;
    new_node->pi_vrf_id = pkt_info->vrf_id;
    new_node->pi_l3_if_type = pkt_info->l3_if_type;
    new_node->pi_v4_ucast_sa_type = pkt_info->v4_ucast_sa_type;
    new_node->pi_v4_ucast_en = pkt_info->v4_ucast_en;
    new_node->pi_v4_mcast_en = pkt_info->v4_mcast_en;
    new_node->pi_v6_ucast_en = pkt_info->v6_ucast_en;
    new_node->pi_v6_mcast_en = pkt_info->v6_mcast_en;
    new_node->pi_v6_ucast_sa_type = pkt_info->v6_ucast_sa_type;
    new_node->pi_pbr_label = pkt_info->pbr_label;
    new_node->pi_ether_lm_valid = pkt_info->ether_lm_valid;
    new_node->pi_ether_oam_discard = pkt_info->ether_oam_discard;
    new_node->pi_stp_state = pkt_info->stp_state;
    new_node->pi_is_router_mac = pkt_info->is_router_mac;
    new_node->pi_is_mpls_switched = pkt_info->is_mpls_switched;
    new_node->pi_is_decap = pkt_info->is_decap;
    new_node->pi_inner_packet_lookup = pkt_info->inner_packet_lookup;
    new_node->pi_vsi_learning_disable = pkt_info->vsi_learning_disable;
    new_node->pi_tunnel_ptp_en = pkt_info->tunnel_ptp_en;
    new_node->pi_acl_qos_use_outer_info = pkt_info->acl_qos_use_outer_info;
    new_node->pi_use_default_vlan_tag = pkt_info->use_default_vlan_tag;
    new_node->pi_link_or_section_oam = pkt_info->link_or_section_OAM;
    new_node->pi_route_lookup_mode = pkt_info->route_lookup_mode;
    new_node->pi_second_parser = pkt_info->second_parser;
    new_node->pi_pip_bypass_learning = pkt_info->pip_bypass_learning;
    new_node->pi_mpls_mep_check = pkt_info->mpls_mep_check;
    new_node->pi_inner_vsi_id_valid = pkt_info->inner_vsi_id_valid;
    new_node->pi_inner_vsi_id = pkt_info->inner_vsi_id;
    new_node->pi_mcast_mac_address = pkt_info->mcast_mac_address;
    new_node->pi_force_parser = pkt_info->force_parser;
    new_node->pi_packet_ttl = pkt_info->packet_ttl;
    new_node->pi_packet_cos0 = pkt_info->packet_cos0;
    if ((pkt_info->lm_type0 !=0) || (pkt_info->lm_type1 !=0) || (pkt_info->lm_type2 !=0) )
    {
        new_node->pi_lm_type_is_not0 = (pkt_info->lm_type0 || pkt_info->lm_type1 || pkt_info->lm_type2);
    }
    new_node->pi_svlan_id_valid = pkt_info->svlan_id_valid;
    new_node->pi_cvlan_id_valid = pkt_info->cvlan_id_valid;
    new_node->pi_inner_logic_src_port_valid = pkt_info->inner_logic_src_port_valid;
    new_node->pi_inner_logic_src_port = pkt_info->inner_logic_src_port;
    new_node->pi_fid_type = pkt_info->fid_type;
    new_node->pi_fatal_exception_valid = pkt_info->fatal_exception_valid;
    new_node->pi_force_ipv6_key = pkt_info->force_ipv6_key;
    new_node->pi_app_data_valid0 = pas_rslt->l4_s.app_data_valid0;
    new_node->pi_app_data_valid1 = pas_rslt->l4_s.app_data_valid1;
    new_node->pi_app_data = pas_rslt->l4_s.app_data;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_IMPI2LM]));

    return DRV_E_NONE;
}
int32
sim_store_ipe_impr2lm_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_impr2lm_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_rslt1;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_IMPR2LM))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_impr2lm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_impr2lm_t));


    new_node->pr_parser_length_error = pas_rslt->parser_length_error;
    new_node->pr_layer2_offset = pas_rslt->layer2_offset;
    new_node->pr_layer3_offset = pas_rslt->l2_s.layer3_offset;
    new_node->pr_layer4_offset = pas_rslt->l3_s.layer4_offset;
    new_node->pr_layer4_type = pas_rslt->layer4_type;
    new_node->pr_layer4_user_type = pas_rslt->l4_s.layer4_user_type;
    new_node->pr_gre_key = pas_rslt->l4_s.gre_bfd_ptp.gre_key;
    new_node->pr_ttl = pas_rslt->l3_s.ttl;
    new_node->pr_is_isatap_interface = pas_rslt->l4_s.isatap_ptp_ver.is_isatap_interface;
    new_node->pr_rid = pas_rslt->l4_s.rid_ptp_bfd.rid_t.rid;
    new_node->pr_mac_ecmp_hash = pas_rslt->l2_s.mac_ecmp_hash;
    new_node->pr_ip_ecmp_hash = pas_rslt->l3_s.ip_ecmp_hash;
    new_node->pr_udp_ptp_correction_field = pas_rslt->l4_s.ptp_oam_ach.udp_ptp_correction_field_63_32;
    new_node->pr_cn_tag_valid = pas_rslt->l2_s.cn_tag_valid;
    new_node->pr_cn_flow_id = pas_rslt->l2_s.cn_flow_id;
    new_node->pr_layer2_header_protocol = pas_rslt->l2_s.layer2_header_protocol;
    new_node->pr_layer3_header_protocol = pas_rslt->l3_s.layer3_header_protocol;
    new_node->pr_stag_cos = pas_rslt->l2_s.stag_cos;
    new_node->pr_stag_cfi = pas_rslt->l2_s.stag_cfi;
    new_node->pr_ctag_cos = pas_rslt->l2_s.ctag_cos;
    new_node->pr_ctag_cfi = pas_rslt->l2_s.ctag_cfi;
    new_node->pr_layer3_type = pas_rslt->layer3_type;
    new_node->pr_mac_da0 = (pas_rslt->l2_s.mac_da3 << 24) | (pas_rslt->l2_s.mac_da2 << 16) | (pas_rslt->l2_s.mac_da1 << 8) | (pas_rslt->l2_s.mac_da0);
    new_node->pr_mac_da1 = (pas_rslt->l2_s.mac_da5 << 8) | (pas_rslt->l2_s.mac_da4);
    new_node->pr_layer2_type = pas_rslt->layer2_type;
    new_node->pr_mac_sa0 = (pas_rslt->l2_s.mac_sa3 << 24) | (pas_rslt->l2_s.mac_sa2 << 16) | (pas_rslt->l2_s.mac_sa1 << 8) | (pas_rslt->l2_s.mac_sa0);
    new_node->pr_mac_sa1 = (pas_rslt->l2_s.mac_sa5 << 8) | (pas_rslt->l2_s.mac_sa4);
    new_node->pr_ip_header_error = pas_rslt->l3_s.ip_header_error;
    new_node->pr_is_tcp = pas_rslt->l4_s.is_tcp;
    new_node->pr_is_udp = pas_rslt->l4_s.is_udp;
    new_node->pr_ip_options = pas_rslt->l3_s.ip_options;
    new_node->pr_frag_info = pas_rslt->l3_s.frag_info;
    new_node->pr_tos = pas_rslt->l3_s.tos.ip_tos;
    new_node->pr_l4_info_mapped = pas_rslt->l4_s.layer4_info_mapped;
    new_node->pr_l4_dest_port = pas_rslt->l4_s.l4_dst_port.l4_dest_port;
    new_node->pr_l4_source_port = pas_rslt->l4_s.l4_src_port.l4_source_port;
    new_node->pr_ipv6_flow_label = pas_rslt->l3_s.ipv6_flow_label;
    new_node->pr_ip_da0 = pas_rslt->l3_s.ip_da.ipv6.ipda_31_0;
    new_node->pr_ip_da1 = pas_rslt->l3_s.ip_da.ipv6.ipda_63_32;
    new_node->pr_ip_da2 = pas_rslt->l3_s.ip_da.ipv6.ipda_95_64;
    new_node->pr_ip_da3 = pas_rslt->l3_s.ip_da.ipv6.ipda_127_96;
    new_node->pr_ip_sa0 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_31_0;
    new_node->pr_ip_sa1 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_63_32;
    new_node->pr_ip_sa2 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_95_64;
    new_node->pr_ip_sa3 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_127_96;
    new_node->pr_cvlan_id = pas_rslt->l2_s.cvlan_id;
    new_node->pr_svlan_id = pas_rslt->l2_s.svlan_id;
    new_node->pr_cvlan_id_valid = pas_rslt->l2_s.cvlan_id_valid;
    new_node->pr_svlan_id_valid = pas_rslt->l2_s.svlan_id_valid;
    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_IMPR2LM]));


    return DRV_E_NONE;
}
int32
sim_store_ipe_lr2fw_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_lr2fw_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_LR2FW))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_lr2fw_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_lr2fw_t));

    new_node->pi_next_hop_ptr_valid = pkt_info->next_hop_ptr_valid;
    new_node->pi_ad_next_hop_ptr = pkt_info->ad_next_hop_ptr;
    new_node->pi_ad_dest_map = pkt_info->ad_dest_map;
    new_node->pi_ad_length_adjust_type = pkt_info->ad_length_adjust_type;
    new_node->pi_ad_critical_packet = pkt_info->ad_critical_packet;
    new_node->pi_ad_next_hop_ext = pkt_info->ad_next_hop_ext;
    new_node->pi_ad_send_local_phy_port = pkt_info->ad_send_local_phy_port;
    new_node->pi_ad_aps_type = pkt_info->ad_aps_type;
    new_node->pi_ad_speed = pkt_info->ad_speed;
    new_node->pi_ds_fwd_ptr_valid = pkt_info->ds_fwd_ptr_valid;
    if (pkt_info->ds_fwd_ptr == 0xffff)
    {
        new_node->pi_ds_fwd_ptr_is_maximum = 1;

    }
    else
    {
        new_node->pi_ds_fwd_ptr_is_maximum = 0;
    }
    new_node->pi_fatal_exception_valid = pkt_info->fatal_exception_valid;
    new_node->pi_fatal_exception = pkt_info->fatal_exception;
    new_node->pi_aps_select_valid0 = pkt_info->aps_select_valid0;
    new_node->pi_aps_select_group_id0 = pkt_info->aps_select_group_id0;
    new_node->pi_aps_select_valid1 = pkt_info->aps_select_valid1;
    new_node->pi_aps_select_group_id1 = pkt_info->aps_select_group_id1;
    new_node->pi_aps_select_valid2 = pkt_info->aps_select_valid2;
    new_node->pi_aps_select_group_id2 = pkt_info->aps_select_group_id2;
    new_node->pi_aps_select_protecting_path0 = pkt_info->aps_select_protecting_path0;
    new_node->pi_aps_select_protecting_path1 = pkt_info->aps_select_protecting_path1;
    new_node->pi_aps_select_protecting_path2 = pkt_info->aps_select_protecting_path2;
    new_node->pi_mac_known = pkt_info->mac_known;
    new_node->pi_storm_ctl_exception_en = pkt_info->storm_ctl_exception_en;
    new_node->pi_source_port_isolate_id = pkt_info->src_port_isolate_id;
    new_node->pi_header_hash = pkt_info->header_hash;
    new_node->pi_mux_destination_valid = pkt_info->mux_destination_valid;
    new_node->pi_logic_src_port = pkt_info->logic_src_port;
    new_node->pi_pbb_src_port_type = pkt_info->pbb_src_port_type;
    new_node->pi_global_src_port = pkt_info->global_src_port;
    new_node->pi_payload_packet_type = pkt_info->payload_packet_type;
    new_node->pi_cvlan_id = pkt_info->cvlan_id;
    new_node->pi_fid = pkt_info->fid;
    new_node->pi_svlan_id = pkt_info->svlan_id;
    new_node->pi_ptp_transparent_clock_en = pkt_info->ptp_transparent_clock_en;
    new_node->pi_qcn_port_id = pkt_info->qcn_port_id;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_LR2FW]));


    return DRV_E_NONE;
}
int32
sim_store_ipe_lm2pp_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_lm2pp_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t *pas_rslt1 = (parsing_result_t *)pkt_info->parser_rslt1;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_LM2PP))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_lm2pp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_lm2pp_t));

    new_node->pi_channel_id = inpkt->chan_id;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    new_node->pi_logic_src_port = pkt_info->logic_src_port;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_discard_type = pkt_info->discard_type;
    new_node->pi_hard_error = 0;
    new_node->pi_pbb_src_port_type = pkt_info->pbb_src_port_type;
    new_node->pi_exception_en = pkt_info->exception_en;
    new_node->pi_exception_index = pkt_info->exception_index;
    new_node->pi_exception_sub_index = pkt_info->exception_sub_index;
    new_node->pi_default_pcp = pkt_info->default_pcp;
    new_node->pi_default_dei = pkt_info->default_dei;
    new_node->pi_classify_stag_cos = pkt_info->classify_stag_cos;
    new_node->pi_classify_stag_cfi = pkt_info->classify_stag_cfi;
    new_node->pi_classify_ctag_cos = pkt_info->classify_ctag_cos;
    new_node->pi_classify_ctag_cfi = pkt_info->classify_ctag_cfi;
    new_node->pi_global_src_port = pkt_info->global_src_port;
    new_node->pi_deny_bridge = pkt_info->deny_bridge;
    new_node->pi_payload_packet_type = pkt_info->payload_packet_type;
    new_node->pi_vlan_ptr = pkt_info->vlan_ptr;
    new_node->pi_outer_vsi_id = pkt_info->outer_vsi_id;
    new_node->pi_interface_id = pkt_info->interface_id;
    new_node->pi_bcast_mac_address = pkt_info->bcast_mac_address;
    new_node->pi_is_port_mac = pkt_info->is_port_mac;
    new_node->pi_cvlan_id = pkt_info->cvlan_id;
    new_node->pi_self_address = pkt_info->self_address;
    new_node->pi_l3_if_type = pkt_info->l3_if_type;
    new_node->pi_ether_oam_discard = pkt_info->ether_oam_discard;
    new_node->pi_stp_state = pkt_info->stp_state;
    new_node->pi_is_mpls_switched = pkt_info->is_mpls_switched;
    new_node->pi_is_decap = pkt_info->is_decap;
    new_node->pi_inner_packet_lookup = pkt_info->inner_packet_lookup;
    new_node->pi_link_or_section_oam = pkt_info->link_or_section_OAM;
    new_node->pi_fid = pkt_info->fid;
    new_node->pi_ptp_en = pkt_info->ptp_en;
    new_node->pi_force_bridge = pkt_info->force_bridge;
    new_node->pi_bridge_packet = pkt_info->bridge_packet;
    new_node->pi_acl_en0 = pkt_info->acl_en0;
    new_node->pi_acl_en1 = pkt_info->acl_en1;
    new_node->pi_acl_en2 = pkt_info->acl_en2;
    new_node->pi_acl_en3 = pkt_info->acl_en3;
    new_node->pi_acl_hash_lookup_en = pkt_info->acl_hash_lookup_en;
    new_node->pi_layer3_da_lookup_mode = pkt_info->layer3_da_lookup_mode;
    new_node->pi_is_ipv4_ucast = pkt_info->is_ipv4_ucast;
    new_node->pi_is_ipv4_mcast = pkt_info->is_ipv4_mcast;
    new_node->pi_is_ipv6_ucast = pkt_info->is_ipv6_ucast;
    new_node->pi_is_ipv6_mcast = pkt_info->is_ipv6_mcast;
    new_node->pi_is_fcoe = pkt_info->is_fcoe;
    new_node->pi_is_trill_ucast = pkt_info->is_trill_ucast;
    new_node->pi_is_trill_mcast = pkt_info->is_trill_mcast;
    new_node->pi_is_ipv4_ucast_rpf = pkt_info->is_ipv4_ucast_rpf;
    new_node->pi_is_ipv6_ucast_rpf = pkt_info->is_ipv6_ucast_rpf;
    new_node->pi_is_ipv4_ucast_nat = pkt_info->is_ipv4_ucast_nat;
    new_node->pi_is_ipv6_ucast_nat = pkt_info->is_ipv6_ucast_nat;
    new_node->pi_is_ipv4_pbr = pkt_info->is_ipv4_pbr;
    new_node->pi_is_ipv6_pbr = pkt_info->is_ipv6_pbr;
    new_node->pi_is_fcoe_rpf = pkt_info->is_fcoe_rpf;
    new_node->pi_layer3_sa_lookup_mode = pkt_info->layer3_sa_lookup_mode;
    new_node->pi_lm_lookup_en0 = pkt_info->lm_lookup_en0;
    new_node->pi_packet_cos0 = pkt_info->packet_cos0;
    new_node->pi_isatap_check_ok = pkt_info->isatap_check_ok;
    new_node->pi_ip_header_error = pkt_info->ip_header_error;
    new_node->pi_igmp_packet = pkt_info->igmp_packet;
    new_node->pi_ipv4_mcast_address = pkt_info->ipv4_mcast_address;
    new_node->pi_ipv6_mcast_address = pkt_info->ipv6_mcast_address;
    new_node->pi_c_mac_ecmp_hash = pkt_info->cmac_ecmp_hash;
    new_node->pi_c_mac_header_hash = pkt_info->cmac_header_hash;
    new_node->pi_mac_ecmp_hash = pkt_info->mac_ecmp_hash;
    new_node->pi_ecn_en = pkt_info->ecn_en;
    new_node->pi_ecn_priority_en = pkt_info->ecn_priority_en;
    new_node->pi_ecn_aware = pkt_info->ecn_aware;
    new_node->pi_bfd_single_hop_ttl_match = pkt_info->bfd_single_hop_ttl_match;
    new_node->pi_is_mpls_packet = pkt_info->is_mpls_packet;
    new_node->pi_trill_version_match = pkt_info->trill_version_match;
    new_node->pi_ip_martian_address = pkt_info->ip_martian_address;
    new_node->pi_ip_link_scope_address = pkt_info->ip_link_scope_address;
    new_node->pi_is_ipv4_icmp_err_msg = pkt_info->is_ipv4_icmp_err_msg;
    new_node->pi_is_ipv6_icmp_err_msg = pkt_info->is_ipv6_icmp_err_msg;
    new_node->pi_ipv4_mcast_address_check_failure = pkt_info->ipv4_mcast_address_check_failure;
    new_node->pi_ipv6_mcast_address_check_failure = pkt_info->ipv6_mcast_address_check_failure;
    new_node->pi_unknown_gre_protocol = pkt_info->unknown_gre_protocol;
    new_node->pi_gre_payload_packet_type = pkt_info->gre_payload_packet_type;
    new_node->pi_classify_tos = pkt_info->classify_tos;
    new_node->pi_classify_layer3_type = pkt_info->classify_layer3_type;
    new_node->pi_classify_source_cos = pkt_info->classify_source_cos;
    new_node->pi_classify_source_cfi = pkt_info->classify_source_cfi;
    new_node->pi_layer3_exception = pkt_info->layer3_exception;
    new_node->pi_layer3_exception_sub_index = pkt_info->layer3_exception_sub_index;
    new_node->pi_mac_ip_lookup_en = pkt_info->mac_ip_lookup_en;
    new_node->pi_mac_da_lookup_en = pkt_info->mac_da_lookup_en;
    new_node->pi_mac_sa_lookup_en = pkt_info->mac_sa_lookup_en;
    new_node->pi_mac_tcam_lookup_en = pkt_info->mac_tcam_lookup_en;
    new_node->pi_mac_hash_lookup_en = pkt_info->mac_hash_lookup_en;
    new_node->pi_oam_lookup_en = pkt_info->oam_lookup_en;
    new_node->pi_outer_mac_sa_lookup_en = pkt_info->outer_mac_sa_lookup_en;
    new_node->pi_payload_offset = pkt_info->payload_offset;
    new_node->pi_rx_oam_type = pkt_info->rx_oam_type;
    new_node->pi_lm_lookup_type = pkt_info->lm_lookup_type;
    new_node->pi_svlan_id = pkt_info->svlan_id;
    new_node->pi_source_cos = pkt_info->source_cos;
    new_node->pi_source_cfi = pkt_info->source_cfi;
    new_node->pi_packet_ttl = pkt_info->packet_ttl;
    new_node->pi_outer_learning_logic_src_port = pkt_info->outer_learning_logic_src_port;
    new_node->pi_is_icmp = pkt_info->is_icmp;
    new_node->pi_fatal_exception_valid = pkt_info->fatal_exception_valid;
    new_node->pi_is_all_rbridges_mac = pkt_info->is_all_rbridge_address;
    new_node->pr_layer2_offset = pas_rslt->layer2_offset;
    new_node->pr_layer3_offset = pas_rslt->l2_s.layer3_offset;
    new_node->pr_layer4_offset = pas_rslt->l3_s.layer4_offset;
    new_node->pr_svlan_id_valid = pas_rslt->l2_s.svlan_id_valid;
    new_node->pr_cvlan_id_valid = pas_rslt->l2_s.cvlan_id_valid;
    new_node->pr_layer4_type = pas_rslt->layer4_type;
    new_node->pr_layer4_user_type = pas_rslt->l4_s.layer4_user_type;
    new_node->pr_ether_oam_level = pas_rslt->l3_s.ip_da.eth_oam.eth_oam_level;
    new_node->pr_tos = pas_rslt->l3_s.tos.ip_tos;
    new_node->pr_is_isatap_interface = pas_rslt->l4_s.isatap_ptp_ver.is_isatap_interface;
    new_node->pr_ip_ecmp_hash = pas_rslt->l3_s.ip_ecmp_hash;
    new_node->pr_mac_ecmp_hash = pas_rslt->l2_s.mac_ecmp_hash;
    new_node->pr_stag_cos = pas_rslt->l2_s.stag_cos;
    new_node->pr_stag_cfi = pas_rslt->l2_s.stag_cfi;
    new_node->pr_ctag_cos = pas_rslt->l2_s.ctag_cos;
    new_node->pr_ctag_cfi = pas_rslt->l2_s.ctag_cfi;
    new_node->pr_layer3_type = pas_rslt->layer3_type;
    new_node->pr_mac_da_bit40 = pas_rslt->l2_s.mac_da5&0x1;
    new_node->pr_mac_sa0 = (pas_rslt->l2_s.mac_sa3 << 24) | (pas_rslt->l2_s.mac_sa2 << 16) | (pas_rslt->l2_s.mac_sa1 << 8) | (pas_rslt->l2_s.mac_sa0);
    new_node->pr_mac_sa1 = (pas_rslt->l2_s.mac_sa5 << 8) | (pas_rslt->l2_s.mac_sa4);
    new_node->pr_ip_options = pas_rslt->l3_s.ip_options;
    new_node->pr_cvlan_id = pas_rslt->l2_s.cvlan_id;
    new_node->pr_svlan_id = pas_rslt->l2_s.svlan_id;
    new_node->pr_cn_tag_valid = pas_rslt->l2_s.cn_tag_valid;
    new_node->pr_cn_flow_id = pas_rslt->l2_s.cn_flow_id;
    new_node->pi_app_data_valid = pkt_info->app_data_valid;
    new_node->pr_app_data = pas_rslt1->l4_s.app_data;
    new_node->pr_y1731_oam_opcode =  pas_rslt->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code;
    new_node->pr_ip_sa95_to00 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_31_0;
    new_node->pr_ip_sa95_to01 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_63_32;
    new_node->pr_ip_sa95_to02 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_95_64;
    new_node->pr_ether_oam_opcode = pas_rslt->l3_s.ip_da.eth_oam.eth_oam_op_code;
    new_node->pr_gre_options = (pas_rslt->l4_s.l4_src_port.gre_flags >> 12) & 0xF;
    new_node->pr_is_esadi = pas_rslt->l3_s.ip_da.trill.is_esadi;
    new_node->pr_is_trill_channel = pas_rslt->l3_s.ip_da.trill.is_trill_channel;
    new_node->pr_ptp_version = pas_rslt->l3_s.ip_da.ptp.ptp_version;
    new_node->pr_udp_ptp_version = (pas_rslt->l4_s.isatap_ptp_ver.udp_ptp_version1 << 1)
                                   | pas_rslt->l4_s.rid_ptp_bfd.ptp_msg_type.udp_ptp_version0;
    new_node->pr_ptp_message_type = pas_rslt->l3_s.ip_da.ptp.ptp_message_type;
    new_node->pr_udp_ptp_message_type = pas_rslt->l4_s.rid_ptp_bfd.ptp_msg_type.udp_ptp_message_type;
    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_LM2PP]));


    return DRV_E_NONE;
}
int32
sim_store_ipe_om2fw_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_om2fw_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_rslt;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_OM2FW))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_om2fw_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_om2fw_t));


    new_node->pi_channel_id = inpkt->chan_id;
    new_node->pi_hard_error = 0;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_mux_length_type = pkt_info->mux_length_type;
    new_node->pi_from_cpu_or_oam = pkt_info->from_cpu_or_oam;
    new_node->pi_acl_dscp_valid = pkt_info->acl_dscp_valid;
    new_node->pi_payload_offset = pkt_info->payload_offset;
    new_node->pi_packet_length_adjust = pkt_info->packet_length_adjust;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_discard_type = pkt_info->discard_type;
    new_node->pi_packet_length = pkt_info->packet_length;
    new_node->pi_exception_en = pkt_info->exception_en;
    new_node->pi_exception_index = pkt_info->exception_index;
    new_node->pi_exception_sub_index = pkt_info->exception_sub_index;
    new_node->pi_storm_ctl_drop = pkt_info->storm_ctl_drop;
    new_node->pi_color = pkt_info->color;
    new_node->pi_priority = pkt_info->priority;
    new_node->pi_mark_drop = pkt_info->mark_drop;
    new_node->pi_new_color = pkt_info->new_color;
    new_node->pi_is_ipv4 = pkt_info->is_ipv4;
    new_node->pr_layer3_offset = pas_rslt->l2_s.layer3_offset;
    new_node->pi_svlan_tag_operation_valid = pkt_info->svlan_tag_operation_valid;
    new_node->pi_cvlan_tag_operation_valid = pkt_info->cvlan_tag_operation_valid;
    new_node->pi_isid_translate_en = pkt_info->isid_translate_en;
    new_node->pi_flow_stats1_valid = pkt_info->flow_stats1_valid;
    new_node->pi_flow_stats1_ptr = pkt_info->flow_stats1_ptr;
    new_node->pi_flow_stats2_valid = pkt_info->flow_stats2_valid;
    new_node->pi_flow_stats2_ptr = pkt_info->flow_stats2_ptr;
    new_node->pi_flow_stats0_valid = pkt_info->flow_stats0_valid;
    new_node->pi_flow_stats0_ptr = pkt_info->flow_stats0_ptr;
    new_node->pi_random_log_en = pkt_info->random_log_en;
    new_node->pi_mpls_label_space_valid = pkt_info->mpls_label_space_valid;
    new_node->pi_mpls_label_space = pkt_info->mpls_label_space;
    new_node->pi_aps_level_for_oam = pkt_info->aps_level_for_oam;
    new_node->pi_mac_isolated_group_id = pkt_info->mac_isolated_groupid;
    new_node->pi_link_oam_mep_index = pkt_info->link_oam_mep_index;
    new_node->pi_source_cos = pkt_info->source_cos;
    new_node->pi_share_type = pkt_info->share_type;
    /*new_node->pi_share_fields0 = pkt_info->share_fields0;
    new_node->pi_share_fields1 = pkt_info->share_fields1;
    new_node->pi_share_fields2 = pkt_info->share_fields2;
    new_node->pi_share_fields3 = pkt_info->share_fields3;*/
    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_OM2FW]));


    return DRV_E_NONE;
}

int32
sim_store_ipe_pr2im_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_pr2im_t *new_node;
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_rslt;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_PR2IM))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_pr2im_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_pr2im_t));

    new_node->pr_app_data_valid0 = pas_rslt->l4_s.app_data_valid0;
    new_node->pr_app_data_valid1 = pas_rslt->l4_s.app_data_valid1;
    new_node->pr_app_data = pas_rslt->l4_s.app_data;
    new_node->pr_ip_length = pas_rslt->l3_s.ip_length;
    new_node->pr_l4_error_bits = pas_rslt->l4_error_bits;
    new_node->pr_parser_length_error = pas_rslt->parser_length_error;
    new_node->pr_layer2_offset = pas_rslt->layer2_offset;
    new_node->pr_layer3_offset = pas_rslt->l2_s.layer3_offset;
    new_node->pr_layer4_offset = pas_rslt->l3_s.layer4_offset;
    new_node->pr_layer4_type = pas_rslt->layer4_type;
    new_node->pr_layer4_user_type = pas_rslt->l4_s.layer4_user_type;
    new_node->pr_gre_key = pas_rslt->l4_s.gre_bfd_ptp.gre_key;
    new_node->pr_ttl = pas_rslt->l3_s.ttl;
    new_node->pr_is_isatap_interface = pas_rslt->l4_s.isatap_ptp_ver.is_isatap_interface;
    new_node->pr_rid = pas_rslt->l4_s.rid_ptp_bfd.rid_t.rid;
    new_node->pr_mac_ecmp_hash = pas_rslt->l2_s.mac_ecmp_hash;
    new_node->pr_ip_ecmp_hash = pas_rslt->l3_s.ip_ecmp_hash;
    new_node->pr_udp_ptp_correction_field = pas_rslt->l4_s.ptp_oam_ach.udp_ptp_correction_field_63_32;
    new_node->pr_cn_tag_valid = pas_rslt->l2_s.cn_tag_valid;
    new_node->pr_cn_flow_id = pas_rslt->l2_s.cn_flow_id;
    new_node->pr_layer2_header_protocol = pas_rslt->l2_s.layer2_header_protocol;
    new_node->pr_layer3_header_protocol = pas_rslt->l3_s.layer3_header_protocol;
    new_node->pr_stag_cos = pas_rslt->l2_s.stag_cos;
    new_node->pr_stag_cfi = pas_rslt->l2_s.stag_cfi;
    new_node->pr_ctag_cos = pas_rslt->l2_s.ctag_cos;
    new_node->pr_ctag_cfi = pas_rslt->l2_s.ctag_cfi;
    new_node->pr_layer3_type = pas_rslt->layer3_type;
    new_node->pr_mac_da0 = (pas_rslt->l2_s.mac_da3 << 24) | (pas_rslt->l2_s.mac_da2 << 16) | (pas_rslt->l2_s.mac_da1 << 8) | (pas_rslt->l2_s.mac_da0);
    new_node->pr_mac_da1 = (pas_rslt->l2_s.mac_da5 << 8) | (pas_rslt->l2_s.mac_da4);
    new_node->pr_layer2_type = pas_rslt->layer2_type;
    new_node->pr_mac_sa0 = (pas_rslt->l2_s.mac_sa3 << 24) | (pas_rslt->l2_s.mac_sa2 << 16) | (pas_rslt->l2_s.mac_sa1 << 8) | (pas_rslt->l2_s.mac_sa0);
    new_node->pr_mac_sa1 = (pas_rslt->l2_s.mac_sa5 << 8) | (pas_rslt->l2_s.mac_sa4);
    new_node->pr_ip_header_error = pas_rslt->l3_s.ip_header_error;
    new_node->pr_is_tcp = pas_rslt->l4_s.is_tcp;
    new_node->pr_is_udp = pas_rslt->l4_s.is_udp;
    new_node->pr_ip_options = pas_rslt->l3_s.ip_options;
    new_node->pr_frag_info = pas_rslt->l3_s.frag_info;
    new_node->pr_tos = pas_rslt->l3_s.tos.ip_tos;
    new_node->pr_l4_info_mapped = pas_rslt->l4_s.layer4_info_mapped;
    new_node->pr_l4_dest_port = pas_rslt->l4_s.l4_dst_port.l4_dest_port;
    new_node->pr_l4_source_port = pas_rslt->l4_s.l4_src_port.l4_source_port;
    new_node->pr_ipv6_flow_label = pas_rslt->l3_s.ipv6_flow_label;
    new_node->pr_ip_da0 = pas_rslt->l3_s.ip_da.ipv6.ipda_31_0;
    new_node->pr_ip_da1 = pas_rslt->l3_s.ip_da.ipv6.ipda_63_32;
    new_node->pr_ip_da2 = pas_rslt->l3_s.ip_da.ipv6.ipda_95_64;
    new_node->pr_ip_da3 = pas_rslt->l3_s.ip_da.ipv6.ipda_127_96;
    new_node->pr_ip_sa0 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_31_0;
    new_node->pr_ip_sa1 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_63_32;
    new_node->pr_ip_sa2 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_95_64;
    new_node->pr_ip_sa3 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_127_96;
    new_node->pr_cvlan_id = pas_rslt->l2_s.cvlan_id;
    new_node->pr_svlan_id = pas_rslt->l2_s.svlan_id;
    new_node->pr_cvlan_id_valid = pas_rslt->l2_s.cvlan_id_valid;
    new_node->pr_svlan_id_valid = pas_rslt->l2_s.svlan_id_valid;
    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_PR2IM]));


    return DRV_E_NONE;
}
int32
sim_store_ipe_pr2lm_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_pr2lm_t *new_node;
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_rslt;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_PR2LM))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_pr2lm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_pr2lm_t));

    new_node->pr_parser_length_error = pas_rslt->parser_length_error;
    new_node->pr_layer2_offset = pas_rslt->layer2_offset;
    new_node->pr_layer3_offset = pas_rslt->l2_s.layer3_offset;
    new_node->pr_layer4_offset = pas_rslt->l3_s.layer4_offset;
    new_node->pr_layer4_type = pas_rslt->layer4_type;
    new_node->pr_layer4_user_type = pas_rslt->l4_s.layer4_user_type;
    new_node->pr_gre_key = pas_rslt->l4_s.gre_bfd_ptp.gre_key;
    new_node->pr_ttl = pas_rslt->l3_s.ttl;
    new_node->pr_is_isatap_interface = pas_rslt->l4_s.isatap_ptp_ver.is_isatap_interface;
    new_node->pr_rid = pas_rslt->l4_s.rid_ptp_bfd.rid_t.rid;
    new_node->pr_mac_ecmp_hash = pas_rslt->l2_s.mac_ecmp_hash;
    new_node->pr_ip_ecmp_hash = pas_rslt->l3_s.ip_ecmp_hash;
    new_node->pr_udp_ptp_correction_field = pas_rslt->l4_s.ptp_oam_ach.udp_ptp_correction_field_63_32;
    new_node->pr_cn_tag_valid = pas_rslt->l2_s.cn_tag_valid;
    new_node->pr_cn_flow_id = pas_rslt->l2_s.cn_flow_id;
    new_node->pr_layer2_header_protocol = pas_rslt->l2_s.layer2_header_protocol;
    new_node->pr_layer3_header_protocol = pas_rslt->l3_s.layer3_header_protocol;
    new_node->pr_stag_cos = pas_rslt->l2_s.stag_cos;
    new_node->pr_stag_cfi = pas_rslt->l2_s.stag_cfi;
    new_node->pr_ctag_cos = pas_rslt->l2_s.ctag_cos;
    new_node->pr_ctag_cfi = pas_rslt->l2_s.ctag_cfi;
    new_node->pr_layer3_type = pas_rslt->layer3_type;
    new_node->pr_mac_da0 = (pas_rslt->l2_s.mac_da3 << 24) | (pas_rslt->l2_s.mac_da2 << 16) | (pas_rslt->l2_s.mac_da1 << 8) | (pas_rslt->l2_s.mac_da0);
    new_node->pr_mac_da1 = (pas_rslt->l2_s.mac_da5 << 8) | (pas_rslt->l2_s.mac_da4);
    new_node->pr_layer2_type = pas_rslt->layer2_type;
    new_node->pr_mac_sa0 = (pas_rslt->l2_s.mac_sa3 << 24) | (pas_rslt->l2_s.mac_sa2 << 16) | (pas_rslt->l2_s.mac_sa1 << 8) | (pas_rslt->l2_s.mac_sa0);
    new_node->pr_mac_sa1 = (pas_rslt->l2_s.mac_sa5 << 8) | (pas_rslt->l2_s.mac_sa4);
    new_node->pr_ip_header_error = pas_rslt->l3_s.ip_header_error;
    new_node->pr_is_tcp = pas_rslt->l4_s.is_tcp;
    new_node->pr_is_udp = pas_rslt->l4_s.is_udp;
    new_node->pr_ip_options = pas_rslt->l3_s.ip_options;
    new_node->pr_frag_info = pas_rslt->l3_s.frag_info;
    new_node->pr_tos = pas_rslt->l3_s.tos.ip_tos;
    new_node->pr_l4_info_mapped = pas_rslt->l4_s.layer4_info_mapped;
    new_node->pr_l4_dest_port = pas_rslt->l4_s.l4_dst_port.l4_dest_port;
    new_node->pr_l4_source_port = pas_rslt->l4_s.l4_src_port.l4_source_port;
    new_node->pr_ipv6_flow_label = pas_rslt->l3_s.ipv6_flow_label;
    new_node->pr_ip_da0 = pas_rslt->l3_s.ip_da.ipv6.ipda_31_0;
    new_node->pr_ip_da1 = pas_rslt->l3_s.ip_da.ipv6.ipda_63_32;
    new_node->pr_ip_da2 = pas_rslt->l3_s.ip_da.ipv6.ipda_95_64;
    new_node->pr_ip_da3 = pas_rslt->l3_s.ip_da.ipv6.ipda_127_96;
    new_node->pr_ip_sa0 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_31_0;
    new_node->pr_ip_sa1 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_63_32;
    new_node->pr_ip_sa2 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_95_64;
    new_node->pr_ip_sa3 = pas_rslt->l3_s.ip_sa.ipv6.ipsa_127_96;
    new_node->pr_cvlan_id = pas_rslt->l2_s.cvlan_id;
    new_node->pr_svlan_id = pas_rslt->l2_s.svlan_id;
    new_node->pr_cvlan_id_valid = pas_rslt->l2_s.cvlan_id_valid;
    new_node->pr_svlan_id_valid = pas_rslt->l2_s.svlan_id_valid;
    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_PR2LM]));

    return DRV_E_NONE;
}
int32
sim_store_ipe_rt2fw_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_rt2fw_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;
    parsing_result_t *pas_rslt = (parsing_result_t *)pkt_info->parser_rslt;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_RT2FW))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_rt2fw_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_rt2fw_t));


    new_node->pi_non_crc = pkt_info->non_crc;
    new_node->pi_src_dscp = pkt_info->src_dscp;
    new_node->pi_packet_type = pkt_info->packet_type;
    new_node->pi_capwap_tunnel_valid = pkt_info->capwap_tunnel_valid;
    new_node->pi_logic_port_type = pkt_info->logic_port_type;
    new_node->pi_roaming_state = pkt_info->roaming_state;
    new_node->pi_capwap_tunnel_type = pkt_info->capwap_tunnel_type;
    new_node->pi_outer_vlan_is_cvlan = pkt_info->outer_vlan_is_cvlan;
    new_node->pi_svlan_tpid_index = pkt_info->svlan_tpid_index;
    new_node->pi_l2_span_en = pkt_info->l2_span_en;
    new_node->pi_l2_span_id = pkt_info->l2_span_id;
    new_node->pi_port_log_en = pkt_info->port_log_en;
    new_node->pi_oam_tunnel_en = pkt_info->oam_tunnel_en;
    new_node->pi_src_queue_select = pkt_info->src_queue_select;
    new_node->pi_stag_action = pkt_info->stag_action;
    new_node->pi_ctag_action = pkt_info->ctag_action;
    new_node->pi_is_leaf = pkt_info->is_leaf;
    new_node->pi_speed = pkt_info->speed;
    new_node->pi_is_esadi = pkt_info->is_esadi;
    new_node->pi_ctag_cos = pkt_info->ctag_cos;
    new_node->pi_ctag_cfi = pkt_info->ctag_cfi;
    new_node->pi_svlan_id_valid = pkt_info->svlan_id_valid;
    new_node->pi_cvlan_id_valid = pkt_info->cvlan_id_valid;
    new_node->pi_src_ctag_offset_type = pkt_info->src_ctag_offset_type;
    new_node->pi_l3_span_en = pkt_info->l3_span_en;
    new_node->pi_l3_span_id = pkt_info->l3_span_id;
    new_node->pi_new_isid = pkt_info->new_isid;
    new_node->pi_pbb_check_discard = pkt_info->pbb_check_discard;
    new_node->pi_ecmp_hash = pkt_info->ecmp_hash;
    new_node->pi_source_port_extender = pkt_info->source_port_extender;
    new_node->pi_vlan_ptr = pkt_info->vlan_ptr;
    new_node->pi_flow_id = pkt_info->flow_id;
    new_node->pi_acl_dscp = pkt_info->acl_dscp;
    new_node->pi_acl_log_en0 = pkt_info->acl_log_en0;
    new_node->pi_acl_log_id0 = pkt_info->acl_log_id0;
    new_node->pi_acl_log_en1 = pkt_info->acl_log_en1;
    new_node->pi_acl_log_id1 = pkt_info->acl_log_id1;
    new_node->pi_acl_log_en2 = pkt_info->acl_log_en2;
    new_node->pi_acl_log_id2 = pkt_info->acl_log_id2;
    new_node->pi_acl_log_en3 = pkt_info->acl_log_en3;
    new_node->pi_acl_log_id3 = pkt_info->acl_log_id3;
    new_node->pi_egress_oam_use_fid = pkt_info->egress_oam_use_fid;
    new_node->pi_ecn_en = pkt_info->ecn_en;
    new_node->pi_ecn_priority_en = pkt_info->ecn_priority_en;
    new_node->pi_ecn_aware = pkt_info->ecn_aware;
    new_node->pi_source_cfi = pkt_info->source_cfi;
    new_node->pi_packet_ttl = pkt_info->packet_ttl;
    new_node->pr_cn_tag_valid = pas_rslt->l2_s.cn_tag_valid;
    new_node->pr_cn_flow_id = pas_rslt->l2_s.cn_flow_id;
    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_RT2FW]));


    return DRV_E_NONE;
}
int32
sim_store_ipe_ui2pp_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_ui2pp_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_UI2PP))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_ui2pp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_ui2pp_t));


    new_node->pi_time_stamp_valid = pkt_info->time_stamp_valid;
    new_node->pi_time_stamp0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;
    new_node->pi_time_stamp1 = pkt_info->share_fields_u.ptp.time_stamp_61_32;
    new_node->pi_source_port_extender = pkt_info->source_port_extender;
    new_node->pi_tx_dm_en = pkt_info->tx_dm_en;
    new_node->pi_header_hash = pkt_info->header_hash;
    new_node->pi_outer_priority = pkt_info->outer_priority;
    new_node->pi_outer_color = pkt_info->outer_color;
    new_node->pi_mux_length_type = pkt_info->mux_length_type;
    new_node->pi_packet_length_adjust = pkt_info->packet_length_adjust;
    new_node->pi_mux_destination = pkt_info->mux_destination;
    new_node->pi_mux_destination_type = pkt_info->mux_destination_type;
    new_node->pi_mux_destination_valid = pkt_info->mux_destination_valid;
    new_node->pi_packet_length = pkt_info->packet_length;
    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_UI2PP]));


    return DRV_E_NONE;
}
int32
sim_store_ipe_ilreq_bus(void *learning_info)
{
    ipe_learn_proc_input_info_t *info = (ipe_learn_proc_input_info_t *)learning_info;
    ipe_ilreq_t *new_node;

     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_ILREQ))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(ipe_ilreq_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_ilreq_t));

    new_node->ether_oam_level = info->ether_oam_level;
    new_node->fast_learn_en = info->fast_learning_en;
    new_node->is_ether_oam = info->is_ether_oam;
    new_node->is_global_src_port = info->is_global_src_port;
    new_node->mac_sa0 = info->mac_sa_31_0;
    new_node->mac_sa1 = info->mac_sa_47_32;
    new_node->new_cvlan_id = info->new_cvlan_id;
    new_node->new_svlan_id = info->new_svlan_id;
    new_node->old_cvlan_id = info->old_cvlan_id;
    new_node->old_svlan_id = info->old_svlan_id;
    new_node->src_port = info->learning_source_port;
    new_node->vsi_id = info->vsi_id;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_ILREQ]));

    return DRV_E_NONE;
}
int32
sim_store_ipe_olreq_bus(void *learning_info)
{
    ipe_learn_proc_input_info_t *info = (ipe_learn_proc_input_info_t *)learning_info;
    ipe_olreq_t *new_node;


     if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_OLREQ))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(ipe_olreq_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_olreq_t));

    new_node->fast_learn_en = info->fast_learning_en;
    new_node->is_global_src_port = info->is_global_src_port;
    new_node->mac_sa0 = info->mac_sa_31_0;
    new_node->mac_sa1 = info->mac_sa_47_32;
    new_node->new_cvlan_id = info->new_cvlan_id;
    new_node->new_svlan_id = info->new_svlan_id;
    new_node->old_cvlan_id = info->old_cvlan_id;
    new_node->old_svlan_id = info->old_svlan_id;
    new_node->src_port = info->learning_source_port;
    new_node->vsi_id = info->vsi_id;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_OLREQ]));


    return DRV_E_NONE;
}

int32 sim_store_ipe_oam2fwd_sharelm_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_sharelm_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_SHA_FLD_OM2FW_LM_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(ipe_sharelm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_sharelm_t));

    new_node->pi_lm_packet_type = pkt_info->share_fields_u.lmtx.lm_packet_type;
    new_node->pi_tx_fcb = pkt_info->share_fields_u.lmtx.tx_fcb;
    new_node->pi_rx_fcb_lm = pkt_info->share_fields_u.lmtx.rx_fcb;
    new_node->pi_rx_tx_fcl_lm = pkt_info->share_fields_u.lmtx.rxtx_fcl;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_LM_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_ipe_oam2fwd_sharenat_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_sharenat_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_SHA_FLD_OM2FW_NAT_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(ipe_sharenat_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_sharenat_t));

    new_node->pi_new_ip_sa0 = pkt_info->share_fields_u.nat.new_ip_sa_31_0;
    new_node->pi_new_ip_sa1 = pkt_info->share_fields_u.nat.new_ip_sa_39_32;
    new_node->pi_new_l4_source_port = pkt_info->share_fields_u.nat.new_l4_source_port;
    new_node->pi_new_ip_sa_valid = pkt_info->share_fields_u.nat.new_ip_sa_valid;
    new_node->pi_new_l4_source_port_valid = pkt_info->share_fields_u.nat.new_l4_source_port_valid;
    new_node->pi_pt_enable = pkt_info->share_fields_u.nat.pt_enable;
    new_node->pi_ipv4_src_embeded_mode = pkt_info->share_fields_u.nat.ipv4_src_embeded_mode;
    new_node->pi_ip_sa_mode = pkt_info->share_fields_u.nat.ip_sa_mode;
    new_node->pi_src_address_mode = pkt_info->share_fields_u.nat.src_address_mode;
    new_node->pi_ip_sa_prefix_length = pkt_info->share_fields_u.nat.ip_sa_prefix_length;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_NAT_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_ipe_oam2fwd_shareoam_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_shareoam_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_SHA_FLD_OM2FW_OAM_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(ipe_shareoam_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_shareoam_t));

    new_node->pi_gal_exist = pkt_info->share_fields_u.oam.gal_exist;
    new_node->pi_entropy_label_exist = pkt_info->share_fields_u.oam.entropy_label_exist;
    new_node->pi_oam_dest_chip_id = pkt_info->share_fields_u.oam.oam_dest_chip_id;
    new_node->pi_mep_index = pkt_info->share_fields_u.oam.mep_index;
    new_node->pi_rx_oam_type = pkt_info->share_fields_u.oam.rx_oam_type;
    new_node->pi_mip_en = pkt_info->share_fields_u.oam.mip_en;
    new_node->pi_link_or_section_oam = pkt_info->share_fields_u.oam.link_or_section_oam;
    new_node->pi_lm_received_packet = pkt_info->share_fields_u.oam.lm_received_packet;
    new_node->pi_dm_en = pkt_info->share_fields_u.oam.dm_en;
    new_node->pi_rx_fcb = pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32;
    new_node->pi_rx_tx_fcl = pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_OAM_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_ipe_oam2fwd_shareptp_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_shareptp_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_SHA_FLD_OM2FW_PTP_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(ipe_shareptp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_shareptp_t));

   // new_node->pi_ptp_edit_type = pkt_info->share_fields_u.ptp.ptp_edit_type;
   // new_node->pi_ptp_sequence_id = pkt_info->share_fields_u.ptp.ptp_sequence_id;
    new_node->pi_ptp_extra_offset = pkt_info->share_fields_u.ptp.ptp_extra_offset;
    new_node->pi_time_stamp0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;
    new_node->pi_time_stamp1 = pkt_info->share_fields_u.ptp.time_stamp_61_32;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_PTP_BUS]));

    return DRV_E_NONE;
}

int32 sim_store_ipe_oam2fwd_sharedm_bus(void *in_pkt)
{
    ipe_in_pkt_t *inpkt = (ipe_in_pkt_t *)in_pkt;
    ipe_sharedm_t *new_node;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)inpkt->pkt_info;

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_IPE], SIM_IPE_SHA_FLD_OM2FW_DMTX_BUS))
    {
        return DRV_E_NONE;
    }

    new_node = sal_malloc(sizeof(ipe_sharedm_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(ipe_sharedm_t));

    new_node->pi_dm_offset = pkt_info->share_fields_u.dmtx.dm_offset;
    new_node->pi_dm_offset = pkt_info->share_fields_u.dmtx.time_stamp_31_0;
    new_node->pi_dm_offset = pkt_info->share_fields_u.dmtx.time_stamp_61_32;

    list_add_tail(&(new_node->head), &(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_DMTX_BUS]));

    return DRV_E_NONE;
}


int32
cosim_ipe_excp_verify(void *bus,bool *succ)
{
    ms_ipe_excp_info_t *c_ipe_excp,v_ipe_excp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};
    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_EXCP])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe excp verify error! <excp list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }
    c_ipe_excp = list_entry(cosim_db.sim_ipe_list[SIM_IPE_EXCP].next,ms_ipe_excp_info_t,head);
    sal_memset(&v_ipe_excp,0,sizeof(ms_ipe_excp_info_t));
    ret = ms_ipe_excp_info_bus_decode(bus, &v_ipe_excp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe excp bus decode error!\n");
        goto RELEASE;
    }
    *succ = ms_ipe_excp_info_bus_compare(c_ipe_excp,&v_ipe_excp);
    list_del(&c_ipe_excp->head);
    sal_free(c_ipe_excp);
    c_ipe_excp = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_excp->head);
    sal_free(c_ipe_excp);
    c_ipe_excp = NULL;
    return ret;
}
int32
cosim_ipe_ha2pr_verify(void *bus,bool *succ)
{
    ipe_ha2pr_t *c_ipe_ha2pr,v_ipe_ha2pr;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_HA2PR])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe ha2pr verify error! <ha2pr list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_ha2pr = list_entry(cosim_db.sim_ipe_list[SIM_IPE_HA2PR].next,ipe_ha2pr_t,head);
    sal_memset(&v_ipe_ha2pr,0,sizeof(ipe_ha2pr_t));
    ret = ipe_ha2pr_bus_decode(bus, &v_ipe_ha2pr);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe ha2pr bus decode error!\n");
        goto RELEASE;
    }


    *succ = ipe_ha2pr_bus_compare(c_ipe_ha2pr,&v_ipe_ha2pr);


    list_del(&c_ipe_ha2pr->head);
    sal_free(c_ipe_ha2pr);
    c_ipe_ha2pr = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_ha2pr->head);
    sal_free(c_ipe_ha2pr);
    c_ipe_ha2pr = NULL;
    return ret;
}
int32
cosim_ipe_ha2im_verify(void *bus,bool *succ)
{
    ipe_ha2im_t *c_ipe_ha2im,v_ipe_ha2im;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_HA2IM])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe ha2im verify error! <ha2im list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_ha2im = list_entry(cosim_db.sim_ipe_list[SIM_IPE_HA2IM].next,ipe_ha2im_t,head);
    sal_memset(&v_ipe_ha2im,0,sizeof(ipe_ha2im_t));
    ret = ipe_ha2im_bus_decode(bus, &v_ipe_ha2im);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe ha2im bus decode error!\n");
        goto RELEASE;
    }


    if (c_ipe_ha2im->pi_discard != v_ipe_ha2im.pi_discard)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe ha2im discard is not match!\n");
        ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_ipe_ha2im.pi_discard, c_ipe_ha2im->pi_discard);
    }
    else if (c_ipe_ha2im->pi_discard == TRUE)
    {
        if (c_ipe_ha2im->pi_discard_type != v_ipe_ha2im.pi_discard_type)
       {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"ipe ha2im discard type is not match!\n");
            ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_ipe_ha2im.pi_discard_type, c_ipe_ha2im->pi_discard_type);
        }
			else
			{
			/* Cmodel and RTL are both discard the packet, their discard types are the same. */
			*succ = TRUE;
			}
    }
    else
    {
        *succ = ipe_ha2im_bus_compare(c_ipe_ha2im,&v_ipe_ha2im);
    }


    list_del(&c_ipe_ha2im->head);
    sal_free(c_ipe_ha2im);
    c_ipe_ha2im = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_ha2im->head);
    sal_free(c_ipe_ha2im);
    c_ipe_ha2im = NULL;
    return ret;
}

int32
cosim_ipe_im2pp_verify(void *bus,bool *succ)
{
    ipe_im2pp_t *c_ipe_im2pp,v_ipe_im2pp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_IM2PP])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe im2pp verify error! <im2pp list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_im2pp = list_entry(cosim_db.sim_ipe_list[SIM_IPE_IM2PP].next,ipe_im2pp_t,head);
    sal_memset(&v_ipe_im2pp,0,sizeof(ipe_im2pp_t));
    ret = ipe_im2pp_bus_decode(bus, &v_ipe_im2pp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe im2pp bus decode error!\n");
        goto RELEASE;
    }


    *succ = ipe_im2pp_bus_compare(c_ipe_im2pp,&v_ipe_im2pp);


    list_del(&c_ipe_im2pp->head);
    sal_free(c_ipe_im2pp);
    c_ipe_im2pp = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_im2pp->head);
    sal_free(c_ipe_im2pp);
    c_ipe_im2pp = NULL;
    return ret;
}
int32
cosim_ipe_impi2lm_verify(void *bus,bool *succ)
{
    ipe_impi2lm_t *c_ipe_impi2lm,v_ipe_impi2lm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_IMPI2LM])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe impi2lm verify error! <impi2lm list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_impi2lm = list_entry(cosim_db.sim_ipe_list[SIM_IPE_IMPI2LM].next,ipe_impi2lm_t,head);
    sal_memset(&v_ipe_impi2lm,0,sizeof(ipe_impi2lm_t));
    ret = ipe_impi2lm_bus_decode(bus, &v_ipe_impi2lm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe impi2lm bus decode error!\n");
        goto RELEASE;
    }


    if (c_ipe_impi2lm->pi_discard != v_ipe_impi2lm.pi_discard)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe impi2lm discard is not match!\n");
        ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_ipe_impi2lm.pi_discard, c_ipe_impi2lm->pi_discard);
    }
    else if (c_ipe_impi2lm->pi_discard == TRUE)
    {
        if (c_ipe_impi2lm->pi_discard_type != v_ipe_impi2lm.pi_discard_type)
       {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"ipe impi2lm discard type is not match!\n");
            ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_ipe_impi2lm.pi_discard_type, c_ipe_impi2lm->pi_discard_type);
        }
        else
        {
            /* Cmodel and RTL are both discard the packet, their discard types are the same. */
            *succ = TRUE;
        }
    }
    else
    {
        *succ = ipe_impi2lm_bus_compare(c_ipe_impi2lm,&v_ipe_impi2lm);
    }


    list_del(&c_ipe_impi2lm->head);
    sal_free(c_ipe_impi2lm);
    c_ipe_impi2lm = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_impi2lm->head);
    sal_free(c_ipe_impi2lm);
    c_ipe_impi2lm = NULL;
    return ret;
}
int32
cosim_ipe_impr2lm_verify(void *bus,bool *succ)
{
    ipe_impr2lm_t *c_ipe_impr2lm,v_ipe_impr2lm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_IMPR2LM])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe impr2lm verify error! <impr2lm list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_impr2lm = list_entry(cosim_db.sim_ipe_list[SIM_IPE_IMPR2LM].next,ipe_impr2lm_t,head);
    sal_memset(&v_ipe_impr2lm,0,sizeof(ipe_impr2lm_t));
    ret = ipe_impr2lm_bus_decode(bus, &v_ipe_impr2lm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe impr2lm bus decode error!\n");
        goto RELEASE;
    }


    *succ = ipe_impr2lm_bus_compare(c_ipe_impr2lm,&v_ipe_impr2lm);


    list_del(&c_ipe_impr2lm->head);
    sal_free(c_ipe_impr2lm);
    c_ipe_impr2lm = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_impr2lm->head);
    sal_free(c_ipe_impr2lm);
    c_ipe_impr2lm = NULL;
    return ret;
}
int32
cosim_ipe_lr2fw_verify(void *bus,bool *succ)
{
    ipe_lr2fw_t *c_ipe_lr2fw,v_ipe_lr2fw;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_LR2FW])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe lr2fw verify error! <lr2fw list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_lr2fw = list_entry(cosim_db.sim_ipe_list[SIM_IPE_LR2FW].next,ipe_lr2fw_t,head);
    sal_memset(&v_ipe_lr2fw,0,sizeof(ipe_lr2fw_t));
    ret = ipe_lr2fw_bus_decode(bus, &v_ipe_lr2fw);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe lr2fw bus decode error!\n");
        goto RELEASE;
    }


    *succ = ipe_lr2fw_bus_compare(c_ipe_lr2fw,&v_ipe_lr2fw);


    list_del(&c_ipe_lr2fw->head);
    sal_free(c_ipe_lr2fw);
    c_ipe_lr2fw = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_lr2fw->head);
    sal_free(c_ipe_lr2fw);
    c_ipe_lr2fw = NULL;
    return ret;
}
int32
cosim_ipe_lm2pp_verify(void *bus,bool *succ)
{
    ipe_lm2pp_t *c_ipe_lm2pp,v_ipe_lm2pp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_LM2PP])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe lm2pp verify error! <lm2pp list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_lm2pp = list_entry(cosim_db.sim_ipe_list[SIM_IPE_LM2PP].next,ipe_lm2pp_t,head);
    sal_memset(&v_ipe_lm2pp,0,sizeof(ipe_lm2pp_t));
    ret = ipe_lm2pp_bus_decode(bus, &v_ipe_lm2pp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe lm2pp bus decode error!\n");
        goto RELEASE;
    }


    if (c_ipe_lm2pp->pi_discard != v_ipe_lm2pp.pi_discard)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe lm2pp discard is not match!\n");
        ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_ipe_lm2pp.pi_discard, c_ipe_lm2pp->pi_discard);
    }
    else if (c_ipe_lm2pp->pi_discard == TRUE)
    {
        if (c_ipe_lm2pp->pi_discard_type != v_ipe_lm2pp.pi_discard_type)
       {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"ipe lm2pp discard type is not match!\n");
            ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_ipe_lm2pp.pi_discard_type, c_ipe_lm2pp->pi_discard_type);
        }
        else
        {
            /* Cmodel and RTL are both discard the packet, their discard types are the same. */
            *succ = TRUE;
        }
    }
    else
    {
        *succ = ipe_lm2pp_bus_compare(c_ipe_lm2pp,&v_ipe_lm2pp);
    }


    list_del(&c_ipe_lm2pp->head);
    sal_free(c_ipe_lm2pp);
    c_ipe_lm2pp = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_lm2pp->head);
    sal_free(c_ipe_lm2pp);
    c_ipe_lm2pp = NULL;
    return ret;
}
int32
cosim_ipe_om2fw_verify(void *bus,bool *succ)
{
    ipe_om2fw_t *c_ipe_om2fw,v_ipe_om2fw;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_OM2FW])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe om2fw verify error! <om2fw list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_om2fw = list_entry(cosim_db.sim_ipe_list[SIM_IPE_OM2FW].next,ipe_om2fw_t,head);
    sal_memset(&v_ipe_om2fw,0,sizeof(ipe_om2fw_t));
    ret = ipe_om2fw_bus_decode(bus, &v_ipe_om2fw);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe om2fw bus decode error!\n");
        goto RELEASE;
    }


    if (c_ipe_om2fw->pi_discard != v_ipe_om2fw.pi_discard)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe om2fw discard is not match!\n");
        ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_ipe_om2fw.pi_discard, c_ipe_om2fw->pi_discard);
    }
    else if (c_ipe_om2fw->pi_discard == TRUE)
    {
        if (c_ipe_om2fw->pi_discard_type != v_ipe_om2fw.pi_discard_type)
       {
            *succ = FALSE;
            ASIC_DEBUG_BUS_CMP(buf,"ipe om2fw discard type is not match!\n");
            ASIC_DEBUG_BUS_CMP(buf,"Asic Value: %x; Cmodel Value: %x; ERROR!\n",
                                        v_ipe_om2fw.pi_discard_type, c_ipe_om2fw->pi_discard_type);
        }
        else
        {
            /* Cmodel and RTL are both discard the packet, their discard types are the same. */
            *succ = TRUE;
        }
    }
    else
    {
        *succ = ipe_om2fw_bus_compare(c_ipe_om2fw,&v_ipe_om2fw);
    }


    list_del(&c_ipe_om2fw->head);
    sal_free(c_ipe_om2fw);
    c_ipe_om2fw = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_om2fw->head);
    sal_free(c_ipe_om2fw);
    c_ipe_om2fw = NULL;
    return ret;
}

int32
cosim_ipe_pr2im_verify(void *bus,bool *succ)
{
    ipe_pr2im_t *c_ipe_pr2im,v_ipe_pr2im;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_PR2IM])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe pr2im verify error! <pr2im list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_pr2im = list_entry(cosim_db.sim_ipe_list[SIM_IPE_PR2IM].next,ipe_pr2im_t,head);
    sal_memset(&v_ipe_pr2im,0,sizeof(ipe_pr2im_t));
    ret = ipe_pr2im_bus_decode(bus, &v_ipe_pr2im);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe pr2im bus decode error!\n");
        goto RELEASE;
    }


    *succ = ipe_pr2im_bus_compare(c_ipe_pr2im,&v_ipe_pr2im);


    list_del(&c_ipe_pr2im->head);
    sal_free(c_ipe_pr2im);
    c_ipe_pr2im = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_pr2im->head);
    sal_free(c_ipe_pr2im);
    c_ipe_pr2im = NULL;
    return ret;
}
int32
cosim_ipe_pr2lm_verify(void *bus,bool *succ)
{
    ipe_pr2lm_t *c_ipe_pr2lm,v_ipe_pr2lm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_PR2LM])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe pr2lm verify error! <pr2lm list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_pr2lm = list_entry(cosim_db.sim_ipe_list[SIM_IPE_PR2LM].next,ipe_pr2lm_t,head);
    sal_memset(&v_ipe_pr2lm,0,sizeof(ipe_pr2lm_t));
    ret = ipe_pr2lm_bus_decode(bus, &v_ipe_pr2lm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe pr2lm bus decode error!\n");
        goto RELEASE;
    }


    *succ = ipe_pr2lm_bus_compare(c_ipe_pr2lm,&v_ipe_pr2lm);


    list_del(&c_ipe_pr2lm->head);
    sal_free(c_ipe_pr2lm);
    c_ipe_pr2lm = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_pr2lm->head);
    sal_free(c_ipe_pr2lm);
    c_ipe_pr2lm = NULL;
    return ret;
}
int32
cosim_ipe_rt2fw_verify(void *bus,bool *succ)
{
    ipe_rt2fw_t *c_ipe_rt2fw,v_ipe_rt2fw;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_RT2FW])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe rt2fw verify error! <rt2fw list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_rt2fw = list_entry(cosim_db.sim_ipe_list[SIM_IPE_RT2FW].next,ipe_rt2fw_t,head);
    sal_memset(&v_ipe_rt2fw,0,sizeof(ipe_rt2fw_t));
    ret = ipe_rt2fw_bus_decode(bus, &v_ipe_rt2fw);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe rt2fw bus decode error!\n");
        goto RELEASE;
    }


    *succ = ipe_rt2fw_bus_compare(c_ipe_rt2fw,&v_ipe_rt2fw);


    list_del(&c_ipe_rt2fw->head);
    sal_free(c_ipe_rt2fw);
    c_ipe_rt2fw = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_rt2fw->head);
    sal_free(c_ipe_rt2fw);
    c_ipe_rt2fw = NULL;
    return ret;
}
int32
cosim_ipe_ui2pp_verify(void *bus,bool *succ)
{
    ipe_ui2pp_t *c_ipe_ui2pp,v_ipe_ui2pp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_UI2PP])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe ui2pp verify error! <ui2pp list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_ui2pp = list_entry(cosim_db.sim_ipe_list[SIM_IPE_UI2PP].next,ipe_ui2pp_t,head);
    sal_memset(&v_ipe_ui2pp,0,sizeof(ipe_ui2pp_t));
    ret = ipe_ui2pp_bus_decode(bus, &v_ipe_ui2pp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe ui2pp bus decode error!\n");
        goto RELEASE;
    }


    *succ = ipe_ui2pp_bus_compare(c_ipe_ui2pp,&v_ipe_ui2pp);


    list_del(&c_ipe_ui2pp->head);
    sal_free(c_ipe_ui2pp);
    c_ipe_ui2pp = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_ui2pp->head);
    sal_free(c_ipe_ui2pp);
    c_ipe_ui2pp = NULL;
    return ret;
}
int32
cosim_ipe_ilreq_verify(void *bus,bool *succ)
{
    ipe_ilreq_t *c_ipe_ilreq,v_ipe_ilreq;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_ILREQ])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe ilreq verify error! <ilreq list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_ilreq = list_entry(cosim_db.sim_ipe_list[SIM_IPE_ILREQ].next,ipe_ilreq_t,head);
    sal_memset(&v_ipe_ilreq,0,sizeof(ipe_ilreq_t));
    ret = ipe_ilreq_bus_decode(bus, &v_ipe_ilreq);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe ilreq bus decode error!\n");
        goto RELEASE;
    }


    *succ = ipe_ilreq_bus_compare(c_ipe_ilreq,&v_ipe_ilreq);


    list_del(&c_ipe_ilreq->head);
    sal_free(c_ipe_ilreq);
    c_ipe_ilreq = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_ilreq->head);
    sal_free(c_ipe_ilreq);
    c_ipe_ilreq = NULL;
    return ret;
}
int32
cosim_ipe_olreq_verify(void *bus,bool *succ)
{
    ipe_olreq_t *c_ipe_olreq,v_ipe_olreq;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_OLREQ])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe olreq verify error! <olreq list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_ipe_olreq = list_entry(cosim_db.sim_ipe_list[SIM_IPE_OLREQ].next,ipe_olreq_t,head);
    sal_memset(&v_ipe_olreq,0,sizeof(ipe_olreq_t));
    ret = ipe_olreq_bus_decode(bus, &v_ipe_olreq);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe olreq bus decode error!\n");
        goto RELEASE;
    }


    *succ = ipe_olreq_bus_compare(c_ipe_olreq,&v_ipe_olreq);


    list_del(&c_ipe_olreq->head);
    sal_free(c_ipe_olreq);
    c_ipe_olreq = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_ipe_olreq->head);
    sal_free(c_ipe_olreq);
    c_ipe_olreq = NULL;
    return ret;
}

int32 cosim_ipe_oam2fwd_sharelm_verify(void *bus,bool *succ)
{
    ipe_sharelm_t *c_ipe_sharelm,v_ipe_sharelm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_LM_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe oam2fwd shareLM verify error! <shareLM list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_ipe_sharelm = list_entry(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_LM_BUS].next,ipe_sharelm_t,head);
    sal_memset(&v_ipe_sharelm,0,sizeof(v_ipe_sharelm));
    ret = ipe_sharelm_bus_decode(bus, &v_ipe_sharelm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe oam2fwd shareLM bus decode error!\n");
        goto RELEASE;
    }

    *succ = ipe_sharelm_bus_compare(c_ipe_sharelm,&v_ipe_sharelm);

    list_del(&c_ipe_sharelm->head);
    sal_free(c_ipe_sharelm);
    c_ipe_sharelm = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_ipe_sharelm->head);
    sal_free(c_ipe_sharelm);
    c_ipe_sharelm = NULL;
    return ret;
}

int32 cosim_ipe_oam2fwd_sharenat_verify(void *bus,bool *succ)
{
    ipe_sharenat_t *c_ipe_sharenat,v_ipe_sharenat;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_NAT_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe oam2fwd shareNAT verify error! <shareNAT list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_ipe_sharenat = list_entry(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_NAT_BUS].next,ipe_sharenat_t,head);
    sal_memset(&v_ipe_sharenat,0,sizeof(v_ipe_sharenat));
    ret = ipe_sharenat_bus_decode(bus, &v_ipe_sharenat);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe oam2fwd shareNAT bus decode error!\n");
        goto RELEASE;
    }

    *succ = ipe_sharenat_bus_compare(c_ipe_sharenat,&v_ipe_sharenat);

    list_del(&c_ipe_sharenat->head);
    sal_free(c_ipe_sharenat);
    c_ipe_sharenat = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_ipe_sharenat->head);
    sal_free(c_ipe_sharenat);
    c_ipe_sharenat = NULL;
    return ret;
}

int32 cosim_ipe_oam2fwd_shareoam_verify(void *bus,bool *succ)
{
    ipe_shareoam_t *c_ipe_shareoam,v_ipe_shareoam;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_OAM_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe oam2fwd shareNAT verify error! <shareNAT list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_ipe_shareoam = list_entry(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_OAM_BUS].next,ipe_shareoam_t,head);
    sal_memset(&v_ipe_shareoam,0,sizeof(v_ipe_shareoam));
    ret = ipe_shareoam_bus_decode(bus, &v_ipe_shareoam);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe oam2fwd shareNAT bus decode error!\n");
        goto RELEASE;
    }

    *succ = ipe_shareoam_bus_compare(c_ipe_shareoam,&v_ipe_shareoam);

    list_del(&c_ipe_shareoam->head);
    sal_free(c_ipe_shareoam);
    c_ipe_shareoam = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_ipe_shareoam->head);
    sal_free(c_ipe_shareoam);
    c_ipe_shareoam = NULL;
    return ret;
}

int32 cosim_ipe_oam2fwd_shareptp_verify(void *bus, bool *succ)
{
    ipe_shareptp_t *c_ipe_shareptp,v_ipe_shareptp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_PTP_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe oam2fwd sharePTP verify error! <sharePTP list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_ipe_shareptp = list_entry(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_PTP_BUS].next,ipe_shareptp_t,head);
    sal_memset(&v_ipe_shareptp,0,sizeof(v_ipe_shareptp));
    ret = ipe_shareptp_bus_decode(bus, &v_ipe_shareptp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe oam2fwd sharePTP bus decode error!\n");
        goto RELEASE;
    }

    *succ = ipe_shareptp_bus_compare(c_ipe_shareptp,&v_ipe_shareptp);

    list_del(&c_ipe_shareptp->head);
    sal_free(c_ipe_shareptp);
    c_ipe_shareptp = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_ipe_shareptp->head);
    sal_free(c_ipe_shareptp);
    c_ipe_shareptp = NULL;
    return ret;
}

int32 cosim_ipe_oam2fwd_sharedm_verify(void *bus, bool *succ)
{
    ipe_sharedm_t *c_ipe_sharedm,v_ipe_sharedm;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    if (list_empty(&(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_DMTX_BUS])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "ipe oam2fwd shareDM verify error! <shareDM list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }

    c_ipe_sharedm = list_entry(cosim_db.sim_ipe_list[SIM_IPE_SHA_FLD_OM2FW_DMTX_BUS].next,ipe_sharedm_t,head);
    sal_memset(&v_ipe_sharedm,0,sizeof(v_ipe_sharedm));
    ret = ipe_sharedm_bus_decode(bus, &v_ipe_sharedm);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"ipe oam2fwd shareDM bus decode error!\n");
        goto RELEASE;
    }

    *succ = ipe_sharedm_bus_compare(c_ipe_sharedm,&v_ipe_sharedm);

    list_del(&c_ipe_sharedm->head);
    sal_free(c_ipe_sharedm);
    c_ipe_sharedm = NULL;
    return DRV_E_NONE;

RELEASE:
    list_del(&c_ipe_sharedm->head);
    sal_free(c_ipe_sharedm);
    c_ipe_sharedm = NULL;
    return ret;
}

