/****************************************************************************
 * sim_oam_interface.c
 *
 * Copyright:    (c)2012 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jack.Xu
 * Date:         2012-01-18
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sim_oam_interface.h"
#include "cm_lib.h"

extern int32
cm_oam_update_ccm_timer(uint32 chip_id, uint32 min_ptr, uint32 max_ptr, uint32 update_times);

extern int32
cm_oam_scan_defect_timer(uint32 chip_id, uint32 scan_times);

extern int32
cm_oam_auto_gen_pkt_tick_update(uint32 chip_id, uint32 update_times);

int32
cosim_do_oam(uint32 chipid, uint32 chanid, uint32 pkt_len, uint8 *pkt)
{
    oam_in_pkt_t in_pkt;
    list_head_t out_pkt, *pos = NULL;
    int ret;
    out_pkt_t *output=NULL;

    if (pkt == NULL)
    {
        return DRV_E_INVALID_PTR;
    }

    sal_memset(&in_pkt, 0, sizeof(oam_in_pkt_t));
    INIT_LIST_HEAD(&out_pkt);

    in_pkt.chip_id = chipid;
    in_pkt.chan_id = chanid;
    in_pkt.pkt = sal_malloc(MTU);

    if (NULL == in_pkt.pkt)
    {
        return DRV_E_NO_MEMORY;
    }

    sal_memset(in_pkt.pkt, 0, MTU);
    sal_memcpy(in_pkt.pkt, pkt+GREAT_BELT_HEADER_LEN, pkt_len); /* only raw packet, do not include bheader */
    in_pkt.packet_length = pkt_len;         /* do not include bheader len */
    in_pkt.pkt_info = NULL;

    in_pkt.module_bus.dest_id_discard = 0;  /* cmodel mustbe 0 */
    in_pkt.module_bus.pkt_len = pkt_len;    /* cmodel OAM can not support cutThrough */
    sal_memcpy(in_pkt.module_bus.packet_header, pkt, GREAT_BELT_HEADER_LEN);

    ret = cm_do_oam(&in_pkt, &out_pkt);
    if (ret < 0)
    {
        return ret;
    }

    list_for_each(pos, &out_pkt)
    {
        output = list_entry(pos, out_pkt_t, head);
        if (cosim_db.store_outpkt)
        {
            ret = cosim_db.store_outpkt(output->chip_id, output->chan_id,
                                output->packet_length, output->pkt, SIM_MODULE_OAM, 0, 0);
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("CoSIM: OAM engine store outpkt error ! ret = %d\n", ret);
            }
        }
    }

    list_del_all_and_free(&out_pkt);

    return DRV_E_NONE;
}

int32
cosim_oam_engine_update(uint32 chip_id, uint32 times, cosim_oam_update_type_t update_tp,
                        uint32 min_ptr, uint32 max_ptr)
{
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};

    switch (update_tp)
    {
        case COSIM_OAM_UPDATE:
            ret = cm_oam_update_ccm_timer(chip_id, min_ptr, max_ptr, times);
            if (ret < 0)
            {
                ASIC_DEBUG_BUS_CMP(buf, "Fail to do cm_oam_update_ccm_timer! ret = %d\n", ret);
                return ret;
            }
            ASIC_DEBUG_BUS_CMP(buf, "+++ CModel OAM CCM update Done!\n");
            break;
        case COSIM_OAM_DEFECT_SCAN:
            ret = cm_oam_scan_defect_timer(chip_id, times);
            if (ret < 0)
            {
                ASIC_DEBUG_BUS_CMP(buf, "Fail to do cm_oam_scan_defect_timer! ret = %d\n", ret);
                return ret;
            }
            ASIC_DEBUG_BUS_CMP(buf, "+++ CModel OAM SCAN defect Done!\n");
            break;
        case COSIM_OAM_GEN_PKT:
            ret = cm_oam_auto_gen_pkt_tick_update(chip_id, times);
            if (ret < 0)
            {
                ASIC_DEBUG_BUS_CMP(buf, "Fail to do cm_oam_scan_defect_timer! ret = %d\n", ret);
                return ret;
            }

            ASIC_DEBUG_BUS_CMP(buf, "+++ CModel OAM Gen Packet Done!\n");
            break;
        default:
            break;
    }

    return DRV_E_NONE;
}

int32
sim_store_oam_ha2pp_bus(void *in_pkt)
{
    oam_in_pkt_t *inpkt = (oam_in_pkt_t *)in_pkt;
    oam_ha2pp_t *new_node;
    oam_pkt_info_t *pkt_info = (oam_pkt_info_t *)inpkt->pkt_info;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_OAM], SIM_OAM_HA2PP))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(oam_ha2pp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(oam_ha2pp_t));


    new_node->pi_discard = pkt_info->discard;
    new_node->pi_packet_length = pkt_info->packet_length;
    new_node->pi_rx_oam_type = pkt_info->rx_oam_type;
    new_node->pi_mip_en = pkt_info->mip_en;
    new_node->pi_link_oam = pkt_info->link_oam;
    new_node->pi_is_up = pkt_info->is_up;
    new_node->pi_input_packet_offset = pkt_info->packet_offset;
    new_node->pi_mep_index = pkt_info->mep_index;
    new_node->pi_global_src_port = pkt_info->global_src_port;
    new_node->pi_ingress_src_port = pkt_info->ingress_src_port;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_bypass_all = pkt_info->by_pass_all;
    new_node->pi_relay_all_to_cpu = pkt_info->relay_all_to_cpu;
    new_node->pi_lm_received_packet = pkt_info->lm_received_packet;
    new_node->pi_label_num = pkt_info->label_num;
    list_add_tail(&(new_node->head), &(cosim_db.sim_oam_list[SIM_OAM_HA2PP]));


    return DRV_E_NONE;
}
int32
sim_store_oam_pp2fw_bus(void *in_pkt)
{
    oam_in_pkt_t *inpkt = (oam_in_pkt_t *)in_pkt;
    oam_pp2fw_t *new_node;
    oam_pkt_info_t *pkt_info = (oam_pkt_info_t *)inpkt->pkt_info;
    oam_parser_result_t* pas_rslt = (oam_parser_result_t*) pkt_info->parser_result;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_OAM], SIM_OAM_PP2FW))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(oam_pp2fw_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(oam_pp2fw_t));


    new_node->pi_input_packet_offset = pkt_info->packet_offset;
    new_node->pi_packet_offset = pas_rslt->packet_offset;
    new_node->pi_oam_type = pas_rslt->oam_type;
    new_node->pi_discard = pkt_info->discard;
    new_node->pi_rx_oam_type = pkt_info->rx_oam_type;
    new_node->pi_src_vlan_ptr = pkt_info->src_vlan_ptr;
    new_node->pi_ingress_src_port = pkt_info->ingress_src_port;
    new_node->pi_local_phy_port = pkt_info->local_phy_port;
    new_node->pi_relay_all_to_cpu = pkt_info->relay_all_to_cpu;
    new_node->pi_bypass_all = pkt_info->by_pass_all;
    new_node->pi_exception = pkt_info->exception;
    new_node->pi_mep_index = pkt_info->mep_index;
    new_node->pi_rmep_index = pkt_info->rmep_index;
    new_node->pi_is_mep_hit = pkt_info->is_mep_hit;
    new_node->pi_is_l2_eth_oam = pas_rslt->is_l2_eth_oam;
    new_node->pi_is_defect_free = pkt_info->is_defect_free;
    new_node->pi_is_up = pkt_info->is_up;
    new_node->pi_equal_dm = pkt_info->equal_dm;
    new_node->pi_equal_lb = pkt_info->equal_lb;
    new_node->pi_bridge_mac0 = ((pkt_info->bridge_mac[2] << 24) | (pkt_info->bridge_mac[3] << 16)\
                                | (pkt_info->bridge_mac[4] << 8) | (pkt_info->bridge_mac[5]));;
    new_node->pi_bridge_mac1 = ((pkt_info->bridge_mac[0] << 8) | (pkt_info->bridge_mac[1]));
    new_node->pi_port_mac0 =  ((pkt_info->port_mac[2] << 24) | (pkt_info->port_mac[3] << 16)\
                                | (pkt_info->port_mac[4] << 8) | (pkt_info->port_mac[5]));
    new_node->pi_port_mac1 = ((pkt_info->port_mac[0] << 8) | (pkt_info->port_mac[1]));
    new_node->pi_equal_lm = pkt_info->equal_lm;
    new_node->pi_oam_use_fid = pkt_info->oam_use_fid;
    new_node->pi_next_hop_ptr = pkt_info->next_hop_ptr;
    new_node->pi_flags = pas_rslt->ma_id.dlm.flags;
    new_node->pi_version = pas_rslt->ma_id.dlm.version;
    new_node->pi_controlcode = pas_rslt->ma_id.dlm.control_code;
    new_node->pi_d_flags = pas_rslt->ma_id.dlm.dflags;
    new_node->pi_timestamp11 = pas_rslt->ma_id.dlm.timestamp1_63_to32;
    new_node->pi_timestamp10 = pas_rslt->ma_id.dlm.timestamp1_31_to0;
    new_node->pi_counter11 = pas_rslt->ma_id.dlm.counter1_63_to32;
    new_node->pi_counter10 = pas_rslt->ma_id.dlm.counter1_31_to0;
    new_node->pi_if_status_valid = pas_rslt->if_status_valid;
    new_node->pi_lm_received_packet = pkt_info->lm_received_packet;
    new_node->pi_label_num = pkt_info->label_num;
    new_node->pi_share_mac_en = pkt_info->share_mac_en;
    new_node->pi_mip_en = pkt_info->mip_en;
    new_node->pi_mpls_tp_entropy_label = pkt_info->mpls_tp_entropy_label;
    new_node->pi_mpls_label_disable = pkt_info->mpls_label_disable;
    new_node->pi_link_oam = pkt_info->link_oam;
    list_add_tail(&(new_node->head), &(cosim_db.sim_oam_list[SIM_OAM_PP2FW]));


    return DRV_E_NONE;
}
int32
sim_store_oam_pr2pp_bus(void *in_pkt)
{
    oam_in_pkt_t *inpkt = (oam_in_pkt_t *)in_pkt;
    oam_pr2pp_t *new_node;
    oam_pkt_info_t *pkt_info = (oam_pkt_info_t *)inpkt->pkt_info;
    oam_parser_result_t *pas_rslt = (oam_parser_result_t *)pkt_info->parser_result;


    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_OAM], SIM_OAM_PR2PP))
    {
        return DRV_E_NONE;
    }


    new_node = sal_malloc(sizeof(oam_pr2pp_t));
    if(NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node,0,sizeof(oam_pr2pp_t));


//    new_node->pr_pkt_seq = pas_rslt->pkt_seq;
    new_node->pr_tlv_options = pas_rslt->tlv_options;
    new_node->pr_md_lvl = pas_rslt->md_lvl;
	new_node->pr_ma_id11 = pas_rslt->ma_id.eth.ma_id_383_to352;
    new_node->pr_ma_id10 = pas_rslt->ma_id.eth.ma_id_351_to320;
    new_node->pr_ma_id9 = pas_rslt->ma_id.eth.ma_id_319_to288;
    new_node->pr_ma_id8 = pas_rslt->ma_id.eth.ma_id_287_to256;
    new_node->pr_ma_id7 = pas_rslt->ma_id.eth.ma_id_255_to224;
    new_node->pr_ma_id6 = pas_rslt->ma_id.eth.ma_id_223_to192;
    new_node->pr_ma_id5 = pas_rslt->ma_id.eth.ma_id_191_to160;
    new_node->pr_ma_id4 = pas_rslt->ma_id.eth.ma_id_159_to128;
    new_node->pr_ma_id3 = pas_rslt->ma_id.eth.ma_id_127_to96;
    new_node->pr_ma_id2 = pas_rslt->ma_id.eth.ma_id_95_to64;
    new_node->pr_ma_id1 = pas_rslt->ma_id.eth.ma_id_63_to32;
    new_node->pr_ma_id0 = pas_rslt->ma_id.eth.ma_id_31_to0;
    new_node->pr_ma_id_length = pas_rslt->ma_id_length;
    new_node->pr_present_traffic = pas_rslt->present_traffic;
    new_node->pr_mac_sa0 = pas_rslt->mac_sa.eth.mac_sa_31_to0;
    new_node->pr_mac_sa1 = pas_rslt->mac_sa.eth.mac_sa_47_to32;
    new_node->pr_mac_da0 = pas_rslt->mac_da.eth.mac_da_31_to0;
    new_node->pr_mac_da1 = pas_rslt->mac_da.eth.mac_da_47_to32;
    new_node->pr_rdi = pas_rslt->rdi;
    new_node->pr_ccm_seq_num = pas_rslt->ccm_seq_num.eth.ccm_seq_num;
    new_node->pr_port_status_valid = pas_rslt->port_status_valid;
    new_node->pr_if_status_valid = pas_rslt->if_status_valid;
    new_node->pr_port_status_value = pas_rslt->port_status_value;
    new_node->pr_if_status_value = pas_rslt->if_status_value;
    new_node->pr_packet_offset = pas_rslt->packet_offset;
    new_node->pr_is_l2_eth_oam = pas_rslt->is_l2_eth_oam;
    new_node->pr_high_version_oam = pas_rslt->high_version_oam;
    new_node->pr_oam_type = pas_rslt->oam_type;
    new_node->pr_ccm_interval = pas_rslt->ccm_interval;
    new_node->pr_oam_pdu_invalid = pas_rslt->oam_pdu_invalid;
    new_node->pr_bfd_oam_pdu_invalid = pas_rslt->bfd_oam_pdu_invalid;
    new_node->pr_rmep_id = pas_rslt->rmep_id;
    new_node->pr_mplslbm_pdu_invalid = pas_rslt->mpls_lbm_pdu_invalid;
    list_add_tail(&(new_node->head), &(cosim_db.sim_oam_list[SIM_OAM_PR2PP]));


    return DRV_E_NONE;
}
int32
cosim_oam_ha2pp_verify(void *bus,bool *succ)
{
    oam_ha2pp_t *c_oam_ha2pp,v_oam_ha2pp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_oam_list[SIM_OAM_HA2PP])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "oam ha2pp verify error! <ha2pp list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_oam_ha2pp = list_entry(cosim_db.sim_oam_list[SIM_OAM_HA2PP].next,oam_ha2pp_t,head);
    sal_memset(&v_oam_ha2pp,0,sizeof(oam_ha2pp_t));
    ret = oam_ha2pp_bus_decode(bus, &v_oam_ha2pp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"oam ha2pp bus decode error!\n");
        goto RELEASE;
    }


    *succ = oam_ha2pp_bus_compare(c_oam_ha2pp,&v_oam_ha2pp);


    list_del(&c_oam_ha2pp->head);
    sal_free(c_oam_ha2pp);
    c_oam_ha2pp = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_oam_ha2pp->head);
    sal_free(c_oam_ha2pp);
    c_oam_ha2pp = NULL;
    return ret;
}
int32
cosim_oam_pp2fw_verify(void *bus,bool *succ)
{
    oam_pp2fw_t *c_oam_pp2fw,v_oam_pp2fw;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_oam_list[SIM_OAM_PP2FW])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "oam pp2fw verify error! <pp2fw list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_oam_pp2fw = list_entry(cosim_db.sim_oam_list[SIM_OAM_PP2FW].next,oam_pp2fw_t,head);
    sal_memset(&v_oam_pp2fw,0,sizeof(oam_pp2fw_t));
    ret = oam_pp2fw_bus_decode(bus, &v_oam_pp2fw);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"oam pp2fw bus decode error!\n");
        goto RELEASE;
    }


    *succ = oam_pp2fw_bus_compare(c_oam_pp2fw,&v_oam_pp2fw);


    list_del(&c_oam_pp2fw->head);
    sal_free(c_oam_pp2fw);
    c_oam_pp2fw = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_oam_pp2fw->head);
    sal_free(c_oam_pp2fw);
    c_oam_pp2fw = NULL;
    return ret;
}
int32
cosim_oam_pr2pp_verify(void *bus,bool *succ)
{
    oam_pr2pp_t *c_oam_pr2pp,v_oam_pr2pp;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] ={0};


    if (list_empty(&(cosim_db.sim_oam_list[SIM_OAM_PR2PP])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "oam pr2pp verify error! <pr2pp list is empty>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }


    c_oam_pr2pp = list_entry(cosim_db.sim_oam_list[SIM_OAM_PR2PP].next,oam_pr2pp_t,head);
    sal_memset(&v_oam_pr2pp,0,sizeof(oam_pr2pp_t));
    ret = oam_pr2pp_bus_decode(bus, &v_oam_pr2pp);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf,"oam pr2pp bus decode error!\n");
        goto RELEASE;
    }


    *succ = oam_pr2pp_bus_compare(c_oam_pr2pp,&v_oam_pr2pp);


    list_del(&c_oam_pr2pp->head);
    sal_free(c_oam_pr2pp);
    c_oam_pr2pp = NULL;
    return DRV_E_NONE;
RELEASE:
    list_del(&c_oam_pr2pp->head);
    sal_free(c_oam_pr2pp);
    c_oam_pr2pp = NULL;
    return ret;
}

