/****************************************************************************
 * oam_update_fsm.c : update the state machine in dsmp in specified scope
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       jiangsz.
 * Date:         2010-11-18.
 * Reason:       First Create.
 *
 * Revision:     V2.0.
 * Author:       mengzw.
 * Date:         2011-04-08.
 * Reason:       Sync for spec V2.0.
 *
 * Revision:     V4.28.
 * Author:       zhaomc.
 * Date:         2011-09-28.
 * Reason:       Sync for spec V4.28.
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

#define CM_OAM_CCM_UPDATE_CNT_MAX   180000
sal_timer_t* cm_cfm_ccm_timer = NULL;
sal_timer_t* cm_cfm_error_cache_timer = NULL;

struct oam_ccm_update_info_s
{
    uint32 mep_index               :14;
    uint32 rmep_index              :14;
    uint32 defect_type             :3;
    uint32 is_rmep_valid           :1;

    uint32 defect_sub_type         :3;
    uint32 resv0                   :29;
};
typedef struct oam_ccm_update_info_s oam_ccm_update_info_t;

struct oam_ccm_pkt_info_s
{
    void* p_ds_bfd_mep;
    void* p_ds_bfd_rmep;
    void* p_ds_eth_mep;
    void* p_ds_eth_rmep;
    void* p_ds_ma;

    void* p_new_ds_bfd_mep;
    void* p_new_ds_bfd_rmep;
    void* p_new_ds_eth_mep;
    void* p_new_ds_eth_rmep;
    void* p_update_info;


    uint32 mep_index             :14;
    uint32 rmep_index            :14;
    uint32 is_remote             :1;
    uint32 signal_fail           :1;
    uint32 is_ether_update       :1;
    uint32 is_bfd_update         :1;

    uint32 ma_index              :13;
    uint32 chip_id               :5;
    uint32 timer_update_en       :1;
    uint32 rsv_0                 :13;
};
typedef struct oam_ccm_pkt_info_s oam_ccm_pkt_info_t;

/****************************************************************************
 * Name:       _cm_oam_generate_aps_msg
 * Purpose:    generate aps messages and send it to cpu
 * Parameters:
 * Input:      ccm_pkt_info -- pointer to buffer which save information
 *                       used in module update ccm timer .
 * Output:     ccm_pkt_info -- pointer to buffer which save information
 *                       used in module update ccm timer.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_generate_aps_msg(oam_ccm_pkt_info_t* ccm_pkt_info)
{
#define APS_MESSAGE_LEN 64
    oam_ccm_update_info_t* update_info = (oam_ccm_update_info_t*)ccm_pkt_info->p_update_info;

    uint8 chip_id = ccm_pkt_info->chip_id;
    uint16 ma_index = ccm_pkt_info->ma_index;
    uint8 signal_fail = ccm_pkt_info->signal_fail;
    uint8 is_remote = ccm_pkt_info->is_remote;
    /*greatbelt_packet_header_t packet_header;*/
    ms_packet_header_t packet_header;

    oam_update_aps_ctl_t oam_update_aps_ctl;
    oam_ether_tx_ctl_t oam_ether_tx_ctl;
    out_pkt_t oam_pkt;

    int32 ret = 0;
    uint8* pkt  = NULL;
    uint8 header_crc = 0;
    uint32 pkt_crc = 0;
    uint32 cmd = 0;

    sal_memset(&oam_update_aps_ctl, 0, sizeof(oam_update_aps_ctl));
    cmd = DRV_IOR(OamUpdateApsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_update_aps_ctl));
    sal_memset(&oam_ether_tx_ctl, 0, sizeof(oam_ether_tx_ctl_t));
    cmd = DRV_IOR(OamEtherTxCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_ether_tx_ctl));

    sal_memset(&oam_pkt, 0, sizeof(out_pkt_t));
    oam_pkt.packet_length = APS_MESSAGE_LEN;

    pkt = sal_malloc(MTU);
    if(NULL == pkt)
    {
        CMODEL_DEBUG_OUT_INFO(" No memory! File:%s Line:%d Function:%s\n",
            __FILE__, __LINE__, __FUNCTION__);
        goto ERROR;
    }
    sal_memset(pkt, 0, MTU);

    oam_pkt.pkt = pkt;
    oam_pkt.exception = sal_malloc(GREAT_BELT_EXCEPTION_LEN);
    if(NULL == oam_pkt.exception)
    {
        CMODEL_DEBUG_OUT_INFO(" No memory! File:%s Line:%d Function:%s\n",
            __FILE__, __LINE__, __FUNCTION__);
        goto ERROR;
    }
    sal_memset(oam_pkt.exception, 0, GREAT_BELT_EXCEPTION_LEN);

    sal_memset(&packet_header, 0, sizeof(ms_packet_header_t));
    packet_header.next_hop_ptr = oam_update_aps_ctl.sig_fail_next_hop_ptr;
    packet_header.dest_map = (oam_update_aps_ctl.dest_chip_id << 16) |oam_update_aps_ctl.dest_port_id;
    packet_header.source_port = (oam_ether_tx_ctl.oam_chip_id << 9) | oam_ether_tx_ctl.oam_port_id;

    DRV_IF_ERROR_RETURN(swap32((uint32 *)&packet_header, (GREAT_BELT_HEADER_LEN) / 4, HOST_TO_NETWORK));
    //header_crc = calculate_crc8((uint8 *)&packet_header, GREAT_BELT_HEADER_LEN, 0);
    header_crc = calculate_crc4((uint8 *)&packet_header, GREAT_BELT_HEADER_LEN, 0);
    ((uint8*)(&packet_header))[GREATBELT_HDR_CRC_OFFSET] &= 0xF0;
    ((uint8*)(&packet_header))[GREATBELT_HDR_CRC_OFFSET] |= (header_crc&0x0F);

    pkt[GREAT_BELT_HEADER_LEN + 0] = (oam_update_aps_ctl.macda_high >> 8) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 1] = (oam_update_aps_ctl.macda_high >> 0) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 2] = (oam_update_aps_ctl.macda_low >> 24) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 3] = (oam_update_aps_ctl.macda_low >> 16) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 4] = (oam_update_aps_ctl.macda_low >>  8) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 5] = (oam_update_aps_ctl.macda_low >>  0) & 0xFF;

    pkt[GREAT_BELT_HEADER_LEN + 6] = (oam_update_aps_ctl.macsa_high >> 8) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 7] = oam_update_aps_ctl.macsa_high & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 8] = (oam_update_aps_ctl.macsa_low >> 24) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 9] = (oam_update_aps_ctl.macsa_low >> 16) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 10] = (oam_update_aps_ctl.macsa_low >> 8) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 11] = oam_update_aps_ctl.macsa_low & 0xFF;

    pkt[GREAT_BELT_HEADER_LEN + 12] = (oam_update_aps_ctl.tpid >> 8) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 13] = oam_update_aps_ctl.tpid & 0xFF;

    pkt[GREAT_BELT_HEADER_LEN + 14] = (oam_update_aps_ctl.vlan >> 8) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 15] = oam_update_aps_ctl.vlan & 0xFF;

    pkt[GREAT_BELT_HEADER_LEN + 16] = (update_info->mep_index>> 8) & 0xFF;/*Mep index*/
    pkt[GREAT_BELT_HEADER_LEN + 17] = update_info->mep_index & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 18] = (update_info->rmep_index>> 8) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 19] = update_info->rmep_index & 0xFF;
    /*in p2mp mode, if update MP is local MEP, rmepIndex is invalid*/

    pkt[GREAT_BELT_HEADER_LEN + 20] = (ma_index >> 8) & 0xFF;
    pkt[GREAT_BELT_HEADER_LEN + 21] = ma_index & 0xFF;
    /*use maIndex and srcChipId to get dsAps*/

    pkt[GREAT_BELT_HEADER_LEN + 22] = signal_fail;

    pkt[GREAT_BELT_HEADER_LEN + 23] = oam_update_aps_ctl.src_chip_id;

    pkt[GREAT_BELT_HEADER_LEN + 24] = is_remote;

    sal_memmove(pkt, pkt + GREAT_BELT_HEADER_LEN , APS_MESSAGE_LEN);

    ctcutil_crc32(0xFFFFFFFF, oam_pkt.pkt,
                 (oam_pkt.packet_length - 4), &pkt_crc);
    DRV_IF_ERROR_RETURN(swap32(&pkt_crc, 1, HOST_TO_NETWORK));

    (oam_pkt.pkt)[oam_pkt.packet_length - 4] = (pkt_crc >> 24) & 0xFF;
    (oam_pkt.pkt)[oam_pkt.packet_length - 3] = (pkt_crc >> 16) & 0xFF;
    (oam_pkt.pkt)[oam_pkt.packet_length - 2] = (pkt_crc >> 8) & 0xFF;
    (oam_pkt.pkt)[oam_pkt.packet_length - 1] = pkt_crc  & 0xFF;

    oam_pkt.pkt_id = 0;
    oam_pkt.chan_id = OAM_CHANID;
    oam_pkt.chip_id = chip_id;
    oam_pkt.dest_queue = SIM_FWD_Q;
    oam_pkt.module_bus.pkt_len = APS_MESSAGE_LEN;
    sal_memcpy(&oam_pkt.module_bus.packet_header, &packet_header, GREAT_BELT_HEADER_LEN);


    DRV_IF_ERROR_RETURN(sim_oam_output_packet(oam_pkt.pkt, oam_pkt.packet_length,
                                oam_pkt.chip_id, oam_pkt.chan_id));

#if (SDK_WORK_PLATFORM == 1)
    DRV_IF_ERROR_RETURN(swap32((uint32 *)&packet_header, (GREAT_BELT_HEADER_LEN) / 4, NETWORK_TO_HOST));

    if (cosim_db.store_bheader)
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_bheader(((void *)&packet_header), SIM_MODULE_OAM));
    }

    if (cosim_db.store_outpkt)
    {
        ret = cosim_db.store_outpkt(oam_pkt.chip_id, oam_pkt.chan_id,
                                oam_pkt.packet_length, oam_pkt.pkt, SIM_MODULE_OAM, 0, 0);
    }
#endif

    /* Send Aps message to CPU via CpuMac, CpuMac will append the Aps Message to 64Bytes and CRC*/
    ret = ctckal_queue_send(sim_queue[SIM_FWD_Q], (void *)&oam_pkt, sizeof(out_pkt_t));

    if(DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("oam engine send aps msg to fpga error! ret = %d\n", ret);

        sal_free(oam_pkt.pkt);
        oam_pkt.pkt = NULL;
        sal_free(oam_pkt.exception);
        oam_pkt.exception = NULL;
    }

    return DRV_E_NONE;
    ERROR:
        if(oam_pkt.pkt != NULL)
        {
            sal_free(oam_pkt.pkt);
            oam_pkt.pkt = NULL;
        }
        if(oam_pkt.exception != NULL)
        {
            sal_free(oam_pkt.exception);
            oam_pkt.exception = NULL;
        }
        return DRV_E_NO_MEMORY;

}

/****************************************************************************
 * Name:       _cm_oam_write_new_mp_and_triger_aps
 * Purpose:    update DsBfdMep and DsBfdRMEP
 * Parameters:
 * Input:      ccm_pkt_info -- pointer to buffer which save information
 *                       used in module update ccm timer .
 * Output:     ccm_pkt_info -- pointer to buffer which save information
 *                       used in module update ccm timer.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_write_new_mp_and_triger_aps(oam_ccm_pkt_info_t* ccm_pkt_info)
{
    ds_eth_mep_t* new_ds_eth_mep = (ds_eth_mep_t*)ccm_pkt_info->p_new_ds_eth_mep;
    ds_eth_rmep_t* new_ds_eth_rmep = (ds_eth_rmep_t*)ccm_pkt_info->p_new_ds_eth_rmep;

    ds_bfd_mep_t* new_ds_bfd_mep = (ds_bfd_mep_t*)ccm_pkt_info->p_new_ds_bfd_mep;
    ds_bfd_rmep_t* new_ds_bfd_rmep = (ds_bfd_rmep_t*)ccm_pkt_info->p_new_ds_bfd_rmep;

    ds_ma_t* ds_ma = (ds_ma_t*)ccm_pkt_info->p_ds_ma;

    ds_eth_mep_t* ds_mep = NULL;
    ds_eth_mep_t* new_ds_mep = NULL;

    uint8 chip_id = ccm_pkt_info->chip_id;
    uint8 is_remote = ccm_pkt_info->is_remote;
    uint8 is_ether_update = ccm_pkt_info->is_ether_update;
    uint8 is_bfd_update = ccm_pkt_info->is_bfd_update;
    uint8 signal_fail = ccm_pkt_info->signal_fail;
    uint16 mep_index = ccm_pkt_info->mep_index;
    uint16 rmep_index = ccm_pkt_info->rmep_index;

    oam_update_aps_ctl_t oam_update_aps_ctl;
    oam_update_ctl_t oam_update_ctl;

    uint32 cmd = 0;
    uint8 sig_fail_remote_mismatch = FALSE;
    uint8 sig_fail_local_mismatch = FALSE;
    uint8 aps_trig = FALSE;
    uint8 sf_fail_while = 0;
    uint8 sf_fail_while_new = 0;
    uint8 is_aps_signal_fail_remote = 0;

    if(is_bfd_update)
    {/*Cmodel added*/
        if(is_remote)
        {
            ds_mep     = (ds_eth_mep_t*)ccm_pkt_info->p_ds_bfd_rmep;
            new_ds_mep = (ds_eth_mep_t*)ccm_pkt_info->p_new_ds_bfd_rmep;
            is_aps_signal_fail_remote = ((ds_bfd_rmep_t*)ds_mep)->aps_signal_fail_remote;
        }
        else
        {
            ds_mep     = (ds_eth_mep_t*)ccm_pkt_info->p_ds_bfd_mep;
            new_ds_mep = (ds_eth_mep_t*)new_ds_bfd_mep;
        }
    }
    else if(is_ether_update)
    {
        if(is_remote)
        {
            ds_mep = (ds_eth_mep_t*)ccm_pkt_info->p_ds_eth_rmep;
            new_ds_mep = (ds_eth_mep_t*)ccm_pkt_info->p_new_ds_eth_rmep;
            is_aps_signal_fail_remote =( (ds_eth_rmep_t*)ds_mep)->aps_signal_fail_remote;
        }
        else
        {
            ds_mep = (ds_eth_mep_t*)ccm_pkt_info->p_ds_eth_mep;
            new_ds_mep = (ds_eth_mep_t*)ccm_pkt_info->p_new_ds_eth_mep;
        }
    }

    sal_memset(&oam_update_aps_ctl, 0, sizeof(oam_update_aps_ctl_t));
    cmd = DRV_IOR(OamUpdateApsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_update_aps_ctl));

    sal_memset(&oam_update_ctl, 0, sizeof(oam_update_ctl));
    cmd = DRV_IOR(OamUpdateCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_update_ctl));

    /*WRITE_TIGER_APS*/
    sig_fail_remote_mismatch = (signal_fail != is_aps_signal_fail_remote) && is_remote;
    sig_fail_local_mismatch = (signal_fail != ds_ma->aps_signal_fail_local) && (!is_remote);
    aps_trig = (sig_fail_remote_mismatch || sig_fail_local_mismatch)
                && ds_ma->aps_en && oam_update_aps_ctl.global_aps_en;

    if(aps_trig)
    {
        sf_fail_while  = ds_mep->sf_fail_while;
        sf_fail_while_new = sf_fail_while? (sf_fail_while-1):0;
        if(sf_fail_while_new == 0)
        {
            new_ds_mep->sf_fail_while = ds_ma->sf_fail_while_cfg_type?
                oam_update_ctl.sf_fail_while_cfg1 : oam_update_ctl.sf_fail_while_cfg0;
        }
        else
        {
            new_ds_mep->sf_fail_while = sf_fail_while_new;
            aps_trig = FALSE;
        }
    }
    else
    {
        new_ds_mep->sf_fail_while = 0;
    }

    /* update memory info in dsMp table*/
    if(is_ether_update)
    {
        if(is_remote)
        {
            cmd = DRV_IOW(DsEthMep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mep_index, cmd, new_ds_eth_mep));
#if (SDK_WORK_PLATFORM == 1)
            if (cosim_db.store_table)
            {
                DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DsEthMep_t, mep_index,
                                            (uint32 *)new_ds_eth_mep, TRUE));
            }
#endif
            cmd = DRV_IOW(DsEthRmep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, rmep_index, cmd, new_ds_eth_rmep));
#if (SDK_WORK_PLATFORM == 1)
            if (cosim_db.store_table)
            {
                DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DsEthRmep_t, rmep_index,
                                            (uint32 *)new_ds_eth_rmep, TRUE));
            }
#endif
        }
        else
        {
            cmd = DRV_IOW(DsEthMep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mep_index, cmd, new_ds_eth_mep));
#if (SDK_WORK_PLATFORM == 1)
            if (cosim_db.store_table)
            {
                DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DsEthMep_t, mep_index,
                                            (uint32 *)new_ds_eth_mep, TRUE));
            }
#endif
        }
    }
    else if(is_bfd_update)
    {
        cmd = DRV_IOW(DsBfdMep_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mep_index, cmd, new_ds_bfd_mep));
#if (SDK_WORK_PLATFORM == 1)
        if (cosim_db.store_table)
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DsBfdMep_t, mep_index,
                                        (uint32 *)new_ds_bfd_mep, TRUE));
        }
#endif

        cmd = DRV_IOW(DsBfdRmep_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, rmep_index, cmd, new_ds_bfd_rmep));

#if (SDK_WORK_PLATFORM == 1)
        if (cosim_db.store_table)
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DsBfdRmep_t, rmep_index,
                                        (uint32 *)new_ds_bfd_rmep, TRUE));
        }
#endif
    }
    /*note: actual write MEP index= mepIndex[13:0]*2; 144 bit*/
    /*actual write RMEP index= rmepIndex[13:0]*2;*/

    if(aps_trig)
    {
       DRV_IF_ERROR_RETURN(_cm_oam_generate_aps_msg(ccm_pkt_info));
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_oam_update_eth_timer
 * Purpose:    update DsEthMep and DsEthRMEP
 * Parameters:
 * Input:      ccm_pkt_info -- pointer to buffer which save information
 *                       used in module update ccm timer .
 * Output:     ccm_pkt_info -- pointer to buffer which save information
 *                       used in module update ccm timer.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_update_eth_timer(oam_ccm_pkt_info_t* ccm_pkt_info)
{
    uint8 timer_update_en = ccm_pkt_info->timer_update_en;
    uint8 is_remote = ccm_pkt_info->is_remote;
    oam_ccm_update_info_t* update_info = ccm_pkt_info->p_update_info;
    uint8 chip_id = ccm_pkt_info->chip_id;
    ds_eth_mep_t* ds_eth_mep = (ds_eth_mep_t*)ccm_pkt_info->p_ds_eth_mep;
    ds_eth_rmep_t* ds_eth_rmep = (ds_eth_rmep_t*)ccm_pkt_info->p_ds_eth_rmep;
    ds_eth_mep_t* new_ds_eth_mep = (ds_eth_mep_t*)ccm_pkt_info->p_new_ds_eth_mep;
    ds_eth_rmep_t* new_ds_eth_rmep = (ds_eth_rmep_t*)ccm_pkt_info->p_new_ds_eth_rmep;
    ds_ma_t* ds_ma = (ds_ma_t*)ccm_pkt_info->p_ds_ma;

    oam_update_ctl_t oam_update_ctl;
    oam_rx_proc_ether_ctl_t oam_rx_proc_ether_ctl;
    oam_update_aps_ctl_t aps_ctl;
    oam_generate_ccm_pkt_info_t gen_ccm_pkt_info;
    uint8 signal_fail = FALSE;
    uint8  cci_while = 0;
    uint8  rmep_while = 0;
    uint8  cci_while_new = 0;
    uint8  rmep_while_new = 0;
    uint8  d_unexp_period_timer = 0;
    uint8  cnt_shift_while = 0;
    uint8  d_unexp_mep_timer = 0;
    uint8  d_mismerge_timer = 0;
    uint8  d_meg_lvl_timer = 0;
    uint8  d_unexp_period_timer_new = 0;
    uint8  cnt_shift_while_new = 0;
    uint8  d_unexp_mep_timer_new = 0;
    uint8  d_mismerge_timer_new = 0;
    uint8  d_meg_lvl_timer_new = 0;
    uint32 cmd = 0;
    uint8 d_unexp_period_valid  = FALSE;
    uint8 port_status_ne_two = FALSE;
    uint8 intf_status_ne_one = FALSE;
    uint8 sum_ccm = 0;
    uint32 ccm_seq_num = 0;
    uint8 csf_while = 0;
    uint8 rx_csf_while = 0;
    uint8 csf_while_new = 0;
    uint8 rx_csf_while_new = 0;

    uint8 d_csf = 0;
    uint8 is_csf_tx_en = 0;

    sal_memset(&gen_ccm_pkt_info, 0, sizeof(oam_generate_ccm_pkt_info_t));

    /*UPDATE_DS_MP2*/
    rmep_while = ds_eth_rmep->rmep_while;
    d_unexp_period_timer = ds_eth_rmep->d_unexp_period_timer;
    cnt_shift_while = ds_eth_rmep->cnt_shift_while;

    cci_while = ds_eth_mep->cci_while;
    d_unexp_mep_timer = ds_eth_mep->d_unexp_mep_timer;
    d_mismerge_timer = ds_eth_mep->d_mismerge_timer;
    d_meg_lvl_timer = ds_eth_mep->d_meg_lvl_timer;

    is_csf_tx_en = IS_BIT_SET(ds_eth_rmep->ccm_seq_num0, 6);
    d_csf        = IS_BIT_SET(ds_eth_rmep->ccm_seq_num0, 14);

    /*Csf timer*/
    if(ds_eth_rmep->is_csf_en)
    {
        csf_while =  is_csf_tx_en ? (ds_eth_rmep->ccm_seq_num0&0x7): 0;
        rx_csf_while = d_csf ? ((ds_eth_rmep->ccm_seq_num0>>10)&0xF): 0;
    }
    else
    {
        csf_while = 0;
        rx_csf_while = 0;
    }

    /*update Timer first of all*/
    if(timer_update_en)
    {
        if(is_remote)
        {
            rmep_while_new = (rmep_while != 0) ? (rmep_while - 1) : 0;
            d_unexp_period_timer_new = (d_unexp_period_timer != 0) ? (d_unexp_period_timer - 1) : 0;
            new_ds_eth_rmep->d_unexp_period_timer = d_unexp_period_timer_new;
            cnt_shift_while_new = (cnt_shift_while != 0) ? (cnt_shift_while - 1) : 0;
            csf_while_new = (csf_while != 0) ? (csf_while - 1) : 0;
            rx_csf_while_new = (rx_csf_while != 0) ? (rx_csf_while - 1) : 0;
        }
        else
        {
            cci_while_new = (cci_while != 0) ? (cci_while - 1) : 0;
            d_unexp_mep_timer_new = (d_unexp_mep_timer != 0) ? (d_unexp_mep_timer - 1) : 0;
            d_mismerge_timer_new = (d_mismerge_timer != 0) ? (d_mismerge_timer - 1) : 0;
            d_meg_lvl_timer_new = (d_meg_lvl_timer != 0) ? (d_meg_lvl_timer - 1) : 0;

            new_ds_eth_mep->d_unexp_mep_timer = d_unexp_mep_timer_new;
            new_ds_eth_mep->d_mismerge_timer = d_mismerge_timer_new;
            new_ds_eth_mep->d_meg_lvl_timer = d_meg_lvl_timer_new;
        }
    }

    sal_memset(&oam_update_ctl, 0, sizeof(oam_update_ctl));
    cmd = DRV_IOR(OamUpdateCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_update_ctl));

    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl_t));
    cmd = DRV_IOR(OamRxProcEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_rx_proc_ether_ctl));

    sal_memset(&aps_ctl, 0, sizeof(aps_ctl));
    cmd = DRV_IOR(OamUpdateApsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &aps_ctl));


    if(is_remote)
    {
        /* UPDATE_ETH_RMEP */
        d_unexp_period_valid = (ds_eth_rmep->d_unexp_period && (0 == d_unexp_period_timer_new)
                                && oam_update_ctl.itu_defect_clear_mode);

        if(ds_eth_rmep->first_pkt_rx)
        {
            if(ds_eth_rmep->d_loc)
            {
                sum_ccm = ((ds_eth_rmep->exp_ccm_num >> 6) & 0x3)
                        + ((ds_eth_rmep->exp_ccm_num >> 4) & 0x3)
                        + ((ds_eth_rmep->exp_ccm_num >> 2) & 0x3)
                        + (ds_eth_rmep->exp_ccm_num  & 0x3);

                if(0 == cnt_shift_while_new)
                {
                    new_ds_eth_rmep->exp_ccm_num = (ds_eth_rmep->exp_ccm_num << 2)& 0xFF;
                    new_ds_eth_rmep->cnt_shift_while = oam_update_ctl.cnt_shift_while_cfg;
                }
                else
                {
                    new_ds_eth_rmep->cnt_shift_while = cnt_shift_while_new;
                }
                if(0 == rmep_while_new)
                {
                    if((sum_ccm >= 3) && oam_update_ctl.itu_defect_clear_mode)
                    {
                        new_ds_eth_rmep->d_loc = FALSE;
                        new_ds_eth_rmep->rmep_while = oam_rx_proc_ether_ctl.rmep_while_cfg;/*3.5*ccmInterval*/

                        update_info->defect_type = 3 ;
                        update_info->defect_sub_type = 7;
                    }
                }
                else
                {
                    new_ds_eth_rmep->rmep_while = rmep_while_new & 0xF;
                }
            }
            else
            {
                if(rmep_while_new == 0)
                {
                    new_ds_eth_rmep->d_loc = TRUE;
                    new_ds_eth_rmep->exp_ccm_num = 0;
                    new_ds_eth_rmep->rmep_while = oam_rx_proc_ether_ctl.rmep_while_cfg;/*3.5*ccmInterval*/
                    new_ds_eth_rmep->cnt_shift_while = oam_update_ctl.cnt_shift_while_cfg;/*same to ccmInterval*/
                    new_ds_eth_mep->present_rdi |= oam_update_ctl.gen_rdi_by_dloc;

                    update_info->defect_type = 3;
                    update_info->defect_sub_type = 0 ;
                }
                else
                {
                    new_ds_eth_rmep->rmep_while = rmep_while_new;
                    new_ds_eth_rmep->cnt_shift_while = cnt_shift_while_new;
                }
            }
            if(ds_eth_rmep->is_csf_en)
            {
                /*Tx CSF*/
                if(is_csf_tx_en && (0 == csf_while_new))
                {
                    SET_BIT_RANGE(new_ds_eth_rmep->ccm_seq_num0,oam_rx_proc_ether_ctl.csf_while_cfg, 0, 3); /*CsfWhile*/

                    /*gen csf packet*/
                    gen_ccm_pkt_info.chip_id = chip_id;
                    gen_ccm_pkt_info.p_ds_ma = ds_ma;
                    gen_ccm_pkt_info.p_ds_mep = new_ds_eth_mep;
                    gen_ccm_pkt_info.p_ds_rmep = new_ds_eth_rmep;
                    gen_ccm_pkt_info.mep_index = update_info->mep_index;
                    gen_ccm_pkt_info.rmep_index = update_info->rmep_index;
                    gen_ccm_pkt_info.is_tx_csf = 1;
                    cm_oam_generate_ccm(&gen_ccm_pkt_info);
                }
                else
                {
                    SET_BIT_RANGE(new_ds_eth_rmep->ccm_seq_num0,csf_while_new, 0, 3); /*CsfWhile*/
                }

                /*Clear CSF*/
                if(d_csf && (0 == rx_csf_while_new))
                {
                    CLEAR_BIT(new_ds_eth_rmep->ccm_seq_num0,14); /*dCSF*/
                    SET_BIT_RANGE(new_ds_eth_rmep->ccm_seq_num0,0 , 10, 4); /*rxCsfWhile*/
                    update_info->defect_type = 3;
                    update_info->defect_sub_type = 2 ;
                }
                else
                {
                    SET_BIT_RANGE(new_ds_eth_rmep->ccm_seq_num0,rx_csf_while_new, 10, 4); /*rxCsfWhile*/
                }

            }

        }/*if ds_eth_rmep->first_pkt_rx */

        if(d_unexp_period_valid)
        {
            new_ds_eth_rmep->d_unexp_period = FALSE;
            update_info->defect_type = 4;
            update_info->defect_sub_type = 7 ;
        }

        port_status_ne_two = (ds_eth_rmep->rmep_last_port_status != 2);
        intf_status_ne_one = (ds_eth_rmep->rmep_last_intf_status != 1);
        signal_fail = ((new_ds_eth_rmep->d_unexp_period) && IS_BIT_SET(aps_ctl.eth_rmep_aps_sig_fail_mask, 4))
                  ||((new_ds_eth_rmep->d_loc) && IS_BIT_SET(aps_ctl.eth_rmep_aps_sig_fail_mask, 3))
                  || ((new_ds_eth_rmep->rmep_last_rdi) && IS_BIT_SET(aps_ctl.eth_rmep_aps_sig_fail_mask, 2))
                  || ((port_status_ne_two) && IS_BIT_SET(aps_ctl.eth_rmep_aps_sig_fail_mask, 1))
                  || ((intf_status_ne_one) && IS_BIT_SET(aps_ctl.eth_rmep_aps_sig_fail_mask, 0));

        ccm_pkt_info->signal_fail |= signal_fail;
    }
    else
    {   /* UPDATE_ETH_MEP */
        if(oam_update_ctl.itu_defect_clear_mode)
        {
            if(ds_eth_mep->d_meg_lvl && (0 == d_meg_lvl_timer_new))
            {
                new_ds_eth_mep->d_meg_lvl = FALSE;
                new_ds_eth_mep->d_meg_lvl_timer = 0;
                update_info->defect_type = 5;
                update_info->defect_sub_type = 6 ;
            }
            if(ds_eth_mep->d_mismerge && (0 == d_mismerge_timer_new))
            {
                new_ds_eth_mep->d_mismerge = FALSE;
                new_ds_eth_mep->d_mismerge_timer = 0;
                update_info->defect_type = 5;
                update_info->defect_sub_type = 7 ;
            }
            if(ds_eth_mep->d_unexp_mep && (0 == d_unexp_mep_timer_new))
            {
                new_ds_eth_mep->d_unexp_mep = FALSE;
                new_ds_eth_mep->d_unexp_mep_timer = 0;

                update_info->defect_type = 4;
                update_info->defect_sub_type = 6 ;
            }
        }

        if(0 == cci_while_new)
        {
            if (ds_eth_mep->cci_en)
            {
                if(ds_eth_mep->seq_num_en)
                {
                    ccm_seq_num =  (ds_eth_mep->ccm_seq_num2 << 26)| (ds_eth_mep->ccm_seq_num1 << 20)| ds_eth_mep->ccm_seq_num0;
                    ccm_seq_num += 1;
                    new_ds_eth_mep->ccm_seq_num0 = ccm_seq_num & 0xFFFFF;
                    new_ds_eth_mep->ccm_seq_num1 = (ccm_seq_num >> 20) & 0x3F;
                    new_ds_eth_mep->ccm_seq_num2 = (ccm_seq_num >> 26) & 0x3F;
                }

                /*GenCcm*/
                gen_ccm_pkt_info.chip_id = chip_id;
                gen_ccm_pkt_info.p_ds_ma = ds_ma;
                gen_ccm_pkt_info.p_ds_mep = new_ds_eth_mep;
                gen_ccm_pkt_info.p_ds_rmep = new_ds_eth_rmep;
                gen_ccm_pkt_info.mep_index = update_info->mep_index;
                gen_ccm_pkt_info.rmep_index = update_info->rmep_index;

                cm_oam_generate_ccm(&gen_ccm_pkt_info);
                /* mepIndex used to calculate header hash */
            }

             new_ds_eth_mep->cci_while = oam_update_ctl.cci_while_cfg;
        }
        else
        {
            new_ds_eth_mep->cci_while = cci_while_new;
        }

        signal_fail = ((new_ds_eth_mep->d_unexp_mep) && IS_BIT_SET(aps_ctl.eth_mep_aps_sig_fail_mask, 2))
                    ||((new_ds_eth_mep->d_mismerge) && IS_BIT_SET(aps_ctl.eth_mep_aps_sig_fail_mask, 1))
                    ||((new_ds_eth_mep->d_meg_lvl) && IS_BIT_SET(aps_ctl.eth_mep_aps_sig_fail_mask, 0));
        ccm_pkt_info->signal_fail |= signal_fail;
    }

    _cm_oam_write_new_mp_and_triger_aps(ccm_pkt_info);

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_oam_update_bfd_timer
 * Purpose:    update DsBfdMep and DsBfdRMEP
 * Parameters:
 * Input:      ccm_pkt_info -- pointer to buffer which save information
 *                       used in module update ccm timer .
 * Output:     ccm_pkt_info -- pointer to buffer which save information
 *                       used in module update ccm timer.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_update_bfd_timer(oam_ccm_pkt_info_t* ccm_pkt_info)
{
    uint8 chip_id = ccm_pkt_info->chip_id;
    uint8 is_remote = ccm_pkt_info->is_remote;
    oam_ccm_update_info_t* update_info = (oam_ccm_update_info_t*)ccm_pkt_info->p_update_info;
    ds_bfd_mep_t* ds_bfd_mep = (ds_bfd_mep_t*)ccm_pkt_info->p_ds_bfd_mep;
    ds_bfd_rmep_t* ds_bfd_rmep = (ds_bfd_rmep_t*)ccm_pkt_info->p_ds_bfd_rmep;
    ds_bfd_mep_t* new_ds_bfd_mep = (ds_bfd_mep_t*)ccm_pkt_info->p_new_ds_bfd_mep;
    ds_bfd_rmep_t* new_ds_bfd_rmep = (ds_bfd_rmep_t*)ccm_pkt_info->p_new_ds_bfd_rmep;
    ds_ma_t* ds_ma = (ds_ma_t*)ccm_pkt_info->p_ds_ma;
    oam_generate_ccm_pkt_info_t gen_ccm_pkt_info;
    oam_update_aps_ctl_t aps_ctl;
    oam_update_ctl_t update_ctl;
    oam_rx_proc_ether_ctl_t oam_rx_proc_ether_ctl;

    uint16 cci_while = 0;
    uint16 rmep_while = 0;
    uint16 rmep_while_new = 0;
    uint16 cci_while_new = 0;
    uint32 cmd = 0;
    uint8 signal_fail = FALSE;

    uint8 rx_csf_while = 0;
    uint8 csf_while = 0;
    uint8 d_mis_con_while = 0;
    uint8 cv_while = 0;

    uint8 rx_csf_while_new = 0;
    uint8 csf_while_new = 0;
    uint8 d_mis_con_while_new = 0;
    uint8 cv_while_new = 0;

    uint8 is_tx_cc = 0;

    sal_memset(&gen_ccm_pkt_info, 0, sizeof(oam_generate_ccm_pkt_info_t));

    sal_memset(&aps_ctl, 0, sizeof(aps_ctl));
    cmd = DRV_IOR(OamUpdateApsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &aps_ctl));

    sal_memset(&update_ctl, 0, sizeof(aps_ctl));
    cmd = DRV_IOR(OamUpdateCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &update_ctl));

    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl_t));
    cmd = DRV_IOR(OamRxProcEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_rx_proc_ether_ctl));


    /* UPDATE_BFD_TIMER */
    cci_while = ds_bfd_mep->hello_while;
    rx_csf_while = ds_bfd_mep->rx_csf_while;
    csf_while   = ds_bfd_mep->bfd_srcport & 0x7;

    rmep_while = ds_bfd_rmep->defect_while;
    d_mis_con_while = (ds_bfd_rmep->ip_sa>>1) & 0xF;
    cv_while = (ds_bfd_rmep->ip_sa>>5) & 0x7;

    #if 0
    CMODEL_DEBUG_OUT_INFO("\n================ OAM Engine Timer Begin================ \n");
    CMODEL_DEBUG_OUT_INFO("cci_while:%d\n",cci_while);
    CMODEL_DEBUG_OUT_INFO("rx_csf_while:%d\n",rx_csf_while);
    CMODEL_DEBUG_OUT_INFO("csf_while:%d\n",csf_while);
    CMODEL_DEBUG_OUT_INFO("rmep_while:%d\n",rmep_while);
    CMODEL_DEBUG_OUT_INFO("d_mis_con_while:%d\n",d_mis_con_while);
    CMODEL_DEBUG_OUT_INFO("cv_while:%d\n",rmep_while);
    CMODEL_DEBUG_OUT_INFO("================ OAM Engine Timer End  ================ \n");
    #endif

    if(is_remote)
    {
        if(ds_bfd_rmep->cc_tx_mode)
        {
            d_mis_con_while_new = (d_mis_con_while != 0) ? (d_mis_con_while - 1) : 0;
            cv_while_new = (cv_while != 0) ? (cv_while - 1) : 0;
        }
    }
    else
    {
        cci_while_new = (cci_while != 0) ? (cci_while - 1) : 0;
        rx_csf_while_new = (rx_csf_while != 0) ? (rx_csf_while - 1) : 0;
        csf_while_new = (csf_while != 0) ? (csf_while - 1) : 0;
        rmep_while_new = (rmep_while != 0) ? (rmep_while - 1) : 0;
    }

    /*UPDATE_BFD_MEP_RMEP*/
    if(is_remote)
    {
        if(ds_bfd_rmep->cc_tx_mode)
        {
            /*
            if(ds_bfd_rmep->first_pkt_rx)
            {
            */
            /*mis-connect detect*/
            if(ds_bfd_rmep->is_cv_en && IS_BIT_SET(ds_bfd_rmep->ip_sa,0) && (0 == d_mis_con_while_new))
            {
                CLEAR_BIT(new_ds_bfd_rmep->ip_sa,0);
                SET_BIT_RANGE(new_ds_bfd_rmep->ip_sa, 0, 1, 4);
                new_ds_bfd_mep->local_diag = (ds_bfd_mep->local_diag == 9)?0:(ds_bfd_mep->local_diag);
                update_info->defect_type = 5;
                update_info->defect_sub_type = 7;
            }
            else
            {
                SET_BIT_RANGE(new_ds_bfd_rmep->ip_sa, d_mis_con_while_new, 1, 4);
            }


            /*MPLS-TP CV*/
            if(0 == cv_while_new && ds_bfd_rmep->is_cv_en)
            {
                SET_BIT_RANGE(new_ds_bfd_rmep->ip_sa,update_ctl.cv_while_cfg, 5, 3);
                gen_ccm_pkt_info.chip_id = chip_id;
                gen_ccm_pkt_info.p_ds_ma = ds_ma;
                gen_ccm_pkt_info.p_ds_mep = new_ds_bfd_mep;
                gen_ccm_pkt_info.p_ds_rmep = new_ds_bfd_rmep;
                gen_ccm_pkt_info.mep_index = update_info->mep_index;
                gen_ccm_pkt_info.rmep_index = update_info->rmep_index;
                gen_ccm_pkt_info.is_tx_cv = 1;
                cm_oam_generate_ccm(&gen_ccm_pkt_info);
            }
            else
            {
                SET_BIT_RANGE(new_ds_bfd_rmep->ip_sa, cv_while_new, 5, 3);
            }
            //}
        }
    }
    else
    {
        if(ds_bfd_rmep->first_pkt_rx)
        {
            if(0 == rmep_while_new)
            {
                new_ds_bfd_rmep->defect_while = ds_bfd_rmep->actual_rx_interval*ds_bfd_rmep->defect_mult;
                if((BFD_STATE_UP == new_ds_bfd_mep->local_stat)||(BFD_STATE_INIT == new_ds_bfd_mep->local_stat))
                {
                    new_ds_bfd_rmep->remote_stat = BFD_STATE_DOWN;
                    new_ds_bfd_mep->local_stat = BFD_STATE_DOWN;
                    new_ds_bfd_mep->local_diag = (5== new_ds_bfd_mep->local_diag && new_ds_bfd_rmep->is_cv_en)?5:1;
                    signal_fail = (BFD_STATE_UP == ds_bfd_rmep->remote_stat)? aps_ctl.bfd_rmep_up_to_down : 0;

                    update_info->defect_type = 2;
                    update_info->defect_sub_type = 3;

                    ccm_pkt_info->signal_fail = signal_fail;
                }
            }
            else
            {
                new_ds_bfd_rmep->defect_while = rmep_while_new;
            }
        }


        is_tx_cc = 0;
        if(cci_while_new == 0) /*TX CC*/
        {
            new_ds_bfd_mep->hello_while = ds_bfd_mep->actual_min_tx_interval;
            is_tx_cc = 1;
            if(ds_bfd_mep->cci_en)
            {
                /*GenCcm*/
                gen_ccm_pkt_info.chip_id = chip_id;
                gen_ccm_pkt_info.p_ds_ma = ds_ma;
                gen_ccm_pkt_info.p_ds_mep = new_ds_bfd_mep;
                gen_ccm_pkt_info.p_ds_rmep = new_ds_bfd_rmep;
                gen_ccm_pkt_info.mep_index = update_info->mep_index;
                gen_ccm_pkt_info.rmep_index = update_info->rmep_index;
                cm_oam_generate_ccm(&gen_ccm_pkt_info);
            }
        }
        else
        {
            new_ds_bfd_mep->hello_while = cci_while_new;
        }

        if (ds_bfd_mep->is_csf_en)
        {    /*TX CSF*/
             if (ds_bfd_mep->is_csf_tx_en && 0 == csf_while_new && 0 == is_tx_cc)
             {
                SET_BIT_RANGE(new_ds_bfd_mep->bfd_srcport, oam_rx_proc_ether_ctl.csf_while_cfg, 0, 3);

                 /*GenCcm*/
                 gen_ccm_pkt_info.chip_id = chip_id;
                 gen_ccm_pkt_info.p_ds_ma = ds_ma;
                 gen_ccm_pkt_info.p_ds_mep = new_ds_bfd_mep;
                 gen_ccm_pkt_info.p_ds_rmep = new_ds_bfd_rmep;
                 gen_ccm_pkt_info.mep_index = update_info->mep_index;
                 gen_ccm_pkt_info.rmep_index = update_info->rmep_index;
                 gen_ccm_pkt_info.is_tx_csf = 1;
                 cm_oam_generate_ccm(&gen_ccm_pkt_info);
             }
             else
             {
                 SET_BIT_RANGE(new_ds_bfd_mep->bfd_srcport, csf_while_new, 0, 3);
             }

             /*CLEAR CSF DETECT*/
             if (IS_BIT_SET(new_ds_bfd_mep->bfd_srcport, 6) && (0 == rx_csf_while_new))
             {
                 CLEAR_BIT(new_ds_bfd_mep->bfd_srcport, 6);
                 new_ds_bfd_mep->rx_csf_while = 0;
                 update_info->defect_type     = 3;
                 update_info->defect_sub_type = 2;
             }
             else
             {
                 new_ds_bfd_mep->rx_csf_while = rx_csf_while_new;
             }
        }

    }

    _cm_oam_write_new_mp_and_triger_aps(ccm_pkt_info);

    return DRV_E_NONE;
}



/****************************************************************************
 * Name:       _cm_oam_update_ccm
 * Purpose:    update the state machine in dsmp in specified scope
 * Parameters:
 * Input:      chip_id -- Chip id.
 *             min_ptr -- the min update ptr.
 *             max_ptr -- the max update ptr.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/

static int32
_cm_oam_update_ccm(uint32 chip_id, uint32 min_ptr, uint32 max_ptr)
{
    oam_ccm_update_info_t update_info;
    oam_update_status_t oam_update_status;
    oam_error_cache_pkt_info_t oam_error_pkt_info ;

    ds_eth_rmep_t ds_mp;
    ds_ma_t ds_ma;

    ds_eth_mep_t ds_mep;
    ds_eth_mep_t ds_eth_mep;
    ds_eth_rmep_t ds_eth_rmep;
    ds_eth_mep_t new_ds_eth_mep;
    ds_eth_rmep_t new_ds_eth_rmep;

    ds_bfd_mep_t ds_bfd_mep;
    ds_bfd_rmep_t ds_bfd_rmep;
    ds_bfd_mep_t new_ds_bfd_mep;
    ds_bfd_rmep_t new_ds_bfd_rmep;

    oam_ccm_pkt_info_t ccm_pkt_info;

    uint32 cmd = 0;
    uint8  ccm_interval = 0;
    uint8  flag_sel = 0;
    uint16 mep_index = 0;
    uint16 rmep_index = 0;
    uint16 ma_index = 0;
    uint32 upd_ptr = 0;
    uint16 ds_mp_index2 = 0;
    uint8  active = FALSE;
    uint8  is_remote = FALSE;
    uint8  is_eth_update = FALSE;
    uint8  timer_update_en = FALSE;
    uint8  ccm_interval_ge_two = FALSE;
    uint8  is_bfd_update = FALSE;
    uint8  quater_flag_bit = FALSE;
    uint8 is_bfd = FALSE;

    uint8 cc_tx_mode = FALSE;

    for (upd_ptr = min_ptr; upd_ptr <= max_ptr; upd_ptr++)
    {
        sal_memset(&ds_mp, 0, sizeof(ds_mp));/*updPtr MUST be within the physical Memory Range*/
        cmd = DRV_IOR(DsEthRmep_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, upd_ptr, cmd, &ds_mp));

        active      = ds_mp.active;
        is_remote   = ds_mp.is_remote;
        is_bfd      = ds_mp.is_bfd;
        mep_index   = ds_mp.mep_index;

        ds_mp_index2 = is_remote ?
            ((ds_mp.eth_oam_p2_p_mode || is_bfd)?(upd_ptr - 1): mep_index):(upd_ptr + 1);
           //:((ds_mp.eth_oam_p2_p_mode || is_bfd)?(upd_ptr + 1): upd_ptr);
        /* Not same with spec, because rtl implement this way, bug 4468. Modify for cosim. */


        if(ds_mp.is_remote)
        {
            mep_index = ds_mp_index2;
            rmep_index = upd_ptr;
        }
        else/*local mep*/
        {
            mep_index = upd_ptr;
            rmep_index = ds_mp_index2;
        }

        sal_memset(&ds_mep, 0, sizeof(ds_mep));
        cmd = DRV_IOR(DsEthMep_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mep_index, cmd, &ds_mep));

        if (ds_mep.is_bfd)
        {
            sal_memset(&ds_bfd_mep, 0, sizeof(ds_bfd_mep));
            cmd = DRV_IOR(DsBfdMep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mep_index, cmd, &ds_bfd_mep));

            sal_memset(&ds_bfd_rmep, 0, sizeof(ds_bfd_rmep));
            cmd = DRV_IOR(DsBfdRmep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, rmep_index, cmd, &ds_bfd_rmep));

            sal_memcpy(&new_ds_bfd_mep, &ds_bfd_mep, sizeof(ds_bfd_mep_t));
            sal_memcpy(&new_ds_bfd_rmep, &ds_bfd_rmep, sizeof(ds_bfd_rmep_t));

            ma_index = new_ds_bfd_mep.ma_index;

            cc_tx_mode = is_remote?ds_bfd_rmep.cc_tx_mode:ds_bfd_mep.cc_tx_mode;
        }
        else
        {
            sal_memset(&ds_eth_mep, 0, sizeof(ds_eth_mep));
            cmd = DRV_IOR(DsEthMep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mep_index, cmd, &ds_eth_mep));

            sal_memset(&ds_eth_rmep, 0, sizeof(ds_eth_rmep));
            cmd = DRV_IOR(DsEthRmep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, rmep_index, cmd, &ds_eth_rmep));

            sal_memcpy(&new_ds_eth_mep, &ds_eth_mep, sizeof(ds_eth_mep_t));
            sal_memcpy(&new_ds_eth_rmep, &ds_eth_rmep, sizeof(ds_eth_rmep_t));

            ma_index = new_ds_eth_mep.ma_index;
        }

        sal_memset(&ds_ma, 0, sizeof(ds_ma));
        cmd = DRV_IOR(DsMa_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_index, cmd, &ds_ma));
        sal_memset(&update_info, 0, sizeof(oam_ccm_update_info_t));
        update_info.mep_index = ds_mp.is_remote ? ds_mp_index2 : upd_ptr;
        update_info.rmep_index = ds_mp.is_remote ? upd_ptr : ds_mp_index2;
        update_info.is_rmep_valid = ds_mp.is_remote;

        if(!is_bfd || cc_tx_mode)
        {
            ccm_interval = (new_ds_bfd_rmep.ip_sa>>8)&0x7; /*ccmInterval[2:0]*/
            ccm_interval = (is_remote && is_bfd) ? ccm_interval : ds_ma.ccm_interval;
            quater_flag_bit = 0;
            timer_update_en = 0;
            ccm_interval_ge_two = (ccm_interval >= 2);

            if(active)
            {
               if(ccm_interval_ge_two)
               {
                    flag_sel = ccm_interval - 2;
                    sal_memset(&oam_update_status, 0, sizeof(oam_update_status));
                    cmd = DRV_IOR(OamUpdateStatus_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_update_status));
                    quater_flag_bit = IS_BIT_SET(oam_update_status.ccm_quater_flag_seen, flag_sel);
               }
               timer_update_en = quater_flag_bit || (!ccm_interval_ge_two);
            }
        }
        else
        {
            timer_update_en = active;
        }

        is_eth_update = active && (!is_bfd) && timer_update_en;
        is_bfd_update = active && is_bfd && timer_update_en;

        sal_memset(&ccm_pkt_info, 0, sizeof(ccm_pkt_info));
        ccm_pkt_info.p_ds_bfd_mep  = &ds_bfd_mep;
        ccm_pkt_info.p_ds_bfd_rmep = &ds_bfd_rmep;
        ccm_pkt_info.p_ds_eth_mep  = &ds_eth_mep;
        ccm_pkt_info.p_ds_eth_rmep = &ds_eth_rmep;

        ccm_pkt_info.p_new_ds_bfd_mep  = &new_ds_bfd_mep;
        ccm_pkt_info.p_new_ds_bfd_rmep = &new_ds_bfd_rmep;
        ccm_pkt_info.p_new_ds_eth_mep  = &new_ds_eth_mep;
        ccm_pkt_info.p_new_ds_eth_rmep = &new_ds_eth_rmep;
        ccm_pkt_info.p_ds_ma   = &ds_ma;
        ccm_pkt_info.is_remote = is_remote;
        ccm_pkt_info.chip_id   = chip_id;
        ccm_pkt_info.timer_update_en = timer_update_en;
        ccm_pkt_info.ma_index        = ma_index;
        ccm_pkt_info.mep_index       = mep_index;
        ccm_pkt_info.rmep_index      = rmep_index;
        ccm_pkt_info.p_update_info   = &update_info;
        ccm_pkt_info.is_ether_update = is_eth_update;
        ccm_pkt_info.is_bfd_update   = is_bfd_update;

        if(is_eth_update)
        {
           _cm_oam_update_eth_timer(&ccm_pkt_info);
        }
        else if(is_bfd_update)
        {
           _cm_oam_update_bfd_timer(&ccm_pkt_info);
        }

        /*update error cache*/
        if(update_info.defect_type || update_info.defect_sub_type)
        {
            sal_memset(&oam_error_pkt_info, 0, sizeof(oam_error_pkt_info));
            oam_error_pkt_info.update_info_valid = TRUE;
            oam_error_pkt_info.packet_info_valid = FALSE;
            oam_error_pkt_info.defect_type = update_info.defect_type;
            oam_error_pkt_info.defect_sub_type = update_info.defect_sub_type;
            oam_error_pkt_info.mep_index = update_info.mep_index;
            oam_error_pkt_info.rmep_index = update_info.rmep_index;
            oam_error_pkt_info.is_rmep_valid = update_info.is_rmep_valid;
            oam_error_pkt_info.chip_id = chip_id;
            cm_oam_error_cache_handle(&oam_error_pkt_info);
        }
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       cm_oam_update_ccm_timer
 * Purpose:    update the state machine in dsmp in specified scope
 * Parameters:
 * Input:      chip_id -- Chip id.
 *             min_ptr -- the min update ptr.
 *             max_ptr -- the max update ptr.
 *             update_times -- update times
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_oam_update_ccm_timer(uint32 chip_id, uint32 min_ptr, uint32 max_ptr, uint32 update_times)
{

#define INTERVAL_1_CCI_WHILE  4
#define INTERVAL_2_CCI_WHILE  12
#define INTERVAL_3_CCI_WHILE  120
#define INTERVAL_4_CCI_WHILE  1200
#define INTERVAL_5_CCI_WHILE  12000
#define INTERVAL_6_CCI_WHILE  (12000*6)
#define INTERVAL_7_CCI_WHILE  (12000*6*10)

    uint8 interval = 0;
    uint32 cmd = 0;
    oam_update_status_t oam_update_status;
    oam_update_ctl_t    oam_update_ctl;

    uint32 interval_while[8] = {0, INTERVAL_1_CCI_WHILE, INTERVAL_2_CCI_WHILE, INTERVAL_3_CCI_WHILE,
        INTERVAL_4_CCI_WHILE, INTERVAL_5_CCI_WHILE, INTERVAL_6_CCI_WHILE, INTERVAL_7_CCI_WHILE};

    sal_memset(&oam_update_status, 0, sizeof(oam_update_status_t));
    sal_memset(&oam_update_ctl, 0, sizeof(oam_update_ctl_t));

    cmd = DRV_IOR(OamUpdateCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_update_ctl));

    if(oam_update_ctl.upd_en || oam_update_ctl.bfd_upd_en)
    {
            cmd = DRV_IOR(OamUpdateStatus_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_update_status));

            if(0 == (update_times+1)%(INTERVAL_1_CCI_WHILE/4))
            {

            }
            else
            {

            }

            for(interval = 2; interval < 8; interval++)
            {
                if(0 == (update_times+1)%(interval_while[interval]/4))
                {
                    SET_BIT(oam_update_status.ccm_quater_flag_seen, (interval-2));
                }
                else
                {
                    CLEAR_BIT(oam_update_status.ccm_quater_flag_seen, (interval-2));
                }
            }

            cmd = DRV_IOW(OamUpdateStatus_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_update_status));

            DRV_IF_ERROR_RETURN(_cm_oam_update_ccm(chip_id, min_ptr, max_ptr));
    }

    return DRV_E_NONE;
}


/**
 @brief oam engine ccm timer simulation

 @param[int] arg         point to argument function

 @return CTC_E_XXX

*/
void
cm_oam_cfm_ccm_while_timer_handler(void* arg)
{
#if (SDK_WORK_PLATFORM == 1 && SDK_WORK_ENV == 1)  /*simulation */
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    static uint32 update_cnt = 0;

    drv_get_chipnum(&lchip_num);

    sal_timer_stop(cm_cfm_ccm_timer);

    update_cnt++;
    if (CM_OAM_CCM_UPDATE_CNT_MAX == update_cnt)
    {
        update_cnt = 0;
    }

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        cm_oam_update_ccm_timer(lchip, 2, 2046, update_cnt);
    }

    sal_timer_start(cm_cfm_ccm_timer, 250);

#endif
}

int32
cm_oam_scan_defect_timer(uint32 chip_id, uint32 scan_times);

static void
cm_oam_cfm_error_cache_timer_handler(void* arg)
{

#if (SDK_WORK_PLATFORM == 1 && SDK_WORK_ENV == 1)  /*simulation */
    uint8 lchip  = 0;
    uint8 lchip_num = 0;
#endif

    sal_timer_stop(cm_cfm_error_cache_timer);
#if (SDK_WORK_PLATFORM == 1 && SDK_WORK_ENV == 1)  /*simulation */
    drv_get_chipnum(&lchip_num);

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        cm_oam_scan_defect_timer(lchip, 1);
    }
#endif
    sal_timer_start(cm_cfm_error_cache_timer, 1000);

}


int32
cm_oam_cfm_run_error_cache_timer(bool enable)
{
    int ret = 0;

    if (enable == TRUE)
    {
        if (!cm_cfm_error_cache_timer)
        {
            ret = sal_timer_create(&cm_cfm_error_cache_timer, cm_oam_cfm_error_cache_timer_handler, NULL);
            if (0 != ret)
            {
                sal_printf("sal_timer_create failed  0x%x\n", ret);
                return DRV_E_CREATE_TIMER;
            }
        }

        sal_timer_start(cm_cfm_error_cache_timer, 1000);
    }
    else
    {
        if (cm_cfm_error_cache_timer)
        {
            sal_timer_stop(cm_cfm_error_cache_timer);
            sal_timer_destroy(cm_cfm_error_cache_timer);
            cm_cfm_error_cache_timer = NULL;
        }
    }

    return DRV_E_NONE;
}


/**
 @brief enable/disable of oam engine ccm timer

 @param[int] enable      enable/disable oam engine ccm timer

 @return CTC_E_XXX

*/
uint32
cm_oam_cfm_run_ccm(bool enable)
{
#if (SDK_WORK_PLATFORM == 1 && SDK_WORK_ENV == 1)  /*simulation */
    int ret = 0;
    if (enable == TRUE)
    {
        if (!cm_cfm_ccm_timer)
        {
            ret = sal_timer_create(&cm_cfm_ccm_timer, &cm_oam_cfm_ccm_while_timer_handler, NULL);
            if (0 != ret)
            {
                sal_printf("sal_timer_create failed  0x%x\n", ret);
                return DRV_E_CREATE_TIMER;
            }
        }

        sal_timer_start(cm_cfm_ccm_timer, 250);
    }
    else
    {
        if (cm_cfm_ccm_timer)
        {
            sal_timer_stop(cm_cfm_ccm_timer);
            sal_timer_destroy(cm_cfm_ccm_timer);
            cm_cfm_ccm_timer = NULL;
        }
    }

#endif

    return DRV_E_NONE;

}


int32
cm_feature_timer_init(void)
{
    drv_work_platform_type_t platform_type;
    drv_work_env_type_t workenv_type;

    drv_get_platform_type(&platform_type);
    drv_get_workenv_type(&workenv_type);

    if ((SW_SIM_PLATFORM == platform_type) && (WITH_CMODEL == workenv_type))
    {
        cm_oam_cfm_run_error_cache_timer(TRUE);
        cm_oam_cfm_run_ccm(TRUE);
    }

    return DRV_E_NONE;
}

