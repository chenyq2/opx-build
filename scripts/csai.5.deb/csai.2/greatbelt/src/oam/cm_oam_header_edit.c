/****************************************************************************
 * cm_oam_header_edit.c : Change the PacketHeader of the Packet while need
                          to relay the packet to Forwarding.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-11-23.
 * Reason:       First Create.
 *
 * Revision:     V2.0.
 * Author:       mengzw.
 * Date:         2011-04-08.
 * Reason:       Sync for spec V2.0.
 *
 * Revision:     V4.28.
 * Author:       zhaomc.
 * Date:         2011-09-28.
 * Reason:       Sync for spec V4.28.
 ****************************************************************************/
 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/

#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include <time.h>

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/
uint8 cm_oam_gen_header_hash(uint16 mep_index, uint16 rmep_index, uint8 old_crc)
{
    uint8 D[32] = {0}, C[8] = {0};
    uint8 new_crc[8] = {0};
    uint32 i = 0;
    uint32 data = 0;
    uint8 result = 0;

    data = (mep_index <<16) | rmep_index;
    for (i = 0; i < 32; i++)
    {
        D[i] = IS_BIT_SET(data, i);
    }

    for (i = 0; i < 8; i++)
    {
        C[i] = IS_BIT_SET(old_crc, i);
    }

    new_crc[0] = D[31] ^ D[25] ^ D[24] ^ D[23] ^ D[21] ^ D[18] ^ D[15] ^
        D[14] ^ D[11] ^ D[10] ^ D[9] ^ D[6] ^ D[4] ^ D[3] ^
        D[0] ^ C[0] ^ C[1] ^ C[7];
    new_crc[1] = D[26] ^ D[25] ^ D[24] ^ D[22] ^ D[19] ^ D[16] ^ D[15] ^
        D[12] ^ D[11] ^ D[10] ^ D[7] ^ D[5] ^ D[4] ^ D[1] ^
        C[0] ^ C[1] ^ C[2];
    new_crc[2] = D[27] ^ D[26] ^ D[25] ^ D[23] ^ D[20] ^ D[17] ^ D[16] ^
        D[13] ^ D[12] ^ D[11] ^ D[8] ^ D[6] ^ D[5] ^ D[2] ^
        C[1] ^ C[2] ^ C[3];
    new_crc[3] = D[28] ^ D[27] ^ D[26] ^ D[24] ^ D[21] ^ D[18] ^ D[17] ^
        D[14] ^ D[13] ^ D[12] ^ D[9] ^ D[7] ^ D[6] ^ D[3] ^
        C[0] ^ C[2] ^ C[3] ^ C[4];
    new_crc[4] = D[31] ^ D[29] ^ D[28] ^ D[27] ^ D[24] ^ D[23] ^ D[22] ^
        D[21] ^ D[19] ^ D[13] ^ D[11] ^ D[9] ^ D[8] ^ D[7] ^
        D[6] ^ D[3] ^ D[0] ^ C[0] ^ C[3] ^ C[4] ^ C[5] ^ C[7];
    new_crc[5] = D[31] ^ D[30] ^ D[29] ^ D[28] ^ D[22] ^ D[21] ^ D[20] ^
        D[18] ^ D[15] ^ D[12] ^ D[11] ^ D[8] ^ D[7] ^ D[6] ^
        D[3] ^ D[1] ^ D[0] ^ C[4] ^ C[5] ^ C[6] ^ C[7];
    new_crc[6] = D[31] ^ D[30] ^ D[29] ^ D[23] ^ D[22] ^ D[21] ^ D[19] ^
        D[16] ^ D[13] ^ D[12] ^ D[9] ^ D[8] ^ D[7] ^ D[4] ^
        D[2] ^ D[1] ^ C[5] ^ C[6] ^ C[7];
    new_crc[7] = D[31] ^ D[30] ^ D[24] ^ D[23] ^ D[22] ^ D[20] ^ D[17] ^
        D[14] ^ D[13] ^ D[10] ^ D[9] ^ D[8] ^ D[5] ^ D[3] ^
        D[2] ^ C[0] ^ C[6] ^ C[7];

    result  = new_crc[7] << 7 | new_crc[6] << 6 | new_crc[5] << 5 | new_crc[4] << 4
               | new_crc[3] << 3 | new_crc[2] << 2 | new_crc[1] << 1 | new_crc[0];

    return result;
}

int32 cm_oam_com_get_link_agg_port(uint8 chip_id ,uint16 dest_id, uint8 crc)
{
    ds_link_aggregate_group_t ds_link_aggregate_group;
    ds_link_aggregate_member_t ds_link_aggregate_member;

    q_write_ctl_t que_write_ctl;

    uint8 linkagg_id = 0;
    uint8 linkagg_sel = 0;
    uint32 cmd = 0;
    uint16 linkagg_mem_num = 0;
    uint16 linkagg_mem_base = 0;
    uint16 linkagg_port_rmep_en = 0;
    uint16 linkagg_flow_num = 0;
    uint16 linkagg_port_member_ptr = 0;
    uint16 header_hash = 0;
    uint32 ds_linkagg_ptr = 0;

    uint16 tx_dest_port = 0;
    /* localPhyPort level link aggregation */
    sal_memset(&ds_link_aggregate_group, 0, sizeof(ds_link_aggregate_group_t));
    linkagg_id = dest_id & 0x3F;
    cmd = DRV_IOR(DsLinkAggregateGroup_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, linkagg_id, cmd, &ds_link_aggregate_group));

    linkagg_mem_num         = ds_link_aggregate_group.link_agg_mem_num;
    linkagg_mem_base        = ds_link_aggregate_group.link_agg_mem_base;
    linkagg_port_rmep_en    = ds_link_aggregate_group.link_agg_port_remap_en;
    linkagg_flow_num        = ds_link_aggregate_group.link_agg_flow_num;
    linkagg_port_member_ptr = ds_link_aggregate_group.link_agg_port_member_ptr;

    if (!linkagg_port_rmep_en)   /* static load balance */
    {
        /* if (QwriteCtl.headerHashMode) headerHash[7:0] = Generate hash use (headerHash[7:0]); */
        sal_memset(&que_write_ctl, 0, sizeof(q_write_ctl_t));

        cmd = DRV_IOR(QWriteCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &que_write_ctl));

        header_hash = crc;

        if (linkagg_mem_num == 0)
        {
            linkagg_sel = header_hash & 0xFF;   /* 256 members */
        }
        else if (linkagg_mem_num <= 16)
        {
            linkagg_sel = header_hash % linkagg_mem_num;
        }
        else if (linkagg_mem_num == 32)
        {
            linkagg_sel = header_hash & 0x1F;
        }
        else if (linkagg_mem_num == 64)
        {
            linkagg_sel = header_hash & 0x3F;
        }
        else if (linkagg_mem_num == 128)
        {
            linkagg_sel = header_hash & 0x7F;
        }
        else
        {
            linkagg_sel = header_hash & 0xFF;   /* 256 members */
        }

        sal_memset(&ds_link_aggregate_member, 0, sizeof(ds_link_aggregate_member_t));
        cmd = DRV_IOR(DsLinkAggregateMember_t, DRV_ENTRY_FLAG);
        ds_linkagg_ptr = (linkagg_mem_base&0x3FF) + linkagg_sel;
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_linkagg_ptr, cmd, &ds_link_aggregate_member));

        tx_dest_port = ((ds_link_aggregate_member.dest_chip_id& 0x1F) << 9)| ds_link_aggregate_member.dest_queue;

    }
    else
    {

    }
    return tx_dest_port;

}
/****************************************************************************
 * Name:       _cm_oam_header_edit_dm_pkt
 * Purpose:    edit ETHER_DMR TMPLS_DMM TMPLS_1DM TMPLS_DMR packet.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_header_edit_dm_pkt(oam_in_pkt_t* in_pkt)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8* pkt = in_pkt->pkt;
    uint8 layer3_offset = 0;
    uint8 layer4_offset = 0;
    uint32 time_sec_l = 0;
    uint32 time_sec_h = 0;
    uint8 pkt_byte_index = 0;

    ms_packet_header_t* packet_header = pkt_info->bheader;
    greatbelt_packet_header_t cm_packet_header;

    layer3_offset = parser_result->packet_offset;
    layer4_offset = parser_result->packet_offset + 4;
    pkt_info->by_pass_all |= hard_error;
    pkt_info->discard |= hard_error;

    sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));
    cm_gen_greatbelt_packet_header(packet_header, &cm_packet_header, TRUE);

    /* if LM is in 32 bit mode: rxTimeStamp[63:0], use dmTs[35:0]; else {rxFcb[29:0],dmTs[31:0]}*/
    /*temp code by MZW, for LM+DM is remove by IPE, but not OAM*/
    if(pkt_info->lm_received_packet)
    {
        pkt_info->rx_fcb        = (cm_packet_header.fid_u.rx_fcb_31_16 << 16) | cm_packet_header.logic_src_port_u.rx_fcb_15_0;
        pkt_info->rx_fcl        = (cm_packet_header.src_ctag_offset_type_u.rxtx_fcl_31 << 31)
                                     | (cm_packet_header.ttl_u.rxtx_fcl_30_23 << 23)
                                     | (cm_packet_header.rxtx_fcl_22_17_u.rxtx_fcl_22_17 << 17)
                                     | (cm_packet_header.src_cvlan_id_valid_u.rxtx_fcl_16 << 16)
                                     | (cm_packet_header.src_cvlan_id_u.rxtx_fcl_15_4 << 4)
                                     | (cm_packet_header.rxtx_fcl3_u.rxtx_fcl_3 << 3)
                                     | (cm_packet_header.rxtx_fcl2_1_u.rxtx_fcl_2_1 << 1)
                                     | cm_packet_header.rxtx_fcl0_u.rxtx_fcl_0;
    }
    else if(cm_packet_header.ip_sa_u.share2.dm_en)
    {
        cm_get_dm_rx_timestamp_in_header(&cm_packet_header,&time_sec_h,&time_sec_l);
    }

    if (pkt_info->is_defect_free && pkt_info->is_mep_hit && pkt_info->equal_dm && !pkt_info->by_pass_all
        && (parser_result->oam_type == ETHER_DMM || parser_result->oam_type == ETHER_DMR
        || parser_result->oam_type == ETHER_1DM))
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_18_DM_TO_CPU);
        switch(parser_result->oam_type)
        {
            case ETHER_DMR:/* Rx timeStamp, 64bit format, SW only do a little simulation*/
                pkt[layer3_offset + 28] = (time_sec_h >> 24)& 0xFF;
                pkt[layer3_offset + 29] = (time_sec_h >> 16)& 0xFF;
                pkt[layer3_offset + 30] = (time_sec_h >> 8)& 0xFF;
                pkt[layer3_offset + 31] = time_sec_h & 0xFF;
                pkt[layer3_offset + 32] = (time_sec_l >> 24)& 0xFF;
                pkt[layer3_offset + 33] = (time_sec_l >> 16)& 0xFF;
                pkt[layer3_offset + 34] = (time_sec_l >> 8)& 0xFF;
                pkt[layer3_offset + 35] = time_sec_l & 0xFF;
                break;
            default:/*DMM*/
                pkt[layer3_offset + 12] = (time_sec_h >> 24)& 0xFF;
                pkt[layer3_offset + 13] = (time_sec_h >> 16)& 0xFF;
                pkt[layer3_offset + 14] = (time_sec_h >> 8)& 0xFF;
                pkt[layer3_offset + 15] = time_sec_h & 0xFF;
                pkt[layer3_offset + 16] = (time_sec_l >> 24)& 0xFF;
                pkt[layer3_offset + 17] = (time_sec_l >> 16)& 0xFF;
                pkt[layer3_offset + 18] = (time_sec_l >> 8)& 0xFF;
                pkt[layer3_offset + 19] = time_sec_l & 0xFF;
                break;
        }
    }

    if (pkt_info->is_defect_free && pkt_info->equal_dm && !pkt_info->by_pass_all
            && (parser_result->oam_type == MPLSTP_DM))
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_15_MPLS_TP_DM_DLMDM_TO_CPU);

        if(!IS_BIT_SET(parser_result->ma_id.dlm.flags, 3)) /*Query*/
        {
            for(pkt_byte_index=12; pkt_byte_index<28; pkt_byte_index++)
            {
                pkt[layer3_offset + pkt_byte_index] = 0;
            }
            pkt[layer3_offset+28] = parser_result->ma_id.dlm.timestamp1_63_to32 >>24;
            pkt[layer3_offset+29] = (parser_result->ma_id.dlm.timestamp1_63_to32 >>16) & 0xff;
            pkt[layer3_offset+30] = (parser_result->ma_id.dlm.timestamp1_63_to32 >>8) & 0xff;
            pkt[layer3_offset+31] = parser_result->ma_id.dlm.timestamp1_63_to32 & 0xff;
            pkt[layer3_offset+32] = parser_result->ma_id.dlm.timestamp1_31_to0 >>24;
            pkt[layer3_offset+33] = (parser_result->ma_id.dlm.timestamp1_31_to0 >>16) & 0xff;
            pkt[layer3_offset+34] = (parser_result->ma_id.dlm.timestamp1_31_to0 >>8) & 0xff;
            pkt[layer3_offset+35] = parser_result->ma_id.dlm.timestamp1_31_to0 & 0xff;

            /*layer3_offset+36..43, get currentTimeStamp*/
            pkt[layer3_offset + 36] = (time_sec_h >> 24)& 0xFF;
            pkt[layer3_offset + 37] = (time_sec_h >> 16)& 0xFF;
            pkt[layer3_offset + 38] = (time_sec_h >> 8)& 0xFF;
            pkt[layer3_offset + 39] = time_sec_h & 0xFF;
            pkt[layer3_offset + 40] = (time_sec_l >> 24)& 0xFF;
            pkt[layer3_offset + 41] = (time_sec_l >> 16)& 0xFF;
            pkt[layer3_offset + 42] = (time_sec_l >> 8)& 0xFF;
            pkt[layer3_offset + 43] = time_sec_l & 0xFF;
        }
        else/* response, only set TimeStamp2*/
        {
            pkt[layer3_offset + 20] = (time_sec_h >> 24)& 0xFF;
            pkt[layer3_offset + 21] = (time_sec_h >> 16)& 0xFF;
            pkt[layer3_offset + 22] = (time_sec_h >> 8)& 0xFF;
            pkt[layer3_offset + 23] = time_sec_h & 0xFF;
            pkt[layer3_offset + 24] = (time_sec_l >> 24)& 0xFF;
            pkt[layer3_offset + 25] = (time_sec_l >> 16)& 0xFF;
            pkt[layer3_offset + 26] = (time_sec_l >> 8)& 0xFF;
            pkt[layer3_offset + 27] = time_sec_l & 0xFF;
        }

    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_header_edit_lm_pkt
 * Purpose:    edit LBM LMM packet.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_header_edit_lb_lm_pkt(oam_in_pkt_t* in_pkt)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8 chip_id = in_pkt->chip_id;
    oam_header_edit_ctl_t oam_header_edit_ctl;
    uint8 lbm_mac_da[6] = {0};
    uint8* pkt = in_pkt->pkt;
    uint8 layer3_offset = parser_result->packet_offset;
    uint32 cmd = 0;
    uint8 pkt_byte_index = 0;

    ms_packet_header_t* packet_header = pkt_info->bheader;
    greatbelt_packet_header_t cm_packet_header;

    sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));
    cm_gen_greatbelt_packet_header(packet_header, &cm_packet_header, TRUE);

    sal_memset(&oam_header_edit_ctl, 0, sizeof(oam_header_edit_ctl));
    cmd = DRV_IOR(OamHeaderEditCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_header_edit_ctl));


    if(pkt_info->is_defect_free && !pkt_info->by_pass_all && (pkt_info->equal_lb || pkt_info->equal_lm)
        && cm_packet_header.ip_sa_u.share2.entropy_label_exist && (OAM_ACH == pkt_info->rx_oam_type))
    {
        pkt_byte_index = layer3_offset - 8;
        pkt[pkt_byte_index + 0] = (pkt_info->mpls_tp_entropy_label >> 12) & 0xFF;
        pkt[pkt_byte_index + 1] = (pkt_info->mpls_tp_entropy_label >> 4) & 0xFF;
        pkt[pkt_byte_index + 2] = ((pkt_info->mpls_tp_entropy_label << 4) & 0xFF) | 1;
        pkt[pkt_byte_index + 3] =  0;
    }

    /*change mac da & sa*/
    if (pkt_info->is_defect_free && parser_result->is_l2_eth_oam
        && (pkt_info->equal_lb||pkt_info->equal_lm) && (!pkt_info->by_pass_all))
    {
        sal_memcpy(lbm_mac_da, pkt, 6);
        sal_memmove(pkt, pkt + 6, 6);

        if (oam_header_edit_ctl.lbr_sa_using_lbm_da && (!IS_BIT_SET(lbm_mac_da[0], 0)))
        {
            sal_memcpy(pkt + 6, lbm_mac_da, 6);
        }
        else if (pkt_info->share_mac_en || oam_header_edit_ctl.lbr_sa_type)/*using bridge mac*/
        {
            sal_memcpy(pkt + 6, pkt_info->bridge_mac, 6);
        }
        else/*using port mac*/
        {
            sal_memcpy(pkt + 6, pkt_info->port_mac, 6);
        }
    }

    /*change opCode*/
    if (pkt_info->equal_lb && pkt_info->is_defect_free && (!pkt_info->by_pass_all))
    {
        pkt[layer3_offset + 1] = OAM_OP_LBR; /*opcode to LBR*/
        if(MPLSTP_LBM == parser_result->oam_type)
        {
            pkt[layer3_offset + 8] = OAM_TLV_TYPE_REPLY_ID; /*reply TLV*/
        }
    }

    if (pkt_info->equal_lm && pkt_info->is_defect_free && (!pkt_info->by_pass_all))
    {
        if(parser_result->oam_type == ETHER_LMM)
        {
            pkt[layer3_offset + 1] = OAM_OP_LMR;/*opcode to LMR*/
            pkt[layer3_offset + 8] = (pkt_info->rx_fcl >> 24) & 0xFF;
            pkt[layer3_offset + 9] = (pkt_info->rx_fcl >> 16) & 0xFF;
            pkt[layer3_offset + 10] = (pkt_info->rx_fcl >> 8) & 0xFF;
            pkt[layer3_offset + 11] = pkt_info->rx_fcl & 0xFF;
        }
        else
        {

            if(!IS_BIT_SET(parser_result->ma_id.dlm.flags, 3))/*Query*/
            {
                if(!pkt_info->is_mep_hit)
                {
                    SET_BIT(pkt_info->exception, OAM_EXCEPTION_14_MPLS_TP_DLM_TO_CPU);
                }
                else if(parser_result->if_status_valid && oam_header_edit_ctl.mplsdlm_tlv_chk)
                {
                    SET_BIT(pkt_info->exception, OAM_EXCEPTION_14_MPLS_TP_DLM_TO_CPU);
                }
                else
                {
                    SET_BIT(pkt[layer3_offset], 3);/*opcode to LMR*/
                }

                /*reply response message and modify packet format*/
                if(pkt_info->is_mep_hit && (0 != parser_result->ma_id.dlm.version) && oam_header_edit_ctl.mplsdlm_ver_chk)
                {
                    pkt[layer3_offset + 1] = 0x11;
                }

                if(pkt_info->is_mep_hit && oam_header_edit_ctl.mplsdlm_query_code_chk
                    && (parser_result->ma_id.dlm.control_code > oam_header_edit_ctl.mplsdlm_query_code_max_value))
                {
                    pkt[layer3_offset + 1] = 0x12;
                }

                if(pkt_info->is_mep_hit && IS_BIT_SET(parser_result->ma_id.dlm.dflags, 2) && oam_header_edit_ctl.mplsdlm_dflags_chk)
                {
                    pkt[layer3_offset + 1] = 0x13;
                }

                for(pkt_byte_index=20; pkt_byte_index<36; pkt_byte_index++)
                {
                    pkt[layer3_offset + pkt_byte_index] = 0;
                }
                pkt[layer3_offset+36] = parser_result->ma_id.dlm.counter1_63_to32>>24;
                pkt[layer3_offset+37] = (parser_result->ma_id.dlm.counter1_63_to32 >>16) & 0xff;
                pkt[layer3_offset+38] = (parser_result->ma_id.dlm.counter1_63_to32 >>8) & 0xff;
                pkt[layer3_offset+39] = parser_result->ma_id.dlm.counter1_63_to32 & 0xff;
                pkt[layer3_offset+40] = parser_result->ma_id.dlm.counter1_31_to0 >>24;
                pkt[layer3_offset+41] = (parser_result->ma_id.dlm.counter1_31_to0 >>16) & 0xff;
                pkt[layer3_offset+42] = (parser_result->ma_id.dlm.counter1_31_to0 >>8) & 0xff;
                pkt[layer3_offset+43] = parser_result->ma_id.dlm.counter1_31_to0 & 0xff;
                if(IS_BIT_SET(parser_result->ma_id.dlm.dflags, 3))
                {
                    pkt[layer3_offset+44] = pkt_info->rx_fcb >>24;
                    pkt[layer3_offset+45] = (pkt_info->rx_fcb >>16) & 0xff;
                    pkt[layer3_offset+46] = (pkt_info->rx_fcb >>8) & 0xff;
                    pkt[layer3_offset+47] = pkt_info->rx_fcb & 0xff;
                    pkt[layer3_offset+48] = pkt_info->rx_fcl >>24;
                    pkt[layer3_offset+49] = (pkt_info->rx_fcl>>16) & 0xff;
                    pkt[layer3_offset+50] = (pkt_info->rx_fcl >>8) & 0xff;
                    pkt[layer3_offset+51] = pkt_info->rx_fcl & 0xff;
                }
                else
                {
                    pkt[layer3_offset+44] = 0;
                    pkt[layer3_offset+45] = 0;
                    pkt[layer3_offset+46] = 0;
                    pkt[layer3_offset+47] = 0;
                    pkt[layer3_offset+48] = pkt_info->rx_fcl >>24;
                    pkt[layer3_offset+49] = (pkt_info->rx_fcl >>16) & 0xff;
                    pkt[layer3_offset+50] = (pkt_info->rx_fcl >>8) & 0xff;
                    pkt[layer3_offset+51] = pkt_info->rx_fcl & 0xff;
                }
            }
            else /*response*/
            {
                SET_BIT(pkt_info->exception, OAM_EXCEPTION_14_MPLS_TP_DLM_TO_CPU);
                if(IS_BIT_SET(parser_result->ma_id.dlm.dflags, 3))
                {
                    pkt[layer3_offset+28] = pkt_info->rx_fcb >>24;
                    pkt[layer3_offset+29] = (pkt_info->rx_fcb >>16) & 0xff;
                    pkt[layer3_offset+30] = (pkt_info->rx_fcb >>8) & 0xff;
                    pkt[layer3_offset+31] = pkt_info->rx_fcb & 0xff;
                    pkt[layer3_offset+32] = pkt_info->rx_fcl >>24;
                    pkt[layer3_offset+33] = (pkt_info->rx_fcl >>16) & 0xff;
                    pkt[layer3_offset+34] = (pkt_info->rx_fcl >>8) & 0xff;
                    pkt[layer3_offset+35] = pkt_info->rx_fcl & 0xff;
                }
                else
                {
                    pkt[layer3_offset+28] = 0;
                    pkt[layer3_offset+29] = 0;
                    pkt[layer3_offset+30] = 0;
                    pkt[layer3_offset+31] = 0;
                    pkt[layer3_offset+32] = pkt_info->rx_fcl >>24;
                    pkt[layer3_offset+33] = (pkt_info->rx_fcl >>16) & 0xff;
                    pkt[layer3_offset+34] = (pkt_info->rx_fcl >>8) & 0xff;
                    pkt[layer3_offset+35] = pkt_info->rx_fcl & 0xff;
                }
            }
        }

    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_header_edit_packet_head
 * Purpose:    change the packet header.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_header_edit_packet_head(oam_in_pkt_t* in_pkt)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    ms_packet_header_t* packet_header = pkt_info->bheader;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    greatbelt_packet_header_t cm_packet_header;
    uint8 chip_id = in_pkt->chip_id;
    int8 cpu_exc_bit = 0;
    uint8 ds_oam_excp_idx = 0;
    oam_header_edit_ctl_t oam_header_edit_ctl;
    ds_oam_excp_t ds_oam_excp;
    uint8 is_oam_exception_valid = FALSE;
    uint32 cpu_exception_vct = 0;
    uint8 header_hash = 0;
    uint32 cmd = 0;
    uint16 dest_id = 0;

    sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));
    cm_gen_greatbelt_packet_header(packet_header, &cm_packet_header, TRUE);

    sal_memset(&oam_header_edit_ctl, 0, sizeof(oam_header_edit_ctl_t));
    cmd = DRV_IOR(OamHeaderEditCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_header_edit_ctl));

    is_oam_exception_valid = (pkt_info->exception != 0);
    cm_packet_header.ip_sa_u.share2.rx_oam  = 0;
    cpu_exception_vct = (pkt_info->exception & oam_header_edit_ctl.cpu_exception_en);

    if (pkt_info->discard)
    {
        pkt_info->relay_all_to_cpu  = 0;
        is_oam_exception_valid      = 0;
        pkt_info->is_defect_free    = 0;
        pkt_info->by_pass_all       = 0;
    }

    if (pkt_info->relay_all_to_cpu)/*send pkt to CPU*/
    {
        cm_packet_header.next_hop_ptr = oam_header_edit_ctl.relay_all_to_cpu_nexthop_ptr & 0x3FFFF;
        cm_packet_header.dest_chip_id = oam_header_edit_ctl.local_chip_id;
        cm_packet_header.dest_id = oam_header_edit_ctl.cpu_port_id;

        sal_memset(&ds_oam_excp, 0 ,sizeof(ds_oam_excp));
        cmd = DRV_IOR(DsOamExcp_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ds_oam_excp));

        if(!oam_header_edit_ctl.use_pkt_pri)
        {
            cm_packet_header.priority = ds_oam_excp.priority;
        }

        cm_packet_header.mcast   = 0;
        cm_packet_header.from_fabric = FALSE;
        pkt_info->relay_to_cpu_valid= TRUE;/* cmodel added, send to bsr for CPU */
        CMODEL_DEBUG_OUT_INFO("\nOAM packet Relay all to cpu in OAM header edit! File:%s Line:%d Function:%s\n",
            __FILE__, __LINE__, __FUNCTION__);
    }
    else
    {
        if (is_oam_exception_valid)
        {
            if (cpu_exception_vct != 0)
            {
                for (cpu_exc_bit= 31; cpu_exc_bit >= 0; --cpu_exc_bit)
                {
                    if (IS_BIT_SET(cpu_exception_vct, cpu_exc_bit))
                    {
                        ds_oam_excp_idx = cpu_exc_bit;
                        break;
                    }
                }
                sal_memset(&ds_oam_excp, 0 ,sizeof(ds_oam_excp));
                cmd = DRV_IOR(DsOamExcp_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_oam_excp_idx, cmd, &ds_oam_excp));

                cm_packet_header.next_hop_ptr = ds_oam_excp.next_hop_ptr;
                if(!oam_header_edit_ctl.use_pkt_pri)
                {
                    cm_packet_header.priority = ds_oam_excp.priority;
                }
                cm_packet_header.dest_chip_id = oam_header_edit_ctl.local_chip_id;
                cm_packet_header.dest_id = oam_header_edit_ctl.cpu_port_id & 0xFF;
                cm_packet_header.mcast   = 0;
                pkt_info->cpu_exception_valid = TRUE;/* cmodel added, send to bsr for CPU */
                cm_packet_header.from_fabric = 0;
                CMODEL_DEBUG_OUT_INFO("\nOAM exception to CPU: 0x%08x in OAM header edit! File:%s Line:%d Function:%s\n",
                    cpu_exception_vct,  __FILE__, __LINE__, __FUNCTION__);
            }
            else
            {
                /*hard discard*/
                pkt_info->hard_discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("\n++++ Exception Discard in OAM header edit! File:%s Line:%d Function:%s, Exception 0x%x\n",
                    __FILE__, __LINE__, __FUNCTION__, pkt_info->exception);
            }
        }
        else if (pkt_info->is_defect_free && !pkt_info->by_pass_all && (pkt_info->equal_lb||pkt_info->equal_lm))
        {   /* send ptk to BSR */
            cm_packet_header.source_port = (oam_header_edit_ctl.local_chip_id << 9) | oam_header_edit_ctl.oam_port_id;

            cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr = pkt_info->mip_en?
                                                                  cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr:
                                                                  pkt_info->src_vlan_ptr;   /*src_vlam_ptr*/
            cm_packet_header.rxtx_fcl0_u.oam_use_fid = pkt_info->oam_use_fid /*oamUseFid*/;
            cm_packet_header.fid_u.share1.fid = pkt_info->oam_use_fid ? pkt_info->src_vlan_ptr : 0;
            cm_packet_header.ip_sa_u.share2.oam_type = pkt_info->rx_oam_type;/*oamType[3:0]*/
            cm_packet_header.mcast = 0;
            cm_packet_header.ip_sa_u.share2.mip_en_or_cw_added = (OAM_ACH == pkt_info->rx_oam_type) ? 1: 0;
            cm_packet_header.from_fabric = FALSE;

            cm_packet_header.packet_offset = pkt_info->packet_offset - (pkt_info->label_num<< 2);

            /*To be done , temp fix bug 1529 by MengZhw*/
            if(pkt_info->label_num)
            {
                cm_packet_header.packet_type = PKT_TYPE_MPLS;
                cm_packet_header.ip_sa_u.share3.mpls_label_disable = pkt_info->mpls_label_disable;
            }
            else if(parser_result->is_l2_eth_oam)
            {
                cm_packet_header.packet_type = PKT_TYPE_ETHERNETV2;
            }
            else
            {
                cm_packet_header.packet_type = PKT_TYPE_RESERVED;
            }

            if (pkt_info->is_up)
            {
                if (!oam_header_edit_ctl.tx_ccm_by_epe)
                {
                    /*keep dest chip id as unchange, for stacking up mep, this dest_chip_id means the chip id on which
                     the oam is lookuped, so reply the lbr/lmr to this chip id to do iloop, can get the correct
                     local_phy_port information. Spec bug 4470 */
                    //cm_packet_header.dest_chip_id = oam_header_edit_ctl.local_chip_id;/*chip id*/

                    /*iloopback channel*/
                    cm_packet_header.dest_id = (oam_header_edit_ctl.iloop_chan_id_h << 8) | oam_header_edit_ctl.iloop_chan_id;/*iloopback channel*/
                    cm_packet_header.next_hop_ptr = pkt_info->local_phy_port;/*{9'0, local_phy_port[8:0]}*/
                    cm_packet_header.next_hop_ext = 0;
                }
                else
                {
                    cm_packet_header.dest_chip_id = (pkt_info->ingress_src_port >> 9) & 0x1F;
                    cm_packet_header.dest_id = pkt_info->ingress_src_port & 0x1FF;
                    cm_packet_header.next_hop_ptr = oam_header_edit_ctl.bypass_next_hop_ptr;
                }
            }
            else
            {
                cm_packet_header.dest_chip_id = pkt_info->link_oam ? oam_header_edit_ctl.local_chip_id :((pkt_info->ingress_src_port >> 9) & 0x1F);
                dest_id = pkt_info->link_oam ? pkt_info->local_phy_port : (pkt_info->ingress_src_port & 0xFF);
                dest_id |= (oam_header_edit_ctl.brg_dest_map15_8 << 8);
                cm_packet_header.dest_id = dest_id;

                if ((OAM_ETHER == pkt_info->rx_oam_type)||(OAM_PBT == pkt_info->rx_oam_type)
                        ||(OAM_PBB_BV == pkt_info->rx_oam_type))
                {
                    cm_packet_header.next_hop_ptr = oam_header_edit_ctl.bypass_next_hop_ptr;
                }
                else
                {/*need consider mpls-tp based y.1731*/
                    cm_packet_header.next_hop_ptr = pkt_info->next_hop_ptr;
                    cm_packet_header.next_hop_ext = IS_BIT_SET(pkt_info->next_hop_ptr, 16);
                }
            }

            header_hash = cm_oam_gen_header_hash(pkt_info->mep_index, pkt_info->rmep_index, 0xff);

            cm_packet_header.header_hash2_0 = header_hash & 0x7;
            cm_packet_header.header_hash7_3 = (header_hash >> 3) & 0x1F;
            cm_packet_header.from_cpu_or_oam = TRUE;
            cm_packet_header.source_port_isolate_id_u.share2.is_up = pkt_info->is_up;

            /*cmodel added for later process*/
            pkt_info->relay_to_bsr_valid = TRUE;

            CMODEL_DEBUG_OUT_INFO("\nEqual LB or LM to BSR! File:%s Line:%d Function:%s\n",
                __FILE__, __LINE__, __FUNCTION__);
        }
        else if(pkt_info->by_pass_all) /* Bypass to BSR */
        {

            if(oam_header_edit_ctl.rbd_en)
            {
                cm_packet_header.mcast          = IS_BIT_SET(oam_header_edit_ctl.redirect_bypass_destmap, 21);
                cm_packet_header.dest_chip_id   = (oam_header_edit_ctl.redirect_bypass_destmap >> 16) & 0x1F;
                cm_packet_header.dest_id        = oam_header_edit_ctl.redirect_bypass_destmap & 0xFFFF;
                cm_packet_header.next_hop_ptr   = oam_header_edit_ctl.bypass_next_hop_ptr;
            }

            cm_packet_header.ip_sa_u.share2.mip_en_or_cw_added = (OAM_ACH == pkt_info->rx_oam_type) ? 1: 0;
            cm_packet_header.packet_offset = pkt_info->packet_offset - (pkt_info->label_num << 2);

            if(pkt_info->label_num)
            {
                cm_packet_header.packet_type = PKT_TYPE_MPLS;
                cm_packet_header.ip_sa_u.share3.mpls_label_disable = pkt_info->mpls_label_disable;
            }
            else if(parser_result->is_l2_eth_oam)
            {
                cm_packet_header.packet_type = PKT_TYPE_ETHERNETV2;
            }
            else
            {
                cm_packet_header.packet_type = PKT_TYPE_RESERVED;
            }

            pkt_info->relay_to_bsr_valid = TRUE;
            CMODEL_DEBUG_OUT_INFO("\n++++ Bypass all in OAM header edit! File:%s Line:%d Function:%s\n",
                __FILE__, __LINE__, __FUNCTION__);
        }
        else
        {
            /*hard discard*/
            pkt_info->hard_discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("\n++++ Hard Discard in OAM header edit! File:%s Line:%d Function:%s\n",
                __FILE__, __LINE__, __FUNCTION__);
        }
    }

    cm_gen_greatbelt_packet_header(packet_header, &cm_packet_header, FALSE);

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_oam_header_edit_handle
 * Purpose:    edit dm packet, lm packet and packet header.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_oam_header_edit_handle(oam_in_pkt_t* in_pkt)
{
    DRV_IF_ERROR_RETURN(_cm_oam_header_edit_dm_pkt(in_pkt));

    DRV_IF_ERROR_RETURN(_cm_oam_header_edit_lb_lm_pkt(in_pkt));

    DRV_IF_ERROR_RETURN(_cm_oam_header_edit_packet_head(in_pkt));

    return DRV_E_NONE;
}

