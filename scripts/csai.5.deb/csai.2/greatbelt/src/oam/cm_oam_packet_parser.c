
/****************************************************************************
 * cm_oam_packet_parser.c : parsing the packet in oam engine
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-11-09.
 * Reason:       First Create.
 *
 * Revision:     V2.0.
 * Author:       mengzw.
 * Date:         2011-04-08.
 * Reason:       Sync for spec V2.0.

 * Revision:     V4.28.
 * Author:       zhaomc.
 * Date:         2011-09-28.
 * Reason:       Sync for spec V4.28.
 ****************************************************************************/
 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

#define MAKE_L2PTL_CAM_KEY(eth, ppp, sap, l2type, hdr)\
    (((eth) << 22) | ((ppp) << 21) | ((sap) << 20) | ((l2type) << 16) | (hdr))


#define PORT_STATUS_TLV_CHECK ((parser_result->port_status_value  < oam_parser_ether_ctl.min_port_status_tlv_value)\
                                || (parser_result->port_status_value > oam_parser_ether_ctl.max_port_status_tlv_value )\
                                || ( parser_result->tlv_length != 1 && oam_parser_ether_ctl.tlv_length_check_en ));


#define IF_STATUS_TLV_CHECK ((parser_result->if_status_value < oam_parser_ether_ctl.min_if_status_tlv_value)\
                                || (parser_result->if_status_value > oam_parser_ether_ctl.max_if_status_tlv_value )\
                                || ( parser_result->tlv_length != 1 && oam_parser_ether_ctl.tlv_length_check_en ));
#define TLV_LEN_CHECK ((parser_result->tlv_length + offset + 3) > (cfm_pdu_length))

/****************************************************************************
 * Name:      _cm_oam_packet_parser_parse_layer2
 * Purpose:   perform layer 2 packet parsing for Eth OAM.
 * Parameters:
 * Input:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 *            parser_info -- parser information.
 *            parser_pkt_info -- pointer to buffer which save the information
 *                     uesed only in oam packet parser module.
 * Output:    in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 *            parser_pkt_info -- pointer to buffer which save the information
 *                     uesed only in oam packet parser module.
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/

static int32
_cm_oam_packet_parser_parse_layer2(oam_in_pkt_t* in_pkt, oam_parser_info_t* parser_info)
{
#define MAX_OAM_PAS_L2PTL_CAM_NUM 4
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t *)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8* l2_header = in_pkt->pkt;
    uint8 chip_id = in_pkt->chip_id;
    oam_parser_ether_ctl_t oam_parser_ether_ctl;

    uint32 key = 0;
    uint32 snap_oui = 0;
    uint16 sap = 0;
    uint16 layer2_header_protocol = 0;
    uint32 layer2_basic_offset = 0;
    uint32 cam_value = 0;
    uint32 cam_mask = 0;
    uint32 cmd = 0;
    uint32 field_id = 0;
    uint16 type_or_length = 0;
    uint8 num_of_vlans = 0;
    uint8 sap_ctl = 0;
    uint8 vlan_offset = 0;
    uint8 pbb_port_with_bvlan = 0;
    uint8 type1_is_vlan = FALSE;
    uint8 is_eth = FALSE;
    uint8 is_sap = FALSE;
    uint8 is_ppp = FALSE;
    uint8 layer2_type = 0;
    uint32 l2_cam_valid = 0;
    uint8 entry_index = 0;
    uint32 layer3_type = 0;
    uint32 additional_offset = 0;

    /*NUM_OF_VLANS*/
    parser_result->mac_da.eth.mac_da_31_to0 = MAKE_UINT32(l2_header[2], l2_header[3], l2_header[4], l2_header[5]);
    parser_result->mac_da.eth.mac_da_47_to32 = MAKE_UINT16(l2_header[0], l2_header[1]);

    parser_result->mac_sa.eth.mac_sa_31_to0 = MAKE_UINT32(l2_header[8], l2_header[9], l2_header[10], l2_header[11]);
    parser_result->mac_sa.eth.mac_sa_47_to32 = MAKE_UINT16(l2_header[6], l2_header[7]);

    /*change vlan parsing according pp parsing, bug 566*/
    pbb_port_with_bvlan = (PBB_PORT_TYPE_PIP == parser_info->pbb_src_port_type)
                          ||(PBB_PORT_TYPE_CBP == parser_info->pbb_src_port_type)
                          ||(PBB_PORT_TYPE_PNP == parser_info->pbb_src_port_type);

    /* read parser ethnet control */
    sal_memset(&oam_parser_ether_ctl, 0, sizeof(oam_parser_ether_ctl));
    cmd = DRV_IOR(OamParserEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd,  &oam_parser_ether_ctl));

    if(pbb_port_with_bvlan)
    {
        type1_is_vlan = (oam_parser_ether_ctl.bvlan_tpid == MAKE_UINT16(l2_header[12], l2_header[13]));
    }
    else
    {
        type1_is_vlan = (oam_parser_ether_ctl.cvlan_tpid == MAKE_UINT16(l2_header[12], l2_header[13]));
        if(!type1_is_vlan)
        {
            switch(parser_info->svlan_tpid_index)
            {
                case 0:
                    type1_is_vlan = (oam_parser_ether_ctl.svlan_tpid0 == MAKE_UINT16(l2_header[12], l2_header[13]) );
                    break;
                case 1:
                    type1_is_vlan = (oam_parser_ether_ctl.svlan_tpid1 == MAKE_UINT16(l2_header[12], l2_header[13]) );
                    break;
                case 2:
                    type1_is_vlan = (oam_parser_ether_ctl.svlan_tpid2 == MAKE_UINT16(l2_header[12], l2_header[13]) );
                    break;
                case 3:
                    type1_is_vlan = (oam_parser_ether_ctl.svlan_tpid3 == MAKE_UINT16(l2_header[12], l2_header[13]) );
                    break;
                default:
                    break;
            }
        }

    }
    num_of_vlans = type1_is_vlan ;

    /* ASSIGN_VLANS */
    switch(num_of_vlans)
    {
        case 1:
            type_or_length = MAKE_UINT16(l2_header[16], l2_header[17]);
            sap         = MAKE_UINT16(l2_header[18], l2_header[19]);
            sap_ctl     = l2_header[20];
            snap_oui    = (l2_header[21] << 16) | (l2_header[22] << 8) | l2_header[23];
            break;
        default:
            type_or_length = MAKE_UINT16(l2_header[12], l2_header[13]);
            sap         = MAKE_UINT16(l2_header[14], l2_header[15]);
            sap_ctl     = l2_header[16];
            snap_oui    = (l2_header[17] << 16) | (l2_header[18] << 8) | l2_header[19];
            break;
    }

    /*DECIDE_ETHER_TYPE*/
    switch(num_of_vlans)
    {
        case 1:
            vlan_offset = 4;
            break;
        default:
            vlan_offset = 0;
            break;
    }

    if(type_or_length >= oam_parser_ether_ctl.max_length_field)
    {
        layer2_type             = OAM_L2_ETH_V2;
        layer2_header_protocol  = MAKE_UINT16(l2_header[12 + vlan_offset],
                                              l2_header[13 + vlan_offset]);
        layer2_basic_offset     = 14 + vlan_offset;
    }
    else if((0xAAAA == sap) && (0x03 == sap_ctl)
        && (oam_parser_ether_ctl.allow_non_zero_oui|| (0 == snap_oui)))
    {
        layer2_type             = OAM_L2_ETH_SNAP;
        layer2_header_protocol  = MAKE_UINT16(l2_header[20 + vlan_offset],
                                              l2_header[21 + vlan_offset]);
        layer2_basic_offset     = 22 + vlan_offset;
    }
    else
    {
        layer2_type             = OAM_L2_ETH_SAP;
        layer2_header_protocol  = MAKE_UINT16(l2_header[14 + vlan_offset],
                                              l2_header[15 + vlan_offset]);
        if(3 == (sap_ctl & 0x3))
        {
            layer2_basic_offset = 17 + vlan_offset;
        }
        else
        {
            layer2_basic_offset = 18 + vlan_offset;
        }
    }

    /*L2_PROTOCOL_LOOKUP*/
    is_eth  = (OAM_L2_ETH_V2 == layer2_type)
                ||(OAM_L2_ETH_SAP == layer2_type)
                    ||(OAM_L2_ETH_SNAP == layer2_type);
    is_sap  = (OAM_L2_ETH_SAP == layer2_type);
    is_ppp  = FALSE;

    key = MAKE_L2PTL_CAM_KEY(is_eth, is_ppp, is_sap, layer2_type,layer2_header_protocol);

    cmd = DRV_IOR(OamParserLayer2ProtocolCamValid_t, OamParserLayer2ProtocolCamValid_Layer2CamEntryValid_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &l2_cam_valid));

    /* search from the match */
    entry_index = 0;
    for (;;)
    {
        /* if this entry is invalid, ignore it */
        if(!IS_BIT_SET(l2_cam_valid, entry_index))
        {
            entry_index ++;
            CONDITIONAL_BREAK(MAX_OAM_PAS_L2PTL_CAM_NUM == entry_index);
            continue;
        }

        field_id = OamParserLayer2ProtocolCam_CamValue0_f + entry_index;
        cmd = DRV_IOR(OamParserLayer2ProtocolCam_t, field_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &cam_value));

        field_id = OamParserLayer2ProtocolCam_CamMask0_f + entry_index;
        cmd = DRV_IOR(OamParserLayer2ProtocolCam_t, field_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &cam_mask));

        field_id = OamParserLayer2ProtocolCam_CamLayer3Type0_f + entry_index;
        cmd = DRV_IOR(OamParserLayer2ProtocolCam_t, field_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &layer3_type));

        field_id = OamParserLayer2ProtocolCam_AdditionalOffset0_f +entry_index;
        cmd = DRV_IOR(OamParserLayer2ProtocolCam_t, field_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &additional_offset));

        /* if matched , break for handle */
        CONDITIONAL_BREAK((cam_value & cam_mask) == (key & cam_mask));

        /* if index equal max number, break */
        entry_index ++;
        CONDITIONAL_BREAK(MAX_OAM_PAS_L2PTL_CAM_NUM == entry_index);
    }

    if(MAX_OAM_PAS_L2PTL_CAM_NUM == entry_index)
    {
        /*miss in OAMParserLayer2ProtocolCam*/
        /*parser_pkt_info->layer3_type = 0;*/
        parser_result->oam_pdu_invalid = TRUE;
        parser_result->layer3_offset = 0;
    }
    else
    {
        /* matched handle */
        /*parser_pkt_info->layer3_type = layer3_type;*/
        parser_result->layer3_offset = layer2_basic_offset + additional_offset;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_packet_parser_parse_bfd
 * Purpose:    parsing the BFD packets,GrealBelt support 3 type:
               IP/UDP BFD, MPLS BFD/MPLS TP based BFD.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_oam_packet_parser_parse_bfd(oam_in_pkt_t* in_pkt, oam_parser_info_t *parser_pkt_info)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t *)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint16 bfd_parser_offset = 0;
    uint8* pkt = in_pkt->pkt;
    uint8  chip_id = in_pkt->chip_id;
    uint8* bfd_header = NULL;
    oam_parser_ether_ctl_t oam_parser_ether_ctl;

    uint8 bfd_length_fail = FALSE;
    uint8 bfd_p2p_fail = FALSE;
    uint8 bfd_defect_mult_fail = FALSE;
    uint8 bfd_my_disc_fail = FALSE;
    uint8 bfd_your_disc_fail = FALSE;
    uint8 bfd_interval_fail = FALSE;
    uint8 bfd_p_fbit_conflict_fail = FALSE;
    uint32 cmd = 0;

    uint8 bfd_version   = 0;
    uint8 bfd_valid_len = 0;
    uint8 bfd_length    = 0;
    uint8 cbit = 0;
    uint8 abit = 0;
    uint8 dbit = 0;
    uint8 mbit = 0;

    uint8 bfd_abit_fail     = FALSE;
    uint8 bfd_mbit_fail     = FALSE;

    uint8 bfd_ach_mepid_par_offset = 0;
    uint8* bfd_mepid_header = NULL;
    uint16 ach_mepid_type = 0;
    uint16 ach_mepid_len  = 0;
    uint8 ach_mepid_type_fail = 0;
    uint8 ach_mepid_len_fail  = 0;
    //uint16 ach_field_index = 0;

    /*Parser BFD packet*/
    sal_memset(&oam_parser_ether_ctl, 0, sizeof(oam_parser_ether_ctl));
    cmd = DRV_IOR(OamParserEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd,  &oam_parser_ether_ctl));

    bfd_parser_offset = parser_result->packet_offset;
    bfd_header = pkt + bfd_parser_offset;

    bfd_version = (bfd_header[0]>>5)& 0x7;

    parser_result->ma_id.bfd.version = bfd_version;
    parser_result->ma_id.bfd.diag = bfd_header[0] & 0x1F;
    parser_result->ma_id.bfd.stat = (bfd_header[1] >>6) & 0x3;
    parser_result->ma_id.bfd.pbit = IS_BIT_SET(bfd_header[1], 5);
    parser_result->ma_id.bfd.fbit = IS_BIT_SET(bfd_header[1], 4);

    cbit = IS_BIT_SET(bfd_header[1], 3);
    abit = IS_BIT_SET(bfd_header[1], 2);
    dbit = IS_BIT_SET(bfd_header[1], 1);
    mbit = IS_BIT_SET(bfd_header[1], 0);
    parser_result->ma_id.bfd.detect_mult = bfd_header[2];

    bfd_valid_len   = parser_pkt_info->packet_length - bfd_parser_offset;
    bfd_length      = bfd_header[3];

    parser_result->ma_id.bfd.my_disc                  = MAKE_UINT32(bfd_header[4], bfd_header[5],
                                                                    bfd_header[6], bfd_header[7]);
    parser_result->ma_id.bfd.your_disc                = MAKE_UINT32(bfd_header[8], bfd_header[9],
                                                                    bfd_header[10], bfd_header[11]);
    parser_result->ma_id.bfd.desired_min_tx_interval  = MAKE_UINT32(bfd_header[12], bfd_header[13],
                                                                    bfd_header[14], bfd_header[15]);
    parser_result->ma_id.bfd.required_min_rx_interval = MAKE_UINT32(bfd_header[16], bfd_header[17],
                                                                    bfd_header[18], bfd_header[19]);

    /*BFD validation*/
    bfd_length_fail          = ((bfd_length < 24)||(bfd_valid_len < 24))&& oam_parser_ether_ctl.bfd_len_check_en;
    bfd_p2p_fail             = mbit && oam_parser_ether_ctl.bfd_p2p_check_en;
    bfd_p_fbit_conflict_fail = parser_result->ma_id.bfd.pbit && parser_result->ma_id.bfd.fbit
                                 && oam_parser_ether_ctl.bfd_pfbit_conflict_check_en;
    bfd_defect_mult_fail     = (0 == parser_result->ma_id.bfd.detect_mult || parser_result->ma_id.bfd.detect_mult>15)
                                 && oam_parser_ether_ctl.bfd_detect_mult_check_en;
    bfd_abit_fail            = abit && oam_parser_ether_ctl.bfd_abit_check_en;
    bfd_mbit_fail            = mbit && oam_parser_ether_ctl.bfd_multipoint_chk;
    bfd_my_disc_fail         = (0 == parser_result->ma_id.bfd.my_disc);
    bfd_your_disc_fail       = (0 == parser_result->ma_id.bfd.your_disc)
                                 &&((parser_result->ma_id.bfd.stat != BFD_STATE_DOWN)
                                 &&(parser_result->ma_id.bfd.stat != BFD_STATE_ADMIN_DOWN));
    bfd_interval_fail        = (0 == parser_result->ma_id.bfd.desired_min_tx_interval);

    parser_result->high_version_oam = (bfd_version != 1) && (!oam_parser_ether_ctl.ignore_bfd_version);

    /*BFD MPLS CV Parser*/
    if (MPLSTP_CV == parser_result->oam_type)
    {
        bfd_ach_mepid_par_offset = bfd_parser_offset + bfd_length;
        bfd_mepid_header = pkt + bfd_ach_mepid_par_offset;

        ach_mepid_type = MAKE_UINT16(bfd_mepid_header[0], bfd_mepid_header[1]);
        ach_mepid_len  = MAKE_UINT16(bfd_mepid_header[2], bfd_mepid_header[3]);

        ach_mepid_type_fail = oam_parser_ether_ctl.bfd_ach_mep_id_type_chk_en
                              && (ach_mepid_type > oam_parser_ether_ctl.bfd_ach_mep_id_max_type);
        ach_mepid_len_fail  = oam_parser_ether_ctl.bfd_ach_mep_id_len_chk_en
                              && (ach_mepid_len > oam_parser_ether_ctl.bfd_ach_mep_id_max_len); /*maxMepidLen suport 32Byptes*/

        if (!ach_mepid_type_fail && !ach_mepid_len_fail && ach_mepid_len != 0) /*bfd_mepid_header = 32+4 = 36Bytes*/
        {
            parser_result->ccm_seq_num.bfd.ach_mepid_field2_287_to272 = MAKE_UINT16(bfd_mepid_header[0], bfd_mepid_header[1]);
            parser_result->mac_sa.bfd.ach_mepid_field1_271_to256 = MAKE_UINT16(bfd_mepid_header[2], bfd_mepid_header[3]);

            if (ach_mepid_len > 0)
            {
                parser_result->mac_sa.bfd.ach_mepid_field1_255_to224
                            = MAKE_UINT32(bfd_mepid_header[4], bfd_mepid_header[5], bfd_mepid_header[6], bfd_mepid_header[7]);
                if (ach_mepid_len < 4)
                {
                    SET_BIT_RANGE(parser_result->mac_sa.bfd.ach_mepid_field1_255_to224, 0, (ach_mepid_len - 0)*8, (4 - ach_mepid_len)*8);
                }
            }
            if (ach_mepid_len > 4)
            {
                parser_result->ma_id.bfd.ach_mepid_field0_223_to192
                            = MAKE_UINT32(bfd_mepid_header[8], bfd_mepid_header[9], bfd_mepid_header[10], bfd_mepid_header[11]);
                if (ach_mepid_len < 8)
                {
                    SET_BIT_RANGE(parser_result->ma_id.bfd.ach_mepid_field0_223_to192, 0, (ach_mepid_len - 4)*8, (8 - ach_mepid_len)*8);
                }
            }
            if (ach_mepid_len > 8)
            {
                parser_result->ma_id.bfd.ach_mepid_field0_191_to160
                            = MAKE_UINT32(bfd_mepid_header[12], bfd_mepid_header[13], bfd_mepid_header[14], bfd_mepid_header[15]);
                if (ach_mepid_len < 12)
                {
                    SET_BIT_RANGE(parser_result->ma_id.bfd.ach_mepid_field0_191_to160, 0, (ach_mepid_len - 8)*8, (12 - ach_mepid_len)*8);
                }
            }
            if (ach_mepid_len > 12)
            {
                parser_result->ma_id.bfd.ach_mepid_field0_159_to128
                            = MAKE_UINT32(bfd_mepid_header[16], bfd_mepid_header[17], bfd_mepid_header[18], bfd_mepid_header[19]);
                if (ach_mepid_len < 16)
                {
                    SET_BIT_RANGE(parser_result->ma_id.bfd.ach_mepid_field0_159_to128, 0, (ach_mepid_len - 12)*8, (16 - ach_mepid_len)*8);
                }
            }
            if (ach_mepid_len > 16)
            {
                parser_result->ma_id.bfd.ach_mepid_field0_127_to96
                            = MAKE_UINT32(bfd_mepid_header[20], bfd_mepid_header[21], bfd_mepid_header[22], bfd_mepid_header[23]);
                if (ach_mepid_len < 20)
                {
                    SET_BIT_RANGE(parser_result->ma_id.bfd.ach_mepid_field0_127_to96, 0, (ach_mepid_len - 16)*8, (20 - ach_mepid_len)*8);
                }
            }
            if (ach_mepid_len > 20)
            {
                parser_result->ma_id.bfd.ach_mepid_field0_95_to64
                            = MAKE_UINT32(bfd_mepid_header[24], bfd_mepid_header[25], bfd_mepid_header[26], bfd_mepid_header[27]);
                if (ach_mepid_len < 24)
                {
                    SET_BIT_RANGE(parser_result->ma_id.bfd.ach_mepid_field0_95_to64, 0, (ach_mepid_len - 20)*8, (24 - ach_mepid_len)*8);
                }
            }
            if (ach_mepid_len > 24)
            {
                parser_result->ma_id.bfd.ach_mepid_field0_63_to32
                            = MAKE_UINT32(bfd_mepid_header[28], bfd_mepid_header[29], bfd_mepid_header[30], bfd_mepid_header[31]);
                if (ach_mepid_len < 28)
                {
                    SET_BIT_RANGE(parser_result->ma_id.bfd.ach_mepid_field0_63_to32, 0, (ach_mepid_len - 24)*8, (28 - ach_mepid_len)*8);
                }
            }
            if (ach_mepid_len > 28)
            {
                parser_result->ma_id.bfd.ach_mepid_field0_31_to0
                            = MAKE_UINT32(bfd_mepid_header[32], bfd_mepid_header[33], bfd_mepid_header[34], bfd_mepid_header[35]);
                if (ach_mepid_len < 32)
                {
                    SET_BIT_RANGE(parser_result->ma_id.bfd.ach_mepid_field0_31_to0, 0, (ach_mepid_len - 28)*8, (32 - ach_mepid_len)*8);
                }
            }
        }

        parser_result->bfd_oam_pdu_invalid =  ach_mepid_type_fail || ach_mepid_len_fail;
        parser_result->bfd_oam_pdu_invalid |=  bfd_length_fail;

    }
    else
    {

        parser_result->bfd_oam_pdu_invalid |= bfd_length_fail || bfd_p2p_fail || bfd_defect_mult_fail || bfd_p_fbit_conflict_fail
                                   || bfd_my_disc_fail || bfd_your_disc_fail || bfd_interval_fail || bfd_mbit_fail || bfd_abit_fail;
    }

    parser_result->bfd_oam_pdu_invalid = parser_result->bfd_oam_pdu_invalid && !parser_result->high_version_oam;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_packet_parser_parse_eth
 * Purpose:    performing layer 3 Eth OAM parsing.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 *             parser_pkt_info -- pointer to buffer which save the information
 *                     uesed only in oam packet parser module.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_oam_packet_parser_parse_eth(oam_in_pkt_t* in_pkt,
                                          oam_parser_info_t *parser_pkt_info)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t *)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8* pkt = in_pkt->pkt;
    uint16 packet_length = parser_pkt_info->packet_length;
    uint8  chip_id = in_pkt->chip_id;
    oam_parser_ether_ctl_t oam_parser_ether_ctl;

    uint32 cmd = 0;
    uint32 offset = 0;
    uint8* l3_header = NULL;
    uint8  is_ether_oam_v0 = FALSE;
    uint8  is_mpls_tp_lbm  = FALSE;
    uint8  first_tlv_offset = 0;
    uint8  first_tlv_offset_fail = FALSE;
    uint8  rmep_id_fail = FALSE;
    uint8  ccm_interval_fail = FALSE;
    uint16 cfm_pdu_length = 0;
    uint8  cfm_pdu_length_fail = FALSE;
    uint8  cfm_pdu_mac_da_md_lvl_check_fail = FALSE;
    uint8  md_name_exist = FALSE;
    uint8  md_name_length = 0;
    uint8  ma_name_length = 0;
    uint8  md_name_length_fail = FALSE;
    uint8  ma_name_length_fail = FALSE;
    uint8  ma_id_length_fail = FALSE;
    uint8  tlv_type     = 0;
    uint8  tlv_sub_type = 0;
    uint8  tlv_offset   = 0;
    uint16  tlv_len     = 0;
    uint16  mepid       = 0;
    uint16  rmepid      = 0;
    uint8  tlv_type_fail = FALSE;
    uint8  tlv_len_fail  = FALSE;
    uint8  sub_type_fail = FALSE;
    uint8  tlv_offset_fail = FALSE;
    uint8  is_csf_parser      = 0;
    uint8  is_ccm_mac_da_high = 0;
    uint16 csf_valid_len = 0;
    uint8  csf_len_fail  = 0;

    /*DEFAULT*/
    l3_header = pkt + parser_result->packet_offset;
    parser_result->oam_pdu_invalid  = parser_result->is_l2_eth_oam
                && IS_BIT_SET(parser_result->mac_sa.eth.mac_sa_47_to32, 8);

    sal_memset(&oam_parser_ether_ctl, 0, sizeof(oam_parser_ether_ctl_t));
    cmd = DRV_IOR(OamParserEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_parser_ether_ctl));

    is_ether_oam_v0 = ((0 == (l3_header[0]& 0x1F))||oam_parser_ether_ctl.ignore_eth_oam_version);
    parser_result->high_version_oam = ((0 != (l3_header[0]& 0x1F))&&(!oam_parser_ether_ctl.ignore_eth_oam_version));

    parser_result->oam_pdu_invalid = parser_result->oam_pdu_invalid && (!parser_result->high_version_oam);

    if(is_ether_oam_v0 && !parser_result->oam_pdu_invalid)
    {
        /*ETHER_OAM_PARSING*/
        parser_result->md_lvl = (l3_header[0] >> 5) & 0x7;
        parser_result->op_code = l3_header[1];
        parser_result->oam_type = ETH_OTHER; /*ethernet oam other than ccm*/
        is_mpls_tp_lbm = (OAM_OP_LBM == parser_result->op_code)&&(OAM_ACH == parser_pkt_info->rx_oam_type);
        is_csf_parser  = (52 == parser_result->op_code);
    }
    else
    {
        return DRV_E_NONE;
    }

    if((OAM_OP_CCM != parser_result->op_code) && !is_mpls_tp_lbm && !is_csf_parser)
    {
        if(parser_result->op_code == oam_parser_ether_ctl.y1731_scc_opcode)
        {
            parser_result->oam_type = SCC;
        }

        switch(parser_result->op_code & 0xFF)
        {
            case OAM_OP_DMM:
                parser_result->oam_type = ETHER_DMM;
                break;
            case OAM_OP_TST:
                parser_result->oam_type = ETHER_TST;
                break;
            case OAM_OP_DMR:
                parser_result->oam_type = ETHER_DMR;
                break;
            case OAM_OP_1DM:
                parser_result->oam_type = ETHER_1DM;
                break;
            case OAM_OP_APS:
                parser_result->oam_type = ETHER_APS;
                break;
            case OAM_OP_RAPS:
                parser_result->oam_type = ETHER_RAPS;
                break;
            case OAM_OP_LBR:
                parser_result->oam_type = ETHER_LBR;
                break;
            case OAM_OP_LBM:
                parser_result->oam_type = ETHER_LBM;
                break;
            case OAM_OP_LMR:
                parser_result->oam_type = ETHER_LMR;
                break;
            case OAM_OP_LMM:
                parser_result->oam_type = ETHER_LMM;
                break;
            case OAM_OP_LTR:
                parser_result->oam_type = ETHER_LTR;
                break;
            case OAM_OP_LTM:
                parser_result->oam_type = ETHER_LTM;
                break;
            case OAM_OP_MCC:
                parser_result->oam_type = MCC;
                break;
            default:
                break;
        }

        parser_result->ccm_seq_num.eth.ccm_seq_num  = MAKE_UINT32(l3_header[4],l3_header[5],l3_header[6],l3_header[7]);
    }
    else if(is_mpls_tp_lbm)
    {
       /*MPLS_TP_LBM_PARSING*/
        parser_result->oam_type = MPLSTP_LBM;
        tlv_offset  =  l3_header[3];
        tlv_type    =  l3_header[8];
        tlv_len     =  MAKE_UINT16(l3_header[9], l3_header[10]);
        tlv_sub_type = l3_header[11];/*bug831*/
        mepid       = MAKE_UINT16(l3_header[12], l3_header[13]);
        parser_result->rmep_id = mepid&0x1FFF;

        /*LBM validation 1*/
        tlv_type_fail = (OAM_TLV_TYPE_TARGET_ID != tlv_type) && oam_parser_ether_ctl.mplstp_lbm_tlv_type_chk;
        tlv_len_fail  = (25 != tlv_len) && oam_parser_ether_ctl.mplstp_lbm_tlv_len_chk;
        sub_type_fail = (OAM_TLV_TYPE_TARGET_ID == tlv_type) && (0x2 != tlv_sub_type)
                            && oam_parser_ether_ctl.mplstp_lbm_tlv_sub_type_chk;
        tlv_offset_fail = (tlv_offset != oam_parser_ether_ctl.mplstp_lbm_tlv_offset)&& oam_parser_ether_ctl.mplstp_lbm_tlv_offset_chk;
        rmep_id_fail  = (tlv_type == OAM_TLV_TYPE_TARGET_ID) && (tlv_sub_type == 0x02) &&
                           ((mepid < oam_parser_ether_ctl.min_mep_id) ||
                            (mepid > oam_parser_ether_ctl.max_mep_id));

        parser_result->mpls_lbm_pdu_invalid = (tlv_type_fail || tlv_len_fail || sub_type_fail);
        parser_result->oam_pdu_invalid     |= (tlv_offset_fail ||rmep_id_fail);
    }
    else if(is_csf_parser)
    {
        parser_result->oam_type    = ETH_CSF;
        parser_result->ccm_seq_num.csf.csf_flags = l3_header[2];

        csf_valid_len = pkt_info->packet_length - parser_result->packet_offset;
        csf_len_fail =  csf_valid_len < 5;

        parser_result->oam_pdu_invalid |= csf_len_fail;
    }
    else
    {
        /*ETHER_CCM_PARSING*/
        parser_result->oam_type     = ETHER_CCM;
        parser_result->ccm_interval = l3_header[2] & 0x7;
        parser_result->ccm_seq_num.eth.ccm_seq_num  = MAKE_UINT32(l3_header[4],l3_header[5],l3_header[6],l3_header[7]);
        rmepid = ((l3_header[8] << 8) | (l3_header[9]));
        parser_result->rmep_id      = rmepid & 0x1FFF;
        parser_result->rdi          = IS_BIT_SET(l3_header[2], 7);
        parser_result->present_traffic = IS_BIT_SET(l3_header[2], 6); /*PBT presentTraffic field*/
        first_tlv_offset = l3_header[3];

        /*CFM validation 1*/
        first_tlv_offset_fail = first_tlv_offset < oam_parser_ether_ctl.first_tlv_offset_chk;
        rmep_id_fail = (rmepid < oam_parser_ether_ctl.min_mep_id)
                            || (rmepid > oam_parser_ether_ctl.max_mep_id);

        ccm_interval_fail   = (0 == parser_result->ccm_interval)
                                && (oam_parser_ether_ctl.invalid_ccm_interval_check_en);

        cfm_pdu_length      = packet_length - parser_result->packet_offset;
        cfm_pdu_length_fail = (cfm_pdu_length < oam_parser_ether_ctl.cfm_pdu_min_length)
                                ||(cfm_pdu_length > oam_parser_ether_ctl.cfm_pdu_max_length);

        is_ccm_mac_da_high = ((parser_result->mac_da.eth.mac_da_47_to32 == 0x0180)
            && ((parser_result->mac_da.eth.mac_da_31_to0&0xFFFFFFF0) == 0xc2000030));

        cfm_pdu_mac_da_md_lvl_check_fail = (((parser_result->mac_da.eth.mac_da_31_to0 & 0xF) != parser_result->md_lvl)
                                            || !is_ccm_mac_da_high)
                                            && oam_parser_ether_ctl.cfm_pdu_mac_da_md_lvl_check_en
                                            && ((OAM_ETHER == parser_pkt_info->rx_oam_type)||(OAM_PBB_BV == parser_pkt_info->rx_oam_type));
        cfm_pdu_mac_da_md_lvl_check_fail = cfm_pdu_mac_da_md_lvl_check_fail & IS_BIT_SET(parser_result->mac_da.eth.mac_da_47_to32, 8);

        parser_result->oam_pdu_invalid |= first_tlv_offset_fail || rmep_id_fail || cfm_pdu_length_fail
                                            || ccm_interval_fail ||cfm_pdu_mac_da_md_lvl_check_fail;

        if(parser_result->oam_pdu_invalid)
        {
            return DRV_E_NONE;
        }

        /*EHTER_CCM_PARSING_MAID*/
        md_name_exist =  (1 != l3_header[10]);
        //sal_memcpy(parser_result->ma_id.eth.ma_id, l3_header + 10, 48);
        parser_result->ma_id.eth.ma_id_383_to352 = MAKE_UINT32(l3_header[10], l3_header[11], l3_header[12], l3_header[13]);
        parser_result->ma_id.eth.ma_id_351_to320 = MAKE_UINT32(l3_header[14], l3_header[15], l3_header[16], l3_header[17]);
        parser_result->ma_id.eth.ma_id_319_to288 = MAKE_UINT32(l3_header[18], l3_header[19], l3_header[20], l3_header[21]);
        parser_result->ma_id.eth.ma_id_287_to256 = MAKE_UINT32(l3_header[22], l3_header[23], l3_header[24], l3_header[25]);
        parser_result->ma_id.eth.ma_id_255_to224 = MAKE_UINT32(l3_header[26], l3_header[27], l3_header[28], l3_header[29]);
        parser_result->ma_id.eth.ma_id_223_to192 = MAKE_UINT32(l3_header[30], l3_header[31], l3_header[32], l3_header[33]);
        parser_result->ma_id.eth.ma_id_191_to160 = MAKE_UINT32(l3_header[34], l3_header[35], l3_header[36], l3_header[37]);
        parser_result->ma_id.eth.ma_id_159_to128 = MAKE_UINT32(l3_header[38], l3_header[39], l3_header[40], l3_header[41]);
        parser_result->ma_id.eth.ma_id_127_to96 = MAKE_UINT32(l3_header[42], l3_header[43], l3_header[44], l3_header[45]);
        parser_result->ma_id.eth.ma_id_95_to64 = MAKE_UINT32(l3_header[46], l3_header[47], l3_header[48], l3_header[49]);
        parser_result->ma_id.eth.ma_id_63_to32 = MAKE_UINT32(l3_header[50], l3_header[51], l3_header[52], l3_header[53]);
        parser_result->ma_id.eth.ma_id_31_to0 = MAKE_UINT32(l3_header[54], l3_header[55], l3_header[56], l3_header[57]);

        if(!md_name_exist)
        {
            /*without MD name*/
            md_name_length = 0;
            ma_name_length = l3_header[12];
            parser_result->ma_id_length = ma_name_length + 3;
        }
        else
        {
            /*with MD name*/
            md_name_length = l3_header[11];
            offset = md_name_length + 13;
            ma_name_length= l3_header[offset];
            parser_result->ma_id_length = md_name_length + ma_name_length + 4;
        }

        md_name_length_fail = md_name_exist
                                &&((0 == md_name_length)||(md_name_length > oam_parser_ether_ctl.md_name_length_chk));
        ma_name_length_fail = (0 == ma_name_length);
        ma_id_length_fail   = parser_result->ma_id_length > oam_parser_ether_ctl.ma_id_length_chk;

        parser_result->oam_pdu_invalid = md_name_length_fail || ma_name_length_fail || ma_id_length_fail;

        if(parser_result->oam_pdu_invalid)
        {
            return DRV_E_NONE;
        }

        /*ETHER_CCM_PARSING_TLV*/
        offset      = first_tlv_offset + 4;
        tlv_type    = l3_header[offset];

        if( OAM_TLV_TYPE_END != tlv_type )
        {
            if(OAM_TLV_TYPE_PORT_STS == tlv_type)/*parsing 1st TLV*/
            {
                parser_result->port_status_valid = TRUE;
                parser_result->tlv_length = MAKE_UINT16(l3_header[offset + 1],l3_header[offset + 2]);
                parser_result->port_status_value = l3_header[offset + 3];
                parser_result->next_type = l3_header[offset + 4];

                parser_result->oam_pdu_invalid = PORT_STATUS_TLV_CHECK;
            }
            else if(OAM_TLV_TYPE_IF_STS == tlv_type)
            {
                parser_result->if_status_valid = TRUE;
                parser_result->tlv_length = MAKE_UINT16(l3_header[offset + 1],l3_header[offset + 2]);
                parser_result->if_status_value = l3_header[offset + 3];
                parser_result->next_type = l3_header[offset + 4];

                parser_result->oam_pdu_invalid = IF_STATUS_TLV_CHECK;
            }
            else
            {/*sender id tlv*/
                parser_result->tlv_length = MAKE_UINT16(l3_header[offset + 1],l3_header[offset + 2]);
                parser_result->tlv_options = TRUE;
                parser_result->next_type = l3_header[offset + parser_result->tlv_length + 3];

                parser_result->oam_pdu_invalid |= TLV_LEN_CHECK;
            }
            offset = offset + parser_result->tlv_length + 3 ;

            if(!parser_result->oam_pdu_invalid && (OAM_TLV_TYPE_END != parser_result->next_type))/*parsing 2nd TLV*/
            {
                if((OAM_TLV_TYPE_PORT_STS == parser_result->next_type) && (!parser_result->port_status_valid))
                {
                    parser_result->port_status_valid = TRUE;
                    parser_result->tlv_length = MAKE_UINT16(l3_header[offset + 1],l3_header[offset + 2]);
                    parser_result->port_status_value = l3_header[offset + 3];
                    parser_result->next_type = l3_header[offset + 4];
                    parser_result->oam_pdu_invalid |= PORT_STATUS_TLV_CHECK;
                }
                else if((OAM_TLV_TYPE_IF_STS == parser_result->next_type) && (!parser_result->if_status_valid))
                {
                    parser_result->if_status_valid = TRUE;
                    parser_result->tlv_length = MAKE_UINT16(l3_header[offset + 1],l3_header[offset + 2]);
                    parser_result->if_status_value = l3_header[offset + 3];
                    parser_result->next_type = l3_header[offset + 4];
                    parser_result->oam_pdu_invalid |= IF_STATUS_TLV_CHECK;
                }
                else
                {
                    parser_result->tlv_length = MAKE_UINT16(l3_header[offset + 1], l3_header[offset + 2]);
                    parser_result->tlv_options = TRUE;
                    parser_result->next_type = l3_header[offset + parser_result->tlv_length + 3];

                    parser_result->oam_pdu_invalid |= TLV_LEN_CHECK;
                }
                offset = offset + parser_result->tlv_length + 3 ;
                if(!parser_result->oam_pdu_invalid && (OAM_TLV_TYPE_END != parser_result->next_type ))/*parsing 3rd TLV*/
                {
                    if((OAM_TLV_TYPE_PORT_STS == parser_result->next_type) && (!parser_result->port_status_valid))
                    {
                        parser_result->port_status_valid = TRUE;
                        parser_result->tlv_length = MAKE_UINT16(l3_header[offset + 1] ,l3_header[offset + 2]);
                        parser_result->port_status_value = l3_header[offset + 3];
                        parser_result->next_type = l3_header[offset + 4];
                        parser_result->oam_pdu_invalid |= PORT_STATUS_TLV_CHECK;
                    }
                    else if((OAM_TLV_TYPE_IF_STS == parser_result->next_type) && (!parser_result->if_status_valid))
                    {
                        parser_result->if_status_valid = TRUE;
                        parser_result->tlv_length = MAKE_UINT16(l3_header[offset + 1],l3_header[offset + 2]);
                        parser_result->if_status_value = l3_header[offset + 3];
                        parser_result->next_type = l3_header[offset + 4];
                        parser_result->oam_pdu_invalid |= IF_STATUS_TLV_CHECK;
                    }
                    else
                    {
                        parser_result->tlv_length = MAKE_UINT16(l3_header[offset + 1], l3_header[offset + 2]);
                        parser_result->tlv_options = TRUE;
                        parser_result->next_type = l3_header[offset + parser_result->tlv_length + 3];
                        parser_result->oam_pdu_invalid |= TLV_LEN_CHECK;
                    }
                    if(OAM_TLV_TYPE_END != parser_result->next_type)
                    {
                        parser_result->tlv_options = TRUE;
                    }
                }/*the third tlv parser*/
            }/*the second tlv parser*/
        }/*the first tlv parser*/
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_packet_parser_parse_mpls_tp_dlm
 * Purpose:    parsing the MPLS TP DLM + DM OAM packets.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 *             parser_pkt_info -- pointer to buffer which save the information
 *                     uesed only in oam packet parser module.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_oam_packet_parser_parse_mpls_tp_dlm(oam_in_pkt_t* in_pkt ,
                                              oam_parser_info_t * parser_pkt_info)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8* pkt = in_pkt->pkt;
    uint8  chip_id      = in_pkt->chip_id;
    uint8* dlm_header   = NULL;
    uint16 msg_len      = 0;
    uint32 cmd          = 0;
    oam_parser_ether_ctl_t oam_parser_ether_ctl;


    sal_memset(&oam_parser_ether_ctl, 0, sizeof(oam_parser_ether_ctl_t));
    cmd = DRV_IOR(OamParserEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_parser_ether_ctl));
    /*DEFAULT*/
    dlm_header = pkt + parser_result->packet_offset;
    parser_result->ma_id.dlm.version = dlm_header[0]>>4;
    parser_result->ma_id.dlm.flags   = dlm_header[0] & 0xf;
    parser_result->ma_id.dlm.control_code = dlm_header[1];
    msg_len = MAKE_UINT16(dlm_header[2], dlm_header[3]);
    if(parser_result->oam_type == MPLSTP_DM)
    {
        parser_result->ma_id.dlm.mplstp_dm_qtf = dlm_header[4]>>4;
        parser_result->ma_id.dlm.mplstp_dm_rtf = dlm_header[4] & 0xf;
        parser_result->ma_id.dlm.mplstp_dm_rptf = dlm_header[5]>>4;
        parser_result->ma_id.dlm.timestamp1_63_to32 = MAKE_UINT32(dlm_header[12], dlm_header[13], dlm_header[14], dlm_header[15]);
        parser_result->ma_id.dlm.timestamp1_31_to0 = MAKE_UINT32(dlm_header[16], dlm_header[17], dlm_header[18], dlm_header[19]);
        parser_result->if_status_valid = msg_len > oam_parser_ether_ctl.mplstp_dm_msg_len;
        parser_result->bfd_oam_pdu_invalid |= msg_len < oam_parser_ether_ctl.mplstp_dm_msg_len;
    }
    else if(parser_result->oam_type == MPLSTP_DLM)
    {
        parser_result->ma_id.dlm.dflags = dlm_header[4]>>4;
        parser_result->ma_id.dlm.mplstp_dm_qtf = dlm_header[4] & 0xf; /*OTF*/
        parser_result->ma_id.dlm.counter1_63_to32 = MAKE_UINT32(dlm_header[20], dlm_header[21], dlm_header[22], dlm_header[23]);
        parser_result->ma_id.dlm.counter1_31_to0 = MAKE_UINT32(dlm_header[24], dlm_header[25], dlm_header[26], dlm_header[27]);
        parser_result->if_status_valid = msg_len > oam_parser_ether_ctl.mplstp_dlm_msg_len;
        parser_result->bfd_oam_pdu_invalid |= msg_len < oam_parser_ether_ctl.mplstp_dlm_msg_len;
    }
    else if(parser_result->oam_type == MPLSTP_DLMDM)
    {
        parser_result->ma_id.dlm.dflags = dlm_header[4]>>4;
        parser_result->ma_id.dlm.mplstp_dm_qtf = dlm_header[4] & 0xf;
        parser_result->ma_id.dlm.mplstp_dm_rtf = dlm_header[5] >>4;
        parser_result->ma_id.dlm.mplstp_dm_rptf = dlm_header[5]& 0xf;
        parser_result->ma_id.dlm.timestamp1_63_to32 = MAKE_UINT32(dlm_header[12], dlm_header[13], dlm_header[14], dlm_header[15]);
        parser_result->ma_id.dlm.timestamp1_31_to0 = MAKE_UINT32(dlm_header[16], dlm_header[17], dlm_header[18], dlm_header[19]);
        parser_result->ma_id.dlm.counter1_63_to32 = MAKE_UINT32(dlm_header[44], dlm_header[45], dlm_header[46], dlm_header[47]);
        parser_result->ma_id.dlm.counter1_31_to0 = MAKE_UINT32(dlm_header[48], dlm_header[49], dlm_header[50], dlm_header[51]);

        parser_result->if_status_valid = msg_len > oam_parser_ether_ctl.mplstp_dlmdm_msg_len;
        parser_result->bfd_oam_pdu_invalid |= msg_len < oam_parser_ether_ctl.mplstp_dlmdm_msg_len;
    }

    if(parser_result->if_status_valid)
    {
        parser_result->ma_id.dlm.dmlm_tlv_type = dlm_header[oam_parser_ether_ctl.mplstp_dlm_msg_len + 3];
    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_packet_parser_parse_mpls_tp_csf
 * Purpose:    parsing the MPLS TP CSF OAM packets.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 *             parser_pkt_info -- pointer to buffer which save the information
 *                     uesed only in oam packet parser module.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_oam_packet_parser_parse_mpls_tp_csf(oam_in_pkt_t* in_pkt ,
                                              oam_parser_info_t * parser_pkt_info)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8* pkt = in_pkt->pkt;
    uint8* csf_header      = NULL;
    uint16  csf_valid_len  = 0;

    csf_header = pkt + parser_result->packet_offset;

    csf_valid_len = pkt_info->packet_length - parser_result->packet_offset;

    parser_result->ccm_seq_num.csf.csf_flags = csf_header[2];
    parser_result->oam_type    = MPLSTP_CSF;

    parser_result->bfd_oam_pdu_invalid |= (csf_valid_len < 5);

    return DRV_E_NONE;
}

 /****************************************************************************
 * Name:       cm_oam_packet_parser_handle
 * Purpose:    extracting relevant information from the packet.
 * Parameters:
 * Input:      parser_info  -- pointer to buffer which save information
 *                              for parser
 *             in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_oam_packet_parser_handle(oam_in_pkt_t* in_pkt,oam_parser_info_t* parser_info )
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t *)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8* pkt = in_pkt->pkt;
    uint8  chip_id = in_pkt->chip_id;

    oam_parser_ether_ctl_t oam_parser_ether_ctl;

    uint32 cmd = 0;
    uint8  by_pass_all = FALSE;
    uint8  is_layer2_parser = FALSE;

    uint8* ach_header = NULL;
    uint16 ach_chan_type = 0;
    uint8  is_eth_oam_parser = FALSE;
    uint8  is_bfd_parser = FALSE;
    uint8  is_mpls_tp_ld_parser = FALSE;
    uint8  is_mpls_tp_csf_parser = FALSE;

    /*DEFAULT*/
    is_layer2_parser = (OAM_ETHER == parser_info->rx_oam_type)||(OAM_PBT == parser_info->rx_oam_type)
                       ||(OAM_PBB_BV == parser_info->rx_oam_type);
    by_pass_all = parser_info->by_pass_all;

    /* temp fix for cosim by mengzw, ask HeZC ??? */
    if(by_pass_all)
    {
        return DRV_E_NONE;
    }

    sal_memset(parser_result, 0, sizeof(oam_parser_result_t));

    if(is_layer2_parser && (!by_pass_all))
    {
        /*LAYER2_PARSING*/
        DRV_IF_ERROR_RETURN(_cm_oam_packet_parser_parse_layer2(in_pkt, parser_info));
    }

    sal_memset(&oam_parser_ether_ctl, 0, sizeof(oam_parser_ether_ctl_t));
    cmd = DRV_IOR(OamParserEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd,  &oam_parser_ether_ctl));

    /*OAM PARSING*/
    if(is_layer2_parser)
    {
        is_eth_oam_parser = TRUE;
        parser_result->packet_offset = parser_result->layer3_offset;
        parser_result->is_l2_eth_oam = TRUE;
    }
    else if(OAM_ACH == parser_info->rx_oam_type )
    {
        ach_header = pkt + parser_info->packet_offset;
        ach_chan_type = MAKE_UINT16(ach_header[2], ach_header[3]);
        if(ach_chan_type == oam_parser_ether_ctl.ach_y1731_chan_type)
        {
            parser_result->packet_offset = parser_info->packet_offset + 4;
            is_eth_oam_parser = TRUE;

        }
        else if(ach_chan_type == oam_parser_ether_ctl.ach_bfd_chan_type_cc
                || ach_chan_type == 0x7) /*0x7 == Basic TP BFD*/
        {
            is_bfd_parser = TRUE;
            parser_result->oam_type = BFD_OAM;
            parser_result->packet_offset = parser_info->packet_offset + 4;
        }
        else if(ach_chan_type == oam_parser_ether_ctl.ach_bfd_chan_type_cv)
        {
            is_bfd_parser = TRUE;
            parser_result->oam_type = MPLSTP_CV; /*MPLS TP BFD CV*/
            parser_result->packet_offset = parser_info->packet_offset + 4;
        }
        else if(ach_chan_type == oam_parser_ether_ctl.ach_chan_type_dm)
        {
            is_mpls_tp_ld_parser = TRUE;
            parser_result->oam_type = MPLSTP_DM;/*MPLS TP DM*/
            parser_result->packet_offset = parser_info->packet_offset + 4;
        }
        else if(ach_chan_type == oam_parser_ether_ctl.ach_chan_type_dlm)
        {
            is_mpls_tp_ld_parser = TRUE;
            parser_result->oam_type = MPLSTP_DLM;/*MPLS TP DLM*/
            parser_result->packet_offset = parser_info->packet_offset + 4;
        }
        else if(ach_chan_type == oam_parser_ether_ctl.ach_chan_type_dlmdm)
        {
            is_mpls_tp_ld_parser = TRUE;
            parser_result->oam_type = MPLSTP_DLMDM;/*MPLS TP DLM+DM*/
            parser_result->packet_offset = parser_info->packet_offset + 4;
        }
        else if(ach_chan_type == oam_parser_ether_ctl.ach_chan_type_csf)
        {
            is_mpls_tp_csf_parser = TRUE;
            parser_result->oam_type = MPLSTP_CSF; /*MPLS TP CSF*/
            parser_result->packet_offset = parser_info->packet_offset + 4;
        }
        else if(ach_chan_type == 0x0001)
        {
            is_mpls_tp_csf_parser = FALSE;
            parser_result->oam_type = MCC;
            parser_result->packet_offset = parser_info->packet_offset;
        }
        else if(ach_chan_type == 0x0002)
        {
            is_mpls_tp_csf_parser = FALSE;
            parser_result->oam_type = SCC;
            parser_result->packet_offset = parser_info->packet_offset;
        }
        else
        {
            parser_result->oam_type = MPLS_OTHER;
            parser_result->packet_offset = parser_info->packet_offset;
        }
    }
    else if(OAM_MPLS == parser_info->rx_oam_type)
    {
        parser_result->oam_type = MPLS_OAM;
    }
    else if((OAM_IP_BFD == parser_info->rx_oam_type)||(OAM_MPLS_BFD == parser_info->rx_oam_type)
            || (OAM_TRILL_BFD == parser_info->rx_oam_type))
    {
        is_bfd_parser = TRUE;
        parser_result->oam_type = BFD_OAM;
        parser_result->packet_offset = parser_info->packet_offset;
    }
    else
    {
        parser_result->oam_type = MPLS_OTHER;
        parser_result->packet_offset = 0;
    }

    /* oam parsing switch */
    if(!parser_result->oam_pdu_invalid)
    {
        if(is_eth_oam_parser && (!by_pass_all))
        {
            DRV_IF_ERROR_RETURN(_cm_oam_packet_parser_parse_eth(in_pkt,parser_info));
        }
        else if(is_bfd_parser && (!by_pass_all))
        {
            DRV_IF_ERROR_RETURN(_cm_oam_packet_parser_parse_bfd(in_pkt, parser_info));
        }
        else if(is_mpls_tp_ld_parser && (!by_pass_all))
        {
            DRV_IF_ERROR_RETURN(_cm_oam_packet_parser_parse_mpls_tp_dlm(in_pkt,parser_info));
        }
        else if(is_mpls_tp_csf_parser && (!by_pass_all))
        {
            DRV_IF_ERROR_RETURN(_cm_oam_packet_parser_parse_mpls_tp_csf(in_pkt,parser_info));
        }
    }

    return DRV_E_NONE;

}

