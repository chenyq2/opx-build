
/****************************************************************************
 * cm_oam_auto_gen_pkt.c : auto gen pkt engine
 *
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       JiangJf.
 * Date:         2011-06-14.
 * Reason:       First Create.
 * Revision:     V1.0.
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#define IS_CARRY(a,b,c) ((a > (c-b))?1:0)

/****************************************************************************
 * Name:      _cm_prbs31
 * Purpose:   calculate prbs sequence.
 * Parameters:
 * Input:     len  --  sequence len
 * Return:    new prbs.
 * Note:      none.
****************************************************************************/
int32
_cm_prbs31(uint32 len, uint8 *seq)
{
#define PRBSLEN 31

    uint8 seed[PRBSLEN] = {0} ;
    uint32 i,j;
    uint32 len_byte = 0;
    uint8 bit = 0;

    len_byte = len/8 + (len%8)?1:0;

    for (i=0;i<PRBSLEN;i++)
    {
        seed[i] = 1;
    }

    for (i=0; i<(len+PRBSLEN); i++)
    {
        if(i>=PRBSLEN)
        {
            seq[(i-PRBSLEN)/8] |= (seed[PRBSLEN-1] << ((i-PRBSLEN)%8));

        }
        #if 0
        sal_printf("%d ",seed[PRBSLEN-1]);
        if(((i+1)%31) == 0)
        {
            sal_printf("\n");
        }
        #endif
        bit = seed[PRBSLEN-1] ^ seed[PRBSLEN-4];
        for(j=1;j<PRBSLEN;j++)
        {
            seed[PRBSLEN-j] = seed[PRBSLEN-j-1];
        }
        seed[0] = bit;

    }
    #if 0
    sal_printf("\n");

    sal_printf("seq:\n");
    for (i=0; i<len; i++)
    {
        bit = IS_BIT_SET(seq[i/8], (7- i%8));
        sal_printf("%d ",bit);
        if(((i+1)%31) == 0)
        {
            sal_printf("\n");
        }
    }
    sal_printf("\n");
    #endif
    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_oam_auto_gen_pkt_queue_send
 * Purpose:    auto generate packet
 * Parameters:
 * Input:      chip_id -- Chip id.
 *             inc_tick -- if gen pkt
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/

static int32
_cm_oam_auto_gen_pkt_queue_send(uint32 chip_id, uint8* pkt, uint32 pkt_length)
{
    out_pkt_t oam_out_pkt;
    uint8* exception = NULL;
    int32 ret = 0;

    sal_memset(&oam_out_pkt, 0, sizeof(out_pkt_t));
    exception = sal_malloc(GREAT_BELT_EXCEPTION_LEN);
    if (NULL == exception)
    {
        sal_free(pkt);
        pkt = NULL;
        return DRV_E_NO_MEMORY;
    }
    sal_memset(exception, 0, GREAT_BELT_EXCEPTION_LEN);

    oam_out_pkt.pkt = pkt;
    oam_out_pkt.exception = exception;
    oam_out_pkt.pkt_id = 0;
    oam_out_pkt.chip_id = chip_id;
    oam_out_pkt.chan_id = OAM_CHANID;
    oam_out_pkt.dest_queue = SIM_FWD_Q;
    oam_out_pkt.packet_length = pkt_length - GREAT_BELT_HEADER_LEN;
    oam_out_pkt.module_bus.pkt_len = pkt_length - GREAT_BELT_HEADER_LEN;
    sal_memcpy(oam_out_pkt.module_bus.packet_header, pkt, GREAT_BELT_HEADER_LEN);
    sal_memmove(pkt, pkt + GREAT_BELT_HEADER_LEN , oam_out_pkt.module_bus.pkt_len);

    /* capture oam_tx pkt to oam_out_pkt.txt */
    ret = sim_oam_output_packet(oam_out_pkt.pkt, oam_out_pkt.packet_length,
                                oam_out_pkt.chip_id, oam_out_pkt.chan_id);
#if (SDK_WORK_PLATFORM == 1)
    DRV_IF_ERROR_RETURN(swap32((uint32 *)oam_out_pkt.module_bus.packet_header, (GREAT_BELT_HEADER_LEN) / 4, NETWORK_TO_HOST));

    if (cosim_db.store_bheader)
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_bheader(((void *)oam_out_pkt.module_bus.packet_header), SIM_MODULE_OAM));
    }

    DRV_IF_ERROR_RETURN(swap32((uint32 *)oam_out_pkt.module_bus.packet_header, (GREAT_BELT_HEADER_LEN) / 4, HOST_TO_NETWORK));

    if (cosim_db.store_outpkt)
    {
        ret = cosim_db.store_outpkt(oam_out_pkt.chip_id, oam_out_pkt.chan_id,
                                oam_out_pkt.packet_length, oam_out_pkt.pkt, SIM_MODULE_OAM, 0, 0);
    }
#endif
    /* Send to fwd */
    ret = ctckal_queue_send(sim_queue[SIM_FWD_Q], (void *)&oam_out_pkt, sizeof(out_pkt_t));
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("oam engine send pkt to fwd error! ret = %d\n", ret);

        goto error;
    }
    return DRV_E_NONE;

error:
    if (oam_out_pkt.pkt != NULL)
    {
        sal_free(oam_out_pkt.pkt);
        oam_out_pkt.pkt = NULL;
    }
    if (oam_out_pkt.exception != NULL)
    {
        sal_free(oam_out_pkt.exception);
        oam_out_pkt.exception = NULL;
    }

    return ret;
}

/****************************************************************************
 * Name:       _cm_oam_auto_gen_pkt_timer_update
 * Purpose:    auto generate packet update
 * Parameters:
 * Input:      chip_id -- Chip id.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
_cm_oam_auto_gen_pkt_timer_update(uint32 chip_id, uint8 udp_ptr)
{
    uint8* pkt = NULL;
    auto_gen_pkt_ctl_t auto_gen_pkt_ctl;
    auto_gen_pkt_pkt_cfg_t ds_pkt_cfg;
    auto_gen_pkt_tx_pkt_stats_t ds_tx_pkt_stats;
    auto_gen_pkt_pkt_hdr_t tx_pkt_entry;
    uint32 cmd = 0;

    uint16 ds_pkt_cfg_ptr = 0;
    uint16 ds_tx_pkt_stats_ptr  = 0;
    uint16 tx_pkt_entry_ptr  = 0;

    uint16 rate_cnt         = 0;
    uint16 rate_frac_cnt    = 0;
    uint16 tx_pkt_cnt       = 0;

    uint32 seq_num = 0;
    uint32 tx_pkts = 0;

    uint32 tx_octets0 = 0;
    uint8  tx_octets1 = 0;

    uint8  auto_gen_pkt = FALSE;
    uint8  stop_after_tx_pkt_cnt = FALSE;

    uint16 pkt_size = 0;
    uint32 pkt_crc = 0;

    uint8  carry = 0;
    uint8  tx_pkt_bytes_cfg[96] = {0,};
    uint8 tx_pkt_bytes[96] = {0,};/**2048+32*/
    uint32 i,j = 0;
    uint8 j8 = 0;
    uint32 pkt_entry_num =0;
    uint32 pkt_pay_load_begin = 0;
    uint32 pkt_pay_load_end = 0;
    uint8 is_tx_pkt_bytes_cfg_res =FALSE;
    uint8 *prbs = NULL;

    sal_memset(&auto_gen_pkt_ctl, 0, sizeof(auto_gen_pkt_ctl));
    cmd = DRV_IOR(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));

    auto_gen_pkt = FALSE;
    stop_after_tx_pkt_cnt = TRUE;
    tx_pkt_entry_ptr        = ((udp_ptr << 4) - (udp_ptr << 2));
    ds_pkt_cfg_ptr          = udp_ptr;
    ds_tx_pkt_stats_ptr     = udp_ptr;


    sal_memset(&ds_pkt_cfg, 0, sizeof(ds_pkt_cfg));
    cmd = DRV_IOR(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);/*1 DsOamLmStats entry*/
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_pkt_cfg_ptr, cmd, &ds_pkt_cfg));

    sal_memset(&ds_tx_pkt_stats, 0, sizeof(ds_tx_pkt_stats));
    cmd = DRV_IOR(AutoGenPktTxPktStats_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_tx_pkt_stats_ptr, cmd, &ds_tx_pkt_stats));

    /* system modified by liwh for bug 25444, 2013-11-13 
       if rate_cnt is not 0, can't send tst packet */
    //rate_cnt        = ds_pkt_cfg.rate_cnt;
    rate_frac_cnt   = ds_pkt_cfg.rate_frac_cnt;
    tx_pkt_cnt      = ds_pkt_cfg.tx_pkt_cnt;

    seq_num = ds_tx_pkt_stats.seq_num;
    tx_pkts = ds_tx_pkt_stats.tx_pkts;
    tx_octets0 = ds_tx_pkt_stats.tx_octets0;
    tx_octets1 = ds_tx_pkt_stats.tx_octets1;
    if(rate_cnt <= 1)
    {/***rate time out,reload rate and transmit packet*/
        carry = IS_CARRY(ds_pkt_cfg.rate_frac_cnt_cfg, rate_frac_cnt, 0xffff);
        rate_frac_cnt += ds_pkt_cfg.rate_frac_cnt_cfg;
        rate_cnt     = ds_pkt_cfg.rate_cnt_cfg + carry;
        if(0 == ds_pkt_cfg.tx_mode)
        {
            tx_pkt_cnt--;
            if(0 == tx_pkt_cnt)
            {
                CLEAR_BIT(auto_gen_pkt_ctl.auto_gen_en, udp_ptr);/*clear the pkt generation*/

                cmd = DRV_IOW(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));

                CMODEL_DEBUG_OUT_INFO("\n++++ AutoGenEn[%d]Intr! File:%s Line:%d Function:%s\n",
                        udp_ptr,__FILE__, __LINE__, __FUNCTION__);
            }
        }

        ds_pkt_cfg.rate_cnt         = rate_cnt;
        ds_pkt_cfg.rate_frac_cnt    = rate_frac_cnt;
        ds_pkt_cfg.tx_pkt_cnt       = tx_pkt_cnt;
        cmd = DRV_IOW(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_pkt_cfg_ptr, cmd, &ds_pkt_cfg));

        /*assemble the tx packet*/
        if(ds_pkt_cfg.pkt_hdr_len%64)
        {
            pkt_entry_num = (ds_pkt_cfg.pkt_hdr_len*8)/64 + 1;
        }
        else
        {
            pkt_entry_num = (ds_pkt_cfg.pkt_hdr_len*8)/64;
        }
        for(i = 0; i < pkt_entry_num; i++)
        {
            sal_memset(&tx_pkt_entry, 0, sizeof(tx_pkt_entry));
            cmd = DRV_IOR(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, tx_pkt_entry_ptr, cmd, &tx_pkt_entry));
            tx_pkt_entry_ptr++;

            /* system modified by liwh for bug 25444, 2013-11-13 
               if not change, uml output packet isn't 01 80 c2 00, but is 00 c2 80 01 */
            if (i >= 4)
            {
                tx_pkt_entry.pkt_hdr_userdata0 = sal_htonl(tx_pkt_entry.pkt_hdr_userdata0);
                tx_pkt_entry.pkt_hdr_userdata1 = sal_htonl(tx_pkt_entry.pkt_hdr_userdata1);
            }
            /* liwh end */

            for(j = 0; j < 8; j++)
            {
                if(j < 4)
                {
                    tx_pkt_bytes_cfg[i*8 + j] = (tx_pkt_entry.pkt_hdr_userdata0 >> (24 - 8*j))&0xff;
                }
                else
                {
                    tx_pkt_bytes_cfg[i*8 + j] = (tx_pkt_entry.pkt_hdr_userdata1 >> (24 - 8*(j - 4)))&0xff;
                }
            }
        }

        /*first segment of tx packet, until seqNumOffset if txSeqNumEn*/
        if(ds_pkt_cfg.tx_seq_num_en)
        {
            for(i = 0; i<ds_pkt_cfg.seq_num_offset; i++)
            {

                tx_pkt_bytes[i] = tx_pkt_bytes_cfg[i];
            }
            for(i = 0; i < 4; i++)
            {
                tx_pkt_bytes[ds_pkt_cfg.seq_num_offset + i] = (ds_tx_pkt_stats.seq_num >> (24 - 8*i))&0xff;
            }
            pkt_pay_load_begin = ds_pkt_cfg.seq_num_offset + 4;
        }
        else
        {

            for(i = 0; i < ds_pkt_cfg.pkt_hdr_len; i++)
            {

                tx_pkt_bytes[i] = tx_pkt_bytes_cfg[i];
            }
            pkt_pay_load_begin = ds_pkt_cfg.pkt_hdr_len;
        }

        is_tx_pkt_bytes_cfg_res = (pkt_pay_load_begin < ds_pkt_cfg.pkt_hdr_len)? 1 : 0;
        pkt_pay_load_end = ds_pkt_cfg.tx_pkt_size + 32 - 4; /***32 -4 ???***/


        /**** 2nd segment of tx packet********/

        if (is_tx_pkt_bytes_cfg_res)
        {
            for (i = pkt_pay_load_begin; i < ds_pkt_cfg.pkt_hdr_len; i++)
            {
                tx_pkt_bytes[i] = tx_pkt_bytes_cfg[i];
            }
            pkt_pay_load_begin = ds_pkt_cfg.pkt_hdr_len;
        }
        pkt = sal_malloc(MTU);
        if (NULL == pkt)
        {
            CMODEL_DEBUG_OUT_INFO("\n++++ DRV_E_NO_MEMORY for auto gen pkt! File:%s Line:%d Function:%s\n",
                __FILE__, __LINE__, __FUNCTION__);
            return DRV_E_NO_MEMORY;
        }
        sal_memset(pkt, 0, MTU);
        sal_memcpy(pkt, tx_pkt_bytes, ds_pkt_cfg.pkt_hdr_len);

        uint32 len = 0;
        /******3th segment of tx packet *****/
        if(ds_pkt_cfg.pkt_hdr_len < (ds_pkt_cfg.tx_pkt_size + 32))
        {

            switch(ds_pkt_cfg.pattern_type & 0x7)
            {
                case 1:

                    len = pkt_pay_load_end - pkt_pay_load_begin;
                    prbs = sal_malloc(len);
                    sal_memset(prbs, 0, len);

                    _cm_prbs31(len*8, prbs);

                    for (i = pkt_pay_load_begin; i < pkt_pay_load_end; i++)
                    {
                        pkt[i] = prbs[i-pkt_pay_load_begin];
                    }

                    if (prbs != NULL)
                    {
                        sal_free(prbs);
                        prbs = NULL;
                    }

                    break;

                 case 2:  /**increment BYTE**/
                    for (i = pkt_pay_load_begin, j8 = 0; i < pkt_pay_load_end; i++)
                    {
                        pkt[i] = j8;
                        j8++;
                    }
                    break;
                 case 3:   /**decrement BYTE**/
                    for (i = pkt_pay_load_begin, j8 = 0xFF; i < pkt_pay_load_end; i++)
                    {
                        pkt[i] = j8;
                        j8--;
                    }
                    break;
                 case 4:  /**increment word**/
                    for (i = pkt_pay_load_begin, j = 0; i < pkt_pay_load_end; i+=4)
                    {
                        pkt[i] = (j >>24)& 0xff ;
                        pkt[i+1] = (j >>16)& 0xff ;
                        pkt[i+2] = (j >>8)& 0xff ;
                        pkt[i+3] = j & 0xff ;
                        j += 4;
                    }
                    break;
                  case 5:   /**decrement word**/
                    for (i = pkt_pay_load_begin, j = 0xFFFFFFFF; i < pkt_pay_load_end; i+=4)
                    {
                        pkt[i + 0] = (j >>24)& 0xff ;
                        pkt[i + 1] = (j >>16)& 0xff ;
                        pkt[i + 2] = (j >>8)& 0xff ;
                        pkt[i + 3] = j & 0xff ;
                        j -= 4;
                    }
                    break;
                  default:
                    for (i = pkt_pay_load_begin; i < pkt_pay_load_end; i += 4)
                    {
                        pkt[i + 0] = (ds_pkt_cfg.repeat_pattern >> 24)& 0xff ;
                        pkt[i + 1] = (ds_pkt_cfg.repeat_pattern >> 16)& 0xff ;
                        pkt[i + 2] = (ds_pkt_cfg.repeat_pattern >> 8)& 0xff ;
                        pkt[i + 3] = ds_pkt_cfg.repeat_pattern & 0xff ;
                    }
                    break;
            }


            /******CRC*******
            tx_pkt_bytes[pkt_pay_load_end] = CRC[31:24];
            tx_pkt_bytes[pkt_pay_load_end + 1] = CRC[23:16];
            tx_pkt_bytes[pkt_pay_load_end + 2] = CRC[15:8];
            tx_pkt_bytes[pkt_pay_load_end + 3] = CRC[7:0];

            *********/
            /*rewrite End TLVs fields*/
            if(ds_pkt_cfg.is_have_end_tlv)
            {
                pkt[pkt_pay_load_end - 1] = 0;
            }
            pkt_size = ds_pkt_cfg.tx_pkt_size + 32;

            ctcutil_crc32(0xFFFFFFFF, pkt + GREAT_BELT_HEADER_LEN, (pkt_size - 4), &pkt_crc);
            DRV_IF_ERROR_RETURN(swap32(&pkt_crc, 1, HOST_TO_NETWORK));

            pkt[pkt_pay_load_end] = (pkt_crc >> 24) & 0xFF;
            pkt[pkt_pay_load_end + 1]  = (pkt_crc >> 16) & 0xFF;
            pkt[pkt_pay_load_end + 2]  = (pkt_crc >> 8) & 0xFF;
            pkt[pkt_pay_load_end + 3]  = pkt_crc  & 0xFF;

            _cm_oam_auto_gen_pkt_queue_send(chip_id, pkt, pkt_size);

            /*******assert normal interrupt while tx stats reach threshold *****/
            if((ds_tx_pkt_stats.tx_pkts >> 26) >= auto_gen_pkt_ctl.pkts_stats_threshold)
            {/*report AutoGenPktTxPktsStatsIntr*/
                CMODEL_DEBUG_OUT_INFO("\n++++ AutoGenPktTxPktsStatsIntr! File:%s Line:%d Function:%s\n",
                    __FILE__, __LINE__, __FUNCTION__);
            }
            if((ds_tx_pkt_stats.tx_octets1) >= auto_gen_pkt_ctl.octets_stats_threshold)
            {/*report AutoGenPktTxOctetStatsIntr*/
                CMODEL_DEBUG_OUT_INFO("\n++++ AutoGenPktTxOctetStatsIntr! File:%s Line:%d Function:%s\n",
                    __FILE__, __LINE__, __FUNCTION__);
            }



            /******tx stats update***/

            if(ds_pkt_cfg.tx_seq_num_en){

                seq_num++;
            }
            tx_pkts++;
            tx_octets1 += IS_CARRY(ds_pkt_cfg.tx_pkt_size, tx_octets0,0xffffffff);
            tx_octets0 += ds_pkt_cfg.tx_pkt_size;
            ds_tx_pkt_stats.seq_num = seq_num;
            ds_tx_pkt_stats.tx_pkts= tx_pkts;
            ds_tx_pkt_stats.tx_octets0 = tx_octets0;
            ds_tx_pkt_stats.tx_octets1 = tx_octets1;
            cmd = DRV_IOW(AutoGenPktTxPktStats_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_tx_pkt_stats_ptr, cmd, &ds_tx_pkt_stats));
        }
        else
        {/**pkt_hdr_len >= tx_pkt_size,config error***/
            /***do nothing **/
        }/**3 th segment of tx packet*/
    }
    else
    { /**only derease rate integar number,none of packet genenration*/
        rate_cnt--;
        ds_pkt_cfg.rate_cnt = rate_cnt;
        cmd = DRV_IOW(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_pkt_cfg_ptr, cmd, &ds_pkt_cfg));
    }

#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_table)
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, AutoGenPktPktCfg_t, ds_pkt_cfg_ptr,
                                    (uint32 *)&ds_pkt_cfg, TRUE));
    }
#endif
    return DRV_E_NONE;
}



/****************************************************************************
 * Name:       cm_oam_auto_gen_pkt_tick_update
 * Purpose:    gen tick for auto gen pkt
 * Parameters:
 * Input:      chip_id -- Chip id.
 *             update_times -- update times
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_oam_auto_gen_pkt_tick_update(uint32 chip_id, uint32 update_times)
{
    uint16 tick_gen_cnt = 0;
    uint8 inc_tick = FALSE;
    uint32 update_time = 0;
    uint8 upd_ptr = 0;
    auto_gen_pkt_ctl_t auto_gen_pkt_ctl;
    uint32 cmd = 0;
    sal_memset(&auto_gen_pkt_ctl, 0, sizeof(auto_gen_pkt_ctl));
    cmd = DRV_IOR(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));
    tick_gen_cnt = auto_gen_pkt_ctl.tick_gen_interval;

    while(auto_gen_pkt_ctl.tick_gen_en && (update_time < update_times))
    {
        sal_memset(&auto_gen_pkt_ctl, 0, sizeof(auto_gen_pkt_ctl));
        cmd = DRV_IOR(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));
        /*TICKGEN_PROC*/
        if(tick_gen_cnt == 0)
        {
            tick_gen_cnt = auto_gen_pkt_ctl.tick_gen_interval;
            inc_tick = TRUE;
            update_time++;/*Software simulation, update_time for one tick*/
        }
        else
        {
            inc_tick = FALSE;
            tick_gen_cnt--;
        }

        if(inc_tick)
        {
            if(IS_BIT_SET(auto_gen_pkt_ctl.auto_gen_en, upd_ptr))
            {
                _cm_oam_auto_gen_pkt_timer_update(chip_id, upd_ptr);
            }
            upd_ptr++;

            if(upd_ptr == auto_gen_pkt_ctl.upd_valid_ptr+1)
            {
                upd_ptr = 0;
            }
        }

    }

    return DRV_E_NONE;
}


