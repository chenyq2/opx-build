/****************************************************************************
 * ctcutil_list.h:      Double linked list
 *
 * Copyright (C) 2010 Centec Networks, Inc.  All rights reserved.
 *
 * Modify History:
 * Revision	:	V1.0
 * Author	: 	Yiquan Chen
 * Date		:	2010-07-15
 * Reason	:	First Create.
 ****************************************************************************/
#ifndef _CTCUTIL_LIST_H_
#define _CTCUTIL_LIST_H_

typedef struct list_head list_head_t;

#ifndef _SAL_LINUX_KM
#define LIST_POISON1  ((void *) 0x0)
#define LIST_POISON2  ((void *) 0x0)


struct list_head
{
    struct list_head *next, *prev;
};

#define LIST_HEAD_INIT(name) \
        { &(name), &(name) }

#define LIST_HEAD(name) \
        struct list_head name = LIST_HEAD_INIT(name)

#define INIT_LIST_HEAD(ptr) \
        do \
        { \
            (ptr)->next = (ptr); (ptr)->prev = (ptr); \
        } while (0)


/**
 * list_entry - get the struct for this entry
 * @ptr:    the &struct list_head pointer.
 * @type:   the type of the struct this is embedded in.
 * @member: the name of the list_struct within the struct.
 */
#define list_entry(ptr, type, member) \
        ((type *)((char *)(ptr) - (unsigned long)(&((type *)0)->member)))

/**
 * list_for_each    -   iterate over a list
 * @pos:    the &struct list_head to use as a loop counter.
 * @head:   the head for your list.
 */
#define list_for_each(pos, head) \
        for (pos = (head)->next; pos != (head); \
            pos = pos->next)

/**
 * list_for_each_prev   -   iterate over a list backwards
 * @pos:    the &struct list_head to use as a loop counter.
 * @head:   the head for your list.
 */
#define list_for_each_prev(pos, head) \
        for (pos = (head)->prev; pos != (head); \
            pos = pos->prev)

/**
 * list_for_each_entry  -   iterate over list of given type
 * @pos:    the type * to use as a loop counter.
 * @head:   the head for your list.
 * @member: the name of the list_struct within the struct.
 */
#define list_for_each_entry(pos, head, member) \
        for (pos = list_entry((head)->next, typeof(*pos), member);  \
            &pos->member != (head); \
            pos = list_entry(pos->member.next, typeof(*pos), member))

/**
 * list_for_each_entry_reverse - iterate backwards over list of given type.
 * @pos:    the type * to use as a loop counter.
 * @head:   the head for your list.
 * @member: the name of the list_struct within the struct.
 */
#define list_for_each_entry_reverse(pos, head, member) \
        for (pos = list_entry((head)->prev, typeof(*pos), member); \
            &pos->member != (head); \
            pos = list_entry(pos->member.prev, typeof(*pos), member))


/*
 * exported functions
 */
extern void list_add(struct list_head *new, struct list_head *head);
extern void list_add_tail(struct list_head *new, struct list_head *head);
extern void list_del(struct list_head *entry);
extern void list_del_all(struct list_head *head);
#if 0
extern void list_del_all_and_free(struct list_head *head);
#endif
extern void list_del_init(struct list_head *entry);
extern int32 list_empty(const struct list_head *head);
extern void list_splice(struct list_head *list, struct list_head *head);
extern void list_splice_init(struct list_head *list, struct list_head *head);
extern void list_move(struct list_head *list, struct list_head *head);
extern void list_move_tail(struct list_head *list, struct list_head *head);
#endif

/*START: modified by zzhu for SDK memory manage 2007-4-12*/
//#if 0
static inline void
list_del_all_and_free(struct list_head *head)
{
    struct list_head *pos;
    struct list_head *entry;

    pos = head->next;
    while ((pos != head) && (pos != NULL))
    {
        entry = pos;
        pos = pos->next;
        entry->next = 0;
        entry->prev = 0;
        SAL_FREE(entry);
    }

    INIT_LIST_HEAD(head);
}
//#else
#if 0
#define list_del_all_and_free(head)\
do{\
    struct list_head *pos;\
    struct list_head *entry;\
    pos = (head)->next;\
    while (pos != head)\
    {\
        entry = pos;\
        pos = pos->next;\
        entry->next = 0;\
        entry->prev = 0;\
        mem_free(entry);\
    }\
    INIT_LIST_HEAD(head);\
}while(0)
#endif
/*END*/

#endif  /* _CTCUTIL_LIST_H_ */
