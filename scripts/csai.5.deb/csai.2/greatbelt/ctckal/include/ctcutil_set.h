/****************************************************************************
 * ctcutil_set.h    : 	set utility
 *
 * Copyright (C) 2010 Centec Networks, Inc.  All rights reserved.
 *
 * Modify History   :
 * Revision	    :	V1.0
 * Author	    : 	Yiquan Chen
 * Date		    :	2010-07-19
 * Reason	    :	First Create.
 ****************************************************************************/
#ifndef _CTCUTIL_H_
#define _CTCUTIL_H_


/****************************************************************************
 * Header Files
 ****************************************************************************/

/****************************************************************************
 * Defines and Macros
 ****************************************************************************/

/****************************************************************************
 * Global and Declarations
 ****************************************************************************/
struct ctcutil_set
{
    uint32 item_cnt;
    uint32 max_items;
    uint32 item_size;       /* needed by find_in_sets */
    void **items;
};
typedef struct ctcutil_set ctcutil_set_t;


/****************************************************************************
 * Functions
 ****************************************************************************/
/****************************************************************************
 * Name         : ctcutil_set_create
 * Purpose      : construct a new set
 * Input        : @max_items
 *              : @items_size
 * Output       :
 * Return       : a pionter to an empty sets
 * Note         : Pre-condition: max_items > 0
 ****************************************************************************/
ctcutil_set_t *ctcutil_set_create(uint32 max_items, uint32 item_size);


/****************************************************************************
 * Name		: ctcutil_set_add_item
 * Purpose	: add an item to a set
 * Input	: @s
 *		: @item
 * Output	:
 * Return	:
 * Note		: Pre-condition: (s is a sets created by a call to
 *              :                 ctcutil_set_create) &&
 *              :                (existing item count < max_items) &&
 *              :                (item != NULL)
 *              : Post-condition: item has been added to s
 ****************************************************************************/
int32 ctcutil_set_add_item(ctcutil_set_t* s, void *item);


/****************************************************************************
 * Name       : ctcutil_set_del_item
 * Purpose    : delete an item from a set
 * Input      : @s
 *            : @item
 * Output     :
 * Return     : void
 * Note       : Pre-condition: (s is a sets created by a call to
 *            :                 ctcutil_set_create) &&
 *            :                (existing item count >= 1) &&
 *            :                (item != NULL)
 *            : Post-condition: item has been deleted from s
 ****************************************************************************/
int32 ctcutil_set_del_item(ctcutil_set_t* s, void *item);


/****************************************************************************
 * Name       : ctcutil_set_find_item
 * Purpose    : find an item in a set
 * Input      : @s
 *            : @key
 * Output     :
 * Return     :
 * Note       : Pre-condition: (s is a sets created by a call to
 *            :                 ctcutil_set_create) &&
 *            :                (key != NULL)
 *            : Post-condition: returns an item identified by key if one
 *            :                 exists, otherwise returns NULL
 ****************************************************************************/
void *ctcutil_set_find_item(ctcutil_set_t* s, void *key);


/****************************************************************************
 * Name         : ctcutil_set_destroy
 * Purpose      : delete a set
 * Input        : @s
 * Output       :
 * Return       : void
 *              :
 * Note         :
 ****************************************************************************/
int32 ctcutil_set_destroy(ctcutil_set_t* s);


/****************************************************************************
 * Name         : ctcutil_set_is_empty
 * Purpose      : check if the set is empty
 * Input        : @s
 * Output       :
 * Return       :
 *              :
 * Note         :
 ****************************************************************************/
bool ctcutil_set_is_empty(ctcutil_set_t* s);


/****************************************************************************
 * Name         : ctcutil_set_get_cnt
 * Purpose      : get item coutn
 * Input        : @s
 * Output       :
 * Return       :
 *              :
 * Note         :
 ****************************************************************************/
int32 ctcutil_set_get_item_cnt(ctcutil_set_t* s, uint32 *p_cnt);


/****************************************************************************
 * Name         : ctcutil_set_get_first
 * Purpose      : get the first item
 * Input        : @s
 * Output       :
 * Return       :
 *              :
 * Note         :
 ****************************************************************************/
void *ctcutil_set_get_first(ctcutil_set_t* s);


/****************************************************************************
 * Name         : ctcutil_set_next
 * Purpose      : get next item
 * Input        : @s
 * Output       :
 * Return       :
 *              :
 * Note         :
 ****************************************************************************/
void *ctcutil_set_get_next(ctcutil_set_t* s);


#if 0  /* todo */
int32 sets_union(sets* dest, sets* src1, sets* src2);
int32 sets_intersection(sets* dest, sets* src1, sets* src2);
int32 sets_difference(sets* dest, sets* src1, sets* src2);
bool sets_is_subset(sets* dest, sets* src);
bool sets_is_equal(sets* dest, sets* src);
#endif


#endif  /* _CTCUTIL_SET_H_ */
