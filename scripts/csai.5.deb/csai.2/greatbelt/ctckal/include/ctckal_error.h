/****************************************************************************
 * ctckal_error.h :         kal error codes
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#ifndef _CTCKAL_ERROR_H_
#define _CTCKAL_ERROR_H_

/* todo: perror kind function */

#define CTCKAL_SUCCESS                   0
#define CTCKAL_ERR_PARAM                -1  /* parameter error */
#define CTCKAL_ERR_RESOURCE             -2  /* no resource */
#define CTCKAL_ERR_EMPTY                -3
#define CTCKAL_ERR_FULL                 -4
#define CTCKAL_ERR_SYSTEM               -5  /* systerm error */
#define CTCKAL_ERR_INTERNAL             -6  /* internal error */



#endif  /* _CTCKAL_ERROR_H_ */

