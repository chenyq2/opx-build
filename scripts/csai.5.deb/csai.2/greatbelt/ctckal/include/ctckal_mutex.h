/****************************************************************************
 * ctckal_mutex.h :         mutex module header
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#ifndef _CTCKAL_MUTEX_H_
#define _CTCKAL_MUTEX_H_

typedef uint32 ctckal_mutex_t;

int32 ctckal_mutex_init(void);
void ctckal_mutex_exit(void);
int32 ctckal_mutex_create(ctckal_mutex_t *mutex);
void ctckal_mutex_destroy(ctckal_mutex_t mutex);
int32 ctckal_mutex_take(ctckal_mutex_t mutex);
int32 ctckal_mutex_give(ctckal_mutex_t mutex);


#endif  /* _CTCKAL_MUTEX_H_ */
