/****************************************************************************
 * ctckal_malloc.h :        malloc module header
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#ifndef _CTCKAL_MALLOC_H_
#define _CTCKAL_MALLOC_H_

void *ctckal_malloc(uint32 size);
void ctckal_free(void *addr);


#endif  /* _CTCKAL_MALLOC_H_ */
