#ifndef __CTC_SAL_CRC_H__
#define __CTC_SAL_CRC_H__

/**
 * @file ctckal_crc.h
 */

extern uint8
calculate_crc8(uint8 *data, int32 len, uint8 init_crc);

extern uint8
calculate_crc4(uint8 *data, int32 len, uint8 init_crc);

#endif /* !__CTCKAL_CRC_H__ */

