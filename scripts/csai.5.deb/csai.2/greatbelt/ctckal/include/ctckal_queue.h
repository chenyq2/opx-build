/****************************************************************************
 * ctckal_queue.h :         queue module header
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-10-13
 * Reason         :         First Create
 ****************************************************************************/
#ifndef _CTCKAL_QUEUE_H_
#define _CTCKAL_QUEUE_H_

typedef uint32 ctckal_queue_t;

#define QUE_TIMEOUT_INFINITE (1 << 0)
int32 ctckal_queue_init(void);
void ctckal_queue_exit(void);
int32 ctckal_queue_create(ctckal_queue_t *queue);
void ctckal_queue_destroy(ctckal_queue_t queue);
int32 ctckal_queue_send(ctckal_queue_t queue, void *message, uint32 size);
int32 ctckal_queue_send_front(ctckal_queue_t queue, void *message,
                              uint32 size);
int32 ctckal_queue_receive(ctckal_queue_t queue, void *message, uint32 *size, uint32 flag);
int32 ctckal_queue_reset(ctckal_queue_t queue);


#endif  /* _CTCKAL_QUEUE_H_ */
