/*****************************************************************************
 * ctcutil_rand.h    random number generate
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:    V1.0
 * Author:      Jack Yang
 * Date:        2010-08-24
 * Reason:      Initial version
 *****************************************************************************/
#ifndef _CTCUTIL_RAND_H_
#define _CTCUTIL_RAND_H_

int32 ctcutil_rand(uint32 min, uint32 max, uint32 *p_value);

#endif  /* _CTCUTIL_RAND_H_ */
