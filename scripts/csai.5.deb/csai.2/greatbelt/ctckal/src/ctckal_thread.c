/****************************************************************************
 * ctckal_trhead.c:         thread module
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "ctcutil_log.h"
#include <pthread.h>

/*****************************************************************************
 * typedefs
 *****************************************************************************/
enum thread_state_e
{
    INVALID,
    PENDING,
    USING
};
typedef enum thread_state_e thread_state_t;

struct thread_storage_cell_s
{
    thread_state_t state;
    pthread_t thread;
    ctckal_thread_attr_t thread_attr;
    ctckal_thread_func_t thread_func;
    void *user_param;
};
typedef struct thread_storage_cell_s thread_storage_cell_t;

#define THREAD_STORAGE_SIZE 28  /* can be configured */
static thread_storage_cell_t thread_storage[THREAD_STORAGE_SIZE];
static pthread_mutex_t thread_storage_mutex;

typedef void (*start_routine_t)(void*);


/*****************************************************************************
 * static function: get a thread storage cell
 *****************************************************************************/
static int32
get_thread_cell(void)
{
    int32 i;

    for (i = 0; i < THREAD_STORAGE_SIZE; i++)
    {
        if (thread_storage[i].state == INVALID)
        {
            thread_storage[i].state = PENDING;
            return i;
        }
    }

    return -1;
}


/*****************************************************************************
 * static function: common thread function to call user handler
 *****************************************************************************/
static void *
ctckal_thread_worker_func(void *param)
{
    uintptr idx;

    idx = (uintptr)param;

    thread_storage[idx].state = USING;
    thread_storage[idx].thread_func((ctckal_thread_t)idx,
                                    thread_storage[idx].user_param);

    return NULL;
}


/*****************************************************************************
 * Name         : ctckal_thread_create
 * Purpose      : create a thread
 * Input        : thread_attr: for future use
 *                thread_func: user handling routine
 *                user_param: solo parameter of the user handling function
 * Output       : thread_attr: thread handle that can be used
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_thread_create(ctckal_thread_t *thread,
                     ctckal_thread_attr_t thread_attr,
                     ctckal_thread_func_t thread_func, void *user_param)
{
    int32 ret;
    uintptr idx;
    pthread_attr_t attr;

     /* anchor added for close Thread */
    /*   if(!use_ctckal)
    {
        return CTCKAL_SUCCESS;
    }*/

    ret = CTCKAL_SUCCESS;

    pthread_mutex_lock(&thread_storage_mutex);

    /* check parameters */
    if (thread == NULL || thread_func == NULL)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: thread = %p, thread_func = %p",
                    (uintptr)thread, (uintptr)thread_func);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    idx = get_thread_cell();
    if (idx < 0)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_CRITICAL,
                    "thread resource exhausted\n");
        ret = CTCKAL_ERR_RESOURCE;
        goto ERROR;
    }

    thread_storage[idx].thread_attr = thread_attr;
    thread_storage[idx].thread_func = thread_func;
    thread_storage[idx].user_param = user_param;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, (256*1024));

    ret = pthread_create(&thread_storage[idx].thread, &attr,
                         ctckal_thread_worker_func, (void*)idx);
    if (ret != 0)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "pthread_create: %d\n", ret);
        thread_storage[idx].state = INVALID;
        ret = CTCKAL_ERR_SYSTEM;
        goto ERROR;
    }

    *thread = (ctckal_thread_t)idx;

    pthread_mutex_unlock(&thread_storage_mutex);
    return CTCKAL_SUCCESS;

ERROR:
    pthread_mutex_unlock(&thread_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_thread_destroy
 * Purpose      : destroy a thread
 * Input        : thread: the thread handle create by ctckal_thread_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void ctckal_thread_destroy(ctckal_thread_t thread)
{
    int32 idx;

    pthread_mutex_lock(&thread_storage_mutex);

    idx = (int32)thread;
    if (idx < 0 || idx >= THREAD_STORAGE_SIZE
        || thread_storage[idx].state != USING)
        goto ERROR;

    pthread_cancel(thread_storage[idx].thread);
    thread_storage[idx].state = INVALID;

    pthread_mutex_unlock(&thread_storage_mutex);
    return;

ERROR:
    pthread_mutex_unlock(&thread_storage_mutex);
}


/*****************************************************************************
 * Name         : ctckal_thread_init
 * Purpose      : initialize the thread module
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_thread_init(void)
{
    pthread_mutex_init(&thread_storage_mutex, NULL);

    return CTCKAL_SUCCESS;
}


/*****************************************************************************
 * Name         : ctckal_thread_exit
 * Purpose      : de-initialize the thread module
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void
ctckal_thread_exit(void)
{
    int32 i;

    for (i = 0; i < THREAD_STORAGE_SIZE; i++)
    {
        if (thread_storage[i].state != INVALID)
            pthread_cancel(thread_storage[i].thread);
    }

    pthread_mutex_destroy(&thread_storage_mutex);
}
