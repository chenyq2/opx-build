/****************************************************************************
 * ctckal_queue.h :         queue module header
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-10-13
 * Reason         :         First Create
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "ctcutil_log.h"
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>

/*****************************************************************************
 * typedefs
 *****************************************************************************/
enum queue_state
{
    INVALID,
    PENDING,
    USING
};
typedef enum queue_state queue_state_t;

struct message_cell
{
    void *message;
    uint32 size;
    struct message_cell *next;
};
typedef struct message_cell message_cell_t;

struct queue_storage_cell
{
    queue_state_t state;
    message_cell_t *ptr_head;
    message_cell_t *ptr_tail;
};
typedef struct queue_storage_cell queue_storage_cell_t;

#define QUEUE_STORAGE_SIZE 256  /* can be configured */
static queue_storage_cell_t queue_storage[QUEUE_STORAGE_SIZE];
static pthread_mutex_t queue_storage_mutex;


/*****************************************************************************
 * static function
 *****************************************************************************/
static int32
get_queue_storage_cell(void)
{
    int32 i;

    for (i = 0; i < QUEUE_STORAGE_SIZE; i++)
    {
        if (queue_storage[i].state == INVALID)
        {
            queue_storage[i].state = PENDING;
            return i;
        }
    }

    return -1;
}


/*****************************************************************************
 * Name         : ctckal_queue_create
 * Purpose      :
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_queue_create(ctckal_queue_t *queue)
{
    int32 ret;
    int32 idx;

    ret = CTCKAL_SUCCESS;

    pthread_mutex_lock(&queue_storage_mutex);

    /* check parameters */
    if (queue == NULL)
    {
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    idx = get_queue_storage_cell();
    if (idx < 0)
    {
        ret = CTCKAL_ERR_RESOURCE;
        goto ERROR;
    }

    queue_storage[idx].state = USING;
    queue_storage[idx].ptr_head = NULL;
    queue_storage[idx].ptr_tail = NULL;

    pthread_mutex_unlock(&queue_storage_mutex);

    *queue = (ctckal_queue_t)idx;

    return CTCKAL_SUCCESS;

ERROR:
    pthread_mutex_unlock(&queue_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_queue_destroy
 * Purpose      :
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void
ctckal_queue_destroy(ctckal_queue_t queue)
{
    int32 idx;
    message_cell_t *ptr;
    message_cell_t *tmp_ptr;

    pthread_mutex_lock(&queue_storage_mutex);

    idx = (int32)queue;
    if (idx < 0 || idx >= QUEUE_STORAGE_SIZE
        || queue_storage[idx].state != USING)
        goto ERROR;

    ptr = queue_storage[idx].ptr_head;
    while (ptr)
    {
        tmp_ptr = ptr->next;
        sal_free(ptr->message);
        sal_free(ptr);
        ptr = tmp_ptr;
    }
    queue_storage[idx].ptr_head = NULL;
    queue_storage[idx].ptr_tail = NULL;
    queue_storage[idx].state = INVALID;

    pthread_mutex_unlock(&queue_storage_mutex);
    return;

ERROR:
    pthread_mutex_unlock(&queue_storage_mutex);
}


/*****************************************************************************
 * Name         : ctckal_queue_send
 * Purpose      :
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_queue_send(ctckal_queue_t queue, void *message, uint32 size)
{
    int32 ret;
    int32 idx;
    message_cell_t *ptr;

    ret = CTCKAL_SUCCESS;
    ptr = NULL;

    pthread_mutex_lock(&queue_storage_mutex);

    idx = (int32)queue;
    if (idx < 0 || idx >= QUEUE_STORAGE_SIZE
        || queue_storage[idx].state != USING)
    {
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    ptr = (message_cell_t*)malloc(sizeof(message_cell_t));
    if (ptr == NULL)
    {
        ret = CTCKAL_ERR_RESOURCE;
        goto ERROR;
    }
    ptr->message = malloc(size);
    if (ptr->message == NULL)
    {
        ret = CTCKAL_ERR_RESOURCE;
        goto ERROR;
    }
    sal_memcpy(ptr->message, message, size);
    ptr->size = size;
    ptr->next = NULL;
    if (queue_storage[idx].ptr_head == NULL)
        queue_storage[idx].ptr_head = queue_storage[idx].ptr_tail = ptr;
    else
    {
        queue_storage[idx].ptr_tail->next = ptr;
        queue_storage[idx].ptr_tail = ptr;
    }

    pthread_mutex_unlock(&queue_storage_mutex);
    return CTCKAL_SUCCESS;

ERROR:
    if (ptr)
    {
        if (ptr->message)
            sal_free(ptr->message);
        sal_free(ptr);
    }
    pthread_mutex_unlock(&queue_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_queue_send_front
 * Purpose      :
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_queue_send_front(ctckal_queue_t queue, void *message, uint32 size)
{
    int32 ret;
    int32 idx;
    message_cell_t *ptr;

    ret = CTCKAL_SUCCESS;
    ptr = NULL;

    pthread_mutex_lock(&queue_storage_mutex);

    idx = (int32)queue;
    if (idx < 0 || idx >= QUEUE_STORAGE_SIZE
        || queue_storage[idx].state != USING)
    {
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    ptr = (message_cell_t*)malloc(sizeof(message_cell_t));
    if (ptr == NULL)
    {
        ret = CTCKAL_ERR_RESOURCE;
        goto ERROR;
    }
    ptr->message = malloc(size);
    if (ptr->message == NULL)
    {
        ret = CTCKAL_ERR_RESOURCE;
        goto ERROR;
    }
    sal_memcpy(ptr->message, message, size);
    ptr->size = size;
    ptr->next = queue_storage[idx].ptr_head;
    queue_storage[idx].ptr_head = ptr;
    if (queue_storage[idx].ptr_tail == NULL)
        queue_storage[idx].ptr_tail = ptr;

    pthread_mutex_unlock(&queue_storage_mutex);
    return CTCKAL_SUCCESS;

ERROR:
    if (ptr)
    {
        if (ptr->message)
            sal_free(ptr->message);
        sal_free(ptr);
    }
    pthread_mutex_unlock(&queue_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_queue_receive
 * Purpose      :
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_queue_receive(ctckal_queue_t queue, void *message, uint32 *size, uint32 flag)
{
    int32 ret;
    int32 idx;
    message_cell_t *ptr;

    ret = CTCKAL_SUCCESS;
    idx = (int32)queue;

LOOP:
    pthread_mutex_lock(&queue_storage_mutex);
    if (idx < 0 || idx >= QUEUE_STORAGE_SIZE
        || queue_storage[idx].state != USING)
    {
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    if (queue_storage[idx].ptr_head == NULL)
    {
        if(QUE_TIMEOUT_INFINITE & flag)
        {
            pthread_mutex_unlock(&queue_storage_mutex);
            usleep(1);
            goto LOOP;
        }
        else
        {
            ret = CTCKAL_ERR_EMPTY;
            goto ERROR;
        }
    }

    if (message == NULL || queue_storage[idx].ptr_head->size > (*size))
    {
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    sal_memcpy(message, queue_storage[idx].ptr_head->message,
           queue_storage[idx].ptr_head->size);
    *size = queue_storage[idx].ptr_head->size;

    ptr = queue_storage[idx].ptr_head;
    queue_storage[idx].ptr_head = queue_storage[idx].ptr_head->next;
    sal_free(ptr->message);
    sal_free(ptr);
    if (queue_storage[idx].ptr_head == NULL)
        queue_storage[idx].ptr_tail = NULL;

    pthread_mutex_unlock(&queue_storage_mutex);
    return CTCKAL_SUCCESS;

ERROR:
    pthread_mutex_unlock(&queue_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_queue_reset
 * Purpose      :
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_queue_reset(ctckal_queue_t queue)
{
    int32 ret;
    int32 idx;
    message_cell_t *ptr;
    message_cell_t *tmp_ptr;

    ret = CTCKAL_SUCCESS;

    pthread_mutex_lock(&queue_storage_mutex);

    idx = (int32)queue;
    if (idx < 0 || idx >= QUEUE_STORAGE_SIZE
        || queue_storage[idx].state != USING)
    {
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    ptr = queue_storage[idx].ptr_head;
    while (ptr)
    {
        tmp_ptr = ptr->next;
        sal_free(ptr->message);
        sal_free(ptr);
        ptr = tmp_ptr;
    }
    queue_storage[idx].ptr_head = NULL;
    queue_storage[idx].ptr_tail = NULL;

    pthread_mutex_unlock(&queue_storage_mutex);
    return CTCKAL_SUCCESS;

ERROR:
    pthread_mutex_unlock(&queue_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_queue_init
 * Purpose      :
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_queue_init(void)
{
    pthread_mutex_init(&queue_storage_mutex, NULL);

    return CTCKAL_SUCCESS;
}


/*****************************************************************************
 * Name         : ctckal_queue_exit
 * Purpose      :
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void
ctckal_queue_exit(void)
{
    int32 i;
    message_cell_t *ptr;
    message_cell_t *tmp_ptr;

    for (i = 0; i < QUEUE_STORAGE_SIZE; i++)
    {
        if (queue_storage[i].state != INVALID)
        {
            ptr = queue_storage[i].ptr_head;
            while (ptr)
            {
                tmp_ptr = ptr->next;
                sal_free(ptr->message);
                sal_free(ptr);
                ptr = tmp_ptr;
            }
            queue_storage[i].ptr_head = NULL;
            queue_storage[i].ptr_tail = NULL;
            queue_storage[i].state = INVALID;
        }
    }

    pthread_mutex_destroy(&queue_storage_mutex);
}
