/****************************************************************************
 * ctcutil_list.c:          double linked list
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Yiquan Chen
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#include "sal.h"
#include "ctcutil_list.h"


/****************************************************************************
 * static functions
 ****************************************************************************/
static inline void
__list_add(struct list_head *new,
           struct list_head *prev,
           struct list_head *next)
{
    next->prev = new;
    new->next = next;
    new->prev = prev;
    prev->next = new;
}


static inline void
__list_del(struct list_head * prev, struct list_head * next)
{
    next->prev = prev;
    prev->next = next;
}


static inline void
__list_splice(struct list_head *list, struct list_head *head)
{
    struct list_head *first = list->next;
    struct list_head *last = list->prev;
    struct list_head *at = head->next;

    first->prev = head;
    head->next = first;

    last->next = at;
    at->prev = last;
}


/****************************************************************************
 * Name		: list_add
 * Purpose	: add a new entry
 * Input	: @new:  new entry to be added
 *              : @head: list head to add it after
 * Output	:
 * Return	: void
 *		:
 * Note		: Insert a new entry after the specified head.
 *              : This is good for implementing stacks.
 ****************************************************************************/
inline void
list_add(struct list_head *new, struct list_head *head)
{
    __list_add(new, head, head->next);
}


/****************************************************************************
 * Name		: list_add_tail
 * Purpose	: add a new entry
 * Input	: @new: new entry to be added
 *              : @head: list head to add it before
 * Output	:
 * Return	: void
 *		:
 * Note		: Insert a new entry after the specified head.
 *              : This is good for implementing queues.
 ****************************************************************************/
inline void
list_add_tail(struct list_head *new, struct list_head *head)
{
    __list_add(new, head->prev, head);
}


/****************************************************************************
 * Name		: list_del
 * Purpose	: deletes entry from list.
 *              :
 * Input	: @entry:the element to delete from the list.
 * Output	:
 * Return	: void
 *		:
 * Note         :
 ****************************************************************************/
inline void
list_del(struct list_head *entry)
{
    __list_del(entry->prev, entry->next);
    entry->next = LIST_POISON1;
    entry->prev = LIST_POISON2;
}


/****************************************************************************
 * Name		: list_del_all
 * Purpose	: deletes entry from list.
 * Input	: @head: the head of the list
 * Output	: n/a
 * Return	: void
 * Note         : it does not free the memory!
 ****************************************************************************/
inline void
list_del_all(struct list_head *head)
{
    struct list_head *pos;
    struct list_head *entry;

    pos = head->next;
    while (pos != head)
    {
        entry = pos;
        pos = pos->next;
        entry->next = 0;
        entry->prev = 0;
    }

    INIT_LIST_HEAD(head);
}

#if 0
inline void
list_del_all_and_free(struct list_head *head)
{
    struct list_head *pos;
    struct list_head *entry;

    pos = head->next;
    while (pos != head)
    {
        entry = pos;
        pos = pos->next;
        entry->next = 0;
        entry->prev = 0;
        SAL_FREE(entry);
    }

    INIT_LIST_HEAD(head);
}
#endif

/****************************************************************************
 * Name		: list_del_init
 * Purpose	: deletes entry from list and reinitialize it.
 *              :
 * Input	: @entry:the element to delete from the list.
 * Output	:
 * Return	: void
 *		:
 * Note		:
 ****************************************************************************/
inline void
list_del_init(struct list_head *entry)
{
    __list_del(entry->prev, entry->next);
    INIT_LIST_HEAD(entry);
}


/****************************************************************************
 * Name		: list_empty
 * Purpose	: test whether a list is empty.
 *              :
 * Input	: @head:the list to test.
 * Output	:
 * Return	: int32
 *	        :
 * Note		:
 ****************************************************************************/
inline int32
list_empty(const struct list_head *head)
{
    return head->next == head;
}


/****************************************************************************
 * Name		: list_splice
 * Purpose	: join two lists.
 *              :
 * Input	: @list:the new list to add.
 *              : @head:the place to add it in the first list.
 * Output	:
 * Return	: void
 *		:
 * Note		:
 ****************************************************************************/
inline void
list_splice(struct list_head *list, struct list_head *head)
{
    if (!list_empty(list))
        __list_splice(list, head);
}


/****************************************************************************
 * Name		: list_splice
 * Purpose	: join two lists.
 *              :
 * Input	: @list:the new list to add.
 *              : @head:the place to add it in the first list.
 * Output	:
 * Return	: void
 *		:
 * Note		: The list at @list is reinitialised
 ****************************************************************************/
inline void
list_splice_init(struct list_head *list, struct list_head *head)
{
    if (!list_empty(list))
    {
        __list_splice(list, head);
        INIT_LIST_HEAD(list);
    }
}


/****************************************************************************
 * Name		: list_move
 * Purpose	: delete from one list and add as another's head
 *              :
 * Input	: @list:he entry to move
 *              : @head: the head that will precede our entry
 * Output	:
 * Return	: void
 *		:
 * Note		:
****************************************************************************/
inline void
list_move(struct list_head *list, struct list_head *head)
{
    __list_del(list->prev, list->next);
    list_add(list, head);
}


/****************************************************************************
 * Name		: list_move
 * Purpose	: delete from one list and add as another's head
 *              :
 * Input	: @list:he entry to move
 *              : @head: the head that will follow our entry
 * Output	:
 * Return	: void
 *		:
 * Note		:
****************************************************************************/
inline void
list_move_tail(struct list_head *list, struct list_head *head)
{
    __list_del(list->prev, list->next);
    list_add_tail(list, head);
}
