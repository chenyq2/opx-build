/****************************************************************************
 * ctckal_event.c :     event module
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :     V1.0
 * Author         :     Jack Yang
 * Date           :     2010-7-28
 * Reason         :     First Create
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"

/*****************************************************************************
 * Name         : ctckal_event_create
 * Purpose      : create an event
 * Input        : event_attr: ATTR_AUTO_RESET or ATTR_MANUAL_RESET
 * Output       : event: an event handle for subsequent function calls
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_event_create(ctckal_event_t *event, ctckal_event_attr_t event_attr)
{
    bool auto_reset;
    sal_err_t err;

    if (event_attr == ATTR_AUTO_RESET)
        auto_reset = TRUE;
    else
        auto_reset = FALSE;

    err = sal_event_create(event, auto_reset);

    return err;
}


/*****************************************************************************
 * Name         : ctckal_event_destroy
 * Purpose      : destroy an event
 * Input        : event: event handle output from ctckal_event_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void
ctckal_event_destroy(ctckal_event_t event)
{
    sal_event_destroy(event);
}


/*****************************************************************************
 * Name         : ctckal_event_set
 * Purpose      : set the event to signaled state
 * Input        : event: event handle output from ctckal_event_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_event_set(ctckal_event_t event)
{
    sal_event_set(event);
    return 0;
}


/*****************************************************************************
 * Name         : ctckal_event_reset
 * Purpose      : reset the event to non-signaled state
 * Input        : event: event handle output from ctckal_event_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_event_reset(ctckal_event_t event)
{
    sal_event_reset(event);
    return 0;
}


/*****************************************************************************
 * Name         : ctckal_event_wait
 * Purpose      : wait for an event
 * Input        : event: event handle output from ctckal_event_create
 *              : timeout: if 0, it returns immediately and event_status has
 *                         the event status, so it's like a peek
 *                         if TIMEOUT_INFINITE, it waits for ever until the
 *                         event is signaled
 *                         otherwise, it will wait for up to specific time,
 *                         in seconds
 * Output       : event_status: STATUS_SIGNALED or STATUS_NON_SIGNALED
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_event_wait(ctckal_event_t event, uint32 timeout, int32 *event_status)
{
    if (sal_event_wait(event, timeout))
        *event_status = STATUS_SIGNALED;
    else
        *event_status = STATUS_TIMEOUT;

    return CTCKAL_SUCCESS;
}


/*****************************************************************************
 * Name         : ctckal_event_init
 * Purpose      : initialize the event module
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_event_init(void)
{
    return CTCKAL_SUCCESS;
}


/*****************************************************************************
 * Name         : ctckal_event_exit
 * Purpose      : de-initialize the event module
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void
ctckal_event_exit(void)
{
}
