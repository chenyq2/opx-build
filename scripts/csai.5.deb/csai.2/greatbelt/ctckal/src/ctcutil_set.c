/****************************************************************************
 * ctcutil_set.c    : 	set utility
 *
 * Copyright (C) 2010 Centec Networks, Inc.  All rights reserved.
 *
 * Modify History   :
 * Revision	    :	V1.0
 * Author	    : 	Yiquan Chen
 * Date		    :	2010-07-19
 * Reason	    :	First Create.
 ****************************************************************************/

/* todo: error code */

/****************************************************************************
 * Header Files
 ****************************************************************************/
#include "sal.h"
#include <stdlib.h>
#include <string.h>
#include "ctcutil_set.h"


/****************************************************************************
 * Defines and Macros
 ****************************************************************************/

/****************************************************************************
 * Global and Declarations
 ****************************************************************************/

/****************************************************************************
 * Functions
 ****************************************************************************/

/****************************************************************************
 * Name         : ctcutil_set_create
 * Purpose      : construct a new set
 * Input        : @max_items
 *              : @items_size
 * Output       :
 * Return       : a pionter to an empty sets
 * Note         : Pre-condition: max_items > 0
 ****************************************************************************/
ctcutil_set_t *
ctcutil_set_create(uint32 max_items, uint32 item_size)
{
    ctcutil_set_t *s;

    if (max_items == 0 || item_size == 0)
        return NULL;

    s = (ctcutil_set_t*)malloc(sizeof(ctcutil_set_t));
    if (s == NULL)
        return NULL;

    s->item_cnt = 0;
    s->max_items = max_items;
    s->item_size = item_size;

    s->items = (void**)malloc(max_items * sizeof(void*));
    if (s->items == NULL)
    {
        sal_free(s);
        return NULL;
    }

    return s;
}


/****************************************************************************
 * Name		: ctcutil_set_add_item
 * Purpose	: add an item to a set
 * Input	: @s
 *		: @item
 * Output	:
 * Return	:
 * Note		: Pre-condition: (s is a sets created by a call to
 *              :                 ctcutil_set_create) &&
 *              :                (existing item count < max_items) &&
 *              :                (item != NULL)
 *              : Post-condition: item has been added to s
 ****************************************************************************/
int32
ctcutil_set_add_item(ctcutil_set_t* s, void *item)
{
    if (s == NULL || item == NULL)
        return -1;

    if (s->item_cnt >= s->max_items)
        return -2;

    s->items[s->item_cnt] = item;
    s->item_cnt++;

    return 0;
}


/****************************************************************************
 * Name       : ctcutil_set_del_item
 * Purpose    : delete an item from a set
 * Input      : @s
 *            : @item
 * Output     :
 * Return     : void
 * Note       : Pre-condition: (s is a sets created by a call to
 *            :                 ctcutil_set_create) &&
 *            :                (existing item count >= 1) &&
 *            :                (item != NULL)
 *            : Post-condition: item has been deleted from s
 ****************************************************************************/
int32
ctcutil_set_del_item(ctcutil_set_t* s, void *item)
{
    int32 i;
    int32 j;

    if (s == NULL || item == NULL)
        return -1;

    if (s->item_cnt == 0)
        return -2;

    for (i = 0; i < s->item_cnt; i++)
    {
        if (s->items[i] == item)
        {
            j = i;
            while (j < s->item_cnt)
            {
                s->items[j] = s->items[j+1];
                j++;
            }
            s->item_cnt--;
            break;
        }
    }

    if (i == s->item_cnt)
        return -1;

    return 0;
}


/****************************************************************************
 * Name       : ctcutil_set_find_item
 * Purpose    : find an item in a set
 * Input      : @s
 *            : @key
 * Output     :
 * Return     :
 * Note       : Pre-condition: (s is a sets created by a call to
 *            :                 ctcutil_set_create) &&
 *            :                (key != NULL)
 *            : Post-condition: returns an item identified by key if one
 *            :                 exists, otherwise returns NULL
 ****************************************************************************/
void *
ctcutil_set_find_item(ctcutil_set_t* s, void *key)
{
    int32 i;

    if (s == NULL || key == NULL)
        return NULL;

    for (i = 0; i < s->item_cnt; i++)
    {
        if (s->items[i] == key
            && sal_memcmp(s->items[i], key, s->item_size))
            return s->items[i];
    }

    return NULL;
}


/****************************************************************************
 * Name         : ctcutil_set_destroy
 * Purpose      : delete a set
 * Input        : @s
 * Output       :
 * Return       : void
 *              :
 * Note         :
 ****************************************************************************/
int32
ctcutil_set_destroy(ctcutil_set_t* s)
{
    if (s == NULL)
        return -1;

    sal_free(s->items);
    sal_free(s);

    return 0;
}


/****************************************************************************
 * Name         : ctcutil_set_is_empty
 * Purpose      : check if the set is empty
 * Input        : @s
 * Output       :
 * Return       :
 *              :
 * Note         :
 ****************************************************************************/
bool
ctcutil_set_is_empty(ctcutil_set_t* s)
{
    if (s == NULL)
        return -1;

    if (s->item_cnt > 0)
        return TRUE;

    return FALSE;
}


/****************************************************************************
 * Name         : ctcutil_set_get_cnt
 * Purpose      : get item coutn
 * Input        : @s
 * Output       :
 * Return       :
 *              :
 * Note         :
 ****************************************************************************/
int32
ctcutil_set_get_item_cnt(ctcutil_set_t* s, uint32 *p_cnt)
{
    if (s == NULL || p_cnt == NULL)
        return -1;

    *p_cnt = s->item_cnt;

    return 0;
}


static int32 internal_count = 0;


/****************************************************************************
 * Name         : ctcutil_set_get_first
 * Purpose      : get the first item
 * Input        : @s
 * Output       :
 * Return       :
 *              :
 * Note         :
 ****************************************************************************/
void *
ctcutil_set_get_first(ctcutil_set_t* s)
{
    if (s == NULL || s->item_cnt == 0)
        return NULL;

    internal_count = 1;

    return s->items[0];
}


/****************************************************************************
 * Name         : ctcutil_set_next
 * Purpose      : get next item
 * Input        : @s
 * Output       :
 * Return       :
 *              :
 * Note         :
 ****************************************************************************/
void *
ctcutil_set_get_next(ctcutil_set_t* s)
{
    if (s == NULL)
        return NULL;

    if (internal_count == s->item_cnt)
        return NULL;

    return s->items[internal_count++];
}


#if 0  /* todo */
int32 sets_union(sets* dest, sets* src1, sets* src2)
{
    int32 max_items, item_size;
    int32 i;

    max_items = src1->max_items+src2->max_items;
    item_size = src1->size;
    /*
    dest = cons_collection(max_items, item_size);
    if(!dest)
        return -1;
    else
        printf("dest collection created succfully!\n");
    */
    for(i = 0; i < src1->item_cnt; i++)
        add_to_sets(dest, src1->items[i]);

    for(i = 0; i < src2->item_cnt; i++)
        if(!find_in_sets(dest, ItemKey(src2->items[i])))
            add_to_sets(dest, src2->items[i]);

    return 0;
}

int32 sets_intersection(sets* dest, sets* src1, sets* src2)
{
    int32 max_items, item_size;
    int32 i;

    max_items = src1->max_items;
    item_size = src1->size;
    /*
    dest = cons_collection(max_items, item_size);
    if(!dest)
        return -1;
    */
    for(i = 0; i < src1->item_cnt; i++)
        if(find_in_sets(src2, src1->items[i]))
            add_to_sets(dest, src1->items[i]);
    return 0;
}

int32 sets_difference(sets* dest, sets* src1, sets* src2)
{
    int32 max_items, item_size;
    int32 i;

    max_items = src1->max_items;
    item_size = src1->size;
    /*
    dest = cons_collection(max_items, item_size);
    if(!dest)
        return -1;
    */
    for(i = 0; i < src1->item_cnt; i++)
        if(!find_in_sets(src2, src1->items[i]))
            add_to_sets(dest, src1->items[i]);

    return 0;
}

bool sets_is_subset(sets* dest, sets* src)
{
    int32 i;

    for(i = 0; i < src->item_cnt; i++)
        if(!find_in_sets(dest, src->items[i]))
            return FALSE;
    return TRUE;
}

bool sets_is_equal(sets* dest, sets* src)
{
    bool dest_bool, src_bool;
    dest_bool = sets_is_subset(src, dest);
    src_bool = sets_is_subset(dest, src);
    if(dest_bool && src_bool)
        return TRUE;
    else
        return FALSE;
}
#endif
