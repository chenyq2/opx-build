/****************************************************************************
 * cmodel_cli.h   cmodel cli header file
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0
 * Author:       Jiang
 * Date:         2010-11-1.
 * Reason:       First Create.
 ****************************************************************************/

#ifndef _CMODEL_CLI_H
#define _CMODEL_CLI_H
#include "sal.h"
#include "ctc_cli.h"
#define CM_IPV6_ADDR_LEN 4
#define CM_IPV4_ADDR_LEN 1
#define CM_ETH_ADDR_LEN  6
#define CM_ROCTO(ip32, index) ((ip32[(index) / 4] >> (32 - ((((index) % 4) + 1) * 8))) & 0xFF)

typedef uint8 cm_mac_addr_t[CM_ETH_ADDR_LEN];

enum cm_ip_octo_e
{
    CM_IP_OCTO_0_7,
    CM_IP_OCTO_8_15,
    CM_IP_OCTO_16_23,
    CM_IP_OCTO_24_31,
    CM_IP_OCTO_32_39,
    CM_IP_OCTO_40_47,
    CM_IP_OCTO_48_55,
    CM_IP_OCTO_56_63,
    CM_IP_OCTO_64_71,
    CM_IP_OCTO_72_79,
    CM_IP_OCTO_80_87,
    CM_IP_OCTO_88_95,
    CM_IP_OCTO_96_103,
    CM_IP_OCTO_104_111,
    CM_IP_OCTO_112_119,
    CM_IP_OCTO_120_127,
};
typedef enum cm_ip_octo_e cm_ip_octo_t;

union cm_ipv4_addr_u
{
    uint32 ip32[1];
};
typedef union cm_ipv4_addr_u cm_ipv4_addr_t;

union cm_ipv6_addr_u
{
    uint32 ip32[CM_IPV6_ADDR_LEN];
};
typedef union cm_ipv6_addr_u cm_ipv6_addr_t;

extern int32 ctc_cmodel_cli_init(uint8 cli_tree_mode);
extern void install_mem_allocation_cli(uint8 cli_tree_mode);

extern void cio_printf(char * str);

#endif  /* _CTC_L2_CLI_H */



