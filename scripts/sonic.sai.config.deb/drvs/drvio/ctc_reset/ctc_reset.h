#ifndef __CTC_RESET_H__
#define __CTC_RESET_H__

#define CTC_RESET_DEV_NAME     "/dev/ctc_reset"
#define CTC_RESET_DEV_MAJOR    112                                                              \

#endif

