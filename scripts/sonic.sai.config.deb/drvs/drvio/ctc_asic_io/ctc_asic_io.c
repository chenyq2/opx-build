/****************************************************************************
 * ctc_asic_io.c :        lkm for ASIC PCI interface
 *
 * Copyright (C) 2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         R0.01
 * Author         :         Zhu Jian
 * Date           :         2010-07-01
 * Reason         :         First Create
 ****************************************************************************/
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/types.h>
#include <asm/io.h>
#include <linux/pci.h>
#ifdef _CTC_OCTEON_CN50XX_
#include <linux/sched.h>
#include <asm/irq.h>
#include <linux/poll.h>
#include <linux/wait.h>
#include <linux/interrupt.h>
#else
#include <asm/uaccess.h>
#endif
#include "ctc_asic_io.h"

#define CTC_ASIC_VID 0x18e8
#define CTC_ASIC_DID 0x6048

#define HUMBER_PCI_READ_ADDR  0x0
#define HUMBER_PCI_READ_DATA  0xc
#define HUMBER_PCI_WRITE_ADDR 0x8
#define HUMBER_PCI_WRITE_DATA 0x4
#define HUMBER_PCI_STATUS     0x10

#define PCI_STATUS_IN_PROCESS      31
#define PCI_STATUS_BAD_PARITY      5
#define PCI_STATUS_CPU_ACCESS_ERR  4
#define PCI_STATUS_READ_CMD        3
#define PCI_STATUS_REGISTER_ERR    1
#define PCI_STATUS_REGISTER_ACK    0

#define PCI_ACCESS_TIMEOUT 0x6400

#ifdef  CTC_LKM_DEBUG
#define CTC_IO_DEBUG(fmt, args...)  printk(KERN_DEBUG "%s: " fmt, __FUNCTION__ , ## args)
#else
#define CTC_IO_DEBUG(x...)
#endif

#define CTC_ASIC_CHIP_NUM_MAX 2

struct ctc_asic_private
{
    u32 pci_phy_addr;
    spinlock_t lock;
};

static struct ctc_asic_private ctc_asic_priv[CTC_ASIC_CHIP_NUM_MAX];

static struct pci_device_id ctc_asic_io_table[] = 
{
    {PCI_DEVICE(CTC_ASIC_VID, CTC_ASIC_DID)},
    {0,},
};

#define CTC_VERIFY_AREA(p_data, len, type)                                  \
{                                                               \
    if (!access_ok(VERIFY_##type, (void*)p_data, len))      \
    {                                                       \
        printk(KERN_WARNING "\nverify_area %lx failed\n", p_data);   \
        return -EFAULT;                                 \
    }                                                       \
}

static int
ctc_asic_io_read(unsigned int chip_id, unsigned int reg_offset, unsigned int *val)
{
    unsigned int status;
    int timeout;
    int ret = 0;

    timeout = PCI_ACCESS_TIMEOUT;
    outl(reg_offset, HUMBER_PCI_READ_ADDR + ctc_asic_priv[chip_id].pci_phy_addr);

    /* polling status */
    status = inl(HUMBER_PCI_STATUS + ctc_asic_priv[chip_id].pci_phy_addr);
    while((!(status&0x1))&&(--timeout))
    {
        status = inl(HUMBER_PCI_STATUS + ctc_asic_priv[chip_id].pci_phy_addr);
    }

    if(!timeout)
    {
        printk("Timeout! read chip by pci failed\n");
        ret += -2; 
    }

    ret += status&(1<<PCI_STATUS_BAD_PARITY)? -4 : 0;
    ret += status&(1<<PCI_STATUS_CPU_ACCESS_ERR)? -8 : 0;
    ret += status&(1<<PCI_STATUS_REGISTER_ERR)? -16 : 0;

    if(ret != 0)
    {
        printk("Read chip %d reg 0x%x status  %x, ret %d\n", 
                chip_id, reg_offset, status, ret);
    }            

    *val = inl(HUMBER_PCI_READ_DATA + ctc_asic_priv[chip_id].pci_phy_addr);

    return ret;
}

static int
ctc_asic_io_write(unsigned int chip_id, unsigned int reg_offset, unsigned int val)
{
    unsigned int status;
    int timeout;
    int ret = 0;

    timeout = PCI_ACCESS_TIMEOUT;
    outl(val, HUMBER_PCI_WRITE_DATA + ctc_asic_priv[chip_id].pci_phy_addr);	
    outl(reg_offset, HUMBER_PCI_WRITE_ADDR + ctc_asic_priv[chip_id].pci_phy_addr);

    /* polling status */
    status = inl(HUMBER_PCI_STATUS + ctc_asic_priv[chip_id].pci_phy_addr);
    while((!(status&0x1))&&(--timeout))
    {
        status = inl(HUMBER_PCI_STATUS + ctc_asic_priv[chip_id].pci_phy_addr);
    }

    if(!timeout)
    {
        printk("Timeout! Write chip by PCI failed\n");
        ret += -2; 
    }
    
    ret += status&(1<<PCI_STATUS_BAD_PARITY)? -4 : 0;
    ret += status&(1<<PCI_STATUS_CPU_ACCESS_ERR)? -8 : 0;
    ret += status&(1<<PCI_STATUS_REGISTER_ERR)? -16 : 0;
    if(ret != 0)
    {
        printk("Write chip %d reg 0x%x status %x, ret %d\n", 
                    chip_id, reg_offset, status, ret);
    }

    return ret;
}

#ifdef _CTC_OCTEON_CN50XX_
static long ctc_asic_io_ioctl (struct file *file, 
            unsigned int cmd, unsigned long parameter) 
#else
static int ctc_asic_io_ioctl (struct inode *inode, struct file *file, 
            unsigned int cmd, unsigned long parameter) 
#endif
{    
    unsigned long flags;
    int timeout;
    int ret = 0;
    cmdpara_asic_t access_para;
    cmdpara_asic_4w_w_t access_para_4w_w;
    cmdpara_asic_4w_r_t access_para_4w_r;
    u32 chip_id = 0;
    u32 reg_offset = 0;

    if(cmd == CTC_CTCLI_ASIC_IO_READ || cmd == CTC_CTCLI_ASIC_IO_WRITE
        || cmd == CTC_ASIC_IO_READ || cmd == CTC_ASIC_IO_WRITE)
    {
        CTC_VERIFY_AREA(parameter, sizeof(cmdpara_asic_t), CTC_ASIC_IO);
        if(copy_from_user((void*)&access_para, (void*)parameter, sizeof(cmdpara_asic_t)))
        {
            return -EFAULT;
        }
        chip_id = access_para.chip_id;
        reg_offset = access_para.reg_offset;
        if(!ctc_asic_priv[chip_id].pci_phy_addr)
        {
            printk("chip %d is not existed\n", chip_id);
            return -EFAULT;
        }
    }
    else if(cmd == CTC_ASIC_IO_READ_4W)
    {
        CTC_VERIFY_AREA(parameter, sizeof(cmdpara_asic_4w_r_t), CTC_ASIC_IO);
        if(copy_from_user((void*)&access_para_4w_r, (void*)parameter, sizeof(cmdpara_asic_4w_r_t)))
        {
            return -EFAULT;
        }
        chip_id = access_para_4w_r.asic_info.chip_id;
        reg_offset = access_para_4w_r.asic_info.reg_offset;
        if(!ctc_asic_priv[chip_id].pci_phy_addr)
        {
            printk("chip %d is not existed\n", chip_id);
            return -EFAULT;
        }
    }
    else if(cmd == CTC_ASIC_IO_WRITE_4W)
    {
        CTC_VERIFY_AREA(parameter, sizeof(cmdpara_asic_4w_w_t), CTC_ASIC_IO);
        if(copy_from_user((void*)&access_para_4w_w, (void*)parameter, sizeof(cmdpara_asic_4w_w_t)))
        {
            return -EFAULT;
        }
        chip_id = access_para_4w_w.chip_id;
        reg_offset = access_para_4w_w.reg_offset;
        if(!ctc_asic_priv[chip_id].pci_phy_addr)
        {
            printk("chip %d is not existed\n", chip_id);
            return -EFAULT;
        }
    }
    
    timeout = PCI_ACCESS_TIMEOUT;
    switch (cmd)
    {
        case CTC_ASIC_IO_READ:
        case CTC_CTCLI_ASIC_IO_READ:
            spin_lock_irqsave(&ctc_asic_priv[chip_id].lock, flags);
            ret += ctc_asic_io_read(chip_id, reg_offset, &access_para.value);
            spin_unlock_irqrestore(&ctc_asic_priv[chip_id].lock, flags);
            
            if(copy_to_user((void*)parameter, (void*)&access_para, sizeof(cmdpara_asic_t)))
            {
                return -EFAULT;
            }
            break;
            
        case CTC_ASIC_IO_WRITE:
        case CTC_CTCLI_ASIC_IO_WRITE:            
            spin_lock_irqsave(&ctc_asic_priv[chip_id].lock, flags);
            ret += ctc_asic_io_write(chip_id, reg_offset, access_para.value);
            spin_unlock_irqrestore(&ctc_asic_priv[chip_id].lock, flags);
            break;
            
        case CTC_ASIC_IO_READ_4W:
            spin_lock_irqsave(&ctc_asic_priv[chip_id].lock, flags);
            ret += ctc_asic_io_read(chip_id, reg_offset, &access_para_4w_r.val[0]);
            ret += ctc_asic_io_read(chip_id, reg_offset+0x4, &access_para_4w_r.val[1]);
            ret += ctc_asic_io_read(chip_id, reg_offset+0x8, &access_para_4w_r.val[2]);
            ret += ctc_asic_io_read(chip_id, reg_offset+0xc, &access_para_4w_r.val[3]);
            spin_unlock_irqrestore(&ctc_asic_priv[chip_id].lock, flags);

            if(copy_to_user((void*)parameter, (void*)&access_para_4w_r, sizeof(cmdpara_asic_4w_r_t)))
            {
                return -EFAULT;
            }
            break;
            
        case CTC_ASIC_IO_WRITE_4W:
            spin_lock_irqsave(&ctc_asic_priv[chip_id].lock, flags);
            ret += ctc_asic_io_write(chip_id, reg_offset, access_para_4w_w.val[0]);
            ret += ctc_asic_io_write(chip_id, reg_offset+0x4, access_para_4w_w.val[1]);
            ret += ctc_asic_io_write(chip_id, reg_offset+0x8, access_para_4w_w.val[2]);
            ret += ctc_asic_io_write(chip_id, reg_offset+0xc, access_para_4w_w.val[3]);
            spin_unlock_irqrestore(&ctc_asic_priv[chip_id].lock, flags);
            break;
            
        default:
            break;
    }
    
    return ret;
}

int ctc_asic_io_probe (struct pci_dev *pdev, const struct pci_device_id *id)
{
    int err;
    u8 bar = 0;

    CTC_IO_DEBUG(KERN_WARNING"CTC asic io probe\n");
    err = pci_enable_device(pdev);
    if (err) 
    {
        printk(KERN_WARNING"Cannot enable PCI device, aborting\n");
        return err;
    }
    
    if (!(pci_resource_flags(pdev, 0) & IORESOURCE_IO)) 
    {
        printk(KERN_WARNING"Cannot find proper PCI device base address\n");
        err = -ENODEV;
        goto pci_resource_fail;
    }
    
    err = pci_request_regions(pdev, CTC_ASIC_IO_DRV_NAME);
    if (err) 
    {
        printk(KERN_WARNING"Cannot obtain PCI resources\n");
        goto pci_resource_fail;
    }

    if(ctc_asic_priv[0].pci_phy_addr)
    {
        ctc_asic_priv[1].pci_phy_addr = pci_resource_start(pdev, bar);
    }
    else
    {
        ctc_asic_priv[0].pci_phy_addr = pci_resource_start(pdev, bar);
    }
    
    return err;
    
pci_resource_fail:
    pci_disable_device(pdev);
    return err;
}

void ctc_asic_io_remove (struct pci_dev *pdev)
{
    pci_release_regions(pdev);
    pci_disable_device(pdev);
}

static struct file_operations fops = 
{
    .owner = THIS_MODULE,
#ifdef _CTC_OCTEON_CN50XX_
    .compat_ioctl = ctc_asic_io_ioctl,
#else
    .ioctl = ctc_asic_io_ioctl,
#endif
};

static struct pci_driver ctc_asic_io =
{
    .name = CTC_ASIC_IO_DRV_NAME,
    .id_table = ctc_asic_io_table,
    .probe = ctc_asic_io_probe,
    .remove = ctc_asic_io_remove,
};

static int __init ctc_asic_io_init(void)
{
    int ret;
    int chip_id;

    for(chip_id = 0; chip_id < CTC_ASIC_CHIP_NUM_MAX; chip_id++)
    {
        ctc_asic_priv[chip_id].pci_phy_addr = 0;
        spin_lock_init(&ctc_asic_priv[chip_id].lock);
    }
    
    ret = register_chrdev(CTC_ASIC_IO_DEV_MAJOR, "ctc_asic_io", &fops);
    if (ret<0)
    {
        printk(KERN_WARNING "Register ctc_asic_io character device, ret %d\n", ret);
        return ret;
    }   

    ret = pci_register_driver(&ctc_asic_io);
    if (ret<0)
    {
        printk(KERN_WARNING "Register ASIC PCI driver failed, ret %d\n", ret);
        return ret;
    }
    
    return ret;
}

static void __exit ctc_asic_io_exit(void)
{
    unregister_chrdev(CTC_ASIC_IO_DEV_MAJOR, "ctc_asic_io");
    pci_unregister_driver(&ctc_asic_io);
}

module_init(ctc_asic_io_init);                                                                                                                   
module_exit(ctc_asic_io_exit);
MODULE_LICENSE("GPL");
