#ifndef __CTC_ASIC_IO_H__
#define __CTC_ASIC_IO_H__

#define CTC_ASIC_IO_DRV_NAME "ctc_asic_io"
#define CTC_ASIC_IO_DEV_NAME     "/dev/ctc_allctrl"
#define CTC_ASIC_IO_DEV_MAJOR    99

//#define CTC_ASIC_IO_READ  _IO(CTC_ASIC_IO_DEV_MAJOR, 1)
//#define CTC_ASIC_IO_WRITE _IO(CTC_ASIC_IO_DEV_MAJOR, 2)
/* todo: block comments */
enum ctc_io_cmd_e {
    /* Bay */
    CTC_ASIC_IO_WRITE = 0,
    CTC_ASIC_IO_READ = 1,

    CTC_ASIC_IO_WRITE_4W = 2,
    CTC_ASIC_IO_READ_4W = 3,

    CTC_CTCLI_ASIC_IO_WRITE = 24,
    CTC_CTCLI_ASIC_IO_READ = 25,
};

typedef struct cmdpara_asic_s {
    uint32_t chip_id;
    uint32_t fpga_id;
    uint32_t reg_offset;
    uint32_t value;
} cmdpara_asic_t;

typedef struct para_asic_info_s {
    uint32_t chip_id;
    uint32_t reg_offset;
} para_asic_info_t;

typedef union cmdpara_asic_4w_r_s{
    uint32_t val[4];
    para_asic_info_t asic_info;
}cmdpara_asic_4w_r_t;

typedef struct cmdpara_asic_4w_w_s{
    uint32_t chip_id;
    uint32_t reg_offset;
    uint32_t val[4];
}cmdpara_asic_4w_w_t;

#endif

