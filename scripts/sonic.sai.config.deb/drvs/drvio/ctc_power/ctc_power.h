#ifndef __CTC_POWER_H__
#define __CTC_POWER_H__

#define CTC_POWER_DEV_NAME          "/dev/ctc_power"
#define CTC_POWER_DEV_MAJOR         113                                                            \

#endif

