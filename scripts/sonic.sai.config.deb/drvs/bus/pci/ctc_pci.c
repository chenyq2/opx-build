#include <sys/ioctl.h>
#include "sal_common.h"
#include "ctc_hw.h"
#include "ctc_reset.h"
#include "ctc_power.h"
#include "ctc_phy.h"
#include "ctc_watchdog.h"
#include "ctc_gpio.h"
#include "kernel_monitor.h"

void* pci_mem_base;
int32 hw_fd = -1;
int32 phy_fd = -1;
int32 poe_fd = -1;
int32 dpll_fd = -1;
int32 reset_fd = -1;
/* Added by liuht for bug 27657, 2014-03-25 */
int32 power_fd = -1;
int32 sys_led_fd = -1;
int32 gpio_fd = -1;

void*
get_pci_base()
{
    return pci_mem_base;
}

int32 ctc_hw_fd_init()
{
    hw_fd = open(CTC_HW_DEV_NAME, O_RDWR);
    return hw_fd;
}

int32 get_ctc_hw_fd()
{
    return hw_fd;
}

int32 ctc_phy_fd_init()
{
    phy_fd = open(CTC_PHY_DEV_NAME, O_RDWR);
    return phy_fd;
}

int32 get_ctc_phy_fd()
{
    return phy_fd;
}

int32 ctc_gpio_fd_init()
{
    gpio_fd = open(CTC_GPIO_DEV_NAME, O_RDWR);
    return gpio_fd;
}

int32 get_ctc_gpio_fd()
{
    return gpio_fd;
}

int32 ctc_reset_fd_init()
{
    reset_fd = open(CTC_RESET_DEV_NAME, O_RDWR);
    return reset_fd;
}

int32 get_ctc_reset_fd()
{
    return reset_fd;
}
/* Added by liuht for bug 27657, 2014-03-25 */
int32 ctc_power_fd_init()
{
    power_fd = open(CTC_POWER_DEV_NAME, O_RDWR);
    return power_fd;
}

int32 get_ctc_power_fd()
{
    return power_fd;
}

/* Merge from openflow by liuht for bug 26911, 2014-03-27 */
/* Added by liuht for bug 27412, 2014-03-27 */
int32 ctc_sys_led_fd_init()
{
    sys_led_fd = open(CTC_SYS_LED_DEV_NAME, O_RDWR);
    return sys_led_fd;
}

int32 get_ctc_sys_led_fd()
{
    return sys_led_fd;
}
/* End of Merge */

int32 get_ctc_poe_fd()
{   
    return poe_fd;
}

int32 get_ctc_dpll_fd()
{
#if 0
    if(dpll_fd < 0)
    {
        dpll_fd = open(CTC_DPLL_DEV_NAME, O_RDWR);
    }
#endif
    return dpll_fd;
}

int32 
pci_memio_init(uint8 is_fpga)
{
    if (ctc_hw_fd_init() < 0)
    {
        return -1;
    }

    if(is_fpga)   
    {
        pci_mem_base = mmap(NULL, 0x10000, PROT_READ|PROT_WRITE, MAP_SHARED, hw_fd, 0);
        if(pci_mem_base < 0)
        {
            return -1;
        }
    }
    
    return 0;
}

int32
hw_get_ctc_phy_int(int32* phy_intr_stat)
{
    return ioctl(phy_fd, RD_PERI_IRQ_STAT, phy_intr_stat);   
}

int32
hw_get_ctc_reset_int(int32* intr_stat)
{
    return ioctl(reset_fd, RD_PERI_IRQ_STAT, intr_stat);   
}

int32
hw_en_phy_int(int32* irq_num)
{
    return ioctl(phy_fd, CTC_CMD_EN_INTERRUPTS, irq_num);   
}

int32
hw_asic_en_normal_int()
{
//jqiu comment for PTN 2013-02-28
return 0;    
    return ioctl(hw_fd, EN_ASIC_NORMAL_INT, 0);   
}

int32
hw_asic_register_normal_int()
{
//jqiu comment for PTN 2013-02-28
return 0; 
    return ioctl(hw_fd, REG_ASIC_NORMAL_INT, 0);
}    

int32
hw_foam_en_normal_int()
{
    //jqiu comment for PTN 2013-02-28
    return 0;
    return ioctl(hw_fd, EN_FOAM_NORMAL_INT, 0);   
}

int32
hw_foam_register_normal_int()
{
//jqiu comment for PTN 2013-02-28
return 0;    
    return ioctl(hw_fd, REG_FOAM_NORMAL_INT, 0);
}    

int32 
hw_asic_en_fatal_int()
{
//jqiu comment for PTN 2013-02-28
return 0;    
    return ioctl(hw_fd, EN_ASIC_FATAL_INT, 0);   
}

int32 
hw_asic_register_fatal_int()
{
//jqiu comment for PTN 2013-02-28
return 0;      
    return ioctl(hw_fd, REG_ASIC_FATAL_INT, 0);
}

int32 
ctc_disable_all_irqs()
{
return 0;
    return ioctl(hw_fd, CTC_DIS_ALL_IRQS, 0);
}  

int32 
ctc_disable_feed_watchdog()
{
    return ioctl(hw_fd, CTC_DIS_FEED_WATCHDOG, 0);
}

int32 
ctc_disable_watchdog()
{
    return ioctl(hw_fd, CTC_DIS_WATCHDOG, 0);
}

