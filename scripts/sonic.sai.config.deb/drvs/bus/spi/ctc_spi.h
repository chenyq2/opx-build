#ifndef __CTC_SPI_H__
#define __CTC_SPI_H__
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <stdint.h>
#include <linux/types.h>

#include "sal_common.h"

#define OCTEON_SPI_CLK_GPIO      18                  /*GPIO 18*/
#define OCTEON_SPI_DO_GPIO       20                  /*GPIO 20*/
#define OCTEON_SPI_DI_GPIO       19                   /*GPIO 19*/
#define OCTEON_SPI_CS_GPIO       22                   /*GPIO 22*/

/*
 * this structure mirrors the layout of the five port registers in
 * the internal memory map - see iop8260_t in <asm/immap_8260.h>
 */
struct ioport_s
{
    uint32 pdir;  /* Port Data Direction Register (35-3) */
    uint32 ppar;  /* Port Pin Assignment Register (35-4) */
    uint32 psor;  /* Port Special Options Register (35-5) */
    uint32 podr;  /* Port Open Drain Register (35-2) */
    uint32 pdat;  /* Port Data Register (35-3) */
};
typedef struct ioport_s ioport_t;


/*
 * this macro calculates the address within the internal
 * memory map (im) of the set of registers for a port (idx)
 *
 * the internal memory map aligns the above structure on
 * a 0x20 byte boundary
 */
#define ioport_addr(im, idx) (ioport_t *)((uint32)&(im)->im_ioport + ((idx)*0x20))



struct spi_op_para_s
{
    uint32 addr;           /*  address of the spi component */    
    uint32 *val;           /* pointer of the value buffur */
};
typedef struct spi_op_para_s spi_op_para_t;



typedef enum
{
    E_SPI_GPIO = 0,        /* the SPI interface is implemented by GPIO pins */
    E_SPI_CPM,             /* the SPI interface is implemented by 8247 SPI controller */
    E_SPI_FPGA,             /* the SPI interface is implemented by ctrl fpga */
    E_SPI_EPLD,             /* the SPI interface is implemented by EPLD */
    E_SPI_OCTEON_GPIO,     /* the SPI interface is implemented by octeon gpio pins */
    E_SPI_CPU,           /* the SPI interface is implemented by CPU */
} spi_type_e;

typedef enum
{
    PORT_A = 0,        
    PORT_B,
    PORT_C,
    PORT_D
} port_type;

typedef enum
{
    CMD_UINT16_VAL_UINT32,  /*cmd is uint16, and value is uint32*/
    CMD_UINT32_VAL_UINT8,  /*cmd is uint32, and value is uint8*/   
}spi_fpga_type_e;

struct spi_pin_info_s
{
   uint8 prot_index;     /*index == 0,means port a) */
   uint32 bit;            /* pin bit */
};
typedef struct spi_pin_info_s spi_pin_info_t;

enum spi_cpu_chip_sel_e
{
    SPI_CPU_CHIP_SEL_0,
    SPI_CPU_CHIP_SEL_1,
    SPI_CPU_CHIP_SEL_2,
    SPI_CPU_CHIP_SEL_3
};
typedef enum spi_cpu_chip_sel_e spi_cpu_chip_sel_t;

struct spi_epld_info_s
{
    uint8* baseaddr; 
    uint32 busy;
};
typedef struct spi_epld_info_s spi_epld_info_t;


struct spi_fpga_info_s
{
    uint32* baseaddr; 
    uint32 busy;
    spi_fpga_type_e fpga_type;
};
typedef struct spi_fpga_info_s spi_fpga_info_t;

struct spi_gpio_info_s
{
    uint32 cpm_base;
    spi_pin_info_t cs;
    spi_pin_info_t clk;
    spi_pin_info_t data_out;
    spi_pin_info_t data_in;  
};
typedef struct spi_gpio_info_s spi_gpio_info_t;

struct spi_cpm_info_s
{
    uint32 cpm_base;
    spi_pin_info_t cs;
};
typedef struct spi_cpm_info_s spi_cpm_info_t;

struct spi_octeon_gpio_info_s
{
    uint8 cs;
    uint8 clk;
    uint8 data_out;
    uint8 data_in; 
    int32 fd;
};
typedef struct spi_octeon_gpio_info_s spi_octeon_gpio_info_t;

struct spi_cpu_info_s
{
    int32 fd;
    spi_cpu_chip_sel_t chip_sel;
};
typedef struct spi_cpu_info_s spi_cpu_info_t;

union spi_info_union
{    
    spi_fpga_info_t spi_fpga_info;
    spi_gpio_info_t spi_gpio_info;
    spi_cpm_info_t spi_cpm_info;
    spi_epld_info_t spi_epld_info;
    spi_octeon_gpio_info_t spi_octeon_gpio_info;
    spi_cpu_info_t spi_cpu_info;
};
typedef union spi_info_union spi_info_union_t;


struct spi_gen_s
{
    spi_type_e spi_type;     
    uint32 len;              /* spi data length (byte)*/    
    uint32 alen;             /* spi address length (byte)*/ 
    spi_info_union_t spi_info; 
};
typedef struct spi_gen_s spi_gen_t;


typedef struct spi_handle_s spi_handle_t;

struct spi_handle_s
{
    int32 (*close)(spi_handle_t *);
    int32 (*read)(const spi_handle_t *, spi_op_para_t *);
    int32 (*write)(const spi_handle_t *, spi_op_para_t *);
    void *data;
};


struct sysconf8260_s 
{
    uint32  sc_siumcr;
    uint32  sc_sypcr;
    char    res1[6];
    uint16  sc_swsr;
    char    res2[20];
    uint32  sc_bcr;
    uint8   sc_ppc_acr;
    char    res3[3];
    uint32  sc_ppc_alrh;
    uint32  sc_ppc_alrl;
    uint8   sc_lcl_acr;
    char    res4[3];
    uint32  sc_lcl_alrh;
    uint32  sc_lcl_alrl;
    uint32  sc_tescr1;
    uint32  sc_tescr2;
    uint32  sc_ltescr1;
    uint32  sc_ltescr2;
    uint32  sc_pdtea;
    uint8   sc_pdtem;
    char    res5[3];
    uint32  sc_ldtea;
    uint8   sc_ldtem;
    char    res6[163];
};
typedef struct sysconf8260_s sysconf8260_t;


/* Memory controller registers.
*/
struct memctl8260_s 
{
    uint32  memc_br0;
    uint32  memc_or0;
    uint32  memc_br1;
    uint32  memc_or1;
    uint32  memc_br2;
    uint32  memc_or2;
    uint32  memc_br3;
    uint32  memc_or3;
    uint32  memc_br4;
    uint32  memc_or4;
    uint32  memc_br5;
    uint32  memc_or5;
    uint32  memc_br6;
    uint32  memc_or6;
    uint32  memc_br7;
    uint32  memc_or7;
    uint32  memc_br8;
    uint32  memc_or8;
    uint32  memc_br9;
    uint32  memc_or9;
    uint32  memc_br10;
    uint32  memc_or10;
    uint32  memc_br11;
    uint32  memc_or11;
    char    res1[8];
    uint32  memc_mar;
    char    res2[4];
    uint32  memc_mamr;
    uint32  memc_mbmr;
    uint32  memc_mcmr;
    char    res3[8];
    uint16  memc_mptpr;
    char    res4[2];
    uint32  memc_mdr;
    char    res5[4];
    uint32  memc_psdmr;
    uint32  memc_lsdmr;
    uint8   memc_purt;
    char    res6[3];
    uint8   memc_psrt;
    char    res7[3];
    uint8   memc_lurt;
    char    res8[3];
    uint8   memc_lsrt;
    char    res9[3];
    uint32  memc_immr;
    uint32  memc_pcibr0;
    uint32  memc_pcibr1;
    char    res10[16];
    uint32  memc_pcimsk0;
    uint32  memc_pcimsk1;
    char    res11[52];
};
typedef struct memctl8260_s memctl8260_t;

/* System Integration Timers.
*/
struct	sit8260_s 
{
    char    res1[32];
    uint16  sit_tmcntsc;
    char    res2[2];
    uint32  sit_tmcnt;
    char    res3[4];
    uint32  sit_tmcntal;
    char    res4[16];
    uint16  sit_piscr;
    char    res5[2];
    uint32  sit_pitc;
    uint32  sit_pitr;
    char    res6[94];
    char    res7[390];
};
typedef struct sit8260_s sit8260_t;

/* PCI
 */
struct pci8260_s 
{
    uint32  pci_omisr;
    uint32  pci_ominr;
    char    res1[8];
    uint32  pci_ifqpr;
    uint32  pci_ofqpr;
    char    res2[8];
    uint32  pci_imr0;
    uint32  pci_imr1;
    uint32  pci_omr0;
    uint32  pci_omr1;
    uint32  pci_odr;
    char    res3[4];
    uint32  pci_idr;
    char    res4[20];
    uint32  pci_imisr;
    uint32  pci_imimr;
    char    res5[24];
    uint32  pci_ifhpr;
    char    res5_2[4];
    uint32  pci_iftpr;
    char    res6[4];
    uint32  pci_iphpr;
    char    res6_2[4];
    uint32  pci_iptpr;
    char    res7[4];
    uint32  pci_ofhpr;
    char    res7_2[4];
    uint32  pci_oftpr;
    char    res8[4];
    uint32  pci_ophpr;
    char    res8_2[4];
    uint32  pci_optpr;
    char    res9[8];
    uint32  pci_mucr;
    char    res10[8];
    uint32  pci_qbar;
    char    res11[12];
    uint32  pci_dmamr0;
    uint32  pci_dmasr0;
    uint32  pci_dmacdar0;
    char    res12[4];
    uint32  pci_dmasar0;
    char    res13[4];
    uint32  pci_dmadar0;
    char    res14[4];
    uint32  pci_dmabcr0;
    uint32  pci_dmandar0;
    char    res15[88];
    uint32  pci_dmamr1;
    uint32  pci_dmasr1;
    uint32  pci_dmacdar1;
    char    res16[4];
    uint32  pci_dmasar1;
    char    res17[4];
    uint32  pci_dmadar1;
    char    res18[4];
    uint32  pci_dmabcr1;
    uint32  pci_dmandar1;
    char    res19[88];
    uint32  pci_dmamr2;
    uint32  pci_dmasr2;
    uint32  pci_dmacdar2;
    char    res20[4];
    uint32  pci_dmasar2;
    char    res21[4];
    uint32  pci_dmadar2;
    char    res22[4];
    uint32  pci_dmabcr2;
    uint32  pci_dmandar2;
    char    res23[88];
    uint32  pci_dmamr3;
    uint32  pci_dmasr3;
    uint32  pci_dmacdar3;
    char    res24[4];
    uint32  pci_dmasar3;
    char    res25[4];
    uint32  pci_dmadar3;
    char    res26[4];
    uint32  pci_dmabcr3;
    uint32  pci_dmandar3;
    char    res27[344];
    uint32  pci_potar0;
    char    res28[4];
    uint32  pci_pobar0;
    char    res29[4];
    uint32  pci_pocmr0;
    char    res30[4];
    uint32  pci_potar1;
    char    res31[4];
    uint32  pci_pobar1;
    char    res32[4];
    uint32  pci_pocmr1;
    char    res33[4];
    uint32  pci_potar2;
    char    res34[4];
    uint32  pci_pobar2;
    char    res35[4];
    uint32  pci_pocmr2;
    char    res36[52];
    uint32  pci_ptcr;
    uint32  pci_gpcr;
    uint32  pci_gcr;
    uint32  pci_esr;
    uint32  pci_emr;
    uint32  pci_ecr;
    uint32  pci_eacr;
    char    res37[4];
    uint32  pci_edcr;
    char    res38[4];
    uint32  pci_eccr;
    char    res39[44];
    uint32  pci_pitar1;
    char    res40[4];
    uint32  pci_pibar1;
    char    res41[4];
    uint32  pci_picmr1;
    char    res42[4];
    uint32  pci_pitar0;
    char    res43[4];
    uint32  pci_pibar0;
    char    res44[4];
    uint32  pci_picmr0;
    char    res45[4];
    uint32  pci_cfg_addr;
    uint32  pci_cfg_data;
    uint32  pci_int_ack;
    char    res46[756];
};
typedef struct pci8260_s pci8260_t;


/* Interrupt Controller.
*/
struct intctl8260_s
{
    uint16  ic_sicr;
    char    res1[2];
    uint32  ic_sivec;
    uint32  ic_sipnrh;
    uint32  ic_sipnrl;
    uint32  ic_siprr;
    uint32  ic_scprrh;
    uint32  ic_scprrl;
    uint32  ic_simrh;
    uint32  ic_simrl;
    uint32  ic_siexr;
    char    res2[88];
};
typedef struct intctl8260_s intctl8260_t;

/* Clocks and Reset.
*/
struct car8260_s 
{
    uint32  car_sccr;
    char    res1[4];
    uint32  car_scmr;
    char    res2[4];
    uint32  car_rsr;
    uint32  car_rmr;
    char    res[104];
};
typedef struct car8260_s car8260_t;

/* Input/Output Port control/status registers.
 * Names consistent with processor manual, although they are different
 * from the original 8xx names.......
 */
struct iop8260_s 
{
    uint32  iop_pdira;
    uint32  iop_ppara;
    uint32  iop_psora;
    uint32  iop_podra;
    uint32  iop_pdata;
    char    res1[12];
    uint32  iop_pdirb;
    uint32  iop_pparb;
    uint32  iop_psorb;
    uint32  iop_podrb;
    uint32  iop_pdatb;
    char    res2[12];
    uint32  iop_pdirc;
    uint32  iop_pparc;
    uint32  iop_psorc;
    uint32  iop_podrc;
    uint32  iop_pdatc;
    char    res3[12];
    uint32  iop_pdird;
    uint32  iop_ppard;
    uint32  iop_psord;
    uint32  iop_podrd;
    uint32  iop_pdatd;
    char    res4[12];
};
typedef struct iop8260_s iop8260_t;

union iop8260_union_s
{
    uint32 im_ioport_ram[32];
    iop8260_t im_ioport;
};
typedef union iop8260_union_s iop8260_union_t;


/* Communication Processor Module Timers
*/
struct cpmtimer8260_s 
{
    uint8   cpmt_tgcr1;
    char    res1[3];
    uint8   cpmt_tgcr2;
    char    res2[11];
    uint16  cpmt_tmr1;
    uint16  cpmt_tmr2;
    uint16  cpmt_trr1;
    uint16  cpmt_trr2;
    uint16  cpmt_tcr1;
    uint16  cpmt_tcr2;
    uint16  cpmt_tcn1;
    uint16  cpmt_tcn2;
    uint16  cpmt_tmr3;
    uint16  cpmt_tmr4;
    uint16  cpmt_trr3;
    uint16  cpmt_trr4;
    uint16  cpmt_tcr3;
    uint16  cpmt_tcr4;
    uint16  cpmt_tcn3;
    uint16  cpmt_tcn4;
    uint16  cpmt_ter1;
    uint16  cpmt_ter2;
    uint16  cpmt_ter3;
    uint16  cpmt_ter4;
    char    res3[584];
};
typedef struct cpmtimer8260_s cpmtimer8260_t;

/* DMA control/status registers.
*/

struct sdma8260_s 
{
    char    res0[24];
    uint8   sdma_sdsr;
    char    res1[3];
    uint8   sdma_sdmr;
    char    res2[3];
    uint8   sdma_idsr1;
    char    res3[3];
    uint8   sdma_idmr1;
    char    res4[3];
    uint8   sdma_idsr2;
    char    res5[3];
    uint8   sdma_idmr2;
    char    res6[3];
    uint8   sdma_idsr3;
    char    res7[3];
    uint8   sdma_idmr3;
    char    res8[3];
    uint8   sdma_idsr4;
    char    res9[3];
    uint8   sdma_idmr4;
    char	res10[707];
};
typedef struct sdma8260_s sdma8260_t;

/* Fast controllers
*/
struct fcc_s
{
    uint32  fcc_gfmr;
    uint32  fcc_fpsmr;
    uint16  fcc_ftodr;
    char    res1[2];
    uint16  fcc_fdsr;
    char    res2[2];
    uint16  fcc_fcce;
    char    res3[2];
    uint16  fcc_fccm;
    char    res4[2];
    uint8   fcc_fccs;
    char    res5[3];
    uint8   fcc_ftirr_phy[4];
};
typedef struct fcc_s fcc_t;

/* Fast controllers continued
 */
struct fcc_c_s 
{
    uint32  fcc_firper;
    uint32  fcc_firer;
    uint32  fcc_firsr_hi;
    uint32  fcc_firsr_lo;
    uint8   fcc_gfemr;
    char	res1[15];
} ;
typedef struct fcc_c_s fcc_c_t;

/* TC Layer
 */
struct tclayer_s 
{
    uint16  tc_tcmode;
    uint16  tc_cdsmr;
    uint16  tc_tcer;
    uint16  tc_rcc;
    uint16  tc_tcmr;
    uint16  tc_fcc;
    uint16  tc_ccc;
    uint16  tc_icc;
    uint16  tc_tcc;
    uint16  tc_ecc;
    char	res1[12];
};
typedef struct tclayer_s tclayer_t;

/* I2C
*/
struct i2c8260_s
{
    uint8   i2c_i2mod;
    char    res1[3];
    uint8   i2c_i2add;
    char    res2[3];
    uint8   i2c_i2brg;
    char    res3[3];
    uint8   i2c_i2com;
    char    res4[3];
    uint8   i2c_i2cer;
    char    res5[3];
    uint8   i2c_i2cmr;
    char    res6[331];
};
typedef struct i2c8260_s i2c8260_t;

struct scc_s
{   /* Serial communication channels */
    uint32  scc_gsmrl;
    uint32  scc_gsmrh;
    uint16  scc_psmr;
    char    res1[2];
    uint16  scc_todr;
    uint16  scc_dsr;
    uint16  scc_scce;
    char    res2[2];
    uint16  scc_sccm;
    char    res3;
    uint8   scc_sccs;
    char    res4[8];
} ;
typedef struct scc_s scc_t;

struct smc_s 
{   /* Serial management channels */
    char    res1[2];
    uint16  smc_smcmr;
    char    res2[2];
    uint8   smc_smce;
    char    res3[3];
    uint8   smc_smcm;
    char    res4[5];
} ;
typedef struct smc_s smc_t;

/* Serial Peripheral Interface.
*/
struct im_spi_s
{
    uint16  spi_spmode;
    char    res1[4];
    uint8   spi_spie;
    char    res2[3];
    uint8   spi_spim;
    char    res3[2];
    uint8   spi_spcom;
    char    res4[82];
} ;
typedef struct im_spi_s im_spi_t;

/* CPM Mux.
*/
struct cpmux_s
{
    uint8   cmx_si1cr;
    char    res1;
    uint8   cmx_si2cr;
    char    res2;
    uint32  cmx_fcr;
    uint32  cmx_scr;
    uint8   cmx_smr;
    char    res3;
    uint16  cmx_uar;
    char	res4[16];
} ;
typedef struct cpmux_s cpmux_t;

/* SIRAM control
*/
struct siramctl_s
{
    uint16  si_amr;
    uint16  si_bmr;
    uint16  si_cmr;
    uint16  si_dmr;
    uint8   si_gmr;
    char    res1;
    uint8   si_cmdr;
    char    res2;
    uint8   si_str;
    char    res3;
    uint16  si_rsr;
} ;
typedef struct siramctl_s siramctl_t;

struct mcc_s
{
    uint16  mcc_mcce;
    char    res1[2];
    uint16  mcc_mccm;
    char    res2[2];
    uint8   mcc_mccf;
    char    res3[7];
} ;
typedef struct mcc_s mcc_t;

struct cpm8260_s 
{
    uint32  cp_cpcr;
    uint32  cp_rccr;
    char    res1[14];
    uint16  cp_rter;
    char    res2[2];
    uint16  cp_rtmr;
    uint16  cp_rtscr;
    char    res3[2];
    uint32  cp_rtsr;
    char    res4[12];
} ;
typedef struct cpm8260_s cpm8260_t;

/* ...and the whole thing wrapped up....
*/
struct immap_s
{
    /* Some references are into the unique and known dpram spaces,
       others are from the generic base.
    */
#define im_dprambase	im_dpram1
    uint8   im_dpram1[16*1024];
    char    res1[16*1024];
    uint8   im_dpram2[4*1024];
    char    res2[8*1024];
    uint8   im_dpram3[4*1024];
    char    res3[16*1024];

    sysconf8260_t   im_siu_conf;    /* SIU Configuration */
    memctl8260_t    im_memctl;  /* Memory Controller */
    sit8260_t       im_sit;     /* System Integration Timers */
    pci8260_t       im_pci; /* PCI Configuration */
    intctl8260_t    im_intctl;  /* Interrupt Controller */
    car8260_t       im_clkrst;  /* Clocks and reset */
    iop8260_t       im_ioport;  /* IO Port control/status */
    cpmtimer8260_t  im_cpmtimer;    /* CPM timers */
    sdma8260_t      im_sdma;    /* SDMA control/status */

    fcc_t       im_fcc[3];  /* Three FCCs */

    char        res4[32];
    fcc_c_t     im_fcc_c[3];   /* Continued FCCs */
    char        res4a[32];

    tclayer_t   im_tclayer[8];  /* Eight TCLayers */
    uint16      tc_tcgsr;
    uint16      tc_tcger;

    /* First set of baud rate generators.*/
	char        res4b[236];
	uint32      im_brgc5;
	uint32      im_brgc6;
	uint32      im_brgc7;
	uint32      im_brgc8;

	char    res5[608];

	i2c8260_t   im_i2c; /* I2C control/status */
	cpm8260_t   im_cpm; /* Communication processor */

	/* Second set of baud rate generators.*/
    uint32  im_brgc1;
    uint32  im_brgc2;
    uint32  im_brgc3;
    uint32  im_brgc4;

    scc_t       im_scc[4];  /* Four SCCs */
    smc_t       im_smc[2];  /* Couple of SMCs */
    im_spi_t    im_spi;     /* A SPI */
    cpmux_t      im_cpmux;  /* CPM clock route mux */
    siramctl_t  im_siramctl1;   /* First SI RAM Control */
    mcc_t       im_mcc1;    /* First MCC */
    siramctl_t  im_siramctl2;   /* Second SI RAM Control */
    mcc_t       im_mcc2;    /* Second MCC */

    char        res6[1184];

    uint16      im_si1txram[256];
    char        res7[512];
    uint16      im_si1rxram[256];
    char        res8[512];
    uint16      im_si2txram[256];
    char        res9[512];
    uint16      im_si2rxram[256];
    char        res10[512];
    char        res11[4096];
} ;
typedef struct immap_s immap_t;


spi_handle_t *spi_create_handle(const spi_gen_t *spi_pgen);

#endif

