/****************************************************************************
* $Id$
*  octeon gpio spi implement
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jcao
* Date          : 2011-05-16
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
* Header Files
* 
****************************************************************************/
#include "sal_common.h"
#include "genlog.h"

#include "ctc_spi.h"
#include "spi_octeon_gpio.h"
#include "drv_debug.h"
#include "spi_err.h"

/****************************************************************************
 *
* Defines and Macros
* 
****************************************************************************/
#define SI_MASK  0x1
#define BIT_WIDTH_8  8


/****************************************************************************
 *
* Global and Declaration
* 
****************************************************************************/

/* for gpio operation safety, add mutex for read and write , each time only one spi device W/R can be excuted */

 sal_mutex_t *g_spi_octeon_gpio_mutex;
int32 octeon_gpio_fd;
/****************************************************************************
 *
* Function
* 
****************************************************************************/
static void spi_gpio_delay()
{ 
    volatile int32 loop = 0x10;
    while(loop--);
}


static int32 gpio_init(spi_gen_t  *spi_pgen)
{     
    DRV_CTC_CHK_PTR(spi_pgen);
    /*now do nothing*/    
    return SPI_SUCCESS;
}


static int spi_cs( int32 assert_data, spi_gen_t  *spi_pgen)
{    
    
    if (assert_data)
    {
        ioctl(octeon_gpio_fd, CTC_GPIO_WRITE, ((OCTEON_SPI_CS_GPIO & 0xff) | 0x10));  
    }           
    else
    {
        ioctl(octeon_gpio_fd, CTC_GPIO_WRITE, (OCTEON_SPI_CS_GPIO & 0xff));       
    }

    return SPI_SUCCESS;
}

static int spi_clk( int32 assert_clk, spi_gen_t  *spi_pgen)
{            
    if (assert_clk)
    {
        ioctl(octeon_gpio_fd, CTC_GPIO_WRITE, ((OCTEON_SPI_CLK_GPIO & 0xff) | 0x10));        
    }
    else
    {
        ioctl(octeon_gpio_fd, CTC_GPIO_WRITE, (OCTEON_SPI_CLK_GPIO & 0xff));  
    }

    return SPI_SUCCESS;
}

static int spi_data_out( int32 assert_data, spi_gen_t  *spi_pgen)
{            
    if (assert_data)
    {
        ioctl(octeon_gpio_fd, CTC_GPIO_WRITE, ((OCTEON_SPI_DO_GPIO & 0xff) | 0x10));        
    }
    else
    {
        ioctl(octeon_gpio_fd, CTC_GPIO_WRITE, (OCTEON_SPI_DO_GPIO & 0xff)); 
    }


    return SPI_SUCCESS;
}

static int spi_data_in(spi_gen_t  *spi_pgen)
{       
    int32 value = 0;
    value = OCTEON_SPI_DI_GPIO & 0xff;
    ioctl(octeon_gpio_fd, CTC_GPIO_READ, &value ); 
    return ((value >> 8)&0xff) ? 1 : 0;
}

/*********************************************************************
 * Name    : spi_octeon_gpio_close
 * Purpose :  free memory and pointer
 * Input   : spi_handle_t *phdl       - the handler of the spi bus
          
 * Output  : N/A
 * Return  : SPI_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
spi_octeon_gpio_close(spi_handle_t *phdl)
{      
    DRV_CTC_CHK_PTR(phdl);
    
    sal_mutex_destroy(g_spi_octeon_gpio_mutex);
        
    if (NULL != phdl->data)
    {
        DRV_FREE(CTCLIB_MEM_DRIVER_SPI_INFO, phdl->data);
        phdl->data = NULL;
    }
    DRV_FREE(CTCLIB_MEM_DRIVER_SPI_INFO, phdl);
    phdl = NULL;
    
    return SPI_SUCCESS;
}

static int32 spi_read(spi_gen_t *spi_pgen, uint16 addr, uint32 *val)
{
    uint32 i;
    uint32 alen ,len;
    
    DRV_CTC_CHK_PTR(spi_pgen);
    DRV_CTC_CHK_PTR(val);

    *val = 0x0;
    
    alen = spi_pgen->alen;
    len = spi_pgen->len;
    
    spi_cs (0, spi_pgen);
    
    for (i = 0; i < alen * BIT_WIDTH_8; i++ )
    {
        //clk(0);
        spi_clk(0, spi_pgen);        
        spi_gpio_delay();
        
        if(addr&(SI_MASK<<(alen*BIT_WIDTH_8-1)))
        {
            //date_out(1);
            spi_data_out(1, spi_pgen);
            spi_gpio_delay();
        }
        else
        {
            //date_out(0);
            spi_data_out(0, spi_pgen);
            spi_gpio_delay();
        }
        //clk(1);
        spi_clk(1, spi_pgen);
        spi_gpio_delay();
        addr <<= 1;
    }/*write  addr*/
    for (i=0; i<len*BIT_WIDTH_8; i++)
    {
        //clk(0);
        spi_clk(0, spi_pgen);        
        spi_gpio_delay();
        
        *val <<= 1;
        
        //if(*di_addr)
        if(spi_data_in(spi_pgen))
        {
            *val |= 0x1; 
            spi_gpio_delay();
        }
        else
        {
            *val &= (~0x1);
            spi_gpio_delay();
        }
        //clk(1);
         spi_clk(1, spi_pgen);
        spi_gpio_delay();      
    }/*read value*/
    
    //*en_addr = ~0x0;
    spi_cs(1, spi_pgen);
    
    return SPI_SUCCESS;
}

static int spi_write(spi_gen_t *spi_pgen, uint16 addr, uint32 val)
{
    uint32 i;
    uint32 tmp;
    uint32 alen ,len;

    DRV_CTC_CHK_PTR(spi_pgen);

    alen = spi_pgen->alen;
    len = spi_pgen->len;
    
    tmp = val;

    //*en_addr = 0x0;
    spi_cs(0, spi_pgen);
   
    for (i=0; i<alen*BIT_WIDTH_8; i++)
    {
        //clk(0);        
       
        spi_clk(0, spi_pgen);        
        spi_gpio_delay();
        
        if((addr)&(SI_MASK<<(alen*BIT_WIDTH_8-1)))
        {
            //date_out(1);
            spi_data_out(1, spi_pgen);
            spi_gpio_delay();
        }
        else
        {
            //date_out(0);
            spi_data_out(0, spi_pgen);
            spi_gpio_delay();
        }
        
        //clk(1);
        spi_clk(1, spi_pgen);        
        spi_gpio_delay();
        
        addr <<= 1;
    }/*write  addr*/   

    for (i=0; i<len*BIT_WIDTH_8; i++)
    {
        //clk(0);
        spi_clk(0, spi_pgen);
        
        spi_gpio_delay();
        
        if(tmp&(SI_MASK<<(len*BIT_WIDTH_8-1)))
        {
            //date_out(1);
            spi_data_out(1, spi_pgen);
            spi_gpio_delay();
        }
        else
        {
            //date_out(0);
            spi_data_out(0, spi_pgen);
            spi_gpio_delay();
        }
        
        //clk(1);
        spi_clk(1, spi_pgen);
        spi_gpio_delay();
        tmp <<= 1;
    }/*write value*/
    
    //*en_addr = ~0x0;
    spi_cs(1, spi_pgen);
    
    return SPI_SUCCESS;
}

/*********************************************************************
 * Name    : spi_octeon_gpio_read
 * Purpose :  read spi bus
 * Input   : const spi_handle_t *phdl       - the handler of the spi bus
          spi_op_para_t *ppara     - some info about spi bus layer operation
                                       
 * Output  : N/A
 * Return  : SPI_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
spi_octeon_gpio_read(const spi_handle_t *phdl, spi_op_para_t *ppara)
{
    spi_gen_t *spi_pgen = NULL;
    int32 ret;
       
    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(ppara);
    
    spi_pgen = (spi_gen_t *)phdl->data;

     /* for gpio operation safety, add read and write mutex, each time only one spi device W/R can be excuted */
    sal_mutex_lock (g_spi_octeon_gpio_mutex);        
    ret = spi_read(spi_pgen, ppara->addr, ppara->val);
    sal_mutex_unlock (g_spi_octeon_gpio_mutex);
    
    return ret;
}

/*********************************************************************
 * Name    : spi_octeon_gpio_write
 * Purpose :  write spi bus
 * Input   : const spi_handle_t *phdl       - the handler of the spi bus
          spi_op_para_t *ppara     - some info about spi bus layer operation
                                       
 * Output  : N/A
 * Return  : SPI_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
spi_octeon_gpio_write(const spi_handle_t *phdl, spi_op_para_t *ppara)
{
    spi_gen_t *spi_pgen = NULL;    
    int32 ret;

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(ppara);
    
    spi_pgen = (spi_gen_t *)phdl->data;

     /* for gpio operation safety, add read and write mutex, each time only one spi device W/R can be excuted */
    sal_mutex_lock (g_spi_octeon_gpio_mutex);        
    ret = spi_write(spi_pgen, ppara->addr, *(ppara->val));
    sal_mutex_unlock (g_spi_octeon_gpio_mutex);
    
    return ret;    
}

/*********************************************************************
 * Name    : spi_octeon_gpio_create_handle
 * Purpose :  create low level I/O handle
 * Input   : const spi_gen_t *spi_info     - some info about the spi bus implement
 
 * Output  : N/A
 * Return  : spi bus handle
           
 * Note    : N/A
*********************************************************************/

spi_handle_t *spi_octeon_gpio_create_handle(const spi_gen_t *spi_info)
{
    spi_handle_t *phdl = NULL;    
    spi_gen_t  *spi_pgen;
       
    phdl = (spi_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_SPI_INFO ,sizeof(spi_handle_t));
    if (NULL == phdl)
    {
        DRV_LOG_ERR( "spi_octeon_gpio_create_handle spi handle null pointer!\n");
        goto err_out;
    }

    phdl->data = (spi_gen_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_SPI_INFO ,sizeof(spi_gen_t));
    if (NULL == phdl->data)
    {
        DRV_LOG_ERR( "spi_octeon_gpio_create_handle spi handle data null pointer!\n");
        goto err_out;
    }

    sal_memcpy((int8 *)phdl->data, (int8 *)spi_info, sizeof(spi_gen_t));
    spi_pgen = ((spi_gen_t *)phdl->data);
    
    sal_mutex_create(&g_spi_octeon_gpio_mutex);
    
    octeon_gpio_fd = spi_pgen->spi_info.spi_octeon_gpio_info.fd;
    
    gpio_init(spi_pgen);
    
    phdl->close = spi_octeon_gpio_close;
    phdl->read = spi_octeon_gpio_read;
    phdl->write = spi_octeon_gpio_write;
   
    return phdl;
    
err_out:
    if (NULL != phdl)
    {
        sal_mutex_destroy(g_spi_octeon_gpio_mutex);
        
        if (NULL != phdl->data)
        {
            DRV_FREE(CTCLIB_MEM_DRIVER_SPI_INFO,phdl->data);
            phdl->data = NULL;
        }
        DRV_FREE(CTCLIB_MEM_DRIVER_SPI_INFO,phdl);
        phdl = NULL;
    }

    return NULL;
}

