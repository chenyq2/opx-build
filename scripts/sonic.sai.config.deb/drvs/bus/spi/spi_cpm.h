/****************************************************************************
* $Id$
*  The header file of the SPI driver implemented by SPI controller in CPM.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jcao
* Date          : 2010-08-04 
* Reason        : First Create.
****************************************************************************/
#ifndef __SPI_CPM_H__
#define __SPI_CPM_H__

/* CPM Command register.
*/
#define CPM_CR_RST  ((uint32)0x80000000)
#define CPM_CR_PAGE ((uint32)0x7c000000)
#define CPM_CR_SBLOCK   ((uint32)0x03e00000)
#define CPM_CR_FLG  ((uint32)0x00010000)
#define CPM_CR_MCN  ((uint32)0x00003fc0)
#define CPM_CR_OPCODE   ((uint32)0x0000000f)

/* Device sub-block and page codes.
*/
#define CPM_CR_SCC1_SBLOCK  (0x04)
#define CPM_CR_SCC2_SBLOCK  (0x05)
#define CPM_CR_SCC3_SBLOCK  (0x06)
#define CPM_CR_SCC4_SBLOCK  (0x07)
#define CPM_CR_SMC1_SBLOCK  (0x08)
#define CPM_CR_SMC2_SBLOCK  (0x09)
#define CPM_CR_SPI_SBLOCK   (0x0a)
#define CPM_CR_I2C_SBLOCK   (0x0b)
#define CPM_CR_TIMER_SBLOCK (0x0f)
#define CPM_CR_RAND_SBLOCK  (0x0e)
#define CPM_CR_FCC1_SBLOCK  (0x10)
#define CPM_CR_FCC2_SBLOCK  (0x11)
#define CPM_CR_FCC3_SBLOCK  (0x12)
#define CPM_CR_IDMA1_SBLOCK (0x14)
#define CPM_CR_IDMA2_SBLOCK (0x15)
#define CPM_CR_IDMA3_SBLOCK (0x16)
#define CPM_CR_IDMA4_SBLOCK (0x17)
#define CPM_CR_MCC1_SBLOCK  (0x1c)

#define CPM_CR_SCC1_PAGE    (0x00)
#define CPM_CR_SCC2_PAGE    (0x01)
#define CPM_CR_SCC3_PAGE    (0x02)
#define CPM_CR_SCC4_PAGE    (0x03)
#define CPM_CR_SMC1_PAGE    (0x07)
#define CPM_CR_SMC2_PAGE    (0x08)
#define CPM_CR_SPI_PAGE     (0x09)
#define CPM_CR_I2C_PAGE     (0x0a)
#define CPM_CR_TIMER_PAGE   (0x0a)
#define CPM_CR_RAND_PAGE    (0x0a)
#define CPM_CR_FCC1_PAGE    (0x04)
#define CPM_CR_FCC2_PAGE    (0x05)
#define CPM_CR_FCC3_PAGE    (0x06)
#define CPM_CR_IDMA1_PAGE   (0x07)
#define CPM_CR_IDMA2_PAGE   (0x08)
#define CPM_CR_IDMA3_PAGE   (0x09)
#define CPM_CR_IDMA4_PAGE   (0x0a)
#define CPM_CR_MCC1_PAGE    (0x07)
#define CPM_CR_MCC2_PAGE    (0x08)

/* Some opcodes (there are more...later)
*/
#define CPM_CR_INIT_TRX     ((uint16)0x0000)
#define CPM_CR_INIT_RX      ((uint16)0x0001)
#define CPM_CR_INIT_TX      ((uint16)0x0002)
#define CPM_CR_HUNT_MODE    ((uint16)0x0003)
#define CPM_CR_STOP_TX      ((uint16)0x0004)
#define CPM_CR_RESTART_TX   ((uint16)0x0006)
#define CPM_CR_SET_GADDR    ((uint16)0x0008)

#define mk_cr_cmd(PG, SBC, MCN, OP) \
    ((PG << 26) | (SBC << 21) | (MCN << 6) | OP)


#define PROFF_SCC1      ((uint32)0x8000)
#define PROFF_SCC2      ((uint32)0x8100)
#define PROFF_SCC3      ((uint32)0x8200)
#define PROFF_SCC4      ((uint32)0x8300)
#define PROFF_FCC1      ((uint32)0x8400)
#define PROFF_FCC2      ((uint32)0x8500)
#define PROFF_FCC3      ((uint32)0x8600)
#define PROFF_MCC1      ((uint32)0x8700)
#define PROFF_SMC1_BASE     ((uint32)0x87fc)
#define PROFF_IDMA1_BASE    ((uint32)0x87fe)
#define PROFF_MCC2      ((uint32)0x8800)
#define PROFF_SMC2_BASE ((uint32)0x88fc)
#define PROFF_IDMA2_BASE    ((uint32)0x88fe)
#define PROFF_SPI_BASE  ((uint32)0x89fc)
#define PROFF_IDMA3_BASE    ((uint32)0x89fe)
#define PROFF_TIMERS    ((uint32)0x8ae0)
#define PROFF_REVNUM    ((uint32)0x8af0)
#define PROFF_RAND      ((uint32)0x8af8)
#define PROFF_I2C_BASE      ((uint32)0x8afc)
#define PROFF_IDMA4_BASE    ((uint32)0x8afe)


/* The SMCs are relocated to any of the first eight DPRAM pages.
 * We will fix these at the first locations of DPRAM, until we
 * get some microcode patches :-).
 * The parameter ram space for the SMCs is fifty-some bytes, and
 * they are required to start on a 64 byte boundary.
 */
#define PROFF_SMC1  (0)
#define PROFF_SMC2  (64)
#define PROFF_SPI   ((16*1024) - 128)

#define BD_SC_EMPTY ((uint16)0x8000)    /* Recieve is empty */
#define BD_SC_READY ((uint16)0x8000)    /* Transmit is ready */
#define BD_SC_WRAP  ((uint16)0x2000)    /* Last buffer descriptor */
#define BD_SC_INTRPT    ((uint16)0x1000)    /* Interrupt on change */
#define BD_SC_LAST  ((uint16)0x0800)    /* Last buffer in frame */
#define BD_SC_CM    ((uint16)0x0200)    /* Continous mode */
#define BD_SC_ID    ((uint16)0x0100)    /* Rec'd too many idles */
#define BD_SC_P     ((uint16)0x0100)    /* xmt preamble */
#define BD_SC_BR    ((uint16)0x0020)    /* Break received */
#define BD_SC_FR    ((uint16)0x0010)    /* Framing error */
#define BD_SC_PR    ((uint16)0x0008)    /* Parity error */
#define BD_SC_OV    ((uint16)0x0002)    /* Overrun */
#define BD_SC_CD    ((uint16)0x0001)    /* ?? */


/* Function code bits, usually generic to devices.
*/
#define CPMFCR_GBL  ((uint8)0x20)	/* Set memory snooping */
#define CPMFCR_EB   ((uint8)0x10)	/* Set big endian byte order */
#define CPMFCR_TC2  ((uint8)0x04)	/* Transfer code 2 value */
#define CPMFCR_DTB  ((uint8)0x02)	/* Use local bus for data when set */
#define CPMFCR_BDB  ((uint8)0x01)	/* Use local bus for BD when set */



/* SPI parameter RAM.
*/
typedef struct spi {
    uint16  spi_rbase;  /* Rx Buffer descriptor base address */
    uint16  spi_tbase;  /* Tx Buffer descriptor base address */
    uint8  spi_rfcr;   /* Rx function code */
    uint8  spi_tfcr;   /* Tx function code */
    uint16  spi_mrblr;  /* Max receive buffer length */
    uint    spi_rstate; /* Internal */
    uint    spi_rdp;    /* Internal */
    uint16  spi_rbptr;  /* Internal */
    uint16  spi_rbc;    /* Internal */
    uint    spi_rxtmp;  /* Internal */
    uint    spi_tstate; /* Internal */
    uint    spi_tdp;    /* Internal */
    uint16  spi_tbptr;  /* Internal */
    uint16  spi_tbc;    /* Internal */
    uint    spi_txtmp;  /* Internal */
    uint    spi_res;    /* Tx temp. */
    uint    spi_res1[4];    /* SDMA temp. */
} spi_t;

/* Buffer descriptors used by many of the CPM protocols.
*/
typedef struct cpm_buf_desc {
	uint16  cbd_sc;     /* Status and Control */
	uint16  cbd_datlen;	/* Data length in buffer */
	uint    cbd_bufaddr;	/* Buffer address in host memory */
} cbd_t;


/* SPI Mode register.
*/
#define SPMODE_LOOP     ((uint16)0x4000)	/* Loopback */
#define SPMODE_CI       ((uint16)0x2000)	/* Clock Invert */
#define SPMODE_CP       ((uint16)0x1000)	/* Clock Phase */
#define SPMODE_DIV16    ((uint16)0x0800)	/* BRG/16 mode */
#define SPMODE_REV      ((uint16)0x0400)	/* Reversed Data */
#define SPMODE_MSTR     ((uint16)0x0200)	/* SPI Master */
#define SPMODE_EN       ((uint16)0x0100)	/* Enable */
#define SPMODE_LENMSK       ((uint16)0x00f0)	/* character length */
#define SPMODE_PMMSK        ((uint16)0x000f)	/* prescale modulus */

#define SPMODE_LEN(x)       ((((x)-1)&0xF)<<4)
#define SPMODE_PM(x)        ((x) &0xF)

/* SPI Event/Mask register.
*/
#define SPI_EMASK   0x37    /* Event Mask				*/
#define SPI_MME     0x20    /* Multi-Master Error			*/
#define SPI_TXE     0x10    /* Transmit Error			*/
#define SPI_BSY     0x04    /* Busy					*/
#define SPI_TXB     0x02    /* Tx Buffer Empty			*/
#define SPI_RXB     0x01    /* RX Buffer full/closed		*/

#define SPI_STR     0x80    /* SPCOM: Start transmit		*/

#define SPI_EB      ((uint8)0x10)  /* big endian byte order */

#define BD_IIC_START        ((uint16)0x0400)


spi_handle_t *spi_cpm_create_handle(const spi_gen_t *spi_info);

#endif

