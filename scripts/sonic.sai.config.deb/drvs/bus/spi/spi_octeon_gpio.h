/****************************************************************************
* $Id$
*  SPI common defines
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jcao
* Date          : 2011-05-16 
* Reason        : First Create.
****************************************************************************/
#ifndef __SPI_OCTEON_GPIO_DRV__
#define __SPI_OCTEON_GPIO_DRV__

#define CTC_GPIO_READ        15
#define CTC_GPIO_WRITE       16
#define CTC_GPIO_GPIO_INIT   17

spi_handle_t *spi_octeon_gpio_create_handle(const spi_gen_t *spi_info);


#endif


