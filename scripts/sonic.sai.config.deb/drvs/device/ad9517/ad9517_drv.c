/****************************************************************************
 * ad9517_drv.c   ad9517 access interface
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jcao
 * Date:         2010-08-04.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "ctc_spi.h"
#include "drv_debug.h"
#include "ad9517_drv.h"
#include "ad9517_err.h"


/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
static ad9517_handle_t* ad9517_spi_create_handle();
static ad9517_handle_t* ad9517_spi_register(spi_gen_t* spi_pgen);

/****************************************************************************
 *
* Functions  
*
****************************************************************************/
/*********************************************************************
 * Name    : ad9517_spi_close
 * Purpose :  free memory and pointer
 * Input   : ad9517_handle_t *phdl       - the handler of the ad9517
          
 * Output  : N/A
 * Return  : AD9517_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ad9517_spi_close(ad9517_handle_t* phdl)
{
    spi_handle_t* spi_phdl = NULL;
    int32 ret = 0;

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(phdl->handle);
    
    spi_phdl = (spi_handle_t*)phdl->handle;
    ret = spi_phdl->close(spi_phdl);

    DRV_FREE( CTCLIB_MEM_DRIVER_AD9517_INFO, phdl);
    phdl = NULL;

    return ret;
}

/*********************************************************************
 * Name    : ad9517_spi_write
 * Purpose :  write a spi type ad9517 register
 * Input   : const ad9517_handle_t *phdl       - the handler of the ad9517
          ad9517_access_t *paccess     - some info pass to spi bus layer
                                       
 * Output  : N/A
 * Return  : AD9517_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ad9517_spi_write(const ad9517_handle_t* phdl, ad9517_access_t* paccess)
{
    spi_handle_t* spi_phdl = NULL;
    spi_op_para_t spi_para;

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(paccess);
    
    spi_phdl = (spi_handle_t *)phdl->handle;
    
    spi_para.addr= (paccess->addr) | (AD_SPI_WIDTH_1<<13) | (AD_SPI_WRITE<<15);//from AD9517 DATASHEET
    spi_para.val = paccess->val;    

    DRV_LOG_DEBUG(clkgen, DRV_CLK_GEN_WRITE, "ad9517_spi_write addr %d, val pointer %p",
                            spi_para.addr, spi_para.val);
    
    return spi_phdl->write(spi_phdl, &spi_para);
}

/*********************************************************************
 * Name    : ad9517_spi_read
 * Purpose :  read a spi type ad9517 register
 * Input   : const ad9517_handle_t *phdl       - the handler of the ad9517
          ad9517_access_t *paccess     - some info pass to spi bus layer
                                       
 * Output  : N/A
 * Return  : AD9517_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ad9517_spi_read(const ad9517_handle_t* phdl, ad9517_access_t* paccess)
{
    spi_handle_t* spi_phdl = NULL;
    spi_op_para_t spi_para;    

    DRV_CTC_CHK_PTR(phdl);
    DRV_CTC_CHK_PTR(paccess);
    
    spi_phdl = (spi_handle_t *)phdl->handle;
      
    spi_para.addr= (paccess->addr) | (AD_SPI_WIDTH_1<<13) | (AD_SPI_READ<<15);//from AD9517 DATASHEET    
    spi_para.val = paccess->val;

    DRV_LOG_DEBUG(clkgen, DRV_CLK_GEN_WRITE,"ad9517_spi_read addr %d, val pointer %p",
                            spi_para.addr, spi_para.val);    
    
    return spi_phdl->read(spi_phdl, &spi_para);
}

/*********************************************************************
 * Name    : ad9517_spi_create_handle
 * Purpose :  create a ad9517 device handler
 * Input   : spi_handle_t *spi_phdl       - the handler of the spi bus layer          
                                       
 * Output  : N/A
 * Return  : the handler of the ad9517
          
 * Note    : N/A
*********************************************************************/

static ad9517_handle_t*
ad9517_spi_create_handle(spi_handle_t* spi_phdl)
{
    ad9517_handle_t* phdl = NULL; 
    
    DRV_CTC_CHK_PTR_NULL(spi_phdl);
    
    phdl = (ad9517_handle_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_AD9517_INFO,sizeof(ad9517_handle_t));

    if (NULL == phdl)
    {
        goto err_out;
    }

    phdl->handle = (void *)spi_phdl;

    phdl->close = ad9517_spi_close;
    phdl->read = ad9517_spi_read;
    phdl->write = ad9517_spi_write;
    
    return phdl;
    
err_out:
    if (NULL != phdl)
    {
        DRV_FREE( CTCLIB_MEM_DRIVER_AD9517_INFO,phdl);
        phdl = NULL;
    }

    return NULL;
}

/*********************************************************************
 * Name    : ad9517_spi_register
 * Purpose :  register spi type ad9517
 * Input   : spi_gen_t *spi_pgen      - some info about the way of ad9517'spi bus implement, 
                                        such as gpio, fpga etc
                                       
 * Output  : N/A
 * Return  : the handler of the ad9517
          
 * Note    : N/A
*********************************************************************/

static ad9517_handle_t*
ad9517_spi_register(spi_gen_t* spi_pgen)
{
    spi_handle_t* spi_phdl = NULL;
    
    /* the spi ad9517 */
  
    spi_pgen->alen = AD9517_ADDRESS_LENTH;
    spi_pgen->len = AD9517_DATA_LENTH;
    
    spi_phdl = spi_create_handle(spi_pgen);

    return ad9517_spi_create_handle(spi_phdl);      
}


/*********************************************************************
 * Name    : ad9517_register
 * Purpose :  register a ad9517 device handler
 * Input   : const void *pgen        - some info about the way of ad9517'spi bus implement, 
                                       such as gpio, fpga etc
          ad9517_type_t type         - the type of accessing ad9517, now just have one type ad9517
          
 * Output  : N/A
 * Return  : the handler of the ad9517
           
 * Note    : N/A
*********************************************************************/

ad9517_handle_t*
ad9517_register(ad9517_type_t type, const void* pgen)
{       
    spi_gen_t* spi_pgen = (spi_gen_t*)pgen;
    
    DRV_CTC_CHK_PTR_NULL(pgen);
    
    switch(type)
    {
        case E_AD9517_SPI:           
            return ad9517_spi_register(spi_pgen);

        default:
            break;        
    }
    
    return NULL;
}


