/****************************************************************************
* $Id$
*  The header file of the ad9517 operation.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jcao
* Date          : 2010-08-04 
* Reason        : First Create.
****************************************************************************/
#ifndef __AD9517_DRV__
#define __AD9517_DRV__

#include "ctc_spi.h"


#define AD9517_DATA_LENTH 1    /* data length (byte)*/  
#define AD9517_ADDRESS_LENTH 2  /* address length (byte)*/ 

#define AD_SPI_READ  0x1
#define AD_SPI_WRITE 0x0
#define AD_SPI_WIDTH_1 0x0
#define AD_SPI_WIDTH_2 0x1
#define AD_SPI_WIDTH_3 0x2
#define AD_SPI_STREAM  0x3


#define AD_VCO_CAL_FINISHED 0x6
#define AD_DIGITAL_LOCK     0x0


typedef enum
{
    E_AD9517_SPI = 0,        /* access the AD9517 by SPI bus */
} ad9517_type_t;


struct ad9517_access_s{
    uint16 addr;             /* ad9517 register address */ 
    uint32  *val;             /* pointer of the value buffur */
} ;
typedef struct ad9517_access_s ad9517_access_t;



typedef struct ad9517_handle_s ad9517_handle_t;
struct ad9517_handle_s
{
    uint32 index;
    int32 (*close)(ad9517_handle_t *);
    int32 (*read)(const ad9517_handle_t *, ad9517_access_t *);
    int32 (*write)(const ad9517_handle_t *, ad9517_access_t *);
    void *handle;  /*handle of the low level operations */
};



ad9517_handle_t *ad9517_register(ad9517_type_t type, const void *pgen);

#endif 

