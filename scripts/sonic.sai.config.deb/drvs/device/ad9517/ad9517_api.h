/****************************************************************************
* $Id$
*  The header file of the ad9517 api.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jcao
* Date          : 2010-08-04 
* Reason        : First Create.
****************************************************************************/
#ifndef __AD9517_API_H__
#define __AD9517_API_H__

#include "ctc_spi.h"

typedef enum
{
    /*
            OUT0    OUT1    OUT2    OUT3    OUT4    OUT5    OUT6    OUT7
    TYPE_0  62.5    NO      62.5    NO      NO      NO      25      25    
    TYPE_1  156.25  156.25  156.25  NO      62.5    62.5    NO      50
    TYPE_2  156.25  NO      NO      NO      50      NO      25      NO
    TYPE_3  156.25  NO      156.25  156.25  62.5    62.5    NO      50         
    */
    E_AD9517_CLOCK_TYPE_0 = 0,        
    E_AD9517_CLOCK_TYPE_1 ,          
    E_AD9517_CLOCK_TYPE_2 ,          
    E_AD9517_CLOCK_TYPE_3 ,           
} ad9517_clock_type_e;

#define AD9517_NUM   0x1

#define AD9517_SPI_DO_BIT       0x4000                  /*PD17*/
#define AD9517_SPI_DI_BIT       0x8000                  /*PD16*/
#define AD9517_SPI_CLK_BIT      0x2000                  /*PD18*/
#define AD9517_SPI_CS_BIT       0x40                    /*PD25*/



int32 ad9517_read(uint32 idx, uint16 addr, uint32  *val);
int32 ad9517_write(uint32 idx, uint16 addr, uint32  val);
int32 ad9517_close(uint32 idx);
int32 ad9517_init(spi_gen_t *spi_gen, uint32 num, uint32 flag);

#endif 

