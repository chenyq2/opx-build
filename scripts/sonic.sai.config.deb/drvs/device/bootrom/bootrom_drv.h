#ifndef __BOOTROM_DRV_H__
#define __BOOTROM_DRV_H__

int update_bootrom(char* src_file, uint8 bootrom_type);

#endif /* __BOOTROM_DRV_H__ */

