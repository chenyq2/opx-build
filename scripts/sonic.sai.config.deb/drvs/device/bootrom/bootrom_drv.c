#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>      
#include "genlog.h"
#include "drv_debug.h"
#include "ctclib_crc.h"
#include "ctclib_sys_cmd.h"

#include "glb_hw_define.h"
typedef enum
{
    E_CPU_P1010,
    E_CPU_P1014,    
}E_CPU_TYPE;


int check_boot_bin(char* src_file, uint8 type)
{
    FILE* fd;
    int ret, file_len;
    char buffend[21];
    char* buff;
    uint32 crc, store_crc;
    struct stat stat_buf;

    if(!sal_stat(src_file, &stat_buf))
    {
        file_len = stat_buf.st_size;
    }
    else
    {
        DRV_LOG_ERR("Get src file stat failed!\n");
        return -1;
    }
    /* Modified by liuht for bug 25654, 2013-11-08 */	
    if(file_len < 0x80000)
    {
        DRV_LOG_ERR("Boot src file length is error!\n");
        return -1;
    }
    
    fd = sal_fopen(src_file, "r");
    if(fd == NULL) 
    {
        DRV_LOG_ERR("Open boot src file failed!\n");
        return -1;
    }
    sal_fseek(fd, -16, SEEK_END);
    ret = sal_fread(buffend, 1, 16, fd);
    if(ret != 16) 
    {        
        DRV_LOG_ERR("read file descriptor error, ret %d\n", ret);
        goto ERROR;
    }
    
    /* Added by liuht for bug44055, 2017-0601 */
    /*CPU type check. */
    if(E_BOOTROM_TYPE_512K == type)
    {
        if(0 != sal_strncmp(buffend, "p101xcrc", 8))
        {
            DRV_LOG_ERR("Wrong bootrom version for bootrom type 512k.\n");
            goto ERROR;
        }
    }
    else if(E_BOOTROM_TYPE_4M== type)
    {
        if(0 != sal_strncmp(buffend, "p1010crc", 8))
        {
            DRV_LOG_ERR("Wrong bootrom version for bootrom type 4M.\n");
            goto ERROR;
        }
    }
    else
    {
        DRV_LOG_ERR("Unknow bootrom type.\n");
        goto ERROR;
    }

    sal_fseek(fd, 0, SEEK_SET);
    buff = sal_malloc(file_len);
    if(buff == NULL)
    {
        DRV_LOG_ERR("Malloc memory to calculate crc failed!\n");
        goto ERROR;
    }
    ret = sal_fread(buff, 1, file_len-16, fd);
    if(ret != (file_len-16))
    {
        sal_free(buff);
        DRV_LOG_ERR("Read file length error!ret %d length %d\n",ret, file_len-16);
        goto ERROR;
    }
    /*CRC checksum check. */    
    /*last checkinfo not in crc calculate.*/
    crc = ctclib_gen_crc32(0, buff, file_len-16);    
    store_crc = (((uint8)buffend[11])<<24)+(((uint8)buffend[10])<<16)+(((uint8)buffend[9])<<8)+((uint8)buffend[8]);
    if(crc != store_crc)
    {
        sal_free(buff);
        DRV_LOG_ERR("Crc check failed.\n");
        goto ERROR;
    }
    sal_fclose(fd);
    sal_free(buff);
    return 0;
ERROR:
    sal_fclose(fd);
    return -1;
}

static int check_hi3535_boot_bin(char* src_file)
{
    FILE* fd;
    int ret, file_len;
    char buffend[21];
    char* buff;
    uint32 crc, store_crc;
    struct stat stat_buf;

    if(!sal_stat(src_file, &stat_buf))
    {
        file_len = stat_buf.st_size;
    }
    else
    {
        DRV_LOG_ERR("Get src file stat failed!\n");
        return -1;
    }
    
    fd = sal_fopen(src_file, "r");
    if(fd == NULL) 
    {
        DRV_LOG_ERR("Open boot src file failed!\n");
        return -1;
    }
    sal_fseek(fd, -13, SEEK_END);
    ret = sal_fread(buffend, 1, 13, fd);
    if(ret != 13) 
    {        
        DRV_LOG_ERR("read file descriptor error, ret %d\n", ret);
        goto ERROR;
    }
    if(0 != sal_strncmp(buffend, "hi3535crc", 9))
    {
        DRV_LOG_ERR("Wrong bootrom version.\n");
        goto ERROR;
    }

    sal_fseek(fd, 0, SEEK_SET);
    buff = sal_malloc(file_len);
    if(buff == NULL)
    {
        DRV_LOG_ERR("Malloc memory to calculate crc failed!\n");
        goto ERROR;
    }
    ret = sal_fread(buff, 1, file_len-13, fd);
    if(ret != (file_len-13))
    {
        sal_free(buff);
        DRV_LOG_ERR("Read file length error!ret %d length %d\n",ret, file_len-13);
        goto ERROR;
    }
    /*CRC checksum check. */    
    /*last checkinfo not in crc calculate.*/
    crc = ctclib_gen_crc32(0, buff, file_len-13);    
    store_crc = (((uint8)buffend[12])<<24)+(((uint8)buffend[11])<<16)+(((uint8)buffend[10])<<8)+((uint8)buffend[9]);
    if(crc != store_crc)
    {
        sal_free(buff);
        DRV_LOG_ERR("Crc check failed.\n");
        goto ERROR;
    }
    sal_fclose(fd);
    sal_free(buff);
    return 0;
ERROR:
    sal_fclose(fd);
    return -1;
}

static int update_bootrom_in_flash(char* src_file, uint8 bootrom_type)
{
    char sys_cmd[256];
    struct stat stat_buf;
    int ret = 0;

#ifdef _CTC_ARM_HI3535_
    if( check_hi3535_boot_bin(src_file) != 0)
#else
    if( check_boot_bin(src_file, bootrom_type) != 0)
#endif
    {
        DRV_LOG_ERR("check bootrom bin failed\n");
        return -1;
    }
    sal_memset(sys_cmd, 0, sizeof(sys_cmd));
    if (!sal_stat(src_file, &stat_buf))
    {
        if (!S_ISREG (stat_buf.st_mode))
        {
            DRV_LOG_ERR("Bootrom image is not existed!\n");
            return -1;
        }
    }

    sal_sprintf(sys_cmd, "flashcp %s /dev/mtd0", src_file);
    //ret = system(sys_cmd);
    ret = ctclib_reconstruct_system_cmd_chld_clone(ctclib_reconstruct_system_cmd_exec_str, (void*)sys_cmd);

    return ret;
}

int update_bootrom(char* src_file, uint8 bootrom_type)
{
    if(src_file == NULL)
    {
        DRV_LOG_ERR("Uboot bin file name is NULL!\n");
        return -1;
    }

    return update_bootrom_in_flash(src_file, bootrom_type);

}

