/****************************************************************************
 * led_api.c    led api 
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       zhuj
 * Date:         2010-09-21.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "ctclib_debug.h"
#include "drv_debug.h"
#include "led_drv.h"
#include "led_api.h"
#include "ctc_api.h"
#include "ctc_chip.h"
/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/


/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
/* led handler */
static led_handle_t *g_p_led_hdl[E_MAX_LED];
static mac_led_info_t* g_p_mac_led_info=NULL;
static mac_led_api_para_t* g_p_port_led_slice0 = NULL;
static mac_led_api_para_t* g_p_port_led_slice1 = NULL;
static uint8 g_mac_table_id=0;
static uint8 g_mac_led_slice0_init_done = 0;
static uint8 g_mac_led_slice1_init_done = 0;

/****************************************************************************
 *
* Functions  
*
****************************************************************************/
int32
led_api_op(glb_led_type_t type, glb_led_stat_t led_stat)
{
    int32 ret = RESULT_OK;

    if(led_stat < 0 || led_stat >=  E_LED_STAT_MAX)
    {
        DRV_LOG_ERR("Invalid parameter when control led, led stat %d.", led_stat);
        return RESULT_ERROR;    
    }

    if(g_p_led_hdl[type]==NULL)
        return ret;
    ret = g_p_led_hdl[type]->op(g_p_led_hdl[type], led_stat);
    return ret;
}

int32 
led_init(led_info_t* p_led_info)
{
    uint8 led_idx;
    
    if(NULL == p_led_info)
    {
        DRV_LOG_ERR("Led init: Invalid pointer.\n");
        return RESULT_ERROR;
    }

    for(led_idx = 0; led_idx < E_MAX_LED; led_idx++)
    {
        if(0 == p_led_info[led_idx].exist)
        {
            g_p_led_hdl[led_idx] = NULL;
            continue;
        }
        g_p_led_hdl[led_idx] = led_register(&(p_led_info[led_idx]));
        if(NULL == g_p_led_hdl[led_idx])
        {
            DRV_LOG_ERR("Led init: register led handle failed.\n");
            return RESULT_ERROR;
        }
    }
    
    return 0;
}

/*bug 23820, support mac led.*/
int32
mac_led_init(mac_led_api_para_t* port_led, uint8 port_num_per_slice)
{
    ctc_chip_led_para_t led_para;
    ctc_chip_mac_led_type_t led_type;
    ctc_chip_mac_led_mapping_t led_map;
    uint8 port;
    bool enable;

    if((0 == port_num_per_slice) || (NULL == port_led))
    {
        return 0;
    }

    for(port = 0; port < port_num_per_slice; port++)
    {
        led_para.ctl_id = port_led[port].ctl_id;
        led_para.lchip = port_led[port].lchip;
        led_para.op_flag = CTC_CHIP_LED_MODE_SET_OP;
        /* modified by liuht for bug 27331, 2014-04-22 */
        led_para.port_id = port_led[port].port_id;
        /* end of liuht modified */
        if(port_led[port].mode == LED_MODE_2_RXLNK_BIACT)
        {
            led_type = CTC_CHIP_USING_TWO_LED;

            led_para.first_mode = CTC_CHIP_RXLINK_MODE;
            /* Modified by liuht to change activity led mode for bug25680, 2013-11-12 */
            led_para.sec_mode = CTC_CHIP_BIACTIVITY_MODE;

        }
        /* added by liuht for bug 29099, 2014-06-23 */
        else if(port_led[port].mode == LED_MODE_1_RXLNK_BIACT)
        {
            led_type = CTC_CHIP_USING_ONE_LED;

            led_para.first_mode = CTC_CHIP_RXLINK_BIACTIVITY_MODE;
        }     
        else if (port_led[port].mode == LED_MODE_2_OFF_RXLNKBIACT)
        {
            led_type = CTC_CHIP_USING_TWO_LED;

            led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
            led_para.sec_mode = CTC_CHIP_RXLINK_BIACTIVITY_MODE;
        }
        /* end of liuht added */
        else if(port_led[port].mode == LED_MODE_2_RXLNKBIACT_OFF)
        {
            led_type = CTC_CHIP_USING_TWO_LED;

            led_para.first_mode = CTC_CHIP_RXLINK_BIACTIVITY_MODE;
            led_para.sec_mode = CTC_CHIP_FORCE_OFF_MODE;
        }
        else if(port_led[port].mode == LED_MODE_2_FORCE_OFF)
        {
            led_type = CTC_CHIP_USING_TWO_LED;

            led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
            led_para.sec_mode = CTC_CHIP_FORCE_OFF_MODE;
        }
        else if(port_led[port].mode == LED_MODE_1_FORCE_ON)
        {
            led_type = CTC_CHIP_USING_ONE_LED;

            led_para.first_mode = CTC_CHIP_FORCE_ON_MODE;
        }
        else if(port_led[port].mode == LED_MODE_1_FORCE_OFF)
        {
            led_type = CTC_CHIP_USING_ONE_LED;

            led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
        }
        else if(port_led[port].mode == LED_MODE_2_OFF_BIACT)
        {
            led_type = CTC_CHIP_USING_TWO_LED;
            led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
            led_para.sec_mode = CTC_CHIP_BIACTIVITY_MODE;
        }
        else if(port_led[port].mode == LED_MODE_2_BIACT_OFF)
        {
            led_type = CTC_CHIP_USING_TWO_LED;
            led_para.first_mode = CTC_CHIP_BIACTIVITY_MODE;
            led_para.sec_mode = CTC_CHIP_FORCE_OFF_MODE;
        }
        else if(port_led[port].mode == LED_MODE_1_BIACT)
        {
            led_type = CTC_CHIP_USING_ONE_LED;
            led_para.first_mode = CTC_CHIP_BIACTIVITY_MODE;
        }
        else if(port_led[port].mode == LED_MODE_2_OFF_ON)
        {
            led_type = CTC_CHIP_USING_TWO_LED;
            led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
            led_para.sec_mode = CTC_CHIP_FORCE_ON_MODE;
        }
        else if(port_led[port].mode == LED_MODE_2_ON_OFF)
        {
            led_type = CTC_CHIP_USING_TWO_LED;
            led_para.first_mode = CTC_CHIP_FORCE_ON_MODE;
            led_para.sec_mode = CTC_CHIP_FORCE_OFF_MODE;
        }
        /* Added by liuht for bug41782, 2016-11-23 */
        else if(port_led[port].mode == LED_MODE_2_TXLNK_RXLNKBIACT)
        {
            led_type = CTC_CHIP_USING_TWO_LED;
            led_para.first_mode = CTC_CHIP_RXLINK_BIACTIVITY_MODE;
            led_para.sec_mode = CTC_CHIP_TXLINK_MODE;
        }
        else if(port_led[port].mode == LED_MODE_2_TXLNK_BIACT)
        {
            led_type = CTC_CHIP_USING_TWO_LED;
            led_para.first_mode = CTC_CHIP_BIACTIVITY_MODE;
            led_para.sec_mode = CTC_CHIP_TXLINK_MODE;
        }
        else if(port_led[port].mode == LED_MODE_2_TXLNK_OFF)
        {
            led_type = CTC_CHIP_USING_TWO_LED;
            led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
            led_para.sec_mode = CTC_CHIP_TXLINK_MODE;
        }
        else if(port_led[port].mode == LED_MODE_2_RXLNKBIACT_TXLNK)
        {
            led_type = CTC_CHIP_USING_TWO_LED;
            led_para.first_mode = CTC_CHIP_TXLINK_MODE;
            led_para.sec_mode = CTC_CHIP_RXLINK_BIACTIVITY_MODE;
        }
        else if(port_led[port].mode == LED_MODE_2_BIACT_TXLNK)
        {
            led_type = CTC_CHIP_USING_TWO_LED;
            led_para.first_mode = CTC_CHIP_TXLINK_MODE;
            led_para.sec_mode = CTC_CHIP_BIACTIVITY_MODE;
        }
        else if(port_led[port].mode == LED_MODE_2_OFF_TXLNK)
        {
            led_type = CTC_CHIP_USING_TWO_LED;
            led_para.first_mode = CTC_CHIP_TXLINK_MODE;
            led_para.sec_mode = CTC_CHIP_FORCE_OFF_MODE;
        }
        ctc_chip_set_mac_led_mode(&led_para, led_type);
    }
    led_map.mac_led_num = port_num_per_slice;
    led_map.lchip = port_led[0].lchip;
    led_map.ctl_id = port_led[0].ctl_id;
    /* Modified by liuht for Malloc bug, 2013-11-18 */	
    led_map.p_mac_id = DRV_MALLOC(CTCLIB_MEM_DRIVER_LED_INFO, sizeof(uint8)*port_num_per_slice);
    for(port=0; port<port_num_per_slice; port++)
    {
        led_map.p_mac_id[port] = port_led[port].port_id;
    }
    ctc_chip_set_mac_led_mapping(&led_map);
    DRV_FREE(CTCLIB_MEM_DRIVER_LED_INFO, led_map.p_mac_id);
    if( ((0 == port_led[0].ctl_id) && (0 == g_mac_led_slice0_init_done))
        ||((1 == port_led[0].ctl_id) && (0 == g_mac_led_slice1_init_done)) )
    {
        led_para.lchip = port_led[0].lchip;
        led_para.ctl_id = port_led[0].ctl_id;
        led_para.op_flag = CTC_CHIP_LED_POLARITY_SET_OP;
        led_para.polarity = g_p_mac_led_info->polarity;
        ctc_chip_set_mac_led_mode(&led_para, led_type);
        ctc_chip_set_mac_led_en(1);
        enable = TRUE;
        ctc_chip_set_property(port_led[0].lchip, CTC_CHIP_MAC_LED_EN, (uint32*)&enable);
        if ((0 == port_led[0].ctl_id) && (0 == g_mac_led_slice0_init_done))
        {
            g_mac_led_slice0_init_done = 1;
        }
        else if ((1 == port_led[0].ctl_id) && (0 == g_mac_led_slice1_init_done))
        {
            g_mac_led_slice1_init_done = 1;
        }
    }
    
    return 0;
}

int32 led_cfg_port_mode(mac_led_api_para_t* port_led)
{
    ctc_chip_led_para_t led_para;
    ctc_chip_mac_led_type_t led_type;
    int ret = 0;
    
    led_para.op_flag = CTC_CHIP_LED_MODE_SET_OP;
    
    /* Fix bug29681, transfer lchip info to SDK, qicx, 2014-09-27 */   
    led_para.lchip = port_led->lchip;
    led_para.ctl_id = port_led->ctl_id;
    led_para.port_id = port_led->port_id;
    if(port_led->mode == LED_MODE_2_RXLNKBIACT_OFF)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_RXLINK_BIACTIVITY_MODE;
        led_para.sec_mode = CTC_CHIP_FORCE_OFF_MODE;
    }
    else if(port_led->mode == LED_MODE_2_OFF_RXLNKBIACT)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
        led_para.sec_mode = CTC_CHIP_RXLINK_BIACTIVITY_MODE;
    }
    else if(port_led->mode == LED_MODE_2_FORCE_OFF)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
        led_para.sec_mode = CTC_CHIP_FORCE_OFF_MODE;
    }
    else if(port_led->mode == LED_MODE_1_FORCE_OFF)
    {
        led_type = CTC_CHIP_USING_ONE_LED;
        led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
    }
    else if(port_led->mode == LED_MODE_1_RXLNK_BIACT)
    {
        led_type = CTC_CHIP_USING_ONE_LED;
        led_para.first_mode = CTC_CHIP_RXLINK_BIACTIVITY_MODE;
    }
    else if(port_led->mode == LED_MODE_2_OFF_BIACT)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
        led_para.sec_mode = CTC_CHIP_BIACTIVITY_MODE;
    }
    else if(port_led->mode == LED_MODE_2_BIACT_OFF)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_BIACTIVITY_MODE;
        led_para.sec_mode = CTC_CHIP_FORCE_OFF_MODE;
    }
    else if(port_led->mode == LED_MODE_1_BIACT)
    {
        led_type = CTC_CHIP_USING_ONE_LED;
        led_para.first_mode = CTC_CHIP_BIACTIVITY_MODE;
    }
    /* Added by liuht for bug41782, 2016-11-23 */
    else if(port_led->mode == LED_MODE_2_TXLNK_RXLNKBIACT)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_RXLINK_BIACTIVITY_MODE;
        led_para.sec_mode = CTC_CHIP_TXLINK_MODE;
    }
    else if(port_led->mode == LED_MODE_2_TXLNK_BIACT)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_BIACTIVITY_MODE;
        led_para.sec_mode = CTC_CHIP_TXLINK_MODE;
    }
    else if(port_led->mode == LED_MODE_2_TXLNK_OFF)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_FORCE_OFF_MODE;
        led_para.sec_mode = CTC_CHIP_TXLINK_MODE;
    }
    else if(port_led->mode == LED_MODE_2_RXLNKBIACT_TXLNK)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_TXLINK_MODE;
        led_para.sec_mode = CTC_CHIP_RXLINK_BIACTIVITY_MODE;
    }
    else if(port_led->mode == LED_MODE_2_BIACT_TXLNK)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_TXLINK_MODE;
        led_para.sec_mode = CTC_CHIP_BIACTIVITY_MODE;
    }
    else if(port_led->mode == LED_MODE_2_OFF_TXLNK)
    {
        led_type = CTC_CHIP_USING_TWO_LED;
        led_para.first_mode = CTC_CHIP_TXLINK_MODE;
        led_para.sec_mode = CTC_CHIP_FORCE_OFF_MODE;
    }
    ret = ctc_chip_set_mac_led_mode(&led_para, led_type);
    mac_led_info_modify(port_led);
    
    return ret;
}

/***************************************************************************************************
 * Name         : mac_led_info_register 
 * Purpose      : register mac led information          
 * Input        : p_mac_led_info         
 * Output       : g_p_mac_led_info              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32 mac_led_info_register(mac_led_info_t* p_mac_led_info)
{
    uint8 table_idx;
    uint8 table_num;
    uint8 mac_num;
    mac_led_api_para_t** mac_led_api_para;
    uint8 slice0_mac_num;
    uint8 slice1_mac_num;
    uint8 led_info_len;
    uint8 led_api_len;
    uint8 led_api_plen;
    uint8 polarity;

    uint8 port = 0;
    uint8 port0 = 0;
    uint8 port1 = 0;

    mac_led_api_para_t* p_port_led = NULL;
    
    if(!p_mac_led_info)
    {
        g_p_mac_led_info = NULL;
        return -1;
    }

    polarity = p_mac_led_info->polarity;
    table_num = p_mac_led_info->table_num;
    mac_num = p_mac_led_info->mac_num;
    slice0_mac_num = p_mac_led_info->slice0_mac_num;
    slice1_mac_num = mac_num - slice0_mac_num;

    led_info_len = sizeof(mac_led_info_t);
    led_api_len = sizeof(mac_led_api_para_t);
    led_api_plen = sizeof(mac_led_api_para_t *);
    
    if(table_num == 0)
    {
        return RESULT_OK;
    }
    
    g_p_mac_led_info = (mac_led_info_t*)DRV_MALLOC(CTCLIB_MEM_DRIVER_LED_INFO, led_info_len);
    if(!g_p_mac_led_info)
    {
        DRV_LOG_ERR("Allocate pointer to mac_led_info_t fail.\n");
        return RESULT_ERROR;
    }

    g_p_mac_led_info->polarity = polarity;
    g_p_mac_led_info->mac_num = mac_num;
    g_p_mac_led_info->table_num = table_num;
    g_p_mac_led_info->slice0_mac_num = slice0_mac_num;

    mac_led_api_para = (mac_led_api_para_t **)DRV_MALLOC(CTCLIB_MEM_DRIVER_LED_INFO, led_api_plen*table_num);
    if(!mac_led_api_para)
    {
        DRV_LOG_ERR("Allocate pointer to mac_led_api_para_t* fail.\n");
        return RESULT_ERROR;
    }

    for(table_idx = 0; table_idx < table_num; table_idx++)
    {
        mac_led_api_para[table_idx] = (mac_led_api_para_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_LED_INFO, led_api_len*mac_num);
        if(!mac_led_api_para[table_idx])
        {
            DRV_LOG_ERR("Allocate pointer to mac_led_api_para_t fail table_idx %d.\n", table_idx);
            return RESULT_ERROR;
        }
        sal_memcpy(mac_led_api_para[table_idx], p_mac_led_info->mac_led_api_para[table_idx], led_api_len*mac_num);
    }

    g_p_mac_led_info->mac_led_api_para = mac_led_api_para;

    if(0 != slice0_mac_num)
    {
        g_p_port_led_slice0 = DRV_MALLOC(CTCLIB_MEM_DRIVER_LED_INFO, sizeof(mac_led_api_para_t)*slice0_mac_num);
        if (!g_p_port_led_slice0)
        {
            DRV_LOG_ERR("Mac led alloc memory failed.");
            return RESULT_ERROR;  
        }
    }
    if(0 != slice1_mac_num)
    {
        g_p_port_led_slice1 = DRV_MALLOC(CTCLIB_MEM_DRIVER_LED_INFO, sizeof(mac_led_api_para_t)*slice1_mac_num);
        if (!g_p_port_led_slice1)
        {
            DRV_LOG_ERR("Mac led alloc memory failed.");
            return RESULT_ERROR;  
        }
    }

    p_port_led = g_p_mac_led_info->mac_led_api_para[0];

    /* 
     * construct two arrays 
     *  1)p_port_led_slice0[slice0_mac_num]: all slice no are 0 
     *  2)p_port_led_slice1[slice1_mac_num]: all slice no are 1
     */
    for (port = 0; port < g_p_mac_led_info->mac_num; port++)
    {
        if (0 == p_port_led[port].ctl_id)
        {
            sal_memcpy(&g_p_port_led_slice0[port0], &p_port_led[port], sizeof(mac_led_api_para_t));
            port0++;
        }
        else if (1 == p_port_led[port].ctl_id)
        {
            sal_memcpy(&g_p_port_led_slice1[port1], &p_port_led[port], sizeof(mac_led_api_para_t));

            port1++;
        }
    }

    return 0;
}

/***************************************************************************************************
 * Name         : mac_led_info_modify 
 * Purpose      : modify mac led information          
 * Input        : port_led         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32 mac_led_info_modify(mac_led_api_para_t* port_led)
{
    uint8 table_id, mac_idx;
    mac_led_api_para_t* pp_mac_led_api_para;

    if(NULL == g_p_mac_led_info)
    {
        DRV_LOG_ERR("Management mac led: g_p_mac_led_info is NULL.\n");
        return RESULT_ERROR;
    }

    for(table_id = 0; table_id < g_p_mac_led_info->table_num; table_id++)
    {
        pp_mac_led_api_para = g_p_mac_led_info->mac_led_api_para[table_id];
        for(mac_idx = 0; mac_idx < g_p_mac_led_info->mac_num; mac_idx++)
        {
            if((pp_mac_led_api_para[mac_idx].port_id == port_led->port_id)
            &&(pp_mac_led_api_para[mac_idx].lchip == port_led->lchip)
            &&(pp_mac_led_api_para[mac_idx].ctl_id == port_led->ctl_id))
            {
                pp_mac_led_api_para[mac_idx].mode = port_led->mode;
                break;
            }
        }
    }

    return 0;
}

/***************************************************************************************************
 * Name         : led_mgt_port_led 
 * Purpose      : configure mac led depand on g_p_mac_led_info        
 * Input        : N/A         
 * Output       : N/A              
 * Return       : LCM_E_SUCCESS
 * Note         : N/A
***************************************************************************************************/
int32 led_mgt_port_led()
{
    int ret = 0;
    uint8 port  = 0;
    uint8 port0 = 0;
    uint8 port1 = 0;
    mac_led_api_para_t* p_mac_led_api_para = NULL;

    if(NULL == g_p_mac_led_info)
    {
        DRV_LOG_ERR("Management mac led: g_p_mac_led_info is NULL.\n");
        return RESULT_ERROR;
    }
    
    if(g_mac_table_id >= g_p_mac_led_info->table_num)
    {
        g_mac_table_id = 0;
    }
    
    p_mac_led_api_para = g_p_mac_led_info->mac_led_api_para[g_mac_table_id++];
    if(!p_mac_led_api_para)
    {
        g_mac_table_id = 0;
        return 0;
    }

    for (port = 0; port < g_p_mac_led_info->mac_num; port++)
    {
        if (0 == p_mac_led_api_para[port].ctl_id)
        {
            sal_memcpy(&g_p_port_led_slice0[port0], &p_mac_led_api_para[port], sizeof(mac_led_api_para_t));
            port0++;
        }
        else if (1 == p_mac_led_api_para[port].ctl_id)
        {
            sal_memcpy(&g_p_port_led_slice1[port1], &p_mac_led_api_para[port], sizeof(mac_led_api_para_t));
            port1++;
        }
    }

    ret = mac_led_init(g_p_port_led_slice0, g_p_mac_led_info->slice0_mac_num);
    ret += mac_led_init(g_p_port_led_slice1, g_p_mac_led_info->mac_num - g_p_mac_led_info->slice0_mac_num);

    return ret;
}

/*Bug35259, jqiu modify 2016-09-13.*/
int32 led_linkup_process(uint8 lchip, uint16 gport)
{
#ifdef GOLDENGATE
    uint32 value;
    sys_goldengate_port_get_mac_stats(lchip, gport, &value);
    if(value)
    {
        sys_goldengate_port_set_reset_mac(lchip, gport, 1);
        sys_goldengate_port_set_reset_mac(lchip, gport, 0);
    }
#endif
    return 0;
}

