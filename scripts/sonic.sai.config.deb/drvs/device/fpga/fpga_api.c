/****************************************************************************
 * fpga_api.c    fpga api of chsm
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       Zhu Jian
 * Date:         2010-08-28.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "fpga_api.h"

/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/
#define FPGA_DEV_MAXNUM    16

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
static fpga_handle_t* g_ctl_fpga_hdl;
static fpga_info_t* g_local_fpga_info;

static fpga_hw_info_t  g_fpga_hw_info[] =
{
}; 

static fpga_info_t g_fpga_info[FPGA_DEV_MAXNUM];

/****************************************************************************
 *
* Functions  
*
****************************************************************************/    
/*****************************************************************************
 * Name         :   fpga_get_info
 * Purpose      :   get the pci fpga dev for specify board
 * Input         :   board_type
 *                 :   fpga_version 
 * Output       :   
 * Return       :   pci fpga info
 * Note         :   
 *****************************************************************************/
fpga_info_t * fpga_get_info(glb_board_type_t *board_type, int32 fpga_version)
{
    int32 i = 0; 
    int32 reg_index = -1;
    
    for(i = 0; i < FPGA_DEV_MAXNUM; i++)
    {
        if(g_fpga_hw_info[i].valid == 0)
        {
            continue;
        }

        if((g_fpga_hw_info[i].board_type.series == board_type->series) 
            && (g_fpga_hw_info[i].board_type.type == board_type->type) 
            && (g_fpga_hw_info[i].fpga_start_version <= fpga_version) 
            && (g_fpga_hw_info[i].fpga_end_version >= fpga_version))
        {
            reg_index = g_fpga_hw_info[i].fpga_reg_index;
            g_local_fpga_info = &g_fpga_info[reg_index];
            return &g_fpga_info[reg_index];
        }
    }

    return NULL;
}

int32 
fpga_read(uint8 byte_width, int32 addr, uint32* value)
{
    fpga_access_t fpga_access;
    int32 ret = 0;

    fpga_access.width = byte_width;
    fpga_access.addr = addr;
    if(0x1 == byte_width)
    {
        fpga_access.val.val_8bit = 0;
    }
    else if(0x2 == byte_width)
    {
        fpga_access.val.val_16bit = 0;
    }
    else
    {
        fpga_access.val.val_32bit = 0;
    }
    ret = g_ctl_fpga_hdl->read(g_ctl_fpga_hdl, &fpga_access);
    if(0x1 == byte_width)
    {
        *value = fpga_access.val.val_8bit;
    }
    else if(0x2 == byte_width)
    {
        *value = fpga_access.val.val_16bit;
    }
    else
    {
        *value = fpga_access.val.val_32bit;
    }

    return ret; 
}

int32 
fpga_write(uint8 byte_width, int32 addr, uint32 value)
{
    fpga_access_t fpga_access;

    fpga_access.width = byte_width;
    fpga_access.addr = addr;
    if(0x1 == byte_width)
    {
        fpga_access.val.val_8bit = (uint8)value;
    }
    else if(0x2 == byte_width)
    {
        fpga_access.val.val_16bit = (uint16)value;
    }
    else
    {
        fpga_access.val.val_32bit = value;
    }
    
    return g_ctl_fpga_hdl->write(g_ctl_fpga_hdl, &fpga_access);
}

int32 
fpga_item_read(uint32 op_reg, int32* value)
{    
    int32 ret;
    int32 val;
    
    if(NULL == g_ctl_fpga_hdl || op_reg > FPGA_REG_MAX_NUM)
    {
        return -1;
    }
    
    ret = g_ctl_fpga_hdl->item_read(g_ctl_fpga_hdl, op_reg, &val);
    *value =  val;

    return ret;
}

int32 
fpga_item_write(uint32 op_reg, int32 value)
{
    if(NULL == g_ctl_fpga_hdl || op_reg > FPGA_REG_MAX_NUM)
    {
        return -1;
    }
    
    return g_ctl_fpga_hdl->item_write(g_ctl_fpga_hdl, op_reg, value);
}


/*****************************************************************************
 * Name         :   fpga_set_reg_desc
 * Purpose      :   set fpga's reg_desc's value 
 * Input        :   reg_offset          
 *              :   start_bit
 *              :   endbit
 *              :   item_bitwidth
 * Output       :   reg_desc
 * Return       :   Success 
 * Note         :
 *****************************************************************************/
inline int32 fpga_set_reg_desc(struct fpga_reg_s * reg_desc, int32 reg_offset, int32 start_bit,
                               int32 end_bit, int32 item_bitwidth)
{
    reg_desc->reg_offset = reg_offset;
    reg_desc->start_bit = start_bit;
    reg_desc->end_bit = end_bit;
    reg_desc->item_bitwidth = item_bitwidth;
    reg_desc->reg_valid = 0x1;

    return 0;
}


int32 
fpga_get_fpga_version(uint32 *fpga_version)
{
    *fpga_version = 0x0;    
    return 0;
}

int32
fpga_cfg_phy_interrupt_mask(int32 mask_en)
{
    fpga_reg_t *p_fpga_reg = NULL;
    uint32 len_gphy = 0;
    
    p_fpga_reg = &g_local_fpga_info->reg_desc[FPGA_PHY_INT_MASK];
    if(NULL == p_fpga_reg || 0 == p_fpga_reg->reg_valid)
    {
        return -1;    
    }

    if(mask_en)
    {
        len_gphy = p_fpga_reg->item_bitwidth;
        fpga_item_write(FPGA_PHY_INT_MASK, (0x1<<len_gphy)-1);
    }
    else
    {
        fpga_item_write(FPGA_PHY_INT_MASK, 0x0);
    }

    return 0;
}

/*****************************************************************************
 * Name         :   api_init_fpga_dev
 * Purpose      :   init fpga dev handler
 * Input         :    fpga fpga info      
 * Output       :   
 * Return        :   Success 
 * Note          :
 *****************************************************************************/
int32 
fpga_init(fpga_info_t *p_fpga_info)
{
    g_ctl_fpga_hdl = fpga_dev_register((void *)p_fpga_info);
    if(NULL == g_ctl_fpga_hdl)
    {
        return -1;
    }
    
    return 0;
}

