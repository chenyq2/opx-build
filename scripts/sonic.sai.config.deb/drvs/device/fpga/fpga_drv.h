/****************************************************************************
* $Id$
*  The header file of the fpga operation.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Jian Zhu
* Date          : 2008-08-30 
* Reason        : First Create.
****************************************************************************/
#ifndef __FPGA_DRV__
#define __FPGA_DRV__

#define FPGA_REG_DESC_MAXNUM    256 /*replace 64 with 128 for e810*/

typedef struct fpga_reg_s
{
    int32 reg_offset;                         /* reg addr*/
    int32 start_bit;                          /* the start bit */
    int32 end_bit;                            /* the end bit */
    int32 item_bitwidth;                      /* how many bits desc one items */
    int32 reg_valid;
} fpga_reg_t;

typedef enum fpga_bus_type_e
{
    FPGA_PCI_TYPE = 0, 
} fpga_bus_type_t;


typedef struct fpga_info_s
{
    int32 base_addr;
    fpga_bus_type_t fpga_bus_type;
    fpga_reg_t reg_desc[FPGA_REG_DESC_MAXNUM];
} fpga_info_t;

typedef struct fpga_access_s{
    int32 addr;      /* the address in epld to be access */
    uint8 width;     /* the width of the value (multiple of byte)*/
    union
    {
        uint8  val_8bit;          /* the 32 bit value W/R from the offset */
        uint16 val_16bit;         /* the 16 bit value W/R from the offset */
        uint32   val_32bit;         /* the 8 bit value W/R from the offset */
    } val;
} fpga_access_t;

typedef struct fpga_handle_s fpga_handle_t;
struct fpga_handle_s
{
    int32 (*item_read)(const fpga_handle_t *phdl, uint32 op_reg, int32 *value);
    int32 (*item_write)(const fpga_handle_t *phdl, uint32 op_reg, int32 value);
    int32 (*read)(const fpga_handle_t *, fpga_access_t *);
    int32 (*write)(const fpga_handle_t *, fpga_access_t *);
    void *info;
};

fpga_handle_t * fpga_dev_register(void *info);
#endif /* !__FPGA_DRV__ */

