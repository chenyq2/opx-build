/****************************************************************************
 * ds26503_api.c    ds26503 api 
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       liangf 
 * Date:         2013-08-17.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "ctclib_debug.h"
#include "drv_debug.h"
#include "ds26503_api.h"
#include "ds26503_drv.h"
#include "ds26503_err.h"


/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/


/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
/* ds26503 handler */
static ds26503_handle_t **g_ds26503_hdl;


/****************************************************************************
 *
* Functions  
*
****************************************************************************/

/*********************************************************************
 * Name    : ds26503_dev_init
 * Purpose :  configuration ds26503
 * Input   : uint32 idx         - the index of ds26503, usually index = 0
          uint32 clock_type     - the flag of clock type, such as richmod type, 
                                  humber type and 10G phy type etc
                              
 * Output  : N/A
 * Return  : ds26503_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds26503_dev_init(uint32 idx)
{
    ds26503_write(idx, 0x8, 0x88);
    ds26503_write(idx, 0x9, 0x4c);
    ds26503_write(idx, 0x30, 0x1);
    
    return 0;
        
}

/*********************************************************************
 * Name    : ds26503_read
 * Purpose :  read ds26503 register
 * Input   : uint32 idx         - the index of ds26503, usually index = 0
          uint16 addr           - the address of ds26503 internal register 
          uint32 *val           - the pointer of read value
                              
 * Output  : N/A
 * Return  : ds26503_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ds26503_read(uint32 idx, uint8 addr, uint32  *val)
{
    ds26503_access_t ds26503_access;

    DRV_CTC_CHK_PTR(val);

    DRV_CTC_CHK_PTR(g_ds26503_hdl[idx]);
    
    ds26503_access.addr= addr;
    ds26503_access.val = val;

//    DRV_LOG_DEBUG(ds26503, DRV_DS26503_READ, "ds26503_read %d, addr %d, val pointer %p",
//                            idx, ds26503_access.addr, ds26503_access.val);

    return g_ds26503_hdl[idx]->read(g_ds26503_hdl[idx], &ds26503_access);
}

/*********************************************************************
 * Name    : ds26503_write
 * Purpose :  write ds26503 register
 * Input   : uint32 idx         - the index of ds26503, usually index = 0
          uint16 addr           - the address of ds26503 internal register 
          uint32 val            - write value 
                              
 * Output  : N/A
 * Return  : ds26503_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ds26503_write(uint32 idx, uint8 addr, uint32  val)
{
    ds26503_access_t ds26503_access;
    
    DRV_CTC_CHK_PTR(g_ds26503_hdl[idx]);
    
    ds26503_access.addr= addr;
    ds26503_access.val = &val;

//    DRV_LOG_DEBUG(ds26503, DRV_DS26503_WRITE, "ds26503_write %d, addr %d, val pointer %p",
//                            idx, ds26503_access.addr, ds26503_access.val);

    return g_ds26503_hdl[idx]->write(g_ds26503_hdl[idx], &ds26503_access);
}

/*********************************************************************
 * Name    : ds26503_close
 * Purpose :  free memory and pointer
 * Input   : uint32 idx     - the index of ds26503, usually index = 0
          
 * Output  : N/A
 * Return  : ds26503_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds26503_close(uint32 idx)
{
    DRV_CTC_CHK_PTR(g_ds26503_hdl[idx]);
    
    return g_ds26503_hdl[idx]->close(g_ds26503_hdl[idx]);
}

/*********************************************************************
 * Name    : ds26503_init
 * Purpose :  init some data structure and config ds26503
 * Input   : spi_gen_t *spi_gen     - some info about the way of ds26503'spi bus implement
          uint32 num         - the number of ds26503
          uint32 clock_type   - 
 * Output  : N/A
 * Return  : ds26503_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/
int32 
ds26503_init(spi_gen_t *spi_gen, uint32 num)
{
    int32 i = 0;
    int32 ret;
    
    DRV_CTC_CHK_PTR(spi_gen);
    
    g_ds26503_hdl = (ds26503_handle_t **)DRV_MALLOC(CTCLIB_MEM_DRIVER_DS26503_INFO,sizeof(ds26503_handle_t *)*num);
    if(NULL == g_ds26503_hdl)
    {
        DRV_LOG_ERR("ds26503 alloc handler fail!\n");
        return DS26503_E_INVALID_PTR;
    }

    for (i = 0; i < num; i++)
    {
        g_ds26503_hdl[i] = ds26503_register(E_DS26503_SPI, (const void *)&spi_gen[i]);
    }

    for (i = 0; i < num; i++)
    {
        ret = ds26503_dev_init(i);
        if(ret != 0)
        {
            DRV_LOG_ERR("ds26503 dev init fail!\n");
            return DS26503_E_INIT_FAILED;        
        }
    }
    
    return DS26503_SUCCESS;
}



