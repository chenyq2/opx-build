/****************************************************************************
* $Id$
*  The header file of the ds26503 operation.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : liangf
* Date          : 2013-08-17 
* Reason        : First Create.
****************************************************************************/
#ifndef __DS26503_DRV__
#define __DS26503_DRV__

#include "ctc_spi.h"

#define DS26503_DATA_LENTH 1    /* data length (byte)*/  
#define DS26503_ADDRESS_LENTH 2  /* address length (byte)*/ 

#define DS26503_SPI_READ  0x1
#define DS26503_SPI_WRITE 0x0
/*1 = burst access, 0 = single access*/
#define DS26503_SPI_ACCESS_MODE 0x0


typedef enum
{
    E_DS26503_SPI = 0,        /* access the ds26503 by SPI bus */
} ds26503_type_t;


struct ds26503_access_s{
    uint8 addr;             /* ds26503 register address */ 
    uint32  *val;             /* pointer of the value buffur */
} ;
typedef struct ds26503_access_s ds26503_access_t;

typedef struct ds26503_handle_s ds26503_handle_t;
struct ds26503_handle_s
{
    uint32 index;
    int32 (*close)(ds26503_handle_t *);
    int32 (*read)(const ds26503_handle_t *, ds26503_access_t *);
    int32 (*write)(const ds26503_handle_t *, ds26503_access_t *);
    void *handle;  /*handle of the low level operations */
};

ds26503_handle_t *ds26503_register(ds26503_type_t type, const void *pgen);

#endif 

