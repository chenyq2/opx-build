/****************************************************************************
* $Id$
*  The header file of the ad9559 operation.
*
* (C) Copyright Actus Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Chani
* Date          : 2013-09-30 
* Reason        : First Create.
****************************************************************************/
#ifndef __AD9559_DRV__
#define __AD9559_DRV__

#include "ctc_spi.h"

#define AD9559_DATA_LENTH 1    /* data length (byte)*/  
#define AD9559_ADDRESS_LENTH 2  /* address length (byte)*/ 

#define AD_SPI_READ  0x1
#define AD_SPI_WRITE 0x0
#define AD_SPI_WIDTH_1 0x0
#define AD_SPI_WIDTH_2 0x1
#define AD_SPI_WIDTH_3 0x2
#define AD_SPI_STREAM  0x3


#define AD_VCO_CAL_FINISHED 0x6
#define AD_DIGITAL_LOCK     0x0


typedef enum
{
    E_AD9559_SPI = 0,        /* access the AD9559 by SPI bus */
} ad9559_type_t;


struct ad9559_access_s{
    uint16 addr;             /* ad9559 register address */ 
    uint32  *val;             /* pointer of the value buffur */
} ;
typedef struct ad9559_access_s ad9559_access_t;



typedef struct ad9559_handle_s ad9559_handle_t;
struct ad9559_handle_s
{
    uint32 index;
    int32 (*close)(ad9559_handle_t *);
    int32 (*read)(const ad9559_handle_t *, ad9559_access_t *);
    int32 (*write)(const ad9559_handle_t *, ad9559_access_t *);
    void *handle;  /*handle of the low level operations */
};



ad9559_handle_t *ad9559_register(ad9559_type_t type, const void *pgen);

#endif 

