/****************************************************************************
 * ad9559_api.c    ad9559 api 
 *
 * Copyright:    (c)2005 Actus Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       Chani
 * Date:         2013-09-30.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "ctclib_debug.h"
#include "drv_debug.h"
#include "ad9559_api.h"
#include "ad9559_drv.h"
#include "ad9559_err.h"


/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/


/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
/* ad9559 handler */
static ad9559_handle_t **g_ad9559_hdl;


/****************************************************************************
 *
* Functions  
*
****************************************************************************/

/*********************************************************************
 * Name    : ad9559_dev_init
 * Purpose : configuration ad9559
 * Input   : uint32 idx         - the index of ad9559, usually index = 0
 * Output  : N/A
 * Return  : AD9559_SUCCESS   = SUCCESS
           	  other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ad9559_dev_init(uint32 idx)
{
	ad9559_write(idx, 0x0, 0x80);

    return 0;
}

/*********************************************************************
 * Name    : ad9559_read
 * Purpose :  read ad9559 register
 * Input   : uint32 idx         - the index of ad9559, usually index = 0
          uint16 addr           - the address of ad9559 internal register 
          uint32 *val           - the pointer of read value
                              
 * Output  : N/A
 * Return  : AD9559_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ad9559_read(uint32 idx, uint16 addr, uint32  *val)
{
    ad9559_access_t ad9559_access;

    DRV_CTC_CHK_PTR(val);

    DRV_CTC_CHK_PTR(g_ad9559_hdl[idx]);
    
    ad9559_access.addr= addr;
    ad9559_access.val = val;

    DRV_LOG_DEBUG(ad9559, DRV_AD9559_READ, "ad9559_read %d, addr %d, val pointer %p",
                            idx, ad9559_access.addr, ad9559_access.val);
    
    return g_ad9559_hdl[idx]->read(g_ad9559_hdl[idx], &ad9559_access);
}

/*********************************************************************
 * Name    : ad9559_write
 * Purpose :  write ad9559 register
 * Input   : uint32 idx         - the index of ad9559, usually index = 0
          uint16 addr           - the address of ad9559 internal register 
          uint32 val            - write value 
                              
 * Output  : N/A
 * Return  : AD9559_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ad9559_write(uint32 idx, uint16 addr, uint32  val)
{
    ad9559_access_t ad9559_access;
    
    DRV_CTC_CHK_PTR(g_ad9559_hdl[idx]);
    
    ad9559_access.addr= addr;
    ad9559_access.val = &val;

    DRV_LOG_DEBUG(ad9559, DRV_AD9559_WRITE, "ad9559_write %d, addr %d, val pointer %p",
                            idx, ad9559_access.addr, ad9559_access.val);
    
    return g_ad9559_hdl[idx]->write(g_ad9559_hdl[idx], &ad9559_access);
}

/*********************************************************************
 * Name    : ad9559_close
 * Purpose :  free memory and pointer
 * Input   : uint32 idx     - the index of ad9559, usually index = 0
          
 * Output  : N/A
 * Return  : AD9559_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ad9559_close(uint32 idx)
{
    DRV_CTC_CHK_PTR(g_ad9559_hdl[idx]);
    
    return g_ad9559_hdl[idx]->close(g_ad9559_hdl[idx]);
}

/*********************************************************************
 * Name    : ad9559_init
 * Purpose :  init some data structure and config ad9559
 * Input   : spi_gen_t *spi_gen     - some info about the way of ad9559'spi bus implement
          uint32 num         - the number of ad9559
 * Output  : N/A
 * Return  : AD9559_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/
int32 
ad9559_init(spi_gen_t *spi_gen, uint32 num)
{
    int32 i = 0;
    int32 ret;
    
    DRV_CTC_CHK_PTR(spi_gen);
    
    g_ad9559_hdl = (ad9559_handle_t **)DRV_MALLOC(CTCLIB_MEM_DRIVER_AD9559_INFO,sizeof(ad9559_handle_t *)*num);
    if(NULL == g_ad9559_hdl)
    {
        DRV_LOG_ERR("AD9559 alloc handler fail!\n");
        return AD9559_E_INVALID_PTR;
    }

    for (i = 0; i < num; i++)
    {
        g_ad9559_hdl[i] = ad9559_register(E_AD9559_SPI, (const void *)&spi_gen[i]);
    }

    for (i = 0; i < num; i++)
    {
        ret = ad9559_dev_init(i);
        if(ret != 0)
        {
            DRV_LOG_ERR("AD9559 dev init fail!\n");
            return AD9559_E_INIT_FAILED;        
        }
    }
    
    return AD9559_SUCCESS;
}



