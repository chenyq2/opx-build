#ifndef __POE_API_H__
#define __POE_API_H__

#include "poe_drv.h"
#include "ctclib_list.h"

#define POE_PORT_MAX_BUDGET    30000

typedef struct
{
	uint32 chip_no;
	uint32 ram_addr;
	uint32 data;
} poe_patch_data_t;

typedef struct poe_list_port_info_s poe_list_port_info_t;
struct poe_list_port_info_s
{
	ctclib_list_node_t node;
	int32 port_num;
};

typedef int32 (*poe_port_deal_item_cb)(uint32);
typedef enum poe_port_deal_item_e
{
    POE_PORT_DEAL_ITEM_MIN = 0,
    POE_PORT_DEAL_ITEM_ENABLE,
    POE_PORT_DEAL_ITEM_BUDGET,
    POE_PORT_DEAL_ITEM_PRIORITY,
    POE_PORT_DEAL_ITEM_MAX
} poe_port_deal_item_t;

typedef int32 (*poe_sys_deal_item_cb)(void);
typedef enum poe_sys_deal_item_e
{
    POE_SYS_DEAL_ITEM_MIN = 0,
    POE_SYS_DEAL_ITEM_PM,
    POE_SYS_DEAL_ITEM_BUDGET,
    POE_SYS_DEAL_ITEM_BUDGET_RESERVE,
    POE_SYS_DEAL_ITEM_CONS_WARN_THRESHOLD,
    POE_SYS_DEAL_ITEM_LEGACY,
    POE_SYS_DEAL_ITEM_MAX
} poe_sys_deal_item_t;

typedef enum poe_deal_item_phase_e
{
    POE_DEAL_ITEM_READY = 0,
    POE_DEAL_ITEM_START,
    POE_DEAL_ITEM_END
} poe_deal_item_phase_t;

int32 poe_sys_read(poe_para_t* para);
int32 poe_sys_write(poe_para_t* para);
int32 poe_port_read(uint32 port_id, poe_para_t* para);
int32 poe_port_write(uint32 port_id, poe_para_t* para);

int32 poe_get_psu_status(uint8* status);
int32 poe_get_present(uint8* present);
int32 poe_clear_intr(void);
int32 poe_get_port_intr(uint32 port_id, poe_port_intr_valid_t *valid);

int32 poe_sys_pm_soft_calc(glb_poe_port_stat_info_t* port_status_info, glb_poe_port_stat_change_t* port_status_change,
                                glb_poe_sys_stat_info_t* sys_status_info, glb_poe_sys_stat_change_t* sys_status_change,
                                int32* port_num);

int32 poe_set_port_budget(uint32 port_id, uint32 budget);
int32 poe_port_enable(uint32 port_id, poe_admin_t enable);
int32 poe_port_enable_item(uint32 port_id);
int32 poe_set_port_priority(uint32 port_id, poe_port_priority_t priority);

int32 poe_set_sys_pm(poe_pm_t pm);
int32 poe_set_sys_pm_item(void);
int32 poe_set_sys_budget(uint32 budget);
int32 poe_set_sys_budget_reserved(uint32 budget_reserved);
int32 poe_set_sys_consump_warn_threshold(uint32 warn_threshold);
int32 poe_set_sys_legacy_cap(poe_legacy_cap_t cap);
int32 poe_set_sys_legacy_cap_item(void);

int32 poe_init(poe_hdl_t** phdl, uint32 chip_num, uint32 port_num, poe_panel_port_t* poe_panel_port_info);

int32 poe_add_mode(poe_daughter_card_work_mode_t mode);
int32 poe_remove_mode(void);

#endif
