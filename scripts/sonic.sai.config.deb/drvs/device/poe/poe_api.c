/****************************************************************************
* $Id$
* B330 POE API function
* 
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : wus
* Date          : 2011-07-30
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "drv_debug.h"
#include "poe_drv.h"
#include "glb_hw_define.h"
#include "epld_api.h"
#include "led_api.h"
#include "poe_api.h"

#define  PD69012_POWER_ON                0
#define  PD69012_POWER_FORCE_ON          1
#define  PD69012_STARTING_UP             2 
#define  PD69012_POWER_IN_FORCE_ON       3
#define  PD69012_DETECTION               4
#define  PD69012_INVALID_SIGNATURE       5
#define  PD69012_CLASS_ERROR             6
#define  PD69012_TEST_IN_FORCE_ON        7
#define  PD69012_VALID_SIGNATURE         8
#define  PD69012_DISABLE                 9
#define  PD69012_STARTUP_OVL             10
#define  PD69012_STARTUP_UDL             11
#define  PD69012_STARTUP_SHORT           12
#define  PD69012_DVDT_FAIL               13
#define  PD69012_TEST_FORCE_ON_ERR       14  
#define  PD69012_OVL                     15
#define  PD69012_UDL                     16
#define  PD69012_SHORT_CIRCUIT           17
#define  PD69012_CHIP_PM_OFF             18
#define  PD69012_CHIP_LEVEL_ERR          19
#define  PD69012_GENERAL_CHIP_ERR        20

/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/
#define  POE_PUNISH_CNT_MAX 60 /* 60*60 = 3690s,  max punish time 1H */
#define  POE_PUNISH_CNT_INTERVAL  60  /* 1min */
#define  POE_ERR_DISABLE_MAX 25 /* at a certain time, PD status changes 25 times at most */
#define  POE_ERR_DISABLE_TIMER_CNT  60 /* poll time 1min interval */
#define  POE_AVER_VAL_MAX_CNT  100
#define  POE_PORT_STATUS_NOT_STABLE  1000

#define  PD69012_POWER_ON                0
#define  PD69012_POWER_FORCE_ON          1
#define  PD69012_STARTING_UP             2 
#define  PD69012_POWER_IN_FORCE_ON       3
#define  PD69012_DETECTION               4
#define  PD69012_INVALID_SIGNATURE       5
#define  PD69012_CLASS_ERROR             6
#define  PD69012_TEST_IN_FORCE_ON        7
#define  PD69012_VALID_SIGNATURE         8
#define  PD69012_DISABLE                 9
#define  PD69012_STARTUP_OVL             10
#define  PD69012_STARTUP_UDL             11
#define  PD69012_STARTUP_SHORT           12
#define  PD69012_DVDT_FAIL               13
#define  PD69012_TEST_FORCE_ON_ERR       14  
#define  PD69012_OVL                     15
#define  PD69012_UDL                     16
#define  PD69012_SHORT_CIRCUIT           17
#define  PD69012_CHIP_PM_OFF             18
#define  PD69012_CHIP_LEVEL_ERR          19
#define  PD69012_GENERAL_CHIP_ERR        20

/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
static poe_hdl_t** g_poe_hdl = NULL;
static poe_panel_port_t* g_poe_panel_port_info;
static uint32 g_port_num;
static uint32 g_poe_chip_num = 0;
static poe_pm_t poe_sys_pm = POE_PM_STATIC;
static uint16 poe_aver_val_cnt = 0;
glb_poe_port_stat_change_t* port_stat_change;
glb_poe_sys_stat_change_t* sys_stat_change;
ctclib_list_t *poe_list_priority_low, *poe_list_priority_high, *poe_list_priority_critical, *poe_list_priority_no;

const poe_patch_data_t g_poe_patch[] =
{ 
        { 
                0x0000,    /* word ChipNo;        disable all ports */
                0x1332,    /* word RamAdd;        */
                0x0FFF     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        open protkey */
                0x031E,    /* word RamAdd;        */
                0x00AB     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 0 - Rise time exit */
                0x0080,    /* word RamAdd;        */
                0xDB49     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 0 - Rise time exit dest */
                0x0082,    /* word RamAdd;        */
                0x1CA0     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 1 - class spike exit */
                0x0084,    /* word RamAdd;        */
                0xE89F     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 1 - class spike exit dest */
                0x0086,    /* word RamAdd;        */
                0x1C00     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 2 - cass threshold exit */
                0x0088,    /* word RamAdd;        */
                0xE8F5     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 2 - class threshold exit dest */
                0x008A,    /* word RamAdd;        */
                0x1C30     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 3 - PM threshold exit */
                0x008C,    /* word RamAdd;        */
                0xC897     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 3 - PM threshold exit dest */
                0x008E,    /* word RamAdd;        */
                0x1C50     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 4 - Static PM Startup exit */
                0x0090,    /* word RamAdd;        */
                0xDE03     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 4 - Static PM Startup exit dest */
                0x0092,    /* word RamAdd;        */
                0x1C70     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 5 - auto int out exit */
                0x0094,    /* word RamAdd;        */
                0xFE3F     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 5 - auto int out exit dest */
                0x0096,    /* word RamAdd;        */
                0x1D20     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 6 - Reduced Cap exit */
                0x0098,    /* word RamAdd;        */
                0xF421     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 6 - Reduced cap exit dest */
                0x009A,    /* word RamAdd;        */
                0x1D50     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 7 - Pre Fix Exit */
                0x009C,    /* word RamAdd;        */
                0xE65D     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        patch 7 - Pre Fix Exit Dest */
                0x009E,    /* word RamAdd;        */
                0x1D80     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        change UDL Thtreshold */
                0x1062,    /* word RamAdd;        */
                0x1D07     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        change Power Resolution Factor */
                0x129E,    /* word RamAdd;        */
                0x153C     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        set Pre1 */
                0x1172,    /* word RamAdd;        */
                0x034C     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        set Pre2 */
                0x1174,    /* word RamAdd;        */
                0x00AF     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        set LD1 */
                0x1176,    /* word RamAdd;        */
                0x00AF     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        set LD2 */
                0x1178,    /* word RamAdd;        */
                0x0075     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        clear patch function reg */
                0x13AA,    /* word RamAdd;        */
                0x0000     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        set auto int out counter to 5 */
                0x13AC,    /* word RamAdd;        */
                0x0005     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        set patch data version */
                0x13B0,    /* word RamAdd;        */
                0x0010     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        close protkey */
                0x031E,    /* word RamAdd;        */
                0x0000     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        class spike code LDL R4,#128 */
                0x1C00,    /* word RamAdd;        */
                0xF480     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R4,#1 */
                0x1C02,    /* word RamAdd;        */
                0xAC01     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R3,(R4,#4) */
                0x1C04,    /* word RamAdd;        */
                0x4B84     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        OR R3,R3,R1 */
                0x1C06,    /* word RamAdd;        */
                0x1366     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R3,(R4,#4) */
                0x1C08,    /* word RamAdd;        */
                0x5B84     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R3,#170 */
                0x1C0A,    /* word RamAdd;        */
                0xF3AA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R3,#19 */
                0x1C0C,    /* word RamAdd;        */
                0xAB13     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R4,(R3,#0) */
                0x1C0E,    /* word RamAdd;        */
                0x4C60     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORL R4,#1 */
                0x1C10,    /* word RamAdd;        */
                0xA401     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R4,(R3,#0) */
                0x1C12,    /* word RamAdd;        */
                0x5C60     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R4,#64 */
                0x1C14,    /* word RamAdd;        */
                0xF440     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R3,#160 */
                0x1C16,    /* word RamAdd;        */
                0xF3A0     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R3,#232 */
                0x1C18,    /* word RamAdd;        */
                0xABE8     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        JAL R3 */
                0x1C1A,    /* word RamAdd;        */
                0x03F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        class 0 upper threshold */
                0x1C1C,    /* word RamAdd;        */
                0x0017     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        class 1 upper threshold */
                0x1C1E,    /* word RamAdd;        */
                0x0031     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        class 2 upper threshold */
                0x1C20,    /* word RamAdd;        */
                0x0051     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        class 3 upper threshold */
                0x1C22,    /* word RamAdd;        */
                0x006D     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        class 4 upper threshold */
                0x1C24,    /* word RamAdd;        */
                0x00A0     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        class thresholds patch code - LDL R3,#170 */
                0x1C30,    /* word RamAdd;        */
                0xF3AA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R3,#13 */
                0x1C32,    /* word RamAdd;        */
                0xAB13     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R2,(R3,#0) */
                0x1C34,    /* word RamAdd;        */
                0x4A60     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORL R2,#2 */
                0x1C36,    /* word RamAdd;        */
                0xA202     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R2,(R3,#0) */
                0x1C38,    /* word RamAdd;        */
                0x5A60     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R3,#28 */
                0x1C3A,    /* word RamAdd;        */
                0xF31C     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R3, #28 */
                0x1C3C,    /* word RamAdd;        */
                0xAB1C     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2, F8 */
                0x1C3E,    /* word RamAdd;        */
                0xF2F8     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R2, E8 */
                0x1C40,    /* word RamAdd;        */
                0xAAE8     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        JAL R2 */
                0x1C42,    /* word RamAdd;        */
                0x02F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        PM th change from 25% to 12.5% - LDL R3,#170 */
                0x1C50,    /* word RamAdd;        */
                0xF3AA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R3,#19 */
                0x1C52,    /* word RamAdd;        */
                0xAB13     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R2,(R3,#0) */
                0x1C54,    /* word RamAdd;        */
                0x4A60     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORL R2,#4 */
                0x1C56,    /* word RamAdd;        */
                0xA204     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R2,(R3,#0) */
                0x1C58,    /* word RamAdd;        */
                0x5A60     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        MOV R2,R4 */
                0x1C5A,    /* word RamAdd;        */
                0x1212     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ASR R2,#3 */
                0x1C5C,    /* word RamAdd;        */
                0x0A39     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R3,9a */
                0x1C5E,    /* word RamAdd;        */
                0xF39A     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R3,c8 */
                0x1C60,    /* word RamAdd;        */
                0xABC8     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        JAL R3 */
                0x1C62,    /* word RamAdd;        */
                0x03F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        Static PM Patch code - LDL R3,#170 */
                0x1C70,    /* word RamAdd;        */
                0xF3AA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R3,#19 */
                0x1C72,    /* word RamAdd;        */
                0xAB13     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R2,(R3,#0) */
                0x1C74,    /* word RamAdd;        */
                0x4A60     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORL R2,#8 */
                0x1C76,    /* word RamAdd;        */
                0xA208     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R2,(R3,#0) */
                0x1C78,    /* word RamAdd;        */
                0x5A60     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2,#172 */
                0x1C7A,    /* word RamAdd;        */
                0xF2AC     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R2,#18 */
                0x1C7C,    /* word RamAdd;        */
                0xAA12     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R3,(R2,#0) */
                0x1C7E,    /* word RamAdd;        */
                0x4B40     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2, AA */
                0x1C80,    /* word RamAdd;        */
                0xF2AA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R2, 12 */
                0x1C82,    /* word RamAdd;        */
                0xAA12     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R2, (R2,#0) */
                0x1C84,    /* word RamAdd;        */
                0x4A40     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        CMP R3,R2 */
                0x1C86,    /* word RamAdd;        */
                0x1868     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        BLS 1 */
                0x1C88,    /* word RamAdd;        */
                0x3201     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        MOV R3,R2 */
                0x1C8A,    /* word RamAdd;        */
                0x130A     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2, #196 */
                0x1C8C,    /* word RamAdd;        */
                0xF2C4     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R1,#10 */
                0x1C8E,    /* word RamAdd;        */
                0xF10A     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R1,#222 */
                0x1C90,    /* word RamAdd;        */
                0xA9DE     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        JAL R1 */
                0x1C92,    /* word RamAdd;        */
                0x01F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        Rise Time patch code  - LDL R6,#170 */
                0x1CA0,    /* word RamAdd;        */
                0xF6AA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R6,#19 */
                0x1CA2,    /* word RamAdd;        */
                0xAE13     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R2,(R6,#0) */
                0x1CA4,    /* word RamAdd;        */
                0x4AC0     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORL R2,#16 */
                0x1CA6,    /* word RamAdd;        */
                0xA210     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R2,(R6,#0) */
                0x1CA8,    /* word RamAdd;        */
                0x5AC0     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        MOV R3,R1 */
                0x1CAA,    /* word RamAdd;        */
                0x1306     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LSL R3,R4 */
                0x1CAC,    /* word RamAdd;        */
                0x0B94     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        MOV R2,R1 */
                0x1CAE,    /* word RamAdd;        */
                0x1206     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R6,#170(SetIntOut Add) */
                0x1CB0,    /* word RamAdd;        */
                0xF6AA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R6, #202 */
                0x1CB2,    /* word RamAdd;        */
                0xAECA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        JAL R6 */
                0x1CB4,    /* word RamAdd;        */
                0x06F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDB R2,(R5,#5) */
                0x1CB6,    /* word RamAdd;        */
                0x42A5     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        MOV R3,R1 */
                0x1CB8,    /* word RamAdd;        */
                0x1306     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LSL R3,R2 */
                0x1CBA,    /* word RamAdd;        */
                0x0B54     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R4,#128 */
                0x1CBC,    /* word RamAdd;        */
                0xF480     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R4,#1 */
                0x1CBE,    /* word RamAdd;        */
                0xAC01     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R3,(R4,#4) */
                0x1CC0,    /* word RamAdd;        */
                0x5B84     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        COM R3 */
                0x1CC2,    /* word RamAdd;        */
                0x130F     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R4,#64 */
                0x1CC4,    /* word RamAdd;        */
                0xF440     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R4,#2 */
                0x1CC6,    /* word RamAdd;        */
                0xAC02     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R2,(R4,#6) */
                0x1CC8,    /* word RamAdd;        */
                0x4A86     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        AND R2,R2,R3 */
                0x1CCA,    /* word RamAdd;        */
                0x124C     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R2,(R4,#6) */
                0x1CCC,    /* word RamAdd;        */
                0x5A86     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2,(R5,#5) */
                0x1CCE,    /* word RamAdd;        */
                0x42A5     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LSL R2,#1 */
                0x1CD0,    /* word RamAdd;        */
                0x0A1C     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R4,#74 */
                0x1CD2,    /* word RamAdd;        */
                0xF44A     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R4,#2 */
                0x1CD4,    /* word RamAdd;        */
                0xAC02     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R1,#8 */
                0x1CD6,    /* word RamAdd;        */
                0xF110     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R1,(R4,R2) */
                0x1CD8,    /* word RamAdd;        */
                0x7988     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2,#100 */
                0x1CDA,    /* word RamAdd;        */
                0xF264     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        NOP */
                0x1CDC,    /* word RamAdd;        */
                0x0100     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        SUBL R2,#1 */
                0x1CDE,    /* word RamAdd;        */
                0xC201     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        BNE -3 */
                0x1CE0,    /* word RamAdd;        */
                0x25FD     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDB R2,(R5,#5) */
                0x1CE2,    /* word RamAdd;        */
                0x42A5     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R1,#1 */
                0x1CE4,    /* word RamAdd;        */
                0xF101     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LSL R1,R2 */
                0x1CE6,    /* word RamAdd;        */
                0x0954     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R4,#128 */
                0x1CE8,    /* word RamAdd;        */
                0xF480     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R4,#1 */
                0x1CEA,    /* word RamAdd;        */
                0xAC01     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R1,(R4,#6) */
                0x1CEC,    /* word RamAdd;        */
                0x5986     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2, #100 */
                0x1CEE,    /* word RamAdd;        */
                0xF24B     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        NOP */
                0x1CF0,    /* word RamAdd;        */
                0x0100     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        SUBL R2,#1 */
                0x1CF2,    /* word RamAdd;        */
                0xC201     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        BNE -3 */
                0x1CF4,    /* word RamAdd;        */
                0x25FD     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDB R2,(R5,#5) */
                0x1CF6,    /* word RamAdd;        */
                0x42A5     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LSL R2,#1 */
                0x1CF8,    /* word RamAdd;        */
                0x0A1C     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R1,#1 */
                0x1CFA,    /* word RamAdd;        */
                0xF101     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R4,#74 */
                0x1CFC,    /* word RamAdd;        */
                0xF44A     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R4,#2 */
                0x1CFE,    /* word RamAdd;        */
                0xAC02     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R1,(R4,R2) */
                0x1D00,    /* word RamAdd;        */
                0x7988     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDB R2,(R5,#5) */
                0x1D02,    /* word RamAdd;        */
                0x42A5     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R1,#1 */
                0x1D04,    /* word RamAdd;        */
                0xF101     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LSL R1,R2 */
                0x1D06,    /* word RamAdd;        */
                0x0954     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2,#106 */
                0x1D08,    /* word RamAdd;        */
                0xF26A     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R2,#219 */
                0x1D0A,    /* word RamAdd;        */
                0xAADB     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        JAL R2 */
                0x1D0C,    /* word RamAdd;        */
                0x02F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        auto int out patch code - LDL R6,#174 */
                0x1D20,    /* word RamAdd;        */
                0xF6AA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R6,#19 */
                0x1D22,    /* word RamAdd;        */
                0xAE13     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R2,(R6,#0) */
                0x1D24,    /* word RamAdd;        */
                0x4AC0     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORL R2,#32 */
                0x1D26,    /* word RamAdd;        */
                0xA220     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R2,(R6,#0) */
                0x1D28,    /* word RamAdd;        */
                0x5AC0     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R3, #172 */
                0x1D2A,    /* word RamAdd;        */
                0xF3AC     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R3, #19 */
                0x1D2C,    /* word RamAdd;        */
                0xAB13     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R2,(R3,#0) */
                0x1D2E,    /* word RamAdd;        */
                0x4A60     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        SUBL R2,#1 */
                0x1D30,    /* word RamAdd;        */
                0xC201     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        BNE */
                0x1D32,    /* word RamAdd;        */
                0x2406     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R6,#254 */
                0x1D34,    /* word RamAdd;        */
                0xF6FE     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R6,#253 */
                0x1D36,    /* word RamAdd;        */
                0xAEFD     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        JAL R6 */
                0x1D38,    /* word RamAdd;        */
                0x06F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R3,#174 */
                0x1D3A,    /* word RamAdd;        */
                0xF3AC     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R3,#19 */
                0x1D3C,    /* word RamAdd;        */
                0xAB13     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2,#5 */
                0x1D3E,    /* word RamAdd;        */
                0xF205     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R2,(R3,#0) */
                0x1D40,    /* word RamAdd;        */
                0x5A60     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R6,#28 */
                0x1D42,    /* word RamAdd;        */
                0xF644     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R6,#254 */
                0x1D44,    /* word RamAdd;        */
                0xAEFE     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        JAL R6 */
                0x1D46,    /* word RamAdd;        */
                0x06F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        Reduced Cap Patch Code LDL R4,#170 */
                0x1D50,    /* word RamAdd;        */
                0xF4AA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R4,#19 */
                0x1D52,    /* word RamAdd;        */
                0xAC13     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R2,(R4,#0) */
                0x1D54,    /* word RamAdd;        */
                0x4A80     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORL R2,#64 */
                0x1D56,    /* word RamAdd;        */
                0xA240     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R2,(R4,#0) */
                0x1D58,    /* word RamAdd;        */
                0x5A80     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R2,(R7,#20) */
                0x1D5A,    /* word RamAdd;        */
                0x4AF4     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ADDL R2, #10 */
                0x1D5C,    /* word RamAdd;        */
                0xE20A     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R2,(R7,#20) */
                0x1D5E,    /* word RamAdd;        */
                0x5AF4     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        MOV R3,R7 */
                0x1D60,    /* word RamAdd;        */
                0x131E     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2,#16 */
                0x1D62,    /* word RamAdd;        */
                0xF210     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R6,0x24 */
                0x1D64,    /* word RamAdd;        */
                0xF624     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R6,0xF4 */
                0x1D66,    /* word RamAdd;        */
                0xAEF4     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        Jal R6 */
                0x1D68,    /* word RamAdd;        */
                0x06F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        Pre Fix Patch Code LDL R2, 0xAA */
                0x1D80,    /* word RamAdd;        */
                0xF2AA     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R2, 0x13 */
                0x1D82,    /* word RamAdd;        */
                0xAA13     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R5, (R2,0) */
                0x1D84,    /* word RamAdd;        */
                0x4D40     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORL R5,#128 */
                0x1D86,    /* word RamAdd;        */
                0xA580     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        STW R5, (R2,0) */
                0x1D88,    /* word RamAdd;        */
                0x5D40     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2, */
                0x1D8A,    /* word RamAdd;        */
                0xF2AC     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R2,  */
                0x1D8C,    /* word RamAdd;        */
                0xAA10     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R5,(R7,#0) */
                0x1D8E,    /* word RamAdd;        */
                0x4DE0     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;         LSL R5,#1 */
                0x1D90,    /* word RamAdd;        */
                0x0D1C     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDW R6, (R5,R2) */
                0x1D92,    /* word RamAdd;        */
                0x6EA8     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2, 0x5D */
                0x1D94,    /* word RamAdd;        */
                0xF25D     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R2,#1 */
                0x1D96,    /* word RamAdd;        */
                0xAA01     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        SUB R0, R6,R2 */
                0x1D98,    /* word RamAdd;        */
                0x18C8     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        BLS 3 */
                0x1D9A,    /* word RamAdd;        */
                0x3203     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2,  */
                0x1D9C,    /* word RamAdd;        */
                0xF286     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R2 */
                0x1D9E,    /* word RamAdd;        */
                0xAAE6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        JAL R2 */
                0x1DA0,    /* word RamAdd;        */
                0x02F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R3,#255 */
                0x1DA2,    /* word RamAdd;        */
                0xF3FF     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R3,#255 */
                0x1DA4,    /* word RamAdd;        */
                0xABFF     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        LDL R2, #102 */
                0x1DA6,    /* word RamAdd;        */
                0xF266     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        ORH R2, #230 */
                0x1DA8,    /* word RamAdd;        */
                0xAAE6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        JAL R2 */
                0x1DAA,    /* word RamAdd;        */
                0x02F6     /* word Data;          */
        }, 
        { 
                0x0000,    /* word ChipNo;        enable all ports */
                0x1332,    /* word RamAdd;        */
                0x0000     /* word Data;          */
        } 
};


/****************************************************************************
 *
* Functions  
*
****************************************************************************/
static int32
poe_port_is_support(int32 port_idx)
{
    return (g_poe_panel_port_info[port_idx].poe_support == 1 && port_idx < g_port_num);
}

poe_hdl_t*
get_poe_hdl(uint32 port_id)
{
    uint32 poe_chip_id = 0;

    if(!poe_port_is_support(port_id))
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE get poe hdl: port:%d not support poe.", port_id + 1);
        return NULL;
    }

    for(poe_chip_id = 0; poe_chip_id < g_poe_chip_num; poe_chip_id++)
    {
        if(g_poe_hdl[poe_chip_id]->chip_info.base_addr == g_poe_panel_port_info[port_id].poe_addr)
        {
            return g_poe_hdl[poe_chip_id];
        }
    }

    return NULL;
}

poe_hdl_t*
get_poe_master_hdl(void)
{
    poe_hdl_t* hdl;
    uint32 chip_id;

    for(chip_id = 0; chip_id < g_poe_chip_num; chip_id++)
    {
        hdl = g_poe_hdl[chip_id];

        if(hdl->chip_info.ctrl_level == POE_MASTER && NULL != hdl)
        {
            return hdl;
        }
    }

    return NULL;
}

int32
poe_sys_read(poe_para_t* para)
{
    poe_hdl_t* hdl;
    int32 ret = 0;

    if(NULL == para)
    {
        DRV_LOG_ERR("POE poe_sys_read: Invalid parameter.");
        return RESULT_ERROR;
    }

    hdl = get_poe_master_hdl();
    if(NULL == hdl)
    {
        DRV_LOG_ERR("POE poe_sys_read: get poe hdl failed.");
        return RESULT_ERROR;
    }

    ret += hdl->reg_read(hdl, para);

    return ret;
}

int32
poe_sys_write(poe_para_t* para)
{
    poe_hdl_t* hdl;
    int32 ret = 0;

    if(NULL == para)
    {
        DRV_LOG_ERR("POE poe_sys_write: Invalid parameter.");
        return RESULT_ERROR;
    }

    hdl = get_poe_master_hdl();
    if(NULL == hdl)
    {
        DRV_LOG_ERR("POE poe_sys_write: get poe hdl failed.");
        return RESULT_ERROR;
    }

    ret += hdl->reg_write(hdl, para);

    return ret;
}

int32
poe_port_read(uint32 port_id, poe_para_t* para)
{
    poe_hdl_t* hdl;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    int32 ret = 0;

    if(NULL == para)
    {
        DRV_LOG_ERR("POE poe_port_read: Invalid parameter.");
        return RESULT_ERROR;
    }

    hdl = get_poe_hdl(port_id);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE poe_port_read: get poe hdl failed.");
        return RESULT_ERROR;
    }

    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;

    para->offset += 2 * map_port_id;
    ret += hdl->reg_read(hdl, para);

    return ret;
}

int32
poe_port_write(uint32 port_id, poe_para_t* para)
{
    poe_hdl_t* hdl;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    int32 ret = 0;

    if(NULL == para)
    {
        DRV_LOG_ERR("POE poe_port_write: Invalid parameter.");
        return RESULT_ERROR;
    }

    hdl = get_poe_hdl(port_id);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE poe_port_write: get poe hdl failed.");
        return RESULT_ERROR;
    }

    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;

    para->offset += 2 * map_port_id;
    ret += hdl->reg_write(hdl, para);

    return ret;
}

static int32
poe_list_insert_descend(ctclib_list_t* p_list, ctclib_list_node_t* p_node)
{
    poe_list_port_info_t *p_port_info, *p_tmp_port_info;
    ctclib_list_node_t* tmp_node;
	
    p_port_info = ctclib_container_of(p_node, poe_list_port_info_t, node);
    
    if(ctclib_list_empty(p_list))
    {
        ctclib_list_insert_head(p_list, p_node);
    }
    else
    {
        ctclib_list_for_each(tmp_node, p_list)
        {
            p_tmp_port_info = ctclib_container_of(tmp_node, poe_list_port_info_t, node);
            
            if(p_tmp_port_info->port_num < p_port_info->port_num)
            {
                ctclib_list_insert_before(p_list, tmp_node, p_node);
                break;
            }
            else if(p_tmp_port_info->port_num > p_port_info->port_num)
            {
                if(ctclib_list_next(tmp_node) == NULL)
                {
                    ctclib_list_insert_after(p_list, tmp_node, p_node);
                    break;
                }

                continue;
            }
            else if(p_tmp_port_info->port_num == p_port_info->port_num)
            {
                return RESULT_ERROR;
            }
        }
    }

    return RESULT_OK;
}

static ctclib_list_node_t* 
poe_list_delete(ctclib_list_t* p_list, int32 port_num)
{
    poe_list_port_info_t *p_port_info;
    ctclib_list_node_t *tmp_node,*del_node = NULL;
	
    tmp_node = ctclib_list_head(p_list);
    if(NULL == tmp_node)
    {
        del_node = NULL;
    }
    else
    {
        ctclib_list_for_each(tmp_node, p_list)
        {
            p_port_info = ctclib_container_of(tmp_node, poe_list_port_info_t, node);
            if(p_port_info->port_num == port_num)
            {
                ctclib_list_delete(p_list, tmp_node);
				tmp_node->p_next = NULL;
				tmp_node->p_prev = NULL;
                del_node = tmp_node;
                break;
            }
        }
    }
	
    return del_node;
}

/* Get PoE external PSU status */
int32
poe_get_psu_status(uint8* status)
{
    int32 ret = 0;
    uint8 psu_status;

    if(NULL == status)
    {
        DRV_LOG_ERR("poe_get_psu_status: Invalid parameter.");
        return RESULT_ERROR;
    }
    
    ret += epld_get_poe_psu_status(&psu_status);
    *status = psu_status;

    return ret;
}

/* Get PoE Card present status */
int32
poe_get_present(uint8* present)
{
    int32 ret = 0;
    uint8 poe_present;

    if(NULL == present)
    {
        DRV_LOG_ERR("poe_get_present: Invalid parameter.");
        return RESULT_ERROR;
    }

    ret += epld_get_poe_present(&poe_present);
    *present = poe_present;

    return ret;
}

int32
poe_clear_intr(void)
{    
    poe_hdl_t* hdl = NULL;
    poe_para_t para = {0};
    uint8 data[2];
    uint32 chip_idx = 0;
    uint32 ret = 0;

    for(chip_idx = 0; chip_idx < g_poe_chip_num; chip_idx++)
    {
        hdl = g_poe_hdl[chip_idx];
        if(NULL == hdl)
        {
            DRV_LOG_ERR("POE sys pm: get master hdl err.");
            return RESULT_ERROR;   
        }

        para.val = data;
        para.len = 2;
        para.offset = POE_CLEAR_INTR_REG;

        ret += hdl->reg_read(hdl, &para);
        /* poe chip can't distinguish which port's intr occurs, so have to think about all ports */
        hdl->poe_chip_intr = (data[0] << 8 | data[1]) ? 0x0fff : 0x0;
    }
    
    return ret;
}

int32
poe_get_port_intr(uint32 port_id, poe_port_intr_valid_t *valid)
{
    poe_hdl_t* hdl = NULL;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */

    
    if(NULL == valid)
    {
        DRV_LOG_ERR("poe_get_port_intr: Invalid parameter.");
        return RESULT_ERROR;
    }

    hdl = get_poe_hdl(port_id);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE _get_port_intr: Invalid parameter.");
        *valid = POE_PORT_INTR_INVALID;
        return RESULT_ERROR;
    }

    /* logic port idx map to chip internal port idx and port_info[] array idx */
    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;

    *valid = ((hdl->poe_chip_intr >> map_port_id) & 0x1) ? POE_PORT_INTR_VALID : POE_PORT_INTR_INVALID;
    hdl->poe_chip_intr &= ~(0x1 << map_port_id);

    return RESULT_OK;
}

/**********************************************************
 *  Name:       : poe_get_port_status
 *  Purpose     : LCM get poe port status;
 *  Input       : state info, state change;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
int32
poe_get_port_status(int32 port_id, glb_poe_port_stat_info_t* stat_info, glb_poe_port_stat_change_t* stat_change)
{
    poe_hdl_t* hdl;
    poe_port_info_t* port_info;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */

    if(NULL == stat_info || NULL == stat_change)
    {
        DRV_LOG_ERR("POE poe_get_port_status: Invalid parameter.");
        return RESULT_ERROR;
    }
    
    hdl = get_poe_hdl(port_id);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE get port status: port idx %d, Get poe hdl err.",
            port_id + 1);
        return RESULT_ERROR;  
    }

    /* get chip internal port and hdl port index */
    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;
    port_info = hdl->port_info;
    //sal_mutex_lock(port_info[map_port_id].pmutex);
    
    stat_info->admin = port_info[map_port_id].stat_info.admin;
    stat_info->aver_consump = port_info[map_port_id].stat_info.aver_consump;
    stat_info->budget = port_info[map_port_id].stat_info.budget;
    stat_info->class = port_info[map_port_id].stat_info.class;
    stat_info->cur_consump = port_info[map_port_id].stat_info.cur_consump;
    stat_info->oper = port_info[map_port_id].stat_info.oper;
    stat_info->peak_consump = port_info[map_port_id].stat_info.peak_consump;
    stat_info->priority = port_info[map_port_id].stat_info.priority;
    sal_memcpy(stat_change, &port_stat_change[port_id], sizeof(glb_poe_port_stat_change_t));

    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE poe_get_port_status: port idx %d, admin %d, aver_consump %d, \
        budget %d, class %d, cur_consump %d, oper %d, peak_consump %d, priority %d.\n",
        port_id + 1, stat_info->admin, stat_info->aver_consump, stat_info->budget, stat_info->class,
        stat_info->cur_consump, stat_info->oper, stat_info->peak_consump, stat_info->priority);

    return RESULT_OK;
}

/**********************************************************
 *  Name:       : poe_get_sys_status
 *  Purpose     : LCM get poe system status;
 *  Input       : state info, state change;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
int32 
poe_get_sys_status(glb_poe_sys_stat_info_t* stat_info, glb_poe_sys_stat_change_t* stat_change)
{
    poe_hdl_t* hdl;
    poe_sys_info_t* sys_info;

    
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE poe_get_sys_status: begin.\n");

    if(NULL == stat_change || NULL == stat_change)
    {
        DRV_LOG_ERR("POE poe_get_sys_status: Invalid parameter.");
        return RESULT_ERROR;
    }
    
    hdl = get_poe_master_hdl();
    if(NULL == hdl)
    {
        DRV_LOG_ERR("POE poe_get_sys_status: Get poe hdl err.");
        return RESULT_ERROR;          
    }
    
    sys_info = &hdl->sys_info;
    //sal_mutex_lock(sys_info->pmutex);

    stat_info->aver_consump = sys_info->stat_info.aver_consump;
    stat_info->aver_volt = sys_info->stat_info.aver_volt;
    stat_info->budget = sys_info->stat_info.budget;
    stat_info->budget_reserved = sys_info->stat_info.budget_reserved;
    stat_info->budget_warn_threshold = sys_info->stat_info.budget_warn_threshold;
    stat_info->cur_consump = sys_info->stat_info.cur_consump;
    stat_info->cur_volt = sys_info->stat_info.cur_volt;
    stat_info->legacy_cap = sys_info->stat_info.legacy_cap;
    stat_info->peak_consump = sys_info->stat_info.peak_consump;
    stat_info->peak_volt = sys_info->stat_info.peak_volt;
    stat_info->pm = sys_info->stat_info.pm;
    sal_memcpy(stat_change, sys_stat_change, sizeof(glb_poe_sys_stat_change_t));

    //sal_mutex_unlock(sys_info->pmutex);

    return RESULT_OK;
}

static int32
poe_get_chip_sys_status(glb_poe_sys_stat_change_t* stat_change)
{
    poe_hdl_t* hdl;
    poe_para_t para = {0};
    poe_sys_info_t* sys_info;
    uint8 data[2];
    glb_poe_sys_stat_info_t stat_info = {0, };
    uint32 reg_val = 0;
    int32 chip_idx, ret = 0;

    para.len = 2;
    para.val = data;

    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE poe_get_chip_sys_status: begin.\n");

    if(NULL == stat_change)
    {
        DRV_LOG_ERR("POE poe_get_chip_sys_status: Invalid parameter.");
        return RESULT_ERROR;
    }
    
    hdl = get_poe_master_hdl();
    if(NULL == hdl)
    {
        DRV_LOG_ERR("POE poe_get_chip_sys_status: Get poe hdl err.");
        return RESULT_ERROR;          
    }
    
    sys_info = &hdl->sys_info;
    /* get system budget */
    for(chip_idx = 0; chip_idx < g_poe_chip_num; chip_idx++)
    {
        para.offset = POE_SYS_SLAVE0_REAL_POWER_CONS_REG + (2 * chip_idx);
        ret += hdl->reg_read(hdl, &para);
        reg_val += (uint32)((data[0] << 8 | data[1]) * 100); /* reg value is (data[0] << 8 | data[1]) * 0.1 * 1000 */
    }
    stat_info.cur_consump = reg_val;

    /* get system voltage */
    para.offset = POE_VMAIN_VOLTAGE_REG;
    ret += hdl->reg_read(hdl, &para);
    stat_info.cur_volt = (data[0] << 8 | data[1]) * 61;

    /*Fix bug 22905. change aver consump and peak consump arithmetic, current consump be 1% of aver consump.*/
    stat_info.aver_consump = (sys_info->stat_info.aver_consump * poe_aver_val_cnt + stat_info.cur_consump) / \
        (poe_aver_val_cnt + 1);/* / 100 * 100*/
    if(stat_info.cur_consump > sys_info->stat_info.peak_consump)
    {
        stat_info.peak_consump = stat_info.cur_consump;
    }
    else
    {
        stat_info.peak_consump = sys_info->stat_info.peak_consump;
    }
    /*Fix bug 22905. aver volt and peak volt arithmetic are same as consump.*/
    stat_info.aver_volt = (sys_info->stat_info.aver_volt * poe_aver_val_cnt + stat_info.cur_volt) / \
        (poe_aver_val_cnt + 1); /*/ 100 * 100*/
    if(stat_info.cur_volt > sys_info->stat_info.peak_volt)
    {
        stat_info.peak_volt = stat_info.cur_volt;
    }
    else
    {
        stat_info.peak_volt = sys_info->stat_info.peak_volt;
    }
    
    stat_info.budget = sys_info->mgt_info.budget;
    stat_info.budget_reserved = sys_info->mgt_info.budget_reserved;    
    stat_info.budget_warn_threshold = sys_info->mgt_info.budget_warn_thrshd;    
    stat_info.pm = sys_info->mgt_info.pm;
    stat_info.legacy_cap = sys_info->mgt_info.legacy_cap;

    if(poe_aver_val_cnt > POE_AVER_VAL_MAX_CNT)
    {
        poe_aver_val_cnt = POE_AVER_VAL_MAX_CNT;
    }
    else
    {
        poe_aver_val_cnt++;
    }
    
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE get chip sys status: aver_consump %d, aver_volt %d, budget %d, budget_reserved %d%%, \
        budget_warn_threshold %d%%,cur_consump %d,cur_volt %d,legacy_cap %d,peak_consump %d,peak_volt %d,pm %d\n",
        stat_info.aver_consump, stat_info.aver_volt,stat_info.budget, stat_info.budget_reserved, 
        stat_info.budget_warn_threshold, stat_info.cur_consump, stat_info.cur_volt,
        stat_info.legacy_cap, stat_info.peak_consump, stat_info.peak_volt, stat_info.pm);

    if(stat_info.aver_consump != sys_info->stat_info.aver_consump)
    {
        sys_info->stat_info.aver_consump = stat_info.aver_consump;
        stat_change->aver_consump_change = 1;
    }
    if(stat_info.aver_volt != sys_info->stat_info.aver_volt)
    {
        sys_info->stat_info.aver_volt = stat_info.aver_volt;
        stat_change->aver_volt_change = 1;
    }
    if(stat_info.budget != sys_info->stat_info.budget)
    {
        sys_info->stat_info.budget = stat_info.budget;
        stat_change->budget_change = 1;
    }
    if(stat_info.budget_reserved!= sys_info->stat_info.budget_reserved)
    {
        sys_info->stat_info.budget_reserved = stat_info.budget_reserved;
        stat_change->budget_reserved_change = 1;
    }
    if(stat_info.budget_warn_threshold != sys_info->stat_info.budget_warn_threshold)
    {
        sys_info->stat_info.budget_warn_threshold = stat_info.budget_warn_threshold;
        stat_change->budget_warn_threshold_change = 1;
    }
    if(stat_info.cur_consump != sys_info->stat_info.cur_consump)
    {
        sys_info->stat_info.cur_consump = stat_info.cur_consump;
        stat_change->cur_consump_change = 1;
    }
    if(stat_info.cur_volt != sys_info->stat_info.cur_volt)
    {
        sys_info->stat_info.cur_volt = stat_info.cur_volt;
        stat_change->cur_volt_change = 1;
    }
    if(stat_info.legacy_cap != sys_info->stat_info.legacy_cap)
    {
        sys_info->stat_info.legacy_cap = stat_info.legacy_cap;
        stat_change->legacy_cap_change = 1;
    }
    if(stat_info.peak_consump != sys_info->stat_info.peak_consump)
    {
        sys_info->stat_info.peak_consump = stat_info.peak_consump;
        stat_change->peak_consump_change = 1;
    }
    if(stat_info.peak_volt != sys_info->stat_info.peak_volt)
    {
        sys_info->stat_info.peak_volt = stat_info.peak_volt;
        stat_change->peak_volt_change= 1;
    }
    if(stat_info.pm != sys_info->stat_info.pm)
    {
        sys_info->stat_info.pm = stat_info.pm;
        stat_change->pm_change = 1;
    }

    return ret;
}

/* If port disable, needn't to update the port
   note: must read 0x0324 after get status */
static int32
poe_get_chip_port_status(uint32 port_id, glb_poe_port_stat_change_t* stat_change)
{
    poe_hdl_t* hdl;
    poe_para_t para = {0};
    poe_port_info_t* port_info;
    glb_poe_port_stat_info_t stat_info;
    uint8 data[2];
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    uint32 reg_val = 0;
    int32 ret = 0;

    para.len = 2;
    para.val = data;

    if(NULL == stat_change)
    {
        DRV_LOG_ERR("POE poe_get_chip_port_status: Invalid parameter.");
        return RESULT_ERROR;
    }

    hdl = get_poe_hdl(port_id);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE get chip port status: port idx %d, Get poe hdl err.",
            port_id + 1);
        return RESULT_ERROR;  
    }
    
    /* get chip internal port and hdl port index */
    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;
    port_info = hdl->port_info;
    
    stat_info.admin = port_info[map_port_id].mgt_info.admin;
    stat_info.budget = (stat_info.admin == POE_FORCE) ? POE_PORT_FORCE_POWER_BUDGET : port_info[map_port_id].mgt_info.budget;
    stat_info.priority = port_info[map_port_id].mgt_info.priority;

    if(stat_info.admin != port_info[map_port_id].stat_info.admin)
    {
        port_info[map_port_id].stat_info.admin = stat_info.admin;
        stat_change->admin_change = 1;
    }
    if(stat_info.budget != port_info[map_port_id].stat_info.budget)
    {
        port_info[map_port_id].stat_info.budget = stat_info.budget;
        stat_change->budget_change = 1;
    }

    if(stat_info.priority != port_info[map_port_id].stat_info.priority)
    {
        port_info[map_port_id].stat_info.priority = stat_info.priority;
        stat_change->priority_change = 1;
    }

    para.offset = POE_PORT0_STATUS_REG + (2 * map_port_id);

    ret += hdl->reg_read(hdl, &para);    
    /*Fix bug 23057, for chip status 2,3,8 should be normal, but here set to POE_PD_UNKNOWN, 
       this cause port be into protection off status.*/
    switch(data[1])
    {
        case PD69012_DISABLE:
            stat_info.oper = POE_PD_OFF;
            break;
        case PD69012_POWER_ON:
        case PD69012_POWER_FORCE_ON:
        case PD69012_TEST_IN_FORCE_ON:
            stat_info.oper = POE_PD_ON;
            break;
        case PD69012_STARTING_UP:
        case PD69012_POWER_IN_FORCE_ON:
        case PD69012_DETECTION:
        case PD69012_INVALID_SIGNATURE:
        case PD69012_VALID_SIGNATURE:
            stat_info.oper = POE_PD_DETECTION;
            break;
        case PD69012_CLASS_ERROR:
        case PD69012_STARTUP_OVL:
        case PD69012_STARTUP_UDL:
        case PD69012_STARTUP_SHORT:
            stat_info.oper = POE_PD_STARTUP_ERROR;
            break;
        case PD69012_DVDT_FAIL:
        case PD69012_UDL:
        case PD69012_SHORT_CIRCUIT:
            stat_info.oper = POE_PD_POWERUP_ERROR;
            break;
        case PD69012_TEST_FORCE_ON_ERR:
            stat_info.oper = POE_PD_FORCE_ERROR;
            break;
        case PD69012_OVL:
            stat_info.oper = POE_PD_OVL;
            break;
        case PD69012_CHIP_PM_OFF:
            stat_info.oper = POE_PD_OVL_OFF;
            break;
        default:
            stat_info.oper = POE_PD_UNKNOWN;
            break;
    }

    /* fix bug:18657 during port connected, port status isn't POE_PD_ON and consumption is 0, then calc system priority,
       but during get system status, the port maybe have POE_PD_ON and consumption isn't 0, system cur_consumption maybe overload,
       based on priority rule: system will disconnect other port*/

    /* The below three status is setted by soft */
    if((POE_PD_OVL_OFF == port_info[map_port_id].stat_info.oper ||
        POE_PD_PRIORITY_OFF == port_info[map_port_id].stat_info.oper ||
        POE_PD_ERR_DISABLE_OFF == port_info[map_port_id].stat_info.oper) && 
        POE_PD_OFF == stat_info.oper)
    {
        /*Fix bug 23096. When port in protection off status, and if admin is disable, the oper should return to disable.*/
        if((POE_DISABLE != stat_info.admin)||(POE_PD_ERR_DISABLE_OFF != port_info[map_port_id].stat_info.oper))
        {
            stat_info.oper = port_info[map_port_id].stat_info.oper;
            stat_change->oper_change = 0;
        }
    }

    if((stat_info.oper == POE_PD_UNKNOWN) && (port_info[map_port_id].stat_info.oper == POE_PD_UNKNOWN))
    {
        /* be sure that port is err-disable, the acction will be dealed by poe_sys_pm_soft_err_dis_calc() */
        POE_TIMER_START(&port_info[map_port_id].err_dis_timer, POE_ERR_DISABLE_TIMER_CNT);
        port_info[map_port_id].port_status_reg = data[0] << 8 | data[1];        
        port_info[map_port_id].stat_change_cnt = POE_ERR_DISABLE_MAX;
        stat_change->oper_change = 0;
    }
    else
    {   
        if(stat_info.oper != port_info[map_port_id].stat_info.oper)
        {
            port_info[map_port_id].stat_info.oper = stat_info.oper;
            stat_change->oper_change = 1;
        }
        /*Fix bug 23057, When not in detection status, then check status register change, start error disable count.
          This avoid that port connect to a Not PoE device, and chip status continue change in detection status,cause 
          protection off. */
        if((stat_info.oper != POE_PD_DETECTION)&&(port_info[map_port_id].port_status_reg != (data[0] << 8 | data[1])))
        {
            if(port_info[map_port_id].stat_change_cnt == 0)
            {
                POE_TIMER_START(&port_info[map_port_id].err_dis_timer, POE_ERR_DISABLE_TIMER_CNT);
            }
            port_info[map_port_id].port_status_reg = data[0] << 8 | data[1];        
            port_info[map_port_id].stat_change_cnt++;
        }

        if(stat_info.oper == POE_PD_UNKNOWN)
        {
            /* not stable, and wait for next poe_sys_soft_calc*/
           return POE_PORT_STATUS_NOT_STABLE;
        }
    }

    /* As not support intr, HW real status can't be take effect in time, soft calc the status*/
    if(port_info[map_port_id].port_status_reg == (data[0] << 8 | data[1]) && POE_PD_ON != stat_info.oper)
    {
        stat_info.class = POE_CLASS_NOT_DEFINED;
        stat_info.cur_consump = 0;
    }
    else
    {
        /* POE get class */
        para.offset = POE_PORT0_CLASS_REG + (2 * map_port_id);
        ret += hdl->reg_read(hdl, &para);
        reg_val = data[0];
        if(reg_val > POE_CLASS4)
        {
            stat_info.class = POE_CLASS_NOT_DEFINED;
        }
        else
        {
            stat_info.class = reg_val;
        }

        /* POE get consumption */
        para.offset = POE_PORT0_POWER_CONS_REG + (2 * map_port_id);
        ret += hdl->reg_read(hdl, &para);
        stat_info.cur_consump = (data[0] << 8 | data[1]) * 100; /* reg value * 0.1 * 1000 */
    }

    /*Fix bug 22905. change aver consump and peak consump arithmetic, current consump be 1% of aver consump.*/
    stat_info.aver_consump = (port_info[map_port_id].stat_info.aver_consump * poe_aver_val_cnt + stat_info.cur_consump) / \
        (poe_aver_val_cnt + 1); /*/ 100 * 100*/
    if(stat_info.cur_consump > port_info[map_port_id].stat_info.peak_consump)
    {
        stat_info.peak_consump = stat_info.cur_consump;
    }
    else
    {
        stat_info.peak_consump = port_info[map_port_id].stat_info.peak_consump;
    }

    if(stat_info.class != port_info[map_port_id].stat_info.class)
    {
        port_info[map_port_id].stat_info.class = stat_info.class;
        stat_change->class_change = 1;
    }

    if(stat_info.cur_consump != port_info[map_port_id].stat_info.cur_consump)
    {
        port_info[map_port_id].stat_info.cur_consump = stat_info.cur_consump;
        stat_change->cur_consump_change = 1;
    }
    if(stat_info.aver_consump != port_info[map_port_id].stat_info.aver_consump)
    {
        port_info[map_port_id].stat_info.aver_consump = stat_info.aver_consump;
        stat_change->aver_consump_change = 1;
    }
    if(stat_info.peak_consump != port_info[map_port_id].stat_info.peak_consump)
    {
        port_info[map_port_id].stat_info.peak_consump = stat_info.peak_consump;
        stat_change->peak_consump_change = 1;
    }
    
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE get chip port status: port idx %d,admin %d,aver_consump %d,budget %d,class %d, \
        cur_consump %d,oper %d,peak_consump %d,priority %d.\n",
        port_id + 1, stat_info.admin, stat_info.aver_consump, stat_info.budget, stat_info.class,
        stat_info.cur_consump, stat_info.oper, stat_info.peak_consump, stat_info.priority);

    return ret;
}

/* if port oper is setted priority off by soft mgt, after restore, the oper is unknown.*/
/* new status will updated by next timer or interrupt */
/**********************************************************
 *  Name:       : poe_set_port_oper_by_soft;
 *  Purpose     : set poe port oper by soft;
 *  Input       : port num, oper status;
 *  Output      : N/A
 *  Return      : err: -1 , ok: 0, set pri success: 1
 *  Note        : N/A
 **********************************************************/
static int32
poe_set_port_oper_priority_by_soft(int32 port_idx, poe_oper_t oper)
{
    poe_port_info_t* port_info;
    poe_sys_info_t* sys_info;
    poe_hdl_t* hdl;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    poe_para_t para = {0};
    uint8 data[2];
    uint16 reg_val;
    int32 ret = 0;

    para.len = 2;
    para.val = data;
    hdl = get_poe_master_hdl();
    if(NULL == hdl)
    {
        DRV_LOG_ERR("POE set port priority off: Get poe hdl err.");
        return RESULT_ERROR;          
    }
    sys_info = &hdl->sys_info;
    hdl = get_poe_hdl(port_idx);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE set port priority off: port idx %d, Get poe hdl err.",
            port_idx + 1);
        return RESULT_ERROR;  
    }
    map_port_id = g_poe_panel_port_info[port_idx].poe_chip_port_idx;
    port_info = hdl->port_info;
    
    if(POE_PD_PRIORITY_OFF == oper)
    {
        /* Note: if port overload but power on by chip, be dealed before */
        if(POE_PD_ON == port_info[map_port_id].stat_info.oper)
        {
            if(sys_info->priority_off_cnt >= g_port_num)
            {
                DRV_LOG_ERR("POE set port priority off: sys cnt err.");
                return RESULT_ERROR;
            }
            para.offset = POE_ALL_PORT_ADMIN_REG;
            ret += hdl->reg_read(hdl, &para);
            reg_val = data[0] << 8 | data[1];
            reg_val |= (0x1 << map_port_id);
            data[0] = (reg_val >> 8) & 0xff;
            data[1] = reg_val & 0xff;
            ret = hdl->reg_write(hdl, &para);
            //sal_udelay(50000);
            if(ret)
            {
                DRV_LOG_ERR("POE set port priority off: write reg fail!");
                return RESULT_ERROR;
            }
            /* set pri off success: retunr 1 */
            ret = 1;
            /* POE chip real status will updated by interrupt */
            sys_info->stat_info.cur_consump -= port_info[map_port_id].stat_info.cur_consump;
            sys_info->priority_off_cnt += 1;
            sys_stat_change->cur_consump_change = 1;
            
            port_info[map_port_id].stat_info.oper = POE_PD_PRIORITY_OFF;
            port_info[map_port_id].stat_info.pre_consumption = port_info[map_port_id].stat_info.cur_consump;
            port_info[map_port_id].stat_info.cur_consump = 0;
            port_stat_change[port_idx].cur_consump_change = 1;
            port_stat_change[port_idx].oper_change = 1;

            DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "port %d, status change from ON to priority OFF.",port_idx+1);
        }
    }
    else if(POE_PD_OPER_MAX == oper)
    {
        if(POE_PD_PRIORITY_OFF == port_info[map_port_id].stat_info.oper)
        {
            if(sys_info->priority_off_cnt <= 0)
            {
                return RESULT_ERROR;
            }
            /* protect from that restore too much */
            if((sys_info->stat_info.cur_consump + port_info[map_port_id].stat_info.pre_consumption) > \
                (sys_info->stat_info.budget * (100 - sys_info->stat_info.budget_reserved) / 100))
            {
                return RESULT_OK;
            }
            para.offset = POE_ALL_PORT_ADMIN_REG;
            ret += hdl->reg_read(hdl, &para);
            reg_val = data[0] << 8 | data[1];
            reg_val &= ~(0x1 << map_port_id);
            data[0] = (reg_val >> 8) & 0xff;
            data[1] = reg_val & 0xff;
            ret += hdl->reg_write(hdl, &para);
            //sal_udelay(50000);
            
            if(ret)
            {
                DRV_LOG_ERR("set port oper by soft err!");
                return RESULT_ERROR;
            }
            /* restore priority off success: return 1 */
            ret = 1;

            /* POE chip real status will updated by interrupt */
            sys_info->stat_info.cur_consump += port_info[map_port_id].stat_info.pre_consumption;
            sys_info->priority_off_cnt -= 1;
            sys_stat_change->cur_consump_change = 1;

            port_info[map_port_id].stat_info.oper = POE_PD_OPER_MAX;
            port_stat_change[port_idx].oper_change = 1;
            
            DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "port %d, status change from priority off to normal.", port_idx+1);            
        }        
    }

    return ret;
}


/* if port oper is setted OVL off by soft mgt, after restore, the oper is unknown */
/* new status will updated by next timer or interrupt */
/**********************************************************
 *  Name:       : poe_set_port_oper_by_soft;
 *  Purpose     : set poe port oper by soft;
 *  Input       : port num, oper status;
 *  Output      : N/A
 *  Return      : err: -1 , ok: 0, set pri success: 1
 *  Note        : N/A
 **********************************************************/
static int32
poe_set_port_oper_ovl_by_soft(int32 port_idx, poe_oper_t oper)
{
    poe_port_info_t* port_info;
    poe_hdl_t* hdl;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    poe_para_t para = {0};
    uint8 data[2];
    uint16 reg_val;
    int32 ret = 0;

    para.len = 2;
    para.val = data;
    
    hdl = get_poe_hdl(port_idx);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE set port priority off: port idx %d, Get poe hdl err.",
            port_idx + 1);
        return RESULT_ERROR;  
    }
    map_port_id = g_poe_panel_port_info[port_idx].poe_chip_port_idx;
    port_info = hdl->port_info;

    if(POE_PD_OVL_OFF == oper)
    {
        /* protect double setting from that port always ovl off */
        if(port_stat_change[port_idx].oper_change == 1)
        {
            para.offset = POE_ALL_PORT_ADMIN_REG;
            ret += hdl->reg_read(hdl, &para);
            reg_val = data[0] << 8 | data[1];
            reg_val |= (0x1 << map_port_id);
            data[0] = (reg_val >> 8) & 0xff;
            data[1] = reg_val & 0xff;
            ret += hdl->reg_write(hdl, &para);
            //sal_udelay(50000);
            
            if(ret)
            {
                DRV_LOG_ERR("set port oper by soft err!");
                return RESULT_ERROR;
            }
            /* set ovl off success: return 1 */
            ret = 1;
            port_info[map_port_id].stat_info.pre_consumption = port_info[map_port_id].stat_info.cur_consump;
            port_info[map_port_id].stat_info.cur_consump = 0;
            port_stat_change[port_idx].cur_consump_change = 1;
            /* POE chip real status will updated by interrupt */

            DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "port %d, status change from ON to OVL OFF.",port_idx+1);
        }
    }
    else if(POE_PD_OPER_MAX == oper)
    {
        if(POE_PD_OVL_OFF == port_info[map_port_id].stat_info.oper)
        {
            para.offset = POE_ALL_PORT_ADMIN_REG;
            ret += hdl->reg_read(hdl, &para);
            reg_val = data[0] << 8 | data[1];
            reg_val &= ~(0x1 << map_port_id);
            data[0] = (reg_val >> 8) & 0xff;
            data[1] = reg_val & 0xff;
            ret += hdl->reg_write(hdl, &para);
            //sal_udelay(50000);
            
            if(ret)
            {
                DRV_LOG_ERR("set port oper by soft err!");
                return RESULT_ERROR;
            }
            /* restore ovl off success: return 1 */
            ret = 1;

            /* POE chip real status will updated by interrupt */
            port_info[map_port_id].stat_info.oper = POE_PD_OPER_MAX;
            port_stat_change[port_idx].oper_change = 1;
            
            DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "port %d, status change from ovl off to normal.", port_idx+1);
        }
    }

    return ret;
}

/**********************************************************
 *  Name:       : poe_set_port_oper_by_soft;
 *  Purpose     : ovl calc: one function of sys pm soft calc;
 *  Input       : port num;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
static int32
poe_sys_pm_soft_ovl_calc(int32 port_id)
{
    poe_port_info_t* port_info;    
    poe_hdl_t* hdl;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    int32 ret = 0;
    
    if(NULL == (hdl = get_poe_hdl(port_id)))
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"poe_sys_pm_soft_ovl_calc: port idx %d, Get poe hdl err.",
            port_id + 1);
        return RESULT_ERROR;
    }
    
    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;
    port_info = hdl->port_info;
    
    /* 2.adjudge whether the port is overload off */        
    /* software double check whether the port is overload, if hardware is overload but still power on */
    if((port_info[map_port_id].stat_info.cur_consump > port_info[map_port_id].stat_info.budget || \
        port_info[map_port_id].stat_info.oper == POE_PD_OVL))
    {
       port_info[map_port_id].stat_info.oper = POE_PD_OVL_OFF;
       port_stat_change[port_id].oper_change = 1;
    }
    if(port_info[map_port_id].stat_info.oper == POE_PD_OVL_OFF)
    {
        ret = poe_set_port_oper_ovl_by_soft(port_id, POE_PD_OVL_OFF);
        if(ret == -1)
        {
            DRV_LOG_ERR("poe_sys_pm_soft_ovl_calc: write reg fail.");
            return RESULT_ERROR;
        }
        else if(ret == 0)
        {
            if(port_info[map_port_id].stat_info.budget > port_info[map_port_id].stat_info.pre_consumption)
            {
                /* if user change the port budget and budget > pre_con, exit the ovl punish */
                ret = poe_set_port_oper_ovl_by_soft(port_id, POE_PD_OPER_MAX);
            }
            else
            {
                /* if port oper is always in ovl off, reduce the punish_cnt step by step */
                sal_gettimeofday(&(port_info[map_port_id].ovl_timer.now));
                if(POE_TIMER_TIMEOUT(&port_info[map_port_id].ovl_timer))
                {
                    /* if the OVL port power on, software need  wait at least 1s to get the port status, and pm_soft_mode_calc
                    timer is 3s, so let the power up status dealed by hw interrupt or next timer */
                    ret = poe_set_port_oper_ovl_by_soft(port_id, POE_PD_OPER_MAX);
                }
            }
        }
        else if(ret == 1)
        {
            /* if soft set ovl off success, add punish_cnt */
            if((port_info[map_port_id].punish_cnt = port_info[map_port_id].punish_cnt + 1) > POE_PUNISH_CNT_MAX)
            {
                port_info[map_port_id].punish_cnt = POE_PUNISH_CNT_MAX;
            }
            POE_TIMER_START(&port_info[map_port_id].ovl_timer, port_info[map_port_id].punish_cnt*POE_PUNISH_CNT_INTERVAL);
        }
    }
    else
    {
        /* if port works normal later, the pre_punish_cnt will reduce step by step */
        if(port_info[map_port_id].punish_cnt > 0)
        {
            if(port_info[map_port_id].punish_cnt_reduce == 0)
            {
                POE_TIMER_START(&port_info[map_port_id].ovl_cnt_timer, POE_PUNISH_CNT_INTERVAL);
                port_info[map_port_id].punish_cnt_reduce = 1;
            }
            else
            {
                sal_gettimeofday(&(port_info[map_port_id].ovl_cnt_timer.now));
                if(POE_TIMER_TIMEOUT(&port_info[map_port_id].ovl_cnt_timer))
                {
                    port_info[map_port_id].punish_cnt_reduce = 0;
                    port_info[map_port_id].punish_cnt--;
                }
            }
        }
    }

    return RESULT_OK;
}

/**********************************************************
 *  Name:       : poe_sys_pm_soft_err_dis_calc;
 *  Purpose     : err disable calc: one function of sys pm soft calc;
 *  Input       : port num;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
static int32
poe_sys_pm_soft_err_dis_calc(int32 port_id)
{
    poe_port_info_t* port_info;    
    poe_hdl_t* hdl;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */    
    poe_para_t para = {0};
    uint8 data[2];
    int32 ret = 0;

    para.len = 2;
    para.val = data;

    if(NULL == (hdl = get_poe_hdl(port_id)))
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"poe_sys_pm_soft_err_dis_calc: port idx %d, Get poe hdl err.",
            port_id + 1);
        return RESULT_ERROR;
    }
    
    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;
    port_info = hdl->port_info;

    if(port_info[map_port_id].stat_change_cnt == 0)
    {
        return RESULT_OK;
    }

    if(port_info[map_port_id].stat_change_cnt == POE_ERR_DISABLE_MAX)
    {
        /* can't set stat to two soft define_self status */
        if(POE_PD_OVL_OFF != port_info[map_port_id].stat_info.oper &&
            POE_PD_PRIORITY_OFF != port_info[map_port_id].stat_info.oper)
        {
            /* disable the port, need to enable it by user */
            para.offset = POE_PORT0_CFG_REG + (2 * map_port_id);
            ret += hdl->reg_read(hdl, &para);            
            data[1] = (data[1] & (~0x3)) | 0x0;
            ret += hdl->reg_write(hdl, &para);
            port_info[map_port_id].stat_change_cnt = 0;
            //port_info[map_port_id].stat_change_interval = 0;
            port_info[map_port_id].stat_info.oper = POE_PD_ERR_DISABLE_OFF;
            port_stat_change[port_id].oper_change = 1;

            /* mostly cur_consumption is 0 */
            if(port_info[map_port_id].stat_info.cur_consump != 0)
            {
                port_info[map_port_id].stat_info.cur_consump = 0;
                port_stat_change[port_id].cur_consump_change = 1;
            }
        }
        else
        {
            port_info[map_port_id].stat_change_cnt = 0;
        }
    }
    else if(port_info[map_port_id].stat_change_cnt < POE_ERR_DISABLE_MAX &&
         0 < port_info[map_port_id].stat_change_cnt)
    {
        sal_gettimeofday(&(port_info[map_port_id].err_dis_timer.now));
        if(POE_TIMER_TIMEOUT(&port_info[map_port_id].err_dis_timer))
        {
            port_info[map_port_id].stat_change_cnt = 0;
        }
    }

    return ret;
}

/**********************************************************
 *  Name:       : poe_get_port_priority_by_soft;
 *  Purpose     : get ports array of which is snatched consumption as priority by soft;
 *  Input       : pri_on port, pri_on list, pri_off_num;
 *  Output      : pri_off_array, pri_off_num;
 *  Return      : err: -1 , won't process: 0, get pri success: 1, get pri fail: 2, system free 3;
 *  Note        : N/A
 **********************************************************/
int32
poe_get_port_priority_by_soft(int32 pri_on_port_id, int32 pri_on_list_pri, int32* pri_off_port_arry, int32* pri_off_port_num)
{
    int32 tmp_list_pri;
    ctclib_list_node_t *tmp_node;
    ctclib_list_t *tmp_list;
    poe_list_port_info_t *port_store;
    poe_port_info_t* port_info;
    poe_sys_info_t* sys_info;
    poe_hdl_t* hdl;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    int32 pri_off_port_cnt = 0,ret = 0;
    int32 pri_off_port_max = *pri_off_port_num;
    int32 consump_need, consump_tmp;
    int32 priority_end = 0, same_list = 0;

    if(NULL == pri_off_port_arry || NULL == pri_off_port_num || 0 == pri_off_port_max)
    {
        return -1;
    }
    if(pri_on_list_pri < POE_PORT_PRI_NONE || pri_on_list_pri > POE_PORT_PRI_CRITICAL)
    {
        return -1;
    }
    
    hdl = get_poe_master_hdl();
    if(NULL == hdl)
    {
        DRV_LOG_ERR("POE get port priority off: Get poe hdl err.");
        return -1;          
    }
    sys_info = &hdl->sys_info;
    consump_tmp = (sys_info->stat_info.budget * (100 - sys_info->stat_info.budget_reserved) / 100) - sys_info->stat_info.cur_consump;

    hdl = get_poe_hdl(pri_on_port_id);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE get port priority off: port idx %d, Get poe hdl err.",
            pri_on_port_id + 1);
        return -1;  
    }
    map_port_id = g_poe_panel_port_info[pri_on_port_id].poe_chip_port_idx;
    port_info = hdl->port_info;
    consump_need  = port_info[map_port_id].stat_info.pre_consumption;

    if(POE_PD_PRIORITY_OFF != port_info[map_port_id].stat_info.oper)
    {
        return 0;
    }

    /* system free consumption, needn't snatch from other port */
    if(consump_tmp >= consump_need)
    {
        //sys_info->stat_info.budget -= port_info[map_port_id].stat_info.pre_consumption;
        return 3;
    }
    
    if(pri_on_list_pri == POE_PORT_PRI_NONE)
    {
        /* belong to dynamic power management */
        ctclib_list_for_each(tmp_node, poe_list_priority_no)
        {
            port_store = ctclib_container_of(tmp_node, poe_list_port_info_t, node);
            /* higher panel port num has the lower priority */            
            if(port_store->port_num <= pri_on_port_id)
            {
                break;
            }
            hdl = get_poe_hdl(port_store->port_num);
            if(NULL == hdl)
            {
                DRV_LOG_ERR("POE set port priority off: port idx %d, Get poe hdl err.",
                    pri_on_port_id + 1);
                return -1;  
            }
            map_port_id = g_poe_panel_port_info[port_store->port_num].poe_chip_port_idx;
            port_info = hdl->port_info;
            if(POE_PD_ON != port_info[map_port_id].stat_info.oper)
            {
                continue;
            }
            /* find a port */
            /* make sure enough space to  store the port_num */
            if((++pri_off_port_cnt) <= pri_off_port_max)
            {
                *(pri_off_port_arry++) = port_store->port_num;                
                ret = 1;
            }
            else
            {
                pri_off_port_cnt--;
                break;
            }
            /* make sure enough consumption freed */
            consump_tmp += port_info[map_port_id].stat_info.cur_consump;
            if(consump_tmp >= consump_need)
            {
                break;
            }
        }

        if(ret == 0)
        {
            /* can't find port */
            return 2;
        }
        else if(ret == -1)
        {
            /* error occurs while processing */
            return -1;
        }
        else if(ret == 1)
        {            
            /* find port and return the real cnt of array member */
            *pri_off_port_num = pri_off_port_cnt;
            return 1;
        }
    }
    else
    {
        /* belong to static power managemnet */
        for(tmp_list_pri = POE_PORT_PRI_LOW; tmp_list_pri <= pri_on_list_pri; tmp_list_pri++)
        {
            tmp_list = (tmp_list_pri == POE_PORT_PRI_LOW) ? poe_list_priority_low : \
                ((tmp_list_pri == POE_PORT_PRI_HIGH) ? poe_list_priority_high : poe_list_priority_critical);
            
            same_list = (tmp_list_pri == pri_on_list_pri) ? 1 : 0;
            ctclib_list_for_each(tmp_node, tmp_list)
            {
                port_store = ctclib_container_of(tmp_node, poe_list_port_info_t, node);
                if(same_list)
                {                    
                    /* higher panel port num has the lower priority */
                    if(port_store->port_num <= pri_on_port_id)
                    {
                        priority_end = 1;
                        break;
                    }
                }
                hdl = get_poe_hdl(port_store->port_num);
                if(NULL == hdl)
                {
                    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE set port priority off: port idx %d, Get poe hdl err.",
                        pri_on_port_id + 1);
                    return -1;  
                }
                map_port_id = g_poe_panel_port_info[port_store->port_num].poe_chip_port_idx;
                port_info = hdl->port_info;
                if(POE_PD_ON != port_info[map_port_id].stat_info.oper)
                {
                    continue;
                }
                /* find a port */
                /* make sure enough space to  store the port_num */
                if((++pri_off_port_cnt) <= pri_off_port_max)
                {
                    *(pri_off_port_arry++) = port_store->port_num;                
                    ret = 1;
                }
                else
                {
                    pri_off_port_cnt--;
                    priority_end = 1;
                    break;
                }
                /* make sure enough consumption freed */
                consump_tmp += port_info[map_port_id].stat_info.cur_consump;
                if(consump_tmp >= consump_need)
                {
                    priority_end = 1;
                    break;
                }
            }
            if(priority_end == 1)
            {
                break;
            }
        }
        
        if(ret == 0)
        {
            /* can't find port */
            return 2;
        }
        else if(ret == -1)
        {
            /* error occurs while processing */
            return -1;
        }
        else if(ret == 1)
        {            
            /* find port and return the real cnt of array member */
            *pri_off_port_num = pri_off_port_cnt;
            return 1;
        }            
    }

    return 0;
}

/**********************************************************
 *  Name:       : poe_sys_pm_soft_pri_calc;
 *  Purpose     : priority calc: one function of sys pm soft calc;
 *  Input       : port num;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
static int32
poe_sys_pm_soft_pri_calc(void)
{
    int32 list_priority, priority_end = 0;
    poe_sys_info_t* sys_info;
    poe_hdl_t* hdl;
    ctclib_list_node_t *tmp_node;
    ctclib_list_t *tmp_list;
    poe_list_port_info_t *port_store;
    int ret = 0, pri_off_port_num = 100;
    int32 pri_off_port_arry[100]={0,};
    int32 pri_off_port_idx, pri_off_cnt_tmp;

    hdl = get_poe_master_hdl();
    if(NULL == hdl)
    {
        DRV_LOG_ERR("poe_sys_pm_soft_pri_calc: Get poe hdl err.");
        return RESULT_ERROR;          
    }
    sys_info = &hdl->sys_info;

    /* if system power > system budget, the behavior is based on chip internal process */
    if(sys_info->stat_info.cur_consump > (sys_info->stat_info.budget * (100 - sys_info->stat_info.budget_reserved) / 100))    
    {
        if(POE_PM_DYNAMIC == poe_sys_pm)
        {
            /* rule 1: same priority, only care about panel number. */
            /* Note: port number from high to low */
            ctclib_list_for_each(tmp_node, poe_list_priority_no)
            {
                port_store = ctclib_container_of(tmp_node, poe_list_port_info_t, node);
                ret = poe_set_port_oper_priority_by_soft(port_store->port_num, POE_PD_PRIORITY_OFF);
                if(ret == -1)
                {
                    DRV_LOG_ERR("poe_sys_pm_soft_pri_calc: port %d,write reg fail.", port_store->port_num + 1);
                    return RESULT_ERROR;
                }
                else if(ret == 0)
                {
                    continue;
                }
                else if(ret == 1)
                {
                    if(sys_info->stat_info.cur_consump <= (sys_info->stat_info.budget * (100 - sys_info->stat_info.budget_reserved) / 100))
                    {
                        break;
                    }                    
                }
            }
        }
        else if(POE_PM_STATIC == poe_sys_pm)
        {
            /* rule 1: same priority, only care about panel number */
            /* rule 2: differrent priority */
            /* Note: port number from high to low */
            priority_end = 0;
            for(list_priority = POE_PORT_PRI_LOW; list_priority < POE_PORT_PRI_MAX; list_priority++)
            {                
                tmp_list = (list_priority == POE_PORT_PRI_LOW) ? poe_list_priority_low : \
                    ((list_priority == POE_PORT_PRI_HIGH) ? poe_list_priority_high : poe_list_priority_critical);

                ctclib_list_for_each(tmp_node, tmp_list)
                {
                    port_store = ctclib_container_of(tmp_node, poe_list_port_info_t, node);
                    ret = poe_set_port_oper_priority_by_soft(port_store->port_num, POE_PD_PRIORITY_OFF);
                    if(ret == -1)
                    {
                        DRV_LOG_ERR("poe_sys_pm_soft_pri_calc: port %d,write reg fail.", port_store->port_num + 1);
                        return RESULT_ERROR;
                    }
                    else if(ret == 0)
                    {
                        continue;
                    }
                    else if(ret == 1)
                    {
                        if(sys_info->stat_info.cur_consump < (sys_info->stat_info.budget * (100 - sys_info->stat_info.budget_reserved) / 100))
                        {
                            priority_end = 1;
                            break; /* break ctclib_list_for_each */
                        }                    
                    }
                }
                
                if(priority_end)
                {
                    break; /* break for(list_priority...) */
                }
            }
        }
    }
    /* Note: off_cnt, if no priority off, need not to do this */
    else if(sys_info->priority_off_cnt)
    {
        pri_off_cnt_tmp = sys_info->priority_off_cnt;

        /* restore the priority off */
        if(POE_PM_DYNAMIC == poe_sys_pm)
        {
            /* rule 1: same priority, only care about panel number. */
            /* Note: port number from low to high */
            ctclib_list_for_each_r(tmp_node, poe_list_priority_no)
            {
                port_store = ctclib_container_of(tmp_node, poe_list_port_info_t, node);
                sal_memset(pri_off_port_arry,0,100);
                pri_off_port_num = 100;
                ret = poe_get_port_priority_by_soft(port_store->port_num, POE_PORT_PRI_NONE, pri_off_port_arry, &pri_off_port_num);
                if(ret == -1)
                {
                    DRV_LOG_ERR("poe_sys_pm_soft_pri_calc: auto pm port %d fail.", port_store->port_num + 1);
                    return RESULT_ERROR;
                }
                else if(ret == 0)
                {
                    continue;
                }
                else if(ret == 1)
                {
                    for(pri_off_port_idx = 0; pri_off_port_idx < pri_off_port_num; pri_off_port_idx++)
                    {
                        poe_set_port_oper_priority_by_soft(pri_off_port_arry[pri_off_port_idx], POE_PD_PRIORITY_OFF);
                    }
                    poe_set_port_oper_priority_by_soft(port_store->port_num, POE_PD_OPER_MAX);
                    if((--pri_off_cnt_tmp) == 0)
                    {
                        break;
                    }
                }
                else if(ret == 2)
                {
                    break;
                }
                else if(ret == 3)
                {
                    poe_set_port_oper_priority_by_soft(port_store->port_num, POE_PD_OPER_MAX);
                    if((--pri_off_cnt_tmp) == 0)
                    {
                        break;
                    }
                }
            }
        }
        else if(POE_PM_STATIC == poe_sys_pm)
        {
            /* rule 1: same priority, only care about panel number */
            /* rule 2: differrent priority */            
            /* Note: port number from low to high */
            priority_end = 0;
            for(list_priority = POE_PORT_PRI_CRITICAL; list_priority >= POE_PORT_PRI_LOW; list_priority--)
            {                
                tmp_list = (list_priority == POE_PORT_PRI_LOW) ? poe_list_priority_low : \
                    ((list_priority == POE_PORT_PRI_HIGH) ? poe_list_priority_high : poe_list_priority_critical);
                ctclib_list_for_each_r(tmp_node, tmp_list)
                {
                    port_store = ctclib_container_of(tmp_node, poe_list_port_info_t, node);
                    sal_memset(pri_off_port_arry,0,100);
                    pri_off_port_num = 100;
                    ret = poe_get_port_priority_by_soft(port_store->port_num, list_priority, pri_off_port_arry, &pri_off_port_num);

                    if(ret == -1)
                    {
                        DRV_LOG_ERR("poe_sys_pm_soft_pri_calc: static pm port %d fail.", port_store->port_num + 1);
                        return RESULT_ERROR;
                    }
                    else if(ret == 0)
                    {
                        continue;
                    }
                    else if(ret == 1)
                    {
                        for(pri_off_port_idx = 0; pri_off_port_idx < pri_off_port_num; pri_off_port_idx++)
                        {
                            poe_set_port_oper_priority_by_soft(pri_off_port_arry[pri_off_port_idx], POE_PD_PRIORITY_OFF);
                        }
                        poe_set_port_oper_priority_by_soft(port_store->port_num, POE_PD_OPER_MAX);
                        if((--pri_off_cnt_tmp) == 0)
                        {
                            priority_end = 1;
                            break;
                        }
                    }
                    else if(ret == 2)
                    {
                        priority_end = 1;
                        break;
                    }
                    else if(ret == 3)
                    {
                        poe_set_port_oper_priority_by_soft(port_store->port_num, POE_PD_OPER_MAX);
                        if((--pri_off_cnt_tmp) == 0)
                        {
                            priority_end = 1;
                            break;
                        }
                    }
                }
                
                if(priority_end)
                {
                    break;
                }
            }
        }
    }

    return RESULT_OK;
}

/* force power, pm mode, new PD powered up*/
int32
poe_sys_pm_soft_calc(glb_poe_port_stat_info_t* port_status_info, glb_poe_port_stat_change_t* port_status_change,
                                glb_poe_sys_stat_info_t* sys_status_info, glb_poe_sys_stat_change_t* sys_status_change,
                                int32* port_num)
{
    int32 port_idx;
    poe_sys_info_t* sys_info;
    poe_hdl_t* hdl;
    poe_para_t para = {0};
    uint8 data[2];
    int32 ret = 0;
    static uint32 vmin; /* milli-watt */
    int32 vmin_change = 0;
    int port_not_stable =0;

    para.len = 2;
    para.val = data;

    hdl = get_poe_master_hdl();
    if(NULL == hdl)
    {
        DRV_LOG_ERR("poe_sys_pm_soft_calc: Get poe hdl err.");
        return RESULT_ERROR;          
    }
    sys_info = &hdl->sys_info;

    sal_mutex_lock(sys_info->soft_pmutex);

    /* 1.get all ports status */
    for(port_idx = 0; port_idx < g_port_num; port_idx++)
    {
        if(NULL == (hdl = get_poe_hdl(port_idx)))
        {
            DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE get port status: port idx %d, Get poe hdl err.",
                port_idx + 1);
            continue;
        }

        sal_memset(&port_stat_change[port_idx], 0, sizeof(glb_poe_port_stat_change_t));
        port_not_stable = poe_get_chip_port_status(port_idx, &port_stat_change[port_idx]);
        if(port_not_stable == POE_PORT_STATUS_NOT_STABLE)
        {
            goto not_stab;
        }
        
        /* 2.adjudge whether the port is overload off */
        ret += poe_sys_pm_soft_ovl_calc(port_idx);

        /* 3.adjudge whether the port is err-disable off */
        ret += poe_sys_pm_soft_err_dis_calc(port_idx);

        if(ret)
        {
            DRV_LOG_ERR("poe_sys_pm_soft_calc: port %d fail.", port_idx);
            sal_mutex_unlock(sys_info->soft_pmutex);
            return RESULT_ERROR;
        }
    }
    
    sal_memset(sys_stat_change, 0, sizeof(glb_poe_sys_stat_change_t));
    ret += poe_get_chip_sys_status(sys_stat_change);

    /* 4.adjudge whether the port is priority off */
    /* if system power > system budget, the behavior is based on chip internal process */
    ret += poe_sys_pm_soft_pri_calc();

    /* 5.update system Vmin */    
    /*
    from FAE:
        Vactual               Con    
        --------  =  ------------------------
        Vmin          (TPPL+1) * 1.0113678    
    */
    if(vmin > sys_info->stat_info.cur_volt)
    {
        vmin = sys_info->stat_info.cur_volt;
        vmin_change = 1;
    }
    else
    {
        if((((float)(sys_info->stat_info.cur_volt - vmin)) / ((float)(sys_info->stat_info.cur_volt))) > POE_PSU_ACCURACY)
        {
            vmin = sys_info->stat_info.cur_volt;
            vmin_change = 1;
        }
    }
    /* fix bug: 0x1300 belongs to protected reg, must poe_select_cfg_mode(hdl, POE_CFG_MODE)*/
    //if(vmin_change)
    if(0)
    {
        para.offset = POE_VMAIN_AT_LOW_TH_REG;
        data[0] = ((vmin/61) >> 8)&0xff;
        data[1] = (vmin/61)&0xff;
        ret += hdl->reg_write(hdl, &para);
    }

not_stab:
    /* 6.after calc, update port status and sys status immediately, protect status from another poe_sys_pm_soft_calc() */
    for(port_idx = 0; port_idx < g_port_num; port_idx++)
    {
        ret += poe_get_port_status(port_idx, &port_status_info[port_idx], &port_status_change[port_idx]);
    }
    *port_num = g_port_num;
    ret += poe_get_sys_status(sys_status_info, sys_status_change);
    sal_mutex_unlock(sys_info->soft_pmutex);
    return ret;
}


/* ================================port config API================================ */


/**********************************************************
 *  Name:       : poe_set_port_budget
 *  Purpose     : set port power consumption limit;
 *  Input       : port_id, budget value;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : Port budget only works in static power management mode. 
                  If the PD is powered up, POE chip will not power down the PD 
                  although setting port budget is lower than PD working budget. 
                  If the PD is powered down, POE chip will power up the PD when setting 
                  port budget is more than PD working budget.
                  When setting port budget, we power down the port to make setting take effect,
                  but the other off port may power on immediately and snatch the budget, 
                  which results the setting port can't get budget and power on any more.
                  So whether the setting takes effect depends on soft mgt mostly
 **********************************************************/

int32
poe_set_port_budget(uint32 port_id, uint32 budget)
{
    poe_hdl_t* hdl;
    poe_port_info_t* port_info;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    int32 ret = 0;
    
    hdl = get_poe_hdl(port_id);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE port enable: get poe hdl err.");
        return RESULT_ERROR;
    }

    /* logic port idx map to chip internal port idx and port_info[] array idx */
    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;
    port_info = hdl->port_info;    
    
    sal_mutex_lock(port_info[map_port_id].pmutex);

    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE poe_set_port_budget: portid %d,pre budget %d, set budget %d.\n",
        port_id + 1, port_info[map_port_id].mgt_info.budget, budget);
    
    if(port_info[map_port_id].mgt_info.budget == budget)
    {
        sal_mutex_unlock(port_info[map_port_id].pmutex);
        return RESULT_OK;
    }

    port_info[map_port_id].mgt_info.budget = budget;
    
    sal_mutex_unlock(port_info[map_port_id].pmutex);
    
    return ret;
}

/**********************************************************
 *  Name:       : poe_port_enable
 *  Purpose     : administer that power on the PD or not;
 *  Input       : port_id, power on or not;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
int32
poe_port_enable(uint32 port_id, poe_admin_t enable)
{
    poe_hdl_t* hdl;
    poe_port_info_t* port_info;
    uint8 data[2] = {0};
    poe_para_t para = {0};
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    poe_admin_t pre_enable = POE_ADMIN_NOT_DEFINED;
    int32 ret = 0;
    uint8 poe_psu_status = POE_PSU_FAIL;

    para.len  = 2;
    para.val = data;

    hdl = get_poe_hdl(port_id);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE port enable: portid %d not support POE.", port_id + 1);
        return RESULT_OK;
    }
    
    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;
    port_info = hdl->port_info;

    sal_mutex_lock(port_info[map_port_id].pmutex);
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE poe_port_enable: portid %d , pre enable %d, set enable %d.\n",
        port_id + 1,port_info[map_port_id].mgt_info.admin, enable);

    if(port_info[map_port_id].port_admin_item.phase != POE_DEAL_ITEM_END)
    {
        DRV_LOG_ERR("poe_port_enable: item has not end\n");
        sal_mutex_unlock(port_info[map_port_id].pmutex);
        return RESULT_OK;
    }

    if(port_info[map_port_id].mgt_info.admin == enable)
    {
        sal_mutex_unlock(port_info[map_port_id].pmutex);
        return RESULT_OK;
    }

    /* if psu fail, only store the cfg val*/
    ret += poe_get_psu_status(&poe_psu_status);
    if(poe_psu_status == POE_PSU_FAIL)
    {
        port_info[map_port_id].mgt_info.admin = enable;
        port_info[map_port_id].port_admin_item.phase = POE_DEAL_ITEM_END;
        sal_mutex_unlock(port_info[map_port_id].pmutex);
        return ret;
    }

    pre_enable = port_info[map_port_id].mgt_info.admin;    
    para.offset = POE_PORT0_CFG_REG + (2 * map_port_id);
    ret += hdl->reg_read(hdl, &para);
    
    if(enable == POE_ENABLE)
    {
        if(pre_enable == POE_FORCE)
        {
            port_info[map_port_id].port_admin_item.phase = POE_DEAL_ITEM_READY;
            port_info[map_port_id].port_admin_item.tmp_val = enable;

            data[1] = (data[1] & (~0x3)) | 0x0;
            ret += hdl->reg_write(hdl, &para);
            sal_mutex_unlock(port_info[map_port_id].pmutex);
            return ret;
        }        
        data[1] = (data[1] & (~0x3)) | 0x1;
    }
    else if(enable == POE_FORCE)
    {
        if(pre_enable == POE_ENABLE)
        {
            port_info[map_port_id].port_admin_item.phase = POE_DEAL_ITEM_READY;
            port_info[map_port_id].port_admin_item.tmp_val = enable;
            
            data[1] = (data[1] & (~0x3)) | 0x0;
            ret += hdl->reg_write(hdl, &para);
            sal_mutex_unlock(port_info[map_port_id].pmutex);
            return ret;
        }
        data[1] = (data[1] & (~0x3)) | 0x2;
    }
    else if(enable == POE_DISABLE)
    {
        data[1] = (data[1] & (~0x3)) | 0x0;
    }    
    ret += hdl->reg_write(hdl, &para);
    port_info[map_port_id].mgt_info.admin = enable;
    port_info[map_port_id].port_admin_item.phase = POE_DEAL_ITEM_END;

    sal_mutex_unlock(port_info[map_port_id].pmutex);
    return ret;
}

/**********************************************************
 *  Name:       : poe_port_enable_item
 *  Purpose     : deal different phase of item;
 *  Input       : port_id;
 *  Output      : real val
 *  Return      : phase val
 *  Note        : if err occur, log info, return phase_end and store the real val.
 **********************************************************/
int32
poe_port_enable_item(uint32 port_id)
{
    poe_hdl_t* hdl;
    poe_para_t para = {0};
    poe_port_info_t* port_info;
    uint8 data[2] = {0};
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    poe_admin_t enable = POE_ADMIN_NOT_DEFINED;
    int32 ret = 0;
    uint8 poe_psu_status = POE_PSU_FAIL;
    
    para.len  = 2;
    para.val = data;

    hdl = get_poe_hdl(port_id);
    if(NULL == hdl)
    {
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE port enable item: portid %d not support POE.", port_id + 1);
        return POE_DEAL_ITEM_END;
    }

    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;
    port_info = hdl->port_info;    

    if(port_info[map_port_id].port_admin_item.phase == POE_DEAL_ITEM_END)
    {
        return POE_DEAL_ITEM_END;
    }

    sal_mutex_lock(port_info[map_port_id].pmutex);

    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE port enable item: portid %d phase %d, val %d.", port_id + 1,
        port_info[map_port_id].port_admin_item.phase, port_info[map_port_id].port_admin_item.tmp_val);

    ret = poe_get_psu_status(&poe_psu_status);
    enable = port_info[map_port_id].port_admin_item.tmp_val;
    if(poe_psu_status == POE_PSU_FAIL || ret)
    {
        port_info[map_port_id].mgt_info.admin = enable;
        port_info[map_port_id].port_admin_item.phase = POE_DEAL_ITEM_END;
        if(ret)
        {
            DRV_LOG_ERR("poe_port_enable item: port %d,get poe psu fail, exit item deal\n",port_id+1);
        }
        sal_mutex_unlock(port_info[map_port_id].pmutex);
        return POE_DEAL_ITEM_END;
    }

    switch(port_info[map_port_id].port_admin_item.phase)
    {
        case POE_DEAL_ITEM_READY:
            port_info[map_port_id].port_admin_item.phase = POE_DEAL_ITEM_START;
            break;
        case POE_DEAL_ITEM_START:
            para.offset = POE_PORT0_CFG_REG + (2 * map_port_id);
            ret = hdl->reg_read(hdl, &para);
            if(enable == POE_ENABLE)
            {
                data[1] = (data[1] & (~0x3)) | 0x1;
            }
            else if(enable == POE_FORCE)
            {
                data[1] = (data[1] & (~0x3)) | 0x2;
            }
            else
            {
                port_info[map_port_id].port_admin_item.phase = POE_DEAL_ITEM_END;
                port_info[map_port_id].mgt_info.admin = enable;
                DRV_LOG_ERR("poe_port_enable item: port %d,deal time error, exit item deal\n",port_id+1);
                sal_mutex_unlock(port_info[map_port_id].pmutex);
                return POE_DEAL_ITEM_END;
            }
            port_info[map_port_id].port_admin_item.phase = POE_DEAL_ITEM_END;
            ret += hdl->reg_write(hdl, &para);
            break;
        default:
            break;
    }
    if(ret)
    {
        port_info[map_port_id].port_admin_item.phase = POE_DEAL_ITEM_END;
        port_info[map_port_id].mgt_info.admin = enable;
        DRV_LOG_ERR("poe_port_enable item: port %d,deal item error\n",port_id+1);
        sal_mutex_unlock(port_info[map_port_id].pmutex);
        return POE_DEAL_ITEM_END;
    }

    if(port_info[map_port_id].port_admin_item.phase == POE_DEAL_ITEM_END)
    {
        port_info[map_port_id].mgt_info.admin = enable;
    }
    ret = port_info[map_port_id].port_admin_item.phase;
    sal_mutex_unlock(port_info[map_port_id].pmutex);

    /* return normally*/
    return ret;
}

/**********************************************************
 *  Name:       : poe_sys_set_port_priority
 *  Purpose     : set port priority;
 *  Input       : port_id, port priority;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : priority not take effect on dynamic PM mode
 **********************************************************/
int32
poe_set_port_priority(uint32 port_id, poe_port_priority_t priority)
{
    poe_hdl_t* hdl;    
    uint32 map_port_id; /* logic port idx map to chip internal port idx */    
    poe_port_info_t* port_info;
    poe_port_priority_t pre_priority = POE_PORT_PRI_MAX;
    ctclib_list_node_t* port_node;
    ctclib_list_t *tmp_list = NULL;
    int32 ret = 0;    
    
    hdl = get_poe_hdl(port_id);
    if(NULL == hdl)
    {        
        DRV_LOG_DEBUG(poe, DRV_POE_NORMAL,"POE port priority: get poe hdl err.");
        return RESULT_ERROR;
    }
    
    map_port_id = g_poe_panel_port_info[port_id].poe_chip_port_idx;
    port_info = hdl->port_info;

    sal_mutex_lock(port_info[map_port_id].pmutex);    
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE set port priority: port %d, pre priority %d, set priority %d.\n",
        port_id, port_info[map_port_id].mgt_info.priority, priority);
    if(port_info[map_port_id].mgt_info.priority == priority)
    {
        sal_mutex_unlock(port_info[map_port_id].pmutex);
        return RESULT_OK;
    }
        
    pre_priority = port_info[map_port_id].mgt_info.priority;
    tmp_list = (pre_priority == POE_PORT_PRI_LOW) ? poe_list_priority_low : \
        ((pre_priority == POE_PORT_PRI_HIGH) ? poe_list_priority_high : poe_list_priority_critical);
    if((port_node = poe_list_delete(tmp_list, port_id)) == NULL)
    {
        DRV_LOG_ERR("POE port priority: fail.");
        sal_mutex_unlock(port_info[map_port_id].pmutex);
        return RESULT_ERROR;
    }        
    tmp_list = (priority == POE_PORT_PRI_LOW) ? poe_list_priority_low : \
        ((priority == POE_PORT_PRI_HIGH) ? poe_list_priority_high : poe_list_priority_critical);
    ret += poe_list_insert_descend(tmp_list, port_node);
    
    /* store the changed val */
    port_info[map_port_id].mgt_info.priority = priority;
    
    /* wait soft poll to take effect, needn't to trigger immediately */
    sal_mutex_unlock(port_info[map_port_id].pmutex);
    
    /* first: trigger POE soft clac */
    //ret += poe_sys_pm_soft_calc();
    return ret;
}

/* ================================system config API================================ */
#if 0
static int32
poe_sys_enable(poe_admin_t enable)
{
    uint32 chip_id;
    int32 ret = 0;

    for(chip_id = 0; chip_id < g_poe_chip_num; chip_id++)
    {
        if(NULL != g_poe_hdl[chip_id]->poe_chip_enable)
        {
            ret += g_poe_hdl[chip_id]->poe_chip_enable(g_poe_hdl[chip_id], enable);
            if(ret)
            {
                DRV_LOG_ERR("POE poe_sys_enable: POE chip num %d, disable failed.", chip_id + 1);
                return RESULT_ERROR;
            }
        }
        else
        {
            DRV_LOG_ERR("POE poe_sys_enable: POE chip num %d, Invalid ptr.", chip_id + 1);
            return RESULT_ERROR;            
        }
    }

    return ret;
}
#endif

/**********************************************************
 *  Name:       : poe_set_sys_pm
 *  Purpose     : set the system pm mode;
 *  Input       : pm mode;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
int32
poe_set_sys_pm(poe_pm_t pm)
{
    poe_hdl_t* hdl;
    poe_sys_info_t* sys_info;
    uint32 chip_idx;
    int32 ret = 0;
    uint8 poe_psu_status = POE_PSU_FAIL;

    if(NULL == (hdl = get_poe_master_hdl()))
    {        
        DRV_LOG_ERR("POE sys pm: get hdl err.");
        return RESULT_ERROR; 
    }
    sys_info = &hdl->sys_info;
    
    sal_mutex_lock(sys_info->pmutex);
    
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE poe_set_sys_pm: pre pm %d, set pm %d.\n",
        sys_info->mgt_info.pm, pm);

    if(sys_info->pm_item.phase != POE_DEAL_ITEM_END)
    {
        DRV_LOG_ERR("poe_set_sys_pm: item has not end\n");
        sal_mutex_lock(sys_info->pmutex);
        return RESULT_OK;
    }

    if(sys_info->mgt_info.pm == pm)
    {
        sal_mutex_unlock(sys_info->pmutex);
        return RESULT_OK;
    }

    /* if psu fail, only store the cfg val*/
    ret += poe_get_psu_status(&poe_psu_status);
    if(poe_psu_status == POE_PSU_FAIL)
    {
        sys_info->mgt_info.pm = pm;
        poe_sys_pm = pm;
        sys_info->pm_item.phase = POE_DEAL_ITEM_END;
        sal_mutex_unlock(sys_info->pmutex);
        return ret;
    }

    for(chip_idx = 0; chip_idx < g_poe_chip_num; chip_idx++)
    {
        hdl = g_poe_hdl[chip_idx];
        if(NULL == hdl)
        {
            DRV_LOG_ERR("POE sys pm: get hdl err.");
            sal_mutex_unlock(sys_info->pmutex);
            return RESULT_ERROR; 
        }

        /* cfg locked reg sequence as flow: */
        /* 1. disable all ports */    
        ret += hdl->poe_chip_enable(hdl, POE_DISABLE);
    }
    sys_info->pm_item.phase = POE_DEAL_ITEM_READY;
    sys_info->pm_item.tmp_val = pm;
    sal_mutex_unlock(sys_info->pmutex);
    return ret;
}


/**********************************************************
 *  Name:       : poe_set_sys_pm_item
 *  Purpose     : deal different phase of item;
 *  Input       : port_id;
 *  Output      : real val
 *  Return      : phase val
 *  Note        : if err occur, log info, return phase_end and store the real val.
 **********************************************************/

int32
poe_set_sys_pm_item(void)
{
    poe_para_t para;
    poe_hdl_t* hdl;
    poe_sys_info_t* sys_info;
    uint32 chip_idx;
    uint8 data[2];
    int32 ret = 0;
    poe_pm_t pm;
    uint8 poe_psu_status = POE_PSU_FAIL;

    if(NULL == (hdl = get_poe_master_hdl()))
    {        
        DRV_LOG_ERR("POE sys pm: get hdl err.");
        return POE_DEAL_ITEM_END; 
    }
    sys_info = &hdl->sys_info;

    if(sys_info->pm_item.phase == POE_DEAL_ITEM_END)
    {
        return POE_DEAL_ITEM_END;
    }
    sal_mutex_lock(sys_info->pmutex);
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE poe_set_sys_pm item: phase %d, val %d.\n",
        sys_info->pm_item.phase, sys_info->pm_item.tmp_val);

    pm = sys_info->pm_item.tmp_val;
    ret += poe_get_psu_status(&poe_psu_status);
    if(poe_psu_status == POE_PSU_FAIL || ret)
    {
        /* store the changed pm */
        sys_info->pm_item.phase = POE_DEAL_ITEM_END;
        sys_info->mgt_info.pm = pm;
        poe_sys_pm = pm;
        if(ret)
        {
            DRV_LOG_ERR("poe_set_sys_pm_item: get poe psu fail, exit item deal\n");
        }
        sal_mutex_unlock(sys_info->pmutex);
        return POE_DEAL_ITEM_END;
    }

    para.len = 2;
    para.val = data;

    switch(sys_info->pm_item.phase)
    {
        case POE_DEAL_ITEM_READY:
            sys_info->pm_item.phase = POE_DEAL_ITEM_START;
            break;
        case POE_DEAL_ITEM_START:
            for(chip_idx = 0; chip_idx < g_poe_chip_num; chip_idx++)
            {
                hdl = g_poe_hdl[chip_idx];
                if(NULL == hdl)
                {
                    sys_info->pm_item.phase = POE_DEAL_ITEM_END;
                    sys_info->mgt_info.pm = pm;
                    poe_sys_pm = pm;
                    DRV_LOG_ERR("POE sys pm: get hdl err.");
                    sal_mutex_unlock(sys_info->pmutex);
                    return RESULT_ERROR; 
                }
                
                /* cfg locked reg sequence as flow: */
                /* 2.change stand alone master/slave mode to cfg mode */
                ret += poe_select_cfg_mode(hdl, POE_CFG_MODE);
                
                /* 3.start config */
                /* set pm */
                para.offset = POE_PM_MODE_REG;
                ret += hdl->reg_read(hdl, &para);        
                /* info from FAE: dynamic mode: [6]=[4]=1, [11]=[10]=0, static mode: [6]=1, [4]=[11]=[10]=0 */
                if(pm == POE_PM_DYNAMIC)
                {
                    data[0] = (data[0] & (~0xc)) | 0x0;
                    data[1] = (data[1] & (~0x50)) | 0x50;
                }
                else
                {
                    data[0] = (data[0] & (~0xc)) | 0x0;
                    data[1] = (data[1] & (~0x50)) | 0x40;
                }
                ret += hdl->reg_write(hdl, &para);
                
                /* 4.change cfg mode to stand alone master/slave mode */
                ret += poe_select_cfg_mode(hdl, POE_MASTER_SLAVE_MODE);
                
                /* 5. enable all ports */
                ret += hdl->poe_chip_enable(hdl, POE_ENABLE);
            }
            sys_info->pm_item.phase = POE_DEAL_ITEM_END;
            break;
        default:
            break;
    }

    if(ret)
    {
        sys_info->pm_item.phase = POE_DEAL_ITEM_END;
        sys_info->mgt_info.pm = pm;
        poe_sys_pm = pm;
        DRV_LOG_ERR("poe_set_sys_pm_item: deal item fail\n");
        sal_mutex_unlock(sys_info->pmutex);
        return POE_DEAL_ITEM_END;
    }

    if(sys_info->pm_item.phase == POE_DEAL_ITEM_END)
    {
        sys_info->mgt_info.pm = pm;
        poe_sys_pm = pm;        
    }
    ret = sys_info->pm_item.phase;
    sal_mutex_unlock(sys_info->pmutex);
       
    return ret;
}

/**********************************************************
 *  Name:       : poe_set_sys_budget
 *  Purpose     : set the system max consumption limit;
 *  Input       : limit budget value;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
int32
poe_set_sys_budget(uint32 budget)
{
    poe_hdl_t* hdl;
    poe_sys_info_t* sys_info;
    int32 ret = 0;    

    if(NULL == (hdl = get_poe_master_hdl()))
    {        
        DRV_LOG_ERR("POE sys budget: get hdl err.");
        return RESULT_ERROR; 
    }
    sys_info = &hdl->sys_info;

    sal_mutex_lock(sys_info->pmutex);
    
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE poe_set_sys_budget: pre budget %d, set budget %d.\n",
        sys_info->mgt_info.budget, budget);
    
    if(sys_info->mgt_info.budget == budget)
    {
        sal_mutex_unlock(sys_info->pmutex);
        return RESULT_OK;
    }

    /* store the changed budget */
    sys_info->mgt_info.budget = budget;
    sal_mutex_unlock(sys_info->pmutex);

    return ret;
}

/**********************************************************
 *  Name:       : poe_set_sys_budget_reserved
 *  Purpose     : set the reserved budget percentage of max budget;
 *  Input       : reserved budget percentage;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
int32
poe_set_sys_budget_reserved(uint32 budget_reserved)
{
    poe_hdl_t* hdl;
    poe_sys_info_t* sys_info;
    int32 ret = 0;

    if(NULL == (hdl = get_poe_master_hdl()))
    {        
        DRV_LOG_ERR("POE sys reserved: get hdl err.");
        return RESULT_ERROR; 
    }
    sys_info = &hdl->sys_info;

    sal_mutex_lock(sys_info->pmutex);
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE sys reserved: pre reserved %d%%, set reserved %d%%.\n",
        sys_info->mgt_info.budget_reserved, budget_reserved);
    if(sys_info->mgt_info.budget_reserved == budget_reserved)
    {
        sal_mutex_unlock(sys_info->pmutex);
        return RESULT_OK;
    }

    /* store the changed val */
    sys_info->mgt_info.budget_reserved = budget_reserved;

    /* wait soft poll to take effect, needn't to trigger immediately */
    sal_mutex_unlock(sys_info->pmutex);
    
    /* first: trigger POE soft clac */
    //ret += poe_sys_pm_soft_calc();
    
    return ret;
}

/**********************************************************
 *  Name:       : poe_set_sys_consump_warn_threshold
 *  Purpose     : set the warn threshold percentage of max budget;
 *  Input       : warn threshold percentage;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
int32
poe_set_sys_consump_warn_threshold(uint32 warn_threshold)
{
    poe_hdl_t* hdl;
    poe_sys_info_t* sys_info;
    int32 ret = 0;
    uint8 poe_psu_status = POE_PSU_FAIL;

    if(NULL == (hdl = get_poe_master_hdl()))
    {        
        DRV_LOG_ERR("POE sys budget threshold: get hdl err.");
        return RESULT_ERROR; 
    }
    sys_info = &hdl->sys_info;
    ret += poe_get_psu_status(&poe_psu_status);

    sal_mutex_lock(sys_info->pmutex);
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE sys reserved: pre threshold %d%%, set threshold %d%%.\n",
        sys_info->mgt_info.budget_warn_thrshd, warn_threshold);
    if(sys_info->mgt_info.budget_warn_thrshd == warn_threshold)
    {
        sal_mutex_unlock(sys_info->pmutex);
        return RESULT_OK;
    }
    if(poe_psu_status == POE_PSU_FAIL)
    {
        /* store the changed val */
        sys_info->mgt_info.budget_warn_thrshd = warn_threshold;
        sal_mutex_unlock(sys_info->pmutex);
        return ret;
    }

    /* store the changed val */
    sys_info->mgt_info.budget_warn_thrshd = warn_threshold;
    /* wait soft poll to take effect, needn't to trigger immediately */
    sal_mutex_unlock(sys_info->pmutex);

    /* first: trigger POE soft clac */
    //ret += poe_sys_pm_soft_calc();

    return ret;
}

/**********************************************************
 *  Name:       : poe_set_sys_legacy_cap
 *  Purpose     : set system legacy_cap enable or disable;
 *  Input       : legacy_cap ability;
 *  Output      : N/A
 *  Return      : RESULT_ERROR or RESULT_OK
 *  Note        : N/A
 **********************************************************/
int32
poe_set_sys_legacy_cap(poe_legacy_cap_t cap)
{
    poe_hdl_t* hdl;
    poe_sys_info_t* sys_info;
    uint32 chip_idx;
    int32 ret = 0;
    uint8 poe_psu_status = POE_PSU_FAIL;

    if(NULL == (hdl = get_poe_master_hdl()))
    {        
        DRV_LOG_ERR("POE sys legacy: get hdl err.");
        return RESULT_ERROR; 
    }
    sys_info = &hdl->sys_info;
    
    sal_mutex_lock(sys_info->pmutex);
    
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE poe_set_sys_legacy_cap: pre lega %d, set lega %d.\n",
        sys_info->mgt_info.legacy_cap, cap);

    if(sys_info->lega_item.phase != POE_DEAL_ITEM_END)
    {
        DRV_LOG_ERR("poe_set_sys_pm: item has not end\n");
        sal_mutex_lock(sys_info->pmutex);
        return RESULT_OK;
    }

    if(sys_info->mgt_info.legacy_cap == cap)
    {
        sal_mutex_unlock(sys_info->pmutex);
        return RESULT_OK;
    }

    /* if psu fail, only store the cfg val*/
    ret += poe_get_psu_status(&poe_psu_status);
    if(poe_psu_status == POE_PSU_FAIL)
    {
        sys_info->mgt_info.legacy_cap = cap;
        sys_info->lega_item.phase = POE_DEAL_ITEM_END;
        sal_mutex_unlock(sys_info->pmutex);
        return ret;
    }

    for(chip_idx = 0; chip_idx < g_poe_chip_num; chip_idx++)
    {
        hdl = g_poe_hdl[chip_idx];
        if(NULL == hdl)
        {
            DRV_LOG_ERR("POE sys pm: get hdl err.");
            sal_mutex_unlock(sys_info->pmutex);
            return RESULT_ERROR; 
        }

        /* cfg locked reg sequence as flow: */
        /* 1. disable all ports */    
        ret += hdl->poe_chip_enable(hdl, POE_DISABLE);
    }
    sys_info->lega_item.phase = POE_DEAL_ITEM_READY;
    sys_info->lega_item.tmp_val = cap;
    sal_mutex_unlock(sys_info->pmutex);
    return ret;
}


/**********************************************************
 *  Name:       : poe_set_sys_legacy_cap_item
 *  Purpose     : deal different phase of item;
 *  Input       : port_id;
 *  Output      : real val
 *  Return      : phase val
 *  Note        : if err occur, log info, return phase_end and store the real val.
 **********************************************************/

int32
poe_set_sys_legacy_cap_item(void)
{
    poe_para_t para;
    poe_hdl_t* hdl;
    poe_sys_info_t* sys_info;
    uint32 chip_idx;
    uint8 data[2];
    int32 ret = 0;
    poe_legacy_cap_t cap;
    uint8 poe_psu_status = POE_PSU_FAIL;

    if(NULL == (hdl = get_poe_master_hdl()))
    {        
        DRV_LOG_ERR("POE sys pm: get hdl err.");
        return POE_DEAL_ITEM_END; 
    }
    sys_info = &hdl->sys_info;

    if(sys_info->lega_item.phase == POE_DEAL_ITEM_END)
    {
        return POE_DEAL_ITEM_END;
    }
    sal_mutex_lock(sys_info->pmutex);
    DRV_LOG_DEBUG(poe, DRV_POE_NORMAL, "POE poe_set_sys_lega item: phase %d, val %d.\n",
        sys_info->lega_item.phase, sys_info->lega_item.tmp_val);
       
    cap = sys_info->lega_item.tmp_val;
    ret += poe_get_psu_status(&poe_psu_status);
    if(poe_psu_status == POE_PSU_FAIL || ret)
    {
        /* store the changed pm */
        sys_info->lega_item.phase = POE_DEAL_ITEM_END;
        sys_info->mgt_info.legacy_cap = cap;
        if(ret)
        {
            DRV_LOG_ERR("poe_set_sys_lega_item: get poe psu fail, exit item deal\n");
        }
        sal_mutex_unlock(sys_info->pmutex);
        return POE_DEAL_ITEM_END;
    }

    para.len = 2;
    para.val = data;

    switch(sys_info->lega_item.phase)
    {
        case POE_DEAL_ITEM_READY:
            sys_info->lega_item.phase = POE_DEAL_ITEM_START;
            break;
        case POE_DEAL_ITEM_START:
            for(chip_idx = 0; chip_idx < g_poe_chip_num; chip_idx++)
            {
                hdl = g_poe_hdl[chip_idx];
                if(NULL == hdl)
                {
                    sys_info->lega_item.phase = POE_DEAL_ITEM_END;
                    sys_info->mgt_info.legacy_cap = cap;
                    DRV_LOG_ERR("POE sys lega: get hdl err.");
                    sal_mutex_unlock(sys_info->pmutex);
                    return RESULT_ERROR; 
                }
                
                /* cfg locked reg sequence as flow: */
                /* 2.change stand alone master/slave mode to cfg mode */
                ret += poe_select_cfg_mode(hdl, POE_CFG_MODE);

                /* 3.start config */
                para.offset = POE_PM_MODE_REG;
                ret += hdl->reg_read(hdl, &para);
                if(cap == POE_DISABLE_LEGACY_CAP)
                {
                    data[1] = (data[1] & (~0x4)) | 0x4;
                }
                else
                {
                    data[1] = (data[1] & (~0x4)) | 0x0;
                }
                ret += hdl->reg_write(hdl, &para);
                
                /* 4.change cfg mode to stand alone master/slave mode */
                ret += poe_select_cfg_mode(hdl, POE_MASTER_SLAVE_MODE);
                
                /* 5. enable all ports */
                ret += hdl->poe_chip_enable(hdl, POE_ENABLE);
            }
            sys_info->lega_item.phase = POE_DEAL_ITEM_END;
            break;
        default:
            break;
    }

    if(ret)
    {
        sys_info->lega_item.phase = POE_DEAL_ITEM_END;
        sys_info->mgt_info.legacy_cap = cap;
        
        DRV_LOG_ERR("poe_set_sys_lega_item: deal item fail\n");
        sal_mutex_unlock(sys_info->pmutex);
        return POE_DEAL_ITEM_END;
    }

    if(sys_info->lega_item.phase == POE_DEAL_ITEM_END)
    {
        sys_info->mgt_info.legacy_cap = cap;        
    }
    ret = sys_info->pm_item.phase;
    sal_mutex_unlock(sys_info->pmutex);
       
    return ret;
}

static int32
poe_init_list_priority(void)
{
    poe_list_port_info_t *port_store_pri, *port_store_no_pri;
    poe_port_info_t* port_info;
    poe_hdl_t* hdl;
    int32 port_idx;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    ctclib_list_t *tmp_list;
    int32 ret = 0;

    /* init  */
    poe_list_priority_low = DRV_MALLOC(CTCLIB_MEM_DRIVER_POE_INFO, sizeof(ctclib_list_t));
    poe_list_priority_high = DRV_MALLOC(CTCLIB_MEM_DRIVER_POE_INFO, sizeof(ctclib_list_t));
    poe_list_priority_critical = DRV_MALLOC(CTCLIB_MEM_DRIVER_POE_INFO, sizeof(ctclib_list_t));
    poe_list_priority_no = DRV_MALLOC(CTCLIB_MEM_DRIVER_POE_INFO, sizeof(ctclib_list_t));
    
    port_store_pri = DRV_MALLOC(CTCLIB_MEM_DRIVER_POE_INFO, sizeof(poe_list_port_info_t)*g_port_num);    
    port_store_no_pri = DRV_MALLOC(CTCLIB_MEM_DRIVER_POE_INFO, sizeof(poe_list_port_info_t)*g_port_num);

    if(NULL == port_store_pri || NULL == port_store_no_pri || NULL == poe_list_priority_low || NULL == poe_list_priority_high ||
        NULL == poe_list_priority_critical || NULL == poe_list_priority_no)
    {
        DRV_LOG_ERR("poe init list: invalid ptr!");
        return RESULT_ERROR;
    }

    /* init list */
    ctclib_list_init(poe_list_priority_low);
    ctclib_list_init(poe_list_priority_high);
    ctclib_list_init(poe_list_priority_critical);
    ctclib_list_init(poe_list_priority_no);

    /* if no support, always -1 */
    //sal_memset(port_store, -1, sizeof(poe_list_port_info_t)*g_port_num);
    for(port_idx = 0; port_idx < g_port_num; port_idx++)
    {
        hdl = get_poe_hdl(port_idx);
        if(NULL == hdl)
        {
            continue;
        }

        port_store_pri[port_idx].port_num = port_idx;        
        port_store_no_pri[port_idx].port_num = port_idx; 
        port_info = hdl->port_info;
        /* get chip internal port and hdl port index */
        map_port_id = g_poe_panel_port_info[port_idx].poe_chip_port_idx;
        /* add node to priority list */
        tmp_list = (port_info[map_port_id].mgt_info.priority == POE_PORT_PRI_LOW) ? poe_list_priority_low : \
            ((port_info[map_port_id].mgt_info.priority == POE_PORT_PRI_HIGH) ? poe_list_priority_high : poe_list_priority_critical);
        ret += poe_list_insert_descend(tmp_list, &port_store_pri[port_idx].node);

        /* add node to not priority list */
        ret += poe_list_insert_descend(poe_list_priority_no, &port_store_no_pri[port_idx].node);
    }

    return ret;
}

int32 
poe_chip_make_patch(void)
{
    poe_para_t para;
    uint8 data[2];
    poe_hdl_t* hdl;
    uint32 chip_index;
    int32 ret = 0;
    int32 patch_len_idx,patch_len = 0;

    para.len = 2;
    para.val = data;

    patch_len = sizeof(g_poe_patch)/sizeof(poe_patch_data_t);
    /* init sys cfg */
    for(chip_index = 0; chip_index < g_poe_chip_num; chip_index++)
    {
        hdl = g_poe_hdl[chip_index];
        if(NULL == hdl)
        {
            DRV_LOG_ERR("POE poe_chip_init: POE chip num %d, Invalid ptr.", chip_index + 1);
            return RESULT_ERROR;
        }
        for(patch_len_idx=0;patch_len_idx<patch_len;patch_len_idx++)
        {
            para.offset = g_poe_patch[patch_len_idx].ram_addr;
            data[0] = (g_poe_patch[patch_len_idx].data >> 8) & 0xff;
            data[1] = (g_poe_patch[patch_len_idx].data) & 0xff;

            ret += hdl->reg_write(hdl, &para);            
        }
    }
    return ret;
}

int32
poe_init(poe_hdl_t** phdl, uint32 chip_num, uint32 port_num, poe_panel_port_t* poe_panel_port_info)
{
    int32 ret = 0;
    
    if(NULL == phdl)
    {
        DRV_LOG_ERR("POE init: Invalid parameter.");
        return RESULT_ERROR;
    }

    g_poe_hdl = phdl;
    g_poe_chip_num = chip_num;
    g_port_num = port_num;
    g_poe_panel_port_info = poe_panel_port_info;
    sys_stat_change = DRV_MALLOC(CTCLIB_MEM_DRIVER_POE_INFO, sizeof(glb_poe_sys_stat_change_t));
    port_stat_change = DRV_MALLOC(CTCLIB_MEM_DRIVER_POE_INFO, sizeof(glb_poe_port_stat_change_t) * g_port_num);
    if(NULL == sys_stat_change || NULL == port_stat_change)
    {
        DRV_LOG_ERR("POE poe_init: invalid ptr.");
        return RESULT_ERROR;
    }
    
    ret += poe_init_list_priority();

    return ret;
}

int32 
poe_chip_init(poe_daughter_card_work_mode_t mode)
{
    poe_para_t para;
    uint8 data[2];
    uint8 port_idx;
    poe_hdl_t* hdl;
    uint32 map_port_id; /* logic port idx map to chip internal port idx */
    poe_port_info_t* port_info;
    poe_sys_info_t* sys_info;
    uint32 chip_index;
    int32 ret = 0;

    para.len = 2;
    para.val = data;

    switch (mode)
    {
        case POE_DAUGHTER_CARD_USER_MODE:
            /* init sys cfg */
            for(chip_index = 0; chip_index < g_poe_chip_num; chip_index++)
            {
                hdl = g_poe_hdl[chip_index];
                if(NULL == hdl)
                {
                    DRV_LOG_ERR("POE poe_chip_init: POE chip num %d, Invalid ptr.", chip_index + 1);
                    return RESULT_ERROR;
                }
                sys_info = &hdl->sys_info;
                
                /* cfg locked reg sequence as follow: */
                /* 1.sys disable all ports */
                ret += hdl->poe_chip_enable(hdl,POE_DISABLE);
                //sal_task_sleep(100);
                sal_udelay(100000);
                
                /* 2.change stand alone master/slave mode to cfg mode */
                ret += poe_select_cfg_mode(hdl, POE_CFG_MODE);

                /* 3.start config */
                /* DC disconnect[0]=1, legacy disable [2]=1, INT Out[5]=0, Vmain discon if under 51V [9]=0 */
                /* info from FAE: dynamic mode: [6]=[4]=1, [11]=[10]=0, static mode: [6]=1, [4]=[11]=[10]=0 */
                /* init sys pm. defaut: static mode */
                para.offset = POE_PM_MODE_REG;
                ret += hdl->reg_read(hdl, &para);
                data[0] = (data[0] & (~0xe)) | 0x0;
                if(sys_info->mgt_info.pm == POE_PM_DYNAMIC)
                {
                    data[1] = (data[1] & (~0x75)) | 0x55;
                }
                else
                {
                    data[1] = (data[1] & (~0x75)) | 0x45;
                }
                ret += hdl->reg_write(hdl, &para);

                /* init system max budget */
                if(hdl->chip_info.ctrl_level == POE_MASTER)
                {
                    para.offset = POE_SYS_POWER_BUDGET0_REG;
                    data[0] = ((POE_SYS_BUDGET / 100) >> 8) & 0xff; /* (budget(mw)/1000 * 10)*/
                    data[1] = (POE_SYS_BUDGET / 100) & 0xff;
                    ret += hdl->reg_write(hdl, &para);
                }

                /* init syste legacy cap */
                para.offset = POE_PM_MODE_REG;
                ret += hdl->reg_read(hdl, &para);
                if(sys_info->mgt_info.legacy_cap == POE_DISABLE_LEGACY_CAP)
                {
                    data[1] = (data[1] & (~0x4)) | 0x4;
                }
                else
                {
                    data[1] = (data[1] & (~0x4)) | 0x0;
                }
                ret += hdl->reg_write(hdl, &para);

                /* needn't to init system reserve-budget and warn-threshold */
                
                /* Power Interface: Alternative A is pre_defined in reg:0x131a-30 by default */
                
                /* From FAE, needn't init system Vmain High threshold 57V, Vmain AT Low threshold 44V */
                
                /* From FAE, needn't to init alarm temperature is 70'C, Disconnection temperature is 95'C*/

                /* 4.change cfg mode to stand alone master/slave mode */
                ret += poe_select_cfg_mode(hdl, POE_MASTER_SLAVE_MODE);

                /* 5. enable all ports */
                ret += hdl->poe_chip_enable(hdl, POE_ENABLE);
                
                /* Interrupt event enable: must mask detection failed intr */
                para.offset = POE_INTR_EVENT_MASK_REG;
                data[0] = 0x00;
                data[1] = 0x00;
                //data[1] = 0xfb;
                ret += hdl->reg_write(hdl, &para);
            }
            
            /* init port cfg */
            for(port_idx = 0; port_idx < g_port_num; port_idx++)
            {
                hdl = get_poe_hdl(port_idx);
                if(NULL == hdl)
                {
                    continue;
                }
                port_info = hdl->port_info;        
                /* get chip internal port and hdl port index */
                map_port_id = g_poe_panel_port_info[port_idx].poe_chip_port_idx;
                /* init port budget */
                /* note: the port budget must less than 32W */
                para.offset = POE_PORT0_POWER_ALLOC_LIMIT_REG + (2 * map_port_id);
                data[0] = 0xff & (POE_PORT_BUDGET / 100 >> 8); /* milli-watt, reg value is (budget/1000*10) */
                data[1] = 0xff & (POE_PORT_BUDGET / 100);
                ret += hdl->reg_write(hdl, &para);

                /* init port enable */        
                para.offset = POE_PORT0_CFG_REG + (2 * map_port_id);
                ret += hdl->reg_read(hdl, &para);
                if(POE_FORCE == port_info[map_port_id].mgt_info.admin)
                {
                    data[1] = (data[1] & (~0x3)) | 0x0;
                    ret += hdl->reg_write(hdl, &para);
                    //sal_task_sleep(50);
                    sal_udelay(50000);
                    data[1] = (data[1] & (~0x3)) | 0x2;
                }
                else if(POE_ENABLE == port_info[map_port_id].mgt_info.admin)
                {            
                    data[1] = (data[1] & (~0x3)) | 0x1;
                }
                else if(POE_DISABLE == port_info[map_port_id].mgt_info.admin)
                {
                    data[1] = (data[1] & (~0x3)) | 0x0;
                }
                
                ret += hdl->reg_write(hdl, &para);
                /* needn't to init port priority */
            }

            break;
        case POE_DAUGHTER_CARD_SIFOS_AT_MODE:
            break;
        case POE_DAUGHTER_CARD_SIFOS_AF_MODE:
            /* init sys cfg */
            for(chip_index = 0; chip_index < g_poe_chip_num; chip_index++)
            {
                hdl = g_poe_hdl[chip_index];
                if(NULL == hdl)
                {
                    DRV_LOG_ERR("POE poe_chip_init: POE chip num %d, Invalid ptr.", chip_index + 1);
                    return RESULT_ERROR;
                }
                sys_info = &hdl->sys_info;
                
                /* cfg locked reg sequence as follow: */
                /* 1.sys disable all ports */
                ret += hdl->poe_chip_enable(hdl,POE_DISABLE);
                //sal_task_sleep(100);
                sal_udelay(100000);
                
                /* 2.change stand alone master/slave mode to cfg mode */
                ret += poe_select_cfg_mode(hdl, POE_CFG_MODE);

                /* 3.start config */
                /* From FAE: for sifos AF test */
                para.offset = POE_PM_MODE_REG;
                data[0] = 0x0;
                data[1] = 0x45;
                ret += hdl->reg_write(hdl, &para);
                
                /* 4.change cfg mode to stand alone master/slave mode */
                ret += poe_select_cfg_mode(hdl, POE_MASTER_SLAVE_MODE);

                /* 5. enable all ports */
                ret += hdl->poe_chip_enable(hdl, POE_ENABLE);
            }
            
            /* init port cfg */
            for(port_idx = 0; port_idx < g_port_num; port_idx++)
            {
                hdl = get_poe_hdl(port_idx);
                if(NULL == hdl)
                {
                    continue;
                }
                /* get chip internal port and hdl port index */
                map_port_id = g_poe_panel_port_info[port_idx].poe_chip_port_idx;
                /* From FAE: for sifos AF test */      
                para.offset = POE_PORT0_CFG_REG + (2 * map_port_id);
                data[0] = 0x0;
                data[1] = 0x5;
                ret += hdl->reg_write(hdl, &para);
            }
            break;
        default:
            break;
    }
    return ret;
}

int32
poe_add_mode(poe_daughter_card_work_mode_t mode)
{    
    int32 ret = 0;

    if(POE_DAUGHTER_CARD_USER_MODE == mode)
    {
        /* reset PoE */
        epld_item_write(0, EPLD_POE_RST, 0x0);
        sal_task_sleep(100);
        /* release POE */
        epld_item_write(0, EPLD_POE_RST, 0x1);
        sal_task_sleep(100);
        ret = poe_chip_init(mode);
    }
    else if(POE_DAUGHTER_CARD_SIFOS_AF_MODE == mode)
    {
        /* note make the port works in AF mode and make sure the PoE software management is invalid*/
        /* The make patch follow from FAE */
        epld_item_write(0, EPLD_POE_DISABLE_PORT, 0x0);
        epld_item_write(0, EPLD_POE_RST, 0x0);
        /* at lease 100us */
        sal_task_sleep(1);
        epld_item_write(0, EPLD_POE_RST, 0x1);
        /* at least 500ms */
        sal_task_sleep(600);
        ret = poe_chip_make_patch();
        epld_item_write(0, EPLD_POE_DISABLE_PORT, 0x1);
        sal_task_sleep(100);
        ret += poe_chip_init(mode);
    }
    else if(POE_DAUGHTER_CARD_SIFOS_AT_MODE == mode)
    {
        /* note make the port works in AT mode and make sure the PoE software management is invalid*/
        /* after reset the PoE chip works in AT mode by default */
        /* reset PoE */
        epld_item_write(0, EPLD_POE_RST, 0x0);
        sal_task_sleep(100);
        epld_item_write(0, EPLD_POE_RST, 0x1);
    }

    return ret;
}

int32
poe_remove_mode()
{
    /* reset PoE */
    epld_item_write(0, EPLD_POE_RST, 0x0);
    sal_task_sleep(100);
    
    return  0;
}


