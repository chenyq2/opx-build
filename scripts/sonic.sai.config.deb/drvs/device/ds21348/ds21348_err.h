/****************************************************************************
 * $Id$
 *  ds21348 err
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      : R0.01
 * Author        : Jcao
 * Date          : 2011-03-30 
 * Reason        : First Create.
 ****************************************************************************/
#ifndef __DS21348_ERR_H__
#define __DS21348_ERR_H__
enum ds21348_error_e
{
    DS21348_SUCCESS = 0,
    DS21348_E_ERROR = -999,
    DS21348_E_NO_MEMORY,
    DS21348_E_NOT_INIT,
    DS21348_E_INIT_FAILED,
    DS21348_E_TIMEOUT,    
    DS21348_E_READ,    
    DS21348_E_WRITE,
    /* parameter check error */
    DS21348_E_INVALID_PARAM,
    DS21348_E_INVALID_PTR,
    DS21348_E_INVALID_INDEX,    
    DS21348_E_INVALID_LENGTH,
    DS21348_E_INVALID_CHIP,

};

#endif /*!__ds21348_ERR_H__*/
