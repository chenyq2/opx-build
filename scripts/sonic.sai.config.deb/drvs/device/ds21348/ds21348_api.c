/****************************************************************************
 * ds21348_api.c    ds21348 api 
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jcao
 * Date:         2011-03-30.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "ctclib_debug.h"
#include "drv_debug.h"
#include "ds21348_api.h"
#include "ds21348_drv.h"
#include "ds21348_err.h"


/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/


/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
/* ds21348 handler */
static ds21348_handle_t **g_ds21348_hdl;


/****************************************************************************
 *
* Functions  
*
****************************************************************************/

/*********************************************************************
 * Name    : ds21348_dev_init
 * Purpose :  configuration ds21348
 * Input   : uint32 idx         - the index of ds21348, usually index = 0
          uint32 clock_type     - the flag of clock type, such as richmod type, 
                                  humber type and 10G phy type etc
                              
 * Output  : N/A
 * Return  : ds21348_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds21348_dev_init(uint32 idx)
{
    return 0;
        
}

/*********************************************************************
 * Name    : ds21348_read
 * Purpose :  read ds21348 register
 * Input   : uint32 idx         - the index of ds21348, usually index = 0
          uint16 addr           - the address of ds21348 internal register 
          uint32 *val           - the pointer of read value
                              
 * Output  : N/A
 * Return  : ds21348_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ds21348_read(uint32 idx, uint8 addr, uint32  *val)
{
    ds21348_access_t ds21348_access;

    DRV_CTC_CHK_PTR(val);

    DRV_CTC_CHK_PTR(g_ds21348_hdl[idx]);
    
    ds21348_access.addr= addr;
    ds21348_access.val = val;

//    DRV_LOG_DEBUG(ds21348, DRV_DS21348_READ, "ds21348_read %d, addr %d, val pointer %p",
//                            idx, ds21348_access.addr, ds21348_access.val);
    
    return g_ds21348_hdl[idx]->read(g_ds21348_hdl[idx], &ds21348_access);
}

/*********************************************************************
 * Name    : ds21348_write
 * Purpose :  write ds21348 register
 * Input   : uint32 idx         - the index of ds21348, usually index = 0
          uint16 addr           - the address of ds21348 internal register 
          uint32 val            - write value 
                              
 * Output  : N/A
 * Return  : ds21348_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ds21348_write(uint32 idx, uint8 addr, uint32  val)
{
    ds21348_access_t ds21348_access;
    
    DRV_CTC_CHK_PTR(g_ds21348_hdl[idx]);
    
    ds21348_access.addr= addr;
    ds21348_access.val = &val;

//    DRV_LOG_DEBUG(ds21348, DRV_DS21348_WRITE, "ds21348_write %d, addr %d, val pointer %p",
//                            idx, ds21348_access.addr, ds21348_access.val);
    
    return g_ds21348_hdl[idx]->write(g_ds21348_hdl[idx], &ds21348_access);
}

/*********************************************************************
 * Name    : ds21348_close
 * Purpose :  free memory and pointer
 * Input   : uint32 idx     - the index of ds21348, usually index = 0
          
 * Output  : N/A
 * Return  : ds21348_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds21348_close(uint32 idx)
{
    DRV_CTC_CHK_PTR(g_ds21348_hdl[idx]);
    
    return g_ds21348_hdl[idx]->close(g_ds21348_hdl[idx]);
}

/*********************************************************************
 * Name    : ds21348_init
 * Purpose :  init some data structure and config ds21348
 * Input   : spi_gen_t *spi_gen     - some info about the way of ds21348'spi bus implement
          uint32 num         - the number of ds21348
          uint32 clock_type   - 
 * Output  : N/A
 * Return  : ds21348_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/
int32 
ds21348_init(spi_gen_t *spi_gen, uint32 num)
{
    int32 i = 0;
    int32 ret;
    
    DRV_CTC_CHK_PTR(spi_gen);
    
    g_ds21348_hdl = (ds21348_handle_t **)DRV_MALLOC(CTCLIB_MEM_DRIVER_DS21348_INFO,sizeof(ds21348_handle_t *)*num);
    if(NULL == g_ds21348_hdl)
    {
        DRV_LOG_ERR("ds21348 alloc handler fail!\n");
        return DS21348_E_INVALID_PTR;
    }

    for (i = 0; i < num; i++)
    {
        g_ds21348_hdl[i] = ds21348_register(E_DS21348_SPI, (const void *)&spi_gen[i]);
    }

    for (i = 0; i < num; i++)
    {
        ret = ds21348_dev_init(i);
        if(ret != 0)
        {
            DRV_LOG_ERR("ds21348 dev init fail!\n");
            return DS21348_E_INIT_FAILED;        
        }
    }
    
    return DS21348_SUCCESS;
}



