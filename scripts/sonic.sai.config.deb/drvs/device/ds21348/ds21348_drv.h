/****************************************************************************
* $Id$
*  The header file of the ds21348 operation.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jcao
* Date          : 2011-03-30 
* Reason        : First Create.
****************************************************************************/
#ifndef __DS21348_DRV__
#define __DS21348_DRV__

#include "ctc_spi.h"


#define DS21348_DATA_LENTH 1    /* data length (byte)*/  
#define DS21348_ADDRESS_LENTH 1  /* address length (byte)*/ 

#define DS21348_SPI_READ  0x1
#define DS21348_SPI_WRITE 0x0
/*1 = burst access, 0 = single access*/
#define DS21348_SPI_ACCESS_MODE 0x0


#define AD_SPI_READ  0x1
#define AD_SPI_WRITE 0x0
#define AD_SPI_WIDTH_1 0x0
#define AD_SPI_WIDTH_2 0x1
#define AD_SPI_WIDTH_3 0x2
#define AD_SPI_STREAM  0x3


#define AD_VCO_CAL_FINISHED 0x6
#define AD_DIGITAL_LOCK     0x0

typedef enum
{
    E_DS21348_SPI = 0,        /* access the ds21348 by SPI bus */
} ds21348_type_t;


struct ds21348_access_s{
    uint8 addr;             /* ds21348 register address */ 
    uint32  *val;             /* pointer of the value buffur */
} ;
typedef struct ds21348_access_s ds21348_access_t;



typedef struct ds21348_handle_s ds21348_handle_t;
struct ds21348_handle_s
{
    uint32 index;
    int32 (*close)(ds21348_handle_t *);
    int32 (*read)(const ds21348_handle_t *, ds21348_access_t *);
    int32 (*write)(const ds21348_handle_t *, ds21348_access_t *);
    void *handle;  /*handle of the low level operations */
};

ds21348_handle_t *ds21348_register(ds21348_type_t type, const void *pgen);

#endif 

