/****************************************************************************
* $Id$
* fiber module driver
* 
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : mayc
* Date          : 2010-09-9
* Reason        : First Create.
****************************************************************************/
#include "fiber_drv.h"
#include "drv_specific.h"
#include "drv_debug.h"
#include "glb_phy_define.h"
#include "sal_common.h"
#include "phy_api.h"
#include "epld_api.h"
#include "gpio_api.h"
#include "ctc_i2c.h"
#include "ctc_api.h"

int32
fiber_phy_reg_write(phy_handle_t* phdl, phyreg_param_t* phy_para, uint16 value)
{
    int32 ret;
    sal_mutex_lock(phdl->phy_info.pmutex);
    ret = phdl->reg_write(phdl, phy_para, value);
    sal_mutex_unlock(phdl->phy_info.pmutex);
    return ret;
}

int32
fiber_phy_reg_read(phy_handle_t* phdl, phyreg_param_t* phy_para, uint16* value)
{
    int32 ret;
    sal_mutex_lock(phdl->phy_info.pmutex);
    ret = phdl->reg_read(phdl, phy_para, value);
    sal_mutex_unlock(phdl->phy_info.pmutex);
    return ret;
}

int32
fiber_phy_reg_write_no_lock(phy_handle_t* phdl, phyreg_param_t* phy_para, uint16 value)
{
    int32 ret;
    ret = phdl->reg_write(phdl, phy_para, value);
    return ret;
}

int32
fiber_phy_reg_read_no_lock(phy_handle_t* phdl, phyreg_param_t* phy_para, uint16* value)
{
    int32 ret;
    ret = phdl->reg_read(phdl, phy_para, value);
    return ret;
}

#if 1
#define I2CSPEED  100
void I2C_delay() {}//{ volatile int v; int i; for (i=0; i < I2CSPEED/2; i++) v; }

bool get_gpio_input_val(phy_handle_t* phdl, uint16 reg)
{
    phyreg_param_t phy_para;
    uint16 value;
    
    phy_para.dev_no = 30;    
    phy_para.dat.regaddr16 = reg;
    fiber_phy_reg_write(phdl, &phy_para, 0x8000);
    fiber_phy_reg_read(phdl, &phy_para, &value);
    if((value & 0x0400)!=0)
        return 1;
    else
        return 0;
}

void set_gpio_output_low(phy_handle_t* phdl, uint16 reg)
{
    phyreg_param_t phy_para;
    
    phy_para.dev_no = 30;    
    phy_para.dat.regaddr16 = reg;
    fiber_phy_reg_write(phdl, &phy_para, 0x0000);
}

// Set SCL as input and return current level of line, 0 or 1
bool read_SCL(phy_handle_t* phdl)  
{
    uint16 reg;
    if(phdl->phy_info.fiber_abs_addr == 0x12a)
    {
        reg = 0x12e;
    }
    else
    {
        reg = 0x10a;
    }
    return get_gpio_input_val(phdl, reg);
}
// Set SCL as input and return current level of line, 0 or 1
bool read_SDA(phy_handle_t* phdl)
{
    uint16 reg;
    if(phdl->phy_info.fiber_abs_addr == 0x12a)
    {
        reg = 0x12c;
    }
    else
    {
        reg = 0x108;
    }
    return get_gpio_input_val(phdl, reg);
}
// Actively drive SCL signal low
void clear_SCL(phy_handle_t* phdl) 
{
    uint16 reg;
    if(phdl->phy_info.fiber_abs_addr == 0x12a)
    {
        reg = 0x12e;
    }
    else
    {
        reg = 0x10a;
    }
    set_gpio_output_low(phdl, reg);
}
// Actively drive SDA signal low
void clear_SDA(phy_handle_t* phdl)
{
    uint16 reg;
    if(phdl->phy_info.fiber_abs_addr == 0x12a)
    {
        reg = 0x12c;
    }
    else
    {
        reg = 0x108;
    }
    set_gpio_output_low(phdl, reg);
}
void arbitration_lost(phy_handle_t* phdl)
{
    DRV_LOG_ERR("arbitration_lost in port addr %d", phdl->phy_info.phy_addr);
}
 
bool started = 0; // global data
void i2c_start_cond(phy_handle_t* phdl) 
{
    if (started) 
    { // if started, do a restart cond
        // set SDA to 1
        read_SDA(phdl);
        I2C_delay();
        while (read_SCL(phdl) == 0) 
        {   // Clock stretching
            // You should add timeout to this loop
        }
        // Repeated start setup time, minimum 4.7us
        I2C_delay();
    }
    if (read_SDA(phdl) == 0) 
    {
        arbitration_lost(phdl);
    }
    // SCL is high, set SDA from 1 to 0.
    clear_SDA(phdl);
    I2C_delay();
    clear_SCL(phdl);
    started = 1;
}

void i2c_stop_cond(phy_handle_t* phdl)
{
    // set SDA to 0
    clear_SDA(phdl);
    I2C_delay();
    // Clock stretching
    while (read_SCL(phdl) == 0) 
    {
        // You should add timeout to this loop.
    }
    // Stop bit setup time, minimum 4us
    I2C_delay();
    // SCL is high, set SDA from 0 to 1
    if (read_SDA(phdl) == 0) 
    {
        arbitration_lost(phdl);
    }
    I2C_delay();
    started = 0;
}

// Write a bit to I2C bus
void i2c_write_bit(phy_handle_t* phdl, bool bit) 
{
    if (bit) 
    {
        read_SDA(phdl);
    }
    else 
    {
        clear_SDA(phdl);
    }
    I2C_delay();
    while (read_SCL(phdl) == 0) 
    {   // Clock stretching
        // You should add timeout to this loop
    }
    // SCL is high, now data is valid
    // If SDA is high, check that nobody else is driving SDA
    if (bit && read_SDA(phdl) == 0) 
    {
        arbitration_lost(phdl);
    }
    I2C_delay();
    clear_SCL(phdl);
}
 
// Read a bit from I2C bus
bool i2c_read_bit(phy_handle_t* phdl) 
{
    bool bit;
    // Let the slave drive data
    read_SDA(phdl);
    I2C_delay();
    while (read_SCL(phdl) == 0) 
    {   // Clock stretching
    // You should add timeout to this loop
    }
    // SCL is high, now data is valid
    bit = read_SDA(phdl);
    I2C_delay();
    clear_SCL(phdl);
    return bit;
}
 
// Write a byte to I2C bus. Return 0 if ack by the slave.
bool i2c_write_byte(phy_handle_t* phdl, bool send_start, bool send_stop, unsigned char byte) 
{
    unsigned bit;
    bool nack;
    if (send_start) 
    {
        i2c_start_cond(phdl);
    }
    for (bit = 0; bit < 8; bit++) 
    {
        i2c_write_bit(phdl, (byte & 0x80) != 0);
        byte <<= 1;
    }
    nack = i2c_read_bit(phdl);
    if (send_stop) 
    {
        i2c_stop_cond(phdl);
    }
    return nack;
}
 
// Read a byte from I2C bus
unsigned char i2c_read_byte(phy_handle_t* phdl, bool nack, bool send_stop) 
{
    unsigned char byte = 0;
    unsigned bit;
    for (bit = 0; bit < 8; bit++) 
    {
        byte = (byte << 1) | i2c_read_bit(phdl);
    }
    i2c_write_bit(phdl, nack);
    if (send_stop) 
    {
        i2c_stop_cond(phdl);
    }
    return byte;
}
#endif

/*After modify as below, every second time run in this func can get the real-time value.*/
int32 fiber_qt2225_phy_read(fiber_handle_t* pfiberhdl, fiber_para_t* paccess)
{
    phy_handle_t* phdl = NULL;
    phyreg_param_t phy_para;
    uint16 value = 0;
    uint16 ctl = 0, mask, offset, dev, addr, maddr;
    int32 i = 0;
    int32 timeout = 10;

    if(NULL == pfiberhdl || NULL == paccess || NULL == paccess->val)
    {
        DRV_LOG_ERR("FIBER read: Invalid parameter");
        return RESULT_ERROR;
    }

    phdl = (phy_handle_t* )(pfiberhdl->phdl_dev1);
    if(NULL == phdl)
    {
        DRV_LOG_ERR("FIBER read: No phy handle");
        return RESULT_ERROR;
    }

    /*be sure first time auto load finish.*/
    phy_para.dev_no = 3;
    phy_para.dat.regaddr16 = 0xd110;
    fiber_phy_reg_read(phdl, &phy_para, &ctl);
    if(paccess->subdev == FIBER_DEV_ADDR1)
    {
        mask = 0x3;
        offset = 0;
        dev = 3;
        addr = 0xd000;
        maddr = 0;
    }
    else
    {
        mask = 0xc;
        offset = 2;
        dev = 1;
        addr = 0xa000;
        maddr = 1;
    }
    while(((ctl & mask) == (2<<offset))&&(timeout>=0))
    {
        usleep(10000);
        timeout--;
        fiber_phy_reg_read(phdl, &phy_para, &ctl);
    }
    if((ctl & mask) != (1<<offset))
    {
        DRV_LOG_ERR("FIBER read %d timeout 0x%x", phdl->phy_info.phy_addr, ctl);
        return RESULT_ERROR; 
    }

    phy_para.dev_no = dev;
    phy_para.dat.regaddr16 = addr + paccess->offset;
    for (i = 0; i < paccess->len; i++)
    {   
        fiber_phy_reg_read(phdl, &phy_para, &value);
        paccess->val[i] = value&0xff;
        phy_para.dat.regaddr16++;
    }
    /*send access command, use for next time  */
    phy_para.dev_no = 3;
    phy_para.dat.regaddr16 = 0xd100;
    fiber_phy_reg_read(phdl, &phy_para, &ctl);
    ctl |= ((maddr<<6) + 0x3);
    fiber_phy_reg_write(phdl, &phy_para, ctl);
    return RESULT_OK;
}

#define MAX_READ 32
/*Bug 16317. jqiu 2011-09-20. support vitesse 10G phy. 
  bug 17397. set i2c speed 100K for vsc8488 not support clock stretching
  After final confirm with vitesse, they announce vsc8488 not support I2C for critical bug. jqiu 2012-04-27*/
int32 fiber_vsc8488_phy_read(fiber_handle_t* pfiberhdl, fiber_para_t* paccess)
{
#if 0    
    phy_handle_t* phdl = NULL;
    phyreg_param_t phy_para;
    uint16 value = 0, length=0, single_len;
    int32 i = 0;
    int32 timeout;

    if(NULL == pfiberhdl || NULL == paccess || NULL == paccess->val)
    {
        DRV_LOG_ERR("FIBER read: Invalid parameter");
        return RESULT_ERROR;
    }

    phdl = (phy_handle_t* )(pfiberhdl->phdl_dev1);
    if(NULL == phdl)
    {
        DRV_LOG_ERR("FIBER read: No phy handle");
        return RESULT_ERROR;
    }

    phy_para.dev_no = 30;
    /*clear the status */
    phy_para.dat.regaddr16 = 0x8000;
    fiber_phy_reg_read(phdl, &phy_para, &value);
    /*select page*/        
    phy_para.dat.regaddr16 = 0x8001;
    value = paccess->subdev;

    fiber_phy_reg_write(phdl, &phy_para, value);
    /*start read*/
    while(length < paccess->len)
    {
        /*cfg read start address*/
        phy_para.dat.regaddr16 = 0x8002;
        value = paccess->offset + length;
        fiber_phy_reg_write(phdl, &phy_para, value);
        /*chip access length, max is 32*/
        phy_para.dat.regaddr16 = 0x8003;
        if(paccess->len - length > MAX_READ)
            value = MAX_READ;
        else
            value = paccess->len - length;
        fiber_phy_reg_write(phdl, &phy_para, value);
        single_len = value;
        /*activate a read cycle*/
        phy_para.dat.regaddr16 = 0x8000;
        fiber_phy_reg_read(phdl, &phy_para, &value);
        if((value&0xc) != 0x0)
        {
            DRV_LOG_ERR("FIBER read: Not ready");
            return RESULT_ERROR;
        }
        fiber_phy_reg_write(phdl, &phy_para, 0x8000);
        /*check command done status */
        timeout = 10;
        while(timeout>=0)
        {
            usleep(10000);
            timeout--;
            fiber_phy_reg_read(phdl, &phy_para, &value);
            if((value&0xc) == 0x4)
            {
                /*bug17397. clear the status after command done.*/
                fiber_phy_reg_read(phdl, &phy_para, &value);
                break;      
            }
        }
        /*chip address for read in data is always 0x8010*/
        phy_para.dat.regaddr16 = 0x8010;            
        i = 0;    
        while(i<single_len)
        {
            fiber_phy_reg_read(phdl, &phy_para, &value);
            paccess->val[length+(i++)] = value&0xff;
            if(i == single_len)
                break;
            paccess->val[length+(i++)] = (value>>8)&0xff;
            phy_para.dat.regaddr16++;
        }
        length += MAX_READ;
    }   
 #else
    phy_handle_t* phdl = NULL;
    uint8 dev_addr;
    int32 i = 0;
    bool nack;

    if(NULL == pfiberhdl || NULL == paccess || NULL == paccess->val)
    {
     DRV_LOG_ERR("FIBER read: Invalid parameter");
     return RESULT_ERROR;
    }

    phdl = (phy_handle_t* )(pfiberhdl->phdl_dev1);
    if(NULL == phdl)
    {
     DRV_LOG_ERR("FIBER read: No phy handle");
     return RESULT_ERROR;
    }
    /*1. send device address.*/
    dev_addr = paccess->subdev;
    nack = i2c_write_byte(phdl, 1, 0, dev_addr<<1);
    if(nack == 1)
        return RESULT_ERROR;
    /*2. send read register start address*/
    nack = i2c_write_byte(phdl, 0, 0, paccess->offset);
    if(nack == 1)
        return RESULT_ERROR;
    /*3. send device address*/
    nack = i2c_write_byte(phdl, 1, 0, (dev_addr<<1) | 1);
    if(nack == 1)
        return RESULT_ERROR;
    /*4. continue read data*/
    for(i=0; i<paccess->len-1; i++)
    {
        paccess->val[i] = i2c_read_byte(phdl, 0, 0);        
    }
    /*5. After recv last data, send nack and stop */
    paccess->val[i] = i2c_read_byte(phdl, 1, 1);    
 #endif
    return RESULT_OK;
}


int32 fiber_qt2225_phy_write(fiber_handle_t* pfiberhdl, fiber_para_t* paccess)
{
    phy_handle_t* phdl = NULL;
    phyreg_param_t phy_para;
    uint16 ctl = 0, cmd, dev, addr;
    int32 i = 0;

    if(NULL == pfiberhdl || NULL == paccess || NULL == paccess->val)
    {
        DRV_LOG_ERR("FIBER write: Invalid parameter");
        return RESULT_ERROR;
    }

    phdl = (phy_handle_t* )(pfiberhdl->phdl_dev1);
    if(NULL == phdl)
    {
        DRV_LOG_ERR("FIBER write: No phy handle");
        return RESULT_ERROR;
    }    
    
    if(paccess->subdev == FIBER_DEV_ADDR1)
    {
        cmd = 0x22;
        dev = 3;
        addr = 0xd000;
    }
    else
    {
        cmd = 0x62;
        dev = 1;
        addr = 0xa000;
    }
    
    for(i=0; i<paccess->len; i++)
    {
        /*check cmd status*/
        phy_para.dev_no = 3;
        phy_para.dat.regaddr16 = 0xd100;
        fiber_phy_reg_read(phdl, &phy_para, &ctl);
        /*Not in progress status*/
        if((ctl & 0xc) !=8)
        {
            /*special register address*/
            phy_para.dev_no = 3;
            phy_para.dat.regaddr16 = 0xd101;
            fiber_phy_reg_write(phdl, &phy_para, paccess->offset+i);
            /*special value */
            phy_para.dev_no = dev;
            phy_para.dat.regaddr16 = addr+i+paccess->offset;
            fiber_phy_reg_write(phdl, &phy_para, paccess->val[i]);
            /*trigger write value */
            phy_para.dev_no = 3;
            phy_para.dat.regaddr16 = 0xd100;
            fiber_phy_reg_write(phdl, &phy_para, cmd);
            usleep(10000);
        }
        else
        {
            return RESULT_ERROR;
        }
    }
    return RESULT_OK;
}
int32 fiber_vsc8488_phy_write(fiber_handle_t* pfiberhdl, fiber_para_t* paccess)
{
    phy_handle_t* phdl = NULL;
    uint8 dev_addr;
    int32 i = 0;
    bool nack, stop;

    if(NULL == pfiberhdl || NULL == paccess || NULL == paccess->val)
    {
     DRV_LOG_ERR("FIBER write: Invalid parameter");
     return RESULT_ERROR;
    }

    phdl = (phy_handle_t* )(pfiberhdl->phdl_dev1);
    if(NULL == phdl)
    {
     DRV_LOG_ERR("FIBER write: No phy handle");
     return RESULT_ERROR;
    }
    /*1. send device address.*/
    dev_addr = paccess->subdev;
    nack = i2c_write_byte(phdl, 1, 0, dev_addr<<1);
    if(nack == 1)
        return RESULT_ERROR;
    /*2. send write register start address*/
    nack = i2c_write_byte(phdl, 0, 0, paccess->offset);
    if(nack == 1)
        return RESULT_ERROR;
    /*3. send data*/
    for(i=0; i<paccess->len; i++)
    {
        if(i >= paccess->len-1)
        {
            stop = 1;
        }
        else
        {
            stop = 0;
        }        
        nack = i2c_write_byte(phdl, 0, stop, paccess->val[i]);
        if(nack == 1)
            return RESULT_ERROR;
    }
    return RESULT_OK;
}

int32 fiber_ctc_chip_read(fiber_handle_t* pfiberhdl, fiber_para_t* paccess)
{
    int32 ret = 0;
    uint32 slave_bitmap;
    ctc_chip_i2c_read_t sfp_para;
    
    if(NULL == pfiberhdl || NULL == pfiberhdl->data || NULL == paccess || NULL == paccess->val)
    {
        DRV_LOG_ERR("FIBER read: Invalid parameter");
        return RESULT_ERROR;
    }

#ifdef GOLDENGATE
    slave_bitmap = ((fiber_ctc_gen_t *)(pfiberhdl->data))->slave_bitmap;
    if (slave_bitmap < 0)
    {
        return RESULT_ERROR;
    }
    
    sfp_para.slave_dev_id = slave_bitmap; 
    sfp_para.slave_bitmap = 0; 
    sfp_para.lchip= ((fiber_ctc_gen_t *)(pfiberhdl->data))->lchip;
    sfp_para.ctl_id = ((fiber_ctc_gen_t *)(pfiberhdl->data))->bus_id;
    sfp_para.dev_addr = paccess->subdev;        
    sfp_para.offset = paccess->offset;
    sfp_para.length = paccess->len;
    sfp_para.buf_length = paccess->len;
    sfp_para.p_buf = paccess->val;
    sfp_para.i2c_switch_id = 0xf;
#else
    slave_bitmap = *((uint32 *)pfiberhdl->data);
    if (slave_bitmap < 0)
    {
        return RESULT_ERROR;
    }
    
    sfp_para.slave_bitmap = (1<<slave_bitmap);    
    sfp_para.dev_addr = paccess->subdev;        
    sfp_para.offset = paccess->offset;
    sfp_para.length = paccess->len;
    sfp_para.p_buf = paccess->val;
#endif

    ret = ctc_chip_i2c_read(&sfp_para);
    if (ret < 0)
    {
        return RESULT_ERROR;
    }
    return RESULT_OK;
}

int32 fiber_ctc_chip_write(fiber_handle_t* phdl, fiber_para_t* para)
{
    int32 ret = 0;
    uint32 slave_bitmap;
    ctc_chip_i2c_write_t sfp_para;
    uint8 i;

    if(NULL == phdl || NULL == phdl->data || NULL == para || NULL == para->val)
    {
        DRV_LOG_ERR("FIBER read: Invalid parameter");
        return RESULT_ERROR;
    }

#ifdef GOLDENGATE
    slave_bitmap = ((fiber_ctc_gen_t *)(phdl->data))->slave_bitmap;
    if (slave_bitmap < 0)
    {
        return RESULT_ERROR;
    }
    sfp_para.dev_addr = para->subdev;
    sfp_para.slave_id = slave_bitmap;
    sfp_para.lchip= ((fiber_ctc_gen_t *)(phdl->data))->lchip;
    sfp_para.ctl_id = ((fiber_ctc_gen_t *)(phdl->data))->bus_id;
    sfp_para.i2c_switch_id = 0xf;
#else
    slave_bitmap = *((uint32 *)phdl->data);
    if (slave_bitmap < 0)
    {
        return RESULT_ERROR;
    }
    sfp_para.dev_addr = para->subdev;
    sfp_para.slave_id = slave_bitmap;
#endif
    for(i=0; i<para->len; i++)
    {
        /*For SFP internal PHY, write 16 bits need do two i2c write, and addr must be same*/
        if(sfp_para.dev_addr == FIBER_DEV_ADDR3)
        {
            sfp_para.offset = para->offset;
        }
        else
        {
            sfp_para.offset = para->offset+i;
        }
        sfp_para.data = para->val[i];
        
        ret = ctc_chip_i2c_write(&sfp_para);
        if (ret < 0)
        {
            return RESULT_ERROR;
        }    
    }
    return RESULT_OK;
}

int32 fiber_i2c_write(fiber_handle_t* pfiberhdl, fiber_para_t* paccess)
{
    i2c_handle_t* i2c_hdl = NULL;
    i2c_op_para_t op_para;
    int32 ret;
    
    if(!pfiberhdl || !paccess)
    {
        DRV_LOG_ERR("FIBER write: Invalid parameter");
        return RESULT_ERROR;
    }
    
    if(FIBER_DEV_ADDR1 == paccess->subdev)
    {
        i2c_hdl = pfiberhdl->phdl_dev1;
    }
    else if(FIBER_DEV_ADDR2 == paccess->subdev)
    {
        i2c_hdl = pfiberhdl->phdl_dev2;
    }
    else if(FIBER_DEV_ADDR3 == paccess->subdev)
    {
        i2c_hdl = pfiberhdl->phdl_dev3;
    }
    if(!i2c_hdl || !i2c_hdl->write)
    {
        DRV_LOG_ERR("FIBER write: Invalid parameter");
        return RESULT_ERROR;
    }

    op_para.offset = paccess->offset;
    op_para.len = paccess->len;   
    op_para.p_val = paccess->val;
        
    ret = i2c_hdl->write(i2c_hdl, &op_para);
    if(ret<0)
    {
        DRV_LOG_ERR("FIBER write: i2c write failed");
        return RESULT_ERROR;
    }

    return RESULT_OK;

}


int32 fiber_i2c_read(fiber_handle_t* pfiberhdl, fiber_para_t* paccess)
{
    i2c_handle_t* i2c_hdl = NULL;
    i2c_op_para_t op_para;
    int32 ii,ret;
    uint8* tmpval_8;
    
    if(!pfiberhdl || !paccess)
    {
        DRV_LOG_ERR("FIBER read: Invalid parameter");
        return RESULT_ERROR;
    }
    
    if(FIBER_DEV_ADDR1 == paccess->subdev)
    {
        i2c_hdl = pfiberhdl->phdl_dev1;
    }
    else if(FIBER_DEV_ADDR2 == paccess->subdev)
    {
        i2c_hdl = pfiberhdl->phdl_dev2;
    }
    else if(FIBER_DEV_ADDR3 == paccess->subdev)
    {
        i2c_hdl = pfiberhdl->phdl_dev3;
    }
    if(!i2c_hdl || !i2c_hdl->read)
    {
        DRV_LOG_ERR("FIBER read: Invalid parameter");
        return RESULT_ERROR;
    }

    op_para.offset = paccess->offset;
    op_para.len = paccess->len;
    tmpval_8 = DRV_MALLOC(CTCLIB_MEM_DRIVER_FIBER_INFO, op_para.len);
    if(!tmpval_8)
    {
        DRV_LOG_ERR("FIBER read: out of memory");
        return RESULT_ERROR;
    }
    op_para.p_val = tmpval_8;
        
    ret = i2c_hdl->read(i2c_hdl, &op_para);
    if(ret<0)
    {
        DRV_LOG_ERR("FIBER read: i2c read failed");
        DRV_FREE(CTCLIB_MEM_DRIVER_FIBER_INFO, tmpval_8);
        return RESULT_ERROR;
    }
    for(ii = 0; ii < op_para.len; ii++)
    {
        paccess->val[ii] = tmpval_8[ii];
        //DRV_LOG_DEBUG(fiber, DRV_FIBER_READ, "fiber_i2c_read offset 0x%x 0x%x", op_para.offset + ii, tmpval_8[ii]);

    }
    
    DRV_FREE(CTCLIB_MEM_DRIVER_FIBER_INFO, tmpval_8);
    
    return RESULT_OK;

}

int32 fiber_epld_get_present_info(uint32 fiber_id, fiber_handle_t* phdl, uint32* present)
{
    
    epld_get_fiber_present(fiber_id, present);
    
    return RESULT_OK;
}

/* raw value 0 means present.*/
int32 fiber_gpio_get_present_info(uint32 fiber_id, fiber_handle_t* phdl, uint32* present)
{
    int32 ret;
    uint8 present_chip, present_no, value;
    
    present_chip = ((fiber_ctc_gen_t *)(phdl->data))->present_chip;
    present_no = ((fiber_ctc_gen_t *)(phdl->data))->present_no;
    
    ret = gpio_get_scan_special_bit_value(present_chip, present_no, &value);
    if(value)
    {
        *present = 0;
    }
    else
    {
        *present = 1;
    }
    return ret;
}

int32 fiber_epld_enable(uint32 fiber_id, fiber_handle_t* phdl, uint32 enable)
{

    epld_set_sfp_enable(fiber_id, enable);
    
    return RESULT_OK;
}

/*raw value 1 means disable*/
int32 fiber_gpio_enable(uint32 fiber_id, fiber_handle_t* phdl, uint32 enable)
{
    int32 ret;
    uint8 enable_chip, enable_no, value;
    
    enable_chip = ((fiber_ctc_gen_t *)(phdl->data))->enable_chip;
    enable_no = ((fiber_ctc_gen_t *)(phdl->data))->enable_no;

    if(enable)
    {
        value = 0;
    }
    else
    {
        value = 1;
    }
    ret = gpio_set_special_bit(enable_chip, enable_no, value);
    
    return ret;
}

int32 fiber_ctc_qsfp_enable(uint32 fiber_id, fiber_handle_t* phdl, uint32 enable)
{
    int ret = 0;
    uint8 val = 0;
    uint8 channel;
    fiber_para_t sfp_para;

    if(phdl->run_info.is_coper)
    {
        return RESULT_OK;
    }

    sfp_para.subdev = FIBER_DEV_ADDR1;   /* Fiber basic information */
    sfp_para.offset = 0x56;    
    sfp_para.len = 1;
    sfp_para.val = &val;

    ret = phdl->read(phdl, &sfp_para);
    if(ret < 0)
    {
       return RESULT_ERROR;
    }

    channel = ((fiber_ctc_gen_t *)(phdl->data))->channel;
    if((channel>4) || (channel<0))
    {
        return RESULT_ERROR;
    }

    if(channel)//4 X 10G
    {
        if(enable == TRUE)
        {
            val &= ~(1<<(channel-1));
        }
        else
        {
            val |= (1<<(channel-1));
        }
    }
    else
    {
        if(enable == TRUE)
        {
            val &= 0xf0;
        }
        else
        {
            val |= 0x0f;
        }
    }
    
    sfp_para.subdev = FIBER_DEV_ADDR1;   /* Fiber basic information */
    sfp_para.offset = 0x56;    
    sfp_para.len = 1;
    sfp_para.val = &val;
    ret = phdl->write(phdl, &sfp_para);
    if(ret < 0)
    {
       return RESULT_ERROR;
    }
    /* delay 40ms according SFF8436 */
    usleep(40000);
    
    return RESULT_OK;
}

/* raw value 1 means los.*/
int32 fiber_gpio_get_los_info(uint32 fiber_id, fiber_handle_t* phdl, uint32* los)
{
    int32 ret;
    uint8 los_chip, los_no, value;
    
    los_chip = ((fiber_ctc_gen_t *)(phdl->data))->los_chip;
    los_no = ((fiber_ctc_gen_t *)(phdl->data))->los_no;
    
    ret = gpio_get_scan_special_bit_value(los_chip, los_no , &value);
    if(value)
    {
        *los = 1;
    }
    else
    {
        *los = 0;
    }
    
    return ret;
}

int32 fiber_epld_get_los_info(uint32 fiber_id, fiber_handle_t* phdl, uint32* los)
{
    
    epld_get_fiber_los(fiber_id, los);
    
    return RESULT_OK;
}

int32 fiber_ctc_get_qsfp_los_info(uint32 fiber_id, fiber_handle_t* phdl, uint32* los)
{
    /* For QSFP+, no need to read real los signal */
    *los = 0;
    return RESULT_OK;
    
    int ret = 0;
    uint8 val = 0;
    uint8 channel;
    fiber_para_t sfp_para;

    if(phdl->run_info.is_coper)
    {
        *los = 0;
        return RESULT_OK;
    }

    sfp_para.subdev = FIBER_DEV_ADDR1;   /* Fiber basic information */
    sfp_para.offset = 0x3;    /* The offset store los information */
    sfp_para.len = 1;
    sfp_para.val = &val;

    ret = phdl->read(phdl, &sfp_para);
    if(ret < 0)
    {
       *los = 1;
       return RESULT_ERROR;
    }
    
    channel = ((fiber_ctc_gen_t *)(phdl->data))->channel;
    if((channel>4) || (channel<0))
    {
        *los = 1;
        return RESULT_ERROR;
    }

    if(channel)//4 10G
    {
        *los = ((val>>(channel-1)) & 0x1);
    }
    else
    {
        if(val == 0)
        {
            *los = 0;
        }
        else
        {
            *los = 1;
        }
    }

    return RESULT_OK;
}

/*bit 8-15 present*/
int32 fiber_vsc8658_get_present_info(uint32 fiber_id, fiber_handle_t* phdl, uint32* present)
{
    uint16 val = 0;
    int16 ret = 0;
    phy_handle_t* p_phy_hdl;
    phyreg_param_t param;
        
    if(NULL == phdl || NULL == present)
    {
        DRV_LOG_ERR("FIBER phy 8658 get present: No handle");
        return RESULT_ERROR;
    }
    p_phy_hdl = (phy_handle_t* )(phdl->phdl_dev4);
    *present = 0;

    /*change to page 0x10*/
    param.dat.regaddr8 = 31;
    if (!sal_mutex_try_lock(p_phy_hdl->phy_info.pmutex))
    {
        return RESULT_ERROR;
    }
    ret = fiber_phy_reg_write_no_lock(p_phy_hdl, &param, 0x10);
    /*read GPIO in value*/
    param.dat.regaddr8 = 15;
    ret += fiber_phy_reg_read_no_lock(p_phy_hdl, &param, &val);
    /*change to page 0x0*/
    param.dat.regaddr8 = 31;
    ret += fiber_phy_reg_write_no_lock(p_phy_hdl, &param, 0);
    sal_mutex_unlock(p_phy_hdl->phy_info.pmutex);

    if((ret == 0)&&((val & (1<<(p_phy_hdl->phy_info.fiber_abs_addr)))==0))
    {
        *present = 1;
    }
    else
    {
        *present = 0;
    }
    return RESULT_OK;
}
/*bit 0-7 enable*/
int32 fiber_vsc8658_enable(uint32 fiber_id, fiber_handle_t* phdl, uint32 enable)
{
    uint16 val = 0;
    int16 ret = 0;
    phy_handle_t* p_phy_hdl;
    phyreg_param_t param;
        
    if(NULL == phdl)
    {
        DRV_LOG_ERR("FIBER phy 8658 enable: No handle");
        return RESULT_ERROR;
    }
    p_phy_hdl = (phy_handle_t* )(phdl->phdl_dev4);

    /*change to page 0x10*/
    param.dat.regaddr8 = 31;
    sal_mutex_lock(p_phy_hdl->phy_info.pmutex);
    ret = fiber_phy_reg_write_no_lock(p_phy_hdl, &param, 0x10);
    /*read GPIO out value*/
    param.dat.regaddr8 = 16;
    ret += fiber_phy_reg_read_no_lock(p_phy_hdl, &param, &val);
    /*modify related bit.*/
    if(enable)
    {
        val &= ~(1<<(p_phy_hdl->phy_info.fiber_txdis_addr));
    }
    else
    {
        val |= (1<<(p_phy_hdl->phy_info.fiber_txdis_addr));
    }
    ret += fiber_phy_reg_write_no_lock(p_phy_hdl, &param, val);
    /*change to page 0x0*/
    param.dat.regaddr8 = 31;
    ret += fiber_phy_reg_write_no_lock(p_phy_hdl, &param, 0);
    sal_mutex_unlock(p_phy_hdl->phy_info.pmutex);

    if(ret == 0)
        return RESULT_OK;
    else
        return RESULT_ERROR;
}

int32 fiber_qt2225_phy_get_present_info(uint32 fiber_id, fiber_handle_t* phdl, uint32* present)
{
    uint16 val = 0;
    int16 ret = 0;
    phy_handle_t* p_phy_hdl;
    phyreg_param_t param;
        
    if(NULL == phdl || NULL == present)
    {
        DRV_LOG_ERR("FIBER phy 2225 get present: No handle");
        return RESULT_ERROR;
    }
    p_phy_hdl = (phy_handle_t* )(phdl->phdl_dev1);
    *present = 0;

    param.dev_no = 0x1;
    param.dat.regaddr16 = 0xc200;
    ret = fiber_phy_reg_read(p_phy_hdl, &param, &val);
    if ((ret == 0) && !(val & 0x1))
    {
        *present = 1;
    }
    else
    {
        *present = 0;
    }
    return RESULT_OK;
}

int32 fiber_qt2225_phy_enable(uint32 fiber_id, fiber_handle_t* phdl, uint32 enable)
{
    uint16 val = 0;
    phy_handle_t* p_phy_hdl;
    phyreg_param_t param;

    if(NULL == phdl)
    {
        DRV_LOG_ERR("FIBER phy 2225 enable: No handle");
        return RESULT_ERROR;
    }
    p_phy_hdl = (phy_handle_t* )(phdl->phdl_dev1);
    param.dev_no = 0x1;
    param.dat.regaddr16 = 0xd005;
    fiber_phy_reg_read(p_phy_hdl, &param, &val);
    if(enable)
    {
        val &= 0xfffd;
    }
    else
    {
        val |= 0x2;
    }
    fiber_phy_reg_write(p_phy_hdl, &param, val);
   
    return RESULT_OK;    
}

/*Bug 16317. jqiu 2011-09-20. support vitesse 10G phy.*/
int32 fiber_vsc8488_phy_get_present_info(uint32 fiber_id, fiber_handle_t* phdl, uint32* present)
{
    uint16 val = 0;
    int16 ret = 0;
    phy_handle_t* p_phy_hdl;
    phyreg_param_t param;
        
    if(NULL == phdl || NULL == present)
    {
        DRV_LOG_ERR("FIBER phy 8488 get present: No handle");
        return RESULT_ERROR;
    }
    p_phy_hdl = (phy_handle_t* )(phdl->phdl_dev1);
    *present = 0;
    
    param.dev_no = 30;        
    param.dat.regaddr16 = p_phy_hdl->phy_info.fiber_abs_addr;
    ret = fiber_phy_reg_read(p_phy_hdl, &param, &val);
    if ((ret == 0) && !(val & 0x0400))
    {
        *present = 1;
    }
    else
    {
        *present = 0;
    }
    return RESULT_OK;
}

/*Bug 16317. jqiu 2011-09-20. support vitesse 10G phy*/
int32 fiber_vsc8488_phy_enable(uint32 fiber_id, fiber_handle_t* phdl, uint32 enable)
{
    uint16 val = 0;
    phy_handle_t* p_phy_hdl;
    phyreg_param_t param;

    if(NULL == phdl)
    {
        DRV_LOG_ERR("FIBER phy 8488 enable: No handle");
        return RESULT_ERROR;
    }
    p_phy_hdl = (phy_handle_t* )(phdl->phdl_dev1);
    param.dev_no = 30;        
    param.dat.regaddr16 = p_phy_hdl->phy_info.fiber_txdis_addr;
    if(enable)
    {
        val = 0;
    }
    else
    {
        val = 0x1000;
    }          
    fiber_phy_reg_write(p_phy_hdl, &param, val);
    return RESULT_OK;    
}


fiber_handle_t* fiber_create_handle(uint32 port_id, fiber_port_info_t* p_info)
{
    phy_handle_t* p_phyhdl;
    i2c_handle_t* i2c_hdl_dev1;
    i2c_handle_t* i2c_hdl_dev2;
    i2c_handle_t* i2c_hdl_dev3;
    fiber_handle_t* phdl;
    i2c_gen_t i2c_gen;
    
    if(NULL == p_info)
    {
        DRV_LOG_ERR("Fiber: Invalid parameter");
        return NULL;
    }
    
    sal_memset(&i2c_gen, 0, sizeof(i2c_gen_t));
    
    phdl = DRV_MALLOC(CTCLIB_MEM_DRIVER_FIBER_INFO, sizeof(fiber_handle_t));
    if(NULL == phdl)
    {
        DRV_LOG_ERR("Fiber: out of memory");
        return NULL;
    }

    switch(p_info->mode)
    {
        case E_FIBER_I2C_EPLD:
        case E_FIBER_I2C_VSC8658:
            i2c_gen.p_br.i2c_br_type = p_info->bridge_type;
            i2c_gen.p_br.channel = p_info->channel;
            i2c_gen.p_br.bridge_addr  = p_info->bridge_addr;
            i2c_gen.i2c_type = E_I2C_CPM;
            i2c_gen.bridge_flag = 1;
            i2c_gen.alen = 1;

            i2c_gen.addr = FIBER_DEV_ADDR1;
            i2c_hdl_dev1 = i2c_create_handle(&i2c_gen);
            
            i2c_gen.addr = FIBER_DEV_ADDR2;
            i2c_hdl_dev2 = i2c_create_handle(&i2c_gen);
            
            i2c_gen.addr = FIBER_DEV_ADDR3;
            i2c_hdl_dev3 = i2c_create_handle(&i2c_gen);

            if(!i2c_hdl_dev1 || !i2c_hdl_dev2 || !i2c_hdl_dev3)
            {
                DRV_FREE(CTCLIB_MEM_DRIVER_FIBER_INFO, phdl);
                return NULL;
            }
            phdl->phdl_dev1 = i2c_hdl_dev1;
            phdl->phdl_dev2 = i2c_hdl_dev2;
            phdl->phdl_dev3 = i2c_hdl_dev3;
            phdl->phdl_dev4 = p_phyhdl = get_phy_hdl(port_id);
            phdl->read = fiber_i2c_read;
            phdl->write = fiber_i2c_write;
            if(p_info->mode == E_FIBER_I2C_EPLD)
            {
                phdl->fiber_present = fiber_epld_get_present_info;
                phdl->fiber_enable = fiber_epld_enable;
            }
            else
            {
                
                phdl->fiber_present = fiber_vsc8658_get_present_info;
                phdl->fiber_enable = fiber_vsc8658_enable;
            }
            /* Add by liuht for Now don't support get los information, 2013-11-20 */		
            phdl->fiber_los = NULL;		
            break;
        case E_FIBER_PHY_QT2225:
            p_phyhdl = get_phy_hdl(port_id);
            if(NULL == p_phyhdl)
            {
                DRV_FREE(CTCLIB_MEM_DRIVER_FIBER_INFO, phdl);
                return NULL;
            }
            phdl->phdl_dev1 = p_phyhdl;
            phdl->read = fiber_qt2225_phy_read;
            phdl->write = fiber_qt2225_phy_write;
            phdl->fiber_present = fiber_qt2225_phy_get_present_info;
            phdl->fiber_enable = fiber_qt2225_phy_enable;
            /* Add by liuht for Now don't support get los information, 2013-11-20 */		
            phdl->fiber_los = NULL;	
            break;
        /*Fix bug 16317. jqiu 2011-09-09. support vsc 10G phy*/    
        case E_FIBER_PHY_VSC8488:
            p_phyhdl = get_phy_hdl(port_id);
            if(NULL == p_phyhdl)
            {
                DRV_FREE(CTCLIB_MEM_DRIVER_FIBER_INFO, phdl);
                return NULL;
            }
            phdl->phdl_dev1 = p_phyhdl;
            phdl->read = fiber_vsc8488_phy_read;
            phdl->write = fiber_vsc8488_phy_write;
            phdl->fiber_present = fiber_vsc8488_phy_get_present_info;
            phdl->fiber_enable = fiber_vsc8488_phy_enable;  
            /* Add by liuht for Now don't support get los information, 2013-11-20 */		
            phdl->fiber_los = NULL;	
            break;
        /* Modified by liuht to support QSFP+ for bug25808, 2013-11-20 */		
        case E_FIBER_CTC_CHIP:
            phdl->data = &(p_info->slave_bitmap);
            /*For bitmap 24~31, GB default is gpio mode, need set to SCL mode
              GB GPIO 4~11 map to SCL 24-31 */
            if(p_info->slave_bitmap >= 24)
            {
                ctc_chip_set_gpio_mode(p_info->slave_bitmap - 24 + 4, CTC_CHIP_SPECIAL_MODE);
            }
            phdl->read = fiber_ctc_chip_read;
            phdl->write = fiber_ctc_chip_write;
            phdl->fiber_present = fiber_epld_get_present_info;
            phdl->fiber_enable = fiber_epld_enable;
            phdl->fiber_los = fiber_epld_get_los_info;
            break;
        case E_FIBER_SFP_CTC_CHIP_GPIO:
            phdl->data = (fiber_ctc_gen_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_FIBER_INFO ,sizeof(fiber_ctc_gen_t));
            if (NULL == phdl->data)
            {
                DRV_FREE(CTCLIB_MEM_DRIVER_FIBER_INFO, phdl);
                return NULL;
            }
            phdl->read = fiber_ctc_chip_read;
            phdl->write = fiber_ctc_chip_write;
            phdl->fiber_present = fiber_gpio_get_present_info;
            ((fiber_ctc_gen_t *)(phdl->data))->lchip = p_info->lchip;
            ((fiber_ctc_gen_t *)(phdl->data))->channel = p_info->fiber_channel;
            ((fiber_ctc_gen_t *)(phdl->data))->bus_id = p_info->bus_id;
            ((fiber_ctc_gen_t *)(phdl->data))->slave_bitmap = p_info->slave_bitmap;
            ((fiber_ctc_gen_t *)(phdl->data))->enable_chip = p_info->enable_chip;
            ((fiber_ctc_gen_t *)(phdl->data))->enable_no = p_info->enable_no;
            ((fiber_ctc_gen_t *)(phdl->data))->present_chip = p_info->present_chip;
            ((fiber_ctc_gen_t *)(phdl->data))->present_no = p_info->present_no;
            ((fiber_ctc_gen_t *)(phdl->data))->los_chip = p_info->los_chip;
            ((fiber_ctc_gen_t *)(phdl->data))->los_no = p_info->los_no;
            phdl->fiber_enable = fiber_gpio_enable;
            phdl->fiber_los = fiber_gpio_get_los_info;
            break;
        case E_FIBER_QSFP_CTC_CHIP_GPIO:
            phdl->data = (fiber_ctc_gen_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_FIBER_INFO ,sizeof(fiber_ctc_gen_t));
            if (NULL == phdl->data)
            {
                DRV_FREE(CTCLIB_MEM_DRIVER_FIBER_INFO, phdl);
                return NULL;
            }
            phdl->read = fiber_ctc_chip_read;
            phdl->write = fiber_ctc_chip_write;
            phdl->fiber_present = fiber_gpio_get_present_info;
            ((fiber_ctc_gen_t *)(phdl->data))->lchip = p_info->lchip;
            ((fiber_ctc_gen_t *)(phdl->data))->channel = p_info->fiber_channel;
            ((fiber_ctc_gen_t *)(phdl->data))->bus_id = p_info->bus_id;
            ((fiber_ctc_gen_t *)(phdl->data))->slave_bitmap = p_info->slave_bitmap;
            ((fiber_ctc_gen_t *)(phdl->data))->enable_chip = p_info->enable_chip;
            ((fiber_ctc_gen_t *)(phdl->data))->enable_no = p_info->enable_no;
            ((fiber_ctc_gen_t *)(phdl->data))->present_chip = p_info->present_chip;
            ((fiber_ctc_gen_t *)(phdl->data))->present_no = p_info->present_no;
            ((fiber_ctc_gen_t *)(phdl->data))->los_chip = p_info->los_chip;
            ((fiber_ctc_gen_t *)(phdl->data))->los_no = p_info->los_no;
            phdl->fiber_enable = fiber_ctc_qsfp_enable;
            phdl->fiber_los = fiber_ctc_get_qsfp_los_info;
            break;
        case E_FIBER_QSFP_I2C_GPIO:
            i2c_gen.p_br.i2c_br_type = p_info->bridge_type;
            i2c_gen.p_br.channel = p_info->channel;
            i2c_gen.p_br.bridge_addr  = p_info->bridge_addr;
            i2c_gen.i2c_type = E_I2C_CPM;
            i2c_gen.bridge_flag = 1;
            i2c_gen.alen = 1;
            i2c_gen.addr = FIBER_DEV_ADDR1;
            i2c_hdl_dev1 = i2c_create_handle(&i2c_gen);

            if(!i2c_hdl_dev1)
            {
                DRV_FREE(CTCLIB_MEM_DRIVER_FIBER_INFO, phdl);
                return NULL;
            }
            phdl->phdl_dev1 = i2c_hdl_dev1;
            phdl->phdl_dev2 = NULL;
            phdl->phdl_dev3 = NULL;
            phdl->phdl_dev4 = NULL;
            phdl->read = fiber_i2c_read;
            phdl->write = fiber_i2c_write;
            
            phdl->data = (fiber_ctc_gen_t *)DRV_MALLOC(CTCLIB_MEM_DRIVER_FIBER_INFO ,sizeof(fiber_ctc_gen_t));
            if (NULL == phdl->data)
            {
                DRV_FREE(CTCLIB_MEM_DRIVER_FIBER_INFO, phdl);
                return NULL;
            }
            ((fiber_ctc_gen_t *)(phdl->data))->lchip = p_info->lchip;
            ((fiber_ctc_gen_t *)(phdl->data))->channel = p_info->fiber_channel;
            ((fiber_ctc_gen_t *)(phdl->data))->bus_id = p_info->bus_id;
            ((fiber_ctc_gen_t *)(phdl->data))->slave_bitmap = p_info->slave_bitmap;
            ((fiber_ctc_gen_t *)(phdl->data))->enable_chip = p_info->enable_chip;
            ((fiber_ctc_gen_t *)(phdl->data))->enable_no = p_info->enable_no;
            ((fiber_ctc_gen_t *)(phdl->data))->present_chip = p_info->present_chip;
            ((fiber_ctc_gen_t *)(phdl->data))->present_no = p_info->present_no;
            ((fiber_ctc_gen_t *)(phdl->data))->los_chip = p_info->los_chip;
            ((fiber_ctc_gen_t *)(phdl->data))->los_no = p_info->los_no;
            phdl->fiber_present = fiber_gpio_get_present_info;
            phdl->fiber_enable = fiber_ctc_qsfp_enable;
            phdl->fiber_los = fiber_ctc_get_qsfp_los_info;
            break;
        default:
            DRV_FREE(CTCLIB_MEM_DRIVER_FIBER_INFO, phdl);
            break;
    }

    return phdl;
}

