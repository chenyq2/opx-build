#ifndef __FIBER_DRV_H__
#define __FIBER_DRV_H__

#include "sal_common.h"
#include "glb_phy_define.h"

#define FIBER_DEV_ADDR1   0x50
#define FIBER_DEV_ADDR2   0x51
#define FIBER_DEV_ADDR3   0x56

#define CMD_STATUS_NO_CMD       0
#define CMD_STATUS_CMD_SUCCESS  1
#define CMD_STATUS_CMD_IN_PROG  2
#define CMD_STATUS_CMD_FAIL     3

typedef enum
{
    E_FIBER_I2C_EPLD = 0,           /* access the FIBER by I2C bus, EN/PRESENT by EPLD */
    E_FIBER_I2C_VSC8658,            /* access the FIBER by I2C bus, EN/PRESENT by vsc8658 GPIO */
    E_FIBER_PHY_QT2225,             /* access the FIBER by QT2225 phy, EN/PRESENT by QT2225 GPIO */ 
    E_FIBER_PHY_VSC8488,            /* access the FIBER by VSC8488 phy. EN/PRESENT by vsc8488 GPIO */ 
    E_FIBER_CTC_CHIP,               /* access the FIBER by Centec chip I2C master. EN/PRESENT/LOS by EPLD */ 
    E_FIBER_SFP_CTC_CHIP_GPIO,      /* access the FIBER by Centec chip I2C master. EN/PRESENT/LOS by GPIO */ 
    E_FIBER_QSFP_CTC_CHIP_GPIO,     /* access the FIBER by Centec chip I2C master. PRESENT by GPIO. EN/LOS by QSFP+ reg */
    E_FIBER_QSFP_I2C_GPIO,          /* access the FIBER by CPU I2C master, PRESENT by GPIO. EN/LOS by QSFP+ reg */
} fiber_access_mode_t;

typedef enum
{
    E_FIBER_SFP = 1,
    E_FIBER_XFP,           
    E_FIBER_SFP_P,
    E_FIBER_QSFP_P
} fiber_device_t;

/* define the structure including fiber operation paramaters */
typedef struct fiber_para_s{
    uint32 subdev;                     /*I2C address. For XFP, memory map at 50, for SFP, memory map at 50,51 */
    uint32 offset;                   /* the address of the fiber dev register */
    uint32 len;                      /* the length of read/write */
    uint8* val;                     /* value pointer*/
}fiber_para_t;

/*support multi GB chip system*/
typedef struct fiber_ctc_gen_s{
    uint32 slave_bitmap;
    uint8 lchip;
    uint8 bus_id;
    uint8 channel;
    uint8 enable_chip;
    uint8 enable_no;
    uint8 present_chip;
    uint8 present_no;
    uint8 los_chip;
    uint8 los_no;
}fiber_ctc_gen_t;

typedef struct fiber_port_info_s{
    int8 fiber_flg;         /* -1 mean not fiber, other get from fiber_device_t */
    fiber_access_mode_t mode;         /* Fiber access mode*/
    uint32 fiber_id;                  /* fiber chip index, 0 based, bitno in sfp present and sfp disable*/
    uint8 bus_id;
    uint32 slave_bitmap;              /* bit map for I2C slave device to scan, used for ctc chip I2C interface
                                         if I2C is not used with ctc chip, set this element to -1 */
    /*start. use for gpio chip pca9505, extend present/tx pin */                                        
    uint8 enable_chip;                /* related to pca9505 chip id.*/    
    uint8 enable_no;                 /*gpio chip pin sum=bank*port_max(5*8), this note the sequence number of the pin */
    uint8 present_chip;               /* related to pca9505 chip id.*/
    uint8 present_no;                /*gpio chip pin sum=bank*port_max(5*8), this note the sequence number of the pin */
    uint8 los_chip;
    uint8 los_no;
    /*end. use for gpio chip pca9505 */    
    uint8 fiber_channel;
    uint8 lchip;
//    uint32 bridge_idx;                /* the fiber corresponding I2C bridge index */
    uint32 channel;                   /* the I2C bridge channel of the fiber */
    uint32 bridge_addr;
    uint32 bridge_type;
}fiber_port_info_t;

/*Fix bug32802, store fiber info in handle, move all fiber operation into one thread.*/
typedef struct fiber_running_info_s{
    uint8 present; //fiber_present_state_t
    uint8 tx_enable; //cfg tx_enable 
    uint8 is_coper;
}fiber_running_info_t;
    
typedef struct fiber_handle_s fiber_handle_t;
struct fiber_handle_s
{
    int32 (*read)(fiber_handle_t* , fiber_para_t* );    
    int32 (*write)(fiber_handle_t* , fiber_para_t* );
    int32 (*fiber_present)(uint32, fiber_handle_t* , uint32* );
    int32 (*fiber_enable)(uint32, fiber_handle_t* , uint32);
    int32 (*fiber_los)(uint32, fiber_handle_t* , uint32*);
    void* phdl_dev1;     /* The hdl of i2c bus or 10G phy, access A0 */  
    void* phdl_dev2;     /* The hdl of i2c bus or 10G phy  access A2*/  
    void* phdl_dev3;     /* The hdl of i2c bus or 10G phy  access AC*/  
    void* phdl_dev4;     /* The hdl of 1G phy hdl*/ 
    fiber_running_info_t run_info;
    void* data;          /* Additional data info for fiber module */
};

fiber_handle_t* fiber_create_handle(uint32 port_id, fiber_port_info_t* p_info);
int32 _fiber_config_handle(fiber_handle_t* phdl, fiber_port_info_t* p_info);

#endif /* __FIBER_DRV_H__ */

