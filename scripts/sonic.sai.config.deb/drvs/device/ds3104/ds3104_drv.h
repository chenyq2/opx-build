/****************************************************************************
* $Id$
*  The header file of the ds3104 operation.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jcao
* Date          : 2011-02-17 
* Reason        : First Create.
****************************************************************************/
#ifndef __DS3104_DRV__
#define __DS3104_DRV__

#include "ctc_spi.h"


#define DS3104_DATA_LENTH 1    /* data length (byte)*/  
#define DS3104_ADDRESS_LENTH 2  /* address length (byte)*/ 

#define DS3104_SPI_READ  0x1
#define DS3104_SPI_WRITE 0x0
/*1 = burst access, 0 = single access*/
#define DS3104_SPI_ACCESS_MODE 0x0


#define AD_SPI_READ  0x1
#define AD_SPI_WRITE 0x0
#define AD_SPI_WIDTH_1 0x0
#define AD_SPI_WIDTH_2 0x1
#define AD_SPI_WIDTH_3 0x2
#define AD_SPI_STREAM  0x3


#define AD_VCO_CAL_FINISHED 0x6
#define AD_DIGITAL_LOCK     0x0

typedef enum
{
    E_DS3104_SPI = 0,        /* access the ds3104 by SPI bus */
} ds3104_type_t;


struct ds3104_access_s{
    uint16 addr;             /* ds3104 register address */ 
    uint32  *val;             /* pointer of the value buffur */
} ;
typedef struct ds3104_access_s ds3104_access_t;



typedef struct ds3104_handle_s ds3104_handle_t;
struct ds3104_handle_s
{
    uint32 index;
    int32 (*close)(ds3104_handle_t *);
    int32 (*read)(const ds3104_handle_t *, ds3104_access_t *);
    int32 (*write)(const ds3104_handle_t *, ds3104_access_t *);
    void *handle;  /*handle of the low level operations */
};

ds3104_handle_t *ds3104_register(ds3104_type_t type, const void *pgen);

#endif 

