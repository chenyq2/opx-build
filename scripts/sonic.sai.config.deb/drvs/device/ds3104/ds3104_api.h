/****************************************************************************
* $Id$
*  The header file of the ds3104 api.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jcao
* Date          : 2011-02-17 
* Reason        : First Create.
****************************************************************************/
#ifndef __DS3104_API_H__
#define __DS3104_API_H__

#include "ctc_spi.h"

#define DS3104_NUM   0x1

#define DS3104_SPI_DO_BIT       0x4000                  /*PD17*/
#define DS3104_SPI_DI_BIT       0x8000                  /*PD16*/
#define DS3104_SPI_CLK_BIT      0x2000                  /*PD18*/
#define DS3104_SPI_CS_BIT       0x40                    /*PD25*/



int32 ds3104_read(uint32 idx, uint16 addr, uint32  *val);
int32 ds3104_read_indirect(uint32 idx, uint16 addr, uint32  *val);
int32 ds3104_write(uint32 idx, uint16 addr, uint32  val);
int32 ds3104_write_indirect(uint32 idx, uint16 addr, uint32  val);
int32 ds3104_close(uint32 idx);
int32 ds3104_init(spi_gen_t *spi_gen, uint32 num);

#endif 

