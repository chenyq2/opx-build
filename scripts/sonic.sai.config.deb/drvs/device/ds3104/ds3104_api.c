/****************************************************************************
 * ds3104_api.c    ds3104 api 
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       jcao
 * Date:         2011-02-17.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files 
*
****************************************************************************/
#include "sal_common.h"
#include "ctclib_debug.h"
#include "drv_debug.h"
#include "epld_drv.h"
#include "ds3104_api.h"
#include "ds3104_drv.h"
#include "ds3104_err.h"


/****************************************************************************
 *
* Defines and Macros 
*
****************************************************************************/


/****************************************************************************
 *
* Global and Declarations  
*
****************************************************************************/
/* ds3104 handler */
static ds3104_handle_t **g_ds3104_hdl;
extern void *epld_base;
extern int32 ds26503_dev_init(uint32 idx);
#ifndef _GLB_UML_SYSTEM_
static void gpio_delay()
{ 
    volatile int32 loop = 0x10;
    while(loop--);
}
#endif

/****************************************************************************
 *
* Functions  
*
****************************************************************************/

/*********************************************************************
 * Name    : ds3104_dev_init
 * Purpose :  configuration ds3104
 * Input   : uint32 idx         - the index of ds3104, usually index = 0
          uint32 clock_type     - the flag of clock type, such as richmod type, 
                                  humber type and 10G phy type etc
                              
 * Output  : N/A
 * Return  : ds3104_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds3104_dev_init(uint32 idx)
{
    int32 ret = 0;
    ret += ds3104_write(idx, 0x1ff, 0x0 );
                        
    ret += ds3104_write(idx, 0x1a8, 0x3 );
    ret += ds3104_write(idx, 0x1ac, 0x2 );
                        
    ret += ds3104_write(idx, 0x1cc, 0x1 );
                        
    ret += ds3104_write(idx, 0x180, 0xc );
    ret += ds3104_write(idx, 0x181, 0x7b );
    ret += ds3104_write(idx, 0x182, 0x0 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x8 );
    ret += ds3104_write(idx, 0x181, 0xdf );
    ret += ds3104_write(idx, 0x182, 0x03 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x0 );
    ret += ds3104_write(idx, 0x180, 0xc );
    ret += ds3104_write(idx, 0x181, 0x79 );
    ret += ds3104_write(idx, 0x182, 0x0 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x8 );
    ret += ds3104_write(idx, 0x181, 0xf5 );
    ret += ds3104_write(idx, 0x182, 0x0 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0xd );
    ret += ds3104_write(idx, 0x181, 0xad );
    ret += ds3104_write(idx, 0x182, 0x02 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x9 );
    ret += ds3104_write(idx, 0x181, 0xd5 );
    ret += ds3104_write(idx, 0x182, 0x03 );
    ret += ds3104_write(idx, 0x183, 0x16 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0xd );
    ret += ds3104_write(idx, 0x181, 0xdb );
    ret += ds3104_write(idx, 0x182, 0x02 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x9 );
    ret += ds3104_write(idx, 0x181, 0xcd );
    ret += ds3104_write(idx, 0x182, 0xa1 );
    ret += ds3104_write(idx, 0x183, 0x1 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0xd );
    ret += ds3104_write(idx, 0x181, 0xdf );
    ret += ds3104_write(idx, 0x182, 0x02 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x9 );
    ret += ds3104_write(idx, 0x181, 0xce );
    ret += ds3104_write(idx, 0x182, 0x03 );
    ret += ds3104_write(idx, 0x183, 0x16 );
    ret += ds3104_write(idx, 0x184, 0x0 );
    /*58*/              
    ret += ds3104_write(idx, 0x180, 0xd );
    ret += ds3104_write(idx, 0x181, 0xb7 );
    ret += ds3104_write(idx, 0x182, 0x03 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x9 );
    ret += ds3104_write(idx, 0x181, 0xce );
    ret += ds3104_write(idx, 0x182, 0x51 );
    ret += ds3104_write(idx, 0x183, 0x01 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0xd );
    ret += ds3104_write(idx, 0x181, 0xc2 );
    ret += ds3104_write(idx, 0x182, 0x03 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x9 );
    ret += ds3104_write(idx, 0x181, 0xce );
    ret += ds3104_write(idx, 0x182, 0x51 );
    ret += ds3104_write(idx, 0x183, 0x4 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0xd );
    ret += ds3104_write(idx, 0x181, 0xc9 );
    ret += ds3104_write(idx, 0x182, 0x03 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x9 );
    ret += ds3104_write(idx, 0x181, 0xcf );
    ret += ds3104_write(idx, 0x182, 0xa1 );
    ret += ds3104_write(idx, 0x183, 0x4 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0xd );
    ret += ds3104_write(idx, 0x181, 0xcc );
    ret += ds3104_write(idx, 0x182, 0x03 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x9 );
    ret += ds3104_write(idx, 0x181, 0xd0 );
    ret += ds3104_write(idx, 0x182, 0xa1 );
    ret += ds3104_write(idx, 0x183, 0x4 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0xd );
    ret += ds3104_write(idx, 0x181, 0xce );
    ret += ds3104_write(idx, 0x182, 0x03 );
    ret += ds3104_write(idx, 0x183, 0x0 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x180, 0x9 );
    ret += ds3104_write(idx, 0x181, 0xcd );
    ret += ds3104_write(idx, 0x182, 0x01 );
    ret += ds3104_write(idx, 0x183, 0x4 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*106*/             
    ret += ds3104_write(idx, 0x181, 0xe );
    ret += ds3104_write(idx, 0x182, 0x5f );
    ret += ds3104_write(idx, 0x183, 0xa1 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x181, 0xd1 );
    ret += ds3104_write(idx, 0x182, 0x51 );
    ret += ds3104_write(idx, 0x183, 0xa4 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x181, 0xd1 );
    ret += ds3104_write(idx, 0x182, 0x51 );
    ret += ds3104_write(idx, 0x183, 0x1 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    ret += ds3104_write(idx, 0x181, 0xf0 );
    ret += ds3104_write(idx, 0x182, 0x11 );
    ret += ds3104_write(idx, 0x183, 0x8 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*122*/             
    ret += ds3104_write(idx, 0x181, 0xc1 );
    ret += ds3104_write(idx, 0x182, 0x1 );
    ret += ds3104_write(idx, 0x183, 0x4 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*126*/             
    ret += ds3104_write(idx, 0x181, 0xe0 );
    ret += ds3104_write(idx, 0x182, 0x2 );
    ret += ds3104_write(idx, 0x183, 0x16 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*130*/             
    ret += ds3104_write(idx, 0x181, 0x94 );
    ret += ds3104_write(idx, 0x182, 0xf );
    ret += ds3104_write(idx, 0x183, 0x1 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*134*/             
    ret += ds3104_write(idx, 0x181, 0x3 );
    ret += ds3104_write(idx, 0x182, 0x0 );
    ret += ds3104_write(idx, 0x183, 0xb );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*138*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0xa0 );
    ret += ds3104_write(idx, 0x183, 0x45 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*142*/             
    ret += ds3104_write(idx, 0x181, 0xd1 );
    ret += ds3104_write(idx, 0x182, 0xa1 );
    ret += ds3104_write(idx, 0x183, 0x44 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*146*/             
    ret += ds3104_write(idx, 0x181, 0xcd );
    ret += ds3104_write(idx, 0x182, 0xa1 );
    ret += ds3104_write(idx, 0x183, 0x44 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*150*/             
    ret += ds3104_write(idx, 0x181, 0xae );
    ret += ds3104_write(idx, 0x182, 0x2 );
    ret += ds3104_write(idx, 0x183, 0x16 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*154*/             
    ret += ds3104_write(idx, 0x180, 0xd );
    ret += ds3104_write(idx, 0x181, 0x35 );
    ret += ds3104_write(idx, 0x182, 0x7 );
    ret += ds3104_write(idx, 0x183, 0x00 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
     /*159*/            
    ret += ds3104_write(idx, 0x180, 0x9 );
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0xff );
    ret += ds3104_write(idx, 0x183, 0xa5 );
    ret += ds3104_write(idx, 0x184, 0xe );
                        
    /*164*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0x7f );
    ret += ds3104_write(idx, 0x183, 0xa9 );
    ret += ds3104_write(idx, 0x184, 0x3 );
                        
    /*168*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0xff );
    ret += ds3104_write(idx, 0x183, 0x52 );
    ret += ds3104_write(idx, 0x184, 0x7 );
                        
    /*172*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0x3f );
    ret += ds3104_write(idx, 0x183, 0x7e );
    ret += ds3104_write(idx, 0x184, 0x4c );
                        
    /*176*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0xf0 );
    ret += ds3104_write(idx, 0x183, 0x2 );
    ret += ds3104_write(idx, 0x184, 0x00 );
                        
    /*180*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0xed );
    ret += ds3104_write(idx, 0x183, 0x36 );
    ret += ds3104_write(idx, 0x184, 0x00 );
                        
    /*184*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0xb4 );
    ret += ds3104_write(idx, 0x183, 0xdb );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*188*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0x55 );
    ret += ds3104_write(idx, 0x183, 0x55 );
    ret += ds3104_write(idx, 0x184, 0x5 );
                        
    /*192*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0x44 );
    ret += ds3104_write(idx, 0x183, 0x44 );
    ret += ds3104_write(idx, 0x184, 0x0 );
                        
    /*196*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0xfe );
    ret += ds3104_write(idx, 0x183, 0xff );
    ret += ds3104_write(idx, 0x184, 0x3f );
                        
    /*200*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0xc8 );
    ret += ds3104_write(idx, 0x183, 0x8f );
    ret += ds3104_write(idx, 0x184, 0x9 );
                        
    /*204*/             
    ret += ds3104_write(idx, 0x181, 0x0 );
    ret += ds3104_write(idx, 0x182, 0x11 );
    ret += ds3104_write(idx, 0x183, 0x00 );
    ret += ds3104_write(idx, 0x184, 0x00 );
                        
    /*208*/             
    ret += ds3104_write(idx, 0x180, 0x0 );
                        
    /*customer config reidx,gister*/
    ret += ds3104_write(idx, 0x20, 0xc1 );
    ret += ds3104_write(idx, 0x21, 0xc1 );
    ret += ds3104_write(idx, 0x22, 0xc1 );
    ret += ds3104_write(idx, 0x23, 0xc1 );
    ret += ds3104_write(idx, 0x24, 0xc1 );
                        
    ret += ds3104_write(idx, 0x25, 0xc0);
    ret += ds3104_write(idx, 0x27, 0x01 );
    ret += ds3104_write(idx, 0x28, 0x01 );
                        
    ret += ds3104_write(idx, 0x4b, 0x0 );
    ret += ds3104_write(idx, 0x18, 0x21 );
    ret += ds3104_write(idx, 0x19, 0x43 );
    ret += ds3104_write(idx, 0x1a, 0x65 );
    ret += ds3104_write(idx, 0x1b, 0x70 );
    ret += ds3104_write(idx, 0x1c, 0x08 );
                        
    ret += ds3104_write(idx, 0x4b, 0x10 );
    ret += ds3104_write(idx, 0x18, 0x0 );
    ret += ds3104_write(idx, 0x19, 0x0 );
    ret += ds3104_write(idx, 0x1a, 0x0 );
    ret += ds3104_write(idx, 0x1b, 0x0 );
    ret += ds3104_write(idx, 0x1c, 0x0 );
                        
    ret += ds3104_write(idx, 0x4b, 0x0 );
                        
    ret += ds3104_write(idx, 0x65, 0x4a );
    ret += ds3104_write(idx, 0x4f, 0x01 );
                        
    ret += ds3104_write(idx, 0x60, 0x54 );
    ret += ds3104_write(idx, 0x61, 0x05);
    ret += ds3104_write(idx, 0x62, 0x00 );
    ret += ds3104_write(idx, 0x63, 0x00 );
                        
                        
    ret += ds3104_write(idx, 0x41, 0x99 );
    ret += ds3104_write(idx, 0x42, 0x00 );
                        
    ret += ds3104_write(idx, 0x69, 0x0e );
    ret += ds3104_write(idx, 0x73, 0x22 );
    ret += ds3104_write(idx, 0x74, 0xe5 );         
    ret += ds3104_write(idx, 0x44, 0x80);

    return ret;
}

/*********************************************************************
 * Name    : ds3104_read
 * Purpose :  read ds3104 register
 * Input   : uint32 idx         - the index of ds3104, usually index = 0
          uint16 addr           - the address of ds3104 internal register 
          uint32 *val           - the pointer of read value
                              
 * Output  : N/A
 * Return  : ds3104_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ds3104_read(uint32 idx, uint16 addr, uint32  *val)
{
    ds3104_access_t ds3104_access;

    DRV_CTC_CHK_PTR(val);

    DRV_CTC_CHK_PTR(g_ds3104_hdl[idx]);
    
    ds3104_access.addr= addr;
    ds3104_access.val = val;

//    DRV_LOG_DEBUG(ds3104, DRV_DS3104_READ, "ds3104_read %d, addr %d, val pointer %p",
//                            idx, ds3104_access.addr, ds3104_access.val);
    
    return g_ds3104_hdl[idx]->read(g_ds3104_hdl[idx], &ds3104_access);
}

/*********************************************************************
 * Name    : ds3104_read_indirect
 * Purpose :  read ds3104 register indirect
 * Input   : uint32 idx         - the index of ds3104, usually index = 0
          uint16 addr           - the address of ds3104 internal register 
          uint32 *val           - the pointer of read value
                              
 * Output  : N/A
 * Return  : ds3104_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ds3104_read_indirect(uint32 idx, uint16 addr, uint32  *val)
{
    /*switch cpu epld to ds3104 */
    *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x2; 
    gpio_delay();
    *((uint8 *)(epld_base + 0xa)) = 0x1; 
    *((uint8 *)(epld_base + 0xa)) = 0x0; 

    return ds3104_read(idx, addr, val);
}

/*********************************************************************
 * Name    : ds3104_write
 * Purpose :  write ds3104 register
 * Input   : uint32 idx         - the index of ds3104, usually index = 0
          uint16 addr           - the address of ds3104 internal register 
          uint32 val            - write value 
                              
 * Output  : N/A
 * Return  : ds3104_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ds3104_write(uint32 idx, uint16 addr, uint32  val)
{
    ds3104_access_t ds3104_access;
    
    DRV_CTC_CHK_PTR(g_ds3104_hdl[idx]);
    
    ds3104_access.addr= addr;
    ds3104_access.val = &val;

//    DRV_LOG_DEBUG(ds3104, DRV_DS3104_WRITE, "ds3104_write %d, addr %d, val pointer %p",
//                            idx, ds3104_access.addr, ds3104_access.val);
    
    return g_ds3104_hdl[idx]->write(g_ds3104_hdl[idx], &ds3104_access);
}

/*********************************************************************
 * Name    : ds3104_write_indirect
 * Purpose :  write ds3104 register indirect
 * Input   : uint32 idx         - the index of ds3104, usually index = 0
          uint16 addr           - the address of ds3104 internal register 
          uint32 val            - write value 
                              
 * Output  : N/A
 * Return  : ds3104_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32 
ds3104_write_indirect(uint32 idx, uint16 addr, uint32  val)
{
    /*switch cpu epld to ds3104 */
    *((uint8 *)(epld_base + EPLD_SPI_SWITCH)) = 0x2; 
    gpio_delay();
    *((uint8 *)(epld_base + 0xa)) = 0x1; 
    *((uint8 *)(epld_base + 0xa)) = 0x0; 

    return ds3104_write(idx, addr, val);
}

/*********************************************************************
 * Name    : ds3104_close
 * Purpose :  free memory and pointer
 * Input   : uint32 idx     - the index of ds3104, usually index = 0
          
 * Output  : N/A
 * Return  : ds3104_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/

int32
ds3104_close(uint32 idx)
{
    DRV_CTC_CHK_PTR(g_ds3104_hdl[idx]);
    
    return g_ds3104_hdl[idx]->close(g_ds3104_hdl[idx]);
}

/*********************************************************************
 * Name    : ds3104_init
 * Purpose :  init some data structure and config ds3104
 * Input   : spi_gen_t *spi_gen     - some info about the way of ds3104'spi bus implement
          uint32 num         - the number of ds3104
          uint32 clock_type   - 
 * Output  : N/A
 * Return  : ds3104_SUCCESS   = SUCCESS
           other           = ErrCode
 * Note    : N/A
*********************************************************************/
int32 
ds3104_init(spi_gen_t *spi_gen, uint32 num)
{
    int32 i = 0;
    int32 ret;
    
    DRV_CTC_CHK_PTR(spi_gen);
    
    g_ds3104_hdl = (ds3104_handle_t **)DRV_MALLOC(CTCLIB_MEM_DRIVER_DS3104_INFO,sizeof(ds3104_handle_t *)*num);
    if(NULL == g_ds3104_hdl)
    {
        DRV_LOG_ERR("ds3104 alloc handler fail!\n");
        return DS3104_E_INVALID_PTR;
    }

    for (i = 0; i < num; i++)
    {
        g_ds3104_hdl[i] = ds3104_register(E_DS3104_SPI, (const void *)&spi_gen[i]);
    }

    for (i = 0; i < 1; i++)
    {
        ret = ds3104_dev_init(i);
        if(ret != 0)
        {
            DRV_LOG_ERR("ds3104 dev init fail!\n");
            return DS3104_E_INIT_FAILED;        
        }
    }
#ifdef GB_DEMO_BOARD

    ret += ds3104_write(1, 0x8, 0x88);
    ret += ds3104_write(1, 0x9, 0x4c);
    ret += ds3104_write(1, 0x30, 0x1);
    ret += ds3104_write(2, 0x8, 0x88);
    ret += ds3104_write(2, 0x9, 0x4c);
    ret += ds3104_write(2, 0x30, 0x1);
    if(ret != 0)
    {
        DRV_LOG_ERR("ds26503 dev init fail!\n");
        return DS3104_E_INIT_FAILED;        
    }
#endif
    
    return DS3104_SUCCESS;
}



