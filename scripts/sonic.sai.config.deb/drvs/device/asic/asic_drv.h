/****************************************************************************
* $Id$
*  The header file of the asic drv.
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Jian Zhu
* Date          : 2008-07-16 
* Reason        : First Create.
****************************************************************************/
#ifndef __ASIC_DRV_H__
#define __ASIC_DRV_H__

/* Alarm!!! some definition refer to ctc_asic_io.h */
#define READ_ASIC    25
#define WRITE_ASIC   24

typedef struct cmdpara_asic_s {
    uint32 asic_id;
    uint32 fpga_id;
    uint32 reg_offset;
    uint32 value;
} cmdpara_asic_t;


typedef struct asic_dev_s asic_dev_t;
struct asic_dev_s
{
    uint32 idx;
    int32 (* reg_read)(asic_dev_t*, uint32, uint32*);
    int32 (* reg_write)(asic_dev_t *, uint32, uint32);    
};

asic_dev_t *
asic_dev_register(uint8 idx);

#endif /* __ASIC_DRV_H__ */

