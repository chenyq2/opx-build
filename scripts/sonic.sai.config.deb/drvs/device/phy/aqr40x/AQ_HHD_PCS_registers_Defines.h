/*! \file 
*   This file contains the compiler assist macros and doxygen comments
*   for the PCS Registers block.
*/

/*! \defgroup PCS_registers_Defines PCS Registers Defines
*   This module contains the compiler assist macros and doxygen comments
*   for the PCS Registers block.
*/
/***********************************************************************
*                 Copyright Aquantia Corporation
*                             Freeware
*
* $File: //depot/icm/proj/Dena/rev1.0/c/Systems/tools/windows/regMapParser/src/gencheaders.py $
*
* $Revision: #10 $
*
* $DateTime: 2014/04/08 16:55:58 $
*
* $Author: joshd $
*
* $Label: $
*
* Description:
*
*   This file contains the compiler assist macros for the registers contained in the PCS Registers block.
*
*
***********************************************************************/


/*@{*/
#ifndef AQ_HHD_PCS_REGS_DEFINES_HEADER
#define AQ_HHD_PCS_REGS_DEFINES_HEADER


/*-----------------------------------------------------------------------------*/
/*Access macro definitions                                                     */
/*-----------------------------------------------------------------------------*/
/*! \brief Base register address of structure AQ_PcsStandardControl_1_HHD */
#define AQ_PcsStandardControl_1_HHD_baseRegisterAddress 0x0000
/*! \brief MMD address of structure AQ_PcsStandardControl_1_HHD */
#define AQ_PcsStandardControl_1_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure reset in AQ_PcsStandardControl_1_HHD */
#define AQ_PcsStandardControl_1_HHD_reset 0
/*! \brief Preprocessor variable to relate field to bit position in structure reset in AQ_PcsStandardControl_1_HHD */
#define bits_AQ_PcsStandardControl_1_HHD_reset u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure reset in AQ_PcsStandardControl_1_HHD */
#define word_AQ_PcsStandardControl_1_HHD_reset u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure loopback in AQ_PcsStandardControl_1_HHD */
#define AQ_PcsStandardControl_1_HHD_loopback 0
/*! \brief Preprocessor variable to relate field to bit position in structure loopback in AQ_PcsStandardControl_1_HHD */
#define bits_AQ_PcsStandardControl_1_HHD_loopback u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure loopback in AQ_PcsStandardControl_1_HHD */
#define word_AQ_PcsStandardControl_1_HHD_loopback u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure speedSelectionLsb in AQ_PcsStandardControl_1_HHD */
#define AQ_PcsStandardControl_1_HHD_speedSelectionLsb 0
/*! \brief Preprocessor variable to relate field to bit position in structure speedSelectionLsb in AQ_PcsStandardControl_1_HHD */
#define bits_AQ_PcsStandardControl_1_HHD_speedSelectionLsb u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure speedSelectionLsb in AQ_PcsStandardControl_1_HHD */
#define word_AQ_PcsStandardControl_1_HHD_speedSelectionLsb u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure lowPower in AQ_PcsStandardControl_1_HHD */
#define AQ_PcsStandardControl_1_HHD_lowPower 0
/*! \brief Preprocessor variable to relate field to bit position in structure lowPower in AQ_PcsStandardControl_1_HHD */
#define bits_AQ_PcsStandardControl_1_HHD_lowPower u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure lowPower in AQ_PcsStandardControl_1_HHD */
#define word_AQ_PcsStandardControl_1_HHD_lowPower u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure clockStopEnable in AQ_PcsStandardControl_1_HHD */
#define AQ_PcsStandardControl_1_HHD_clockStopEnable 0
/*! \brief Preprocessor variable to relate field to bit position in structure clockStopEnable in AQ_PcsStandardControl_1_HHD */
#define bits_AQ_PcsStandardControl_1_HHD_clockStopEnable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure clockStopEnable in AQ_PcsStandardControl_1_HHD */
#define word_AQ_PcsStandardControl_1_HHD_clockStopEnable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure speedSelectionMsb in AQ_PcsStandardControl_1_HHD */
#define AQ_PcsStandardControl_1_HHD_speedSelectionMsb 0
/*! \brief Preprocessor variable to relate field to bit position in structure speedSelectionMsb in AQ_PcsStandardControl_1_HHD */
#define bits_AQ_PcsStandardControl_1_HHD_speedSelectionMsb u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure speedSelectionMsb in AQ_PcsStandardControl_1_HHD */
#define word_AQ_PcsStandardControl_1_HHD_speedSelectionMsb u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gSpeedSelection in AQ_PcsStandardControl_1_HHD */
#define AQ_PcsStandardControl_1_HHD__10gSpeedSelection 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gSpeedSelection in AQ_PcsStandardControl_1_HHD */
#define bits_AQ_PcsStandardControl_1_HHD__10gSpeedSelection u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gSpeedSelection in AQ_PcsStandardControl_1_HHD */
#define word_AQ_PcsStandardControl_1_HHD__10gSpeedSelection u0.word_0

/*! \brief Base register address of structure AQ_PcsStandardStatus_1_HHD */
#define AQ_PcsStandardStatus_1_HHD_baseRegisterAddress 0x0001
/*! \brief MMD address of structure AQ_PcsStandardStatus_1_HHD */
#define AQ_PcsStandardStatus_1_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure txLpiReceived in AQ_PcsStandardStatus_1_HHD */
#define AQ_PcsStandardStatus_1_HHD_txLpiReceived 0
/*! \brief Preprocessor variable to relate field to bit position in structure txLpiReceived in AQ_PcsStandardStatus_1_HHD */
#define bits_AQ_PcsStandardStatus_1_HHD_txLpiReceived u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure txLpiReceived in AQ_PcsStandardStatus_1_HHD */
#define word_AQ_PcsStandardStatus_1_HHD_txLpiReceived u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure rxLpiReceived in AQ_PcsStandardStatus_1_HHD */
#define AQ_PcsStandardStatus_1_HHD_rxLpiReceived 0
/*! \brief Preprocessor variable to relate field to bit position in structure rxLpiReceived in AQ_PcsStandardStatus_1_HHD */
#define bits_AQ_PcsStandardStatus_1_HHD_rxLpiReceived u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure rxLpiReceived in AQ_PcsStandardStatus_1_HHD */
#define word_AQ_PcsStandardStatus_1_HHD_rxLpiReceived u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure txLpiIndication in AQ_PcsStandardStatus_1_HHD */
#define AQ_PcsStandardStatus_1_HHD_txLpiIndication 0
/*! \brief Preprocessor variable to relate field to bit position in structure txLpiIndication in AQ_PcsStandardStatus_1_HHD */
#define bits_AQ_PcsStandardStatus_1_HHD_txLpiIndication u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure txLpiIndication in AQ_PcsStandardStatus_1_HHD */
#define word_AQ_PcsStandardStatus_1_HHD_txLpiIndication u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure rxLpiIndication in AQ_PcsStandardStatus_1_HHD */
#define AQ_PcsStandardStatus_1_HHD_rxLpiIndication 0
/*! \brief Preprocessor variable to relate field to bit position in structure rxLpiIndication in AQ_PcsStandardStatus_1_HHD */
#define bits_AQ_PcsStandardStatus_1_HHD_rxLpiIndication u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure rxLpiIndication in AQ_PcsStandardStatus_1_HHD */
#define word_AQ_PcsStandardStatus_1_HHD_rxLpiIndication u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure fault in AQ_PcsStandardStatus_1_HHD */
#define AQ_PcsStandardStatus_1_HHD_fault 0
/*! \brief Preprocessor variable to relate field to bit position in structure fault in AQ_PcsStandardStatus_1_HHD */
#define bits_AQ_PcsStandardStatus_1_HHD_fault u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure fault in AQ_PcsStandardStatus_1_HHD */
#define word_AQ_PcsStandardStatus_1_HHD_fault u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure clockStopCapable in AQ_PcsStandardStatus_1_HHD */
#define AQ_PcsStandardStatus_1_HHD_clockStopCapable 0
/*! \brief Preprocessor variable to relate field to bit position in structure clockStopCapable in AQ_PcsStandardStatus_1_HHD */
#define bits_AQ_PcsStandardStatus_1_HHD_clockStopCapable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure clockStopCapable in AQ_PcsStandardStatus_1_HHD */
#define word_AQ_PcsStandardStatus_1_HHD_clockStopCapable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pcsReceiveLinkStatus in AQ_PcsStandardStatus_1_HHD */
#define AQ_PcsStandardStatus_1_HHD_pcsReceiveLinkStatus 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsReceiveLinkStatus in AQ_PcsStandardStatus_1_HHD */
#define bits_AQ_PcsStandardStatus_1_HHD_pcsReceiveLinkStatus u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsReceiveLinkStatus in AQ_PcsStandardStatus_1_HHD */
#define word_AQ_PcsStandardStatus_1_HHD_pcsReceiveLinkStatus u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure lowPowerAbility in AQ_PcsStandardStatus_1_HHD */
#define AQ_PcsStandardStatus_1_HHD_lowPowerAbility 0
/*! \brief Preprocessor variable to relate field to bit position in structure lowPowerAbility in AQ_PcsStandardStatus_1_HHD */
#define bits_AQ_PcsStandardStatus_1_HHD_lowPowerAbility u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure lowPowerAbility in AQ_PcsStandardStatus_1_HHD */
#define word_AQ_PcsStandardStatus_1_HHD_lowPowerAbility u0.word_0

/*! \brief Base register address of structure AQ_PcsStandardDeviceIdentifier_HHD */
#define AQ_PcsStandardDeviceIdentifier_HHD_baseRegisterAddress 0x0002
/*! \brief MMD address of structure AQ_PcsStandardDeviceIdentifier_HHD */
#define AQ_PcsStandardDeviceIdentifier_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure deviceIdMSW in AQ_PcsStandardDeviceIdentifier_HHD */
#define AQ_PcsStandardDeviceIdentifier_HHD_deviceIdMSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure deviceIdMSW in AQ_PcsStandardDeviceIdentifier_HHD */
#define bits_AQ_PcsStandardDeviceIdentifier_HHD_deviceIdMSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure deviceIdMSW in AQ_PcsStandardDeviceIdentifier_HHD */
#define word_AQ_PcsStandardDeviceIdentifier_HHD_deviceIdMSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure deviceIdLSW in AQ_PcsStandardDeviceIdentifier_HHD */
#define AQ_PcsStandardDeviceIdentifier_HHD_deviceIdLSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure deviceIdLSW in AQ_PcsStandardDeviceIdentifier_HHD */
#define bits_AQ_PcsStandardDeviceIdentifier_HHD_deviceIdLSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure deviceIdLSW in AQ_PcsStandardDeviceIdentifier_HHD */
#define word_AQ_PcsStandardDeviceIdentifier_HHD_deviceIdLSW u1.word_1

/*! \brief Base register address of structure AQ_PcsStandardSpeedAbility_HHD */
#define AQ_PcsStandardSpeedAbility_HHD_baseRegisterAddress 0x0004
/*! \brief MMD address of structure AQ_PcsStandardSpeedAbility_HHD */
#define AQ_PcsStandardSpeedAbility_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure _10pass_ts__2base_tlCapable in AQ_PcsStandardSpeedAbility_HHD */
#define AQ_PcsStandardSpeedAbility_HHD__10pass_ts__2base_tlCapable 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10pass_ts__2base_tlCapable in AQ_PcsStandardSpeedAbility_HHD */
#define bits_AQ_PcsStandardSpeedAbility_HHD__10pass_ts__2base_tlCapable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10pass_ts__2base_tlCapable in AQ_PcsStandardSpeedAbility_HHD */
#define word_AQ_PcsStandardSpeedAbility_HHD__10pass_ts__2base_tlCapable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gCapable in AQ_PcsStandardSpeedAbility_HHD */
#define AQ_PcsStandardSpeedAbility_HHD__10gCapable 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gCapable in AQ_PcsStandardSpeedAbility_HHD */
#define bits_AQ_PcsStandardSpeedAbility_HHD__10gCapable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gCapable in AQ_PcsStandardSpeedAbility_HHD */
#define word_AQ_PcsStandardSpeedAbility_HHD__10gCapable u0.word_0

/*! \brief Base register address of structure AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_baseRegisterAddress 0x0005
/*! \brief MMD address of structure AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure autonegotiationPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_autonegotiationPresent 0
/*! \brief Preprocessor variable to relate field to bit position in structure autonegotiationPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_autonegotiationPresent u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure autonegotiationPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_autonegotiationPresent u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure tcPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_tcPresent 0
/*! \brief Preprocessor variable to relate field to bit position in structure tcPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_tcPresent u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure tcPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_tcPresent u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure dteXsPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_dteXsPresent 0
/*! \brief Preprocessor variable to relate field to bit position in structure dteXsPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_dteXsPresent u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure dteXsPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_dteXsPresent u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure phyXS_Present in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_phyXS_Present 0
/*! \brief Preprocessor variable to relate field to bit position in structure phyXS_Present in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_phyXS_Present u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure phyXS_Present in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_phyXS_Present u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pcsPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_pcsPresent 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_pcsPresent u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_pcsPresent u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure wisPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_wisPresent 0
/*! \brief Preprocessor variable to relate field to bit position in structure wisPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_wisPresent u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure wisPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_wisPresent u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pmaPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_pmaPresent 0
/*! \brief Preprocessor variable to relate field to bit position in structure pmaPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_pmaPresent u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pmaPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_pmaPresent u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure clause_22RegistersPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_clause_22RegistersPresent 0
/*! \brief Preprocessor variable to relate field to bit position in structure clause_22RegistersPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_clause_22RegistersPresent u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure clause_22RegistersPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_clause_22RegistersPresent u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificDevice_2Present in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_vendorSpecificDevice_2Present 1
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificDevice_2Present in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_vendorSpecificDevice_2Present u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificDevice_2Present in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_vendorSpecificDevice_2Present u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificDevice_1Present in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_vendorSpecificDevice_1Present 1
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificDevice_1Present in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_vendorSpecificDevice_1Present u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificDevice_1Present in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_vendorSpecificDevice_1Present u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure clause_22ExtensionPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define AQ_PcsStandardDevicesInPackage_HHD_clause_22ExtensionPresent 1
/*! \brief Preprocessor variable to relate field to bit position in structure clause_22ExtensionPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define bits_AQ_PcsStandardDevicesInPackage_HHD_clause_22ExtensionPresent u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure clause_22ExtensionPresent in AQ_PcsStandardDevicesInPackage_HHD */
#define word_AQ_PcsStandardDevicesInPackage_HHD_clause_22ExtensionPresent u1.word_1

/*! \brief Base register address of structure AQ_PcsStandardControl_2_HHD */
#define AQ_PcsStandardControl_2_HHD_baseRegisterAddress 0x0007
/*! \brief MMD address of structure AQ_PcsStandardControl_2_HHD */
#define AQ_PcsStandardControl_2_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure pcsDeviceType in AQ_PcsStandardControl_2_HHD */
#define AQ_PcsStandardControl_2_HHD_pcsDeviceType 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsDeviceType in AQ_PcsStandardControl_2_HHD */
#define bits_AQ_PcsStandardControl_2_HHD_pcsDeviceType u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsDeviceType in AQ_PcsStandardControl_2_HHD */
#define word_AQ_PcsStandardControl_2_HHD_pcsDeviceType u0.word_0

/*! \brief Base register address of structure AQ_PcsStandardStatus_2_HHD */
#define AQ_PcsStandardStatus_2_HHD_baseRegisterAddress 0x0008
/*! \brief MMD address of structure AQ_PcsStandardStatus_2_HHD */
#define AQ_PcsStandardStatus_2_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure devicePresent in AQ_PcsStandardStatus_2_HHD */
#define AQ_PcsStandardStatus_2_HHD_devicePresent 0
/*! \brief Preprocessor variable to relate field to bit position in structure devicePresent in AQ_PcsStandardStatus_2_HHD */
#define bits_AQ_PcsStandardStatus_2_HHD_devicePresent u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure devicePresent in AQ_PcsStandardStatus_2_HHD */
#define word_AQ_PcsStandardStatus_2_HHD_devicePresent u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure transmitFault in AQ_PcsStandardStatus_2_HHD */
#define AQ_PcsStandardStatus_2_HHD_transmitFault 0
/*! \brief Preprocessor variable to relate field to bit position in structure transmitFault in AQ_PcsStandardStatus_2_HHD */
#define bits_AQ_PcsStandardStatus_2_HHD_transmitFault u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure transmitFault in AQ_PcsStandardStatus_2_HHD */
#define word_AQ_PcsStandardStatus_2_HHD_transmitFault u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure receiveFault in AQ_PcsStandardStatus_2_HHD */
#define AQ_PcsStandardStatus_2_HHD_receiveFault 0
/*! \brief Preprocessor variable to relate field to bit position in structure receiveFault in AQ_PcsStandardStatus_2_HHD */
#define bits_AQ_PcsStandardStatus_2_HHD_receiveFault u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure receiveFault in AQ_PcsStandardStatus_2_HHD */
#define word_AQ_PcsStandardStatus_2_HHD_receiveFault u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tCapable in AQ_PcsStandardStatus_2_HHD */
#define AQ_PcsStandardStatus_2_HHD__10gbase_tCapable 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tCapable in AQ_PcsStandardStatus_2_HHD */
#define bits_AQ_PcsStandardStatus_2_HHD__10gbase_tCapable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tCapable in AQ_PcsStandardStatus_2_HHD */
#define word_AQ_PcsStandardStatus_2_HHD__10gbase_tCapable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_wCapable in AQ_PcsStandardStatus_2_HHD */
#define AQ_PcsStandardStatus_2_HHD__10gbase_wCapable 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_wCapable in AQ_PcsStandardStatus_2_HHD */
#define bits_AQ_PcsStandardStatus_2_HHD__10gbase_wCapable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_wCapable in AQ_PcsStandardStatus_2_HHD */
#define word_AQ_PcsStandardStatus_2_HHD__10gbase_wCapable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_xCapable in AQ_PcsStandardStatus_2_HHD */
#define AQ_PcsStandardStatus_2_HHD__10gbase_xCapable 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_xCapable in AQ_PcsStandardStatus_2_HHD */
#define bits_AQ_PcsStandardStatus_2_HHD__10gbase_xCapable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_xCapable in AQ_PcsStandardStatus_2_HHD */
#define word_AQ_PcsStandardStatus_2_HHD__10gbase_xCapable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_rCapable in AQ_PcsStandardStatus_2_HHD */
#define AQ_PcsStandardStatus_2_HHD__10gbase_rCapable 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_rCapable in AQ_PcsStandardStatus_2_HHD */
#define bits_AQ_PcsStandardStatus_2_HHD__10gbase_rCapable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_rCapable in AQ_PcsStandardStatus_2_HHD */
#define word_AQ_PcsStandardStatus_2_HHD__10gbase_rCapable u0.word_0

/*! \brief Base register address of structure AQ_PcsStandardPackageIdentifier_HHD */
#define AQ_PcsStandardPackageIdentifier_HHD_baseRegisterAddress 0x000E
/*! \brief MMD address of structure AQ_PcsStandardPackageIdentifier_HHD */
#define AQ_PcsStandardPackageIdentifier_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure packageIdMSW in AQ_PcsStandardPackageIdentifier_HHD */
#define AQ_PcsStandardPackageIdentifier_HHD_packageIdMSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure packageIdMSW in AQ_PcsStandardPackageIdentifier_HHD */
#define bits_AQ_PcsStandardPackageIdentifier_HHD_packageIdMSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure packageIdMSW in AQ_PcsStandardPackageIdentifier_HHD */
#define word_AQ_PcsStandardPackageIdentifier_HHD_packageIdMSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure packageIdLSW in AQ_PcsStandardPackageIdentifier_HHD */
#define AQ_PcsStandardPackageIdentifier_HHD_packageIdLSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure packageIdLSW in AQ_PcsStandardPackageIdentifier_HHD */
#define bits_AQ_PcsStandardPackageIdentifier_HHD_packageIdLSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure packageIdLSW in AQ_PcsStandardPackageIdentifier_HHD */
#define word_AQ_PcsStandardPackageIdentifier_HHD_packageIdLSW u1.word_1

/*! \brief Base register address of structure AQ_PcsEeeCapabilityRegister_HHD */
#define AQ_PcsEeeCapabilityRegister_HHD_baseRegisterAddress 0x0014
/*! \brief MMD address of structure AQ_PcsEeeCapabilityRegister_HHD */
#define AQ_PcsEeeCapabilityRegister_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_krEee in AQ_PcsEeeCapabilityRegister_HHD */
#define AQ_PcsEeeCapabilityRegister_HHD__10gbase_krEee 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_krEee in AQ_PcsEeeCapabilityRegister_HHD */
#define bits_AQ_PcsEeeCapabilityRegister_HHD__10gbase_krEee u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_krEee in AQ_PcsEeeCapabilityRegister_HHD */
#define word_AQ_PcsEeeCapabilityRegister_HHD__10gbase_krEee u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_kx4Eee in AQ_PcsEeeCapabilityRegister_HHD */
#define AQ_PcsEeeCapabilityRegister_HHD__10gbase_kx4Eee 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_kx4Eee in AQ_PcsEeeCapabilityRegister_HHD */
#define bits_AQ_PcsEeeCapabilityRegister_HHD__10gbase_kx4Eee u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_kx4Eee in AQ_PcsEeeCapabilityRegister_HHD */
#define word_AQ_PcsEeeCapabilityRegister_HHD__10gbase_kx4Eee u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _1000base_kxEee in AQ_PcsEeeCapabilityRegister_HHD */
#define AQ_PcsEeeCapabilityRegister_HHD__1000base_kxEee 0
/*! \brief Preprocessor variable to relate field to bit position in structure _1000base_kxEee in AQ_PcsEeeCapabilityRegister_HHD */
#define bits_AQ_PcsEeeCapabilityRegister_HHD__1000base_kxEee u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _1000base_kxEee in AQ_PcsEeeCapabilityRegister_HHD */
#define word_AQ_PcsEeeCapabilityRegister_HHD__1000base_kxEee u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tEee in AQ_PcsEeeCapabilityRegister_HHD */
#define AQ_PcsEeeCapabilityRegister_HHD__10gbase_tEee 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tEee in AQ_PcsEeeCapabilityRegister_HHD */
#define bits_AQ_PcsEeeCapabilityRegister_HHD__10gbase_tEee u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tEee in AQ_PcsEeeCapabilityRegister_HHD */
#define word_AQ_PcsEeeCapabilityRegister_HHD__10gbase_tEee u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _1000base_tEee in AQ_PcsEeeCapabilityRegister_HHD */
#define AQ_PcsEeeCapabilityRegister_HHD__1000base_tEee 0
/*! \brief Preprocessor variable to relate field to bit position in structure _1000base_tEee in AQ_PcsEeeCapabilityRegister_HHD */
#define bits_AQ_PcsEeeCapabilityRegister_HHD__1000base_tEee u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _1000base_tEee in AQ_PcsEeeCapabilityRegister_HHD */
#define word_AQ_PcsEeeCapabilityRegister_HHD__1000base_tEee u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _100base_txEee in AQ_PcsEeeCapabilityRegister_HHD */
#define AQ_PcsEeeCapabilityRegister_HHD__100base_txEee 0
/*! \brief Preprocessor variable to relate field to bit position in structure _100base_txEee in AQ_PcsEeeCapabilityRegister_HHD */
#define bits_AQ_PcsEeeCapabilityRegister_HHD__100base_txEee u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _100base_txEee in AQ_PcsEeeCapabilityRegister_HHD */
#define word_AQ_PcsEeeCapabilityRegister_HHD__100base_txEee u0.word_0

/*! \brief Base register address of structure AQ_PcsEeeWakeErrorCounter_HHD */
#define AQ_PcsEeeWakeErrorCounter_HHD_baseRegisterAddress 0x0016
/*! \brief MMD address of structure AQ_PcsEeeWakeErrorCounter_HHD */
#define AQ_PcsEeeWakeErrorCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure eeeWakeErrorCounter in AQ_PcsEeeWakeErrorCounter_HHD */
#define AQ_PcsEeeWakeErrorCounter_HHD_eeeWakeErrorCounter 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeWakeErrorCounter in AQ_PcsEeeWakeErrorCounter_HHD */
#define bits_AQ_PcsEeeWakeErrorCounter_HHD_eeeWakeErrorCounter u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeWakeErrorCounter in AQ_PcsEeeWakeErrorCounter_HHD */
#define word_AQ_PcsEeeWakeErrorCounter_HHD_eeeWakeErrorCounter u0.word_0

/*! \brief Base register address of structure AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD_baseRegisterAddress 0x0020
/*! \brief MMD address of structure AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure _10gReceiveLinkStatus in AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD__10gReceiveLinkStatus 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gReceiveLinkStatus in AQ_Pcs10G_Status_HHD */
#define bits_AQ_Pcs10G_Status_HHD__10gReceiveLinkStatus u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gReceiveLinkStatus in AQ_Pcs10G_Status_HHD */
#define word_AQ_Pcs10G_Status_HHD__10gReceiveLinkStatus u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_rPrbs9PatternTestingAbility in AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD__10gbase_rPrbs9PatternTestingAbility 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_rPrbs9PatternTestingAbility in AQ_Pcs10G_Status_HHD */
#define bits_AQ_Pcs10G_Status_HHD__10gbase_rPrbs9PatternTestingAbility u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_rPrbs9PatternTestingAbility in AQ_Pcs10G_Status_HHD */
#define word_AQ_Pcs10G_Status_HHD__10gbase_rPrbs9PatternTestingAbility u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_rPrbs31PatternTestingAbility in AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD__10gbase_rPrbs31PatternTestingAbility 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_rPrbs31PatternTestingAbility in AQ_Pcs10G_Status_HHD */
#define bits_AQ_Pcs10G_Status_HHD__10gbase_rPrbs31PatternTestingAbility u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_rPrbs31PatternTestingAbility in AQ_Pcs10G_Status_HHD */
#define word_AQ_Pcs10G_Status_HHD__10gbase_rPrbs31PatternTestingAbility u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gHighBer in AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD__10gHighBer 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gHighBer in AQ_Pcs10G_Status_HHD */
#define bits_AQ_Pcs10G_Status_HHD__10gHighBer u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gHighBer in AQ_Pcs10G_Status_HHD */
#define word_AQ_Pcs10G_Status_HHD__10gHighBer u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gPcsBlockLock in AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD__10gPcsBlockLock 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gPcsBlockLock in AQ_Pcs10G_Status_HHD */
#define bits_AQ_Pcs10G_Status_HHD__10gPcsBlockLock u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gPcsBlockLock in AQ_Pcs10G_Status_HHD */
#define word_AQ_Pcs10G_Status_HHD__10gPcsBlockLock u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pcsBlockLockLatched in AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD_pcsBlockLockLatched 1
/*! \brief Preprocessor variable to relate field to bit position in structure pcsBlockLockLatched in AQ_Pcs10G_Status_HHD */
#define bits_AQ_Pcs10G_Status_HHD_pcsBlockLockLatched u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure pcsBlockLockLatched in AQ_Pcs10G_Status_HHD */
#define word_AQ_Pcs10G_Status_HHD_pcsBlockLockLatched u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure highBerLatched in AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD_highBerLatched 1
/*! \brief Preprocessor variable to relate field to bit position in structure highBerLatched in AQ_Pcs10G_Status_HHD */
#define bits_AQ_Pcs10G_Status_HHD_highBerLatched u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure highBerLatched in AQ_Pcs10G_Status_HHD */
#define word_AQ_Pcs10G_Status_HHD_highBerLatched u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure erroredFrameCounter in AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD_erroredFrameCounter 1
/*! \brief Preprocessor variable to relate field to bit position in structure erroredFrameCounter in AQ_Pcs10G_Status_HHD */
#define bits_AQ_Pcs10G_Status_HHD_erroredFrameCounter u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure erroredFrameCounter in AQ_Pcs10G_Status_HHD */
#define word_AQ_Pcs10G_Status_HHD_erroredFrameCounter u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure erroredBlockCounter in AQ_Pcs10G_Status_HHD */
#define AQ_Pcs10G_Status_HHD_erroredBlockCounter 1
/*! \brief Preprocessor variable to relate field to bit position in structure erroredBlockCounter in AQ_Pcs10G_Status_HHD */
#define bits_AQ_Pcs10G_Status_HHD_erroredBlockCounter u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure erroredBlockCounter in AQ_Pcs10G_Status_HHD */
#define word_AQ_Pcs10G_Status_HHD_erroredBlockCounter u1.word_1

/*! \brief Base register address of structure AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedA_HHD_baseRegisterAddress 0x0022
/*! \brief MMD address of structure AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedA_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure testPatternSeedABits_15_0 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_15_0 0
/*! \brief Preprocessor variable to relate field to bit position in structure testPatternSeedABits_15_0 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define bits_AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_15_0 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure testPatternSeedABits_15_0 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define word_AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_15_0 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure testPatternSeedABits_31_16 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_31_16 1
/*! \brief Preprocessor variable to relate field to bit position in structure testPatternSeedABits_31_16 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define bits_AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_31_16 u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure testPatternSeedABits_31_16 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define word_AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_31_16 u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure testPatternSeedABits_47_32 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_47_32 2
/*! \brief Preprocessor variable to relate field to bit position in structure testPatternSeedABits_47_32 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define bits_AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_47_32 u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure testPatternSeedABits_47_32 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define word_AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_47_32 u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure testPatternSeedABits_57_48 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_57_48 3
/*! \brief Preprocessor variable to relate field to bit position in structure testPatternSeedABits_57_48 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define bits_AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_57_48 u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure testPatternSeedABits_57_48 in AQ_Pcs10G_base_rTestPatternSeedA_HHD */
#define word_AQ_Pcs10G_base_rTestPatternSeedA_HHD_testPatternSeedABits_57_48 u3.word_3

/*! \brief Base register address of structure AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedB_HHD_baseRegisterAddress 0x0026
/*! \brief MMD address of structure AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedB_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure testPatternSeedBBits_15_0 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_15_0 0
/*! \brief Preprocessor variable to relate field to bit position in structure testPatternSeedBBits_15_0 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define bits_AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_15_0 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure testPatternSeedBBits_15_0 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define word_AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_15_0 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure testPatternSeedBBits_31_16 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_31_16 1
/*! \brief Preprocessor variable to relate field to bit position in structure testPatternSeedBBits_31_16 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define bits_AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_31_16 u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure testPatternSeedBBits_31_16 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define word_AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_31_16 u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure testPatternSeedBBits_47_32 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_47_32 2
/*! \brief Preprocessor variable to relate field to bit position in structure testPatternSeedBBits_47_32 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define bits_AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_47_32 u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure testPatternSeedBBits_47_32 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define word_AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_47_32 u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure testPatternSeedBBits_57_48 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_57_48 3
/*! \brief Preprocessor variable to relate field to bit position in structure testPatternSeedBBits_57_48 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define bits_AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_57_48 u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure testPatternSeedBBits_57_48 in AQ_Pcs10G_base_rTestPatternSeedB_HHD */
#define word_AQ_Pcs10G_base_rTestPatternSeedB_HHD_testPatternSeedBBits_57_48 u3.word_3

/*! \brief Base register address of structure AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternControl_HHD_baseRegisterAddress 0x002A
/*! \brief MMD address of structure AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternControl_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure prbs9TransmitTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternControl_HHD_prbs9TransmitTest_patternEnable 0
/*! \brief Preprocessor variable to relate field to bit position in structure prbs9TransmitTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define bits_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_prbs9TransmitTest_patternEnable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure prbs9TransmitTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define word_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_prbs9TransmitTest_patternEnable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure prbs31ReceiveTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternControl_HHD_prbs31ReceiveTest_patternEnable 0
/*! \brief Preprocessor variable to relate field to bit position in structure prbs31ReceiveTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define bits_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_prbs31ReceiveTest_patternEnable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure prbs31ReceiveTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define word_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_prbs31ReceiveTest_patternEnable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure prbs31TransmitTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternControl_HHD_prbs31TransmitTest_patternEnable 0
/*! \brief Preprocessor variable to relate field to bit position in structure prbs31TransmitTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define bits_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_prbs31TransmitTest_patternEnable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure prbs31TransmitTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define word_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_prbs31TransmitTest_patternEnable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure transmitTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternControl_HHD_transmitTest_patternEnable 0
/*! \brief Preprocessor variable to relate field to bit position in structure transmitTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define bits_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_transmitTest_patternEnable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure transmitTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define word_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_transmitTest_patternEnable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure receiveTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternControl_HHD_receiveTest_patternEnable 0
/*! \brief Preprocessor variable to relate field to bit position in structure receiveTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define bits_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_receiveTest_patternEnable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure receiveTest_patternEnable in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define word_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_receiveTest_patternEnable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure test_patternSelect in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternControl_HHD_test_patternSelect 0
/*! \brief Preprocessor variable to relate field to bit position in structure test_patternSelect in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define bits_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_test_patternSelect u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure test_patternSelect in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define word_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_test_patternSelect u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure dataPatternSelect in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternControl_HHD_dataPatternSelect 0
/*! \brief Preprocessor variable to relate field to bit position in structure dataPatternSelect in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define bits_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_dataPatternSelect u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure dataPatternSelect in AQ_Pcs10G_base_rPcsTest_patternControl_HHD */
#define word_AQ_Pcs10G_base_rPcsTest_patternControl_HHD_dataPatternSelect u0.word_0

/*! \brief Base register address of structure AQ_Pcs10G_base_rPcsTest_patternErrorCounter_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternErrorCounter_HHD_baseRegisterAddress 0x002B
/*! \brief MMD address of structure AQ_Pcs10G_base_rPcsTest_patternErrorCounter_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternErrorCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure test_patternErrorCounter in AQ_Pcs10G_base_rPcsTest_patternErrorCounter_HHD */
#define AQ_Pcs10G_base_rPcsTest_patternErrorCounter_HHD_test_patternErrorCounter 0
/*! \brief Preprocessor variable to relate field to bit position in structure test_patternErrorCounter in AQ_Pcs10G_base_rPcsTest_patternErrorCounter_HHD */
#define bits_AQ_Pcs10G_base_rPcsTest_patternErrorCounter_HHD_test_patternErrorCounter u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure test_patternErrorCounter in AQ_Pcs10G_base_rPcsTest_patternErrorCounter_HHD */
#define word_AQ_Pcs10G_base_rPcsTest_patternErrorCounter_HHD_test_patternErrorCounter u0.word_0

/*! \brief Base register address of structure AQ_TimesyncPcsCapability_HHD */
#define AQ_TimesyncPcsCapability_HHD_baseRegisterAddress 0x1800
/*! \brief MMD address of structure AQ_TimesyncPcsCapability_HHD */
#define AQ_TimesyncPcsCapability_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure timesyncTransmitPathDataDelay in AQ_TimesyncPcsCapability_HHD */
#define AQ_TimesyncPcsCapability_HHD_timesyncTransmitPathDataDelay 0
/*! \brief Preprocessor variable to relate field to bit position in structure timesyncTransmitPathDataDelay in AQ_TimesyncPcsCapability_HHD */
#define bits_AQ_TimesyncPcsCapability_HHD_timesyncTransmitPathDataDelay u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure timesyncTransmitPathDataDelay in AQ_TimesyncPcsCapability_HHD */
#define word_AQ_TimesyncPcsCapability_HHD_timesyncTransmitPathDataDelay u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure timesyncReceivePathDataDelay in AQ_TimesyncPcsCapability_HHD */
#define AQ_TimesyncPcsCapability_HHD_timesyncReceivePathDataDelay 0
/*! \brief Preprocessor variable to relate field to bit position in structure timesyncReceivePathDataDelay in AQ_TimesyncPcsCapability_HHD */
#define bits_AQ_TimesyncPcsCapability_HHD_timesyncReceivePathDataDelay u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure timesyncReceivePathDataDelay in AQ_TimesyncPcsCapability_HHD */
#define word_AQ_TimesyncPcsCapability_HHD_timesyncReceivePathDataDelay u0.word_0

/*! \brief Base register address of structure AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define AQ_TimesyncPcsTransmitPathDataDelay_HHD_baseRegisterAddress 0x1801
/*! \brief MMD address of structure AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define AQ_TimesyncPcsTransmitPathDataDelay_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure maximumPcsTransmitPathDataDelayLSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define AQ_TimesyncPcsTransmitPathDataDelay_HHD_maximumPcsTransmitPathDataDelayLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure maximumPcsTransmitPathDataDelayLSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define bits_AQ_TimesyncPcsTransmitPathDataDelay_HHD_maximumPcsTransmitPathDataDelayLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure maximumPcsTransmitPathDataDelayLSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define word_AQ_TimesyncPcsTransmitPathDataDelay_HHD_maximumPcsTransmitPathDataDelayLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure maximumPcsTransmitPathDataDelayMSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define AQ_TimesyncPcsTransmitPathDataDelay_HHD_maximumPcsTransmitPathDataDelayMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure maximumPcsTransmitPathDataDelayMSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define bits_AQ_TimesyncPcsTransmitPathDataDelay_HHD_maximumPcsTransmitPathDataDelayMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure maximumPcsTransmitPathDataDelayMSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define word_AQ_TimesyncPcsTransmitPathDataDelay_HHD_maximumPcsTransmitPathDataDelayMSW u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure minimumPcsTransmitPathDataDelayLSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define AQ_TimesyncPcsTransmitPathDataDelay_HHD_minimumPcsTransmitPathDataDelayLSW 2
/*! \brief Preprocessor variable to relate field to bit position in structure minimumPcsTransmitPathDataDelayLSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define bits_AQ_TimesyncPcsTransmitPathDataDelay_HHD_minimumPcsTransmitPathDataDelayLSW u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure minimumPcsTransmitPathDataDelayLSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define word_AQ_TimesyncPcsTransmitPathDataDelay_HHD_minimumPcsTransmitPathDataDelayLSW u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure minimumPcsTransmitPathDataDelayMSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define AQ_TimesyncPcsTransmitPathDataDelay_HHD_minimumPcsTransmitPathDataDelayMSW 3
/*! \brief Preprocessor variable to relate field to bit position in structure minimumPcsTransmitPathDataDelayMSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define bits_AQ_TimesyncPcsTransmitPathDataDelay_HHD_minimumPcsTransmitPathDataDelayMSW u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure minimumPcsTransmitPathDataDelayMSW in AQ_TimesyncPcsTransmitPathDataDelay_HHD */
#define word_AQ_TimesyncPcsTransmitPathDataDelay_HHD_minimumPcsTransmitPathDataDelayMSW u3.word_3

/*! \brief Base register address of structure AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define AQ_TimesyncPcsReceivePathDataDelay_HHD_baseRegisterAddress 0x1805
/*! \brief MMD address of structure AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define AQ_TimesyncPcsReceivePathDataDelay_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure maximumPcsReceivePathDataDelayLSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define AQ_TimesyncPcsReceivePathDataDelay_HHD_maximumPcsReceivePathDataDelayLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure maximumPcsReceivePathDataDelayLSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define bits_AQ_TimesyncPcsReceivePathDataDelay_HHD_maximumPcsReceivePathDataDelayLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure maximumPcsReceivePathDataDelayLSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define word_AQ_TimesyncPcsReceivePathDataDelay_HHD_maximumPcsReceivePathDataDelayLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure maximumPcsReceivePathDataDelayMSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define AQ_TimesyncPcsReceivePathDataDelay_HHD_maximumPcsReceivePathDataDelayMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure maximumPcsReceivePathDataDelayMSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define bits_AQ_TimesyncPcsReceivePathDataDelay_HHD_maximumPcsReceivePathDataDelayMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure maximumPcsReceivePathDataDelayMSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define word_AQ_TimesyncPcsReceivePathDataDelay_HHD_maximumPcsReceivePathDataDelayMSW u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure minimumPcsReceivePathDataDelayLSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define AQ_TimesyncPcsReceivePathDataDelay_HHD_minimumPcsReceivePathDataDelayLSW 2
/*! \brief Preprocessor variable to relate field to bit position in structure minimumPcsReceivePathDataDelayLSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define bits_AQ_TimesyncPcsReceivePathDataDelay_HHD_minimumPcsReceivePathDataDelayLSW u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure minimumPcsReceivePathDataDelayLSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define word_AQ_TimesyncPcsReceivePathDataDelay_HHD_minimumPcsReceivePathDataDelayLSW u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure minimumPcsReceivePathDataDelayMSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define AQ_TimesyncPcsReceivePathDataDelay_HHD_minimumPcsReceivePathDataDelayMSW 3
/*! \brief Preprocessor variable to relate field to bit position in structure minimumPcsReceivePathDataDelayMSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define bits_AQ_TimesyncPcsReceivePathDataDelay_HHD_minimumPcsReceivePathDataDelayMSW u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure minimumPcsReceivePathDataDelayMSW in AQ_TimesyncPcsReceivePathDataDelay_HHD */
#define word_AQ_TimesyncPcsReceivePathDataDelay_HHD_minimumPcsReceivePathDataDelayMSW u3.word_3

/*! \brief Base register address of structure AQ_PcsTransmitVendorProvisioning_HHD */
#define AQ_PcsTransmitVendorProvisioning_HHD_baseRegisterAddress 0xC400
/*! \brief MMD address of structure AQ_PcsTransmitVendorProvisioning_HHD */
#define AQ_PcsTransmitVendorProvisioning_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure pcsTxAuxilliaryBitValue in AQ_PcsTransmitVendorProvisioning_HHD */
#define AQ_PcsTransmitVendorProvisioning_HHD_pcsTxAuxilliaryBitValue 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsTxAuxilliaryBitValue in AQ_PcsTransmitVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitVendorProvisioning_HHD_pcsTxAuxilliaryBitValue u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsTxAuxilliaryBitValue in AQ_PcsTransmitVendorProvisioning_HHD */
#define word_AQ_PcsTransmitVendorProvisioning_HHD_pcsTxAuxilliaryBitValue u0.word_0

/*! \brief Base register address of structure AQ_PcsTransmitReservedVendorProvisioning_HHD */
#define AQ_PcsTransmitReservedVendorProvisioning_HHD_baseRegisterAddress 0xC410
/*! \brief MMD address of structure AQ_PcsTransmitReservedVendorProvisioning_HHD */
#define AQ_PcsTransmitReservedVendorProvisioning_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure reservedTransmitProvisioning_1 in AQ_PcsTransmitReservedVendorProvisioning_HHD */
#define AQ_PcsTransmitReservedVendorProvisioning_HHD_reservedTransmitProvisioning_1 0
/*! \brief Preprocessor variable to relate field to bit position in structure reservedTransmitProvisioning_1 in AQ_PcsTransmitReservedVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitReservedVendorProvisioning_HHD_reservedTransmitProvisioning_1 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure reservedTransmitProvisioning_1 in AQ_PcsTransmitReservedVendorProvisioning_HHD */
#define word_AQ_PcsTransmitReservedVendorProvisioning_HHD_reservedTransmitProvisioning_1 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pcsIEEE_LoopbackPassthroughDisable in AQ_PcsTransmitReservedVendorProvisioning_HHD */
#define AQ_PcsTransmitReservedVendorProvisioning_HHD_pcsIEEE_LoopbackPassthroughDisable 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsIEEE_LoopbackPassthroughDisable in AQ_PcsTransmitReservedVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitReservedVendorProvisioning_HHD_pcsIEEE_LoopbackPassthroughDisable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsIEEE_LoopbackPassthroughDisable in AQ_PcsTransmitReservedVendorProvisioning_HHD */
#define word_AQ_PcsTransmitReservedVendorProvisioning_HHD_pcsIEEE_LoopbackPassthroughDisable u0.word_0

/*! \brief Base register address of structure AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define AQ_PcsTransmitXfiVendorProvisioning_HHD_baseRegisterAddress 0xC455
/*! \brief MMD address of structure AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define AQ_PcsTransmitXfiVendorProvisioning_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure xfiTestPatternSeedAWord_0 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_0 0
/*! \brief Preprocessor variable to relate field to bit position in structure xfiTestPatternSeedAWord_0 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_0 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xfiTestPatternSeedAWord_0 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_0 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfiTestPatternSeedAWord_1 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_1 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfiTestPatternSeedAWord_1 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_1 u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfiTestPatternSeedAWord_1 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_1 u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfiTestPatternSeedAWord_2 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_2 2
/*! \brief Preprocessor variable to relate field to bit position in structure xfiTestPatternSeedAWord_2 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_2 u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure xfiTestPatternSeedAWord_2 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_2 u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure xfiTestPatternSeedAWord_3 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_3 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfiTestPatternSeedAWord_3 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_3 u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfiTestPatternSeedAWord_3 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedAWord_3 u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfiTestPatternSeedBWord_0 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_0 4
/*! \brief Preprocessor variable to relate field to bit position in structure xfiTestPatternSeedBWord_0 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_0 u4.bits_4
/*! \brief Preprocessor variable to relate field to word position in structure xfiTestPatternSeedBWord_0 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_0 u4.word_4
/*! \brief Preprocessor variable to relate field to word number in structure xfiTestPatternSeedBWord_1 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_1 5
/*! \brief Preprocessor variable to relate field to bit position in structure xfiTestPatternSeedBWord_1 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_1 u5.bits_5
/*! \brief Preprocessor variable to relate field to word position in structure xfiTestPatternSeedBWord_1 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_1 u5.word_5
/*! \brief Preprocessor variable to relate field to word number in structure xfiTestPatternSeedBWord_2 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_2 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfiTestPatternSeedBWord_2 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_2 u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfiTestPatternSeedBWord_2 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_2 u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfiTestPatternSeedBWord_3 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_3 7
/*! \brief Preprocessor variable to relate field to bit position in structure xfiTestPatternSeedBWord_3 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_3 u7.bits_7
/*! \brief Preprocessor variable to relate field to word position in structure xfiTestPatternSeedBWord_3 in AQ_PcsTransmitXfiVendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfiVendorProvisioning_HHD_xfiTestPatternSeedBWord_3 u7.word_7

/*! \brief Base register address of structure AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_baseRegisterAddress 0xC460
/*! \brief MMD address of structure AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure xfi0PcsScramblerDisable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0PcsScramblerDisable 0
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0PcsScramblerDisable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0PcsScramblerDisable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xfi0PcsScramblerDisable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0PcsScramblerDisable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestSqaureWaveTestDuration in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestSqaureWaveTestDuration 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestSqaureWaveTestDuration in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestSqaureWaveTestDuration u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestSqaureWaveTestDuration in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestSqaureWaveTestDuration u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestDataSelect in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestDataSelect 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestDataSelect in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestDataSelect u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestDataSelect in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestDataSelect u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestModeSelect in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestModeSelect 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestModeSelect in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestModeSelect u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestModeSelect in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestModeSelect u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestPrbs_9Enable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestPrbs_9Enable 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestPrbs_9Enable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestPrbs_9Enable u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestPrbs_9Enable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestPrbs_9Enable u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestPrbs_31Enable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestPrbs_31Enable 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestPrbs_31Enable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestPrbs_31Enable u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestPrbs_31Enable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestPrbs_31Enable u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestPatternEnable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestPatternEnable 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestPatternEnable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestPatternEnable u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestPatternEnable in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0TestPatternEnable u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0LocalFaultInject in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0LocalFaultInject 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0LocalFaultInject in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0LocalFaultInject u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0LocalFaultInject in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0LocalFaultInject u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0InjectSingleError in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0InjectSingleError 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0InjectSingleError in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0InjectSingleError u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0InjectSingleError in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0InjectSingleError u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0PcsHighBerInject in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0PcsHighBerInject 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0PcsHighBerInject in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0PcsHighBerInject u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0PcsHighBerInject in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0PcsHighBerInject u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0PcsLossOfLockInject in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0PcsLossOfLockInject 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0PcsLossOfLockInject in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0PcsLossOfLockInject u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0PcsLossOfLockInject in AQ_PcsTransmitXfi0VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi0VendorProvisioning_HHD_xfi0PcsLossOfLockInject u1.word_1

/*! \brief Base register address of structure AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_baseRegisterAddress 0xC470
/*! \brief MMD address of structure AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure xfi1PcsScramblerDisable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1PcsScramblerDisable 0
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1PcsScramblerDisable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1PcsScramblerDisable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xfi1PcsScramblerDisable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1PcsScramblerDisable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TestSqaureWaveTestDuration in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestSqaureWaveTestDuration 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TestSqaureWaveTestDuration in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestSqaureWaveTestDuration u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TestSqaureWaveTestDuration in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestSqaureWaveTestDuration u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TestDataSelect in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestDataSelect 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TestDataSelect in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestDataSelect u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TestDataSelect in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestDataSelect u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TestModeSelect in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestModeSelect 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TestModeSelect in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestModeSelect u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TestModeSelect in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestModeSelect u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TestPrbs_9Enable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestPrbs_9Enable 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TestPrbs_9Enable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestPrbs_9Enable u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TestPrbs_9Enable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestPrbs_9Enable u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TestPrbs_31Enable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestPrbs_31Enable 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TestPrbs_31Enable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestPrbs_31Enable u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TestPrbs_31Enable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestPrbs_31Enable u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TestPatternEnable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestPatternEnable 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TestPatternEnable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestPatternEnable u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TestPatternEnable in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1TestPatternEnable u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1LocalFaultInject in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1LocalFaultInject 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1LocalFaultInject in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1LocalFaultInject u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1LocalFaultInject in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1LocalFaultInject u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1InjectSingleError in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1InjectSingleError 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1InjectSingleError in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1InjectSingleError u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1InjectSingleError in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1InjectSingleError u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1PcsHighBerInject in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1PcsHighBerInject 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1PcsHighBerInject in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1PcsHighBerInject u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1PcsHighBerInject in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1PcsHighBerInject u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1PcsLossOfLockInject in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1PcsLossOfLockInject 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1PcsLossOfLockInject in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define bits_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1PcsLossOfLockInject u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1PcsLossOfLockInject in AQ_PcsTransmitXfi1VendorProvisioning_HHD */
#define word_AQ_PcsTransmitXfi1VendorProvisioning_HHD_xfi1PcsLossOfLockInject u1.word_1

/*! \brief Base register address of structure AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define AQ_PcsSerdesMuxSwapTxrxRegister_HHD_baseRegisterAddress 0xC4F0
/*! \brief MMD address of structure AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define AQ_PcsSerdesMuxSwapTxrxRegister_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure serdesMuxSwapTxLane_3 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_3 0
/*! \brief Preprocessor variable to relate field to bit position in structure serdesMuxSwapTxLane_3 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define bits_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_3 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure serdesMuxSwapTxLane_3 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define word_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_3 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure serdesMuxSwapTxLane_2 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_2 0
/*! \brief Preprocessor variable to relate field to bit position in structure serdesMuxSwapTxLane_2 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define bits_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_2 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure serdesMuxSwapTxLane_2 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define word_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_2 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure serdesMuxSwapTxLane_1 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_1 0
/*! \brief Preprocessor variable to relate field to bit position in structure serdesMuxSwapTxLane_1 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define bits_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_1 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure serdesMuxSwapTxLane_1 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define word_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_1 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure serdesMuxSwapTxLane_0 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_0 0
/*! \brief Preprocessor variable to relate field to bit position in structure serdesMuxSwapTxLane_0 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define bits_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_0 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure serdesMuxSwapTxLane_0 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define word_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapTxLane_0 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure serdesMuxSwapRxLane_3 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_3 0
/*! \brief Preprocessor variable to relate field to bit position in structure serdesMuxSwapRxLane_3 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define bits_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_3 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure serdesMuxSwapRxLane_3 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define word_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_3 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure serdesMuxSwapRxLane_2 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_2 0
/*! \brief Preprocessor variable to relate field to bit position in structure serdesMuxSwapRxLane_2 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define bits_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_2 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure serdesMuxSwapRxLane_2 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define word_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_2 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure serdesMuxSwapRxLane_1 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_1 0
/*! \brief Preprocessor variable to relate field to bit position in structure serdesMuxSwapRxLane_1 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define bits_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_1 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure serdesMuxSwapRxLane_1 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define word_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_1 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure serdesMuxSwapRxLane_0 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_0 0
/*! \brief Preprocessor variable to relate field to bit position in structure serdesMuxSwapRxLane_0 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define bits_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_0 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure serdesMuxSwapRxLane_0 in AQ_PcsSerdesMuxSwapTxrxRegister_HHD */
#define word_AQ_PcsSerdesMuxSwapTxrxRegister_HHD_serdesMuxSwapRxLane_0 u0.word_0

/*! \brief Base register address of structure AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD */
#define AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD_baseRegisterAddress 0xC820
/*! \brief MMD address of structure AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD */
#define AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tGoodFrameCounterLSW in AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD */
#define AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tGoodFrameCounterLSW in AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD */
#define bits_AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tGoodFrameCounterLSW in AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD */
#define word_AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tGoodFrameCounterMSW in AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD */
#define AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tGoodFrameCounterMSW in AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD */
#define bits_AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tGoodFrameCounterMSW in AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD */
#define word_AQ_PcsTransmitVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD */
#define AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD_baseRegisterAddress 0xC822
/*! \brief MMD address of structure AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD */
#define AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tErrorFrameCounterLSW in AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD */
#define AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tErrorFrameCounterLSW in AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD */
#define bits_AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tErrorFrameCounterLSW in AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD */
#define word_AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tErrorFrameCounterMSW in AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD */
#define AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tErrorFrameCounterMSW in AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD */
#define bits_AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tErrorFrameCounterMSW in AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD */
#define word_AQ_PcsTransmitVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsTransmitXfi0VendorState_HHD */
#define AQ_PcsTransmitXfi0VendorState_HHD_baseRegisterAddress 0xC860
/*! \brief MMD address of structure AQ_PcsTransmitXfi0VendorState_HHD */
#define AQ_PcsTransmitXfi0VendorState_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure xfi0GoodFrameCounterLSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define AQ_PcsTransmitXfi0VendorState_HHD_xfi0GoodFrameCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0GoodFrameCounterLSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define bits_AQ_PcsTransmitXfi0VendorState_HHD_xfi0GoodFrameCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xfi0GoodFrameCounterLSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define word_AQ_PcsTransmitXfi0VendorState_HHD_xfi0GoodFrameCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfi0GoodFrameCounterMSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define AQ_PcsTransmitXfi0VendorState_HHD_xfi0GoodFrameCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0GoodFrameCounterMSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define bits_AQ_PcsTransmitXfi0VendorState_HHD_xfi0GoodFrameCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0GoodFrameCounterMSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define word_AQ_PcsTransmitXfi0VendorState_HHD_xfi0GoodFrameCounterMSW u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0BadFrameCounterLSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define AQ_PcsTransmitXfi0VendorState_HHD_xfi0BadFrameCounterLSW 2
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0BadFrameCounterLSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define bits_AQ_PcsTransmitXfi0VendorState_HHD_xfi0BadFrameCounterLSW u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure xfi0BadFrameCounterLSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define word_AQ_PcsTransmitXfi0VendorState_HHD_xfi0BadFrameCounterLSW u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure xfi0BadFrameCounterMSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define AQ_PcsTransmitXfi0VendorState_HHD_xfi0BadFrameCounterMSW 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0BadFrameCounterMSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define bits_AQ_PcsTransmitXfi0VendorState_HHD_xfi0BadFrameCounterMSW u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi0BadFrameCounterMSW in AQ_PcsTransmitXfi0VendorState_HHD */
#define word_AQ_PcsTransmitXfi0VendorState_HHD_xfi0BadFrameCounterMSW u3.word_3

/*! \brief Base register address of structure AQ_PcsTransmitXfi1VendorState_HHD */
#define AQ_PcsTransmitXfi1VendorState_HHD_baseRegisterAddress 0xC870
/*! \brief MMD address of structure AQ_PcsTransmitXfi1VendorState_HHD */
#define AQ_PcsTransmitXfi1VendorState_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure xfi1GoodFrameCounterLSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define AQ_PcsTransmitXfi1VendorState_HHD_xfi1GoodFrameCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1GoodFrameCounterLSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define bits_AQ_PcsTransmitXfi1VendorState_HHD_xfi1GoodFrameCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xfi1GoodFrameCounterLSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define word_AQ_PcsTransmitXfi1VendorState_HHD_xfi1GoodFrameCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfi1GoodFrameCounterMSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define AQ_PcsTransmitXfi1VendorState_HHD_xfi1GoodFrameCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1GoodFrameCounterMSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define bits_AQ_PcsTransmitXfi1VendorState_HHD_xfi1GoodFrameCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1GoodFrameCounterMSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define word_AQ_PcsTransmitXfi1VendorState_HHD_xfi1GoodFrameCounterMSW u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1BadFrameCounterLSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define AQ_PcsTransmitXfi1VendorState_HHD_xfi1BadFrameCounterLSW 2
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1BadFrameCounterLSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define bits_AQ_PcsTransmitXfi1VendorState_HHD_xfi1BadFrameCounterLSW u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure xfi1BadFrameCounterLSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define word_AQ_PcsTransmitXfi1VendorState_HHD_xfi1BadFrameCounterLSW u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure xfi1BadFrameCounterMSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define AQ_PcsTransmitXfi1VendorState_HHD_xfi1BadFrameCounterMSW 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1BadFrameCounterMSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define bits_AQ_PcsTransmitXfi1VendorState_HHD_xfi1BadFrameCounterMSW u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi1BadFrameCounterMSW in AQ_PcsTransmitXfi1VendorState_HHD */
#define word_AQ_PcsTransmitXfi1VendorState_HHD_xfi1BadFrameCounterMSW u3.word_3

/*! \brief Base register address of structure AQ_PcsTransmitXgsVendorState_HHD */
#define AQ_PcsTransmitXgsVendorState_HHD_baseRegisterAddress 0xC880
/*! \brief MMD address of structure AQ_PcsTransmitXgsVendorState_HHD */
#define AQ_PcsTransmitXgsVendorState_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure xgsCollisionEventsCounter_0 in AQ_PcsTransmitXgsVendorState_HHD */
#define AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_0 0
/*! \brief Preprocessor variable to relate field to bit position in structure xgsCollisionEventsCounter_0 in AQ_PcsTransmitXgsVendorState_HHD */
#define bits_AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_0 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xgsCollisionEventsCounter_0 in AQ_PcsTransmitXgsVendorState_HHD */
#define word_AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_0 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xgsCollisionEventsCounter_1 in AQ_PcsTransmitXgsVendorState_HHD */
#define AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_1 1
/*! \brief Preprocessor variable to relate field to bit position in structure xgsCollisionEventsCounter_1 in AQ_PcsTransmitXgsVendorState_HHD */
#define bits_AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_1 u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xgsCollisionEventsCounter_1 in AQ_PcsTransmitXgsVendorState_HHD */
#define word_AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_1 u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xgsCollisionEventsCounter_2 in AQ_PcsTransmitXgsVendorState_HHD */
#define AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_2 2
/*! \brief Preprocessor variable to relate field to bit position in structure xgsCollisionEventsCounter_2 in AQ_PcsTransmitXgsVendorState_HHD */
#define bits_AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_2 u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure xgsCollisionEventsCounter_2 in AQ_PcsTransmitXgsVendorState_HHD */
#define word_AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_2 u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure xgsCollisionEventsCounter_3 in AQ_PcsTransmitXgsVendorState_HHD */
#define AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_3 3
/*! \brief Preprocessor variable to relate field to bit position in structure xgsCollisionEventsCounter_3 in AQ_PcsTransmitXgsVendorState_HHD */
#define bits_AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_3 u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xgsCollisionEventsCounter_3 in AQ_PcsTransmitXgsVendorState_HHD */
#define word_AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_3 u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xgsCollisionEventsCounter_4 in AQ_PcsTransmitXgsVendorState_HHD */
#define AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_4 4
/*! \brief Preprocessor variable to relate field to bit position in structure xgsCollisionEventsCounter_4 in AQ_PcsTransmitXgsVendorState_HHD */
#define bits_AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_4 u4.bits_4
/*! \brief Preprocessor variable to relate field to word position in structure xgsCollisionEventsCounter_4 in AQ_PcsTransmitXgsVendorState_HHD */
#define word_AQ_PcsTransmitXgsVendorState_HHD_xgsCollisionEventsCounter_4 u4.word_4

/*! \brief Base register address of structure AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_baseRegisterAddress 0xCC00
/*! \brief MMD address of structure AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure reservedPcsTransmitVendorAlarms_1 in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_reservedPcsTransmitVendorAlarms_1 0
/*! \brief Preprocessor variable to relate field to bit position in structure reservedPcsTransmitVendorAlarms_1 in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_reservedPcsTransmitVendorAlarms_1 u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure reservedPcsTransmitVendorAlarms_1 in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_reservedPcsTransmitVendorAlarms_1 u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xauiTransmitInvalid_64bBlockDetected in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_xauiTransmitInvalid_64bBlockDetected 0
/*! \brief Preprocessor variable to relate field to bit position in structure xauiTransmitInvalid_64bBlockDetected in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_xauiTransmitInvalid_64bBlockDetected u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xauiTransmitInvalid_64bBlockDetected in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_xauiTransmitInvalid_64bBlockDetected u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure reservedPcsTransmitVendorAlarms_2 in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_reservedPcsTransmitVendorAlarms_2 1
/*! \brief Preprocessor variable to relate field to bit position in structure reservedPcsTransmitVendorAlarms_2 in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_reservedPcsTransmitVendorAlarms_2 u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure reservedPcsTransmitVendorAlarms_2 in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_reservedPcsTransmitVendorAlarms_2 u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure reservedPcsTransmitVendorAlarms_3 in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_reservedPcsTransmitVendorAlarms_3 2
/*! \brief Preprocessor variable to relate field to bit position in structure reservedPcsTransmitVendorAlarms_3 in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_reservedPcsTransmitVendorAlarms_3 u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure reservedPcsTransmitVendorAlarms_3 in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_reservedPcsTransmitVendorAlarms_3 u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TransmitInvalidXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_xfi1TransmitInvalidXgmiiCharacterReceived 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TransmitInvalidXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_xfi1TransmitInvalidXgmiiCharacterReceived u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TransmitInvalidXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_xfi1TransmitInvalidXgmiiCharacterReceived u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TransmitReservedXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_xfi1TransmitReservedXgmiiCharacterReceived 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TransmitReservedXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_xfi1TransmitReservedXgmiiCharacterReceived u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TransmitReservedXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_xfi1TransmitReservedXgmiiCharacterReceived u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi1Transmit_64bEncodeError in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_xfi1Transmit_64bEncodeError 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1Transmit_64bEncodeError in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_xfi1Transmit_64bEncodeError u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi1Transmit_64bEncodeError in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_xfi1Transmit_64bEncodeError u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TransmitLofDetected in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_xfi1TransmitLofDetected 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TransmitLofDetected in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_xfi1TransmitLofDetected u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TransmitLofDetected in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_xfi1TransmitLofDetected u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TransmitInvalidXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_xfi0TransmitInvalidXgmiiCharacterReceived 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TransmitInvalidXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_xfi0TransmitInvalidXgmiiCharacterReceived u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TransmitInvalidXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_xfi0TransmitInvalidXgmiiCharacterReceived u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TransmitReservedXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_xfi0TransmitReservedXgmiiCharacterReceived 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TransmitReservedXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_xfi0TransmitReservedXgmiiCharacterReceived u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TransmitReservedXgmiiCharacterReceived in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_xfi0TransmitReservedXgmiiCharacterReceived u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi0Transmit_64bEncodeError in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_xfi0Transmit_64bEncodeError 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0Transmit_64bEncodeError in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_xfi0Transmit_64bEncodeError u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi0Transmit_64bEncodeError in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_xfi0Transmit_64bEncodeError u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TransmitLofDetected in AQ_PcsTransmitVendorAlarms_HHD */
#define AQ_PcsTransmitVendorAlarms_HHD_xfi0TransmitLofDetected 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TransmitLofDetected in AQ_PcsTransmitVendorAlarms_HHD */
#define bits_AQ_PcsTransmitVendorAlarms_HHD_xfi0TransmitLofDetected u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TransmitLofDetected in AQ_PcsTransmitVendorAlarms_HHD */
#define word_AQ_PcsTransmitVendorAlarms_HHD_xfi0TransmitLofDetected u3.word_3

/*! \brief Base register address of structure AQ_PcsStandardInterruptMask_HHD */
#define AQ_PcsStandardInterruptMask_HHD_baseRegisterAddress 0xD000
/*! \brief MMD address of structure AQ_PcsStandardInterruptMask_HHD */
#define AQ_PcsStandardInterruptMask_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure txLpiReceivedMask in AQ_PcsStandardInterruptMask_HHD */
#define AQ_PcsStandardInterruptMask_HHD_txLpiReceivedMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure txLpiReceivedMask in AQ_PcsStandardInterruptMask_HHD */
#define bits_AQ_PcsStandardInterruptMask_HHD_txLpiReceivedMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure txLpiReceivedMask in AQ_PcsStandardInterruptMask_HHD */
#define word_AQ_PcsStandardInterruptMask_HHD_txLpiReceivedMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure rxLpiReceivedMask in AQ_PcsStandardInterruptMask_HHD */
#define AQ_PcsStandardInterruptMask_HHD_rxLpiReceivedMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure rxLpiReceivedMask in AQ_PcsStandardInterruptMask_HHD */
#define bits_AQ_PcsStandardInterruptMask_HHD_rxLpiReceivedMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure rxLpiReceivedMask in AQ_PcsStandardInterruptMask_HHD */
#define word_AQ_PcsStandardInterruptMask_HHD_rxLpiReceivedMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pcsReceiveLinkStatusMask in AQ_PcsStandardInterruptMask_HHD */
#define AQ_PcsStandardInterruptMask_HHD_pcsReceiveLinkStatusMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsReceiveLinkStatusMask in AQ_PcsStandardInterruptMask_HHD */
#define bits_AQ_PcsStandardInterruptMask_HHD_pcsReceiveLinkStatusMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsReceiveLinkStatusMask in AQ_PcsStandardInterruptMask_HHD */
#define word_AQ_PcsStandardInterruptMask_HHD_pcsReceiveLinkStatusMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure transmitFaultMask in AQ_PcsStandardInterruptMask_HHD */
#define AQ_PcsStandardInterruptMask_HHD_transmitFaultMask 1
/*! \brief Preprocessor variable to relate field to bit position in structure transmitFaultMask in AQ_PcsStandardInterruptMask_HHD */
#define bits_AQ_PcsStandardInterruptMask_HHD_transmitFaultMask u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure transmitFaultMask in AQ_PcsStandardInterruptMask_HHD */
#define word_AQ_PcsStandardInterruptMask_HHD_transmitFaultMask u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure receiveFaultMask in AQ_PcsStandardInterruptMask_HHD */
#define AQ_PcsStandardInterruptMask_HHD_receiveFaultMask 1
/*! \brief Preprocessor variable to relate field to bit position in structure receiveFaultMask in AQ_PcsStandardInterruptMask_HHD */
#define bits_AQ_PcsStandardInterruptMask_HHD_receiveFaultMask u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure receiveFaultMask in AQ_PcsStandardInterruptMask_HHD */
#define word_AQ_PcsStandardInterruptMask_HHD_receiveFaultMask u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tPcsBlockLockLatchedMask in AQ_PcsStandardInterruptMask_HHD */
#define AQ_PcsStandardInterruptMask_HHD__10gbase_tPcsBlockLockLatchedMask 2
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tPcsBlockLockLatchedMask in AQ_PcsStandardInterruptMask_HHD */
#define bits_AQ_PcsStandardInterruptMask_HHD__10gbase_tPcsBlockLockLatchedMask u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tPcsBlockLockLatchedMask in AQ_PcsStandardInterruptMask_HHD */
#define word_AQ_PcsStandardInterruptMask_HHD__10gbase_tPcsBlockLockLatchedMask u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tHighBerLatchedMask in AQ_PcsStandardInterruptMask_HHD */
#define AQ_PcsStandardInterruptMask_HHD__10gbase_tHighBerLatchedMask 2
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tHighBerLatchedMask in AQ_PcsStandardInterruptMask_HHD */
#define bits_AQ_PcsStandardInterruptMask_HHD__10gbase_tHighBerLatchedMask u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tHighBerLatchedMask in AQ_PcsStandardInterruptMask_HHD */
#define word_AQ_PcsStandardInterruptMask_HHD__10gbase_tHighBerLatchedMask u2.word_2

/*! \brief Base register address of structure AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_baseRegisterAddress 0xD400
/*! \brief MMD address of structure AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure reservedPcsTransmitVendorAlarms_1Mask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_reservedPcsTransmitVendorAlarms_1Mask 0
/*! \brief Preprocessor variable to relate field to bit position in structure reservedPcsTransmitVendorAlarms_1Mask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define bits_AQ_PcsTransmitVendorInterruptMask_HHD_reservedPcsTransmitVendorAlarms_1Mask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure reservedPcsTransmitVendorAlarms_1Mask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define word_AQ_PcsTransmitVendorInterruptMask_HHD_reservedPcsTransmitVendorAlarms_1Mask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xauiTransmitInvalid_64bBlockDetectedMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_xauiTransmitInvalid_64bBlockDetectedMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure xauiTransmitInvalid_64bBlockDetectedMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define bits_AQ_PcsTransmitVendorInterruptMask_HHD_xauiTransmitInvalid_64bBlockDetectedMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xauiTransmitInvalid_64bBlockDetectedMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define word_AQ_PcsTransmitVendorInterruptMask_HHD_xauiTransmitInvalid_64bBlockDetectedMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure reservedPcsTransmitVendorAlarms_2Mask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_reservedPcsTransmitVendorAlarms_2Mask 1
/*! \brief Preprocessor variable to relate field to bit position in structure reservedPcsTransmitVendorAlarms_2Mask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define bits_AQ_PcsTransmitVendorInterruptMask_HHD_reservedPcsTransmitVendorAlarms_2Mask u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure reservedPcsTransmitVendorAlarms_2Mask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define word_AQ_PcsTransmitVendorInterruptMask_HHD_reservedPcsTransmitVendorAlarms_2Mask u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure reservedPcsTransmitVendorAlarms_3Mask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_reservedPcsTransmitVendorAlarms_3Mask 2
/*! \brief Preprocessor variable to relate field to bit position in structure reservedPcsTransmitVendorAlarms_3Mask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define bits_AQ_PcsTransmitVendorInterruptMask_HHD_reservedPcsTransmitVendorAlarms_3Mask u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure reservedPcsTransmitVendorAlarms_3Mask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define word_AQ_PcsTransmitVendorInterruptMask_HHD_reservedPcsTransmitVendorAlarms_3Mask u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TransmitInvalidXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_xfi1TransmitInvalidXgmiiCharacterErrorMask 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TransmitInvalidXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define bits_AQ_PcsTransmitVendorInterruptMask_HHD_xfi1TransmitInvalidXgmiiCharacterErrorMask u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TransmitInvalidXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define word_AQ_PcsTransmitVendorInterruptMask_HHD_xfi1TransmitInvalidXgmiiCharacterErrorMask u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TransmitReservedXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_xfi1TransmitReservedXgmiiCharacterErrorMask 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TransmitReservedXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define bits_AQ_PcsTransmitVendorInterruptMask_HHD_xfi1TransmitReservedXgmiiCharacterErrorMask u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TransmitReservedXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define word_AQ_PcsTransmitVendorInterruptMask_HHD_xfi1TransmitReservedXgmiiCharacterErrorMask u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TransmitEncode_64bErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_xfi1TransmitEncode_64bErrorMask 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TransmitEncode_64bErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define bits_AQ_PcsTransmitVendorInterruptMask_HHD_xfi1TransmitEncode_64bErrorMask u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TransmitEncode_64bErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define word_AQ_PcsTransmitVendorInterruptMask_HHD_xfi1TransmitEncode_64bErrorMask u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TransmitInvalidXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_xfi0TransmitInvalidXgmiiCharacterErrorMask 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TransmitInvalidXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define bits_AQ_PcsTransmitVendorInterruptMask_HHD_xfi0TransmitInvalidXgmiiCharacterErrorMask u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TransmitInvalidXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define word_AQ_PcsTransmitVendorInterruptMask_HHD_xfi0TransmitInvalidXgmiiCharacterErrorMask u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TransmitReservedXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_xfi0TransmitReservedXgmiiCharacterErrorMask 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TransmitReservedXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define bits_AQ_PcsTransmitVendorInterruptMask_HHD_xfi0TransmitReservedXgmiiCharacterErrorMask u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TransmitReservedXgmiiCharacterErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define word_AQ_PcsTransmitVendorInterruptMask_HHD_xfi0TransmitReservedXgmiiCharacterErrorMask u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TransmitEncode_64bErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define AQ_PcsTransmitVendorInterruptMask_HHD_xfi0TransmitEncode_64bErrorMask 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TransmitEncode_64bErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define bits_AQ_PcsTransmitVendorInterruptMask_HHD_xfi0TransmitEncode_64bErrorMask u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TransmitEncode_64bErrorMask in AQ_PcsTransmitVendorInterruptMask_HHD */
#define word_AQ_PcsTransmitVendorInterruptMask_HHD_xfi0TransmitEncode_64bErrorMask u3.word_3

/*! \brief Base register address of structure AQ_PcsTransmitVendorDebug_HHD */
#define AQ_PcsTransmitVendorDebug_HHD_baseRegisterAddress 0xD800
/*! \brief MMD address of structure AQ_PcsTransmitVendorDebug_HHD */
#define AQ_PcsTransmitVendorDebug_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure pcsTxScramblerDisable in AQ_PcsTransmitVendorDebug_HHD */
#define AQ_PcsTransmitVendorDebug_HHD_pcsTxScramblerDisable 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsTxScramblerDisable in AQ_PcsTransmitVendorDebug_HHD */
#define bits_AQ_PcsTransmitVendorDebug_HHD_pcsTxScramblerDisable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsTxScramblerDisable in AQ_PcsTransmitVendorDebug_HHD */
#define word_AQ_PcsTransmitVendorDebug_HHD_pcsTxScramblerDisable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pcsTxInjectCrcError in AQ_PcsTransmitVendorDebug_HHD */
#define AQ_PcsTransmitVendorDebug_HHD_pcsTxInjectCrcError 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsTxInjectCrcError in AQ_PcsTransmitVendorDebug_HHD */
#define bits_AQ_PcsTransmitVendorDebug_HHD_pcsTxInjectCrcError u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsTxInjectCrcError in AQ_PcsTransmitVendorDebug_HHD */
#define word_AQ_PcsTransmitVendorDebug_HHD_pcsTxInjectCrcError u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pcsTxInjectFrameError in AQ_PcsTransmitVendorDebug_HHD */
#define AQ_PcsTransmitVendorDebug_HHD_pcsTxInjectFrameError 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsTxInjectFrameError in AQ_PcsTransmitVendorDebug_HHD */
#define bits_AQ_PcsTransmitVendorDebug_HHD_pcsTxInjectFrameError u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsTxInjectFrameError in AQ_PcsTransmitVendorDebug_HHD */
#define word_AQ_PcsTransmitVendorDebug_HHD_pcsTxInjectFrameError u0.word_0

/*! \brief Base register address of structure AQ_PcsReceiveVendorProvisioning_HHD */
#define AQ_PcsReceiveVendorProvisioning_HHD_baseRegisterAddress 0xE400
/*! \brief MMD address of structure AQ_PcsReceiveVendorProvisioning_HHD */
#define AQ_PcsReceiveVendorProvisioning_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure pcsRxErrorLdpcFrameEnable in AQ_PcsReceiveVendorProvisioning_HHD */
#define AQ_PcsReceiveVendorProvisioning_HHD_pcsRxErrorLdpcFrameEnable 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsRxErrorLdpcFrameEnable in AQ_PcsReceiveVendorProvisioning_HHD */
#define bits_AQ_PcsReceiveVendorProvisioning_HHD_pcsRxErrorLdpcFrameEnable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsRxErrorLdpcFrameEnable in AQ_PcsReceiveVendorProvisioning_HHD */
#define word_AQ_PcsReceiveVendorProvisioning_HHD_pcsRxErrorLdpcFrameEnable u0.word_0

/*! \brief Base register address of structure AQ_PcsReceiveXfi0Provisioning_HHD */
#define AQ_PcsReceiveXfi0Provisioning_HHD_baseRegisterAddress 0xE460
/*! \brief MMD address of structure AQ_PcsReceiveXfi0Provisioning_HHD */
#define AQ_PcsReceiveXfi0Provisioning_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure xfi0RxDescramblerDisable in AQ_PcsReceiveXfi0Provisioning_HHD */
#define AQ_PcsReceiveXfi0Provisioning_HHD_xfi0RxDescramblerDisable 0
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0RxDescramblerDisable in AQ_PcsReceiveXfi0Provisioning_HHD */
#define bits_AQ_PcsReceiveXfi0Provisioning_HHD_xfi0RxDescramblerDisable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xfi0RxDescramblerDisable in AQ_PcsReceiveXfi0Provisioning_HHD */
#define word_AQ_PcsReceiveXfi0Provisioning_HHD_xfi0RxDescramblerDisable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestDataSource in AQ_PcsReceiveXfi0Provisioning_HHD */
#define AQ_PcsReceiveXfi0Provisioning_HHD_xfi0TestDataSource 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestDataSource in AQ_PcsReceiveXfi0Provisioning_HHD */
#define bits_AQ_PcsReceiveXfi0Provisioning_HHD_xfi0TestDataSource u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestDataSource in AQ_PcsReceiveXfi0Provisioning_HHD */
#define word_AQ_PcsReceiveXfi0Provisioning_HHD_xfi0TestDataSource u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestModeSelect in AQ_PcsReceiveXfi0Provisioning_HHD */
#define AQ_PcsReceiveXfi0Provisioning_HHD_xfi0TestModeSelect 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestModeSelect in AQ_PcsReceiveXfi0Provisioning_HHD */
#define bits_AQ_PcsReceiveXfi0Provisioning_HHD_xfi0TestModeSelect u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestModeSelect in AQ_PcsReceiveXfi0Provisioning_HHD */
#define word_AQ_PcsReceiveXfi0Provisioning_HHD_xfi0TestModeSelect u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestPatternEnable in AQ_PcsReceiveXfi0Provisioning_HHD */
#define AQ_PcsReceiveXfi0Provisioning_HHD_xfi0TestPatternEnable 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestPatternEnable in AQ_PcsReceiveXfi0Provisioning_HHD */
#define bits_AQ_PcsReceiveXfi0Provisioning_HHD_xfi0TestPatternEnable u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestPatternEnable in AQ_PcsReceiveXfi0Provisioning_HHD */
#define word_AQ_PcsReceiveXfi0Provisioning_HHD_xfi0TestPatternEnable u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0LocalFaultInject in AQ_PcsReceiveXfi0Provisioning_HHD */
#define AQ_PcsReceiveXfi0Provisioning_HHD_xfi0LocalFaultInject 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0LocalFaultInject in AQ_PcsReceiveXfi0Provisioning_HHD */
#define bits_AQ_PcsReceiveXfi0Provisioning_HHD_xfi0LocalFaultInject u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0LocalFaultInject in AQ_PcsReceiveXfi0Provisioning_HHD */
#define word_AQ_PcsReceiveXfi0Provisioning_HHD_xfi0LocalFaultInject u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveXfi1Provisioning_HHD */
#define AQ_PcsReceiveXfi1Provisioning_HHD_baseRegisterAddress 0xE470
/*! \brief MMD address of structure AQ_PcsReceiveXfi1Provisioning_HHD */
#define AQ_PcsReceiveXfi1Provisioning_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure xfi1RxDescramblerDisable in AQ_PcsReceiveXfi1Provisioning_HHD */
#define AQ_PcsReceiveXfi1Provisioning_HHD_xfi1RxDescramblerDisable 0
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1RxDescramblerDisable in AQ_PcsReceiveXfi1Provisioning_HHD */
#define bits_AQ_PcsReceiveXfi1Provisioning_HHD_xfi1RxDescramblerDisable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xfi1RxDescramblerDisable in AQ_PcsReceiveXfi1Provisioning_HHD */
#define word_AQ_PcsReceiveXfi1Provisioning_HHD_xfi1RxDescramblerDisable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TestDataSource in AQ_PcsReceiveXfi1Provisioning_HHD */
#define AQ_PcsReceiveXfi1Provisioning_HHD_xfi1TestDataSource 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TestDataSource in AQ_PcsReceiveXfi1Provisioning_HHD */
#define bits_AQ_PcsReceiveXfi1Provisioning_HHD_xfi1TestDataSource u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TestDataSource in AQ_PcsReceiveXfi1Provisioning_HHD */
#define word_AQ_PcsReceiveXfi1Provisioning_HHD_xfi1TestDataSource u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestModeSelect in AQ_PcsReceiveXfi1Provisioning_HHD */
#define AQ_PcsReceiveXfi1Provisioning_HHD_xfi0TestModeSelect 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestModeSelect in AQ_PcsReceiveXfi1Provisioning_HHD */
#define bits_AQ_PcsReceiveXfi1Provisioning_HHD_xfi0TestModeSelect u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestModeSelect in AQ_PcsReceiveXfi1Provisioning_HHD */
#define word_AQ_PcsReceiveXfi1Provisioning_HHD_xfi0TestModeSelect u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TestPatternEnable in AQ_PcsReceiveXfi1Provisioning_HHD */
#define AQ_PcsReceiveXfi1Provisioning_HHD_xfi1TestPatternEnable 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TestPatternEnable in AQ_PcsReceiveXfi1Provisioning_HHD */
#define bits_AQ_PcsReceiveXfi1Provisioning_HHD_xfi1TestPatternEnable u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TestPatternEnable in AQ_PcsReceiveXfi1Provisioning_HHD */
#define word_AQ_PcsReceiveXfi1Provisioning_HHD_xfi1TestPatternEnable u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1LocalFaultInject in AQ_PcsReceiveXfi1Provisioning_HHD */
#define AQ_PcsReceiveXfi1Provisioning_HHD_xfi1LocalFaultInject 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1LocalFaultInject in AQ_PcsReceiveXfi1Provisioning_HHD */
#define bits_AQ_PcsReceiveXfi1Provisioning_HHD_xfi1LocalFaultInject u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1LocalFaultInject in AQ_PcsReceiveXfi1Provisioning_HHD */
#define word_AQ_PcsReceiveXfi1Provisioning_HHD_xfi1LocalFaultInject u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveVendorState_HHD */
#define AQ_PcsReceiveVendorState_HHD_baseRegisterAddress 0xE800
/*! \brief MMD address of structure AQ_PcsReceiveVendorState_HHD */
#define AQ_PcsReceiveVendorState_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure pcsRxCurrentValueOfAuxilliaryBit in AQ_PcsReceiveVendorState_HHD */
#define AQ_PcsReceiveVendorState_HHD_pcsRxCurrentValueOfAuxilliaryBit 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsRxCurrentValueOfAuxilliaryBit in AQ_PcsReceiveVendorState_HHD */
#define bits_AQ_PcsReceiveVendorState_HHD_pcsRxCurrentValueOfAuxilliaryBit u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsRxCurrentValueOfAuxilliaryBit in AQ_PcsReceiveVendorState_HHD */
#define word_AQ_PcsReceiveVendorState_HHD_pcsRxCurrentValueOfAuxilliaryBit u0.word_0

/*! \brief Base register address of structure AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD */
#define AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD_baseRegisterAddress 0xE810
/*! \brief MMD address of structure AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD */
#define AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure crc_8ErrorCounterLSW in AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD */
#define AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD_crc_8ErrorCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure crc_8ErrorCounterLSW in AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD */
#define bits_AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD_crc_8ErrorCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure crc_8ErrorCounterLSW in AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD */
#define word_AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD_crc_8ErrorCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure crc_8ErrorCounterMSW in AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD */
#define AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD_crc_8ErrorCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure crc_8ErrorCounterMSW in AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD */
#define bits_AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD_crc_8ErrorCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure crc_8ErrorCounterMSW in AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD */
#define word_AQ_PcsReceiveVendorCrc_8ErrorCounter_HHD_crc_8ErrorCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD */
#define AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD_baseRegisterAddress 0xE812
/*! \brief MMD address of structure AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD */
#define AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tGoodFrameCounterLSW in AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD */
#define AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tGoodFrameCounterLSW in AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD */
#define bits_AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tGoodFrameCounterLSW in AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD */
#define word_AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tGoodFrameCounterMSW in AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD */
#define AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tGoodFrameCounterMSW in AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD */
#define bits_AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tGoodFrameCounterMSW in AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD */
#define word_AQ_PcsReceiveVendorFcsNoErrorFrameCounter_HHD__10gbase_tGoodFrameCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD */
#define AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD_baseRegisterAddress 0xE814
/*! \brief MMD address of structure AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD */
#define AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tErrorFrameCounterLSW in AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD */
#define AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tErrorFrameCounterLSW in AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD */
#define bits_AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tErrorFrameCounterLSW in AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD */
#define word_AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _10gbase_tErrorFrameCounterMSW in AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD */
#define AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure _10gbase_tErrorFrameCounterMSW in AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD */
#define bits_AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure _10gbase_tErrorFrameCounterMSW in AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD */
#define word_AQ_PcsReceiveVendorFcsErrorFrameCounter_HHD__10gbase_tErrorFrameCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD */
#define AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD_baseRegisterAddress 0xE820
/*! \brief MMD address of structure AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD */
#define AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure uncorrectedFrameCounterLSW in AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD */
#define AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD_uncorrectedFrameCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure uncorrectedFrameCounterLSW in AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD */
#define bits_AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD_uncorrectedFrameCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure uncorrectedFrameCounterLSW in AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD */
#define word_AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD_uncorrectedFrameCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure uncorrectedFrameCounterMSW in AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD */
#define AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD_uncorrectedFrameCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure uncorrectedFrameCounterMSW in AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD */
#define bits_AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD_uncorrectedFrameCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure uncorrectedFrameCounterMSW in AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD */
#define word_AQ_PcsReceiveVendorUncorrectedFrameCounter_HHD_uncorrectedFrameCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD_baseRegisterAddress 0xE840
/*! \brief MMD address of structure AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_1IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD_correctedFrames_1IterationCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_1IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD_correctedFrames_1IterationCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_1IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD_correctedFrames_1IterationCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_1IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD_correctedFrames_1IterationCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_1IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD_correctedFrames_1IterationCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_1IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_1IterationCounter_HHD_correctedFrames_1IterationCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD_baseRegisterAddress 0xE842
/*! \brief MMD address of structure AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_2IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD_correctedFrames_2IterationCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_2IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD_correctedFrames_2IterationCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_2IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD_correctedFrames_2IterationCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_2IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD_correctedFrames_2IterationCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_2IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD_correctedFrames_2IterationCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_2IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_2IterationCounter_HHD_correctedFrames_2IterationCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD_baseRegisterAddress 0xE844
/*! \brief MMD address of structure AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_3IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD_correctedFrames_3IterationCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_3IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD_correctedFrames_3IterationCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_3IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD_correctedFrames_3IterationCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_3IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD_correctedFrames_3IterationCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_3IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD_correctedFrames_3IterationCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_3IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_3IterationCounter_HHD_correctedFrames_3IterationCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD_baseRegisterAddress 0xE846
/*! \brief MMD address of structure AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_4IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD_correctedFrames_4IterationCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_4IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD_correctedFrames_4IterationCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_4IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD_correctedFrames_4IterationCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_4IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD_correctedFrames_4IterationCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_4IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD_correctedFrames_4IterationCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_4IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_4IterationCounter_HHD_correctedFrames_4IterationCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD_baseRegisterAddress 0xE848
/*! \brief MMD address of structure AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_5IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD_correctedFrames_5IterationCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_5IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD_correctedFrames_5IterationCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_5IterationCounterLSW in AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD_correctedFrames_5IterationCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_5IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD_correctedFrames_5IterationCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_5IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD_correctedFrames_5IterationCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_5IterationCounterMSW in AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_5IterationCounter_HHD_correctedFrames_5IterationCounterMSW u1.word_1

/*! \brief Base register address of structure AQ_PcsReceiveVendorCorrectedFrame_6IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_6IterationCounter_HHD_baseRegisterAddress 0xE850
/*! \brief MMD address of structure AQ_PcsReceiveVendorCorrectedFrame_6IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_6IterationCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_6IterationCounter in AQ_PcsReceiveVendorCorrectedFrame_6IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_6IterationCounter_HHD_correctedFrames_6IterationCounter 0
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_6IterationCounter in AQ_PcsReceiveVendorCorrectedFrame_6IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_6IterationCounter_HHD_correctedFrames_6IterationCounter u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_6IterationCounter in AQ_PcsReceiveVendorCorrectedFrame_6IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_6IterationCounter_HHD_correctedFrames_6IterationCounter u0.word_0

/*! \brief Base register address of structure AQ_PcsReceiveVendorCorrectedFrame_7IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_7IterationCounter_HHD_baseRegisterAddress 0xE851
/*! \brief MMD address of structure AQ_PcsReceiveVendorCorrectedFrame_7IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_7IterationCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_7IterationCounter in AQ_PcsReceiveVendorCorrectedFrame_7IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_7IterationCounter_HHD_correctedFrames_7IterationCounter 0
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_7IterationCounter in AQ_PcsReceiveVendorCorrectedFrame_7IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_7IterationCounter_HHD_correctedFrames_7IterationCounter u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_7IterationCounter in AQ_PcsReceiveVendorCorrectedFrame_7IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_7IterationCounter_HHD_correctedFrames_7IterationCounter u0.word_0

/*! \brief Base register address of structure AQ_PcsReceiveVendorCorrectedFrame_8IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_8IterationCounter_HHD_baseRegisterAddress 0xE852
/*! \brief MMD address of structure AQ_PcsReceiveVendorCorrectedFrame_8IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_8IterationCounter_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure correctedFrames_8IterationCounter in AQ_PcsReceiveVendorCorrectedFrame_8IterationCounter_HHD */
#define AQ_PcsReceiveVendorCorrectedFrame_8IterationCounter_HHD_correctedFrames_8IterationCounter 0
/*! \brief Preprocessor variable to relate field to bit position in structure correctedFrames_8IterationCounter in AQ_PcsReceiveVendorCorrectedFrame_8IterationCounter_HHD */
#define bits_AQ_PcsReceiveVendorCorrectedFrame_8IterationCounter_HHD_correctedFrames_8IterationCounter u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure correctedFrames_8IterationCounter in AQ_PcsReceiveVendorCorrectedFrame_8IterationCounter_HHD */
#define word_AQ_PcsReceiveVendorCorrectedFrame_8IterationCounter_HHD_correctedFrames_8IterationCounter u0.word_0

/*! \brief Base register address of structure AQ_PcsReceiveXfi0VendorState_HHD */
#define AQ_PcsReceiveXfi0VendorState_HHD_baseRegisterAddress 0xE860
/*! \brief MMD address of structure AQ_PcsReceiveXfi0VendorState_HHD */
#define AQ_PcsReceiveXfi0VendorState_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure xfi0GoodFrameCounterLSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define AQ_PcsReceiveXfi0VendorState_HHD_xfi0GoodFrameCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0GoodFrameCounterLSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define bits_AQ_PcsReceiveXfi0VendorState_HHD_xfi0GoodFrameCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xfi0GoodFrameCounterLSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define word_AQ_PcsReceiveXfi0VendorState_HHD_xfi0GoodFrameCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfi0GoodFrameCounterMSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define AQ_PcsReceiveXfi0VendorState_HHD_xfi0GoodFrameCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0GoodFrameCounterMSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define bits_AQ_PcsReceiveXfi0VendorState_HHD_xfi0GoodFrameCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi0GoodFrameCounterMSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define word_AQ_PcsReceiveXfi0VendorState_HHD_xfi0GoodFrameCounterMSW u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi0BadFrameCounterLSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define AQ_PcsReceiveXfi0VendorState_HHD_xfi0BadFrameCounterLSW 2
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0BadFrameCounterLSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define bits_AQ_PcsReceiveXfi0VendorState_HHD_xfi0BadFrameCounterLSW u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure xfi0BadFrameCounterLSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define word_AQ_PcsReceiveXfi0VendorState_HHD_xfi0BadFrameCounterLSW u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure xfi0BadFrameCounterMSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define AQ_PcsReceiveXfi0VendorState_HHD_xfi0BadFrameCounterMSW 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0BadFrameCounterMSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define bits_AQ_PcsReceiveXfi0VendorState_HHD_xfi0BadFrameCounterMSW u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi0BadFrameCounterMSW in AQ_PcsReceiveXfi0VendorState_HHD */
#define word_AQ_PcsReceiveXfi0VendorState_HHD_xfi0BadFrameCounterMSW u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi0BerCounter in AQ_PcsReceiveXfi0VendorState_HHD */
#define AQ_PcsReceiveXfi0VendorState_HHD_xfi0BerCounter 4
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0BerCounter in AQ_PcsReceiveXfi0VendorState_HHD */
#define bits_AQ_PcsReceiveXfi0VendorState_HHD_xfi0BerCounter u4.bits_4
/*! \brief Preprocessor variable to relate field to word position in structure xfi0BerCounter in AQ_PcsReceiveXfi0VendorState_HHD */
#define word_AQ_PcsReceiveXfi0VendorState_HHD_xfi0BerCounter u4.word_4
/*! \brief Preprocessor variable to relate field to word number in structure xfi0ErroredBlockCounter in AQ_PcsReceiveXfi0VendorState_HHD */
#define AQ_PcsReceiveXfi0VendorState_HHD_xfi0ErroredBlockCounter 5
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0ErroredBlockCounter in AQ_PcsReceiveXfi0VendorState_HHD */
#define bits_AQ_PcsReceiveXfi0VendorState_HHD_xfi0ErroredBlockCounter u5.bits_5
/*! \brief Preprocessor variable to relate field to word position in structure xfi0ErroredBlockCounter in AQ_PcsReceiveXfi0VendorState_HHD */
#define word_AQ_PcsReceiveXfi0VendorState_HHD_xfi0ErroredBlockCounter u5.word_5
/*! \brief Preprocessor variable to relate field to word number in structure xfi0TestPatternErrorCounter in AQ_PcsReceiveXfi0VendorState_HHD */
#define AQ_PcsReceiveXfi0VendorState_HHD_xfi0TestPatternErrorCounter 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0TestPatternErrorCounter in AQ_PcsReceiveXfi0VendorState_HHD */
#define bits_AQ_PcsReceiveXfi0VendorState_HHD_xfi0TestPatternErrorCounter u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi0TestPatternErrorCounter in AQ_PcsReceiveXfi0VendorState_HHD */
#define word_AQ_PcsReceiveXfi0VendorState_HHD_xfi0TestPatternErrorCounter u6.word_6

/*! \brief Base register address of structure AQ_PcsReceiveXfi1VendorState_HHD */
#define AQ_PcsReceiveXfi1VendorState_HHD_baseRegisterAddress 0xE870
/*! \brief MMD address of structure AQ_PcsReceiveXfi1VendorState_HHD */
#define AQ_PcsReceiveXfi1VendorState_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure xfi1GoodFrameCounterLSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define AQ_PcsReceiveXfi1VendorState_HHD_xfi1GoodFrameCounterLSW 0
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1GoodFrameCounterLSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define bits_AQ_PcsReceiveXfi1VendorState_HHD_xfi1GoodFrameCounterLSW u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure xfi1GoodFrameCounterLSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define word_AQ_PcsReceiveXfi1VendorState_HHD_xfi1GoodFrameCounterLSW u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfi1GoodFrameCounterMSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define AQ_PcsReceiveXfi1VendorState_HHD_xfi1GoodFrameCounterMSW 1
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1GoodFrameCounterMSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define bits_AQ_PcsReceiveXfi1VendorState_HHD_xfi1GoodFrameCounterMSW u1.bits_1
/*! \brief Preprocessor variable to relate field to word position in structure xfi1GoodFrameCounterMSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define word_AQ_PcsReceiveXfi1VendorState_HHD_xfi1GoodFrameCounterMSW u1.word_1
/*! \brief Preprocessor variable to relate field to word number in structure xfi1BadFrameCounterLSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define AQ_PcsReceiveXfi1VendorState_HHD_xfi1BadFrameCounterLSW 2
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1BadFrameCounterLSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define bits_AQ_PcsReceiveXfi1VendorState_HHD_xfi1BadFrameCounterLSW u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure xfi1BadFrameCounterLSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define word_AQ_PcsReceiveXfi1VendorState_HHD_xfi1BadFrameCounterLSW u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure xfi1BadFrameCounterMSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define AQ_PcsReceiveXfi1VendorState_HHD_xfi1BadFrameCounterMSW 3
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1BadFrameCounterMSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define bits_AQ_PcsReceiveXfi1VendorState_HHD_xfi1BadFrameCounterMSW u3.bits_3
/*! \brief Preprocessor variable to relate field to word position in structure xfi1BadFrameCounterMSW in AQ_PcsReceiveXfi1VendorState_HHD */
#define word_AQ_PcsReceiveXfi1VendorState_HHD_xfi1BadFrameCounterMSW u3.word_3
/*! \brief Preprocessor variable to relate field to word number in structure xfi1BerCounter in AQ_PcsReceiveXfi1VendorState_HHD */
#define AQ_PcsReceiveXfi1VendorState_HHD_xfi1BerCounter 4
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1BerCounter in AQ_PcsReceiveXfi1VendorState_HHD */
#define bits_AQ_PcsReceiveXfi1VendorState_HHD_xfi1BerCounter u4.bits_4
/*! \brief Preprocessor variable to relate field to word position in structure xfi1BerCounter in AQ_PcsReceiveXfi1VendorState_HHD */
#define word_AQ_PcsReceiveXfi1VendorState_HHD_xfi1BerCounter u4.word_4
/*! \brief Preprocessor variable to relate field to word number in structure xfi1ErroredBlockCounter in AQ_PcsReceiveXfi1VendorState_HHD */
#define AQ_PcsReceiveXfi1VendorState_HHD_xfi1ErroredBlockCounter 5
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1ErroredBlockCounter in AQ_PcsReceiveXfi1VendorState_HHD */
#define bits_AQ_PcsReceiveXfi1VendorState_HHD_xfi1ErroredBlockCounter u5.bits_5
/*! \brief Preprocessor variable to relate field to word position in structure xfi1ErroredBlockCounter in AQ_PcsReceiveXfi1VendorState_HHD */
#define word_AQ_PcsReceiveXfi1VendorState_HHD_xfi1ErroredBlockCounter u5.word_5
/*! \brief Preprocessor variable to relate field to word number in structure xfi1TestPatternErrorCounter in AQ_PcsReceiveXfi1VendorState_HHD */
#define AQ_PcsReceiveXfi1VendorState_HHD_xfi1TestPatternErrorCounter 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1TestPatternErrorCounter in AQ_PcsReceiveXfi1VendorState_HHD */
#define bits_AQ_PcsReceiveXfi1VendorState_HHD_xfi1TestPatternErrorCounter u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi1TestPatternErrorCounter in AQ_PcsReceiveXfi1VendorState_HHD */
#define word_AQ_PcsReceiveXfi1VendorState_HHD_xfi1TestPatternErrorCounter u6.word_6

/*! \brief Base register address of structure AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_baseRegisterAddress 0xEC00
/*! \brief MMD address of structure AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure crcError in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_crcError 0
/*! \brief Preprocessor variable to relate field to bit position in structure crcError in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_crcError u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure crcError in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_crcError u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure ldpcDecodeFailure in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_ldpcDecodeFailure 0
/*! \brief Preprocessor variable to relate field to bit position in structure ldpcDecodeFailure in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_ldpcDecodeFailure u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure ldpcDecodeFailure in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_ldpcDecodeFailure u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure localFaultDetect in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_localFaultDetect 0
/*! \brief Preprocessor variable to relate field to bit position in structure localFaultDetect in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_localFaultDetect u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure localFaultDetect in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_localFaultDetect u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure lofDetect in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_lofDetect 0
/*! \brief Preprocessor variable to relate field to bit position in structure lofDetect in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_lofDetect u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure lofDetect in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_lofDetect u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _40gBipLock in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD__40gBipLock 0
/*! \brief Preprocessor variable to relate field to bit position in structure _40gBipLock in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD__40gBipLock u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _40gBipLock in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD__40gBipLock u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure invalid_65bBlock in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_invalid_65bBlock 0
/*! \brief Preprocessor variable to relate field to bit position in structure invalid_65bBlock in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_invalid_65bBlock u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure invalid_65bBlock in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_invalid_65bBlock u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure eeeRxLpiActiveOff in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiActiveOff 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeRxLpiActiveOff in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiActiveOff u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeRxLpiActiveOff in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiActiveOff u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure eeeRxLpiActiveOn in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiActiveOn 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeRxLpiActiveOn in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiActiveOn u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeRxLpiActiveOn in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiActiveOn u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure ldpcConsecutiveErroredFrameExceeded in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_ldpcConsecutiveErroredFrameExceeded 0
/*! \brief Preprocessor variable to relate field to bit position in structure ldpcConsecutiveErroredFrameExceeded in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_ldpcConsecutiveErroredFrameExceeded u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure ldpcConsecutiveErroredFrameExceeded in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_ldpcConsecutiveErroredFrameExceeded u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure eeeRxLpiAlert in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiAlert 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeRxLpiAlert in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiAlert u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeRxLpiAlert in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiAlert u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure eeeRxLpiReceivedLatchedLow in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiReceivedLatchedLow 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeRxLpiReceivedLatchedLow in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiReceivedLatchedLow u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeRxLpiReceivedLatchedLow in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiReceivedLatchedLow u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure eeeRxLpiReceivedLatchedHigh in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiReceivedLatchedHigh 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeRxLpiReceivedLatchedHigh in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiReceivedLatchedHigh u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeRxLpiReceivedLatchedHigh in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_eeeRxLpiReceivedLatchedHigh u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure changeInAuxilliaryBit in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_changeInAuxilliaryBit 0
/*! \brief Preprocessor variable to relate field to bit position in structure changeInAuxilliaryBit in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_changeInAuxilliaryBit u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure changeInAuxilliaryBit in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_changeInAuxilliaryBit u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfi1Invalid_66bCharacterReceived in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_xfi1Invalid_66bCharacterReceived 5
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1Invalid_66bCharacterReceived in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_xfi1Invalid_66bCharacterReceived u5.bits_5
/*! \brief Preprocessor variable to relate field to word position in structure xfi1Invalid_66bCharacterReceived in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_xfi1Invalid_66bCharacterReceived u5.word_5
/*! \brief Preprocessor variable to relate field to word number in structure xfi0Invalid_66bCharacterReceived in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_xfi0Invalid_66bCharacterReceived 5
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0Invalid_66bCharacterReceived in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_xfi0Invalid_66bCharacterReceived u5.bits_5
/*! \brief Preprocessor variable to relate field to word position in structure xfi0Invalid_66bCharacterReceived in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_xfi0Invalid_66bCharacterReceived u5.word_5
/*! \brief Preprocessor variable to relate field to word number in structure xfi1ReceiveLinkStatusLatchHigh in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_xfi1ReceiveLinkStatusLatchHigh 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1ReceiveLinkStatusLatchHigh in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_xfi1ReceiveLinkStatusLatchHigh u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi1ReceiveLinkStatusLatchHigh in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_xfi1ReceiveLinkStatusLatchHigh u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfi1HighBerStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_xfi1HighBerStatus 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1HighBerStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_xfi1HighBerStatus u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi1HighBerStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_xfi1HighBerStatus u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfi1BlockLockStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_xfi1BlockLockStatus 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1BlockLockStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_xfi1BlockLockStatus u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi1BlockLockStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_xfi1BlockLockStatus u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfi0ReceiveLinkStatusLatchHigh in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_xfi0ReceiveLinkStatusLatchHigh 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0ReceiveLinkStatusLatchHigh in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_xfi0ReceiveLinkStatusLatchHigh u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi0ReceiveLinkStatusLatchHigh in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_xfi0ReceiveLinkStatusLatchHigh u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfi0HighBerStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_xfi0HighBerStatus 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0HighBerStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_xfi0HighBerStatus u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi0HighBerStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_xfi0HighBerStatus u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfi0BlockLockStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define AQ_PcsReceiveVendorAlarms_HHD_xfi0BlockLockStatus 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0BlockLockStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define bits_AQ_PcsReceiveVendorAlarms_HHD_xfi0BlockLockStatus u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi0BlockLockStatus in AQ_PcsReceiveVendorAlarms_HHD */
#define word_AQ_PcsReceiveVendorAlarms_HHD_xfi0BlockLockStatus u6.word_6

/*! \brief Base register address of structure AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_baseRegisterAddress 0xF400
/*! \brief MMD address of structure AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure crcErrorMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_crcErrorMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure crcErrorMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_crcErrorMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure crcErrorMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_crcErrorMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure ldpcDecodeFailureMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_ldpcDecodeFailureMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure ldpcDecodeFailureMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_ldpcDecodeFailureMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure ldpcDecodeFailureMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_ldpcDecodeFailureMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure localFaultDetectMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_localFaultDetectMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure localFaultDetectMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_localFaultDetectMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure localFaultDetectMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_localFaultDetectMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure lofDetectMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_lofDetectMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure lofDetectMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_lofDetectMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure lofDetectMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_lofDetectMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure _40gBipLockMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD__40gBipLockMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure _40gBipLockMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD__40gBipLockMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure _40gBipLockMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD__40gBipLockMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure invalid_65bBlockMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_invalid_65bBlockMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure invalid_65bBlockMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_invalid_65bBlockMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure invalid_65bBlockMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_invalid_65bBlockMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure eeeRxLpiActiveOffMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiActiveOffMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeRxLpiActiveOffMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiActiveOffMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeRxLpiActiveOffMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiActiveOffMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure eeeRxLpiActiveOnMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiActiveOnMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeRxLpiActiveOnMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiActiveOnMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeRxLpiActiveOnMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiActiveOnMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure ldpcConsecutiveErroredFrameExceededMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_ldpcConsecutiveErroredFrameExceededMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure ldpcConsecutiveErroredFrameExceededMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_ldpcConsecutiveErroredFrameExceededMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure ldpcConsecutiveErroredFrameExceededMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_ldpcConsecutiveErroredFrameExceededMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure eeeRxLpiAlertMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiAlertMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeRxLpiAlertMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiAlertMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeRxLpiAlertMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiAlertMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure eeeRxLpiReceivedLatchedLowMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiReceivedLatchedLowMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeRxLpiReceivedLatchedLowMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiReceivedLatchedLowMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeRxLpiReceivedLatchedLowMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiReceivedLatchedLowMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure eeeRxLpiReceivedLatchedHighMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiReceivedLatchedHighMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure eeeRxLpiReceivedLatchedHighMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiReceivedLatchedHighMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure eeeRxLpiReceivedLatchedHighMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_eeeRxLpiReceivedLatchedHighMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure changeInAuxilliaryBitMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_changeInAuxilliaryBitMask 0
/*! \brief Preprocessor variable to relate field to bit position in structure changeInAuxilliaryBitMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_changeInAuxilliaryBitMask u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure changeInAuxilliaryBitMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_changeInAuxilliaryBitMask u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure xfi1Invalid_66bCharacterReceivedMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_xfi1Invalid_66bCharacterReceivedMask 5
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1Invalid_66bCharacterReceivedMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_xfi1Invalid_66bCharacterReceivedMask u5.bits_5
/*! \brief Preprocessor variable to relate field to word position in structure xfi1Invalid_66bCharacterReceivedMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_xfi1Invalid_66bCharacterReceivedMask u5.word_5
/*! \brief Preprocessor variable to relate field to word number in structure xfi0Invalid_66bCharacterReceivedMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_xfi0Invalid_66bCharacterReceivedMask 5
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0Invalid_66bCharacterReceivedMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_xfi0Invalid_66bCharacterReceivedMask u5.bits_5
/*! \brief Preprocessor variable to relate field to word position in structure xfi0Invalid_66bCharacterReceivedMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_xfi0Invalid_66bCharacterReceivedMask u5.word_5
/*! \brief Preprocessor variable to relate field to word number in structure xfi1ReceiveLinkStatusLatchHighMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_xfi1ReceiveLinkStatusLatchHighMask 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1ReceiveLinkStatusLatchHighMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_xfi1ReceiveLinkStatusLatchHighMask u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi1ReceiveLinkStatusLatchHighMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_xfi1ReceiveLinkStatusLatchHighMask u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfi1HighBerStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_xfi1HighBerStatusMask 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1HighBerStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_xfi1HighBerStatusMask u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi1HighBerStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_xfi1HighBerStatusMask u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfi1BlockLockStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_xfi1BlockLockStatusMask 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi1BlockLockStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_xfi1BlockLockStatusMask u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi1BlockLockStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_xfi1BlockLockStatusMask u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfi0ReceiveLinkStatusLatchHighMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_xfi0ReceiveLinkStatusLatchHighMask 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0ReceiveLinkStatusLatchHighMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_xfi0ReceiveLinkStatusLatchHighMask u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi0ReceiveLinkStatusLatchHighMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_xfi0ReceiveLinkStatusLatchHighMask u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfi0HighBerStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_xfi0HighBerStatusMask 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0HighBerStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_xfi0HighBerStatusMask u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi0HighBerStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_xfi0HighBerStatusMask u6.word_6
/*! \brief Preprocessor variable to relate field to word number in structure xfi0BlockLockStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define AQ_PcsReceiveVendorInterruptMask_HHD_xfi0BlockLockStatusMask 6
/*! \brief Preprocessor variable to relate field to bit position in structure xfi0BlockLockStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define bits_AQ_PcsReceiveVendorInterruptMask_HHD_xfi0BlockLockStatusMask u6.bits_6
/*! \brief Preprocessor variable to relate field to word position in structure xfi0BlockLockStatusMask in AQ_PcsReceiveVendorInterruptMask_HHD */
#define word_AQ_PcsReceiveVendorInterruptMask_HHD_xfi0BlockLockStatusMask u6.word_6

/*! \brief Base register address of structure AQ_PcsReceiveVendorDebug_HHD */
#define AQ_PcsReceiveVendorDebug_HHD_baseRegisterAddress 0xF800
/*! \brief MMD address of structure AQ_PcsReceiveVendorDebug_HHD */
#define AQ_PcsReceiveVendorDebug_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure pcsRxDescramblerDisable in AQ_PcsReceiveVendorDebug_HHD */
#define AQ_PcsReceiveVendorDebug_HHD_pcsRxDescramblerDisable 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsRxDescramblerDisable in AQ_PcsReceiveVendorDebug_HHD */
#define bits_AQ_PcsReceiveVendorDebug_HHD_pcsRxDescramblerDisable u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsRxDescramblerDisable in AQ_PcsReceiveVendorDebug_HHD */
#define word_AQ_PcsReceiveVendorDebug_HHD_pcsRxDescramblerDisable u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pcsNetworkLoopbackMerge in AQ_PcsReceiveVendorDebug_HHD */
#define AQ_PcsReceiveVendorDebug_HHD_pcsNetworkLoopbackMerge 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsNetworkLoopbackMerge in AQ_PcsReceiveVendorDebug_HHD */
#define bits_AQ_PcsReceiveVendorDebug_HHD_pcsNetworkLoopbackMerge u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsNetworkLoopbackMerge in AQ_PcsReceiveVendorDebug_HHD */
#define word_AQ_PcsReceiveVendorDebug_HHD_pcsNetworkLoopbackMerge u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pcsNetworkLoopbackPassThrough in AQ_PcsReceiveVendorDebug_HHD */
#define AQ_PcsReceiveVendorDebug_HHD_pcsNetworkLoopbackPassThrough 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsNetworkLoopbackPassThrough in AQ_PcsReceiveVendorDebug_HHD */
#define bits_AQ_PcsReceiveVendorDebug_HHD_pcsNetworkLoopbackPassThrough u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsNetworkLoopbackPassThrough in AQ_PcsReceiveVendorDebug_HHD */
#define word_AQ_PcsReceiveVendorDebug_HHD_pcsNetworkLoopbackPassThrough u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure pcsNetworkLoopback in AQ_PcsReceiveVendorDebug_HHD */
#define AQ_PcsReceiveVendorDebug_HHD_pcsNetworkLoopback 0
/*! \brief Preprocessor variable to relate field to bit position in structure pcsNetworkLoopback in AQ_PcsReceiveVendorDebug_HHD */
#define bits_AQ_PcsReceiveVendorDebug_HHD_pcsNetworkLoopback u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure pcsNetworkLoopback in AQ_PcsReceiveVendorDebug_HHD */
#define word_AQ_PcsReceiveVendorDebug_HHD_pcsNetworkLoopback u0.word_0

/*! \brief Base register address of structure AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_baseRegisterAddress 0xFC00
/*! \brief MMD address of structure AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_mmdAddress 0x03
/*! \brief Preprocessor variable to relate field to word number in structure standardAlarm_1Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_standardAlarm_1Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure standardAlarm_1Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_standardAlarm_1Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure standardAlarm_1Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_standardAlarm_1Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure standardAlarm_2Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_standardAlarm_2Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure standardAlarm_2Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_standardAlarm_2Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure standardAlarm_2Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_standardAlarm_2Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure standardAlarm_3Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_standardAlarm_3Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure standardAlarm_3Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_standardAlarm_3Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure standardAlarm_3Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_standardAlarm_3Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificTxAlarms_1Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificTxAlarms_1Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificTxAlarms_1Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificTxAlarms_1Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificTxAlarms_1Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificTxAlarms_1Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificTxAlarms_2Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificTxAlarms_2Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificTxAlarms_2Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificTxAlarms_2Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificTxAlarms_2Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificTxAlarms_2Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificTxAlarms_3Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificTxAlarms_3Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificTxAlarms_3Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificTxAlarms_3Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificTxAlarms_3Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificTxAlarms_3Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificRxAlarms_1Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_1Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificRxAlarms_1Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_1Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificRxAlarms_1Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_1Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificRxAlarms_2Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_2Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificRxAlarms_2Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_2Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificRxAlarms_2Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_2Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificRxAlarms_3Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_3Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificRxAlarms_3Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_3Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificRxAlarms_3Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_3Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificRxAlarms_4Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_4Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificRxAlarms_4Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_4Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificRxAlarms_4Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_4Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificRxAlarms_5Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_5Interrupt 0
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificRxAlarms_5Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_5Interrupt u0.bits_0
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificRxAlarms_5Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_5Interrupt u0.word_0
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificRxAlarms_6Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_6Interrupt 2
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificRxAlarms_6Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_6Interrupt u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificRxAlarms_6Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_6Interrupt u2.word_2
/*! \brief Preprocessor variable to relate field to word number in structure vendorSpecificRxAlarms_7Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_7Interrupt 2
/*! \brief Preprocessor variable to relate field to bit position in structure vendorSpecificRxAlarms_7Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define bits_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_7Interrupt u2.bits_2
/*! \brief Preprocessor variable to relate field to word position in structure vendorSpecificRxAlarms_7Interrupt in AQ_PcsVendorGlobalInterruptFlags_HHD */
#define word_AQ_PcsVendorGlobalInterruptFlags_HHD_vendorSpecificRxAlarms_7Interrupt u2.word_2
#endif
/*@}*/
/*@}*/
