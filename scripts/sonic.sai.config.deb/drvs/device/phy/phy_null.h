#ifndef __PHY_NULL_DRV__
#define __PHY_NULL_DRV__

#include "phy_drv.h"

phy_handle_t* phy_null_dev_register(phy_info_t* pphy_info);

#endif /* !__PHY_NULL_DRV__ */
