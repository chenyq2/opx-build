/****************************************************************************
* $Id$
* phy Null device driver
* 
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : jqiu 
* Date          : 2013-03-18
* Reason        : First Create.
* Revision      : R0.02
* Author        : jqiu 
* Date          : 2016-07-08
* Reason        : Support Clause73 Auto-neg for 40/100G. see bug39456.
****************************************************************************/
#include "sal_common.h"
#include "drv_debug.h"
#include "glb_phy_define.h"
#include "glb_hw_define.h"
#include "phy_null.h"
#include "ctc_api.h"
#include "ctc_port.h"
#include "epld_api.h"
#include "fiber_api.h"

/*SDK requirement:
  1. be sure mac enable;
  2. cfg auto;
  3. roll back mac config;
*/
int32 ctc_phy_port_set_auto_reg(phy_info_t *pphy_info, uint8 enable)
{
    int32 ret;

    if(pphy_info->phy_manage_info.enable)
    {
        ret = ctc_port_set_auto_neg(pphy_info->port_info.port_id, enable);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d  ret %d", 
                 __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }
    }
    else
    {
        ret = ctc_port_set_mac_en(pphy_info->port_info.port_id, 1);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d  ret %d", 
                 __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }
        ret = ctc_port_set_auto_neg(pphy_info->port_info.port_id, enable);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d  ret %d", 
                 __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }
        ret = ctc_port_set_mac_en(pphy_info->port_info.port_id, 0);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d  ret %d", 
                 __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }
    }
    return ret;
}

int32 ctc_phy_port_restart_auto(phy_info_t *pphy_info)
{
    int32 ret=0;

    /* bug44010, When serdes loopback enable, skip do cl73 auto, qicx, 2017-05-15 */
    if (pphy_info->serdes_lb_en)
    {
        return RESULT_OK;
    }

    if((pphy_info->phy_manage_info.enable) && (pphy_info->phy_manage_info.cl73_enable))
    {
        ret = ctc_port_set_auto_neg(pphy_info->port_info.port_id, 0);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d  ret %d", 
                 __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }
        if(pphy_info->phy_manage_info.cl73_ability != 0)
        {
            ret = ctc_port_set_auto_neg(pphy_info->port_info.port_id, 1);
            if(ret != CTC_E_NONE)
            {
                DRV_LOG_ERR("%s %d gport %d  ret %d", 
                     __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
            }
        }
    }
    return ret;
}

/* Added by qicx for bug44301, rollback auto except 10G status, 2017-06-09 */
int32 ctc_phy_port_rollback_auto(phy_info_t *pphy_info)
{
    int32 ret = 0;
    ctc_port_speed_t ctc_speed;

    glb_port_speed_t speed, fiber_ability;
    glb_port_duplex_t duplex;

    speed = pphy_info->phy_manage_info.speed;
    duplex = pphy_info->phy_manage_info.duplex;
    fiber_ability = pphy_info->phy_manage_info.fiber_ability;

    /* Auto mode */
    if ((GLB_SPEED_AUTO == speed) || (GLB_DUPLEX_AUTO == duplex))
    {
        ret = ctc_port_get_speed(pphy_info->port_info.port_id, &ctc_speed);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d get speed ret %d",
                __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }
        /* If pcs speed mode is 10G, cannot enable AN */
        if(CTC_PORT_SPEED_10G != ctc_speed)
        {
            ret += ctc_phy_port_set_auto_reg(pphy_info, 1);
        }
    }

    return ret;
}

/*Old SDK requirement:
  1. clear old ability, set to 0;
  2. cfg real ability;
*/
int32 ctc_phy_port_update_cl73_ability(phy_info_t *pphy_info)
{
    int32 ret;
    uint32 ability;
    
    ability = pphy_info->phy_manage_info.cl73_ability;    
    if((ability & (CTC_PORT_CL73_100GBASE_CR4|CTC_PORT_CL73_100GBASE_KR4)) != 0)
    {
        ability |= CTC_PORT_CL73_FEC_ABILITY;
    }
    if(pphy_info->phy_manage_info.fec_en)
    {
        ability |= CTC_PORT_CL73_FEC_REQUESTED;
    }
    ret = ctc_port_set_property(pphy_info->port_info.port_id, CTC_PORT_PROP_CL73_ABILITY, ability);
    if(ret != CTC_E_NONE)
    {
        DRV_LOG_ERR("%s %d gport %d  ret %d", 
             __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
    }
    return ret;
}

/*SDK requirement:
  1. mac disable;
  2. change speed;
  3. mac roll back;
*/
int32 ctc_phy_port_set_speed(phy_info_t *pphy_info, ctc_port_speed_t speed_mode)
{
    int32 ret=0;
    /*Before change speed, must disable mac first.*/
    if(pphy_info->phy_manage_info.enable)
    {
        ret = ctc_port_set_mac_en(pphy_info->port_info.port_id, 0);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d  ret %d",
                __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }
    }
#ifdef GREATBELT
    ctc_chip_serdes_info_t serdes_info;
    if(speed_mode == CTC_PORT_SPEED_1G)
        serdes_info.serdes_mode = CTC_CHIP_SERDES_XSGMII_MODE;
    else if(speed_mode == CTC_PORT_SPEED_10G)
        serdes_info.serdes_mode = CTC_CHIP_SERDES_XFI_MODE;
    serdes_info.serdes_id = pphy_info->port_info.serdes_id;
    ret=ctc_chip_set_serdes_mode(pphy_info->port_info.lchip, &serdes_info);
    pphy_info->serdes_mode = serdes_info.serdes_mode;
#else
    ret += ctc_port_set_speed(pphy_info->port_info.port_id, speed_mode);
#endif
    if(ret != CTC_E_NONE)
    {                        
        DRV_LOG_ERR("%s %d gport %d  ret %d",
            __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
    }
    /*After change speed, mac roll back config.*/
    if(pphy_info->phy_manage_info.enable)
    {
        ret += ctc_port_set_mac_en(pphy_info->port_info.port_id, 1);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d  ret %d",
                __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }
    }
    return ret;
}

int32 ctc_phy_port_set_fec_en(phy_info_t *pphy_info, uint8 fec_en)
{
    int32 ret = 0;
    
    if(pphy_info->phy_manage_info.enable)
    {
        ctc_port_set_mac_en(pphy_info->port_info.port_id, 0);
    }
    ret = ctc_port_set_property(pphy_info->port_info.port_id, CTC_PORT_PROP_FEC_EN, fec_en ? 1 : 0);
    if(ret != CTC_E_NONE)
    {
        DRV_LOG_ERR("%s %d gport %d  ret %d", 
             __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
    }
    if(pphy_info->phy_manage_info.enable)
    {
        /*Bug39827 After config FEC, roll back mac config.*/
        ret = ctc_port_set_mac_en(pphy_info->port_info.port_id, 1);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d  ret %d", 
                 __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }
    }    
    return ret;
}

int32 ctc_phy_port_do_cl73_auto(phy_info_t *pphy_info)
{
    int is_up;
    uint16 gport;
    int32 ret = RESULT_OK;
    uint32 auto_en;

   gport = pphy_info->port_info.port_id;

    if(pphy_info->phy_manage_info.enable)
    {
        if(pphy_info->phy_manage_info.cl73_enable)
        {   
            if(pphy_info->phy_manage_info.cl73_ability != 0)
            {
                ret = ctc_port_get_mac_link_up(gport, &is_up);
                if(ret != CTC_E_NONE)
                {
                    DRV_LOG_ERR("%s %d gport %d  ret %d", 
                         __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
                }
                if(!is_up)
                {
                    ret = ctc_port_get_property(pphy_info->port_info.port_id, CTC_PORT_PROP_AUTO_NEG_EN, &auto_en);
                    /*From auto to training, need wait more.*/
                    if((auto_en == 2)&&(pphy_info->phy_stat_flag.cl73_status == 1))
                    {
                        pphy_info->phy_stat_flag.cl73_status = auto_en;
                    }
                    else
                    //if((auto_en == 0) || (auto_en == 1) || ((auto_en == 2)&&(pphy_info->phy_stat_flag.cl73_status == 2))||(auto_en == 3))
                    //if((auto_en == 0) || ((auto_en == 2)&&(pphy_info->phy_stat_flag.cl73_status == 2)))
                    {
                        /*restart auto-negotiation*/
                        ctc_phy_port_restart_auto(pphy_info);
                        pphy_info->phy_stat_flag.cl73_status = 1;
                        DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null addr %d trigger auto. ability 0x%x auto %d",
                            pphy_info->port_info.port_id, pphy_info->phy_manage_info.cl73_ability, auto_en) 
                    }
                }
                else
                {
                    pphy_info->phy_stat_flag.cl73_status = 3;
                }
            }
        }
    }
    return ret;    
}
int32 phy_null_enable(phy_handle_t* phy_handle, int8 enable)
{
    int32 ret=0;
    phy_info_t *pphy_info;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    pphy_info = &phy_handle->phy_info;
    ret = ctc_port_set_mac_en(pphy_info->port_info.port_id, enable);
    if(enable)
    {
        ctc_phy_port_restart_auto(pphy_info);
    }
    return ret;
}

/***********************************************************
  1. FEC config won't be lost when speed change between 100G and 40G.
  2. After config FEC, if port enable CL73, need update ability and restart auto.
  3. FEC config must do when mac disable.
************************************************************/
int32 phy_null_config_fec_en(phy_handle_t* phy_handle, uint8 fec_en)
{
    int32 ret = 0;
    phy_info_t *pphy_info = NULL;
        
    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    
    pphy_info = &phy_handle->phy_info;
    ctc_phy_port_set_fec_en(pphy_info, fec_en);
    /*need restart auto if enable auto*/
    ctc_phy_port_update_cl73_ability(pphy_info);
    ctc_phy_port_restart_auto(pphy_info);

    return ret;    
}

int32 
phy_null_config_unidir(phy_handle_t* phy_handle, uint8 enable)
{
    int ret;
    uint16 gport;
    phy_info_t *pphy_info;

    pphy_info = &phy_handle->phy_info;
    gport = pphy_info->port_info.port_id;   

    /* Added by liuht for bug 37450, 2016-03-11 */
    /* If unidir function is enabled, then disable port interrupt */
    if(GLB_PORT_UNIDIR_DISABLE == enable)
    {
        ret = ctc_port_set_property(gport,CTC_PORT_PROP_LINK_INTRRUPT_EN,TRUE);
        ret += ctc_port_set_property(gport, CTC_PORT_PROP_UNIDIR_EN, 0);
    }
    else
    {
        ret = ctc_port_set_property(gport,CTC_PORT_PROP_LINK_INTRRUPT_EN,FALSE);
        ret += ctc_port_set_property(gport, CTC_PORT_PROP_UNIDIR_EN, 1);
    }

    /* Modified by liuht for bug42776, 2017-02-17 */
    /* when mac is enabled, if unidirectional rx-only is set,
     * then disable mac tx */
    if((GLB_PORT_UNIDIR_RX_ONLY == enable))
    {
        ctc_port_set_property(gport,CTC_PORT_PROP_NET_TX, FALSE);
    }
    else
    {
        /* Modified by liuht for bug 44007, 2017-05-12*/
        /* E350 don't support this property, so now just ignor return with error */
        ctc_port_set_property(gport,CTC_PORT_PROP_NET_TX, TRUE);
    }
    
    return ret;
}

static int32 phy_null_conf_set(phy_handle_t* phy_handle, glb_port_speed_t speed, glb_port_duplex_t duplex)
{
    int32 ret = 0;
    ctc_port_speed_t ctc_speed;
    phy_info_t *pphy_info;
    
    pphy_info = &phy_handle->phy_info;
    
    /*Auto mode*/
    if((speed == GLB_SPEED_AUTO)||(duplex == GLB_DUPLEX_AUTO))
    {
        /*Get real speed.*/
        ret = ctc_port_get_speed(pphy_info->port_info.port_id, &ctc_speed);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d get speed ret %d",
                __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }                
        /*For 1G/10G auto, first change speed to aim speed, then open auto.*/
        if(CTC_PORT_SPEED_1G == ctc_speed)
        {
            if((GLB_SPEED_10G == speed) 
                || ((GLB_SPEED_AUTO == speed)&&(GLB_SPEED_10G == pphy_info->phy_manage_info.fiber_ability)))
            {
                ret += ctc_phy_port_set_speed(pphy_info, CTC_PORT_SPEED_10G);
                if(ret != CTC_E_NONE)
                {
                    DRV_LOG_ERR("%s %d gport %d set speed ret %d",
                        __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
                }
                DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null port %d switch to 10G",pphy_info->port_info.port_id)                
            }
            else
            {
                ret += ctc_phy_port_set_auto_reg(pphy_info, 1);
            }
        }
        else if(CTC_PORT_SPEED_10G == ctc_speed)
        {
            if((GLB_SPEED_1G == speed) 
                || ((GLB_SPEED_AUTO == speed)&&(GLB_SPEED_1G == pphy_info->phy_manage_info.fiber_ability)))
            {
                ret += ctc_phy_port_set_speed(pphy_info, CTC_PORT_SPEED_1G);
                ret += ctc_phy_port_set_auto_reg(pphy_info, 1);
                DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null port %d switch to 1G",pphy_info->port_info.port_id)
            }            
        }
        else if((CTC_PORT_SPEED_40G == ctc_speed)||(CTC_PORT_SPEED_100G == ctc_speed))
        {
            pphy_info->phy_manage_info.cl73_enable = 1;
            ret += ctc_phy_port_update_cl73_ability(pphy_info);
            /*Bug42145. Be same as force mode when fiber insert.*/
            if(pphy_info->phy_manage_info.cl73_ability == 0)
            {
                /* Fix bug43932, when fiber insert, must disable AN first */
                ret += ctc_phy_port_set_auto_reg(pphy_info, 0);  
                /*cfg speed is auto, real speed depend on fiber speed.*/
                if(speed == GLB_SPEED_AUTO)
                {
                    if((ctc_speed == CTC_PORT_SPEED_40G) && (pphy_info->phy_manage_info.fiber_ability == GLB_SPEED_100G))
                    {
                        ret += ctc_phy_port_set_speed(pphy_info, CTC_PORT_SPEED_100G);
                    }
                    else if((ctc_speed == CTC_PORT_SPEED_100G) && (pphy_info->phy_manage_info.fiber_ability == GLB_SPEED_40G))
                    {
                        ret += ctc_phy_port_set_speed(pphy_info, CTC_PORT_SPEED_40G);
                    }
                }                
                /*cfg speed is force, real speed depend on CFG speed.*/
                else
                {
                    if((ctc_speed == CTC_PORT_SPEED_40G) && (speed == GLB_SPEED_100G))
                    {
                        ret += ctc_phy_port_set_speed(pphy_info, CTC_PORT_SPEED_100G);
                    }
                    else if((ctc_speed == CTC_PORT_SPEED_100G) && (speed == GLB_SPEED_40G))
                    {
                        ret += ctc_phy_port_set_speed(pphy_info, CTC_PORT_SPEED_40G);
                    }
                }
                /*get new ctc speed*/
                ret = ctc_port_get_speed(pphy_info->port_info.port_id, &ctc_speed);
                /*if 100G enable fec, when change to force, need disable/enable mac to avoid fec hang.*/
                if((pphy_info->phy_manage_info.enable)&&(ctc_speed == CTC_PORT_SPEED_100G)&&(pphy_info->phy_manage_info.fec_en))
                {
                    ret = ctc_port_set_mac_en(pphy_info->port_info.port_id, 0);
                    if(ret != CTC_E_NONE)
                    {
                        DRV_LOG_ERR("%s %d gport %d  ret %d", 
                             __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
                    }
                    ret = ctc_port_set_mac_en(pphy_info->port_info.port_id, 1);
                    if(ret != CTC_E_NONE)
                    {
                        DRV_LOG_ERR("%s %d gport %d  ret %d", 
                             __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
                    }
                }
            }
            else
            {
                ret += ctc_phy_port_restart_auto(pphy_info);
                DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null port %d start clause73 auto",pphy_info->port_info.port_id)
            }
        }        
    }
    else /*Force mode*/
    {
        /*1. disable auto. Note: if current speed is 10G, and need change to 1G, then this disable won't affect 1G 
            auto. because sdk will check pcs mode before disable auto.*/
        pphy_info->phy_manage_info.cl73_enable = 0;
        ret += ctc_phy_port_set_auto_reg(pphy_info, 0);
        /*2. Get real speed.*/
        ret = ctc_port_get_speed(pphy_info->port_info.port_id, &ctc_speed);
        if(ret != CTC_E_NONE)
        {
            DRV_LOG_ERR("%s %d gport %d get speed ret %d",
                __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
        }
        /*3. decide to change speed*/      
        if(speed == GLB_SPEED_1G)
        {
            if(ctc_speed != CTC_PORT_SPEED_1G)
            {
                ret += ctc_phy_port_set_speed(pphy_info, CTC_PORT_SPEED_1G);
                ret += ctc_phy_port_set_auto_reg(pphy_info, 0);
                DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null port %d force to 1G",pphy_info->port_info.port_id)
            }
            else
            {
                /*When 1G disable auto, force port down/up to notify link parter.*/
                if(pphy_info->phy_manage_info.enable)
                {
                    ret += ctc_port_set_mac_en(pphy_info->port_info.port_id, 0);
                    if(ret != CTC_E_NONE)
                    {
                        DRV_LOG_ERR("%s %d gport %d  ret %d", 
                             __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
                    }
                    /*Bug39941, delay 20ms between down/up to notify link partner.*/
                    sal_udelay(20000);
                    ret += ctc_port_set_mac_en(pphy_info->port_info.port_id, 1);
                    if(ret != CTC_E_NONE)
                    {
                        DRV_LOG_ERR("%s %d gport %d  ret %d", 
                             __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
                    }
                } 
            }
        }        
        else if((speed == GLB_SPEED_10G) && (ctc_speed != CTC_PORT_SPEED_10G))
        {
            ret += ctc_phy_port_set_speed(pphy_info, CTC_PORT_SPEED_10G);
            DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null port %d force to 10G",pphy_info->port_info.port_id)
        }
        else if((speed == GLB_SPEED_40G) && (ctc_speed != CTC_PORT_SPEED_40G))
        {
            ret += ctc_phy_port_set_speed(pphy_info, CTC_PORT_SPEED_40G);
            DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null port %d force to 40G",pphy_info->port_info.port_id)
        }
        else if((speed == GLB_SPEED_100G) && (ctc_speed != CTC_PORT_SPEED_100G))
        {
            ret += ctc_phy_port_set_speed(pphy_info, CTC_PORT_SPEED_100G);
            DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null port %d force to 100G",pphy_info->port_info.port_id)
        }
        /*if 100G enable fec, when change to force, need disable/enable mac to avoid fec hang.*/
        if((pphy_info->phy_manage_info.enable)&&(speed == GLB_SPEED_100G)&&(pphy_info->phy_manage_info.fec_en))
        {
            ret = ctc_port_set_mac_en(pphy_info->port_info.port_id, 0);
            if(ret != CTC_E_NONE)
            {
                DRV_LOG_ERR("%s %d gport %d  ret %d", 
                     __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
            }
            ret = ctc_port_set_mac_en(pphy_info->port_info.port_id, 1);
            if(ret != CTC_E_NONE)
            {
                DRV_LOG_ERR("%s %d gport %d  ret %d", 
                     __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
            }
        }
        /* after set speed, must re-enable undir function if needed */
        if(GLB_PORT_UNIDIR_DISABLE != pphy_info->phy_manage_info.unidir)
        {
            phy_null_config_unidir(phy_handle, pphy_info->phy_manage_info.unidir);
        }
    }
    return ret;
}

/*GB not support config flowctrl ability. GG support, but need sdk give API.*/
int32 phy_null_config_flowctrl(phy_handle_t* phy_handle, uint8 symmetric, uint8 asymmetric)
{
    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    return RESULT_OK;
}

/* added by tongzb for bug 44368, support loopback on CNOS */
int32 phy_null_config_loopback(phy_handle_t* phy_handle, uint8 lb_mode)
{
    uint8 i;
    int32 ret = RESULT_OK;
    phy_info_t *pphy_info;
    uint8 lchip = 0;
    ctc_chip_serdes_loopback_t  lb_param;
    uint8 il, el; /* current internal/external loopback status */
    ctc_port_speed_t ctc_speed;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }

    pphy_info = &phy_handle->phy_info;
    DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL,
        "phy null port %d config loopback mode %d", pphy_info->port_info.port_id, lb_mode);
    
    sal_memset(&lb_param, 0, sizeof(ctc_chip_serdes_loopback_t));

    lb_param.serdes_id = pphy_info->port_info.serdes_id;
    /* get internal loopback status */
    lb_param.mode = 0;
    ret = ctc_chip_get_property(lchip, CTC_CHIP_PROP_SERDES_LOOPBACK, (void*)&lb_param);
    il = lb_param.enable;

    /* get external loopback status */
    lb_param.mode = 1;
    ret = ctc_chip_get_property(lchip, CTC_CHIP_PROP_SERDES_LOOPBACK, (void*)&lb_param);
    el = lb_param.enable;

    switch (lb_mode)
    {
    case GLB_LB_NONE: /* disable loopback */
        if (il)   /* disable internal loopback if exist */
        {
            for (i = 0; i < pphy_info->port_info.serdes_num; i++)
            {
                lb_param.serdes_id = pphy_info->port_info.serdes_id+i;
                lb_param.mode = 0;
                lb_param.enable = 0;
                ret += ctc_chip_set_property(lchip, CTC_CHIP_PROP_SERDES_LOOPBACK, (void*)&lb_param);
            }
        }
        if (el)   /* disable external loopback if exist */
        {
            for (i = 0; i < pphy_info->port_info.serdes_num; i++)
            {
                lb_param.serdes_id = pphy_info->port_info.serdes_id+i;
                lb_param.mode = 1;
                lb_param.enable = 0;
                ret = ctc_chip_set_property(lchip, CTC_CHIP_PROP_SERDES_LOOPBACK, (void*)&lb_param);
            }
        }
        /* Rollback AN */
        ret += ctc_phy_port_rollback_auto(pphy_info);
        /* update serdes loopback flag to 0 */
        pphy_info->serdes_lb_en = 0;
        break;
    case GLB_LB_PHY_NEAR: /* internal loopback */
        if (el)   /* disable external loopback if exist */ 
        {
            for (i = 0; i < pphy_info->port_info.serdes_num; i++)
            {
                lb_param.serdes_id = pphy_info->port_info.serdes_id+i;
                lb_param.mode = 1;
                lb_param.enable = 0;
                ret = ctc_chip_set_property(lchip, CTC_CHIP_PROP_SERDES_LOOPBACK, (void*)&lb_param);
            }
        }
        /* update serdes loopback flag to 1 */
        pphy_info->serdes_lb_en = 1;
        /* Before config loopback, need disable AN first */
        /* modified by tongzb for bug 44296 */
        ret = ctc_port_get_speed(pphy_info->port_info.port_id, &ctc_speed);
        if(CTC_PORT_SPEED_1G != ctc_speed)
        {
            ret += ctc_phy_port_set_auto_reg(pphy_info, 0);
        }
        for (i = 0; i < pphy_info->port_info.serdes_num; i++)
        {        
            lb_param.serdes_id = pphy_info->port_info.serdes_id+i;
            lb_param.mode = 0;
            lb_param.enable = 1;
            ret += ctc_chip_set_property(lchip, CTC_CHIP_PROP_SERDES_LOOPBACK, (void*)&lb_param);
            if (ret)
            {
                /* set serdes loopback failed, Rollback AN and lb flag */
                ret += ctc_phy_port_rollback_auto(pphy_info);
                pphy_info->serdes_lb_en = 0;
            }
        }
        break;
    case GLB_LB_PHY_FAR:  /* external loopback */
        if (il)   /* disable internal loopback if exist */
        {
            for (i = 0; i < pphy_info->port_info.serdes_num; i++)
            {           
                lb_param.serdes_id = pphy_info->port_info.serdes_id+i;
                lb_param.mode = 0;
                lb_param.enable = 0;
                ret = ctc_chip_set_property(lchip, CTC_CHIP_PROP_SERDES_LOOPBACK, (void*)&lb_param);
            }
        }
        /* update serdes loopback flag to 1 */
        pphy_info->serdes_lb_en = 1;
        /* Before config loopback, need disable AN first */
        /* modified by tongzb for bug 44326, if port is 1G, do not disable autoneg */
        ret = ctc_port_get_speed(pphy_info->port_info.port_id, &ctc_speed);
        if(CTC_PORT_SPEED_1G != ctc_speed)
        {
            ret += ctc_phy_port_set_auto_reg(pphy_info, 0);
        }
        for (i = 0; i < pphy_info->port_info.serdes_num; i++)
        {
            lb_param.serdes_id = pphy_info->port_info.serdes_id+i;
            lb_param.mode = 1;
            lb_param.enable = 1;
            ret += ctc_chip_set_property(lchip, CTC_CHIP_PROP_SERDES_LOOPBACK, (void*)&lb_param);
            if (ret)
            {
                /* set serdes loopback failed, Rollback AN and lb flag */
                ret += ctc_phy_port_rollback_auto(pphy_info);
                pphy_info->serdes_lb_en = 0;
            }
        }
        break;
    default:
        return RESULT_ERROR;
        break;
    }
    
    return ret;
}

int32 phy_null_config_medium(phy_handle_t* phy_handle, uint8 mac_if, uint8 media_if)
{
    return RESULT_OK;
}
/*Bug39456 jqiu 2016-07-19, support CL73 auto.*/
int32 phy_null_do_cl73_auto(phy_handle_t* phy_handle)
{
    phy_info_t *pphy_info;
    int32 ret = RESULT_OK;

    if (NULL == phy_handle)
    {
        return RESULT_ERROR;
    }

    pphy_info = &phy_handle->phy_info;
    if(pphy_info->phy_manage_info.enable 
        && pphy_info->phy_manage_info.cl73_enable
        && pphy_info->phy_manage_info.cl73_ability)
    {
        ret = ctc_phy_port_do_cl73_auto(pphy_info);
    }
    return ret;    
}

int32 phy_null_get_cur_status(phy_handle_t* phy_handle, glb_phy_state_t *phy_val)
{
    phy_info_t *pphy_info;
    ctc_port_speed_t port_speed;
    int is_up, link_up;
    uint16 gport;
    int32 ret = RESULT_OK;

    if (NULL == phy_handle)
    {
        return RESULT_ERROR;
    }

    pphy_info = &phy_handle->phy_info;
    gport = pphy_info->port_info.port_id;
    if(pphy_info->phy_manage_info.enable)
    {
        /* if unidir is enabled, then force link up */
        /* Modfied by liuht for bug45110, 2017-0912 */
        if(GLB_PORT_UNIDIR_DISABLE != phy_handle->phy_info.phy_manage_info.unidir)
            is_up = GLB_LINK_UP;
        else
            ret = ctc_port_get_mac_link_up(gport, &is_up);
    }
    else
    {
        is_up = GLB_LINK_DOWN;
    }
    
    if(is_up)
    {
        ret += ctc_port_get_speed(gport, &port_speed);
        /* Modified by liuht for bug41686, 2016-11-23 */
        /* 100G port need get link status (with fault signal) from epld */
        /* Modfied by liuht for bug45110, 2017-0912 */
        if((port_speed == CTC_PORT_SPEED_100G) 
            && (GLB_PORT_UNIDIR_DISABLE == phy_handle->phy_info.phy_manage_info.unidir))
        {
            epld_get_txlink_status(phy_handle->phy_info.zg_port_id, &is_up);
        }
    }

    if(is_up)
    {
        if(port_speed == CTC_PORT_SPEED_100G)
            phy_val->speed = GLB_SPEED_100G;
        else if(port_speed == CTC_PORT_SPEED_40G)
            phy_val->speed = GLB_SPEED_40G;
        else if(port_speed == CTC_PORT_SPEED_10G)
            phy_val->speed = GLB_SPEED_10G;
        else if(port_speed == CTC_PORT_SPEED_2G5)
            phy_val->speed = GLB_SPEED_2_5G;
        else if(port_speed == CTC_PORT_SPEED_1G)
            phy_val->speed = GLB_SPEED_1G;  

        link_up = GLB_LINK_UP;
    }
    else
    {
        phy_val->speed = pphy_info->phy_manage_info.speed;
        link_up = GLB_LINK_DOWN;
    }
    phy_val->link_up = link_up;

    phy_val->duplex = GLB_DUPLEX_FULL;
    phy_val->linkup_media = GLB_PORT_TYPE_FIBER;
    phy_val->flowctrl.recv = phy_handle->phy_info.phy_manage_info.flowctrl.recv;
    phy_val->flowctrl.send = phy_handle->phy_info.phy_manage_info.flowctrl.send;
    return ret;
}

extern uint32 g_link_tolerable_time;
int32 phy_null_get_link_interrupt(phy_handle_t* phy_handle, glb_phy_state_t* phy_val, 
                            phy_state_change_t* phy_change)
{
    phy_info_t *pphy_info;
    int32 ret = RESULT_OK;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    pphy_info = &phy_handle->phy_info;

    if (g_link_tolerable_time == 0)
    {
        phy_val->link_up = GLB_LINK_DOWN;
    }
    else
    {
        sal_task_sleep(g_link_tolerable_time);
        phy_null_get_cur_status(phy_handle, phy_val);
    }
       
    /*link change from up to down*/
    //if(pphy_info->phy_stat_flag.link_up == GLB_LINK_UP)
    if((pphy_info->phy_stat_flag.link_up != phy_val->link_up)
        &&(phy_val->link_up == GLB_LINK_DOWN))
    {
        phy_change->action = 0;
        DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null addr %d link down",pphy_info->port_info.port_id)
        /*Bug4038, jqiu optimize. When use chip link, must disable intr when link is down, or it will report intr continully. uni-dir won't use intr.*/
        if(GLB_PORT_UNIDIR_ENABLE != phy_handle->phy_info.phy_manage_info.unidir)
        {
            ret = ctc_port_set_property(pphy_info->port_info.port_id,CTC_PORT_PROP_LINK_INTRRUPT_EN, FALSE);
            if(ret != CTC_E_NONE)
            {
                DRV_LOG_ERR("%s %d gport %d  ret %d", 
                     __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
            }
        }
        ctc_phy_port_restart_auto(pphy_info);
        pphy_info->phy_stat_flag.link_up = phy_val->link_up;
    }    
    /*link not change*/
    else
    {
        phy_change->action = -1;
    }
    
    return RESULT_OK;    
}

int32 phy_null_get_link_poll(phy_handle_t* phy_handle, glb_phy_state_t* phy_val, 
                            phy_state_change_t* phy_change)
{
    phy_info_t *pphy_info;
    int32 ret = RESULT_OK;

    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    pphy_info = &phy_handle->phy_info;
    phy_null_get_cur_status(phy_handle, phy_val);
    
    /*link change from down to up*/
    if((pphy_info->phy_stat_flag.link_up != phy_val->link_up)
        &&(phy_val->link_up != GLB_LINK_DOWN))
    {
        phy_change->action = 1;
        if(pphy_info->phy_stat_flag.flowctrl.send != phy_val->flowctrl.send ||
            pphy_info->phy_stat_flag.flowctrl.recv != phy_val->flowctrl.recv)
        {
            phy_change->flowctrl_change = 1;
        }
        /*When use chip link, only can enable intr when link is up, uni-dir won't use intr.*/
        if(GLB_PORT_UNIDIR_ENABLE != phy_handle->phy_info.phy_manage_info.unidir)
        {
            ret = ctc_port_set_property(pphy_info->port_info.port_id,CTC_PORT_PROP_LINK_INTRRUPT_EN,TRUE);
            if(ret != CTC_E_NONE)
            {
                DRV_LOG_ERR("%s %d gport %d  ret %d", 
                     __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
            }
        }
        DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null addr %d link up",pphy_info->port_info.port_id) 
    }
    /*link change from up to down*/
    else if((pphy_info->phy_stat_flag.link_up != phy_val->link_up)
        &&(phy_val->link_up == GLB_LINK_DOWN))
    {
        phy_change->action = 0;
        DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL, "phy null addr %d link down",pphy_info->port_info.port_id)
        /*Bug4038, jqiu optimize. When use chip link, must disable intr when link is down, or it will report intr continully. uni-dir won't use intr.*/
        if(GLB_PORT_UNIDIR_ENABLE != phy_handle->phy_info.phy_manage_info.unidir)
        {
            ret = ctc_port_set_property(pphy_info->port_info.port_id,CTC_PORT_PROP_LINK_INTRRUPT_EN, FALSE);
            if(ret != CTC_E_NONE)
            {
                DRV_LOG_ERR("%s %d gport %d  ret %d", 
                     __FUNCTION__, __LINE__,pphy_info->port_info.port_id, ret);
            }
        }
        ctc_phy_port_restart_auto(pphy_info);
    }
    /*link always up*/
    else if(phy_val->link_up == GLB_LINK_UP)
    {
        phy_change->action = -1;
        if(pphy_info->phy_stat_flag.speed != phy_val->speed)
        {            
            phy_change->speed_change = 1;
        }
        if(pphy_info->phy_stat_flag.flowctrl.send != phy_val->flowctrl.send ||
            pphy_info->phy_stat_flag.flowctrl.recv != phy_val->flowctrl.recv)
        {
            phy_change->flowctrl_change = 1;
        }
    }
    /*link always down*/
    else
    {
        phy_change->action = -1;
    }
    pphy_info->phy_stat_flag.link_up = phy_val->link_up;
    pphy_info->phy_stat_flag.speed = phy_val->speed;
    pphy_info->phy_stat_flag.duplex = phy_val->duplex;
    pphy_info->phy_stat_flag.linkup_media = phy_val->linkup_media;
    /*When link is down, not update flow ctrl*/
    if(phy_val->link_up == GLB_LINK_UP)
    {
        pphy_info->phy_stat_flag.flowctrl.send = phy_val->flowctrl.send;
        pphy_info->phy_stat_flag.flowctrl.recv = phy_val->flowctrl.recv;
    }

    return RESULT_OK;

}

int32 
phy_null_config_phy_sig_test_mode(phy_handle_t* phy_handle, uint8 serdes_id, uint8 mode)
{
// TODO: by weij for merge GB trunk to GG
#if 0
    ctc_chip_serdes_reg_access_t reg_access;
    
    if(mode == PHY_SIG_TEST_MODE_NORMAL)
    {
        reg_access.serdes_id = serdes_id;
        reg_access.direction = 1;
        reg_access.addr = 1;
        reg_access.value = 0;
        ctc_chip_set_property(0, CTC_CHIP_REG_ACCESS, (void *)&reg_access);
    }
    else if(mode == PHY_SIG_TEST_MODE_PRBS9)
    {
        reg_access.serdes_id = serdes_id;
        reg_access.direction = 1;
        reg_access.addr = 1;
        reg_access.value = 0x1008;
        ctc_chip_set_property(0, CTC_CHIP_REG_ACCESS, (void *)&reg_access);
    }
    else if(mode == PHY_SIG_TEST_MODE_PRBS31)
    {
        reg_access.serdes_id = serdes_id;
        reg_access.direction = 1;
        reg_access.addr = 1;
        reg_access.value = 0xe;
        ctc_chip_set_property(0, CTC_CHIP_REG_ACCESS, (void *)&reg_access);
    }
#endif
    return RESULT_OK;
}

int32 phy_null_config_speed(phy_handle_t* phy_handle, uint8 speed)
{
    int32 ret = 0;
    phy_info_t *pphy_info;
    
    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    pphy_info = &phy_handle->phy_info;
    ret = phy_null_conf_set(phy_handle, speed, pphy_info->phy_manage_info.duplex);
    DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL,
        "phy null gport %d config speed %d, orig %d, ret %d", pphy_info->port_info.port_id, speed, 
            pphy_info->phy_manage_info.speed, ret);
    return ret;
}

int32 phy_null_config_duplex(phy_handle_t* phy_handle, uint8 duplex)
{
    int32 ret = 0;
    phy_info_t *pphy_info;
    
    if(NULL == phy_handle)
    {
        return RESULT_ERROR;
    }
    pphy_info = &phy_handle->phy_info;
    ret = phy_null_conf_set(phy_handle, pphy_info->phy_manage_info.speed, duplex);
    DRV_LOG_DEBUG(phy, DRV_PHY_NORMAL,
        "phy null gport %d config duplex %d, orig %d, ret %d", pphy_info->port_info.port_id, duplex, 
            pphy_info->phy_manage_info.duplex, ret);
    return ret;
}

phy_handle_t* phy_null_dev_register(phy_info_t* pphy_info)
{
    phy_handle_t* phdl = NULL;
    
    if(NULL == pphy_info)
    {
        return NULL;
    }
    
    phdl = (phy_handle_t* )DRV_CALLOC(CTCLIB_MEM_DRIVER_PHY_INFO, sizeof(phy_handle_t));
    if(NULL == phdl)
    {
        DRV_LOG_ERR("malloc failed");
        return NULL;
    }

    sal_memcpy(&phdl->phy_info, pphy_info, sizeof(phy_info_t));

    phdl->config_enable = phy_null_enable;
    phdl->config_speed = phy_null_config_speed;
    phdl->config_duplex = phy_null_config_duplex;
    phdl->config_medium = phy_null_config_medium;
    phdl->config_flowctrl = phy_null_config_flowctrl;
    phdl->config_loopback = phy_null_config_loopback; /* bug44010, support serdes loopback, qicx, 2017-05-15 */
    phdl->get_link_poll = phy_null_get_link_poll;
    phdl->get_link_interupt = phy_null_get_link_interrupt;
    phdl->config_master_slave= NULL;
    phdl->get_cur_status = phy_null_get_cur_status; /* modified by liuht for bug 26641, 2014-0422 */
    phdl->config_phy_sig_test_mode = phy_null_config_phy_sig_test_mode;
    phdl->config_unidir = phy_null_config_unidir;
    phdl->config_fec_en = phy_null_config_fec_en;
    return phdl;
}




