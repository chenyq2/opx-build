#ifndef __PHY_DRV_H__
#define __PHY_DRV_H__

#include "sal_common.h"
#include "sal_mutex.h"
#include "glb_hw_define.h"
#include "glb_phy_define.h"
#include "mdio.h"
#if 0
#include <sys/time.h>
#include <time.h>
#include <errno.h>
#endif
/****************************************************
*
*       MACRO Define
*
*****************************************************/


/****************************************************
*
*   TYPES Define
*
****************************************************/
#define XGPHY_PMA_DEV                   0x1
#define XGPHY_WIS_DEV                   0x2
#define XGPHY_PCS_DEV                   0x3
#define XGPHY_XS_DEV                    0x4

#define XGPHY_REG_CONTROL_REG            0x0
#define XGPHY_REG_STATUS_REG            0x1

typedef enum
{
    PORT_PHY_QT2X25,
    PORT_PHY_VSC8211,
    PORT_PHY_VSC8x58,
    PORT_PHY_VSC8488,
    PORT_PHY_VSC8512,
    PORT_PHY_NULL,
    PORT_PHY_LSI1082,
    PORT_PHY_VSC8504,
    PORT_PHY_SFP, /*bug23865*/
    PORT_PHY_AQR405,
    PORT_PHY_AQR408,
    PORT_PHY_AQR409,
    MAX_PHY_TYPE,
}phy_device_type_t;

/* Work mode */
typedef enum
{
    PHY_WORK_MODE_NORMAL=0,
    PHY_WORK_MODE_PASSTHROUGH,
}phy_work_mode_t;

/* enable auto negotiation */
typedef enum
{
    PHY_DISABLE_AUTO_NEGO = 0,
    PHY_ENABLE_AUTO_NEGO,
}phy_enable_auto_nego_t;

/* For the purpose of read and write the PHY register */
typedef struct phyreg_param_s 
{
    uint8 dev_no;           /* dev type of 10G phy, for 1G phy it's not used*/
    union {
        uint8 regaddr8;     /* 1G phy reg 8bit width */
        uint16 regaddr16;   /* 10G phy 16bit width*/
    } dat;
} phyreg_param_t;

struct flowctrl_adv_ability_s
{
     uint8 asymmetric_pause; /*if 1 enable pause,0 disable pause*/
     uint8 symmetric_pause;  /*if 1 enable pause,0 disable pause*/
};
typedef struct flowctrl_adv_ability_s flowctrl_adv_ability_t;


/* VeriPHY result */
typedef struct {
    int8                      link;      /* Link status */
    glb_pair_state_t          status[4]; /* Status, pair A-D (0-3) */
    uint8                     length[4]; /* Length (meters), pair A-D (0-3) */
} phy_veriphy_result_t;


typedef struct
{
    /* Variables common to all tasks */
    uint8 task_state;   /* 0x00 ==> idle (but still serviced) */
                                /* 0x01 - 0x7f ==> task-defined, */
                                /* bit [7]: 1 ==> abort requested */

    /* VeriPHY public variables */
    uint8 flags;        /* bit [7:6] = VeriPHY operating mode */
                                /*        00 ==> full VeriPHY algorithm */
                                /*        01 ==> anomaly-search only */
                                /*        10 ==> anomaly-search w/o x-pair only */
                                /*        11 ==> reserved */
                                /* bit [5:4] = unreliablePtr (if bit [3] == 1) */
                                /* bit [3]   = unreliablePtr presence flag */
                                /* bit [2]   = getCableLength done flag */
                                /* bit [1]   = valid */
                                /* bit [0]   = linkup-mode */
    uint8  stat[4];      /* status for pairs A-D (0-3), 4-bit unsigned number */
                                /*        most signiciant 4-bits represents prev. status */
    uint8 loc[4];       /* length/fault location for pairs A-D (0-3), 8-bit unsgn */

    /* VeriPHY private variables */
    int8 subchan;
    int8 nc;
    uint8 numCoeffs;
    uint8 firstCoeff;
    int16 strength[4];          /* fault strength for pairs A-D (0-3), 14-bit signed int. */
    int16 thresh[4];            /* threshold (used in different places), 13-bit unsgn */
    int16 log2VGAx256;          /* log2(VGA gain scalefactor)*256 (0 for link-down case) */
    int8  signFlip;      /* count used to improve location accuracy */
    int32 tr_raw0188;            /* wastes one byte */
    int16 maxAbsCoeff;
    int16 coeff[12]; 
    uint16 saveMediaSelect;   /* store previous media */ 
    phy_veriphy_result_t result; /* VCT test result */
    uint8 count;             /* Timeout count*/
    int32 ret;                /* store the status func return result */
} phy_veriphy_task_t;


typedef struct
{
    int action;             /* if 1 link down yo link up; 0 link up to link down, -1, mean link do not change */
    int duplex_change;      /* if 1, duplex change */
    int speed_change;       /* if 1, speed change */
    int flowctrl_change;   /* if 1, flow control change */
    int media_change;       /* if 1, media change */
    int master_slave_change;/* if 0 mode-auto; 1 mode-master; 2 mode-slave for bug 28155 */
    /* Modified by liuht to support eee for bug 28298, 2014-05-16 */
    int eee_status_change;  /* if 1, eee status change */
    /* Modified by liuht for bug 29005, 2014-06-17 */
    int link_change;
    /* End of liuht modified */
} phy_state_change_t;

typedef struct
{
    int8 enable;   /*phy enable flag 1: enable; 0:disable*/
    int8 syncE_enable; /* phy syncE enable flag 1: enable; 0:disable*/
    glb_media_interface_t  media_type;    /*Auto default*/
    glb_mac_interface_t mac_if;     /* SGMII default */
    glb_port_speed_t speed;
    glb_port_duplex_t duplex;
    glb_port_master_slave_t master_slave; /* Modified by liuht for bug 28155, 2014-04-17 */
    glb_port_flowctrl_t flowctrl;     /* flow cntrol, default is disable */
    flowctrl_adv_ability_t flowctrl_ability; /* phy flowctrl ability, default is disable */
    glb_lb_phy_t    lb_mode;        /*loopback mode*/
    int32 mode;             /* phy work mode: normal or pass-through*/
    glb_port_init_seq_t phy_init_seq_flag; /* for vsc8512 phy, indicate pre-reset/reset/post-reset sequence */
    glb_slot_num_t slot_card_idx;        /* for GB Demo board, mark slot card location for each PHY chip */
    uint8 trace_length; /*for vsc8512 phy, indicate the trace length for different position.*/
    glb_vtss_phy_clock_conf_t phy_clk_conf;
    /* Modified by liuht to support eee for bug 28298, 2014-05-16 */
    glb_eee_enable_t eee_enable; /* enable or disable eee function */
    /* End of liuht modified */
    uint8 cl73_enable;       /* enable when speed 40G, duplex auto*/
    uint32 cl73_ability;     /*GG do CL73 802.3ap depend this ability. get ability from FIBER type. */
    uint8 is_DAC;            /* fiber is DAC?*/
    glb_port_speed_t fiber_ability;/*1/10G:depend on fiber speed;40/100G:depend on fiber type*/    
    glb_port_unidir_t unidir;
    /* added by liuyang, 2016-5-3 */
    uint8 fec_en; /* 1 enable, otherwise 0 */
} phy_manage_info_t;

/*bug32103 jqiu 20150305. add lchip and serdes info*/
struct phy_port_info_s
{
    uint16 port_id; /* when multichip, port_id include chip info, so should be uint16 */
    uint8 lchip;
    uint8 serdes_id;    
    uint8 serdes_num;   /* bug44010, support serdes loopback, qicx, 2017-05-15 */
};
typedef struct phy_port_info_s phy_port_info_t;

typedef struct
{
    sal_mutex_t* pmutex;
    phy_device_type_t phy_device_type;
    mdio_bus_type_t mdio_bus;
    uint32 base_addr;      /*mdio controller base addr*/     
    uint8 phy_addr;    /*the phy address of each port on one phy chip*/
    phy_port_info_t port_info;
    uint16 fiber_abs_addr;  /*fiber absent status register address. ctrl by phy GPIO*/
    uint16 fiber_txdis_addr; /* fiber tx disable register address, ctrl by phy GPIO*/
    uint8 port_num; /* port id, added by liuht for bug 25808 */
    uint8 gpio_init;        /*is GPIO need init*/
    uint16 switch_chnl_id;  /*xgmac and 1g phy switch channel*/
    phy_manage_info_t phy_manage_info;
    glb_phy_state_t phy_stat_flag;
    uint8 vct_support;      /* 1 support, otherwise 0 */
    phy_veriphy_task_t *phy_veriphy_tsk;
    void *data;            /*currently, only used for l2switch internal phy, ex:vtss7390*/
    /*modified by jcao for bug 14399, 2011-03-31*/
    glb_phy_led_type_t led_type;
    glb_phy_led_freq_t led_freq;/* added by tongzb, for config led freq, 2017-01-20 */
    /* modified by qicx to get PHY revision, 2012-10-18 */
    uint8 phy_revision;
    uint16 part_num; /*phy part number*/
    void * next_phy_hdl; /* Pointer to next level phy handle. use for MAC+PHY+PHY mode. bug23865*/
    uint8 pair_reverse;/* MDI Reversed (ABCD -> DCBA) */

    uint32 fiber_ability; /* speed ability from fiber type*/
    uint8 speed_ability;
    uint8 serdes_mode;
    uint8 zg_port_id;  /* 100G port id, the first 100G port is 1, and 0 means invalid */
    uint8 serdes_lb_en; /* For bug44010, qicx, 2017-05-23. Serdes loopback enable/disable flag, 
                              1-->internal or external loopback enable;
                              0-->no loopback */

} phy_info_t;

typedef struct phy_handle_s phy_handle_t;
struct phy_handle_s
{
    int32 (* phy_init)(phy_handle_t* );
    int32 (* config_enable)(phy_handle_t*, int8 );
    int32 (* config_speed)(phy_handle_t*, uint8 );
    int32 (* config_master_slave)(phy_handle_t*, uint8 );
    int32 (* config_duplex)(phy_handle_t*, uint8 );
    int32 (* config_loopback)(phy_handle_t*, uint8 );
    int32 (* config_medium)(phy_handle_t*, uint8, uint8 );
    int32 (* config_flowctrl)(phy_handle_t*, uint8, uint8 );
    int32 (* config_clock)(phy_handle_t*, glb_vtss_phy_clock_conf_t);
    int32 (* config_fec_en)(phy_handle_t*, uint8);
    int32 (* get_link_poll)(phy_handle_t*, glb_phy_state_t*, phy_state_change_t* );
    int32 (* get_link_interupt)(phy_handle_t*, glb_phy_state_t* , phy_state_change_t* );
    int32 (* get_cur_status)(phy_handle_t*, glb_phy_state_t*);
    int32 (* config_phy)(phy_handle_t*,phy_manage_info_t* );
    int32 (* reg_read)(phy_handle_t*, phyreg_param_t* , uint16*);
    int32 (* reg_write)(phy_handle_t*, phyreg_param_t*, uint16);
    int32 (* phy_set_vct_mod)(phy_handle_t* );
    int32 (* phy_get_vct_info)(phy_handle_t*, glb_port_cable_info_t* );
    int32 (* enable_syncE)(phy_handle_t*, int8);
    int32 (* mmd_reg_write_mask)(phy_handle_t*, uint16, uint16, uint16, uint16);
    int32 (* enable_eee)(phy_handle_t*, int8);
    int32 (* config_phy_sig_test_mode)(phy_handle_t*, uint8, uint8);/*bug30363 jqiu add 2014-10-23 for customer request*/
    int32 (* config_unidir)(phy_handle_t*, uint8);
    phy_info_t phy_info;
    mdio_handle_t *mdio_hdl;
};


/***************************************************************************
 *  Name:       : phy_dev_register
 *  Purpose     : Create a phy driver handle;
 *  Input       : phy info, ex: device type,bus type,phy addr,base addr,
                  media type;
 *  Output      : N/A
 *  Return      : phy driver handle or NULL
 *  Note        : N/A
 **************************************************************************/
phy_handle_t* phy_dev_register(phy_info_t* pphy_info);
int32 phy_dev_unregister(phy_handle_t* phy_handle);

void flowctrl_admin_to_ability(glb_port_flowctrl_t* admin_flowctrl, flowctrl_adv_ability_t* ability);
void flowctrl_ability_to_admin(flowctrl_adv_ability_t* ability, glb_port_flowctrl_t* admin_flowctrl);


#endif /*__PHY_DRV_H__*/

