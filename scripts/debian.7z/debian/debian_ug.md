#1. Configuring Debian OS image

##1.1 Overview

Centec E580 OSP switch system is based on Debian Linux. Debian Linux OS is composed entirely of free and open-source software, most of which is under the GNU General Public License, and packaged by a group of individuls known as the Debian project. The Debian stable distribution is one of the most popular for personal computers and network servers, and has been used as a base for several other Linux distributions.
The Debian OS gives user great flexibility to customize your switch's operating system and able to install/run your own software/scripts on the switch.
The following sections describe how to configure the Debian Linux OS on your switch. 

##1.2 Install Debian OS from Tradational Centec E580 System 

###1.2.1 Copy Centec E580 OSP Debian OS image file into switch's local flash memory
Boot from tradational Centec Switch OS, and copy the new Centec E580 Debian OS image file: *centecOS-v5.0.0.1.fcs.swi* from FTP or TFTP. 

	SWITCH# copy mgmt-if ftp://username:password@10.10.25.33/centecOS-v5.0.0.1.fcs.swi
	flash:/rootfs.swi

**Note**:

The Debian OS image file must be named as *rootfs.swi* under the root directory on switch's flash memory. On next boot, the system will load the Debian OS image file: *flash:/rootfs.swi* as default configuration.
The configuration of the next boot Debian OS image file path can be configured in the file: *flash:/boot_config*, user may create it manually.

Sample of *flash:/boot_config*:

    boot_config=flash:/rootfs.swi


###1.2.2 Copy Centec E580 cboot image file into switch's local flash memory
Copy the next boot system image: *cboot-v5.0.0.1.fcs.bin* from FTP or TFTP.

	SWITCH# copy mgmt-if ftp://username:password@10.10.25.33/cboot-v5.0.0.1.fcs.bin
	flash:/boot/cboot-v5.0.0.1.fcs.bin

###1.2.3 Configure the next boot system image
Configure the next boot system image: *cboot-v5.0.0.1.fcs.bin*.

	SWITCH# boot system flash:/boot/cboot-v5.0.0.1.fcs.bin

###1.2.3 Reboot switch

	SWITCH# reboot

###1.2.4 Validation Commands

    Switch# show boot image 
	Current boot image version: 48X2Q4Z-0.0.0.13.it
	System image files list:
  	Create Time              Version               File name
	-----------------------+---------------------+----------------------------------
	* 2015-04-10 01:34:15   v0.0.0.12.it          cboot.041001
  	  2015-04-09 06:00:29   v0.0.0.13.it          tap-v580-v0.0.0.13.it.d.bin

##1.3 Install/Upgrade Debian OS from Centec E580 OSP System 

###1.3.1 Copy Centec E580 OSP Debian OS image file into switch's local flash memory
Boot from Centec E580 OSP Switch OS, and copy the new Centec E580 Debian OS image file: *centecOS-v5.0.0.1.fcs.swi* from FTP or TFTP. 

	SWITCH# copy mgmt-if ftp://username:password@10.10.25.33/centecOS-v5.0.0.1.fcs.swi
	flash:/centecOS-v5.0.0.1.fcs.swi

###1.3.2 Configure the next boot OS
Configure the next boot OS image: *centecOS-v5.0.0.1.fcs.swi*

	SWITCH# boot os flash:/centecOS-v5.0.0.1.fcs.swi

###1.3.3 Copy Centec E580 cboot image file to switch's local flash (optional)
Copy the next boot system image: *cboot-v5.0.0.1.fcs.bin* from FTP or TFTP, if user wants to upgrade the cboot image.

	SWITCH# copy mgmt-if ftp://username:password@10.10.25.33/cboot-v5.0.0.1.fcs.bin
	flash:/boot/cboot-v5.0.0.1.fcs.bin

###1.3.4 Configure the next boot system image (optional)
Configure the next boot system image: *cboot-v5.0.0.1.fcs.bin*, if user wants to upgrade the cboot image.

	SWITCH# boot system flash:/boot/cboot-v5.0.0.1.fcs.bin

###1.3.5 Reboot switch

	SWITCH# reboot

###1.3.6 Validation Commands

    Switch# show boot image 
	Current boot image version: 48X2Q4Z-0.0.0.13.it
	System image files list:
  	Create Time           Version               File name
	-----------------------+---------------------+----------------------------------
	* 2015-04-10 01:34:15   v0.0.0.12.it          cboot.041001
  	  2015-04-09 06:00:29   v0.0.0.13.it          tap-v580-v0.0.0.13.it.d.bin

	Switch# show boot config 
	OS image: flash:/rootfs.swi


#2. Basic Debian OS Operations
##2.1 Access Debian OS bash shell

To enter Debian shell, user may enter the "bash" command under switch's shell.

	Switch# bash
	Welcome to Debian bash shell
	root@Switch:/mnt/flash# ls

To exit Debian shell, user may enter the "exit" command under bash shell.

	root@Switch:/mnt/flash# exit
	logout
	Switch#

**Note**:

By default, there are two net namespaces in the Debian OS system: "default" and "mgmt".
User may access the network via panel service port by default namespace
and user may access the network via serial console management port by "mgmt" namespace

For example, user may ping 10.10.1.1 via serial console management port:

	root@Switch:/mnt/flash# ip netns exec mgmt ping 10.10.1.1
	PING 10.10.1.1 (10.10.1.1) 56(84) bytes of data.
	From 10.10.25.253 icmp_seq=1 Time to live exceeded

##2.2 User accounts in Debian OS

The pre-created user accounts are shown below:

Here are the match fields supported by E580 switch:

+------------------------------+------------------------------+
| User Name                    | Password                     |
+------------------------------+------------------------------+
| root                         | centec                       |
+------------------------------+------------------------------+
| centec                       | centec                       |
+------------------------------+------------------------------+

**Note**:

By default, the account "root" (super user) is not alloed to logging on to the system other than console port due to security reason. However, you may logging as normal user using "centec" account, and then enter command "su" to become "root" account. Many administrative tasks require "root" priviledges.

##2.3 Reboot Debian OS
To reboot the system under Debian "bash" shell, you need "root" priviledge, and enter command "reboot".

	centec@Switch:/mnt/flash$ su
	Password: 
	root@Switch:/mnt/flash# reboot

##2.4 Basic Debian Configuration
###2.4.1 Configure DNS server

Step 1. Edit the file */etc/resolv.conf*

Step 2. Configure name server.

	nameserver 10.10.39.254

Step 3. Restart networking service

	#service networking restart
	Configuring network interfaces...done.
**Note**:

"root" privildge is required to perform this operation.

##2.5 Install Debian Package
### Install Debian package from remote repository

Step 1. Make sure you have correct network configurations and remote repository access.

Step 2. Edit */etc/apt/sources.list*, and configure correct remote Debian package repository.

Eg.

	# deb http://ftp.debian.org/debian/ wheezy main

	deb http://ftp.us.debian.org/debian/ wheezy main
	deb-src http://ftp.us.debian.org/debian/ wheezy main

	deb http://security.debian.org/ wheezy/updates main
	deb-src http://security.debian.org/ wheezy/updates main

	# wheezy-updates, previously known as 'volatile'
	deb http://ftp.us.debian.org/debian/ wheezy-updates main
	deb-src http://ftp.us.debian.org/debian/ wheezy-updates main

Step 3. Resynchronize the package index files from sources.

	# apt-get update

Step 4. Install package.

	$ apt-get install package_name

### Install local Debian package:

You may also use the command "dpkg" to install local Debian package

eg.

	# dpkg -i package.deb
**Note**:

"root" privildge is required to perform this operation.