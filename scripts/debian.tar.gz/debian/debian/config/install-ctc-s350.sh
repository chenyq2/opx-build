#!/bin/bash

########################################################################
# Copyright (C) 2004-2014 Centec Networks. All rights reserved.
########################################################################

CENTEC_SWITCH_DIR=/centec_switch
DEBIAN_DIR=/
CHROOT="chroot $CENTEC_SWITCH_DIR"
PACKAGE_ROOT_DIR=$(dirname $(readlink -f $0))
version=2.15.so

uninstall() {
    echo "Uninstalling Centec S350 package ..."
   touch /tmp/ctc-service-uninstall

    killall -9 angel >/dev/null 2>&1
    killall -9 monitor >/dev/null 2>&1
    killall -9 python >/dev/null 2>&1
    killall -9 rpc_server >/dev/null 2>&1
    killall -9 syslog-ng >/dev/null 2>&1
    killall -9 udevd >/dev/null 2>&1
    killall -9 lictl >/dev/null 2>&1
    killall -9 scfgd >/dev/null 2>&1
    killall -9 ntpd >/dev/null 2>&1
    killall -9 hsrvd >/dev/null 2>&1
    killall -9 chsm >/dev/null 2>&1
    killall -9 sshd >/dev/null 2>&1
    killall -9 telnetd >/dev/null 2>&1
    killall -9 dhcrelay6 >/dev/null 2>&1
    killall -9 dhcpd6 >/dev/null 2>&1
    killall -9 dhcrelay6 >/dev/null 2>&1
    killall -9 dhclient >/dev/null 2>&1
    killall -9 nsm >/dev/null 2>&1
    killall -9 snmpd >/dev/null 2>&1
    killall -9 bhm >/dev/null 2>&1
    killall -9 lacpd >/dev/null 2>&1
    killall -9 oamd >/dev/null 2>&1
    killall -9 authd >/dev/null 2>&1
    killall -9 mstpd >/dev/null 2>&1
    killall -9 rmond >/dev/null 2>&1
    killall -9 ripd >/dev/null 2>&1
    killall -9 imi >/dev/null 2>&1

    umount $CENTEC_SWITCH_DIR/proc >/dev/null 2>&1
    umount $CENTEC_SWITCH_DIR/sys >/dev/null 2>&1
    umount $CENTEC_SWITCH_DIR/dev/pts >/dev/null 2>&1
    rm -rf $CENTEC_SWITCH_DIR/dev/pts >/dev/null 2>&1
    umount $CENTEC_SWITCH_DIR/dev >/dev/null 2>&1
    
    rm -rf $CENTEC_SWITCH_DIR/bin
    rm -rf $CENTEC_SWITCH_DIR/centec_switch
    rm -rf $CENTEC_SWITCH_DIR/data
    rm -rf $CENTEC_SWITCH_DIR/etc
    rm -rf $CENTEC_SWITCH_DIR/root
    rm -rf $CENTEC_SWITCH_DIR/sys
    rm -rf $CENTEC_SWITCH_DIR/tmp
    rm -rf $CENTEC_SWITCH_DIR/var
    rm -rf $CENTEC_SWITCH_DIR/conf
    rm -rf $CENTEC_SWITCH_DIR/dev
    rm -rf $CENTEC_SWITCH_DIR/lib
    rm -rf $CENTEC_SWITCH_DIR/proc
    rm -rf $CENTEC_SWITCH_DIR/sbin
    rm -rf $CENTEC_SWITCH_DIR/tftpboot
    rm -rf $CENTEC_SWITCH_DIR/usr
    
    echo "Done"
    echo ""
}

usage() {
    echo "Usage: install-ctc-s350 [uninstall]"
    echo "           uninstall:    Uninstall s350 package"
}

case $# in
    0)
        install_type="install"
        ;;
    1)
        install_type=$1
        ;;
    *)
        usage
        exit 1
esac

if [ $EUID != 0 ]; then
    echo "Please run as root"
    exit
fi

if [ $install_type == "uninstall" ]; then
    echo ""
    uninstall
    exit 1
elif [ $install_type == "install" ]; then
    echo "" 
    #uninstall
else
    usage
    exit 1
fi

if [ ! -d $PACKAGE_ROOT_DIR/s350_package  ]; then
    echo "The Centec S350 package is corrupted, missing directory: s350_package" 
    exit
fi

org_pwd=$(pwd)

echo "Installing Centec S350 package ..."
#rm -rf $CENTEC_SWITCH_DIR
mkdir -p $CENTEC_SWITCH_DIR
mkdir -p $CENTEC_SWITCH_DIR/bin

#upgrade (by overwrite) the directory centec_switch, copying directory will cause running program that using the shared library crash
rm -rf $CENTEC_SWITCH_DIR/upgrade
mkdir -p $CENTEC_SWITCH_DIR/upgrade
cp -rf $PACKAGE_ROOT_DIR/s350_package/* $CENTEC_SWITCH_DIR/upgrade

cd $CENTEC_SWITCH_DIR/upgrade
dirs=$(find -type d)
for dir in ${dirs}; do
    mkdir -p $CENTEC_SWITCH_DIR/${dir}
done

files=$(find -type f)
for file in ${files}; do
    mv -f $CENTEC_SWITCH_DIR/upgrade/$file $CENTEC_SWITCH_DIR/$file
done
rm -rf $CENTEC_SWITCH_DIR/upgrade

#basic library installation
#rm -rf $CENTEC_SWITCH_DIR/lib/powerpc-linux-gnu
#mkdir -p $CENTEC_SWITCH_DIR/lib/powerpc-linux-gnu
#cp -rf $DEBIAN_DIR/lib/powerpc-linux-gnu $CENTEC_SWITCH_DIR/lib/
#ln -s powerpc-linux-gnu/ld-2.13.so $CENTEC_SWITCH_DIR/lib/ld.so.1

cd $CENTEC_SWITCH_DIR/lib

if [ ! -h ld.so.1 ]; then
    ln -s ld-${version}           ld.so.1
fi

if [ ! -h libc.so.6 ]; then
    ln -s libc-${version}         libc.so.6
fi

if [ ! -h libm.so.6 ]; then
    ln -s libm-${version}         libm.so.6
fi

if [ ! -h librt.so.1 ]; then
    ln -s librt-${version}        librt.so.1
fi

if [ ! -h libcrypt.so.1 ]; then
    ln -s libcrypt-${version}     libcrypt.so.1
fi

if [ ! -h libutil.so.1 ]; then
    ln -s libutil-${version}      libutil.so.1
fi
    
if [ ! -h libnsl.so.1 ]; then
    ln -s libnsl-${version}       libnsl.so.1
fi

if [ ! -h libnss_files.so.2 ]; then
    ln -s libnss_files-${version} libnss_files.so.2
fi

if [ ! -h libnss_dns.so.2 ]; then
    ln -s libnss_dns-${version}   libnss_dns.so.2
fi

if [ ! -h libresolv.so.2 ]; then
    ln -s libresolv-${version}    libresolv.so.2
fi
  
if [ ! -h libreadline.so.5 ]; then
    ln -s libreadline.so.5.2      libreadline.so.5
fi

if [ ! -h libpthread.so.0 ]; then
    ln -s libpthread-${version}   libpthread.so.0
fi

if [ ! -h libthread_db.so.1 ]; then
    ln -s libthread_db-1.0.so     libthread_db.so.1
fi

if [ ! -h libdl.so.2 ]; then
    ln -s libdl-${version}        libdl.so.2
fi

if [ ! -h libcrypto.so ]; then
    ln -s libcrypto.so.1.0.0      libcrypto.so
fi

if [ ! -h libssl.so ]; then
    ln -s libssl.so.1.0.0         libssl.so
fi

if [ ! -h libstdc++.so.6 ]; then
    ln -s libstdc++.so.6.0.17     libstdc++.so.6
fi

if [ ! -h libstdc++.so ]; then
    ln -s libstdc++.so.6          libstdc++.so
fi

if [ ! -h libgcc_s.so ]; then
    ln -s libgcc_s.so.1           libgcc_s.so
fi

if [ ! -h libz.so.1 ]; then
    ln -s libz.so.1.2.7           libz.so.1
fi

if [ ! -h libz.so ]; then
    ln -s libz.so.1.2.7           libz.so
fi

if [ ! -h libncurses.so.5 ]; then
    ln -s libncurses.so.5.9       libncurses.so.5
fi

if [ ! -h libncurses.so ]; then
    ln -s libncurses.so.5         libncurses.so
fi

if [ ! -h libpcap.so.1 ]; then
    ln -s libpcap.so.1.5.1        libpcap.so.1
fi

if [ ! -h libpcap.so ]; then
    ln -s libpcap.so.1            libpcap.so
fi

if [ ! -h libglib-2.0.so ]; then
    ln -s libglib-2.0.so.0.3400.3 libglib-2.0.so
fi

if [ ! -h libglib-2.0.so.0 ]; then
    ln -s libglib-2.0.so.0.3400.3 libglib-2.0.so.0
fi

#run prepare-s350.sh to prepare the new rootfs for S350 running environment
cd $CENTEC_SWITCH_DIR/bin
if [ ! -h sh ]; then
    ln -s busybox sh
fi

cd ${org_pwd}

cp -rf $PACKAGE_ROOT_DIR/s350_script/prepare-s350.sh $CENTEC_SWITCH_DIR/bin/
cp -rf $PACKAGE_ROOT_DIR/s350_script/start-service.sh $CENTEC_SWITCH_DIR/bin/
chmod +x $CENTEC_SWITCH_DIR/bin/prepare-s350.sh
chmod +x $CENTEC_SWITCH_DIR/bin/start-service.sh
chroot $CENTEC_SWITCH_DIR /bin/prepare-s350.sh

#copy chvrf to debian /bin
cp -rf $CENTEC_SWITCH_DIR/bin/chvrf /bin/chvrf

#setting environment
echo "PermitUserEnvironment yes" >> $CENTEC_SWITCH_DIR/etc/ssh/sshd_config

#########
#install service script
cp -rf $PACKAGE_ROOT_DIR/s350_script/ctc-s350 /etc/init.d/
/sbin/insserv -f ctc-s350
echo "Done"
echo "You must restart the switch for the service to take effect"
echo ""
