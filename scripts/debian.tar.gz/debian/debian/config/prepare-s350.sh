#!/bin/sh

########################################################################
# Copyright (C) 2004-2014 Centec Networks. All rights reserved.
########################################################################

BUSYBOX="/bin/busybox"

#Create dirs
create_dir(){
    #dirs
    $BUSYBOX mkdir -p /bin
    $BUSYBOX mkdir -p /dev
    $BUSYBOX mkdir -p /etc
    $BUSYBOX mkdir -p /lib
    $BUSYBOX mkdir -p /mnt
    $BUSYBOX mkdir -p /mnt/flash
    $BUSYBOX mkdir -p /proc
    $BUSYBOX mkdir -p /root
    $BUSYBOX mkdir -p /sbin
    $BUSYBOX mkdir -p /sys
    $BUSYBOX mkdir -p /tftpboot
    $BUSYBOX mkdir -p /tmp
    $BUSYBOX mkdir -p /tmp/cmd
    $BUSYBOX mkdir -p /usr
    $BUSYBOX mkdir -p /usr/bin
    $BUSYBOX mkdir -p /usr/sbin
    $BUSYBOX mkdir -p /usr/share
    $BUSYBOX mkdir -p /usr/share/zoneinfo
    $BUSYBOX mkdir -p /var
    $BUSYBOX mkdir -p /var/www
    $BUSYBOX mkdir -p /var/www/images
    $BUSYBOX mkdir -p /var/www/pub
    $BUSYBOX mkdir -p /var/lib
    $BUSYBOX mkdir -p /var/lib/ntp
    $BUSYBOX mkdir -p /var/log
    $BUSYBOX mkdir -p /var/run
    $BUSYBOX mkdir -p /var/empty
    $BUSYBOX mkdir -p /etc/ssh
    $BUSYBOX mkdir -p /etc/ssh/keys
    $BUSYBOX mkdir -p /data
    $BUSYBOX mkdir -p /etc/udev
    $BUSYBOX mkdir -p /etc/udev/rules.d
    $BUSYBOX mkdir -p /mnt/udisk
    $BUSYBOX mkdir -p /mnt/data
    ##
    $BUSYBOX mkdir -p /centec_switch
    $BUSYBOX rm -rf /tmp
    $BUSYBOX rm -rf /boot
    $BUSYBOX mkdir -p /tmp
    $BUSYBOX mkdir -p /tmp/cmd
    
    #symbolic links
    if [ ! -h /sbin/mount ]; then
        $BUSYBOX ln -s /bin/busybox /sbin/mount
    fi
    if [ ! -h /etc/mtab ]; then
        $BUSYBOX ln -s /proc/mounts /etc/mtab
    fi
    
    #make nodes
    if [ ! -c /dev/console ]; then
        $BUSYBOX mknod /dev/console -m 600 c 5 1
    fi
    if [ ! -c /dev/ttyS0 ]; then
        $BUSYBOX mknod /dev/ttyS0 -m 600 c 4 64
    fi
    if [ ! -b /dev/hda ]; then
        $BUSYBOX mknod /dev/hda -m 660 b 3 0
    fi
    if [ ! -b /dev/hda1 ]; then
        $BUSYBOX mknod /dev/hda1 -m 660 b 3 1
    fi
    if [ ! -b /dev/hda2 ]; then
        $BUSYBOX mknod /dev/hda2 -m 660 b 3 2
    fi
    if [ ! -b /dev/hda3 ]; then
        $BUSYBOX mknod /dev/hda3 -m 660 b 3 3
    fi
    if [ ! -b /dev/hda4 ]; then
        $BUSYBOX mknod /dev/hda4 -m 660 b 3 4
    fi
    if [ ! -b /dev/hda5 ]; then
        $BUSYBOX mknod /dev/hda5 -m 660 b 3 5
    fi
    if [ ! -c /dev/ctc_monitor ]; then
        $BUSYBOX mknod /dev/ctc_monitor -m 660 c 200 0
    fi
}

#Create dirs
create_dir

#busybox installation
/bin/busybox mkdir -p /proc
/bin/busybox mkdir -p /sbin
/bin/busybox mount -t proc none /proc > /dev/null 2>&1
/bin/busybox --install -s

#mount dev and system
mkdir -p /sys
mount -t sysfs sysfs /sys > /dev/null 2>&1

mkdir -p /dev
if [ ! -c /dev/null ]; then
    mknod /dev/null c 1 3 > /dev/null 2>&1
fi

/usr/sbin/udevd --daemon > /dev/null 2>&1
/usr/sbin/udevstart > /dev/null 2>&1

if [ ! -c /dev/ctc_allctrl ]; then
    mknod /dev/ctc_allctrl c 99 0
fi
if [ ! -c /dev/ctc_hw ]; then
    mknod /dev/ctc_hw c 100 0
fi
if [ ! -c /dev/linux_dal ]; then
    mknod /dev/linux_dal c 199 0
fi
if [ ! -c /dev/board_hw ]; then
    mknod /dev/board_hw c 100 0
fi
if [ ! -c /dev/ctc_asic_normal ]; then
    mknod /dev/ctc_asic_normal c 101 0
fi
if [ ! -c /dev/ctc_asic_fatal ]; then
    mknod /dev/ctc_asic_fatal c 103 0
fi
if [ ! -c /dev/rtc ]; then
    mknod /dev/rtc c 254 0
fi
if [ ! -c /dev/ctc_cpm ]; then
    mknod /dev/ctc_cpm c 105 0
fi
if [ ! -c /dev/ctc_foam_normal ]; then
    mknod /dev/ctc_foam_normal c 104 0
fi
if [ ! -c /dev/ctc_board_ctl ]; then
    mknod /dev/ctc_board_ctl c 200 0
fi
if [ ! -c /dev/ctc_gpio ]; then
    mknod /dev/ctc_gpio c 106 0
fi
if [ ! -c /dev/ctc_shm ]; then
    mknod /dev/ctc_shm c 110 0
fi
if [ ! -c /dev/ctc_memchk_one_page_shm ]; then
    mknod /dev/ctc_memchk_one_page_shm c 111 0
fi
#Modified by liuht for bug 27657, 2014-03-25
if [ ! -c /dev/ctc_power ]; then
    mknod /dev/ctc_power c 113 0
fi
if [ ! -c /dev/ctc_sys_led ]; then
    mknod /dev/ctc_sys_led c 107 0
fi

mkdir -p /dev/pts
mount -t devpts none /dev/pts > /dev/null 2>&1
