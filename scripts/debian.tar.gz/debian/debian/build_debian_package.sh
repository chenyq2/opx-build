#!/bin/bash

########################################################################
# Copyright (C) 2004-2014 Centec Networks. All rights reserved.
########################################################################

source ${PLAT_TOP_DIR}/build_svc/debian/Debian.env.inc

version=2.15.so

#Build CTCOS Debian Package
echo "Building Centec $_DEBIAN_PACKAGE_NAME Debian package: $_DEBIAN_PACKAGE"

if [ ! -d $_DEBIAN_BUILD_DIR/bin ]; then
    echo "Unable to retrieve binaries, please check if you have built the system correctly"
fi

CROSS_COMPILER="powerpc-fsl_networking-linux-gnuspe-"
_BIN_DIR=bin
if [ $_VER == "d" ]; then
STRIP_PROG=touch
#STRIP_PROG=${CROSS_COMPILER}strip
else
STRIP_PROG=${CROSS_COMPILER}strip
fi

debian_package_bin="\
$_BUILD_ROOTFS_DIR/$_BUILD_BIN_DIR/ls \
$_BUILD_ROOTFS_DIR/$_BUILD_BIN_DIR/ps \
$_BUILD_ROOTFS_DIR/$_BUILD_BIN_DIR/netstat \
$_BUILD_ROOTFS_DIR/$_BUILD_BIN_DIR/ping \
$_BUILD_ROOTFS_DIR/$_BUILD_BIN_DIR/ping6 \
$_DEBIAN_BUILD_DIR/bin/more \
$_DEBIAN_BUILD_DIR/bin/chvrf \
$_BUSYBOX_DIR/busybox \
"
debian_package_sbin="\
$_BUILD_ROOTFS_DIR/$_BUILD_BIN_DIR/mii-tool \
$_BUILD_ROOTFS_DIR/$_BUILD_BIN_DIR/ethtool \
$_BUILD_ROOTFS_DIR/$_BUILD_BIN_DIR/tcpdump \
$_BUILD_ROOTFS_DIR/$_BUILD_BIN_DIR/strace \
"

debian_package_usr_bin="\
$_BUILD_ROOTFS_DIR/usr/$_BIN_DIR/gdb \
$_BUILD_ROOTFS_DIR/usr/$_BIN_DIR/gdbserver \
$_DEBIAN_BUILD_SVC_ETC_DIR/core_helper \
$_DEBIAN_BUILD_DIR/bin/tftp \
$_DEBIAN_BUILD_DIR/bin/ftp \
$_DEBIAN_BUILD_DIR/bin/ntpdate \
$_DEBIAN_BUILD_DIR/bin/hsrvd \
$_DEBIAN_BUILD_DIR/bin/lcsh \
$_DEBIAN_BUILD_DIR/bin/vtysh \
$_DEBIAN_BUILD_DIR/bin/imish \
$_DEBIAN_BUILD_SVC_ETC_DIR/iptables-ppc \
"

debian_package_usr_sbin="\
$_BUILD_ROOTFS_DIR/$_BIN_DIR/flash_erase \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/flashcp \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/flash_eraseall \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/flash_lock \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/flash_unlock \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/ubiattach \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/ubimkvol \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/ubiformat \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/ubinfo \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/ubidetach \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/udevd \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/udevstart \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/lspci \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/setpci \
$_BUILD_ROOTFS_DIR/$_BIN_DIR/tftpd \
$_DEBIAN_BUILD_SVC_ETC_DIR/$BOARD/startup_monitor \
$_DEBIAN_BUILD_DIR/bin/board_type_detect \
$_DEBIAN_BUILD_DIR/bin/ntpq \
$_DEBIAN_BUILD_DIR/bin/monitor \
$_DEBIAN_BUILD_DIR/bin/nopassword \
$_DEBIAN_BUILD_DIR/bin/ssh \
$_DEBIAN_BUILD_DIR/bin/sshd \
$_DEBIAN_BUILD_DIR/bin/imi \
$_DEBIAN_BUILD_DIR/bin/ripd \
$_DEBIAN_BUILD_DIR/bin/ospfd \
$_DEBIAN_BUILD_DIR/bin/ospf6d \
$_DEBIAN_BUILD_DIR/bin/ripngd \
$_DEBIAN_BUILD_DIR/bin/onmd \
$_DEBIAN_BUILD_DIR/bin/mstpd \
$_DEBIAN_BUILD_DIR/bin/ldpd \
$_DEBIAN_BUILD_DIR/bin/pimd \
$_DEBIAN_BUILD_DIR/bin/pim6d \
$_DEBIAN_BUILD_DIR/bin/authd \
$_DEBIAN_BUILD_DIR/bin/bgpd \
$_DEBIAN_BUILD_DIR/bin/bhm \
$_DEBIAN_BUILD_DIR/bin/lacpd \
$_DEBIAN_BUILD_DIR/bin/ptpd \
$_DEBIAN_BUILD_DIR/bin/ssmd \
$_DEBIAN_BUILD_DIR/bin/oamd \
$_DEBIAN_BUILD_DIR/bin/rsvpd \
$_DEBIAN_BUILD_DIR/bin/filem \
$_DEBIAN_BUILD_DIR/bin/angel \
$_DEBIAN_BUILD_DIR/bin/strace \
$_DEBIAN_BUILD_DIR/bin/dhclient \
$_DEBIAN_BUILD_DIR/bin/scfgd \
$_DEBIAN_BUILD_DIR/bin/check_image \
$_DEBIAN_BUILD_DIR/bin/scfg_detect \
$_DEBIAN_BUILD_DIR/bin/dhcpd6 \
$_DEBIAN_BUILD_DIR/bin/fea_shm_init \
$_DEBIAN_BUILD_DIR/bin/httpd \
$_DEBIAN_BUILD_DIR/bin/lictl \
$_DEBIAN_BUILD_DIR/bin/nsm \
$_DEBIAN_BIN_BOARD_DIR/chsm \
$_DEBIAN_BUILD_DIR/bin/ntpd \
$_DEBIAN_BUILD_DIR/bin/ntpdc \
$_DEBIAN_BUILD_DIR/bin/syslog-ng \
$_DEBIAN_BUILD_DIR/bin/init-syslog-ng.sh \
$_DEBIAN_BUILD_DIR/bin/mplsonm \
$_DEBIAN_BUILD_DIR/bin/logsync.sh \
$_DEBIAN_BUILD_DIR/bin/diaglogsync.sh \
$_DEBIAN_BUILD_DIR/bin/dhcrelay6 \
$_DEBIAN_BUILD_DIR/bin/snmpd \
$_DEBIAN_BUILD_DIR/bin/rmond \
$_DEBIAN_BUILD_DIR/bin/break_chroot \
"
debian_package_etc="\
$_DEBIAN_BUILD_SVC_ETC_DIR/UTC \
$_DEBIAN_BUILD_SVC_ETC_DIR/$BOARD/inittab_sup \
$_DEBIAN_BUILD_SVC_ETC_DIR/$BOARD/inittab_lc \
$_DEBIAN_BUILD_SVC_ETC_DIR/termcap \
$_DEBIAN_BUILD_SVC_ETC_DIR/passwd \
$_DEBIAN_BUILD_SVC_ETC_DIR/group \
$_DEBIAN_BUILD_SVC_ETC_DIR/profile \
$_DEBIAN_BUILD_SVC_ETC_DIR/services \
$_DEBIAN_BUILD_SVC_ETC_DIR/protocols \
$_DEBIAN_BUILD_SVC_ETC_DIR/hosts \
$_DEBIAN_BUILD_SVC_ETC_DIR/resolv.conf \
$_DEBIAN_BUILD_SVC_ETC_DIR/nsswitch.conf \
$_DEBIAN_BUILD_SVC_ETC_DIR/cf_hotplug \
$_DEBIAN_BUILD_SVC_ETC_DIR/mount.sh \
$_DEBIAN_BUILD_SVC_ETC_DIR/unmount.sh \
$_DEBIAN_BUILD_SVC_ETC_DIR/$BOARD/rc.sysinit \
$_DEBIAN_BUILD_SVC_ETC_DIR/qt2x25_firmware_mdio.bin \
$_DEBIAN_ETC_DIR/lic.pub.rsa \
$_DEBIAN_ETC_DIR/ntp.conf \
$_DEBIAN_ETC_DIR/ntpkeys.conf \
$_DEBIAN_ETC_DIR/snmpd.conf \
$_DEBIAN_ETC_DIR/httpd.conf \
$_DEBIAN_ETC_DIR/server.pem \
$_DEBIAN_ETC_DIR/fea_cfg_basic_s350 \
"

debian_package_etc_udev="\
$_DEBIAN_BUILD_SVC_ETC_DIR/udev/udev.conf \
"

debian_package_etc_udev_rules="\
$_DEBIAN_BUILD_SVC_ETC_DIR/udev/rules.d/udev.conf \
$_DEBIAN_BUILD_SVC_ETC_DIR/udev/rules.d/mount.rules \
$_DEBIAN_BUILD_SVC_ETC_DIR/udev/rules.d/unmount.rules \
"

debian_package_usr_share_zoneinfo="\
$_DEBIAN_BUILD_SVC_DIR/zone.tab \
$_DEBIAN_BUILD_SVC_DIR/iso3166.tab \
"

debian_package_tmp="\
$_DEBIAN_ETC_DIR/ShowIpeDiscardType.txt \
$_DEBIAN_ETC_DIR/ShowEpeDiscardType.txt \
"

debian_package_ctc_datapath_profile=$(ls \
$_DEBIAN_BUILD_SVC_ETC_DIR/datapath_profile/* \
)

debian_package_lib_ko="\
$_DEBIAN_BUILD_DIR/bin/mpls.ko \
$_DEBIAN_BUILD_DIR/bin/ctc_hw.ko \
$_DEBIAN_BUILD_DIR/bin/dal.ko \
$_DEBIAN_BUILD_DIR/bin/ctc_gpio.ko \
$_DEBIAN_BUILD_DIR/bin/peth_km.ko \
$_DEBIAN_BUILD_DIR/bin/kernel_monitor.ko \
"

debian_package_lib="\
$_DEBIAN_BUILD_DIR/lib/libasn1.so \
$_DEBIAN_BUILD_DIR/lib/libsal.so \
$_DEBIAN_BUILD_DIR/lib/libctclib.so \
$_DEBIAN_BUILD_DIR/lib/libzos.so \
$_DEBIAN_BUILD_DIR/lib/mod_access.so \
$_DEBIAN_BUILD_DIR/lib/mod_cgi.so \
$_DEBIAN_BUILD_DIR/lib/mod_indexfile.so \
$_DEBIAN_BUILD_DIR/lib/mod_auth.so \
$_DEBIAN_BUILD_DIR/lib/mod_dirlisting.so \
$_DEBIAN_BUILD_DIR/lib/mod_staticfile.so \
$_DEBIAN_BUILD_DIR/lib/libneo_cs.so \
$_DEBIAN_BUILD_DIR/lib/libneo_cgi.so \
$_DEBIAN_BUILD_DIR/lib/libneo_utl.so \
$_DEBIAN_BUILD_DIR/lib/libimish.so \
$_DEBIAN_BUILD_DIR/lib/libcjson.so \

$_BUILD_ROOTFS_DIR/usr/lib/libproc-3.2.8.so \
$_BUILD_ROOTFS_DIR/usr/lib/libcrypto.so.1.0.0 \
$_BUILD_ROOTFS_DIR/usr/lib/libssl.so.1.0.0 \

$_BUILD_ROOTFS_DIR/lib/ld-${version} \
$_BUILD_ROOTFS_DIR/lib/libc-${version} \
$_BUILD_ROOTFS_DIR/lib/libm-${version} \
$_BUILD_ROOTFS_DIR/lib/librt-${version} \
$_BUILD_ROOTFS_DIR/lib/libcrypt-${version} \
$_BUILD_ROOTFS_DIR/lib/libutil-${version} \
$_BUILD_ROOTFS_DIR/lib/libnsl-${version} \
$_BUILD_ROOTFS_DIR/lib/libnss_files-${version} \
$_BUILD_ROOTFS_DIR/lib/libnss_dns-${version} \
$_BUILD_ROOTFS_DIR/lib/libresolv-${version} \
$_BUILD_ROOTFS_DIR/usr/lib/libreadline.so.5.2 \
$_BUILD_ROOTFS_DIR/lib/libpthread-${version} \
$_BUILD_ROOTFS_DIR/lib/libthread_db-1.0.so \
$_BUILD_ROOTFS_DIR/lib/libdl-${version} \
$_BUILD_ROOTFS_DIR/usr/lib/libstdc++.so.6.0.17 \
$_BUILD_ROOTFS_DIR/lib/libgcc_s.so.1 \
$_BUILD_ROOTFS_DIR/usr/lib/libz.so.1.2.7 \
$_BUILD_ROOTFS_DIR/usr/lib/libncurses.so.5.9 \
$_BUILD_ROOTFS_DIR/usr/lib/libpcap.so.1.5.1 \
$_BUILD_ROOTFS_DIR/usr/lib/libglib-2.0.so.0.3400.3 \
"

debian_package_etc_ssh="\
$_DEBIAN_ETC_DIR/moduli \
$_DEBIAN_ETC_DIR/ssh_config \
$_DEBIAN_ETC_DIR/ssh_host_dsa_key \
$_DEBIAN_ETC_DIR/ssh_host_dsa_key.pub \
$_DEBIAN_ETC_DIR/ssh_host_key \
$_DEBIAN_ETC_DIR/ssh_host_key.pub \
$_DEBIAN_ETC_DIR/ssh_host_rsa_key \
$_DEBIAN_ETC_DIR/ssh_host_rsa_key.pub \
$_DEBIAN_ETC_DIR/sshd_config \
"

debian_package_etc_mem_profile=$(ls \
$_DEBIAN_ETC_DIR/profile/* \
)

debian_package_var_www=$(ls \
$_DEBIAN_BUILD_DIR/bin/*.cgi \
)

#Dirs
rm -rf $_DEBIAN_PKG_TMP_TOP_DIR
mkdir -p $_DEBIAN_PKG_TMP_TOP_DIR
mkdir -p $_DEBIAN_PKG_TMP_DIR
mkdir -p $_DEBIAN_SCRIPT_TMP_DIR

mkdir -p $_DEBIAN_PKG_TMP_DIR/bin
mkdir -p $_DEBIAN_PKG_TMP_DIR/sbin
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/bin
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/sbin
mkdir -p $_DEBIAN_PKG_TMP_DIR/etc
mkdir -p $_DEBIAN_PKG_TMP_DIR/etc/udev
mkdir -p $_DEBIAN_PKG_TMP_DIR/etc/udev/rules.d
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/share
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/share/zoneinfo
mkdir -p $_DEBIAN_PKG_TMP_DIR/lib
mkdir -p $_DEBIAN_PKG_TMP_DIR/etc/ssh
mkdir -p $_DEBIAN_PKG_TMP_DIR/etc/memory_profile
mkdir -p $_DEBIAN_PKG_TMP_DIR/etc/datapath_profile
mkdir -p $_DEBIAN_PKG_TMP_DIR/etc/ntp
mkdir -p $_DEBIAN_PKG_TMP_DIR/etc/mibs
mkdir -p $_DEBIAN_PKG_TMP_DIR/var
mkdir -p $_DEBIAN_PKG_TMP_DIR/var/www
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/include
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/include/python2.7
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/lib
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/lib/python2.7
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/lib/python2.7/site-packages
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/lib/python2.7/lib-dynload
mkdir -p $_DEBIAN_PKG_TMP_DIR/usr/lib/python2.7/config

#Check files
debian_package_list="${debian_package_bin} ${debian_package_sbin} ${debian_package_usr_bin} \
    ${debian_package_usr_sbin} ${debian_package_etc} ${debian_package_usr_share_zoneinfo} \
    ${debian_package_tmp} ${debian_package_lib} ${debian_package_lib_ko} ${debian_package_etc_ssh} \
    ${debian_package_etc_udev} ${debian_package_etc_udev_rules}"
    
for package_filepathpath in ${debian_package_list}; do
    if [ ! -f ${package_filepathpath} ]; then 
        echo "Unable to retrieve file: ${package_filepathpath}, please check if you have built package correctly"
        exit 1
    fi
done

#Copy files to the package temp dir
for package_filepath in ${debian_package_bin}; do
    filename=$(basename "$package_filepath")
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/bin
    $STRIP_PROG $_DEBIAN_PKG_TMP_DIR/bin/${filename} 2>/dev/null
    chmod +x $_DEBIAN_PKG_TMP_DIR/bin/${filename}
done

for package_filepath in ${debian_package_sbin}; do
    filename=$(basename "$package_filepath")
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/sbin
    $STRIP_PROG $_DEBIAN_PKG_TMP_DIR/sbin/${filename} 2>/dev/null
    chmod +x $_DEBIAN_PKG_TMP_DIR/sbin/${filename}
done

for package_filepath in ${debian_package_usr_bin}; do
    filename=$(basename "$package_filepath")
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/usr/bin
    $STRIP_PROG $_DEBIAN_PKG_TMP_DIR/usr/bin/${filename} 2>/dev/null
    chmod +x $_DEBIAN_PKG_TMP_DIR/usr/bin/${filename}
done
mv $_DEBIAN_PKG_TMP_DIR/usr/bin/iptables-ppc $_DEBIAN_PKG_TMP_DIR/usr/bin/iptables

for package_filepath in ${debian_package_usr_sbin}; do
    filename=$(basename "$package_filepath")
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/usr/sbin
    $STRIP_PROG $_DEBIAN_PKG_TMP_DIR/usr/sbin/${filename} 2>/dev/null
    chmod +x $_DEBIAN_PKG_TMP_DIR/usr/sbin/${filename} 
done

for package_filepath in ${debian_package_etc}; do
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/etc
done

for package_filepath in ${debian_package_etc_udev}; do
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/etc/udev
done

for package_filepath in ${debian_package_etc_udev_rules}; do
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/etc/udev/rules.d
done

for package_filepath in ${debian_package_usr_share_zoneinfo}; do
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/usr/share/zoneinfo
done

for package_filepath in ${debian_package_tmp}; do
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/etc
done

for package_filepath in ${debian_package_lib}; do
    filename=$(basename "$package_filepath")
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/lib
    $STRIP_PROG $_DEBIAN_PKG_TMP_DIR/lib/${filename} 2>/dev/null
    chmod +x $_DEBIAN_PKG_TMP_DIR/lib/${filename}
done

for package_filepath in ${debian_package_lib_ko}; do
    filename=$(basename "$package_filepath")
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/lib
    chmod +x $_DEBIAN_PKG_TMP_DIR/lib/${filename}
done

for package_filepath in ${debian_package_etc_ssh}; do
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/etc/ssh
done

for package_filepath in ${debian_package_ctc_datapath_profile}; do
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/etc/datapath_profile/
done

for package_filepath in ${debian_package_etc_mem_profile}; do
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/etc/memory_profile/
done

for package_filepath in ${debian_package_var_www}; do
    filename=$(basename "$package_filepath")
    cp -rf ${package_filepath} $_DEBIAN_PKG_TMP_DIR/var/www/
    $STRIP_PROG $_DEBIAN_PKG_TMP_DIR/var/www/${filename} 2>/dev/null
    chmod +x $_DEBIAN_PKG_TMP_DIR/var/www/${filename}
done
# python libraries
cp -rf $_DEBIAN_PRE_COMPILED_DIR/usr/include/python2.7 $_DEBIAN_PKG_TMP_DIR/usr/include/
cp -rf $_DEBIAN_PRE_COMPILED_DIR/usr/lib/python2.7/site-packages $_DEBIAN_PKG_TMP_DIR/usr/lib/python2.7/site-packages
cp -rf $_DEBIAN_PRE_COMPILED_DIR/usr/bin $_DEBIAN_PKG_TMP_DIR/usr/
cp -rf $_DEBIAN_PRE_COMPILED_DIR/usr/lib $_DEBIAN_PKG_TMP_DIR/usr/
cp -rf $_DEBIAN_SOFTWARE_DIR/apps/sdn $_DEBIAN_PKG_TMP_DIR/usr/lib/python2.7/site-packages
find $_DEBIAN_PKG_TMP_DIR/usr | grep /.project | xargs rm -rf
find $_DEBIAN_PKG_TMP_DIR/usr | grep /.svn | xargs rm -rf
find $_DEBIAN_PKG_TMP_DIR/usr | grep /.pyc | xargs rm -rf
find $_DEBIAN_PKG_TMP_DIR/usr | grep /.settings | xargs rm -rf
find $_DEBIAN_PKG_TMP_DIR/usr | grep /.pydevproject | xargs rm -rf
find $_DEBIAN_PKG_TMP_DIR/usr | grep /.git | xargs rm -rf

#Special process
mv -f $_DEBIAN_PKG_TMP_DIR/etc/ntpkeys.conf $_DEBIAN_PKG_TMP_DIR/etc/ntp/keys 
mv -f $_DEBIAN_PKG_TMP_DIR/etc/UTC $_DEBIAN_PKG_TMP_DIR/etc/localtime
# Use s350 fea_cfg, modify by zhangdy @ 20140904.
mv -f $_DEBIAN_PKG_TMP_DIR/etc/fea_cfg_basic_s350 $_DEBIAN_PKG_TMP_DIR/etc/fea_cfg

#Copy install script
cp -rf $_DEBIAN_BUILD_SVC_CFG_DIR/prepare-s350.sh $_DEBIAN_SCRIPT_TMP_DIR
cp -rf $_DEBIAN_BUILD_SVC_CFG_DIR/start-service.sh $_DEBIAN_SCRIPT_TMP_DIR
cp -rf $_DEBIAN_BUILD_SVC_CFG_DIR/ctc-s350 $_DEBIAN_SCRIPT_TMP_DIR
cp -rf $_DEBIAN_BUILD_SVC_CFG_DIR/install-ctc-s350.sh $_DEBIAN_PKG_TMP_TOP_DIR

#chmod
chmod 777 $_DEBIAN_PKG_TMP_DIR/etc/*.sh
chmod 777 $_DEBIAN_SCRIPT_TMP_DIR/prepare-s350.sh
chmod 777 $_DEBIAN_SCRIPT_TMP_DIR/start-service.sh
chmod 777 $_DEBIAN_SCRIPT_TMP_DIR/ctc-s350
chmod 777 $_DEBIAN_PKG_TMP_TOP_DIR/install-ctc-s350.sh

#Final Package
rm -rf $_DEBIAN_PACKAGE
tar czvf $_DEBIAN_PACKAGE -C ${_DEBIAN_PKG_TMP_TOP_DIR} . > /dev/null 2>&1
