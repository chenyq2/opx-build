#!/bin/sh
mount -t vfat /dev/$1 /mnt/udisk
sync
