#!/bin/sh
sync
umount /mnt/udisk
