#!/bin/sh

#echo "Syn system time to hardware clock"
/sbin/hwclock --systohc > /dev/null 2>&1

#echo "For safe unmount flash killing some pm before restart"

#killall -9 sh > /dev/null 2>&1
#killall -9 imish > /dev/null 2>&1
killall -q -9 ripd > /dev/null 2>&1
killall -q -9 ripngd > /dev/null 2>&1
killall -q -9 ospfd > /dev/null 2>&1
killall -q -9 ospf6d > /dev/null 2>&1
killall -q -9 mstpd > /dev/null 2>&1
killall -q -9 rmond > /dev/null 2>&1
killall -q -9 pim6d > /dev/null 2>&1
killall -q -9 pimd > /dev/null 2>&1
killall -q -9 bgpd > /dev/null 2>&1
killall -q -9 onmd > /dev/null 2>&1

killall -9 chsm > /dev/null 2>&1 
killall -9 nsm > /dev/null 2>&1      
killall -9 sshd > /dev/null 2>&1     
killall -9 dhcrelay6 > /dev/null 2>&1 
killall -9 dhclient > /dev/null 2>&1 
killall -9 dhcpd6 > /dev/null 2>&1   
killall -9 snmpd > /dev/null 2>&1    
killall -9 imi > /dev/null 2>&1      

#echo "Umount flash before restart"
sync
umount /mnt/flash/boot > /dev/null 2>&1
umount /mnt/flash > /dev/null 2>&1
