#!/bin/bash
#
# Copyright (C) 2004-2014 Centec Networks. All rights reserved.
#
#
set -o errexit

print_usage_and_exit()
{
    echo "Usage: ./bdimg_e350_gbdemo.sh [r|d] "
    echo "       r: release version (default)"
    echo "       d: debug version" 
    exit 1
}

case $# in
0)
    version=r
    ;;
1)
    version=$1
    ;;
*)
    print_usage_and_exit
esac

if [ $version != "d" ] && [ $version != "r" ]; then
    print_usage_and_exit
fi
# Board info
cpu='p1020'
board='gbdemo'
# Generated and export environment variables.
export BASH_ENV_INC="Bash.gbdemo.env.inc"
./createenv.sh $cpu $board $version
source ./${BASH_ENV_INC}


# Compile the source and enjoy it.
make
