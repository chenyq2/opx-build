#!/bin/bash
#
# Copyright (C) 2004-2014 Centec Networks. All rights reserved.
#
#
PROG=`basename $0`
version='r'
debian="n"
rpc_server="y"
export DEBIAN_PACKAGE_NAME=s350-8ts12x

set -o errexit

print_usage_and_exit()
{
    echo "Usage: ./bdimg_s350_8ts12x.sh [OPTION]"
    echo ""
    echo "Available options are listed: " 
    echo "       -r, --release        release version (default)"
    echo "       -d, --debug          debug version"
    echo "       -D, --debian         build Debian package"
    echo "       -h, --help           display this help and exit"
    exit 1
}

ARGS=`getopt  --long help,debug,release,debian --options h,d,r,D --name $PROG -- "$@"`
eval set -- "$ARGS"
while true; do
    case "$1" in
        -h | --help)
            print_usage_and_exit ;;
        -r | --release)
            version=r; shift ;;
        -d | --debug)
            version=d; shift ;;
        -D | --debian)
            debian="y"; shift ;;
        --)
            shift; break;; # end of options
        *)
            print_usage_and_exit ;; 
    esac
done

if [ $version != "d" ] && [ $version != "r" ]; then
    print_usage_and_exit
fi
# Board info
cpu='p1010'
board='8ts12x'
# Generated and export environment variables.
export BASH_ENV_INC="Bash.8ts12x.env.inc"
export ENABLE_S350_FEATURE=y
export ENABLE_DEBIAN_LINUX=$debian
export ENABLE_RPC_SERVER=$rpc_server

./createenv.sh $cpu $board $version
source ./${BASH_ENV_INC}


# Compile the source and enjoy it.
make
