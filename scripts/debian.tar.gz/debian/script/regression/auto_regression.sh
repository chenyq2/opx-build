#!/bin/bash

RUN_DATE=$(date +%Y%m%d_%H%M)
REGRESSION_HOME=~
REGRESSION_LOG_PATH=$REGRESSION_HOME/auto_regression/log
REGRESSION_SCRIPT_PATH=$REGRESSION_HOME/auto_regression/ctc_script/regression
REGRESSION_LOG_FILE=$REGRESSION_LOG_PATH/auto_regression_$RUN_DATE.log
REGRESSION_RESULT_FILE=$REGRESSION_LOG_PATH/auto_regression_result_$RUN_DATE.log 
REGRESSION_MAIL_FILE=$REGRESSION_LOG_PATH/auto_regression_$RUN_DATE.mail
MAIL_SENDER=mail
SENDTO_ADDRESS=yangsj@centecnetworks.com,kcao@centecnetworks.com
CC_ADDRESS=protocol@centecnetworks.com,systest@centecnetworks.com,gu@centecnetworks.com
COMPILE_RESULT=$REGRESSION_HOME/regression/build_out/zebos/uml/Centec_Switch-uml.tar.gz 
RESULT_LINK=http://10.10.25.31/daily_regression/$RUN_DATE.html
echo $RESULT_LINK

# Flags default alue
FLAG_DO_COMPILE="No"

# Define functions.

write_mail()
{
    MAIL_TYPE=$1
    MAIL_FILE=$2
    {
    #echo "MAIL_TYPE=$1, MAIL_FILE=$2"
     echo "MAIL_TYPE=$1"
    if [ "$MAIL_TYPE" != "success" ]; then
	echo "Auto regression test failed." 
	echo "log file path : $REGRESSION_LOG_FILE"
        cat $REGRESSION_HOME/auto_regression/log/temp_result.txt 
    else
	
        echo "Auto regression test success."
	#echo "Result file path: $REGRESSION_RESULT_FILE" 
	#echo "log file path : $REGRESSION_LOG_FILE" 
	cat $REGRESSION_HOME/auto_regression/log/temp_result.txt
        echo "Result Link : $3"
        
    fi
    } > $MAIL_FILE
    return 
}

#
# Send mail
#
send_mail()
{
    mailtype=$1
    msgfile=$2
    cur=`date "+%Y-%m-%d %H:%M:%S"`

    write_mail $mailtype $msgfile $RESULT_LINK 
    if [ "$mailtype" != "success" ]; then
        subject="WARNING: ($HOSTNAME) Auto Regression on UML Error at "$cur
        $MAIL_SENDER -s "$subject"  $SENDTO_ADDRESS < $msgfile
    else
        subject="Notify: ($HOSTNAME) Auto Regression on UML Success at "$cur
        $MAIL_SENDER -s "$subject" -c $CC_ADDRESS $SENDTO_ADDRESS < $msgfile
    fi
    return
}
get_args()
{
    if [ $# -ge 1 ] && [ "$1" == "-c" ]
    then
	FLAG_DO_COMPILE="Yes"
    else
	FLAG_DO_COMPILE="No"
    fi
}
#
# Error check
#
error_check()
{
    retcode="$?"
    msg=$1
    if [ "$retcode" != "0" ]; then
        echo "$msg: fail"
        send_mail "fail" $REGRESSION_MAIL_FILE 
        cd $PWD_DIR
        exit 1
    else
        echo "$msg: success"
    fi
    return
}
rm -f $REGRESSION_LOG_PATH/temp_result.txt
#exec &> $REGRESSION_LOG_FILE
get_args "$@"

# Compile Code
if [ "$FLAG_DO_COMPILE" == "Yes" ]
then
    $SHELL $REGRESSION_SCRIPT_PATH/regression_compile.sh $REGRESSION_LOG_FILE
    error_check "Regression compile"
fi

# Do Compile Success check
if [ ! -e $COMPILE_RESULT ]; then
    echo "NOT Find Compiled out file."
    send_mail "fail" $REGRESSION_MAIL_FILE 
    exit 0
else
    echo "Find compiled Code"
fi
# make the regression case list
expect $REGRESSION_SCRIPT_PATH/tools_total_tsc.tcl > $REGRESSION_LOG_PATH/regression_list_$RUN_DATE.tsc 
# Do regression test
expect $REGRESSION_SCRIPT_PATH/regression_test.tcl $REGRESSION_RESULT_FILE $COMPILE_RESULT $RUN_DATE
error_check "Do regression test"

# Send regression test result mail.
if [ ! -e $REGRESION_RESULT_FILE ]; then
    echo 
    send_mail "fail" $REGRESSION_MAIL_FILE 
    exit 0
else
    echo 
    send_mail "success" $REGRESSION_MAIL_FILE 
fi

echo "Regression succes."
