#!/bin/bash
#
# ==========================================================
# auto_compile.sh:    auto compile shell script
#
#  (C) Copyright Centec Networks Inc.  All rights reserved.
#
# Modify History:
# Revision:  R0.01
# Author  :  Alexander Liu
# Date    :  2006-11-17
# Reason  :  Initialize Version.
#
# Revision:  R0.02
# Author  :  Lin Feng
# Date    :  2006-11-20
# Reason  :  (1) Only check out nessary code
#            (2) Add cvs tag function
#
# Revision:  R0.03
# Author  :  Lin Feng
# Date    :  2006-12-21
# Reason  :  (1) Add release emulation_board version
# ==========================================================
#

#
# Variable Defines: Please define these variables
#
# Set variable to Yes to enable option
#

# cvs root directory
USER_NAME=$(whoami)
USER_HOME=~
export CVSROOT=:pserver:$USER_NAME@10.10.25.11:/data/cvsroot

# source code module
CVS_CHECK_OUT_TAG=
CVS_CHECK_ADD_TAG=

# compile working directory
COMPILE_WORKING_PATH=$USER_HOME/dev/autorel

# option for send fail mail
SEND_FAIL_MAIL=Yes
FAIL_MAILERS=flin@centecnetworks.com

# option for send success mail
SEND_SUCCESS_MAIL=Yes
SUCCESS_MAILERS=flin@centecnetworks.com

#
# ===========================================================
#
# Notes: Please don't change script under this line
#
MAIL_SENDER=mail
DATETIME=`date +%Y-%m-%d`
CO_DIR=$COMPILE_WORKING_PATH
TEMP_DIR=$CO_DIR/tmp
OUTPUT_FILE=$TEMP_DIR"/Release_By_Tag_"$DATETIME".msg"
PWD_DIR=`pwd`
RE_CHECK_OUT="No"
#
# Send mail
#
send_mail()
{
    mailtype=$1
    msgfile=$2
    cur=`date "+%Y-%m-%d %H:%M:%S"`
    if [ "$mailtype" == "fail" ] && [ "$SEND_FAIL_MAIL" != "Yes" ]; then
        echo "Ignore Fail Mail..."
        return
    fi

    if [ "$mailtype" == "success" ] && [ "$SEND_SUCCESS_MAIL" != "Yes" ]; then
        echo "Ignore Success Mail..."
        return
    fi

    if [ "$mailtype" == "fail" ]; then
        subject="WARNING: auto compile error at "$cur
        $MAIL_SENDER -s "$subject" $FAIL_MAILERS < $msgfile
    else
        subject="Notify: auto compile success at "$cur
        $MAIL_SENDER -s "$subject" $SUCCESS_MAILERS < $msgfile
    fi
    return
}

#
# Error check
#
error_check()
{
    retcode="$?"
    msg=$1
    if [ "$retcode" != "0" ]; then
        echo "$msg: fail"
        send_mail "fail" $OUTPUT_FILE
        cd $PWD_DIR
        exit 1
    else
        echo "$msg: success"
    fi
    return
}

#
# Check Argument
#
get_args()
{

    if [ "$1" != "" ]; then
	CVS_CHECK_OUT_TAG=$1
	if [ "$2" != "" ]; then
	    CVS_CHECK_ADD_TAG=$2
	else
	    CVS_CHECK_ADD_TAG=
	fi
	if [ "$3" == "-c" ]; then
	    RE_CHECK_OUT="Yes"
	else
	    RE_CHECK_OUT="No"
	fi
	    
    else
	echo "Useage: $0 cvs_tag [cvs_new_tag] [-c]"
	exit 1
    fi
}

#
# Set Env
#
set_env()
{
#    export CROSS_COMPILE=ppc-linux-
#    export ARCH=ppc
    export PROJECT_ROOT=$CO_DIR
    export ZEBOS=$PROJECT_ROOT/software/Code/Platforms/zebos/
    export DRIVERS=$PROJECT_ROOT/software/Code/Platforms/drivers
    export BLDROOT=$PROJECT_ROOT/software/Code/Build
    export SRCROOT=$PROJECT_ROOT/software/Code
    PATH=$PATH:/sw/qmiao/bin
    PATH=$PROJECT_ROOT/software/script:$PATH
    export PATH

    if [ "$DO_COPY_TO_PUB" != "Yes" ]; then
	RELEASE_PATH_ROOT=$CO_DIR
    fi

    mkdir -p $CO_DIR
    mkdir -p $TEMP_DIR
    error_check "Set env for auto compile"

    rm -fr $OUTPUT_FILE
    return
}

#
# Check out source code from CVS
#
checkout_code()
{
    if [ "$CVS_CHECK_OUT_TAG" == "" ]; then
	exit 1	
    fi

    echo "Do check out cvs tag <$CVS_CHECK_OUT_TAG>" 
    cd $CO_DIR
    # Check out test
    cvs co -r $CVS_CHECK_OUT_TAG software
    error_check "Check out source code"

    cvs co -r $CVS_CHECK_OUT_TAG platform
    error_check "Check out source code"

    cd $PWD_DIR
    echo "Complete check out cvs tag $CVS_CHECK_OUT_TAG." 

    return
}

#
# remove source code
#
remove_code()
{
    echo "Remove old code."
    rm -fr $CO_DIR/software
    rm -fr $CO_DIR/platform
}

#
# cleanup when exists
#
cleanup()
{
    echo "Do finally cleanup ..."
    #remove_code
    #rm -fr $OUTPUT_FILE
    #rm -fr $TMP_VERSION_FILE
    return
}

#
# Add cvs tag to new version
#
cvs_tag_version()
{

    cd $CO_DIR
    release_tag=$CVS_CHECK_ADD_TAG

    if [ "$release_tag" == "" ]; then
	echo "There is NOT new cvs tag"
    else
	echo "cvs tag $release_tag software" 
	cvs tag $release_tag software 
	echo "cvs tag $release_tag platform" 
	cvs tag $release_tag platform
	error_check $ADD_TAG_MSG
    fi

    cd $PWD_DIR
    return
}

#
# Print title
#
print_title()
{
    cd $CO_DIR
    echo "=============Auto release at time "$(date)" ===============" 
    return
}

# setting traps to do cleanup
trap 'cleanup' EXIT
trap 'echo "Command interrupted by user"; exit 1;' SIGINT SIGKILL SIGHUP

#
# do auto compile
#

# setting evn for compile
set_env 
# Check argument 
get_args "$@" 1>>$OUTPUT_FILE 2>&1 

# print title
print_title 1>>$OUTPUT_FILE 2>&1 

if [ $RE_CHECK_OUT == "Yes" ]
then
    # remove old version code
    remove_code 1>>$OUTPUT_FILE 2>&1 

    # check out source code
    checkout_code 1>>$OUTPUT_FILE 2>&1 
fi

# add cvs version tag
cvs_tag_version 1>>$OUTPUT_FILE 2>&1 

# running well, let's send success notify
send_mail "success" $OUTPUT_FILE

echo "Success...." 1>>$OUTPUT_FILE 2>&1 
echo "Success...."
