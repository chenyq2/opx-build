#!/bin/bash
#
# ==========================================================
# auto_compile.sh:    auto compile shell script
#
#  (C) Copyright Centec Networks Inc.  All rights reserved.
#
# Modify History:
# Revision:  R0.01
# Author  :  Lin Feng
# Date    :  2007-01-23
# Reason  :  Create check out and compile script regression .
# ==========================================================
#

#
# Variable Defines: Please define these variables
#
# Set variable to Yes to enable option
#

# cvs root directory
USER_NAME=$(whoami)
USER_HOME=~
export CVSROOT=:pserver:$USER_NAME@10.10.25.11:/data/cvsroot

# source code module
#CVS_MODULE="software"

# compile working directory
COMPILE_WORKING_PATH=$USER_HOME/regression

# release package output directory
DO_COPY_TO_PUB=$1
RELEASE_PATH_ROOT=$USER_HOME/regression/build_out/zebos

# option for increment version number
INCREMENT_VERSION=Yes

# option for check in version number file
DO_CHECKIN=$1
CHECKIN_MSG="Increment version number by auto compile tool"

# option for add cvs version tag
DO_ADD_TAG=$1
ADD_TAG_MSG="Add cvs version tag"

# option for send fail mail
SEND_FAIL_MAIL=Yes
FAIL_MAILERS=flin@centecnetworks.com

# option for send success mail
SEND_SUCCESS_MAIL=Yes
SUCCESS_MAILERS=flin@centecnetworks.com

#
# ===========================================================
#
# Notes: Please don't change script under this line
#
MAIL_SENDER=mail
DATETIME=`date +%Y-%m-%d`
CO_DIR=$COMPILE_WORKING_PATH
TEMP_DIR=$CO_DIR/tmp
OUTPUT_FILE=$TEMP_DIR"/Compile"$DATETIME".msg"
CHECKIN_VERSION_DIR=$CO_DIR"/software"
CHECKIN_VERSION_FILE="Code/Platforms/zebos/lib/version.h"
VERSION_FILE=$CHECKIN_VERSION_DIR"/"$CHECKIN_VERSION_FILE
SCRIPT_DIR=$CO_DIR"/software/script"
PWD_DIR=`pwd`
#COMPILE_SCRIPTS="bdc bdk bdx"
COMPILE_SCRIPTS="bdk bdx"
RELEASE_VERSION="0.0.0.0"
CVS_VERSION_TAG="0-0-0-0"
PRODUCT_NAME="Centec_Switch"
TMP_VERSION_FILE="${TEMP_DIR}/${DATATIME}_TmpVersionFile"

#
# Send mail
#
send_mail()
{
    mailtype=$1
    msgfile=$2
    cur=`date "+%Y-%m-%d %H:%M:%S"`
    if [ "$mailtype" == "fail" ] && [ "$SEND_FAIL_MAIL" != "Yes" ]; then
        echo "Ignore Fail Mail..."
        return
    fi

    if [ "$mailtype" == "success" ] && [ "$SEND_SUCCESS_MAIL" != "Yes" ]; then
        echo "Ignore Success Mail..."
        return
    fi

    if [ "$mailtype" == "fail" ]; then
        subject="WARNING: auto compile error at "$cur
        $MAIL_SENDER -s "$subject" $FAIL_MAILERS < $msgfile
    else
        subject="Notify: auto compile success at "$cur
        $MAIL_SENDER -s "$subject" $SUCCESS_MAILERS < $msgfile
    fi
    return
}

#
# Error check
#
error_check()
{
    retcode="$?"
    msg=$1
    if [ "$retcode" != "0" ]; then
        echo "$msg: fail"
        send_mail "fail" $OUTPUT_FILE
        cd $PWD_DIR
        exit 1
    else
        echo "$msg: success"
    fi
    return
}

#
# Set Env
#
set_env()
{
#    export CROSS_COMPILE=ppc-linux-
#    export ARCH=ppc
    export PROJECT_ROOT=$CO_DIR
    export ZEBOS=$PROJECT_ROOT/software/Code/Platforms/zebos/
    export DRIVERS=$PROJECT_ROOT/software/Code/Platforms/drivers
    export BLDROOT=$PROJECT_ROOT/software/Code/Build
    export SRCROOT=$PROJECT_ROOT/software/Code
    #PATH=$PATH:/sw/qmiao/bin
    PATH=$PROJECT_ROOT/software/script:$PATH
    export PATH

    mkdir -p $CO_DIR
    mkdir -p $TEMP_DIR
    error_check "Set env for auto regression"

    rm -fr $OUTPUT_FILE
    return
}

#
# Check out source code from CVS
#
checkout_code()
{
    cd $CO_DIR

    if [ 1 ]; then
	# Check out test
	cvs co software
    error_check "Check out source code"
	#cvs co platform
    error_check "Check out source code"
    else
	# Not Check out test
	cvs co -l software
	cd software
	cvs co -d script software/script 
	cvs co -l -d Code software/Code

	cd Code
	cvs co -d KAL           software/Code/KAL
	cvs co -d Utility       software/Code/Utility
	cvs co -d TheGrandCanal software/Code/TheGrandCanal
	cvs co -d UI            software/Code/UI
	cvs co -d libasn1       software/Code/libasn1
	cvs co -d ctp	    software/Code/ctp

	cvs co -l -d Platforms  software/Code/Platforms
	cd Platforms
	cvs co -d drivers       software/Code/Platforms/drivers
	cvs co -d lcm_msg       software/Code/Platforms/lcm_msg
	cvs co -d zebos         software/Code/Platforms/zebos 
	cvs co -d applications  software/Code/Platforms/applications
    fi

    error_check "Check out source code"
    cd $PWD_DIR
    return
}

#
# remove source code
#
remove_code()
{
    echo "Remove old code."
    rm -fr $CO_DIR/software
    rm -fr $CO_DIR/platform
    rm -fr $RELEASE_PATH_ROOT
}

#
# cleanup when exists
#
cleanup()
{
    echo "Do finally cleanup ..."
    #remove_code
    #rm -fr $OUTPUT_FILE
    #rm -fr $TMP_VERSION_FILE
    return
}

#
# compile source code
#
compile_code()
{
    echo "Do compile."

    cd $SCRIPT_DIR
    for script in $COMPILE_SCRIPTS; do
        msg="Execute compile script $script"
        sh +x $script 
        error_check "$msg"
    done
    cd $PWD_DIR
    return
}

#
# increment version file
#
increment_version()
{
    echo "Incre version."
    verfile=$VERSION_FILE
    if [ "$INCREMENT_VERSION" != "Yes" ]; then
        echo "Ignore check in version file"
        return;
    fi

    # get product name
    if [ "$DO_COPY_TO_PUB" == "Yes" ]; then
	PRODUCT_NAME=`grep "#define CENTEC_PRODUCT_NAME" $verfile | awk '
	    {
		print substr($3, 2, length($3) - 2);
	    }'`
    else
	PRODUCT_NAME="TempVersion"
    fi
    
    #
    # Format of version number line
    # #define CENTEC_VERSION          "A.B.C.D"
    #
    oldver=`grep "#define CENTEC_VERSION" $verfile | awk '
        {
            print substr($3, 2, length($3) - 2);
        }'`
    newver=`echo $oldver | awk '
        {
            split($0, arr, ".");
            print arr[1]"."arr[2]"."arr[3]"."arr[4] + 1;
        }'`
    RELEASE_VERSION=$newver

    ver_tag=`echo $oldver | awk '
        {
            split($0, arr, ".");
            print arr[1]"-"arr[2]"-"arr[3]"-"arr[4] + 1;
        }'`
    CVS_VERSION_TAG=$ver_tag
    cat $verfile | awk '
        {
            msg=$0
            if (match(msg, "#define CENTEC_VERSION") == 1)
            {
                ver = substr($3, 2, length($3) - 2);
                split(ver, arr, ".");
                print "#define CENTEC_VERSION          \""arr[1]"."arr[2]"."arr[3]"."arr[4] + 1"\"";
            }
            else
            {
                print $0
            }
        }' > $TMP_VERSION_FILE
    cp -fr $TMP_VERSION_FILE $VERSION_FILE
    echo "Increment version from $oldver to $newver"
    return
}

#
# check in version number file
#
checkin_version_file()
{
    cd $CHECKIN_VERSION_DIR
    echo "===================================="
    echo "Version number CVS diff result: "
    cvs diff $CHECKIN_VERSION_FILE 
    echo "===================================="
    if [ "$DO_CHECKIN" != "Yes" ]; then
        echo "Ignore check in version file"
        echo "Ignore cvs ci -m \"$CHECKIN_MSG\" $CHECKIN_VERSION_FILE"
        cd $PWD_DIR
        return
    fi

    echo "cvs ci -m $CHECKIN_MSG $CHECKIN_VERSION_FILE"
    cvs ci -m "$CHECKIN_MSG" $CHECKIN_VERSION_FILE 
    error_check "Check in version file"
    cd $PWD_DIR
    return
}

#
# Add cvs tag to new version
#
cvs_tag_version()
{
    cd $CO_DIR
    release_tag=$PRODUCT_NAME"_"$CVS_VERSION_TAG
    if [ "$DO_ADD_TAG" != "Yes" ]; then
        echo "Ignore cvs tag "$release_tag
    else
        echo "cvs tag $release_tag software" 
        cvs tag $release_tag software 
        cvs tag $release_tag platform
        error_check $ADD_TAG_MSG
    fi

    cd $PWD_DIR
    return
}

#
# make release
#
make_release()
{
    echo "Copy to release dir."
    #RELEASE_PATH=$RELEASE_PATH_ROOT"/uml/"$PRODUCT_NAME"-"$RELEASE_VERSION
    RELEASE_PATH=$RELEASE_PATH_ROOT"/uml"
    mkdir -p $RELEASE_PATH
    error_check "Make release directory"

    releasename=$PRODUCT_NAME"-uml.tar.gz"
    BUILD_OUT_DIR=$SRCROOT"/build.i686.d"
    cd $BUILD_OUT_DIR
    mkdir -p ./zebos/sbin
     
    cp -fr ./etc ./zebos/
    mkdir -p ./zebos/etc/tmp
    cp -fr ./mibs ./zebos/
    cp ./bin/* ./zebos/sbin
    cp ./bin.sw_emu/* ./zebos/sbin 
    tar cvzf $RELEASE_PATH/$releasename zebos
    error_check "Make release"
    cd $PWD_DIR

    # Release emulation board version
    RELEASE_PATH=$RELEASE_PATH_ROOT"/emulation_board"
    mkdir -p $RELEASE_PATH
    error_check "Make release directory"

    releasename=$PRODUCT_NAME"-emu.tar.gz"
    BUILD_OUT_DIR=$SRCROOT"/build.ppc_82xx.d"
    cd $BUILD_OUT_DIR
    mkdir -p ./zebos/sbin
    cp -fr ./etc ./zebos/
    mkdir -p ./zebos/etc/tmp
    cp -fr ./mibs ./zebos/
    cp ./bin/* ./zebos/sbin
    cp ./bin.hw_emu/* ./zebos/sbin 
    tar cvzf $RELEASE_PATH/$releasename zebos
    error_check "Make release"
    cd $PWD_DIR

    return
}

#
# Print title
#
print_title()
{
    cd $CO_DIR
    echo "=============Auto release at time "$(date)" ===============\n" 
    return
}

# setting traps to do cleanup
trap 'cleanup' EXIT
trap 'echo "Command interrupted by user"; exit 1;' SIGINT SIGKILL SIGHUP

#
# do auto compile
#

# setting evn for compile
set_env

# print title
print_title 1>>$OUTPUT_FILE 2>&1 

# remove old version code
remove_code 1>>$OUTPUT_FILE 2>&1 

# check out source code
checkout_code 1>>$OUTPUT_FILE 2>&1 

# do version number increment
#increment_version 1>>$OUTPUT_FILE 2>&1 

# do compile
compile_code 1>>$OUTPUT_FILE 2>&1 

# do release
make_release 1>>$OUTPUT_FILE 2>&1 

# check in version file
#checkin_version_file 1>>$OUTPUT_FILE 2>&1 

# add cvs version tag
#cvs_tag_version 1>>$OUTPUT_FILE 2>&1 

# running well, let's send success notify
send_mail "success" $OUTPUT_FILE

echo "Success...." 1>>$OUTPUT_FILE 2>&1 
echo "Success...."
