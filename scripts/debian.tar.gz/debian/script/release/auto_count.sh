#!/bin/bash
#
# ==========================================================
# auto_count.sh:    auto count software codes
#
#  (C) Copyright Centec Networks Inc.  All rights reserved.
#
# Modify History:
# Revision:  R0.01
# Author  :  Alexander Liu
# Date    :  2007-04-30
# Reason  :  Initialize Version.
#
# ==========================================================
#

#
# Variable Defines: Please define these variables
#
# Set variable to Yes to enable option
#

# cvs root directory
USER_NAME=$(whoami)
USER_HOME=~
export CVSROOT=:pserver:$USER_NAME@10.10.25.11:/data/cvsroot
SVN_TRUNK="http://10.10.25.20/svn/ctcos/trunk"
SVN_TAGS="http://10.10.25.20/svn/ctcos/tags"

# checkout working directory
CHECKOUT_WORKING_PATH=$USER_HOME/.codescount

# option for send fail mail
SEND_FAIL_MAIL=Yes
FAIL_MAILERS=$USER_NAME@centecnetworks.com

# option for send success mail
SEND_SUCCESS_MAIL=Yes
SUCCESS_MAILERS=$USER_NAME@centecnetworks.com

#
# ===========================================================
#
# Notes: Please don't change script under this line
#
MAIL_SENDER=mail
DATETIME=`date +%Y-%m-%d`
CO_DIR=$CHECKOUT_WORKING_PATH
TEMP_DIR=$CO_DIR"/tmp"
SUCCESS_MAIL=$TEMP_DIR"/success.mail"
OUTPUT_FILE=$TEMP_DIR"/codecount"$DATETIME".msg"
ERR_FILE=$OUTPUT_FILE
PWD_DIR=`pwd`
OLD_TAG_STRING=""
NEW_TAG_STRING=""

#
# Usage
#
usage()
{
    echo "Usage: auto_count.sh old_tag_string [new_tag_string]";
    exit 1;
}

#
# Get tags from user
#
if [ $# -eq 1 ]; then
    OLD_TAG_STRING=$1;
elif [ $# -eq 2 ]; then
    OLD_TAG_STRING=$1;
    NEW_TAG_STRING=$2
else
    usage;
    exit 1;
fi

#
# Send mail
#
send_mail()
{
    mailtype=$1
    msgfile=$2
    cur=`date "+%Y-%m-%d %H:%M:%S"`
    if [ "$mailtype" == "fail" ] && [ "$SEND_FAIL_MAIL" != "Yes" ]; then
        echo "Ignore Fail Mail..."
        return
    fi

    if [ "$mailtype" == "success" ] && [ "$SEND_SUCCESS_MAIL" != "Yes" ]; then
        echo "Ignore Success Mail..."
        return
    fi

    if [ "$mailtype" == "fail" ]; then
        subject="WARNING: ($HOSTNAME) auto software code count error at "$cur
        $MAIL_SENDER -s "$subject" $FAIL_MAILERS < $msgfile
    else
        subject="Notify: ($HOSTNAME) auto software code count success at "$cur
        $MAIL_SENDER -s "$subject" $SUCCESS_MAILERS < $msgfile
    fi
    return
}

#
# Error check
#
error_check()
{
    retcode="$?"
    msg=$1
    if [ "$retcode" != "0" ]; then
        echo "$msg: fail"
        send_mail "fail" $ERR_FILE
        cd $PWD_DIR
        exit 1
    else
        echo "$msg: success"
    fi
    return
}

#
# Set Env
#
set_env()
{
    export PROJECT_ROOT=$CO_DIR
    export ZEBOS=$PROJECT_ROOT/software/Code/Platforms/zebos/
    export DRIVERS=$PROJECT_ROOT/software/Code/Platforms/drivers
    export BLDROOT=$PROJECT_ROOT/software/Code/Build
    export SRCROOT=$PROJECT_ROOT/software/Code
    export PLAT_TOP_DIR=$PROJECT_ROOT/platform
    export PPC_KDIR=/sw/pub/release/compile/kernel_build_out/kbuild.ppc
    PATH=$PROJECT_ROOT/software/script:$PATH
    export PATH

    mkdir -p $CO_DIR
    mkdir -p $TEMP_DIR
    error_check "Set env for auto software code count"

    rm -fr $OUTPUT_FILE
    rm -fr $ERR_FILE
    echo "This is log info file." 1> $ERR_FILE
    return
}

#
# Check out source code from CVS
#
checkout_code()
{
    cd $CO_DIR
    MODULES="software/Code/Platforms/zebos/nsm"
    MODULES=$MODULES" software/Code/Platforms/zebos/imi"
    MODULES=$MODULES" software/Code/Platforms/zebos/imish"
    MODULES=$MODULES" software/Code/Platforms/zebos/lib"
    MODULES=$MODULES" software/Code/Platforms/zebos/layer2"
    MODULES=$MODULES" software/Code/Platforms/zebos/platform"
    MODULES=$MODULES" software/Code/Platforms/zebos/ctc"
    MODULES=$MODULES" software/Code/Platforms/zebos/pal"
    MODULES=$MODULES" software/Code/Platforms/zebos/chsm"
    MODULES=$MODULES" software/Code/Platforms/zebos/hal"
    MODULES=$MODULES" software/Code/Platforms/zebos/authd"
    MODULES=$MODULES" software/Code/Platforms/zebos/ldpd"
    MODULES=$MODULES" software/Code/Platforms/zebos/dvmrpd"
    MODULES=$MODULES" software/Code/Platforms/zebos/lacpd"
    MODULES=$MODULES" software/Code/Platforms/zebos/mstpd"
    MODULES=$MODULES" software/Code/Platforms/zebos/ospf6d"
    MODULES=$MODULES" software/Code/Platforms/zebos/ospfd"
    MODULES=$MODULES" software/Code/Platforms/zebos/pimd"
    MODULES=$MODULES" software/Code/Platforms/zebos/ripd"
    MODULES=$MODULES" software/Code/Platforms/zebos/ripngd"
    MODULES=$MODULES" software/Code/Platforms/zebos/stpd"
    MODULES=$MODULES" software/Code/Platforms/zebos/bgpd"
    MODULES=$MODULES" software/Code/Platforms/applications"
    MODULES=$MODULES" software/Code/Platforms/lcmgr"
    MODULES=$MODULES" software/Code/Platforms/lcm_msg"
    MODULES=$MODULES" software/Code/Platforms/drivers/ctc_baymemreg"
    MODULES=$MODULES" software/Code/Platforms/drivers/ctc_cmodel"
    MODULES=$MODULES" software/Code/Platforms/drivers/ctc_hw"
    MODULES=$MODULES" software/Code/Platforms/drivers/fpga"
    MODULES=$MODULES" software/Code/Platforms/drivers/i2c"
    MODULES=$MODULES" software/Code/Platforms/drivers/mdio"
    MODULES=$MODULES" software/Code/TheGrandCanal/CModel"
    MODULES=$MODULES" software/Code/TheGrandCanal/SDK-1.0.0"
    MODULES=$MODULES" software/Code/TheGrandCanal/Diag"
    MODULES=$MODULES" software/Code/KAL"
    MODULES=$MODULES" software/Code/UI/cli"

	# Check out codes
    for mdir in $MODULES; do
        svn co $SVN_TAGS/$OLD_TAG_STRING/$mdir tmpdir/$mdir 1>/dev/null 2>&1
        error_check "Check out source code for old tag: "$OLD_TAG_STRING" "$mdir
    done
    mv $CO_DIR/tmpdir/software $CO_DIR/software_old
    rm -fr $CO_DIR/tmpdir

    for mdir in $MODULES; do
        if [ "$NEW_TAG_STRING" == "" ]; then
            svn co $SVN_TRUNK/$mdir tmpdir/$mdir 1>/dev/null 2>&1
            error_check "Check out source code for new tag: main line "$mdir
        else
            svn co $SVN_TAGS/$NEW_TAG_STRING/$mdir tmpdir/$mdir 1>/dev/null 2>&1
            error_check "Check out source code for new tag: "$NEW_TAG_STRING" "$mdir
        fi
    done
    mv $CO_DIR/tmpdir/software $CO_DIR/software
    rm -fr $CO_DIR/tmpdir

    cd $PWD_DIR
    return
}

#
# remove source code
#
remove_code()
{
    echo "Remove old code."
    rm -fr $CO_DIR/software
    rm -fr $CO_DIR/software_old
    rm -fr $TEMP_DIR/*
}

#
# cleanup when exists
#
cleanup()
{
    echo "Do finally cleanup ..."
    remove_code
    rm -fr $OUTPUT_FILE
    rm -fr $ERR_FILE
    rm -fr $CO_DIR/tmpdir
    rm -fr $TEMP_DIR
    return
}

#
# Print title
#
print_title()
{
    cd $CO_DIR
    echo "=============Auto software code count at time "$(date)" ===============\n" 
    echo "Old tag string: "$OLD_TAG_STRING
    if [ "$NEW_TAG_STRING" != "" ]; then
        echo "New tag string: "$NEW_TAG_STRING
    else
        echo "New tag string: main line"
    fi
    return
}

#
# Write success mail
#
write_success_mail()
{
    FILE_NAME=$1

    echo "Auto software code count success at host $HOSTNAME, on $(date)" > $FILE_NAME
    echo "" >> $FILE_NAME
    echo "Old version is: $OLD_TAG_STRING" >> $FILE_NAME
    if [ "$NEW_TAG_STRING" == "" ]; then
        echo "New version is: main line" >> $FILE_NAME
    else
        echo "New version is: $NEW_TAG_STRING" >> $FILE_NAME
    fi
    echo "" >> $FILE_NAME
    cat $OUTPUT_FILE >> $FILE_NAME
    return;
}

# setting traps to do cleanup
trap 'cleanup' EXIT
trap 'echo "Command interrupted by user"; exit 1;' SIGINT SIGKILL SIGHUP

#
# do auto compile
#

# setting evn for compile
set_env 1>/dev/null

# print title
print_title 1>>$OUTPUT_FILE 2>>$ERR_FILE

# remove old version code
remove_code 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# check out source code
checkout_code 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# do code count
cat /dev/null > $OUTPUT_FILE
cat /dev/null > $ERR_FILE
codecount.pl $CO_DIR/software_old $CO_DIR/software 1>>$OUTPUT_FILE 2>>$ERR_FILE
error_check "Software code count"

# running well, let's send success notify
write_success_mail $SUCCESS_MAIL
send_mail "success" $SUCCESS_MAIL

echo "Success...." 1>>$OUTPUT_FILE 2>>$ERR_FILE 
cleanup
echo "Success...."
