#!/bin/sh 
#
# ==========================================================
# auto_compile.sh:    auto compile shell script
#
#  (C) Copyright Centec Networks Inc.  All rights reserved.
#
# Modify History:
# Revision:  R0.01
# Author  :  Alexander Liu
# Date    :  2006-11-17
# Reason  :  Initialize Version.
#
# Revision:  R0.02
# Author  :  Lin Feng
# Date    :  2006-11-20
# Reason  :  (1) Only check out nessary code
#            (2) Add cvs tag function
#
# Revision:  R0.03
# Author  :  Lin Feng
# Date    :  2006-12-21
# Reason  :  (1) Add release emulation_board version
#
# Revision:  R0.04
# Author  :  Yu Wu
# Date    :  2007-9-20
# Reason  :  (1) Not increase version number automatically.
#            (2) Changing the version format to CISCO style. 
#
# Revision:  R0.05
# Author  :  Kun Cao
# Date    :  2007-11-01
# Reason  :  (1) Change to svn environment
#
# Revision:  R0.06
# Author  :  Xianghong Gu
# Date    :  2010-10-15
# Reason  :  (1) Change for humber system release
# ==========================================================
#
# Internal-1.2.3
# v1.2.alpha3
#
# Check the arguments passed to script.
#

# (1) check the arguments number.
ARGS=2
if [ $# -ne "$ARGS" ]
then 
    echo "usage:    auto_release.sh <Yes|No> <Tag>"
    echo "Yes:      formal release (check version.h and tag)"
    echo "No:       temporary release"
    echo "Tag:      tag name e.g. Internal-1.2.3 for trunk release or v2.1.3.beta3 for branch v2.1 release"
    exit 1
fi

# (2) check the first argument.
DEBUG=$1
if [ $DEBUG == "No" ]
then 
    echo "For pre-release."
elif [ $DEBUG == "Yes" ]
then 
    echo "For official release."
else 
    echo "Please choice Yes or No"
    echo "Yes:      formal release (check version.h and tag)"
    echo "No:       temporary release"
    exit 1
fi

# (3) check the second argument. get the version number.
TAG=$2
TAG_INTERNAL=`expr match "$TAG" '\(v[0-9]*.[0-9]*.[0-9]*.[0-9]*..*\)'`
TAG_CONSUMER=`expr match "$TAG" '\(v[0-9]*.[0-9]*.[0-9]*..*\)'`
if [ $TAG_INTERNAL ]
then 
    mainline=1
    version_tmp=`echo $TAG |sed "s/"v"//g"`
    VERSION_NUM=$version_tmp
    BRANCH_NUM=trunk
    echo "Tag for INTERNAL release is : $TAG_INTERNAL"
    echo "INTERNAL version is : $VERSION_NUM"
elif [ $TAG_CONSUMER ]
then 
    mainline=0
    
    REMARK=`echo $TAG |sed "s/^\(v[0-9]*.[0-9]*.[0-9]*.\)//g"`
    BUILD_NO_AND_REMARK=`echo $TAG |sed "s/^\(v[0-9]*.[0-9]*.\)//g"`
    BRANCH_NUM=`echo $TAG |sed "s/\(.$BUILD_NO_AND_REMARK\)//g"`
    branch=`echo $BRANCH_NUM |sed "s/"_"/"."/g"`
    remark=`echo $REMARK |sed "s/"_"//g"`
    version_tmp=`echo $branch |sed "s/"v"//g"`
    buildno=`echo $BUILD_NO_AND_REMARK |sed "s/\(.$REMARK\)//g"`

    VERSION_NUM=$version_tmp\($buildno\)\,$remark
    echo "Tag for CONSUMER release is: $TAG_CONSUMER"
    echo "Branch for CONSUMER release is: $BRANCH_NUM"

    echo "Remark for CONSUMER release is: $REMARK"
    echo "CONSUMER version is : $VERSION_NUM"
    echo "branch= $branch"
    echo "buildno= $buildno"
    echo "remark= $remark"
    echo "version_tmp= $version_tmp"
else
    echo "Tag format is not correct."
    echo "Tag:      tag name e.g. Internal-1.2.3 for trunk release or v1.2.4.beta3 for branch v1.2 release"
    exit 1
fi

#
# Variable Defines: Please define these variables
#
# Set variable to Yes to enable option
#

# cvs root directory
USER_NAME=$(whoami)
USER_HOME=~
#export CVSROOT=:pserver:$USER_NAME@10.10.25.11:/data/cvsroot

# source code module
#CVS_MODULE="software"

# compile working directory
#COMPILE_WORKING_PATH=$USER_HOME/dev/autorel
COMPILE_WORKING_PATH=$USER_HOME/dev/"$BRANCH_NUM"

# release package output directory
DO_COPY_TO_PUB=$1
RELEASE_PATH_ROOT=/sw/pub/release/centec_switch

# option for increment version number
INCREMENT_VERSION=Yes

# option for check in version number file
DO_CHECKIN=$1
CHECKIN_MSG="Increment version number by auto compile tool"

# option for add svn version tag
DO_ADD_TAG=$1
ADD_TAG_MSG="Add svn version tag"

# option for send fail mail
SEND_FAIL_MAIL=Yes
FAIL_MAILERS=huwx@centecnetworks.com

# option for send success mail
SEND_SUCCESS_MAIL=Yes
SUCCESS_MAILERS=xgu@centecnetworks.com



# ===========================================================
#
# Notes: Please don't change script under this line
#
MAIL_SENDER=mail
DATETIME=`date +%Y-%m-%d`
CO_DIR=$COMPILE_WORKING_PATH
TEMP_DIR=$CO_DIR/tmp
SUCCESS_MAIL=$TEMP_DIR"/success.mail"
OUTPUT_FILE=$TEMP_DIR"/Compile"$DATETIME".msg" 

#ERR_FILE=$TEMP_DIR"/Compile"$DATETIME"_err.msg"
ERR_FILE=$OUTPUT_FILE
CHECKIN_VERSION_DIR=$CO_DIR"/ctcos/code/software"
CHECKIN_VERSION_FILE="zebos/lib/version.h"
VERSION_FILE=$CHECKIN_VERSION_DIR"/"$CHECKIN_VERSION_FILE
SCRIPT_DIR=$CO_DIR"/ctcos/code/script"
PWD_DIR=`pwd`
#COMPILE_SCRIPTS="bdk bdx bdk_rel bdx_rel"
COMPILE_SCRIPTS="cuml.sh"
#####COMPILE_IMAGE_SCRIPTS="$SCRIPT_DIR/release/bdx_image"
#IMAGE_VERSION_STRING="r d"
IMAGE_VERSION_STRING="r"
RELEASE_VERSION="$2"
SVN_VERSION_TAG="$2"
PRODUCT_NAME="centecOS"
TMP_VERSION_FILE="${TEMP_DIR}/${DATATIME}_TmpVersionFile"

#
# Send mail
#
send_mail()
{
    mailtype=$1
    msgfile=$2
    cur=`date "+%Y-%m-%d %H:%M:%S"`
    if [ "$mailtype" == "fail" ] && [ "$SEND_FAIL_MAIL" != "Yes" ]; then
        echo "Ignore Fail Mail..."
        return
    fi

    if [ "$mailtype" == "success" ] && [ "$SEND_SUCCESS_MAIL" != "Yes" ]; then
        echo "Ignore Success Mail..."
        return
    fi

    if [ "$mailtype" == "fail" ]; then
        subject="WARNING: ($HOSTNAME) auto compile error at "$cur
        $MAIL_SENDER -s "$subject" $FAIL_MAILERS < $msgfile
    else
        subject="Notify: ($HOSTNAME) auto compile success at "$cur
        $MAIL_SENDER -s "$subject" $SUCCESS_MAILERS < $msgfile
    fi
    return
}

#
# Error check
#
error_check()
{
    retcode="$?"
    msg=$1
    if [ "$retcode" != "0" ]; then
        echo "$msg: fail"
        send_mail "fail" $ERR_FILE
        cd $PWD_DIR
        exit 1
    else
        echo "$msg: success"
    fi
    return
}

#
# Set Env
#
set_env()
{
#    export CROSS_COMPILE=ppc-linux-
#    export ARCH=ppc
    export PROJECT_ROOT=$CO_DIR/ctcos
    export ZEBOS=$PROJECT_ROOT/code/software/zebos
    export DRIVERS=$PROJECT_ROOT/code/software/drvs
#####    export BLDROOT=$PROJECT_ROOT/software/Code/Build
    export SRCROOT=$PROJECT_ROOT/code/software
    export PLAT_TOP_DIR=$PROJECT_ROOT/code/platform
#####    export PPC_KDIR=/sw/pub/release/compile/kernel_build_out/kbuild.ppc
    echo "SRCROOT set to $SRCROOT"
    echo "PROJECT_ROOT set to $PROJECT_ROOT"
    echo "CO_DIR set to $CO_DIR"
#####   #PATH=$PATH:/sw/qmiao/bin
    PATH=$PROJECT_ROOT/code/script:$PATH
    export PATH
    export BTYPE=pizza_box

    if [ "$DO_COPY_TO_PUB" != "Yes" ]; then
        RELEASE_PATH_ROOT=$CO_DIR
    fi

    mkdir -p $CO_DIR
    mkdir -p $TEMP_DIR
    error_check "Set env for auto compile"

    rm -fr $OUTPUT_FILE
    rm -fr $ERR_FILE
    echo "This is log info file." 1> $ERR_FILE
    return
}

#
# Check out source code from SVN
#
checkout_code()
{
    cd $CO_DIR
    
    if [ 1 ]
    then
        # Check out test
        
        # check out mainline code.
        
        if [ $mainline -eq 1 ]
        then     
            echo "Checkout mainline code"
            
            echo "svn co http://10.10.25.20/svn/ctcos/trunk/"
            svn co http://10.10.25.20/svn/ctcos/trunk ctcos
#####       svn up ctcos/software/Code/Platforms/applications/openssh
            error_check "Check out software. Mainline source code."
        else
            echo "Checkout branch code"
            echo "svn co http://10.10.25.20/svn/ctcos/branches/$BRANCH_NUM"
	    svn co http://10.10.25.20/svn/ctcos/branches/$BRANCH_NUM ctcos
            svn up ctcos/software/Code/Platforms/applications/openssh
            error_check "Check out software. Branch $BRANCH_NUM source code."
        fi

    else
        # Not Check out test
        cvs co -l software
        cd software
        cvs co -d script software/script 
        cvs co -l -d Code software/Code
        
        cd Code
        cvs co -d KAL           software/Code/KAL
        cvs co -d Utility       software/Code/Utility
        cvs co -d TheGrandCanal software/Code/TheGrandCanal
        cvs co -d UI            software/Code/UI
        cvs co -d libasn1       software/Code/libasn1
        cvs co -d ctp	    software/Code/ctp
        
        cvs co -l -d Platforms  software/Code/Platforms
        cd Platforms
        cvs co -d drivers       software/Code/Platforms/drivers
        cvs co -d lcm_msg       software/Code/Platforms/lcm_msg
        cvs co -d zebos         software/Code/Platforms/zebos 
        cvs co -d applications  software/Code/Platforms/applications
    fi
        
    error_check "Check out source code"
    cd $PWD_DIR
    return
}

#
# remove source code
#
remove_code()
{
    echo "Remove old code."
    rm -fr $CO_DIR/ctcos
}

#
# cleanup when exists
#
cleanup()
{
    echo "Do finally cleanup ..."
    #remove_code
    #rm -fr $OUTPUT_FILE
    #rm -fr $TMP_VERSION_FILE
    return
}

######
###### compile image code
######
#####compile_image()
#####{
#####    echo "Do image compile."
#####
#####    cd "$SCRIPT_DIR/release"
#####    for version in $IMAGE_VERSION_STRING; do
#####        echo $(pwd)
#####        echo $script
#####        msg="Execute image compile script $script"
#####        sh +x $COMPILE_IMAGE_SCRIPTS -$version
#####        echo "$script end"
#####        error_check "$msg"
#####    done
#####    
#####    cd $PWD_DIR
#####    return
#####}

#
# compile source code
#
compile_code()
{
    echo "Do compile."

    cd $SCRIPT_DIR
    for script in $COMPILE_SCRIPTS; do
        msg="Execute compile script $script"
        sh +x $script 
        error_check "$msg"
    done
    
    cd $PWD_DIR
    return
}

#
# increment version file
#
increment_version()
{
    echo "Incre version."
    verfile=$VERSION_FILE
    if [ "$INCREMENT_VERSION" != "Yes" ]; then
        echo "Ignore check in version file"
        return;
    fi

    newver=$VERSION_NUM

    # Change the macro in version file.
    
    if [ $mainline -eq 1 ]
    then
        cat $verfile | awk '
            {
                msg=$0
                if (match(msg, "#define CENTEC_VERSION ") == 1)
                {
                    ver = "'$newver'";
                    print "#define CENTEC_VERSION          \""ver"\"";
                }
                else
                {
                    print $0
                }
            }' > $TMP_VERSION_FILE
     else 
         cat $verfile | awk '
            {
                msg=$0
                if (match(msg, "#define CENTEC_VERSION ") == 1)
                {
                    ver = "'$newver'";
                    split(ver, arr, ",");
                    print "#define CENTEC_VERSION          \""arr[1]",\ "arr[2]"\"";
                }
                else
                {
                    print $0
                }
            }' > $TMP_VERSION_FILE
         fi
    
    cp -fr $TMP_VERSION_FILE $VERSION_FILE
      
    echo "Increment version from $oldver to $newver"
    return
}

#
# check in version number file
#
checkin_version_file()
{
    cd $CHECKIN_VERSION_DIR
    echo "===================================="
    echo "Version number CVS diff result: "
    cvs diff $CHECKIN_VERSION_FILE 
    echo "===================================="
    if [ "$DO_CHECKIN" != "Yes" ]; then
        echo "Ignore check in version file"
        echo "Ignore svn ci -m \"$CHECKIN_MSG\" $CHECKIN_VERSION_FILE"
        cd $PWD_DIR
        return
    fi

    echo "svn ci -m $CHECKIN_MSG $CHECKIN_VERSION_FILE"
    svn ci -m "$CHECKIN_MSG" $CHECKIN_VERSION_FILE 
    error_check "Check in version file"
    cd $PWD_DIR
    return
}

#
# Add cvs tag to new version
#
svn_tag_version()
{
    cd $CO_DIR
    release_tag=$SVN_VERSION_TAG
    if [ "$DO_ADD_TAG" != "Yes" ]; then
        echo "Ignore svn tag "$release_tag
    else
#####1. Tag code version    
        echo "svn tag $release_tag ctcos" 
        echo "svn copy ctcos http://10.10.25.20/svn/ctcos/tags/$release_tag"
        svn copy ctcos http://10.10.25.20/svn/ctcos/tags/$release_tag -m "Tag version $release_tag by auto compile tool"
        error_check $ADD_TAG_MSG
#####2. Tag document version
        echo "svn tag document $release_tag ctcos" 
        echo "svn copy http://10.10.25.20/svn/system_docs/trunk/project/01_humber_system/ http://10.10.25.20/svn/system_docs/tags/$release_tag"
        svn copy http://10.10.25.20/svn/system_docs/trunk/project/01_humber_system/ http://10.10.25.20/svn/system_docs/tags/$release_tag -m"Tag version $release_tag by auto compile tool"
    fi

    cd $PWD_DIR
    return
}

#
# make uml release, copy uml image to release dir
#
make_release()
{
    echo "Copy to release dir."
    # Release uml environment version
    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/uml"
    mkdir -p $RELEASE_PATH
    error_check "Make release directory"

    releasename=$PRODUCT_NAME"-"$RELEASE_VERSION"-uml.tar.gz"
    BUILD_OUT_DIR=$SRCROOT"/../../"
    cd $BUILD_OUT_DIR
#####    mkdir -p ./zebos/sbin
#####     
#####    cp -fr ./etc ./zebos/
#####    mkdir -p ./zebos/etc/tmp
#####    cp -fr ./mibs ./zebos/
#####    cp ./bin/* ./zebos/sbin
#####    cp ./bin.tmp/* ./zebos/sbin 
#####    cp -rf ./lib ./zebos/
    tar cvzf $RELEASE_PATH/$releasename umlimage
    error_check "Make release"
    cd $PWD_DIR

    # Release emulation board version
    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/emulation_board"
    mkdir -p $RELEASE_PATH
    error_check "Make release directory"

    ### need copy to release after bdimg.sh
    #releasename=$PRODUCT_NAME"-"$RELEASE_VERSION"-emu.tar.gz"
    #BUILD_OUT_DIR=$SRCROOT"/build.ppc_82xx.d"
    #cd $BUILD_OUT_DIR
    #mkdir -p ./zebos/sbin
    #cp -fr ./etc ./zebos/
    #mkdir -p ./zebos/etc/tmp
    #cp -fr ./mibs ./zebos/
    #cp ./bin/* ./zebos/sbin
    #cp ./bin.emu_svc/* ./zebos/sbin 
    #tar cvzf $RELEASE_PATH/$releasename zebos
    #error_check "Make release"
    #cd $PWD_DIR

    return
}

######
###### release emulation board image
######
#####release_image()
#####{
#####    echo "Copy image to release dir."
#####    # Release emulation board version
#####    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/emulation_board/image"
#####    echo $RELEASE_PATH
#####    mkdir -p $RELEASE_PATH
#####    error_check "Make image release directory"
#####    
#####    for version in $IMAGE_VERSION_STRING; do
#####        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-"$RELEASE_VERSION"-emu.uImage.emu_svc.$version"
#####        BUILD_OUT_DIR="$PLAT_TOP_DIR/build_svc"
#####        echo "BD = $BUILD_OUT_DIR releas= $releasename"
#####        cd $BUILD_OUT_DIR
#####        cp -f ./uImage.emu_svc.$version  $releasename
#####    done
#####
#####    error_check "Make image release"
#####    cd $PWD_DIR
#####
#####    return
#####}

######
###### build boot image
######
#####build_boot_image()
#####{
#####    echo "Build boot image."
#####
#####    # Release emulation board version
#####    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/emulation_board/image"
#####    echo $RELEASE_PATH
#####    
#####    mkdir -p $RELEASE_PATH
#####
#####    for version in $IMAGE_VERSION_STRING; do
#####    releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-"$RELEASE_VERSION"-uImage.emu_svc.$version"
#####    echo "BD = $CO_DIR/ctcos/software/script/bdimg.sh emu_svc $version"
#####    $CO_DIR/ctcos/software/script/bdimg.sh emu_svc $version
#####    echo "copy to $releasename"
#####    cp -f $CO_DIR/ctcos/platform/build_svc/uImage.emu_svc.$version $releasename
#####    echo "cp -f $CO_DIR/ctcos/platform/build_svc/uImage.emu_svc.$version $releasename"
#####    echo "finish Build $releasename"
#####    ### copy and tar binary files 
#####    releasename=$PRODUCT_NAME"-"$RELEASE_VERSION"-emu_svc.$version.tar.gz"
#####    BUILD_OUT_DIR=$SRCROOT"/build.ppc_82xx.$version"
#####    cd $BUILD_OUT_DIR
#####    mkdir -p ./zebos/sbin
#####    cp -fr ./etc ./zebos/
#####    mkdir -p ./zebos/etc/tmp
#####    cp -fr ./mibs ./zebos/
#####    cp ./bin/* ./zebos/sbin
#####    cp ./bin.emu_svc/* ./zebos/sbin 
#####    cp ./lib/libzos.so ./zebos/sbin
#####    tar cvzf $RELEASE_PATH/../$releasename zebos
#####    error_check "Copy the symbol of emu_svc.$version"
#####    cd $PWD_DIR
#####    done
#####
#####    error_check "Make emulation image release"
#####    cd $PWD_DIR
#####
#####    return
#####}

build_ppc_image()
{
    echo "Build e330 ppc image."

    # Release humber demo board version
    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/pizza_box/image"
    echo $RELEASE_PATH
    
    mkdir -p $RELEASE_PATH
    BUILD_OUT_IMG_DIR=$CO_DIR/ctcos/code/platform/build_svc
    BUILD_IMG_MID_STR=hw_pizza_box
    for version in $IMAGE_VERSION_STRING; do
        echo "BD = $CO_DIR/ctcos/code/script/bdimg.sh -i pizza_box $version"
        $CO_DIR/ctcos/code/script/bdimg.sh -i p $version
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-ppc-eb-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_eb.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_eb.$BUILD_IMG_MID_STR.$version $releasename"
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-ppc-es-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_es.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_es.$BUILD_IMG_MID_STR.$version $releasename"
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-ppc-ea-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_ea.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_ea.$BUILD_IMG_MID_STR.$version $releasename"
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-ppc-mb-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_mb.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_mb.$BUILD_IMG_MID_STR.$version $releasename"
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-ppc-ms-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_ms.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_ms.$BUILD_IMG_MID_STR.$version $releasename"
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-ppc-ma-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_ma.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_ma.$BUILD_IMG_MID_STR.$version $releasename"
        
        echo "finish Build $releasename"
        ### copy and tar binary files 
        releasename=$PRODUCT_NAME"-"$RELEASE_VERSION"-ppc.$version.tar.gz"
        BUILD_OUT_DIR=$SRCROOT"/../../out/$BTYPE/build.ppc_82xx.$version"
        cd $BUILD_OUT_DIR
        mkdir -p ./zebos/sbin
        cp -fr ./etc ./zebos/
        mkdir -p ./zebos/etc/tmp
        cp -fr ./mibs ./zebos/
        cp ./bin/* ./zebos/sbin
        cp ./bin.hw_pizza_box/* ./zebos/sbin 
        cp ./lib/* ./zebos/sbin
        tar cvzf $RELEASE_PATH/../$releasename zebos
        error_check "Copy the symbol of ppc.$version"
        cd $PWD_DIR
    done

    error_check "Make E330 ppc image release"
    cd $PWD_DIR
    return
}



build_oct_image()
{
    echo "Build e330 oct image."

    # Release e300 board version
    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/pizza_box/image"
    echo $RELEASE_PATH
    
    mkdir -p $RELEASE_PATH
    BUILD_OUT_IMG_DIR=$CO_DIR/ctcos/code/platform/build_svc
    BUILD_IMG_MID_STR=oct.hw_pizza_box
    for version in $IMAGE_VERSION_STRING; do
        echo "BD = $CO_DIR/ctcos/code/script/bdimg_octeon.sh -i pizza_box $version"
        $CO_DIR/ctcos/code/script/bdimg_octeon.sh -i p $version
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-oct-eb-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_eb.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_eb.$BUILD_IMG_MID_STR.$version $releasename"
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-oct-es-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_es.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_es.$BUILD_IMG_MID_STR.$version $releasename"
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-oct-ea-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_ea.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_ea.$BUILD_IMG_MID_STR.$version $releasename"
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-oct-mb-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_mb.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_mb.$BUILD_IMG_MID_STR.$version $releasename"
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-oct-ms-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_ms.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_ms.$BUILD_IMG_MID_STR.$version $releasename"
        
        releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-oct-ma-"$RELEASE_VERSION".$version.bin"
        cp -f $BUILD_OUT_IMG_DIR/uImage_ma.$BUILD_IMG_MID_STR.$version $releasename
        echo "cp -f $BUILD_OUT_IMG_DIR/uImage_ma.$BUILD_IMG_MID_STR.$version $releasename"
        
        echo "finish Build $releasename"
        ### copy and tar binary files 
        releasename=$PRODUCT_NAME"-"$RELEASE_VERSION"-oct.$version.tar.gz"
        BUILD_OUT_DIR=$SRCROOT"/../../out/$BTYPE/build.octeon.$version"
        cd $BUILD_OUT_DIR
        mkdir -p ./zebos/sbin
        cp -fr ./etc ./zebos/
        mkdir -p ./zebos/etc/tmp
        cp -fr ./mibs ./zebos/
        cp ./bin/* ./zebos/sbin
        cp ./bin.hw_pizza_box/* ./zebos/sbin 
        cp ./lib/* ./zebos/sbin
        tar cvzf $RELEASE_PATH/../$releasename zebos
        error_check "Copy the symbol of e330.oct.$version"
        cd $PWD_DIR
    done

    error_check "Make E330 oct image release"
    cd $PWD_DIR
    return
}

#build_e600_image()
#{
#    echo "Build e600 image."
#
#    # Release e600 board version
#    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/e600/image"
#    echo $RELEASE_PATH
#
#    mkdir -p $RELEASE_PATH
#
#    for version in $IMAGE_VERSION_STRING; do
#    releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-"$RELEASE_VERSION"-e600.$version.bin"
#    echo "BD = $CO_DIR/ctcos/software/script/bdimg.sh atca_svc $version"
#    $CO_DIR/ctcos/software/script/bdimg.sh atca_svc $version
#    
#    releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-e600-eb-"$RELEASE_VERSION".$version.bin"
#    cp -f $CO_DIR/ctcos/platform/build_svc/uImage_eb.atca_svc.$version $releasename
#    echo "cp -f $CO_DIR/ctcos/platform/build_svc/uImage_eb.atca_svc.$version $releasename"
#
#    releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-e600-es-"$RELEASE_VERSION".$version.bin"
#    cp -f $CO_DIR/ctcos/platform/build_svc/uImage_es.atca_svc.$version $releasename
#    echo "cp -f $CO_DIR/ctcos/platform/build_svc/uImage_es.atca_svc.$version $releasename"
#
#    releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-e600-ea-"$RELEASE_VERSION".$version.bin"
#    cp -f $CO_DIR/ctcos/platform/build_svc/uImage_ea.atca_svc.$version $releasename
#    echo "cp -f $CO_DIR/ctcos/platform/build_svc/uImage_ea.atca_svc.$version $releasename"
#
#    releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-e600-mb-"$RELEASE_VERSION".$version.bin"
#    cp -f $CO_DIR/ctcos/platform/build_svc/uImage_mb.atca_svc.$version $releasename
#    echo "cp -f $CO_DIR/ctcos/platform/build_svc/uImage_mb.atca_svc.$version $releasename"
#
#    releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-e600-ms-"$RELEASE_VERSION".$version.bin"
#    cp -f $CO_DIR/ctcos/platform/build_svc/uImage_ms.atca_svc.$version $releasename
#    echo "cp -f $CO_DIR/ctcos/platform/build_svc/uImage_ms.atca_svc.$version $releasename"
#
#    releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-e600-ma-"$RELEASE_VERSION".$version.bin"
#    cp -f $CO_DIR/ctcos/platform/build_svc/uImage_ma.atca_svc.$version $releasename
#    echo "cp -f $CO_DIR/ctcos/platform/build_svc/uImage_ma.atca_svc.$version $releasename"
#
#    echo "finish Build $releasename"
#    ### copy and tar binary files 
#    releasename=$PRODUCT_NAME"-e600-"$RELEASE_VERSION".$version.tar.gz"
#    BUILD_OUT_DIR=$SRCROOT"/build.ppc_82xx.$version"
#    cd $BUILD_OUT_DIR
#    mkdir -p ./zebos/sbin
#    cp -fr ./etc ./zebos/
#    mkdir -p ./zebos/etc/tmp
#    cp -fr ./mibs ./zebos/
#    cp ./bin/* ./zebos/sbin
#    cp ./bin.atca_svc/* ./zebos/sbin
#    cp ./lib/libzos.so ./zebos/sbin
#    rm -rf bin
#    rm -rf bin.pizza_box
#    rm -rf lib
#    tar cvzf $RELEASE_PATH/../$releasename zebos
#    error_check "Copy the symbol of e600.$version"
#    cd $PWD_DIR
#    done
#
#    error_check "Make E600 image release"
#    cd $PWD_DIR
#    return
#}

#
# Print title
#
print_title()
{
    cd $CO_DIR
    echo "=============Auto release at time "$(date)" ===============\n" 
    return
}

#
# Write success mail
#
write_success_mail()
{
    FILE_NAME=$1

    echo "Compile success at host $HOSTNAME, on $(date)\n" > $FILE_NAME
    echo "New version is : $RELEASE_VERSION" >> $FILE_NAME
}

#
#build mib file
#
build_mib_file()
{
        echo "Build mib file."
        
        RELEASE_PATH="$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/
        echo $RELEASE_PATH
    
    mkdir -p $RELEASE_PATH
        
        release_mib_file="$PRODUCT_NAME"-mib-"$RELEASE_VERSION"
    echo "mib file name $RELEASE_PATH $release_mib_file"
    mkdir -p $release_mib_file
    cp -fr "$CO_DIR"/ctcos/code/software/apps/net-snmp/mibs/ctc_private_mibs $release_mib_file
    cp -fr "$CO_DIR"/ctcos/code/software/apps/net-snmp/mibs/ctc_public_mibs $release_mib_file
    rm -fr "$release_mib_file"/*/.svn
    tar -zcvf "$release_mib_file".tar.gz $release_mib_file
    rm -fr $release_mib_file
    
    #cp mib file to release PATH
        mv "$release_mib_file".tar.gz $RELEASE_PATH
}

# setting traps to do cleanup
trap 'cleanup' EXIT
trap 'echo "Command interrupted by user"; exit 1;' SIGINT SIGKILL SIGHUP

#
# do auto compile
#

# setting evn for compile
set_env 

# print title
print_title 1>>$OUTPUT_FILE 2>>$ERR_FILE

# remove old version code
#remove_code 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# check out source code
#checkout_code 1>>$OUTPUT_FILE 2>>$ERR_FILE 

#release MIB file                           
build_mib_file 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# do version number increment
increment_version 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# do build e330 ppc image
build_ppc_image 1>>$OUTPUT_FILE 2>>$ERR_FILE

# do build e330 oct image
#build_oct_image 1>>$OUTPUT_FILE 2>>$ERR_FILE

# do build e600 image
##### build_e600_image 1>>$OUTPUT_FILE 2>>$ERR_FILE

# do compile
compile_code 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# make uml release, copy uml image to release dir
make_release 1>>$OUTPUT_FILE 2>>$ERR_FILE 

###### do build boot image
######build_boot_image 1>>$OUTPUT_FILE 2>>$ERR_FILE
#####
###### compile image 
######compile_image 1>>$OUTPUT_FILE 2>>$ERR_FILE   
#####
###### cp image to release dir
######release_image 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# check in version file
checkin_version_file 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# add cvs version tag
svn_tag_version 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# running well, let's send success notify
#send_mail "success" $OUTPUT_FILE
write_success_mail $SUCCESS_MAIL
send_mail "success" $SUCCESS_MAIL

echo "Success...." 1>>$OUTPUT_FILE 2>>$ERR_FILE 
echo "Success...."
