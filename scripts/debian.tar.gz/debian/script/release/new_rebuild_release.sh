#!/bin/bash
#
# ==========================================================
# auto_compile.sh:    auto compile shell script
#
#  (C) Copyright Centec Networks Inc.  All rights reserved.
#
# Modify History:
# Revision:  R0.01
# Author  :  Alexander Liu
# Date    :  2006-11-17
# Reason  :  Initialize Version.
#
# Revision:  R0.02
# Author  :  Lin Feng
# Date    :  2006-11-20
# Reason  :  (1) Only check out nessary code
#            (2) Add cvs tag function
#
# Revision:  R0.03
# Author  :  Lin Feng
# Date    :  2006-12-21
# Reason  :  (1) Add release emulation_board version
# ==========================================================
#

#
# Variable Defines: Please define these variables
#
# Set variable to Yes to enable option
#

# cvs root directory
USER_NAME=$(whoami)
USER_HOME=~
export CVSROOT=:pserver:$USER_NAME@10.10.25.11:/data/cvsroot

# source code module
#CVS_MODULE="software"

# compile working directory
COMPILE_WORKING_PATH=$USER_HOME/dev/autorel

# release package output directory
DO_COPY_TO_PUB=$1
RELEASE_PATH_ROOT=/sw/pub/release/centec_switch

# option for increment version number
INCREMENT_VERSION=Yes

# option for check in version number file
DO_CHECKIN=$1
CHECKIN_MSG="Increment version number by auto compile tool"

# option for add cvs version tag
DO_ADD_TAG=$1
ADD_TAG_MSG="Add cvs version tag"

# option for send fail mail
SEND_FAIL_MAIL=Yes
FAIL_MAILERS=kcao@centecnetworks.com

# option for send success mail
SEND_SUCCESS_MAIL=Yes
SUCCESS_MAILERS=kcao@centecnetworks.com
#
# ===========================================================
#
# Notes: Please don't change script under this line
#
MAIL_SENDER=mail
DATETIME=`date +%Y-%m-%d`
CO_DIR=$COMPILE_WORKING_PATH
TEMP_DIR=$CO_DIR/tmp
SUCCESS_MAIL=$TEMP_DIR"/success.mail"
OUTPUT_FILE=$TEMP_DIR"/Compile"$DATETIME".msg"
#ERR_FILE=$TEMP_DIR"/Compile"$DATETIME"_err.msg"
ERR_FILE=$OUTPUT_FILE
CHECKIN_VERSION_DIR=$CO_DIR"/software"
CHECKIN_VERSION_FILE="Code/Platforms/zebos/lib/version.h"
VERSION_FILE=$CHECKIN_VERSION_DIR"/"$CHECKIN_VERSION_FILE
SCRIPT_DIR=$CO_DIR"/software/script"
PWD_DIR=`pwd`
#COMPILE_SCRIPTS="bdk bdx bdk_rel bdx_rel"
COMPILE_SCRIPTS="bdk bdk_rel"
COMPILE_IMAGE_SCRIPTS="$SCRIPT_DIR/release/bdx_image"
IMAGE_VERSION_STRING="d r"
RELEASE_VERSION="0.0.0.0"
CVS_VERSION_TAG="0-0-0-0"
PRODUCT_NAME="Centec"
TMP_VERSION_FILE="${TEMP_DIR}/${DATATIME}_TmpVersionFile"

#
# Send mail
#
send_mail()
{
    mailtype=$1
    msgfile=$2
    cur=`date "+%Y-%m-%d %H:%M:%S"`
    if [ "$mailtype" == "fail" ] && [ "$SEND_FAIL_MAIL" != "Yes" ]; then
        echo "Ignore Fail Mail..."
        return
    fi

    if [ "$mailtype" == "success" ] && [ "$SEND_SUCCESS_MAIL" != "Yes" ]; then
        echo "Ignore Success Mail..."
        return
    fi

    if [ "$mailtype" == "fail" ]; then
        subject="WARNING: ($HOSTNAME) auto compile error at "$cur
        $MAIL_SENDER -s "$subject" $FAIL_MAILERS < $msgfile
    else
        subject="Notify: ($HOSTNAME) auto compile success at "$cur
        $MAIL_SENDER -s "$subject" $SUCCESS_MAILERS < $msgfile
    fi
    return
}

#
# Error check
#
error_check()
{
    retcode="$?"
    msg=$1
    if [ "$retcode" != "0" ]; then
        echo "$msg: fail"
        send_mail "fail" $ERR_FILE
        cd $PWD_DIR
        exit 1
    else
        echo "$msg: success"
    fi
    return
}

#
# Set Env
#
set_env()
{
#    export CROSS_COMPILE=ppc-linux-
#    export ARCH=ppc
    export PROJECT_ROOT=$CO_DIR
    export ZEBOS=$PROJECT_ROOT/software/Code/Platforms/zebos/
    export DRIVERS=$PROJECT_ROOT/software/Code/Platforms/drivers
    export BLDROOT=$PROJECT_ROOT/software/Code/Build
    export SRCROOT=$PROJECT_ROOT/software/Code
    export PLAT_TOP_DIR=$PROJECT_ROOT/platform
    export PPC_KDIR=/sw/pub/release/compile/kernel_build_out/kbuild.ppc
    #PATH=$PATH:/sw/qmiao/bin
    PATH=$PROJECT_ROOT/software/script:$PATH
    export PATH

    if [ "$DO_COPY_TO_PUB" != "Yes" ]; then
	RELEASE_PATH_ROOT=$CO_DIR
    fi

    mkdir -p $CO_DIR
    mkdir -p $TEMP_DIR
    error_check "Set env for auto compile"

    rm -fr $OUTPUT_FILE
    rm -fr $ERR_FILE
    echo "This is log info file." 1> $ERR_FILE
    return
}

#
# Check out source code from CVS
#
checkout_code()
{
    cd $CO_DIR

    if [ 1 ]; then
	# Check out test
	cvs co platform
    error_check "Check out source code"

	cvs co software
    error_check "Check out source code"

    else
	# Not Check out test
	cvs co -l software
	cd software
	cvs co -d script software/script 
	cvs co -l -d Code software/Code

	cd Code
	cvs co -d KAL           software/Code/KAL
	cvs co -d Utility       software/Code/Utility
	cvs co -d TheGrandCanal software/Code/TheGrandCanal
	cvs co -d UI            software/Code/UI
	cvs co -d libasn1       software/Code/libasn1
	cvs co -d ctp	    software/Code/ctp

	cvs co -l -d Platforms  software/Code/Platforms
	cd Platforms
	cvs co -d drivers       software/Code/Platforms/drivers
	cvs co -d lcm_msg       software/Code/Platforms/lcm_msg
	cvs co -d zebos         software/Code/Platforms/zebos 
	cvs co -d applications  software/Code/Platforms/applications
    fi

    error_check "Check out source code"
    cd $PWD_DIR
    return
}

#
# remove source code
#
remove_code()
{
    echo "Remove old code."
    rm -fr $CO_DIR/software
    rm -fr $CO_DIR/platform
}

#
# cleanup when exists
#
cleanup()
{
    echo "Do finally cleanup ..."
    #remove_code
    #rm -fr $OUTPUT_FILE
    #rm -fr $TMP_VERSION_FILE
    return
}

#
# compile image code
#
compile_image()
{
    echo "Do image compile."

    cd "$SCRIPT_DIR/release"
    for version in $IMAGE_VERSION_STRING; do
	echo $(pwd)
	echo $script
        msg="Execute image compile script $script"
        sh +x $COMPILE_IMAGE_SCRIPTS -$version
	echo "$script end"
        error_check "$msg"
    done
    cd $PWD_DIR
    return
}

#
# compile source code
#
compile_code()
{
    echo "Do compile."

    cd $SCRIPT_DIR
    for script in $COMPILE_SCRIPTS; do
        msg="Execute compile script $script"
        sh +x $script 
        error_check "$msg"
    done
    cd $PWD_DIR
    return
}

#
# increment version file
#
increment_version()
{
    echo "Incre version."
    verfile=$VERSION_FILE
    if [ "$INCREMENT_VERSION" != "Yes" ]; then
        echo "Ignore check in version file"
        return;
    fi

    # get product name
    if [ "$DO_COPY_TO_PUB" == "Yes" ]; then
	PRODUCT_NAME=`grep "#define CENTEC_VERSION_TYPE" $verfile | awk '
	    {
		print substr($3, 2, length($3) - 2);
	    }'`
    else
	PRODUCT_NAME="TempVersion"
    fi
    
    #
    # Format of version number line
    # #define CENTEC_VERSION          "A.B.C.D"
    #
    oldver=`grep "#define CENTEC_VERSION " $verfile | awk '
        {
            print substr($3, 2, length($3) - 2);
        }'`
    RELEASE_VERSION=$oldver

    return
}

#
# check in version number file
#
checkin_version_file()
{
    cd $CHECKIN_VERSION_DIR
    echo "===================================="
    echo "Version number CVS diff result: "
    cvs diff $CHECKIN_VERSION_FILE 
    echo "===================================="
    if [ "$DO_CHECKIN" != "Yes" ]; then
        echo "Ignore check in version file"
        echo "Ignore cvs ci -m \"$CHECKIN_MSG\" $CHECKIN_VERSION_FILE"
        cd $PWD_DIR
        return
    fi

    echo "cvs ci -m $CHECKIN_MSG $CHECKIN_VERSION_FILE"
    cvs ci -m "$CHECKIN_MSG" $CHECKIN_VERSION_FILE 
    error_check "Check in version file"
    cd $PWD_DIR
    return
}

#
# Add cvs tag to new version
#
cvs_tag_version()
{
    cd $CO_DIR
    release_tag=$PRODUCT_NAME"_"$CVS_VERSION_TAG
    if [ "$DO_ADD_TAG" != "Yes" ]; then
        echo "Ignore cvs tag "$release_tag
    else
        echo "cvs tag $release_tag software" 
        cvs tag $release_tag software 
        cvs tag $release_tag platform
        error_check $ADD_TAG_MSG
    fi

    cd $PWD_DIR
    return
}

#
# make release
#
make_release()
{
    echo "Copy to release dir."
    # Release uml environment version
    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/uml"
    mkdir -p $RELEASE_PATH
    error_check "Make release directory"

    releasename=$PRODUCT_NAME"-"$RELEASE_VERSION"-uml.tar.gz"
    BUILD_OUT_DIR=$SRCROOT"/build.i686.d"
    cd $BUILD_OUT_DIR
    mkdir -p ./zebos/sbin
     
    cp -fr ./etc ./zebos/
    mkdir -p ./zebos/etc/tmp
    cp -fr ./mibs ./zebos/
    cp ./bin/* ./zebos/sbin
    cp ./bin.sw_emu/* ./zebos/sbin 
    tar cvzf $RELEASE_PATH/$releasename zebos
    error_check "Make release"
    cd $PWD_DIR

#    # Release emulation board version
#    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/emulation_board"
#    mkdir -p $RELEASE_PATH
#    error_check "Make release directory"
#
#    releasename=$PRODUCT_NAME"-"$RELEASE_VERSION"-emu.tar.gz"
#    BUILD_OUT_DIR=$SRCROOT"/build.ppc_82xx.d"
#    cd $BUILD_OUT_DIR
#    mkdir -p ./zebos/sbin
#    cp -fr ./etc ./zebos/
#    mkdir -p ./zebos/etc/tmp
#    cp -fr ./mibs ./zebos/
#    cp ./bin/* ./zebos/sbin
#    cp ./bin.emu_svc/* ./zebos/sbin 
#    tar cvzf $RELEASE_PATH/$releasename zebos
#    error_check "Make release"
#    cd $PWD_DIR

    return
}

#
# release image
#
release_image()
{
    echo "Copy image to release dir."
    # Release emulation board version
    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/emulation_board/image"
    echo $RELEASE_PATH
    mkdir -p $RELEASE_PATH
    error_check "Make image release directory"
    
    for version in $IMAGE_VERSION_STRING; do
	releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-"$RELEASE_VERSION"-emu.uImage.emu_svc.$version"
	BUILD_OUT_DIR="$PLAT_TOP_DIR/build_svc"
	echo "BD = $BUILD_OUT_DIR releas= $releasename"
	cd $BUILD_OUT_DIR
	cp -f ./uImage.emu_svc.$version  $releasename
    done

    error_check "Make image release"
    cd $PWD_DIR

    return
}

#
# build boot image
#
build_boot_image()
{
    echo "Build boot image."

    # Release emulation board version
    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/emulation_board/image"
    echo $RELEASE_PATH
    
    mkdir -p $RELEASE_PATH

    for version in $IMAGE_VERSION_STRING; do
    releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-"$RELEASE_VERSION"-uImage.emu_svc.$version"
    echo "BD = $CO_DIR/software/script/bdimg.sh emu_svc $version"
    $CO_DIR/software/script/bdimg.sh emu_svc $version
    echo "copy to $releasename"
    cp -f $CO_DIR/platform/build_svc/uImage.emu_svc.$version $releasename
    echo "cp -f $CO_DIR/platform/build_svc/uImage.emu_svc.$version $releasename"
    echo "finish Build $releasename"
    done

    error_check "Make image release"
    cd $PWD_DIR

    ### copy and tar binary files 
    releasename=$PRODUCT_NAME"-"$RELEASE_VERSION"-emu.tar.gz"
    BUILD_OUT_DIR=$SRCROOT"/build.ppc_82xx.d"
    cd $BUILD_OUT_DIR
    mkdir -p ./zebos/sbin
    cp -fr ./etc ./zebos/
    mkdir -p ./zebos/etc/tmp
    cp -fr ./mibs ./zebos/
    cp ./bin/* ./zebos/sbin
    cp ./bin.emu_svc/* ./zebos/sbin 
    cp ./lib/libzos.so ./zebos/sbin
    tar cvzf $RELEASE_PATH/$releasename zebos
    error_check "Make release"
    cd $PWD_DIR

    return
}

build_e300_image()
{
    echo "Build e300 image."

    # Release e300 board version
    RELEASE_PATH=$RELEASE_PATH_ROOT"/"$PRODUCT_NAME"-"$RELEASE_VERSION"/pizza_box/image"
    echo $RELEASE_PATH
    
    mkdir -p $RELEASE_PATH

    for version in $IMAGE_VERSION_STRING; do
    releasename=$RELEASE_PATH"/"$PRODUCT_NAME"-"$RELEASE_VERSION"-uImage.pizza_box.$version"
    echo "BD = $CO_DIR/software/script/bdimg.sh pizza_box $version"
    $CO_DIR/software/script/bdimg.sh pizza_box $version
    echo "copy to $releasename"
    cp -f $CO_DIR/platform/build_svc/uImage.pizza_box.$version $releasename
    echo "cp -f $CO_DIR/platform/build_svc/uImage.pizza_box.$version $releasename"
    echo "finish Build $releasename"
    done

    error_check "Make image release"
    cd $PWD_DIR

    ### copy and tar binary files 
    releasename=$PRODUCT_NAME"-"$RELEASE_VERSION"-pizza_box.tar.gz"
    BUILD_OUT_DIR=$SRCROOT"/build.ppc_82xx.d"
    cd $BUILD_OUT_DIR
    mkdir -p ./zebos/sbin
    cp -fr ./etc ./zebos/
    mkdir -p ./zebos/etc/tmp
    cp -fr ./mibs ./zebos/
    cp ./bin/* ./zebos/sbin
    cp ./bin.pizza_box/* ./zebos/sbin 
    cp ./lib/libzos.so ./zebos/sbin
    tar cvzf $RELEASE_PATH/$releasename zebos
    error_check "Make release"
    cd $PWD_DIR

    return
}


#
# Print title
#
print_title()
{
    cd $CO_DIR
    echo "=============Auto release at time "$(date)" ===============\n" 
    return
}

#
# Write success mail
#
write_success_mail()
{
    FILE_NAME=$1

    echo "Compile success at host $HOSTNAME, on $(date)\n" > $FILE_NAME
    echo "New version is : $RELEASE_VERSION" >> $FILE_NAME
}

# setting traps to do cleanup
trap 'cleanup' EXIT
trap 'echo "Command interrupted by user"; exit 1;' SIGINT SIGKILL SIGHUP

#
# do auto compile
#

# setting evn for compile
set_env 

# print title
print_title 1>>$OUTPUT_FILE 2>>$ERR_FILE

# remove old version code
#remove_code 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# check out source code
#checkout_code 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# do version number increment
increment_version 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# do compile
compile_code 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# do release
make_release 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# do build e300 image
build_e300_image 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# do build boot image
build_boot_image 1>>$OUTPUT_FILE 2>>$ERR_FILE

# compile image 
#compile_image 1>>$OUTPUT_FILE 2>>$ERR_FILE   

# cp image to release dir
#release_image 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# check in version file
#checkin_version_file 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# add cvs version tag
#cvs_tag_version 1>>$OUTPUT_FILE 2>>$ERR_FILE 

# running well, let's send success notify
#send_mail "success" $OUTPUT_FILE
write_success_mail $SUCCESS_MAIL
send_mail "success" $SUCCESS_MAIL

echo "Success...." 1>>$OUTPUT_FILE 2>>$ERR_FILE 
echo "Success...."
