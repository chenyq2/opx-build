cd ~/dev/trunk/platform
svn update
cd ~/dev/trunk/platform/linux

KB_OUT_DIR=kernel_build_out_2008_01_09
bash build_ctc8247.sh /sw/pub/release/compile/build_out/$KB_OUT_DIR/kbuild.ppc
bash build_uml.sh /sw/pub/release/compile/build_out/$KB_OUT_DIR/kbuild.uml
cp /sw/pub/release/compile/build_out/$KB_OUT_DIR/kbuild.uml/linux /sw/pub/release/uml/uml-latest/
