#!/bin/bash
#
# Copyright (C) 2004-2014 Centec Networks. All rights reserved.
#
#
set -o errexit

usage() {
    echo "Usage: createenv.sh [i686|p1010|p1014|p1020|ls2f] [uml|48T4X|GBDEMO|8T12X|8T4S12X|8TS12X|ODM] [r|d]"
    echo "           i686:    Intel X86 i686"
    echo "           p1010:   Freescale Powerpc P1010"
    echo "           p1014:   Freescale Powerpc P1014"
    echo "           p1020:   Freescale Powerpc P1020"
    echo "           ls2f:    loongson 2f"
    echo "           uml:     Centec uml Board"
    echo "           48T4X:   Centec 48T4X Board"
    echo "           GBDEMO:  Centec GBDEMO Board"
    echo "           8T12X:   Centec 8T12X Board"
    echo "           8T4S12X: Centec 8T4S12X Board"
    echo "           8TS12X:  Centec 8TS12X Board"
    echo "           ODM:     CETC7_48T4X, CPCI_24T8X Board"
    echo "           r:       release version "
    echo "           d:       debug version"
}

case $# in
    3)
        cpu=$1
        board=$2
        version=$3
        ;;
    *)
        usage
        exit 1
esac

if [ $cpu == "i686" ]; then
    arch="um"
    crosscompile=""
    withlib="TRUE"
    uml="y"
    sdk_board="ctc-sim"
    toolchain_path="/usr/bin"
elif [ $cpu == "p1010" ] ; then
    arch="powerpc"
    crosscompile="powerpc-fsl_networking-linux-gnuspe-"
    BUILD_ROOTFS_DIR=/opt/fsl-networking/QorIQ-SDK-V1.4/sysroots/ppce500v2-fsl_networking-linux-gnuspe
    BUILD_BIN_DIR=bin
    GLIB_USER=/opt/fsl-networking/QorIQ-SDK-V1.4/sysroots/ppce500v2-fsl_networking-linux-gnuspe/usr
    withlib="FALSE"
    uml="n"
    sdk_board="ctc-board"
    toolchain_path="/opt/fsl-networking/QorIQ-SDK-V1.4/sysroots/i686-fsl_networking_sdk-linux/usr/bin/ppce500v2-fsl_networking-linux-gnuspe"
elif [ $cpu == "p1014" ] ; then
    arch="powerpc"
    crosscompile="powerpc-fsl_networking-linux-gnuspe-"
    BUILD_ROOTFS_DIR=/opt/fsl-networking/QorIQ-SDK-V1.4/sysroots/ppce500v2-fsl_networking-linux-gnuspe
    BUILD_BIN_DIR=bin
    GLIB_USER=/opt/fsl-networking/QorIQ-SDK-V1.4/sysroots/ppce500v2-fsl_networking-linux-gnuspe/usr
    withlib="FALSE"
    uml="n"
    sdk_board="ctc-board"
    toolchain_path="/opt/fsl-networking/QorIQ-SDK-V1.4/sysroots/i686-fsl_networking_sdk-linux/usr/bin/ppce500v2-fsl_networking-linux-gnuspe"
elif [ $cpu == "p1020" ] ; then
    arch="powerpc"
    crosscompile="powerpc-fsl_networking-linux-gnuspe-"
    BUILD_ROOTFS_DIR=/opt/fsl-networking/QorIQ-SDK-V1.4/sysroots/ppce500v2-fsl_networking-linux-gnuspe
    BUILD_BIN_DIR=bin
    GLIB_USER=/opt/fsl-networking/QorIQ-SDK-V1.4/sysroots/ppce500v2-fsl_networking-linux-gnuspe/usr
    withlib="FALSE"
    uml="n"
    sdk_board="ctc-board"
    toolchain_path="/opt/fsl-networking/QorIQ-SDK-V1.4/sysroots/i686-fsl_networking_sdk-linux/usr/bin/ppce500v2-fsl_networking-linux-gnuspe"
elif [ $cpu == "ls2f" ] ; then
    arch="mips"
    crosscompile="mipsel-linux-"
    BUILD_ROOTFS_DIR=/opt/gcc-3.4.6-2f/root_fs
    BUILD_BIN_DIR=bin
    GLIB_USER=/opt/gcc-3.4.6-2f/mipsel-linux
    withlib="FALSE"
    uml="n"
    sdk_board="ctc-board"
    toolchain_path="/opt/gcc-3.4.6-2f/bin"

else
    usage
    exit 2
fi

# release version
C_VER=$version

# make env
CTC_MAKE="\"make -j8\""

# pizza_box or chasis
BTYPE="pizza_box"

# sdk need
SDK_BOARD=$sdk_board
 
BASH_ENV_INC_FILE=Bash.$board.env.inc

# please don't edit under this line
#

# get root directory
CUR_DIR=`dirname $0`
BUILD_DIR=`pwd`
cd $CUR_DIR/../..
ROOT_DIR=`pwd`
PLAT_TOP_DIR=$ROOT_DIR/code/platform
TOP_DIR=$ROOT_DIR/code/software
OUT_DIR=$ROOT_DIR/out.$board
cd $BUILD_DIR

echo "Generate $BASH_ENV_INC_FILE ($C_VER) under $BUILD_DIR/ ..."
cat > $BUILD_DIR/$BASH_ENV_INC_FILE <<EOF
#
# please don't edit this file
#
# This file is automatically created by createenv.sh
# edit createenv.sh and run it to setting new environments
#
# Copyrights (C) 2004-2014 Centec Networks (suzhou) Co., Ltd.
# All rights reserved.
# 
# please use absolute path
# source code root directory (is currently directory)
export PATH=$PATH:$toolchain_path
export ROOT_DIR=$ROOT_DIR
export PLAT_TOP_DIR=$PLAT_TOP_DIR
export TOP_DIR=$TOP_DIR
export OUT_DIR=$OUT_DIR
export BUILD_ROOTFS_DIR=$BUILD_ROOTFS_DIR
export BUILD_BIN_DIR=$BUILD_BIN_DIR
export GLIB_USER=$GLIB_USER
# compile debug or release version (please use d or r)
export VER=$C_VER

export CTC_MAKE=$CTC_MAKE

export SDK_BOARD=$SDK_BOARD

export BTYPE=$BTYPE
#
# please don't modify under this line
#
# cross compile prefix
export CROSS_COMPILE=$crosscompile

# CPU ARCH settings 
export ARCH=$arch
export CPU=$cpu

export targetbase=linux
export BOARD=$board
export WITHLIB=$withlib
export IS_UML=$uml

export SDK_DIR=\$TOP_DIR/sdk
export CMODEL_DIR=\$TOP_DIR/cmodel
export LC_DIR=\$TOP_DIR/lc
export SAL_TOP_DIR=\$TOP_DIR/sal
export DRV_TOP_DIR=\$TOP_DIR/drvs
export MK_DIR=\$TOP_DIR/build/
export ZEBOS_TOP_DIR=\$TOP_DIR/zebos
export BLD_DIR=\$OUT_DIR/build.\$CPU.\$VER
export KDIR=\$OUT_DIR/kbuild.\$CPU.\$VER
export BUSYBOX_DIR=\$OUT_DIR/build.busybox.\$CPU.\$VER
export APP_TOP_DIR=\$TOP_DIR/apps
export APPLICATION=no

export CHIPNAME=greatbelt

export IS_GCOV=no

EOF

if [ "$ENABLE_S350_FEATURE" == "y" ]; then
    echo "export ENABLE_S350_FEATURE=$ENABLE_S350_FEATURE" >> $BUILD_DIR/$BASH_ENV_INC_FILE
fi
if [ "$ENABLE_DEBIAN_LINUX" == "y" ]; then
    echo "export ENABLE_DEBIAN_LINUX=$ENABLE_DEBIAN_LINUX" >> $BUILD_DIR/$BASH_ENV_INC_FILE  
fi
if [ "$ENABLE_RPC_SERVER" == "y" ]; then
    echo "export UML_ROOT=$ROOT_DIR/umlimage/e300" >> $BUILD_DIR/$BASH_ENV_INC_FILE
    echo "export PYTHON_PATH=$ROOT_DIR/umlimage/e300/usr/lib/python2.7/site-packages" >> $BUILD_DIR/$BASH_ENV_INC_FILE
    echo "export ENABLE_RPC_SERVER=$ENABLE_RPC_SERVER" >> $BUILD_DIR/$BASH_ENV_INC_FILE
    echo "" >> $BUILD_DIR/$BASH_ENV_INC_FILE  
fi

echo "  Done...."
