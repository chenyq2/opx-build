#!/bin/sh
set -o errexit

board=$BOARD
rootfs_dir=$BUILD_ROOTFS_DIR
CROSS_COMPILER=$CROSS_COMPILE
etc_dir=$PLAT_TOP_DIR/build_svc/etc
ctc_build_dir=$BLD_DIR
kbuild_dir=$KDIR
top_dir=$TOP_DIR
ver=$VER
version=2.15.so
bin_dir=bin
tmp_file=$(mktemp)
pre_compiled_dir=${TOP_DIR}/pre-compiled
enable_s350_feature=${ENABLE_S350_FEATURE}
enable_rpc_server=${ENABLE_RPC_SERVER}
enable_debian=${ENABLE_DEBIAN_LINUX}

#package init config
package_init_config=""
if [ "${enable_debian}" == "y" ]; then
    package_init_config="
slink   /bin/init /bin/busybox 755 0 0
file    /sbin/init ${etc_dir}/${board}/debian/boot.sysinit               755 0 0
file    /etc/rc.sysinit     ${etc_dir}/${board}/debian/rc.sysinit               755 0 0"
else
    package_init_config="
slink   /init /bin/busybox 755 0 0
slink   /sbin/init /bin/busybox 755 0 0
file    /etc/rc.sysinit     ${etc_dir}/${board}/rc.sysinit               755 0 0"
fi

echo "
dir     /bin        755 0 0
dir     /dev        755 0 0
dir     /etc        755 0 0
dir     /lib        755 0 0
dir     /mnt        755 0 0
dir     /mnt/flash  755 0 0
dir     /proc       755 0 0
dir     /root       755 0 0
dir     /sbin       755 0 0
dir     /sys        755 0 0
dir     /tftpboot   777 0 0
dir     /tmp        755 0 0
dir     /tmp/cmd    755 0 0
dir     /usr        755 0 0
dir     /usr/bin    755 0 0
dir     /usr/sbin   755 0 0
dir     /usr/share  755 0 0
dir     /usr/share/zoneinfo 755 0 0
dir     /var            755 0 0
dir     /var/www    755 0 0
dir     /var/www/images    755 0 0
dir     /var/www/pub    755 0 0
dir     /var/lib        755 0 0
dir     /var/lib/ntp    755 0 0
dir     /var/log        755 0 0
dir     /var/run        755 0 0
dir     /var/empty      755 0 0
dir     /etc/ssh        755 0 0
dir     /etc/ssh/keys   700 0 0
dir     /data        755 0 0
dir     /etc/udev   755 0 0
dir     /etc/udev/rules.d   755 0 0
dir     /mnt/udisk   755 0 0
dir     /mnt/data   755 0 0
#comment by jcao for bug 19380,2012/05/23
#slink   /var/log/lastlog /mnt/flash/log/lastlog 755 0 0
#slink   /var/log/wtmp /mnt/flash/log/wtmp 755 0 0

slink   /boot /mnt/flash/boot   755 0 0
slink   /conf /mnt/flash/conf   755 0 0

dir /centec_switch 755 0 0
slink /centec_switch/etc /mnt/flash/conf 755 0 0

nod     /dev/console 600 0 0 c 5 1
nod     /dev/ttyS0 600 0 0 c 4 64
nod     /dev/hda  660 0 0 b 3 0
nod     /dev/hda1  660 0 0 b 3 1
nod     /dev/hda2  660 0 0 b 3 2
nod     /dev/hda3  660 0 0 b 3 3
nod     /dev/hda4  660 0 0 b 3 4
nod     /dev/hda5  660 0 0 b 3 5
nod     /dev/ctc_monitor 660 0 0 c 200 0

file    /lib/ld-${version} ${rootfs_dir}/lib/ld-${version} 755 0 0
slink   /lib/ld.so.1 ld-${version} 755 0 0
file    /lib/libc-${version} ${rootfs_dir}/lib/libc-${version} 755 0 0
slink   /lib/libc.so.6 libc-${version} 755 0 0
file    /lib/libm-${version} ${rootfs_dir}/lib/libm-${version} 755 0 0
slink   /lib/libm.so.6 libm-${version} 755 0 0
file    /lib/librt-${version} ${rootfs_dir}/lib/librt-${version} 755 0 0
slink   /lib/librt.so.1 librt-${version} 755 0 0
file    /lib/libcrypt-${version} ${rootfs_dir}/lib/libcrypt-${version} 755 0 0
slink   /lib/libcrypt.so.1 libcrypt-${version} 755 0 0
file    /lib/libutil-${version} ${rootfs_dir}/lib/libutil-${version} 755 0 0
slink   /lib/libutil.so.1 libutil-${version} 755 0 0
file    /lib/libnsl-${version} ${rootfs_dir}/lib/libnsl-${version} 755 0 0
slink   /lib/libnsl.so.1 libnsl-${version} 755 0 0
file    /lib/libnss_files-${version} ${rootfs_dir}/lib/libnss_files-${version} 755 0 0
slink   /lib/libnss_files.so.2 libnss_files-${version} 755 0 0
file    /lib/libnss_dns-${version} ${rootfs_dir}/lib/libnss_dns-${version} 755 0 0
slink   /lib/libnss_dns.so.2 libnss_dns-${version} 755 0 0
file    /lib/libresolv-${version} ${rootfs_dir}/lib/libresolv-${version} 755 0 0
slink   /lib/libresolv.so.2 libresolv-${version} 755 0 0
file    /lib/libreadline.so.5.2 ${rootfs_dir}/usr/lib/libreadline.so.5.2 755 0 0
slink   /lib/libreadline.so.5 libreadline.so.5.2 755 0 0
file    /lib/libpthread-${version} ${rootfs_dir}/lib/libpthread-${version} 755 0 0
slink   /lib/libpthread.so.0 libpthread-${version} 755 0 0
file    /lib/libthread_db-1.0.so ${rootfs_dir}/lib/libthread_db-1.0.so 755 0 0
slink   /lib/libthread_db.so.1 libthread_db-1.0.so 755 0 0
file    /lib/libdl-${version} ${rootfs_dir}/lib/libdl-${version} 755 0 0
slink   /lib/libdl.so.2 libdl-${version} 755 0 0

file    /lib/libproc-3.2.8.so ${rootfs_dir}/usr/lib/libproc-3.2.8.so 755 0 0

file    /lib/libcrypto.so.1.0.0 ${rootfs_dir}/usr/lib/libcrypto.so.1.0.0 755 0 0
slink   /lib/libcrypto.so libcrypto.so.1.0.0 755 0 0
file    /lib/libssl.so.1.0.0 ${rootfs_dir}/usr/lib/libssl.so.1.0.0 755 0 0
slink   /lib/libssl.so libssl.so.1.0.0 755 0 0

file    /lib/libstdc++.so.6 ${rootfs_dir}/usr/lib/libstdc++.so.6.0.17 755 0 0
slink   /lib/libstdc++.so libstdc++.so.6 755 0 0
file    /lib/libgcc_s.so.1 ${rootfs_dir}/lib/libgcc_s.so.1 755 0 0
slink   /lib/libgcc_s.so libgcc_s.so.1 755 0 0

file    /lib/libz.so.1.2.7 ${rootfs_dir}/usr/lib/libz.so.1.2.7 755 0 0
slink   /lib/libz.so.1 libz.so.1.2.7  755 0 0
slink   /lib/libz.so libz.so.1.2.7  755 0 0

file    /lib/libncurses.so.5.9 ${rootfs_dir}/usr/lib/libncurses.so.5.9 755 0 0
slink   /lib/libncurses.so.5 libncurses.so.5.9 755 0 0
slink   /lib/libncurses.so libncurses.so.5 755 0 0

file    /lib/libpcap.so.1.5.1 ${rootfs_dir}/usr/lib/libpcap.so.1.5.1 755 0 0
slink   /lib/libpcap.so.1 libpcap.so.1.5.1 755 0 0
slink   /lib/libpcap.so libpcap.so.1 755 0 0

file    /lib/libglib-2.0.so.0.3400.3 ${rootfs_dir}/usr/lib/libglib-2.0.so.0.3400.3 755 0 0
slink   /lib/libglib-2.0.so libglib-2.0.so.0.3400.3 755 0 0
slink   /lib/libglib-2.0.so.0 libglib-2.0.so.0.3400.3 755 0 0

file    /bin/busybox $BUSYBOX_DIR/busybox 755 0 0
${package_init_config}
slink   /bin/sh /bin/busybox 755 0 0
slink   /bin/ash /bin/busybox 755 0 0
slink   /bin/login /bin/busybox 755 0 0
slink   /init /sbin/init 755 0 0
slink   /sbin/mount /bin/busybox 755 0 0
slink   /sbin/getty /bin/busybox 755 0 0
slink   /etc/mtab /proc/mounts 755 0 0

#added by xgu for bug 13955
file    /sbin/mii-tool ${rootfs_dir}/${bin_dir}/mii-tool 755 0 0
file    /sbin/ethtool ${rootfs_dir}/${bin_dir}/ethtool 755 0 0
file    /sbin/tcpdump ${rootfs_dir}/${bin_dir}/tcpdump 755 0 0
file    /sbin/strace ${rootfs_dir}/${bin_dir}/strace 755 0 0
#file    /bin/fsck ${rootfs_dir}/bin/fsck 755 0 0
#file    /bin/fsck.msdos ${rootfs_dir}/bin/fsck.msdos 755 0 0
#file    /bin/mkfs ${rootfs_dir}/bin/mkfs 755 0 0
#file    /bin/mkfs.msdos ${rootfs_dir}/bin/mkfs.msdos 755 0 0
file    /bin/ls ${rootfs_dir}/${bin_dir}/ls 755 0 0
file    /bin/ps ${rootfs_dir}/${bin_dir}/ps 755 0 0
file    /bin/netstat ${rootfs_dir}/${bin_dir}/netstat 755 0 0
file    /bin/ping ${rootfs_dir}/${bin_dir}/ping 755 0 0
file    /bin/ping6 ${rootfs_dir}/${bin_dir}/ping6 755 0 0
#file    /usr/bin/traceroute6 ${rootfs_dir}/${bin_dir}/traceroute6 755 0 0

file    /usr/bin/gdbserver ${rootfs_dir}/usr/${bin_dir}/gdbserver 755 0 0
file    /usr/bin/gdb ${rootfs_dir}/usr/${bin_dir}/gdb 755 0 0

file    /usr/bin/core_helper     ${etc_dir}/core_helper     755 0 0
file    /usr/sbin/flash_erase ${rootfs_dir}/${bin_dir}/flash_erase 755 0 0
file    /usr/sbin/flashcp ${rootfs_dir}/${bin_dir}/flashcp 755 0 0
file    /usr/sbin/flash_eraseall ${rootfs_dir}/${bin_dir}/flash_eraseall 755 0 0
file    /usr/sbin/flash_lock ${rootfs_dir}/${bin_dir}/flash_lock 755 0 0
file    /usr/sbin/flash_unlock ${rootfs_dir}/${bin_dir}/flash_unlock 755 0 0
file    /usr/sbin/ubiattach ${rootfs_dir}/${bin_dir}/ubiattach 755 0 0
file    /usr/sbin/ubimkvol  ${rootfs_dir}/${bin_dir}/ubimkvol  755 0 0
file    /usr/sbin/ubiformat ${rootfs_dir}/${bin_dir}/ubiformat 755 0 0
file    /usr/sbin/ubinfo ${rootfs_dir}/${bin_dir}/ubinfo 755 0 0
file    /usr/sbin/ubidetach ${rootfs_dir}/${bin_dir}/ubidetach 755 0 0
#file    /usr/sbin/stressapptest  ${rootfs_dir}/${bin_dir}/stressapptest  755 0 0
file    /usr/sbin/udevd ${rootfs_dir}/${bin_dir}/udevd 755 0 0
file    /usr/sbin/udevstart ${rootfs_dir}/${bin_dir}/udevstart 755 0 0
file    /usr/sbin/lspci ${rootfs_dir}/${bin_dir}/lspci 755 0 0
file    /usr/sbin/setpci ${rootfs_dir}/${bin_dir}/setpci 755 0 0
file    /usr/sbin/startup_monitor ${etc_dir}/${board}/startup_monitor 755 0 0
file    /usr/sbin/tftpd ${rootfs_dir}/${bin_dir}/tftpd 755 0 0

file    /etc/localtime      ${etc_dir}/UTC                      644 0 0
file    /etc/inittab_sup    ${etc_dir}/${board}/inittab_sup              644 0 0
file    /etc/inittab_lc     ${etc_dir}/${board}/inittab_lc              644 0 0
file    /etc/termcap        ${etc_dir}/termcap                  644 0 0
file    /etc/passwd         ${etc_dir}/passwd                   644 0 0
file    /etc/group          ${etc_dir}/group                    644 0 0
file    /etc/profile        ${etc_dir}/profile                  644 0 0
file    /etc/services       ${etc_dir}/services                 644 0 0
file    /etc/protocols       ${etc_dir}/protocols               644 0 0
file    /etc/hosts          ${etc_dir}/hosts                    644 0 0
file    /etc/resolv.conf    ${etc_dir}/resolv.conf              644 0 0
file    /etc/nsswitch.conf  ${etc_dir}/nsswitch.conf            644 0 0
file    /etc/cf_hotplug     ${etc_dir}/cf_hotplug               755 0 0
file    /etc/udev/udev.conf      ${etc_dir}/udev/udev.conf                755 0 0
file    /etc/udev/rules.d/udev.conf      ${etc_dir}/udev/rules.d/udev.conf                755 0 0
file    /etc/udev/rules.d/mount.rules      ${etc_dir}/udev/rules.d/mount.rules                755 0 0
file    /etc/udev/rules.d/unmount.rules      ${etc_dir}/udev/rules.d/unmount.rules                755 0 0
file    /etc/mount.sh     ${etc_dir}/mount.sh               755 0 0
file    /etc/unmount.sh     ${etc_dir}/unmount.sh               755 0 0
file    /usr/sbin/restart.sh ${etc_dir}/restart.sh    755 0 0
file    /usr/share/zoneinfo/zone.tab ${PLAT_TOP_DIR}/build_svc/zone.tab 644 0 0
file    /usr/share/zoneinfo/iso3166.tab ${PLAT_TOP_DIR}/build_svc/iso3166.tab 644 0 0
file    /tmp/ShowIpeDiscardType.txt ${ctc_build_dir}/etc/ShowIpeDiscardType.txt 644 0 0
file    /tmp/ShowEpeDiscardType.txt ${ctc_build_dir}/etc/ShowEpeDiscardType.txt 644 0 0
" > ${tmp_file}

echo "
file    /etc/qt2x25_firmware_mdio.bin     ${etc_dir}/qt2x25_firmware_mdio.bin          755 0 0
" >> ${tmp_file}

echo "dir /etc/datapath_profile 755 0 0" >> ${tmp_file}
profile_list=$(ls $etc_dir/datapath_profile)
for f in $profile_list; do
    echo "file /etc/datapath_profile/$f ${etc_dir}/datapath_profile/$f 755 0 0" >> ${tmp_file}
done

# For emulation board
if [ "$board" == "hw_emu" ] || [ "$board" == "emu_svc" ]; then
echo "
dir /etc/emu_init 755 0 0
file /etc/emu_init/hwinit.txt ${SRCROOT}/TheGrandCanal/emu_init/hwinit.txt 644 0 0
file /etc/emu_init/disable_phy ${SRCROOT}/TheGrandCanal/emu_init/disable_phy 644 0 0
file /etc/emu_init/enable_phy ${SRCROOT}/TheGrandCanal/emu_init/enable_phy 644 0 0
file /etc/emu_init/mac_init ${SRCROOT}/TheGrandCanal/emu_init/mac_init 644 0 0
file /etc/emu_init/patch ${SRCROOT}/TheGrandCanal/emu_init/patch 644 0 0
file /etc/emu_init/InitBayDataPath_24GNet_16GFabric.pl ${SRCROOT}/TheGrandCanal/emu_init/InitBayDataPath_24GNet_16GFabric.pl 644 0 0
" >> ${tmp_file}
fi

rm -rf tmp
mkdir tmp

# line card binary package
if [ "$board" == "atca_svc" ]; then
cp ${ctc_build_dir}/lcpkg/lcimg.md5 tmp
cp ${ctc_build_dir}/lcpkg/lcimg.tar.gz tmp
echo "file /tftpboot/lcimg.md5 ${PLAT_TOP_DIR}/build_svc/tmp/lcimg.md5 777 0 0" >> ${tmp_file}
echo "file /tftpboot/lcimg.tar.gz ${PLAT_TOP_DIR}/build_svc/tmp/lcimg.tar.gz 777 0 0" >> ${tmp_file}
fi

# Modified native commands
cp ${ctc_build_dir}/bin/tftp tmp
cp ${ctc_build_dir}/bin/ftp tmp
cp ${ctc_build_dir}/bin/more tmp
cp ${ctc_build_dir}/bin/chvrf tmp
${CROSS_COMPILER}strip tmp/tftp
${CROSS_COMPILER}strip tmp/ftp
${CROSS_COMPILER}strip tmp/more
${CROSS_COMPILER}strip tmp/chvrf
echo "file /usr/bin/tftp ${PLAT_TOP_DIR}/build_svc/tmp/tftp 755 0 0" >> ${tmp_file}
echo "file /usr/bin/ftp ${PLAT_TOP_DIR}/build_svc/tmp/ftp 755 0 0" >> ${tmp_file}
echo "file /bin/more ${PLAT_TOP_DIR}/build_svc/tmp/more 755 0 0" >> ${tmp_file}
echo "file /bin/chvrf ${PLAT_TOP_DIR}/build_svc/tmp/chvrf 755 0 0" >> ${tmp_file}
if [ "$board" == "hw_emu" ] || [ "$board" == "emu_svc" ]; then
    cp ${ctc_build_dir}/bin/ntpdate tmp
    cp ${ctc_build_dir}/bin/ntpq tmp
    ${CROSS_COMPILER}strip tmp/ntpdate
    ${CROSS_COMPILER}strip tmp/ntpq
    echo "file /usr/bin/ntpdate ${PLAT_TOP_DIR}/build_svc/tmp/ntpdate 755 0 0 " >> ${tmp_file}
    echo "file /usr/sbin/ntpq ${PLAT_TOP_DIR}/build_svc/tmp/ntpq 755 0 0" >> ${tmp_file}
fi

# LKMs
#lkm_list="mpls.ko ctc_hw.ko peth_km.ko ctc_asic_io.ko ctc_cpm.ko"
lkm_list="mpls.ko ctc_hw.ko dal.ko ctc_gpio.ko peth_km.ko kernel_monitor.ko"
for lkm in ${lkm_list}; do
    cp ${ctc_build_dir}/bin/${lkm} tmp
if [ $ver == "r" ]; then
    ${CROSS_COMPILER}strip -g tmp/${lkm}
fi
    echo "file /lib/${lkm} ${PLAT_TOP_DIR}/build_svc/tmp/${lkm} 644 0 0" >> ${tmp_file}
done

# board_type_detect
cp ${ctc_build_dir}/bin/board_type_detect tmp
${CROSS_COMPILER}strip tmp/board_type_detect
echo "file /usr/sbin/board_type_detect ${PLAT_TOP_DIR}/build_svc/tmp/board_type_detect 755 0 0" >> ${tmp_file}
# startup monitor prog
cp ${ctc_build_dir}/bin/monitor tmp
${CROSS_COMPILER}strip tmp/monitor
echo "file /usr/sbin/monitor ${PLAT_TOP_DIR}/build_svc/tmp/monitor 755 0 0" >> ${tmp_file}
#boot console no password
cp ${ctc_build_dir}/bin/nopassword tmp
${CROSS_COMPILER}strip tmp/nopassword
echo "file /usr/sbin/nopassword ${PLAT_TOP_DIR}/build_svc/tmp/nopassword 755 0 0" >> ${tmp_file}

# dynamic lib
libs="libasn1.so libsal.so libctclib.so libcjson.so"
for lib in $libs; do
    cp ${ctc_build_dir}/lib/$lib tmp
    ${CROSS_COMPILER}strip tmp/$lib
    echo "file /lib/$lib ${PLAT_TOP_DIR}/build_svc/tmp/$lib 755 0 0" >> ${tmp_file}
done

# libzos.so
cp ${ctc_build_dir}/lib/libzos.so tmp
${CROSS_COMPILER}strip tmp/libzos.so
echo "file /lib/libzos.so ${PLAT_TOP_DIR}/build_svc/tmp/libzos.so 755 0 0" >> ${tmp_file}

# SSHD
ssh_cfg_list="moduli ssh_config ssh_host_dsa_key ssh_host_dsa_key.pub"
ssh_cfg_list=${ssh_cfg_list}" ssh_host_key ssh_host_key.pub ssh_host_rsa_key ssh_host_rsa_key.pub sshd_config"
for cfg in ${ssh_cfg_list}; do
    cp ${ctc_build_dir}/etc/${cfg} tmp
    echo "file /etc/ssh/${cfg} ${PLAT_TOP_DIR}/build_svc/tmp/${cfg} 600 0 0" >> ${tmp_file}
done

cp ${ctc_build_dir}/etc/lic.pub.rsa tmp
echo "file /etc/lic.pub.rsa ${PLAT_TOP_DIR}/build_svc/tmp/lic.pub.rsa 600 0 0" >> ${tmp_file}

# PMs
#prog_list="imi ripd ripngd ospfd ospf6d onmd mstpd ldpd bgpd authd lacpd pimd ctcli"
if [ "$ctcli" == "yes" ] || [ "$board" == "hw_emu" ] || [ "$board" == "emu_svc" ]; then
prog_list="ssh sshd imi ripd ospfd onmd mstpd ldpd pimd pdmd authd bgpd ctcli bhm lacpd ptpd ssmd oamd rsvpd filem livepatch"
else
prog_list="ssh sshd imi ripd ospfd ospf6d ripngd onmd mstpd ldpd pimd pdmd pim6d authd bgpd bhm lacpd ptpd ssmd oamd rsvpd filem"
fi
prog_list=$prog_list" angel strace"
prog_list=$prog_list" dhclient scfgd check_image scfg_detect cpulimit"
prog_list=$prog_list" dhcpd6"
prog_list=$prog_list" fea_shm_init httpd lictl"
if [ "${enable_debian}" == "y" ]; then
prog_list=$prog_list" break_chroot"
fi
for prog in ${prog_list}; do
    cp ${ctc_build_dir}/bin/${prog} tmp
    ${CROSS_COMPILER}strip tmp/${prog}
    echo "file /usr/sbin/${prog} ${PLAT_TOP_DIR}/build_svc/tmp/${prog} 755 0 0" >> ${tmp_file}
done

# DTCLI
#cp ${ctc_build_dir}/bin/dtcli tmp
#${CROSS_COMPILER}strip tmp/dtcli
#echo "file /usr/bin/dtcli ${PLAT_TOP_DIR}/build_svc/tmp/dtcli 755 0 0" >> ${tmp_file}

# HAL
cp ${ctc_build_dir}/bin/hsrvd tmp
${CROSS_COMPILER}strip tmp/hsrvd
echo "file /usr/bin/hsrvd ${PLAT_TOP_DIR}/build_svc/tmp/hsrvd 755 0 0" >> ${tmp_file}

# LCSH
cp ${ctc_build_dir}/bin/lcsh tmp
${CROSS_COMPILER}strip tmp/lcsh
echo "file /usr/bin/lcsh ${PLAT_TOP_DIR}/build_svc/tmp/lcsh 755 0 0" >> ${tmp_file}

# VTYSH
cp ${ctc_build_dir}/bin/vtysh tmp
${CROSS_COMPILER}strip tmp/vtysh
echo "file /usr/bin/vtysh ${PLAT_TOP_DIR}/build_svc/tmp/vtysh 755 0 0" >> ${tmp_file}


# IMISH
cp ${ctc_build_dir}/bin/imish tmp
${CROSS_COMPILER}strip tmp/imish
echo "file /usr/bin/imish ${PLAT_TOP_DIR}/build_svc/tmp/imish 755 0 0" >> ${tmp_file}

# NSM
cp ${ctc_build_dir}/bin/nsm tmp
${CROSS_COMPILER}strip tmp/nsm
echo "file /usr/sbin/nsm ${PLAT_TOP_DIR}/build_svc/tmp/nsm 755 0 0" >> ${tmp_file}
echo "dir /etc/memory_profile 755 0 0" >> ${tmp_file}
profile_list=$(ls ${ctc_build_dir}/etc/profile)
for f in $profile_list; do
    echo "file /etc/memory_profile/$f ${ctc_build_dir}/etc/profile/$f 644 0 0" >> ${tmp_file}
done






# IPTABLES
cp ${PLAT_TOP_DIR}/build_svc/etc/iptables-ppc tmp/iptables
${CROSS_COMPILER}strip tmp/iptables
echo "file /usr/bin/iptables ${PLAT_TOP_DIR}/build_svc/tmp/iptables 755 0 0" >> ${tmp_file}

# CHSM
cp ${ctc_build_dir}/bin.${board}/chsm tmp
${CROSS_COMPILER}strip tmp/chsm
echo "file /usr/sbin/chsm ${PLAT_TOP_DIR}/build_svc/tmp/chsm 755 0 0" >> ${tmp_file}

# NTP
cp ${ctc_build_dir}/bin/ntpd tmp
cp ${ctc_build_dir}/bin/ntpdc tmp
${CROSS_COMPILER}strip tmp/ntpd
${CROSS_COMPILER}strip tmp/ntpdc
echo "file /usr/sbin/ntpd ${PLAT_TOP_DIR}/build_svc/tmp/ntpd 755 0 0" >> ${tmp_file}
echo "file /usr/sbin/ntpdc ${PLAT_TOP_DIR}/build_svc/tmp/ntpdc 755 0 0" >> ${tmp_file}
echo "file /etc/ntp.conf ${ctc_build_dir}/etc/ntp.conf 644 0 0" >> ${tmp_file}
echo "dir /etc/ntp 755 0 0" >> ${tmp_file}
echo "file /etc/ntp/keys ${ctc_build_dir}/etc/ntpkeys.conf 644 0 0" >> ${tmp_file}

# syslog-ng
cp ${ctc_build_dir}/bin/syslog-ng tmp
${CROSS_COMPILER}strip tmp/syslog-ng
cp ${ctc_build_dir}/bin/init-syslog-ng.sh tmp
echo "file /usr/sbin/syslog-ng ${PLAT_TOP_DIR}/build_svc/tmp/syslog-ng 755 0 0" >> ${tmp_file}
echo "file /usr/sbin/init-syslog-ng.sh ${PLAT_TOP_DIR}/build_svc/tmp/init-syslog-ng.sh 755 0 0" >> ${tmp_file}

# mplsonm
cp ${ctc_build_dir}/bin/mplsonm tmp
${CROSS_COMPILER}strip tmp/mplsonm
echo "file /usr/sbin/mplsonm ${PLAT_TOP_DIR}/build_svc/tmp/mplsonm 755 0 0" >> ${tmp_file}

# logrotate
echo "file /usr/sbin/logsync.sh ${ctc_build_dir}/bin/logsync.sh 755 0 0" >> ${tmp_file}
echo "file /usr/sbin/diaglogsync.sh ${ctc_build_dir}/bin/diaglogsync.sh 755 0 0" >> ${tmp_file}
#echo "file /usr/sbin/dailyrotate.sh ${ctc_build_dir}/bin/dailyrotate.sh 755 0 0" >> ${tmp_file}
#echo "file /usr/sbin/diagdailyrotate.sh ${ctc_build_dir}/bin/diagdailyrotate.sh 755 0 0" >> ${tmp_file}

# crond for bug 13802 by weij 2010-12-23
#echo "dir /etc/crontabs 755 0 0" >> ${tmp_file}
#cat ${ctc_build_dir}/etc/dailyrotate.cron > ${PLAT_TOP_DIR}/build_svc/tmp/etc_crontabs_root
#echo "file /etc/crontabs/root ${PLAT_TOP_DIR}/build_svc/tmp/etc_crontabs_root 644 0 0" >> ${tmp_file}

# DHCP relay
cp ${ctc_build_dir}/bin/dhcrelay6 tmp
${CROSS_COMPILER}strip tmp/dhcrelay6
echo "file /usr/sbin/dhcrelay6 ${PLAT_TOP_DIR}/build_svc/tmp/dhcrelay6 755 0 0" >> ${tmp_file}
#echo "file /etc/dhcpd.conf ${ctc_build_dir}/etc/dhcpd.conf 644 0 0" >> ${tmp_file}

# SNMP
cp ${ctc_build_dir}/bin/snmpd tmp
${CROSS_COMPILER}strip tmp/snmpd
echo "file /usr/sbin/snmpd ${PLAT_TOP_DIR}/build_svc/tmp/snmpd 755 0 0" >> ${tmp_file}
echo "file /etc/snmpd.conf ${ctc_build_dir}/etc/snmpd.conf 644 0 0" >> ${tmp_file}
echo "dir /etc/mibs 755 0 0" >> ${tmp_file}

# RMON
cp ${ctc_build_dir}/bin/rmond tmp
${CROSS_COMPILER}strip tmp/rmond
echo "file /usr/sbin/rmond ${PLAT_TOP_DIR}/build_svc/tmp/rmond 755 0 0" >> ${tmp_file}

# chvrf
cp ${ctc_build_dir}/bin/chvrf tmp
${CROSS_COMPILER}strip tmp/chvrf
echo "file /bin/chvrf ${PLAT_TOP_DIR}/build_svc/tmp/chvrf 755 0 0" >> ${tmp_file}

#for mib_file in ${ctc_build_dir}/mibs/*.txt; do
#    mib_file=$(basename ${mib_file})
#    echo "file /etc/mibs/${mib_file} ${ctc_build_dir}/mibs/${mib_file} 644 0 0" >> ${tmp_file}
#done

echo "file /etc/httpd.conf ${ctc_build_dir}/etc/httpd.conf 755 0 0" >> ${tmp_file}
echo "file /etc/server.pem ${ctc_build_dir}/etc/server.pem 755 0 0" >> ${tmp_file}

# httpd lib
libs="mod_access.so mod_cgi.so mod_indexfile.so mod_auth.so mod_dirlisting.so mod_staticfile.so"
for item in ${libs}; do
    cp ${ctc_build_dir}/lib/${item} tmp
    ${CROSS_COMPILER}strip tmp/${item}
    echo "file /lib/${item} ${PLAT_TOP_DIR}/build_svc/tmp/${item} 755 0 0" >> ${tmp_file}
done

libs="libneo_cs.so libneo_cgi.so libneo_utl.so"
for item in ${libs}; do
    cp ${ctc_build_dir}/lib/${item} tmp
    ${CROSS_COMPILER}strip tmp/${item}
    echo "file /lib/${item} ${PLAT_TOP_DIR}/build_svc/tmp/${item} 755 0 0" >> ${tmp_file}
done

# httpd web
cgis="`cd ${ctc_build_dir}/bin && ls --color=none *.cgi`"
for item in ${cgis}; do
    cp ${ctc_build_dir}/bin/${item} tmp
    ${CROSS_COMPILER}strip tmp/${item}
    echo "file /var/www/${item} ${PLAT_TOP_DIR}/build_svc/tmp/${item} 755 0 0" >> ${tmp_file}
done

# package web binary image
${top_dir}/apps/web/cgi/pkg_web.sh ${top_dir}/apps/web/cgi webImage.bin
ls -l webImage.bin
##############
# package python
if [ "${enable_rpc_server}" == "y" ]; then
# 1. create dir for python
echo "dir /usr/include                       755 0 0" >> ${tmp_file}
echo "dir /usr/include/python2.7             755 0 0" >> ${tmp_file}
echo "dir /usr/lib                           755 0 0" >> ${tmp_file}
echo "dir /usr/lib/python2.7                 755 0 0" >> ${tmp_file}
echo "dir /usr/lib/python2.7/site-packages   755 0 0" >> ${tmp_file}
echo "dir /usr/lib/python2.7/lib-dynload     755 0 0" >> ${tmp_file}
echo "dir /usr/lib/python2.7/config          755 0 0" >> ${tmp_file}

# 1. python ctype driver libimish.so
libs="libimish.so"
for item in ${libs}; do
    cp ${ctc_build_dir}/lib/${item} tmp
if [ "$ver" == "r" ]; then
    ${CROSS_COMPILER}strip tmp/${item}
fi
    echo "file /lib/${item} ${PLAT_TOP_DIR}/build_svc/tmp/${item} 755 0 0" >> ${tmp_file}
done

# 2. python include files
file_list=$(ls $pre_compiled_dir/usr/include/python2.7)
for f in $file_list; do
    echo "file /usr/include/python2.7/$f ${pre_compiled_dir}/usr/include/python2.7/$f 644 0 0" >> ${tmp_file}
done

# 3. package bin files
file_list=$(ls $pre_compiled_dir/usr/bin)
for f in $file_list; do
    echo "file /usr/bin/$f ${pre_compiled_dir}/usr/bin/$f 755 0 0" >> ${tmp_file}
done

# 4. package lib file
echo "file  /usr/lib/python27.zip ${pre_compiled_dir}/usr/lib/python27.zip 644 0 0" >> ${tmp_file}

# 5. package other config files
file_list=$(ls $pre_compiled_dir/usr/lib/python2.7/lib-dynload)
for f in $file_list; do
    echo "file /usr/lib/python2.7/lib-dynload/$f ${pre_compiled_dir}/usr/lib/python2.7/lib-dynload/$f 755 0 0" >> ${tmp_file}
done

file_list=$(ls $pre_compiled_dir/usr/lib/python2.7/config)
for f in $file_list; do
    echo "file /usr/lib/python2.7/config/$f ${pre_compiled_dir}/usr/lib/python2.7/config/$f 755 0 0" >> ${tmp_file}
done
fi

###
# rpc_server package in python site-packages
org_pwd=$(pwd)
cd ${TOP_DIR}/apps
# 1. create dir for rpc_server
dir_list=$(find sdn -type d -not -iwholename '*.svn*' -not -iwholename '*.settings*')
for f in $dir_list; do
    echo "dir /usr/lib/python2.7/site-packages/$f  755 0 0" >> ${tmp_file}
done

echo "slink /usr/sbin/rpc_server /usr/lib/python2.7/site-packages/sdn/rpc_server.py 755 0 0" >> ${tmp_file}
echo "slink /usr/sbin/cloud_agent /usr/lib/python2.7/site-packages/sdn/cloud_agent.py 755 0 0" >> ${tmp_file}

# 1. package sdn service
# 1.1 package py files
file_list=$(find sdn -path '*.py')
for f in $file_list; do
    echo "file /usr/lib/python2.7/site-packages/$f ${TOP_DIR}/apps/$f 755 0 0" >> ${tmp_file}
done
cd ${org_pwd}

# 2. package site-packages
cd $pre_compiled_dir/usr/lib/python2.7/site-packages
# 2.1 create dir for site-packages
dir_list=$(find -type d -not -iwholename '*.svn*' -not -iwholename '*.settings*')
for f in $dir_list; do
    echo "dir /usr/lib/python2.7/site-packages/$f  755 0 0" >> ${tmp_file}
done

# 2.2 package py files
file_list=$(find -type f -path '*' -not -iwholename '*.svn*' -not -iwholename '*.settings*')
for f in $file_list; do
    echo "file /usr/lib/python2.7/site-packages/$f $pre_compiled_dir/usr/lib/python2.7/site-packages/$f 755 0 0" >> ${tmp_file}
done
cd ${org_pwd}
##############

echo "Create System Image..."
#cat ${tmp_file}

if [ "$board" == "hw_pizza_box" ]; then
   product_name="E330"
elif [ "$board" == "hw_chassis_svc" ]; then
   product_name="E8xx"
fi

# Basic Image
if [ "${enable_s350_feature}" == "y" ]; then
    cp ${ctc_build_dir}/etc/fea_cfg_basic_s350 tmp
    echo "file /etc/fea_cfg ${PLAT_TOP_DIR}/build_svc/tmp/fea_cfg_basic_s350 600 0 0" >> ${tmp_file}
else
    cp ${ctc_build_dir}/etc/fea_cfg_basic tmp
    echo "file /etc/fea_cfg ${PLAT_TOP_DIR}/build_svc/tmp/fea_cfg_basic 600 0 0" >> ${tmp_file}
fi
# copy profiles: FIXME
profile_list=$(ls ${ctc_build_dir}/etc/profile)
for f in $profile_list; do
    echo "file /etc/memory_profile/$f ${ctc_build_dir}/etc/profile/$f 644 0 0" >> ${tmp_file}
done

${kbuild_dir}/usr/gen_init_cpio ${tmp_file} | lzma -f -9 - > ${kbuild_dir}/initramfs.lzma
rm ${tmp_file}

