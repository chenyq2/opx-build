/****************************************************************************
 * ctckal_malloc.c:         memory allocation module
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#include "sal.h"

/*****************************************************************************
 * Name         : ctckal_malloc
 * Purpose      : allocate memory
 * Input        : size: memory size in byte
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void *ctckal_malloc(uint32 size)
{
    return malloc(size);
}


/*****************************************************************************
 * Name         : ctckal_free
 * Purpose      : free memory
 * Input        : addr: memory address returned by ctckal_malloc
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void ctckal_free(void *addr)
{
    if (addr == NULL)
        return;

    #if 1
    free(addr);
    #endif
}
