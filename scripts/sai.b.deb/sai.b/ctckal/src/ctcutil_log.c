/*****************************************************************************
 * ctcutil_log.c    logging facility
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:    V1.0
 * Author:      Jack Yang
 * Date:        2010-08-18
 * Reason:      Initial version
 *****************************************************************************/


/* todo: error code */
/* todo: move fopen to init */
/* todo: log file rotate */


#include "sal.h"
#include "ctcutil_log.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>


/*****************************************************************************
 * defines
 *****************************************************************************/
#define OUTPUT_FILENAME_LEN             1024
#define MAC_STR_LEN                     32


/*****************************************************************************
 * global variables
 *****************************************************************************/
static uint32 output_device = 0;
static char output_filename[OUTPUT_FILENAME_LEN] = "ctcutil_log";
static int32 module_log_level[CTCUTIL_LOG_MAX_MODULE] = {0};
static uint32 log_flag = 0;


/*****************************************************************************
 * static functions
 *****************************************************************************/
static int32
do_log(uint32 module, int32 level, char *prefix, char *fmt, va_list args)
{
    time_t curr_time;
    struct tm *calendar_time;

    if (level > module_log_level[module])
        return -1;

    curr_time = time(NULL);
    calendar_time = localtime(&curr_time);

    if (output_device & CTCUTIL_LOG_CONSOLE)
    {
        if (log_flag & CTCUTIL_LOG_ADD_TIME)
            printf("%d/%d/%d:%d:%d:%d",
                   calendar_time->tm_year + 1900,
                   calendar_time->tm_mon + 1,
                   calendar_time->tm_mday,
                   calendar_time->tm_hour,
                   calendar_time->tm_min,
                   calendar_time->tm_sec);

        if (prefix)
            printf("::%s:", prefix);

        if ((log_flag & CTCUTIL_LOG_PREFIX_SEPARATE)
            && ((log_flag & CTCUTIL_LOG_ADD_TIME)
                || prefix))
            printf("\n");

        vprintf(fmt, args);
    }

    if (output_device & CTCUTIL_LOG_FILE)
    {
        FILE *output_file;

        output_file = fopen(output_filename, "a+");
        if (!output_file)
            return -1;

        if (log_flag & CTCUTIL_LOG_ADD_TIME)
            sal_fprintf(output_file, "%d/%d/%d:%d:%d:%d",
                    calendar_time->tm_year + 1900,
                    calendar_time->tm_mon + 1,
                    calendar_time->tm_mday,
                    calendar_time->tm_hour,
                    calendar_time->tm_min,
                    calendar_time->tm_sec);

        if (prefix)
            sal_fprintf(output_file, "::%s:", prefix);

        if ((log_flag & CTCUTIL_LOG_PREFIX_SEPARATE)
            && ((log_flag & CTCUTIL_LOG_ADD_TIME)
                || prefix))
            sal_fprintf(output_file, "\n");

        vfprintf(output_file, fmt, args);
        fclose(output_file);
    }

    return 0;
}


/*****************************************************************************
 * exported functions
 *****************************************************************************/

/****************************************************************************
 * Name		: ctcutil_log
 * Purpose	: log information without prefix
 * Input	: module: defined in ctcutil_log.h
 *                level: defined in ctcutil_log.h
 * Output	: n/a
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log(uint32 module, int32 level, char *fmt, ...)
{
    int32 ret;
    va_list args;

    if (module >= CTCUTIL_LOG_MAX_MODULE
        || level >= CTCUTIL_LOG_MAX_LEVEL
        || !fmt)
        return -1;

    va_start(args, fmt);
    ret = do_log(module, level, NULL, fmt, args);
    va_end(args);

    return ret;
}


/****************************************************************************
 * Name		: ctcutil_log_standard
 * Purpose	: log information with file name, function name and line no.
 * Input	: module: defined in ctcutil_log.h
 *                level: defined in ctcutil_log.h
 * Output	: n/a
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_standard(char *file, char *function, int32 line,
                     uint32 module, int32 level, char *fmt, ...)
{
    int32 ret;
    va_list args;
    char prefix_buf[128];
    char strbuf[64];

    if (module >= CTCUTIL_LOG_MAX_MODULE
        || level >= CTCUTIL_LOG_MAX_LEVEL
        || !fmt)
        return -1;

    sal_memset(prefix_buf, 0, sizeof(prefix_buf));
    sal_memset(strbuf, 0, sizeof(strbuf));

    if (file)
    {
        sal_strcat(prefix_buf, "::");
        sal_strcat(prefix_buf, file);
    }

    if (function)
    {
        sal_strcat(prefix_buf, "::");
        sal_strcat(prefix_buf, function);
    }

    if (line != 0)
    {
        sal_strcat(prefix_buf, "::");
        sal_sprintf(strbuf, "%d", line);
        sal_strcat(prefix_buf, strbuf);
    }

    va_start(args, fmt);
    ret = do_log(module, level, prefix_buf, fmt, args);
    va_end(args);

    return ret;
}


/****************************************************************************
 * Name		: ctcutil_log_prefix
 * Purpose	: log information with prefix
 * Input	: module: defined in ctcutil_log.h
 *                level: defined in ctcutil_log.h
 * Output	: n/a
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_prefix(uint32 module, int32 level, char *prefix,
                   char *fmt, ...)
{
    int32 ret;
    va_list args;

    if (module >= CTCUTIL_LOG_MAX_MODULE
        || level >= CTCUTIL_LOG_MAX_LEVEL
        || !fmt)
        return -1;

    va_start(args, fmt);
    ret = do_log(module, level, prefix, fmt, args);
    va_end(args);

    return ret;
}


/****************************************************************************
 * Name		: ctcutil_log_set_device
 * Purpose	: set output device
 * Input	: device: defined in ctcutil_log.h
 * Output	: n/a
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_set_device(uint32 device)
{
    if (!((device & CTCUTIL_LOG_CONSOLE)
          || (device & CTCUTIL_LOG_FILE)))
        return -1;

    output_device = device;

    return 0;
}


/****************************************************************************
 * Name		: ctcutil_log_get_device
 * Purpose	: get output device
 * Input	: n/a
 * Output	: p_device: output device
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_get_device(uint32 *p_device)
{
    if (!p_device)
        return -1;

    *p_device = output_device;

    return 0;
}


/****************************************************************************
 * Name		: ctcutil_log_set_filename
 * Purpose	: set output filename
 * Input	: filename: output filename
 * Output	: n/a
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_set_filename(char *filename)
{
    if (!(output_device & CTCUTIL_LOG_FILE) || !filename)
        return -1;

    sal_strncpy(output_filename, filename, OUTPUT_FILENAME_LEN);

    return 0;
}


/****************************************************************************
 * Name		: ctcutil_log_get_filename
 * Purpose	: get output filename
 * Input	: buf_len: the length of the output buffer
 * Output	: buf: output buffer
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_get_filename(char *buf, int32 buf_len)
{
    if (!buf || buf_len == 0)
        return -1;

    sal_strncpy(buf, output_filename, buf_len);

    return 0;
}


/****************************************************************************
 * Name		: ctcutil_log_set_flag
 * Purpose	: set log flag
 * Input	: flag: defined in ctcutil_log.h
 * Output	: n/a
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_set_flag(uint32 flag)
{
    if (!((flag & CTCUTIL_LOG_ADD_TIME)
          || (flag & CTCUTIL_LOG_PREFIX_SEPARATE)))
        return -1;

    log_flag = flag;

    return 0;
}


/****************************************************************************
 * Name		: ctcutil_log_get_flag
 * Purpose	: get log flag
 * Input	: n/a
 * Output	: p_flag: log flag
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_get_flag(uint32 *p_flag)
{
    if (!p_flag)
        return -1;

    *p_flag = log_flag;

    return 0;
}


/****************************************************************************
 * Name		: ctcutil_log_set_level
 * Purpose	: set module log level
 * Input	: module: defined in ctcutil_log.h
 *                level: defined in ctcutil_log.h
 * Output	: n/a
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_set_level(uint32 module, int32 level)
{
    if (module >= CTCUTIL_LOG_MAX_MODULE
        || level < 0
        || level >= CTCUTIL_LOG_MAX_LEVEL)
        return -1;

    module_log_level[module] = level;

    return 0;
}


/****************************************************************************
 * Name		: ctcutil_log_get_level
 * Purpose	: get module log level
 * Input	: module: defined in ctcutil_log.h
 * Output	: p_level: log_level
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_get_level(uint32 module, int32 *p_level)
{
    if (module >= CTCUTIL_LOG_MAX_MODULE
        || !p_level)
        return -1;

    *p_level = module_log_level[module];

    return 0;
}


/****************************************************************************
 * Name		: ctcutil_log_set_rotate_mode
 * Purpose	:
 * Input	:
 *
 * Output	:
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_set_rotate_mode(uint32 mode, int32 max_rotate_num,
                            uint32 sec, uint32 size)
{
    return 0;
}


/****************************************************************************
 * Name		: ctcutil_log_get_rotate_mode
 * Purpose	:
 * Input	:
 *
 * Output	:
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_get_rotate_mode(uint32 *p_mode, int32 *p_max_rotate_num,
                            uint32 *p_sec, uint32 *p_size)
{
    return 0;
}


/****************************************************************************
 * Name		: ctcutil_log_mem
 * Purpose	: log memory
 * Input	: module: as defined in ctcutil_log.h
 *                level:  as defined in ctcutil_log.h
 *                addr: point to memory address
 *                size: memory size
 * Output	:
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_mem(uint32 module, int32 level, void *addr, uint32 size)
{
    uint8 *p;
    int32 i;
    int32 n;
    int32 r;

    if (module >= CTCUTIL_LOG_MAX_MODULE
        || level < 0
        || level >= CTCUTIL_LOG_MAX_LEVEL)
        return -1;

    if (addr == NULL || size == 0)
        return -1;

    p = (uint8*)addr;

    n = size / 16;
    r = size % 16;

    for (i = 0; i < n; i++)
    {
        ctcutil_log(module, level,
                    "%02x %02x %02x %02x %02x %02x %02x %02x   "
                    "%02x %02x %02x %02x %02x %02x %02x %02x\n",
                    p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7],
                    p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15]);
        p += 16;
    }

    if (r > 8)
    {
        ctcutil_log(module, level,
                    "%02x %02x %02x %02x %02x %02x %02x %02x   ",
                    p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]);
        p += 8;

        for (i = 0; i < r - 8; i++)
            ctcutil_log(module, level, "%02x ", *p++);
        printf("\n");
    }
    else
    {
        for (i = 0; i < r; i++)
            ctcutil_log(module, level, "%02x ", *p++);
        printf("\n");
    }

    return 0;
}


#if 0
/****************************************************************************
 * Name		: ctcutil_log_mac
 * Purpose	: log a mac address
 * Input	: module: as defined in ctcutil_log.h
 *                level:  as defined in ctcutil_log.h
 *                mac: mac address to be print
 * Output	: n/a
 * Return	:
 * Note		:
 ****************************************************************************/
int32
ctcutil_log_mac(uint32 module, int32 level, mac_addr_t mac)
{
    uint8 *p;

    if (module >= CTCUTIL_LOG_MAX_MODULE
        || level < 0
        || level >= CTCUTIL_LOG_MAX_LEVEL)
        return -1;

    p = (uint8*)mac;
    ctcutil_log(module, level,
                "%02x:%02x:%02x:%02x:%02x:%02x",
                p[0], p[1], p[2], p[3], p[4], p[5]);

    return 0;
}


/****************************************************************************
 * Name		: ctcutil_mac_to_str
 * Purpose	: convert a mac address to a string
 * Input	: mac: mac address to be converted
 * Output	: n/a
 * Return	: the string
 * Note		:
 ****************************************************************************/
uint8 *
ctcutil_mac_to_str(mac_addr_t mac)
{
    static uint8 str[MAC_STR_LEN];

    uint8 *p = (uint8*)mac;

    sal_memset(str, 0, MAC_STR_LEN);
    sal_snprintf(str, MAC_STR_LEN, "%02x:%02x:%02x:%02x:%02x:%02x",
             p[0], p[1], p[2], p[3], p[4], p[5]);

    return str;
}
#endif

