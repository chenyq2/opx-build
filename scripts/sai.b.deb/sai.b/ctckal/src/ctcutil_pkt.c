/*****************************************************************************
 * ctcutil_pkt.c    packet generator
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:    V1.0
 * Author:      Hai Sun
 * Date:        2010-11-23
 * Reason:      Initial version
 *****************************************************************************/

#include "sal.h"
#include "ctckal.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <netinet/in.h>

#include "ctcutil_pkt.h"
#include "ctcutil_rand.h"

#define CRCPOLY_LE                      0xedb88320
#define CRCPOLY_BE                      0x04c11db7

/****************************************************************************
 * Name:       swap16
 * Purpose:    swap uint16 data.
 * Parameters:
 * Input:      data  -- pointer to uint32 data
 *             len   -- data length.
 *             direction -- swap direction.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *	       Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32
swap16(uint16 *data, int32 len, uint8 direction)
{
    int32 cnt;

    for (cnt = 0; cnt < len; cnt ++)
    {
        if (HOST_TO_NETWORK == direction)
        {
            data[cnt] = sal_htons(data[cnt]);
        }
        else
        {
            data[cnt] = sal_ntohs(data[cnt]);
        }
    }

    return 0;  /*DRV_E_NONE;*/
}

/****************************************************************************
 * Name:       swap32
 * Purpose:    swap uint32 data.
 * Parameters:
 * Input:      data  -- pointer to uint32 data
 *             len   -- data length.
 *             direction -- swap direction.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *	       Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32
swap32(uint32 *data, int32 len, uint8 direction)
{
    int32 cnt;

    for (cnt = 0; cnt < len; cnt ++)
    {
        if (HOST_TO_NETWORK == direction)
        {
            data[cnt] = sal_htonl(data[cnt]);
        }
        else
        {
            data[cnt] = sal_ntohl(data[cnt]);
        }
    }

    return 0;/*DRV_E_NONE;*/
}


/*****************************************************************************
 * calculate 32 bit crc
 *****************************************************************************/
static inline int32
_crc32_le(uint32 seed, unsigned char *data, uint32 data_len, uint32 *p_crc)
{
    uint32 crc;
    int32 i;

    crc = seed;

    while (data_len)
    {
        crc ^= *data;
        for (i = 0; i < 8; i++)
            crc = (crc >> 1) ^ ((crc & 1) ? CRCPOLY_LE : 0);
        data++;
        data_len--;
    }

    *p_crc = ~crc;

    return 0;
}

static inline int32
_crc32_be(uint32 seed, unsigned char *data, uint32 data_len, uint32 *p_crc)
{
    uint32 crc;
    int32 i;

    crc = seed;

    while (data_len)
    {
        crc ^= (*data << 24);
        for (i = 0; i < 8; i++)
            crc = (crc << 1) ^ ((crc & 0x80000000) ? CRCPOLY_BE : 0);
        data++;
        data_len--;
    }

    *p_crc = ~crc;

     return 0;
}


/*****************************************************************************
 * Name         : ctcutil_crc32
 * Purpose      : calculate crc32
 * Input        : seed: initial crc seed
 *                data: data buffer to be calculated
 *                data_len: data length
 * Output       : crc: calculated crc
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctcutil_crc32(uint32 seed, unsigned char *data, uint32 data_len, uint32 *p_crc)
{
    int32 ret;

    if (!data || data_len == 0 || !p_crc)
        return -1;

    if (CTC_HOST_IS_LITTLE_ENDIAN)
        ret = _crc32_le(seed, data, data_len, p_crc);
    else
        ret = _crc32_be(seed, data, data_len, p_crc);

    return ret;
}

// crc 16, used by oam to calculate ttsi hash
// by guhuade
int32 ctcutil_crc16(uint8* data, uint32 data_len, uint16* p_crc)
{
    uint16 crc_poly;
    uint16 crc = 0xFFFF;
    uint32 i;

    if (!data || data_len == 0 || !p_crc)
        return -1;

    if (CTC_HOST_IS_LITTLE_ENDIAN)
    {
        crc_poly = 0x1021;
        while (data_len)
        {
            crc ^= *data;
            for (i = 0; i < 8; i++)
            crc = (crc >> 1) ^ ((crc & 1) ? crc_poly : 0);
            data++;
            data_len--;
        }
    }
    else
    {
        crc_poly = 0x8408;
        while (data_len)
        {
            crc ^= (*data << 8);
            for (i = 0; i < 8; i++)
            crc = (crc << 1) ^ ((crc & 0x8000) ? crc_poly : 0);
            data++;
            data_len--;
        }
    }

    *p_crc = ~crc;

    return 0;

}

// added by guhuade
// calculate bip 16 for t-mpls oam pdu
int32 ctcutil_bip16(uint8* data, uint32 len, uint16* bip)
{
    uint32 i;
    *bip = 0;
    for (i = 0; i < len; i += 2)
    {
        *bip ^= MAKE_UINT16(*(data + i), *(data + i + 1));
    }

    return 0;
}

/****************************************************************************
 * Name:       ip_chksum
 * Purpose:    calculate ip checksum.
 * Parameters:
 * Input:      p points to ip header
 *             length is the header length
 *             init is the initial seed value for calculation
 * Output:     none.
 * Return:     0 = success. Otherwise failure.
 * Note:       none.
 ****************************************************************************/
uint16
ip_chksum (uint16 *p, uint16 length, uint16 init)
{
    uint32 sum = init;
    uint16 len = length >> 1;

    while (len-- > 0)
        sum += ctc_ntoh16(*p++);

    if (length & 1)
        sum += (*p & 0xFF00);

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);

    len = sum & 0xFFFF;
    return(~len);
}

/****************************************************************************
 * Name:       generate_random_pkt
 * Purpose:    generate fixed length packet randomly
 * Parameters:
 * Input:       *pkt -- the random pkt will be added there
 *             length -- payload length
 * Output:     none.
 * Return:     0 = success. Otherwise failure.
 * Note:       none.
 ****************************************************************************/
uint16
generate_random_pkt (uint8 **pkt, uint32 length)
{
    uint32 random;
    uint32 i;

    for (i = 0; i < length; i ++)
    {
        ctcutil_rand(0, 255, &random);
        **pkt = (uint8)random;
        (*pkt) ++;
    }

       return 0;
}

/****************************************************************************
 * Name		: strtoul
 * Purpose	: The function implement converting a string to long integer.
 * Input	: s: the source string to be converted;
 *                endptr : if endptr is not null, these functions set
 *                *endptr (the "next character pointer") to
 *                point to the character that stopped the
 *                scan (*endptr = &stopper).
 *                endptr is useful for error detection.
 *                radix : determine the base of the value being converted.
 * Output	:
 * Return	: 0xFFFFFFFF : invalid value;
 *		:
 * Note		:
 ****************************************************************************/
static __inline__ uint32
pkt_str2ul(char* s_start, char* s_end)
{
    char *str_temp = NULL;
    bool hex_bool;
    bool hex_temp1 = FALSE, hex_temp2 = FALSE, hex_temp3 = FALSE;
    int32 i = 0,k = 1;
    uint32 sum = 0;
    bool str_bool;

    if (!s_start)
        return 0;

    str_temp = s_start;
    if (!s_end)
        s_end = s_start + sal_strlen(s_start);

    if ('0' == *str_temp && 'x' == *(str_temp+1))
    {
        str_temp += 2;
        while (str_temp <= s_end && '\0' != *str_temp)
        {
            hex_temp1 = *str_temp >= 'a' && *str_temp <= 'f';
            hex_temp2 = *str_temp >= 'A' && *str_temp <= 'F';
            hex_temp3 = *str_temp >= '0' && *str_temp <= '9';
            hex_bool = hex_temp1 || hex_temp2 || hex_temp3;

            if (!hex_bool)
                return 0xFFFFFFFF;
            ++str_temp;
        }
        --str_temp;

        while (str_temp >= s_start && 'x'!= *str_temp)
        {
            hex_temp1 = *str_temp >= 'a' && *str_temp <= 'f';
            hex_temp2 = *str_temp >= 'A' && *str_temp <= 'F';
            hex_temp3 = *str_temp >= '0' && *str_temp <= '9';

            if (hex_temp1)
                i = (int32)(*str_temp - 'a') + 10;
            if (hex_temp2)
                i = (int32)(*str_temp - 'A') + 10;
            if (hex_temp3)
                i = (int32)(*str_temp - '0');

            sum = sum + i * k;
            k *= 16;
            --str_temp;
        }
        return sum;
    }

    while (str_temp <= s_end && '\0' != *str_temp)
    {
        str_bool = *str_temp >= '0' && *str_temp <= '9';
        if (str_bool)
        str_temp++;
        else
        return 0xFFFFFFFF;
    }
    --str_temp;
    while (str_temp >= s_start)
    {
        i = (int32)(*str_temp - '0');
        sum = sum + i * k;
        k *= 10;
        --str_temp;
    }

    return sum;
}


static __inline__ uint32
ipv4addr_to_uint(uint8* address)
{
    uint8* str;
    char addr_tmp[4][6];
    uint16 i = 0, j;
    uint32 value = 0, value_tmp;

    if (!address)
        return 0;

    for (i = 0; i < 4; i++)
        sal_memset(addr_tmp[i], 0, 6);

    str = address;
    i = 0;
    /*save the address to the string array addr_tmp*/
    while (0 != *str && '/' != *str)
    {
        if ('.' != *str)
        {
            j = 0;
            while (0 != *str && '/' != *str && '.' != *str)
            {
                if (i < 4 && j < 6)
                    addr_tmp[i][j++] = *str++;
                else
                    ++str;
            }

            ++i;
        }

        if (0 == *str || '/' == *str)
            break;

        ++str;
    }

    /*convert the addr_tmp string to unsigned long data type*/
    for (i = 0; i < 4; i++)
    {
        value_tmp = pkt_str2ul(addr_tmp[i], NULL);
        value = value | (value_tmp << (3-i)*8);
    }

    return value;
}


/******************************************************************************
 * Name   : memcpy_data
 * Purpose: copy data to memory location according to edian
 * Input  : p_pkt: address of memory pointer
 *          data:  points to data to be copied
 *          size:  data size
 * Output : p_pkt: memory pointer gets updated based on size
 * Return : SUCCESS
 *          Other = ErrCode
 * Note   : N/A
 *****************************************************************************/
int32
memcpy_data(uint8 **p_pkt, void *data, int32 size)
{
    uint8 *pkt = *p_pkt;

    if (size == 2)
    {
        if (is_little_endian)
            *(uint16*)data = CTC_SWAP16(*(uint16*)data);
        sal_memcpy(pkt, data, 2);
        pkt += 2;
    }
    else if (size == 3)
    {
        if (is_little_endian)
            *(uint32*)data = CTC_SWAP32(*(uint32*)data) >> 8;
        else
            *(uint32*)data >>= 8;
        sal_memcpy(pkt, data, 3);
        pkt += 3;
    }
    else if (size == 4)
    {
        if (is_little_endian)
            *(uint32*)data = CTC_SWAP32(*(uint32*)data);
        sal_memcpy(pkt, data, 4);
        pkt += 4;
    }
    *p_pkt = pkt;

    return 0;
}

