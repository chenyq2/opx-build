/****************************************************************************
 * ctckal_timer.c :         timer module
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "ctcutil_log.h"
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>

/*****************************************************************************
 * typdefs
 *****************************************************************************/
static bool ctckal_timer_activated;
static pthread_t timer_pthread;

enum timer_state_e
{
    TIMER_INVALID,
    TIMER_PENDING,
    TIMER_RUNNING,
    TIMER_STOPPED,
    TIMER_USER
};
typedef enum timer_state_e timer_state_t;


/* global timer storage */
struct timer_attr_s
{
    timer_state_t state;
    bool onetime;
    uint32 elapsed;
    uint32 remaining;
    struct timeval start;
    ctckal_timer_handler_t timer_handler;
    void *user_param;
};
typedef struct timer_attr_s timer_attr_t;

#define TIMER_STORAGE_SIZE 256  /* can be configured */
static timer_attr_t timer_storage[TIMER_STORAGE_SIZE];
static pthread_mutex_t timer_storage_mutex;


/*****************************************************************************
 * static function: substract two timeval: result = x - y
 *****************************************************************************/
static int32
substract_timeval(struct timeval *result,
                  struct timeval *x, struct timeval *y)
{
    if ((x->tv_sec < y->tv_sec)
        || ((x->tv_sec == y->tv_sec) && (x->tv_usec <= y->tv_usec)))
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "x:tv_sec %d, tv_usec %d; y:tv_sec %d, tv_usec %d\n",
                    x->tv_sec, x->tv_usec, y->tv_sec, y->tv_usec);
        return CTCKAL_ERR_PARAM;
    }

    if (x->tv_usec > y->tv_usec)
        result->tv_usec = x->tv_usec - y->tv_usec;
    else
    {
        result->tv_usec = x->tv_usec + 1000000 - y->tv_usec;
        result->tv_sec = x->tv_sec - y->tv_sec;
    }

    return CTCKAL_SUCCESS;
}


/*****************************************************************************
 * static function: get a timer storage cell
 *****************************************************************************/
static int32
get_timer(void)
{
    int32 i;

    for (i = 0; i < TIMER_STORAGE_SIZE; i++)
    {
        if (timer_storage[i].state == TIMER_INVALID)
        {
            timer_storage[i].state = TIMER_PENDING;
            break;
        }
    }

    if (i == TIMER_STORAGE_SIZE)
        return -1;

    return i;
}


/*****************************************************************************
 * static function: reset the timer to 0, start running
 *****************************************************************************/
static int32
reset_timer(timer_attr_t *timer_attr)
{
    int32 ret;
    struct timezone tz;

    timer_attr->remaining = timer_attr->elapsed;

    ret = gettimeofday(&timer_attr->start, &tz);
    if (ret != 0)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "gettimeofday: %d\n", ret);
        timer_attr->state = TIMER_INVALID;
        return CTCKAL_ERR_SYSTEM;
    }

    timer_attr->state = TIMER_RUNNING;

    return CTCKAL_SUCCESS;
}


#if 0
/*****************************************************************************
 * static function: thread function to call user handling function and than
 *                  reset the timer if it's a recurrent timer
 *****************************************************************************/
static void *
ctckal_timer_worker_func(void *param)
{
    int32 ret;
    int32 idx;

    idx = (int32)param;

    timer_storage[idx].timer_handler((ctckal_timer_t)idx,
                                     timer_storage[idx].user_param);
    if (timer_storage[idx].onetime)
    {
        timer_storage[idx].state = TIMER_INVALID;
    }
    else
    {
        ret = reset_timer(&timer_storage[idx]);
        if (ret != CTCKAL_SUCCESS)
            return NULL;
    }

    return NULL;
}
#endif


/*****************************************************************************
 * static function: check whether a timer is expired
 *****************************************************************************/
static inline int32
check_expiration(int32 idx, struct timeval *current)
{
    int32 sec, usec;
    int32 expire_sec, expire_usec;

    sec = timer_storage[idx].remaining / 1000;
    usec = (timer_storage[idx].remaining % 1000) * 1000;

    expire_sec = timer_storage[idx].start.tv_sec + sec;
    expire_usec = timer_storage[idx].start.tv_usec + usec;
    if (expire_usec > 1000000)
    {
        expire_usec -= 1000000;
        expire_sec++;
    }

    if (current->tv_sec > expire_sec)
        return TRUE;
    else if (current->tv_sec == expire_sec
             && current->tv_usec > expire_usec)
        return TRUE;

    return FALSE;
}


/*****************************************************************************
 * static function: update all active timers, check whether they are expired
 *****************************************************************************/
static inline int32
update_timers(struct timeval *current)
{
    int32 ret;
    bool expired;
    int32 i;
    /*pthread_t pthread;*/

    for (i = 0; i < TIMER_STORAGE_SIZE; i++)
    {
        if (timer_storage[i].state != TIMER_RUNNING)
            continue;

        expired = check_expiration(i, current);
        if (expired)
        {
            if (!ctckal_timer_activated)
            {
                ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_CRITICAL,
                            "!ctckal_timer_activated");
                return CTCKAL_ERR_INTERNAL;
            }

            /*
            timer_storage[i].state = TIMER_USER;
            ret = pthread_create(&pthread, NULL,
                                 ctckal_timer_worker_func, (void*)i);
            if (ret != 0)
            {
                printf("pthread_create failed\n");
                perror();
                return CTCKAL_ERR_SYSTEM;
            }
            */
            timer_storage[i].timer_handler((ctckal_timer_t)i,
                                           timer_storage[i].user_param);
            if (timer_storage[i].onetime)
            {
                timer_storage[i].state = TIMER_INVALID;
            }
            else
            {
                ret = reset_timer(&timer_storage[i]);
                if (ret != CTCKAL_SUCCESS)
                    return CTCKAL_ERR_INTERNAL;
            }
        }
    }

    return CTCKAL_SUCCESS;
}


/*****************************************************************************
 * static function: thread function to keep checking all the timers
 *****************************************************************************/
static void *
ctckal_timer_func(void *param)
{
    int32 ret;
    struct timeval current;
    struct timezone tz;

    while (ctckal_timer_activated)
    {
        usleep(1000);

        ret = gettimeofday(&current, &tz);
        if (ret != 0)
        {
            ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                        "gettimeofday: %d\n", ret);
            ctckal_timer_activated = FALSE;
            return NULL;
        }

        ret = update_timers(&current);
        if (ret != CTCKAL_SUCCESS)
        {
            ctckal_timer_activated = FALSE;
            return NULL;
        }
    }

    return NULL;
}


/*****************************************************************************
 * static function: activate timer thread to start checking all the timers
 *****************************************************************************/
static inline int32
activate_timer(void)
{
    pthread_attr_t attr;
    int32 ret;

    ctckal_timer_activated = TRUE;

    /* create a thread for the timer */
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 16*1024);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    ret = pthread_create(&timer_pthread, &attr, ctckal_timer_func, NULL);
    if (ret != 0)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "pthread_create: %d\n", ret);
        ctckal_timer_activated = FALSE;
        return CTCKAL_ERR_SYSTEM;
    }

    return CTCKAL_SUCCESS;
}


/*****************************************************************************
 * Name         : ctckal_timer_create
 * Purpose      : create a timer
 * Input        : onetime: if 1, it's a one-time timer
 *                         if 0, it's a recurrent timer
 *                elapsed: the expiration time of the timer
 *                timer_handler: user handler when timer expires
 *                user_param: solo user parameter to the user handling func
 * Output       : timer: a timer hanle can be used by subsequent functions
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_timer_create(ctckal_timer_t *timer,
                    bool onetime, uint32 elapsed,
                    ctckal_timer_handler_t timer_handler, void *user_param)
{
    int32 ret;
    int32 idx;
    struct timezone tz;

     /* anchor added for close timer */
    /*if(!use_ctckal)
    {
        return CTCKAL_SUCCESS;
    }*/

    ret = CTCKAL_SUCCESS;
    idx = -1;

    pthread_mutex_lock(&timer_storage_mutex);

    if (timer == NULL || timer_handler == NULL)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: timer = %p, timer_handler = %p\n",
                    (uintptr)timer, (uintptr)timer_handler);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    idx = get_timer();
    if (idx < 0)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_CRITICAL,
                    "thread resource exhausted\n");
        ret = CTCKAL_ERR_RESOURCE;
        goto ERROR;
    }

    timer_storage[idx].onetime = onetime;
    timer_storage[idx].elapsed = elapsed;
    timer_storage[idx].remaining = elapsed;
    timer_storage[idx].timer_handler = timer_handler;
    timer_storage[idx].user_param = user_param;
    timer_storage[idx].state = TIMER_RUNNING;
    ret = gettimeofday(&timer_storage[idx].start, &tz);
    if (ret != 0)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "gettimeofday: %d\n", ret);
        ret = CTCKAL_ERR_SYSTEM;
        goto ERROR;
    }

    *timer = (ctckal_timer_t)idx;

    if (!ctckal_timer_activated)
    {
        ret = activate_timer();
        if (ret != CTCKAL_SUCCESS)
        {
            ret = CTCKAL_ERR_INTERNAL;
            goto ERROR;
        }
    }

    pthread_mutex_unlock(&timer_storage_mutex);
    return ret;

ERROR:
    if (idx >= 0)
        timer_storage[idx].state = TIMER_INVALID;
    pthread_mutex_unlock(&timer_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_timer_destroy
 * Purpose      : destroy a timer
 * Input        : timer: the timer created by ctckal_timer_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void
ctckal_timer_destroy(ctckal_timer_t timer)
{
    int32 idx;
    int32 i;

    pthread_mutex_lock(&timer_storage_mutex);

    idx = (int32)timer;
    if (idx < 0 || idx >= TIMER_STORAGE_SIZE
        || timer_storage[idx].state == TIMER_INVALID)
        goto ERROR;

    timer_storage[idx].state = TIMER_INVALID;

    for (i = 0; i < TIMER_STORAGE_SIZE; i++)
    {
        if (timer_storage[i].state != TIMER_INVALID)
            goto ERROR;
    }

    ctckal_timer_activated = FALSE;

    pthread_mutex_unlock(&timer_storage_mutex);
    return;

ERROR:
    pthread_mutex_unlock(&timer_storage_mutex);
}


/*****************************************************************************
 * Name         : ctckal_timer_set_onetime
 * Purpose      : make the timer a one-time timer or a recurrent timer
 * Input        : timer: the timer created by ctckal_timer_create
 *                onetime: if TRUE, make it a one-time timer
 *                         if FALSE, make it a recurrent timer
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_timer_set_onetime(ctckal_timer_t timer, bool onetime)
{
    int32 ret;
    int32 idx;

    ret = CTCKAL_SUCCESS;

    pthread_mutex_lock(&timer_storage_mutex);

    idx = (int32)timer;
    if (idx < 0 || idx >= TIMER_STORAGE_SIZE)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: idx = %d\n", idx);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    if (timer_storage[idx].state == TIMER_INVALID)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: timer state = %ld\n", timer_storage[idx].state);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    timer_storage[idx].onetime = onetime;

    pthread_mutex_unlock(&timer_storage_mutex);
    return CTCKAL_SUCCESS;

ERROR:
    pthread_mutex_unlock(&timer_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_timer_set_elapsed
 * Purpose      : set expiration time
 * Input        : timer: the timer created by ctckal_timer_create
 *                elapsed: the expiration time in ms
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_timer_set_elapsed(ctckal_timer_t timer, uint32 elapsed)
{
    int32 ret;
    int32 idx;

    ret = CTCKAL_SUCCESS;

    pthread_mutex_lock(&timer_storage_mutex);

    idx = (int32)timer;
    if (idx < 0 || idx >= TIMER_STORAGE_SIZE)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: idx = %d\n", idx);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    if (timer_storage[idx].state == TIMER_INVALID)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: timer state = %ld\n", timer_storage[idx].state);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    timer_storage[idx].elapsed = elapsed;

    pthread_mutex_unlock(&timer_storage_mutex);
    return CTCKAL_SUCCESS;

ERROR:
    pthread_mutex_unlock(&timer_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_timer_reset
 * Purpose      : reset the timer, ie, re-start
 * Input        : timer: the timer handle created by ctckal_timer_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_timer_reset(ctckal_timer_t timer)
{
    int32 ret;
    int32 idx;

    ret = CTCKAL_SUCCESS;

    pthread_mutex_lock(&timer_storage_mutex);

    idx = (int32)timer;
    if (idx < 0 || idx >= TIMER_STORAGE_SIZE)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: idx = %d\n", idx);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    if (timer_storage[idx].state != TIMER_RUNNING
        && timer_storage[idx].state != TIMER_STOPPED)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: timer state = %ld\n", timer_storage[idx].state);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    idx = (int32)timer;

    ret = reset_timer(&timer_storage[idx]);
    if (ret != CTCKAL_SUCCESS)
    {
        ret = CTCKAL_ERR_INTERNAL;
        goto ERROR;
    }

    pthread_mutex_unlock(&timer_storage_mutex);
    return CTCKAL_SUCCESS;

ERROR:
    pthread_mutex_unlock(&timer_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_timer_stop
 * Purpose      : temporally stop the timer, but not reset it
 * Input        : timer: the timer handle created by ctckal_timer_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_timer_stop(ctckal_timer_t timer)
{
    int32 ret;
    int32 idx;
    struct timeval current;
    struct timezone tz;
    struct timeval result = {0};

    ret = CTCKAL_SUCCESS;

    pthread_mutex_lock(&timer_storage_mutex);

    idx = (int32)timer;
    if (idx < 0 || idx >= TIMER_STORAGE_SIZE)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: idx = %d\n", idx);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    if (timer_storage[idx].state != TIMER_RUNNING)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: timer state = %ld\n", timer_storage[idx].state);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    ret = gettimeofday(&current, &tz);
    if (ret != 0)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "gettimeofday: %d\n", ret);
        ret = CTCKAL_ERR_SYSTEM;
        goto ERROR;
    }

    ret = substract_timeval(&result, &current, &timer_storage[idx].start);
    if (ret != CTCKAL_SUCCESS)
    {
        ret = CTCKAL_ERR_INTERNAL;
        goto ERROR;
    }

    timer_storage[idx].remaining -= ((result.tv_sec * 1000)
                                     + (result.tv_usec / 1000));
    timer_storage[idx].state = TIMER_STOPPED;

    pthread_mutex_unlock(&timer_storage_mutex);
    return CTCKAL_SUCCESS;

ERROR:
    pthread_mutex_unlock(&timer_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_timer_resume
 * Purpose      : resume the timer that was previously stopped
 * Input        : timer: the timer handle created by ctckal_timer_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_timer_resume(ctckal_timer_t timer)
{
    int32 ret;
    int32 idx;
    struct timezone tz;

    ret = CTCKAL_SUCCESS;

    pthread_mutex_lock(&timer_storage_mutex);

    idx = (int32)timer;
    if (idx < 0 || idx >= TIMER_STORAGE_SIZE)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: idx = %d\n", idx);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    if (timer_storage[idx].state != TIMER_STOPPED)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "Error: timer state = %ld\n", timer_storage[idx].state);
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    ret = gettimeofday(&timer_storage[idx].start, &tz);
    if (ret != 0)
    {
        ctcutil_log(CTCUTIL_LOG_SAL, CTCUTIL_LOG_ERROR,
                    "gettimeofday: %d\n", ret);
        ret = CTCKAL_ERR_SYSTEM;
        goto ERROR;
    }

    timer_storage[idx].state = TIMER_RUNNING;

    pthread_mutex_unlock(&timer_storage_mutex);
    return CTCKAL_SUCCESS;

ERROR:
    pthread_mutex_unlock(&timer_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_timer_init
 * Purpose      : initialize the timer module
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_timer_init(void)
{
    pthread_mutex_init(&timer_storage_mutex, NULL);

    return CTCKAL_SUCCESS;
}


/*****************************************************************************
 * Name         : ctckal_timer_exit
 * Purpose      : de-initialize the timer module
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void
ctckal_timer_exit(void)
{
    pthread_mutex_destroy(&timer_storage_mutex);

    ctckal_timer_activated = FALSE;
}
