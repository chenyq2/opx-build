/****************************************************************************
 * ctckal_mutex.c :         mutex module
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include <pthread.h>

/* todo: more on mutex attribute */


/*****************************************************************************
 * typedefs
 *****************************************************************************/
enum mutex_state_e
{
    INVALID,
    PENDING,
    USING
};
typedef enum mutex_state_e mutex_state_t;

struct mutex_storage_cell_s
{
    mutex_state_t state;
    pthread_mutex_t mutex;
    /*pthread_mutexattr_t mutex_attr;*/
};
typedef struct mutex_storage_cell_s mutex_storage_cell_t;

#define MUTEX_STORAGE_SIZE 0x8000  /* can be configured */
static mutex_storage_cell_t mutex_storage[MUTEX_STORAGE_SIZE];
static pthread_mutex_t mutex_storage_mutex;


/*****************************************************************************
 * static function: get a mutex storage cell
 *****************************************************************************/
static int32
get_mutex_cell(void)
{
    int32 i;

    for (i = 0; i < MUTEX_STORAGE_SIZE; i++)
    {
        if (mutex_storage[i].state == INVALID)
        {
            mutex_storage[i].state = PENDING;
            return i;
        }
    }

    return -1;
}


/*****************************************************************************
 * Name         : ctckal_mutex_create
 * Purpose      : create a mutex
 * Input        :
 * Output       : mutex: the mutex handle can be used by other function
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_mutex_create(ctckal_mutex_t *mutex)
{
    int32 ret;
    int32 idx;

    ret = CTCKAL_SUCCESS;

    pthread_mutex_lock(&mutex_storage_mutex);

    /* check parameters */
    if (mutex == NULL)
    {
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    idx = get_mutex_cell();
    if (idx < 0)
    {
        ret = CTCKAL_ERR_RESOURCE;
        goto ERROR;
    }

    ret = pthread_mutex_init(&mutex_storage[idx].mutex, NULL);
    if (ret != 0)
    {
        mutex_storage[idx].state = INVALID;
        ret = CTCKAL_ERR_SYSTEM;
        goto ERROR;
    }

    mutex_storage[idx].state = USING;

    pthread_mutex_unlock(&mutex_storage_mutex);

    *mutex = (ctckal_mutex_t)idx;

    return CTCKAL_SUCCESS;

ERROR:
    pthread_mutex_unlock(&mutex_storage_mutex);
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_mutex_destroy
 * Purpose      : destroy the mutex
 * Input        : mutex: mutex handle returned by ctckal_mutex_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void
ctckal_mutex_destroy(ctckal_mutex_t mutex)
{
    int32 idx;

    pthread_mutex_lock(&mutex_storage_mutex);

    idx = (int32)mutex;
    if (idx < 0 || idx >= MUTEX_STORAGE_SIZE
        || mutex_storage[idx].state != USING)
        goto ERROR;

    pthread_mutex_destroy(&mutex_storage[idx].mutex);
    mutex_storage[idx].state = INVALID;

    pthread_mutex_unlock(&mutex_storage_mutex);
    return;

ERROR:
    pthread_mutex_unlock(&mutex_storage_mutex);
}


/*****************************************************************************
 * Name         : ctckal_mutex_take
 * Purpose      : obtain a mutex
 * Input        : mutex: mutex handle returned by ctckal_mutex_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_mutex_take(ctckal_mutex_t mutex)
{
    int32 ret;
    int32 idx;

    ret = CTCKAL_SUCCESS;

    idx = (int32)mutex;
    if (idx < 0 || idx >= MUTEX_STORAGE_SIZE
        || mutex_storage[idx].state != USING)
    {
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    ret = pthread_mutex_lock(&mutex_storage[idx].mutex);
    if (ret != 0)
    {
        ret = CTCKAL_ERR_SYSTEM;
        goto ERROR;
    }

    return CTCKAL_SUCCESS;

ERROR:
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_mutex_give
 * Purpose      : release a mutex
 * Input        : mutex: mutex handle returned by ctckal_mutex_create
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_mutex_give(ctckal_mutex_t mutex)
{
    int32 ret;
    int32 idx;

    ret = CTCKAL_SUCCESS;

    idx = (int32)mutex;
    if (idx < 0 || idx >= MUTEX_STORAGE_SIZE
        || mutex_storage[idx].state != USING)
    {
        ret = CTCKAL_ERR_PARAM;
        goto ERROR;
    }

    ret = pthread_mutex_unlock(&mutex_storage[idx].mutex);
    if (ret != 0)
    {
        ret = CTCKAL_ERR_SYSTEM;
        goto ERROR;
    }

    return CTCKAL_SUCCESS;

ERROR:
    return ret;
}


/*****************************************************************************
 * Name         : ctckal_mutex_init
 * Purpose      : initialize the mutex module
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
int32
ctckal_mutex_init(void)
{
    pthread_mutex_init(&mutex_storage_mutex, NULL);

    return CTCKAL_SUCCESS;
}


/*****************************************************************************
 * Name         : ctckal_mutex_exit
 * Purpose      : de-initialize the mutex module
 * Input        :
 * Output       :
 * Return       :
 * Note         :
 *****************************************************************************/
void
ctckal_mutex_exit(void)
{
    int32 i;

    for (i = 0; i < MUTEX_STORAGE_SIZE; i++)
    {
        if (mutex_storage[i].state != INVALID)
            pthread_mutex_destroy(&mutex_storage[i].mutex);
    }

    pthread_mutex_destroy(&mutex_storage_mutex);
}
