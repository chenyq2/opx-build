/****************************************************************************
 * ctckal_thread.h :         thread module header
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#ifndef _CTCKAL_THREAD_H_
#define _CTCKAL_THREAD_H_

typedef uint32 ctckal_thread_t;
typedef void *ctckal_thread_attr_t;
typedef void (*ctckal_thread_func_t)(ctckal_thread_t thread,
                                     void *user_param);

int32 ctckal_thread_init(void);
void ctckal_thread_exit(void);
int32 ctckal_thread_create(ctckal_thread_t *thread,
                           ctckal_thread_attr_t thread_attr,
                           ctckal_thread_func_t thread_func, void *user_param);
void ctckal_thread_destroy(ctckal_thread_t thread);


#endif  /* _CTCKAL_THREAD_H_ */
