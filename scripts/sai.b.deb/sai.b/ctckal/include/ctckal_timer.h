/****************************************************************************
 * ctckal_timer.h :         timer module header
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#ifndef _CTCKAL_TIMER_H_
#define _CTCKAL_TIMER_H_

typedef uint32 ctckal_timer_t;
typedef void (*ctckal_timer_handler_t)(ctckal_timer_t timer,
                                       void *user_param);

int32 ctckal_timer_init(void);
void ctckal_timer_exit(void);
int32 ctckal_timer_create(ctckal_timer_t *timer,
                        bool onetime, uint32 elapsed,
                        ctckal_timer_handler_t timer_handler,
                        void *user_param);
void ctckal_timer_destroy(ctckal_timer_t timer);
int32 ctckal_timer_set_onetime(ctckal_timer_t timer, bool onetime);
int32 ctckal_timer_set_elapsed(ctckal_timer_t timer, uint32 elapsed);
int32 ctckal_timer_reset(ctckal_timer_t timer);
int32 ctckal_timer_stop(ctckal_timer_t timer);
int32 ctckal_timer_resume(ctckal_timer_t timer);


#endif  /* _CTCKAL_TIMER_H_ */
