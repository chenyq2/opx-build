/****************************************************************************
 * ctckal_event.h :         event module header
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History :
 * Revision       :         V1.0
 * Author         :         Jack Yang
 * Date           :         2010-7-28
 * Reason         :         First Create
 ****************************************************************************/
#ifndef _CTCKAL_EVENT_H_
#define _CTCKAL_EVENT_H_

/*
 * event status
 */
#define STATUS_NON_SIGNALED   0
#define STATUS_SIGNALED       1
#define STATUS_TIMEOUT        2

#define TIMEOUT_INFINITE      0xffffffff

/*
 * event attribute
 */
#define ATTR_AUTO_RESET       0
#define ATTR_MANUAL_RESET     1

typedef sal_event_t *ctckal_event_t;
typedef uint32 ctckal_event_attr_t;


int32 ctckal_event_init(void);
void ctckal_event_exit(void);
int32 ctckal_event_create(ctckal_event_t *event,
                          ctckal_event_attr_t event_attr);
void ctckal_event_destroy(ctckal_event_t event);
int32 ctckal_event_set(ctckal_event_t event);
int32 ctckal_event_reset(ctckal_event_t event);
int32 ctckal_event_wait(ctckal_event_t event, uint32 timeout,
                        int32 *event_status);

#endif  /* _CTCKAL_EVENT_H_ */
