/*****************************************************************************
 * ctcutil_pkt.h      packet generator
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:    V1.0
 * Author:      Jack Yang
 * Date:        2010-08-16
 * Reason:      Initial version
 *****************************************************************************/
#ifndef _CTCUTIL_PKT_H_
#define _CTCUTIL_PKT_H_

#include "sal.h"

#define MAX_MPLS_LABELS 10
#define MAX_NUM_IGMP_V3_SRC_ADDRESS 10

/* byte operation macros */
#define MAKE_UINT16(hb, lb) (((hb) << 8) | (lb))
#define MAKE_UINT32(b3, b2, b1, b0) (((b3) << 24) | ((b2) << 16)\
                                       | ((b1) << 8) | (b0))
enum swap_direction
{
    HOST_TO_NETWORK,
    NETWORK_TO_HOST
};

/*
 * exported function prototypes
 */
extern int32 swap32(uint32 *data, int32 len, uint8 direction);
extern int32 swap16(uint16 *data, int32 len, uint8 direction);
extern uint16 ip_chksum (uint16 *dp, uint16 length, uint16 init);
extern int32 ctcutil_crc32(uint32 seed, unsigned char *data, uint32 data_len, uint32 *p_crc);
extern int32 memcpy_data(uint8 **p_pkt, void *data, int32 size);
extern int32 ctcutil_crc16(uint8* data, uint32 data_len, uint16* p_crc);
extern int32 ctcutil_bip16(uint8* data, uint32 len, uint16* bip);

#endif
