/****************************************************************************
 * ctc_endian.h : byte order swapping
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision     : V1.0
 * Author       : Jack Yang
 * Date         : 2010-8-5
 ****************************************************************************/
#ifndef _CTC_ENDIAN_H_
#define _CTC_ENDIAN_H_

#if (HOST_IS_LE == 1)
#define CTC_HOST_IS_BIG_ENDIAN          FALSE
#define CTC_HOST_IS_LITTLE_ENDIAN       TRUE
#else
#define CTC_HOST_IS_BIG_ENDIAN          TRUE
#define CTC_HOST_IS_LITTLE_ENDIAN       FALSE
#endif


#if CTC_HOST_IS_BIG_ENDIAN
static bool is_big_endian __attribute__((unused)) = TRUE;
static bool is_little_endian __attribute__((unused)) = FALSE;
#else
static bool is_big_endian __attribute__((unused)) = FALSE;
static bool is_little_endian __attribute__((unused)) = TRUE;
#endif


/*
 * byte swapping macros
 */
#define CTC_SWAP16(x) ((((uint16)(x) & (uint16)0x00ff) << 8) \
                      | (((uint16)(x) & (uint16)0xff00) >> 8))

#define CTC_SWAP32(x) ((((uint32)(x) & (uint32)0x000000ff) << 24) \
                      | (((uint32)(x) & (uint32)0x0000ff00) << 8) \
                      | (((uint32)(x) & (uint32)0x00ff0000) >> 8) \
                      | (((uint32)(x) & (uint32)0xff000000) >> 24))

#define CTC_SWAP64(x) \
        ((((uint64)(x) & (uint64)0x00000000000000ffULL) << 56)  \
        | (((uint64)(x) & (uint64)0x000000000000ff00ULL) << 40) \
        | (((uint64)(x) & (uint64)0x0000000000ff0000ULL) << 24) \
        | (((uint64)(x) & (uint64)0x00000000ff000000ULL) << 8)  \
        | (((uint64)(x) & (uint64)0x000000ff00000000ULL) >> 8)  \
        | (((uint64)(x) & (uint64)0x0000ff0000000000ULL) >> 24) \
        | (((uint64)(x) & (uint64)0x00ff000000000000ULL) >> 40) \
        | (((uint64)(x) & (uint64)0xff00000000000000ULL) >> 56))


static inline uint16 ctc_ntoh16(uint16 x)
{
    if (CTC_HOST_IS_LITTLE_ENDIAN)
        return CTC_SWAP16(x);
    else
        return x;
}


static inline uint32 ctc_ntoh32(uint32 x)
{
    if (CTC_HOST_IS_LITTLE_ENDIAN)
        return CTC_SWAP32(x);
    else
        return x;
}


static inline uint64 ctc_ntoh64(uint64 x)
{
    if (CTC_HOST_IS_LITTLE_ENDIAN)
        return CTC_SWAP64(x);
    else
        return x;
}


static inline uint16 ctc_hton16(uint16 x)
{
    if (CTC_HOST_IS_LITTLE_ENDIAN)
        return CTC_SWAP16(x);
    else
        return x;
}


static inline uint32 ctc_hton32(uint32 x)
{
    if (CTC_HOST_IS_LITTLE_ENDIAN)
        return CTC_SWAP32(x);
    else
        return x;
}


static inline uint64 ctc_hton64(uint64 x)
{
    if (CTC_HOST_IS_LITTLE_ENDIAN)
        return CTC_SWAP64(x);
    else
        return x;
}


#endif  /* _CTC_ENDIAN_H_ */
