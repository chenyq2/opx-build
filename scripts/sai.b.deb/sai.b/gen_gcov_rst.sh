#!/bin/bash

## usage:
#1. vi TheGrandCanal/cmodel/mk/cmodel_sys.mk, modify: IS_GCOV = yes
#2. vi TheGrandCanal/sdk/mk/sys.mk, modify: IS_GCOV = yes
#3. in sdk dir: rm build.i686.d -rf , delete old sdk compile gen-file
#4. bds re-compile
#5. regression test cases
#6. in TheGrandCanal/cmodel: ./gen_gcov_rst.sh>gcov_log.txt
#7. in software/Code/gcov_result: gcov's result
#8. please don't forget to modify back #1 and #2 .mk

mkdir -p ../../gcov_result
mkdir -p ../../gcov_result/ipe
mkdir -p ../../gcov_result/oam
mkdir -p ../../gcov_result/epe
mkdir -p ../../gcov_result/qmgt
mkdir -p ../../gcov_result/common

gcov -f greatbelt/src/ipe/cm_ipe_*.c -o ~/software/Code/TheGrandCanal/sdk/build.i686.d/obj.ctc-sim/greatbelt/src/ipe/
mv cm_ipe_*.c.gcov ../../gcov_result/ipe

gcov -f greatbelt/src/common/cm_com_*.c --object-directory ~/software/Code/TheGrandCanal/sdk/build.i686.d/obj.ctc-sim/greatbelt/src/common/
mv cm_com_*.c.gcov ../../gcov_result/common
mv *.h.gcov ../../gcov_result/common

gcov -f greatbelt/src/epe/cm_epe_*.c -o ~/software/Code/TheGrandCanal/sdk/build.i686.d/obj.ctc-sim/greatbelt/src/epe/
mv cm_epe_*.c.gcov ../../gcov_result/epe

gcov -f greatbelt/src/oam/cm_oam_*.c -o ~/software/Code/TheGrandCanal/sdk/build.i686.d/obj.ctc-sim/greatbelt/src/oam/
mv cm_oam_*.c.gcov ../../gcov_result/oam

gcov -f greatbelt/src/qmgt/cm_qmgt_*.c -o ~/software/Code/TheGrandCanal/sdk/build.i686.d/obj.ctc-sim/greatbelt/src/qmgt
mv cm_qmgt_*.c.gcov ../../gcov_result/qmgt

#rm *.gcov
