/****************************************************************************
 * sim_oam_interface.h
 *
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V4.29.3.
 * Author:       ZhouW
 * Date:         2011-11-12
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#ifndef _SIM_OAM_INTERFACE_H_
#define _SIM_OAM_INTERFACE_H_

#include "sim_common.h"

extern int32
cosim_do_oam(uint32 chipid, uint32 chanid, uint32 pkt_len, uint8 *pkt);

extern int32 sim_store_oam_ha2pp_bus(void *in_pkt);
extern int32 sim_store_oam_pp2fw_bus(void *in_pkt);
extern int32 sim_store_oam_pr2pp_bus(void *in_pkt);

extern int32 cosim_oam_ha2pp_verify(void *bus, bool *succ);
extern int32 cosim_oam_pp2fw_verify(void *bus, bool *succ);
extern int32 cosim_oam_pr2pp_verify(void *bus, bool *succ);
extern int32
cosim_oam_engine_update(uint32 chip_id, uint32 times, cosim_oam_update_type_t update_tp,
                        uint32 min_ptr, uint32 max_ptr);

#endif

