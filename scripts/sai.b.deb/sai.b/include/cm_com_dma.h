/****************************************************************************
 * cm_com_dma.h  DMA for ASIC C-Model.
 * Copyright:      (c)2012 Centec Networks Inc. All rights reserved.
 *
 * Revision:        V1.0.
 * Author:         kcao.
 * Date:           2012-12-08.
 * Reason:         First Create.
 ****************************************************************************/
#ifndef _CM_COM_DMA_H_
#define _CM_COM_DMA_H_

#if (__WORDSIZE == 64)
#define CM_COMBINE_64BITS_DATA(high, low, data) \
    {  \
        (data) = high; \
        (data) = (data <<32) | (uint32)(low); \
    }
#else
#define CM_COMBINE_64BITS_DATA(high, low, data) \
    {  \
        (data) = low; \
    }
#endif

/****************************************************************************
 *
* Header Files
*
****************************************************************************/

/****************************************************************************
 *
* Defines and Macros
*
****************************************************************************/

/****************************************************************************
 *
* Global and Declarations
*
****************************************************************************/
int32
cm_sim_dma_tx_pkt(out_pkt_t* p_pkt);

void
cm_sim_dma_engine();

#endif


