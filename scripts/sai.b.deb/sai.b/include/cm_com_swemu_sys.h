/***************************************************************************
 * cm_com_emu_sys.h: provides emulation do foward interface.
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Revision:      V1.0.
 * Author:       Zhouw
 * Date:         2010-11-1.
 * Reason:       First Create.
 *
 * Modify History:
****************************************************************************/
#ifndef _CM_COM_EMU_SYS_H_
#define _CM_COM_EMU_SYS_H_

/***************************************************************************
 *
 * Header Files
 *
***************************************************************************/
#include "cm_com_engine.h"
#include "cm_com_common.h"

/***************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/
#define MAX_ETH_NAME_LEN    10
#define PKT_BUFFER_SIZE  (1024*9+64)
#define CM_PKT_MIN_SIZE     64

enum um_emu_mode_e
{
    UM_EMU_MODE_SDK,
    UM_EMU_MODE_CMODEL,
    UM_EMU_MODE_NUM
};
typedef enum um_emu_mode_e um_emu_mode_t;

struct mac_descriptor_s
{
    bool valid;
    queue_type_t queue_type;
    uint32 eth_if_id;
    int32 sock;
    bool error_sock;
};
typedef struct mac_descriptor_s mac_descriptor_t;

/***************************************************************************
 *
 * Global and Declarations
 *
***************************************************************************/
int32 g_pkt_cnt_rx[MAX_MACNUM];
int32 g_pkt_cnt_tx[MAX_MACNUM];

/***************************************************************************
 *
 * Functions
 *
****************************************************************************/
extern int32 swemu_socket_init(void);
extern void swemu_ios_netrx_engine();
extern void swemu_ios_nettx_engine();
extern int32 swemu_environment_setting(char *filename);
extern int32 swemu_read_profile_string_atrim(char*, const char*);
extern int32 swemu_receive_packet_from_board(void);
extern int32 swemu_send_packet_to_board(void);
extern int32 swemu_socket_init_board(void);
#endif

