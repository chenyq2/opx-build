/****************************************************************************
 * cm_ipe.h  All packet type Deinfines.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0
 * Author:
 * Date:         2010-10-10.
 * Reason:       First Create.
 ****************************************************************************/
#ifndef _CM_IPE_H_
#define _CM_IPE_H_

#include "cm_com_common.h"
#include "cm_com_sgmac_info.h"
/****************************************************************************
 *
* Defines and Macros
*
****************************************************************************/
/* MsPacketHeader operation type definition */
enum operation_type_e
{
    OPERATION_TYPE_NORMAL,            /* 0 */
    OPERATION_TYPE_LM_TX,             /* 1 */
    OPERATION_TYPE_PBB,               /* 2 */
    OPERATION_TYPE_DM_TX,             /* 3 */
    OPERATION_TYPE_C2C,               /* 4 */
    OPERATION_TYPE_PTP,               /* 5 */
    OPERATION_TYPE_NAT,               /* 6 */
    OPERATION_TYPE_OAM                /* 7 */
};
typedef enum operation_type_e operation_type_t;

/* Packet type definition */
enum packet_type_e
{
    PKT_TYPE_ETHERNETV2,              /* 0 */
    PKT_TYPE_IPV4,                    /* 1 */
    PKT_TYPE_MPLS,                    /* 2 */
    PKT_TYPE_IPV6,                    /* 3 */
    PKT_TYPE_MCAST_MPLS,              /* 4 */
    PKT_TYPE_TRILL,                   /* 5 */
    PKT_TYPE_FLEXIBLE,                /* 6 */
    PKT_TYPE_RESERVED                 /* 7 */
};
typedef enum packet_type_e packet_type_t;

/* Share type definition */
enum share_type_e
{
    SHARE_TYPE_NONE,                  /* 0 */
    SHARE_TYPE_NAT,                   /* 1 */
    SHARE_TYPE_LMTX,                  /* 2 */
    SHARE_TYPE_PTP,                   /* 3 */
    SHARE_TYPE_OAM,                   /* 4 */
    SHARE_TYPE_DMTX,                  /* 5 */
    SHARE_TYPE_RESERVED1,             /* 6 */
    SHARE_TYPE_RESERVED2              /* 7 */

};
typedef enum share_type_e share_type_t;

/* Layer2 header type definition */
enum layer2_type_e
{
    L2_TYPE_NONE,                     /* 0 */
    L2_TYPE_ETHV2,                    /* 1 */
    L2_TYPE_ETHSAP,                   /* 2 */
    L2_TYPE_ETHSNAP,                  /* 3 */
    L2_TYPE_PPP2B,                    /* 4 */
    L2_TYPE_PPP1B,                    /* 5 */
    L2_TYPE_RAW_SNAP,                 /* 6 */
    L2_TYPE_RESERVED0,
    L2_TYPE_RESERVED1,
    L2_TYPE_RESERVED2,
    L2_TYPE_RESERVED3,
    L2_TYPE_RESERVED4,
    L2_TYPE_RESERVED5,
    L2_TYPE_RESERVED6,
    L2_TYPE_RESERVED7,
    L2_TYPE_FLEX_L2                   /* 15 */
};
typedef enum layer2_type_e layer2_type_t;

/* Layer3 header type definition */
enum layer3_type_e
{
    L3_TYPE_NONE,                     /* 0 */
    L3_TYPE_IP,                       /* 1 */
    L3_TYPE_IPV4,                     /* 2 */
    L3_TYPE_IPV6,                     /* 3 */
    L3_TYPE_MPLS,                     /* 4 */
    L3_TYPE_MPLSMCAST,                /* 5 */
    L3_TYPE_ARP,                      /* 6 */
    L3_TYPE_FCOE,                     /* 7:  0x8906 */
    L3_TYPE_TRILL,                    /* 8:  0x22F3 */
    L3_TYPE_ETHEROAM,                 /* 9:  0x8902 */
    L3_TYPE_SLOWPROTO,                /* 10: 0x8809 */
    L3_TYPE_CMAC,                     /* 11: 0x88E7 */
    L3_TYPE_PTP,                      /* 12: 0x88F7 */
    L3_TYPE_RESERVED0,                /* reserved */
    L3_TYPE_RESERVED1,                /* reserved */
    L3_TYPE_FLEX_L3                   /* 15 */
};
typedef enum layer3_type_e layer3_type_t;

/* Layer4 header type definition */
enum layer4_type_e
{
    L4_TYPE_NONE,                     /* 0 */
    L4_TYPE_TCP,                      /* 1 */
    L4_TYPE_UDP,                      /* 2 */
    L4_TYPE_GRE,                      /* 3 */
    L4_TYPE_IP_IN_IP,                 /* 4 */
    L4_TYPE_V6_IN_IP,                 /* 5 */
    L4_TYPE_ICMP,                     /* 6 */
    L4_TYPE_IGMP,                     /* 7 */
    L4_TYPE_IP_IN_V6,                 /* 8 */
    L4_TYPE_PBB_ITAG_OAM,             /* 9 */
    L4_TYPE_ACH_OAM,                  /* 10 */
    L4_TYPE_V6_IN_V6,                 /* 11 */
    L4_TYPE_RDP,                      /* 12 */
    L4_TYPE_SCTP,                     /* 13 */
    L4_TYPE_DCCP,                     /* 14 */
    L4_TYPE_FLEX_L4                   /* 15 */
};
typedef enum layer4_type_e layer4_type_t;

/* Layer4 User Type for UDP */
enum layer4_user_type_udp_e
{
    L4_USER_TYPE_UDP_NONE,            /* 0 */
    L4_USER_TYPE_UDP_BFD,             /* 1: BFD */
    L4_USER_TYPE_UDP_PTP,             /* 2: UDPPTP */
    L4_USER_TYPE_UDP_CAPWAP,          /* 3: CAPWAP */
    L4_USER_TYPE_UDP_NTP,             /* 4: NTP */
    L4_USER_TYPE_UDP_RESERVED0,
    L4_USER_TYPE_UDP_RESERVED1,
    L4_USER_TYPE_UDP_RESERVED2,
    L4_USER_TYPE_UDP_RESERVED3,
    L4_USER_TYPE_UDP_RESERVED4,
    L4_USER_TYPE_UDP_RESERVED5,
    L4_USER_TYPE_UDP_RESERVED6,
    L4_USER_TYPE_UDP_RESERVED7,
    L4_USER_TYPE_UDP_RESERVED8,
    L4_USER_TYPE_UDP_RESERVED9,
    L4_USER_TYPE_UDP_RESERVED10
};
typedef enum layer4_user_type_udp_e layer4_user_type_udp_t;

/* Layer4 User Type for ACHOAM */
enum layer4_user_type_achoam_e
{
    L4_USER_TYPE_ACHOAM_NONE,         /* 0 */
    L4_USER_TYPE_ACHOAM_ACH_Y1731,    /* 1:  Ach Y.1731 */
    L4_USER_TYPE_ACHOAM_ACH_BFD,      /* 2:  Ach BFD */
    L4_USER_TYPE_ACHOAM_ACH_CC,       /* 3:  Ach CC */
    L4_USER_TYPE_ACHOAM_ACH_CV,       /* 4:  Ach CV */
    L4_USER_TYPE_ACHOAM_ACH_DLM,      /* 5:  Ach DLM */
    L4_USER_TYPE_ACHOAM_ACH_ILM,      /* 6   Ach ILM */
    L4_USER_TYPE_ACHOAM_ACH_ILMDM,    /* 7   Ach ILMDM */
    L4_USER_TYPE_ACHOAM_ACH_DLMDM,    /* 8:  Ach DLMDM */
    L4_USER_TYPE_ACHOAM_ACH_DM,       /* 9:  Ach DM */
    L4_USER_TYPE_ACHOAM_MCC,          /* 10: Ach MCC */
    L4_USER_TYPE_ACHOAM_SCC,          /* 11: Ach SCC */
    L4_USER_TYPE_ACHOAM_RESERVED2,
    L4_USER_TYPE_ACHOAM_RESERVED3,
    L4_USER_TYPE_ACHOAM_RESERVED4,
    L4_USER_TYPE_ACHOAM_RESERVED5
};
typedef enum layer4_user_type_achoam_e layer4_user_type_achoam_t;

/* TBD */
enum ipe_lm_packet_type_e
{
    IPE_LM_PACKET_TYPE_LM_NONE = 0,
    IPE_LM_PACKET_TYPE_LM_CCM = 4,
    IPE_LM_PACKET_TYPE_LMM = 5,
    IPE_LM_PACKET_TYPE_LMR = 6,
    IPE_LM_PACKET_TYPE_LM_ACH = 7,
};
typedef enum ipe_lm_packet_type_e ipe_lm_packet_type_t;

/* TBD */
enum ptp_version_e
{
    PTP_VERSION_UNKNOWN,                    /* 0: unknow */
    PTP_VERSION1,                           /* 1: PTP version 1 */
    PTP_VERSION2,                           /* 2: PTP version 2 */
    PTP_VERSION3                            /* 3: >= PTP version 3 (extension use) */
};
typedef enum ptp_version_e ptp_version_t;

/* TBD */
enum ptp_message_type_e
{
    PTP_MESSAGE_TYPE_SYNC,                  /* 0 */
    PTP_MESSAGE_TYPE_DELAY_REQ,             /* 1 */
    PTP_MESSAGE_TYPE_PDELAY_REQ,            /* 2 */
    PTP_MESSAGE_TYPE_PDELAY_RESP,           /* 3 */
    PTP_MESSAGE_TYPE_RESERVED4,
    PTP_MESSAGE_TYPE_RESERVED5,
    PTP_MESSAGE_TYPE_RESERVED6,
    PTP_MESSAGE_TYPE_RESERVED7,
    PTP_MESSAGE_TYPE_FOLLOW_UP,             /* 8 */
    PTP_MESSAGE_TYPE_DELAY_RESP,            /* 9 */

    PTP_MESSAGE_TYPE_PDELAY_RESP_FOLLOW_UP, /* A */
    PTP_MESSAGE_TYPE_ANNOUNCE,              /* B */
    PTP_MESSAGE_TYPE_SIGNALING,             /* C */
    PTP_MESSAGE_TYPE_MANAGEMENT,            /* D */

    PTP_MESSAGE_TYPE_RESERVED0,             /* E */
    PTP_MESSAGE_TYPE_RESERVED1,             /* F */

    PTP_MESSAGE_TYPE_NUM
};
typedef enum ptp_message_type_e ptp_message_type_t;

/* TBD */
enum mux_header_adjust_type_e
{
    MUX_HEADER_ADJUST_TYPE_REGULAR_PORT,                   /* 4'b0000: Regular port(No MUX)           */
    MUX_HEADER_ADJUST_TYPE_OLD_VLAN_ENCODE_MULTIPLEXING,   /* 4'b0001: Old VLAN encodec multiplexing  */
    MUX_HEADER_ADJUST_TYPE_EVB,                            /* 4'b0010: EVB                            */
    MUX_HEADER_ADJUST_TYPE_CB_DOWNLINK,                    /* 4'b0011: CB downlink                    */
    MUX_HEADER_ADJUST_TYPE_PE_DOWNLINK_WITH_CASCADE,       /* 4'b0100: PE downlink with cascade port  */
    MUX_HEADER_ADJUST_TYPE_PE_UPLINK,                      /* 4'b0101: PE uplink                      */
    MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITHOUT_TUNNEL,   /* 4'b0110: BridgeHeader without tunnel    */
    MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2,          /* 4'b0111: BridgeHeader with L2           */
    MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2_AND_IPV4, /* 4'b1000: BridgeHeader with L2 + IPv4    */
    MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_L2_AND_IPV6, /* 4'b1001: BridgeHeader with L2 + IPv6    */
    MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_IPV4,        /* 4'b1010: BridgeHeader IPv4              */
    MUX_HEADER_ADJUST_TYPE_BRIDGE_HEADER_WITH_IPV6,        /* 4'b1011: BridgeHeader IPv6              */
    MUX_HEADER_ADJUST_TYPE_RESERVED,                       /* 4'b1100 ~ 4'b1101: Reserved             */
};
typedef enum mux_header_adjust_type_e mux_header_adjust_type_t;

/* TBD */
enum parser_l4_op_type_e
{
    PARSER_L4_OP_UDP_APP,                   /* 0 */
    PARSER_L4_OP_PORT,                      /* 1 */
    PARSER_L4_OP_TCP_FLAG,                  /* 2 */
    PARSER_L4_OP_INVALID                    /* 3: Unknown layer4 operation type value */
};
typedef enum parser_l4_op_type_e parser_l4_op_type_t;

/* Define operation type in pkt header, see MsPacketHeader */
enum operation_type_ext_e
{
    OP_TYPE_EXT_NONE,                        /* 0 */
    OP_TYPE_EXT_LM,                          /* 1 */
    OP_TYPE_EXT_LABEL_SPACE,                 /* 2 */
    OP_TYPE_EXT_RESERVED,                    /* 3 */
    OP_EXT_INVALID_TYPE
};
typedef enum operation_type_ext_e operation_type_ext_t;

/* STP state definition */
enum stp_state_e
{
    STP_FORWARDING,                         /* 0: forwarding state */
    STP_BLOCKING,                           /* 1: blocking state */
    STP_LEARNING,                           /* 2: learning state */
    STP_INVALID                             /* 3: unknown state value */
};
typedef enum stp_state_e stp_state_t;

/* QoS Policy definition */
enum qos_policy_e
{
    QOS_POLICY_TRUST_PORT,                  /* 0: Trust Port */
    QOS_POLICY_COPY_OUTER,                  /* 1: Copy outer */
    QOS_POLICY_TRUST_COS,                   /* 2: Trust COS */
    QOS_POLICY_TRUST_DSCP,                  /* 3: Trust DSCP */
    QOS_POLICY_TRUST_IP_PRECEDENCE,         /* 4: Trust IP Precedence */
    QOS_POLICY_TRUST_STAG_COS,              /* 5: Trust stag-cos */
    QOS_POLICY_TRUST_CTAG_COS,              /* 6: Trust ctag-cos */
    QOS_POLICY_INVALID                      /* 7: Invalid*/
};
typedef enum qos_policy_e qos_policy_t;

enum ctag_offset_type_e
{
    CTAG_OFFSET_TYPE_AFTER_STAG,
    CTAG_OFFSET_TYPE_AFTER_MAC
};
typedef enum ctag_offset_type_e ctag_offset_type_t;

/* IPE module fatal exception meanings definition */
enum fatal_exception_e
{
    FATAL_EXP_UC_IP_HDR_ERR_OR_IP_MARTION_ADDR,   /* 0: discard */
    FATAL_EXP_UC_IP_OPTIONS,                      /* 1: to CPU */
    FATAL_EXP_UC_GRE_UNKNOWN_OPTION_OR_PTL,       /* 2: to CPU */
    FATAL_EXP_UC_ISATAP_SRC_ADD_CHECK_FAIL,       /* 3: discard */
    FATAL_EXP_UC_IP_TTL_CHECK_FAIL,               /* 4: discard */
    FATAL_EXP_UC_RPF_CHECK_FAIL,                  /* 5: discard */
    FATAL_EXP_UC_OR_MC_MORE_RPF,                  /* 6: to CPU */
    FATAL_EXP_UC_LINK_ID_CHECK_FAIL,              /* 7: to CPU */
    FATAL_EXP_MPLS_LABEL_OUT_OF_RANGE,            /* 8: discard */
    FATAL_EXP_MPLS_SBIT_ERROR,                    /* 9: discard */
    FATAL_EXP_MPLS_TTL_CHECK_FAIL,                /* 10: discard */
    FATAL_EXP_FCOE_VIRTUAL_LINK_CHECK_FAIL,       /* 11: discard */
    FATAL_EXP_IGMP_SNOOPED_PACKET,                /* 12: to CPU */
    FATAL_EXP_TRILL_OPTION,                       /* 13: to CPU */
    FATAL_EXP_TRILL_TTL_CHECK_FAIL,               /* 14: discard */
    FATAL_EXP_RESERVED1,                          /* 15: reserved */
};
typedef enum fatal_exception_e fatal_exception_t;

enum ds_phy_port_ext_user_id_hash_type_e
{
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_DISABLE,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_TWO_VLAN,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_SVLAN,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_CVLAN,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_SVLAN_COS,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_CVLAN_COS,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_MAC_SA,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_PORT_MAC_SA,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_IP_SA,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_PORT_IP_SA,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_PORT,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_L2,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_RES,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_TUNNEL,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_TRILL,
    DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_NUM
};
typedef enum ds_phy_port_ext_user_id_hash_type_e ds_phy_port_ext_user_id_hash_type_t;

/* TBD */
enum layer3_sa_key_type_e
{
    LAYER3_SA_IPV4_UCAST_RPF_KEY,           /* 0 */
    LAYER3_SA_IPV6_UCAST_RPF_KEY,           /* 1 */
    LAYER3_SA_IPV4_NAT_KEY,                 /* 2 */
    LAYER3_SA_IPV6_NAT_KEY,                 /* 3 */
    LAYER3_SA_IPV4_PBR_KEY,                 /* 4 */
    LAYER3_SA_IPV6_PBR_KEY,                 /* 5 */
    LAYER3_SA_FCOE_KEY,                     /* 6 */
    LAYER3_SA_TRILL_UCAST_RPF_KEY,          /* 7 */
    LAYER3_SA_TRILL_MCAST_RPF_KEY,          /* 8 */
    LAYER3_SA_MAX_KEY
};
typedef enum layer3_sa_key_type_e layer3_sa_key_type_t;

/* IPE module discard type value meanings definition */
enum ipe_pktinfo_discard_type_e
{
    /* 0~9 */
    IPE_DISCARD_USER_ID_BINDING_DISCARD,                        /*0*/
    IPE_DISCARD_HDR_ADJ_BYTE_RMV_ERR_DISCARD,                   /*1*/
    IPE_DISCARD_PSR_LEN_ERR,                                    /*2*/
    IPE_DISCARD_MAC_ISOLATED_DISCARD,                           /*3*/
    IPE_DISCARD_EXCEP_2_DISCARD,                                /*4*/
    IPE_DISCARD_USER_ID_DISCARD,                                /*5*/
    IPE_DISCARD_PORT_OR_DS_VLAN_RCV_DIS,                        /*6*/
    IPE_DISCARD_ITAG_CHK_FAIL,                                  /*7*/
    IPE_DISCARD_PTL_VLAN_DISCARD,                               /*8*/
    IPE_DISCARD_VLAN_TAG_CTL_DISCARD,                           /*9*/

    /* 10~19 */
    IPE_DISCARD_NOT_ALLOW_MCAST_MAC_SA_DISCARD,                 /*10*/
    IPE_DISCARD_STP_DISCARD,                                    /*11*/
    IPE_DISCARD_RESERVED0,                                      /*12*/
    IPE_DISCARD_PBB_OAM_DISCARD,                                /*13*/
    IPE_DISCARD_ARP_DHCP_DISCARD,                               /*14*/
    IPE_DISCARD_DS_PHYPORT_SRC_DISCARD,                         /*15*/
    IPE_DISCARD_VLAN_STATUS_FILTER_DISCARD,                     /*16*/
    IPE_DISCARD_ACLQOS_DISCARD_PKT,                             /*17*/
    IPE_DISCARD_ROUTING_MCAST_IP_ADDR_CHK_DISCARD,              /*18*/
    IPE_DISCARD_BRG_BPDU_ETC_DISCARD,                           /*19*/

    /* 20~29 */
    IPE_DISCARD_STORM_CTL_DISCARD,                              /*20*/
    IPE_DISCARD_LEARNING_DISCARD,                               /*21*/
    IPE_DISCARD_POLICING_DISCARD,                               /*22*/
    IPE_DISCARD_NO_FWD_PTR_DISCARD,                             /*23*/
    IPE_DISCARD_FWD_PTR_ALL_F_OR_VALID_DISCARD,                 /*24*/
    IPE_DISCARD_FATAL_EXCEPTION_DSCD,                           /*25*/
    IPE_DISCARD_APS_DISCARD,                                    /*26*/
    IPE_DISCARD_FWD_DEST_ID_DISCARD,                            /*27*/
    IPE_DISCARD_RESERVED1,                                      /*28*/
    IPE_DISCARD_HDR_AJUST_SMALL_PKT_DISCARD,                    /*29*/

    /* 30~39 */
    IPE_DISCARD_HDR_ADJUST_PKT_ERR,                             /*30*/
    IPE_DISCARD_TRILL_ESADI_PKT_DISCARD,                        /*31*/
    IPE_DISCARD_LOOPBACK_DISCARD,                               /*32*/
    IPE_DISCARD_EFM_DISCARD,                                    /*33*/
    IPE_DISCARD_CAPWAP_FROM_AC_ERR_OR_UNEXPECTABLE,             /*34*/
    IPE_DISCARD_STACKING_NETWORK_HEADER_CHK_ERR,                /*35*/
    IPE_DISCARD_TRILL_FILTER_ERR,                               /*36*/
    IPE_DISCARD_CAPWAP_CONTROL_EXCEPTION,                       /*37*/
    IPE_DISCARD_L3_EXCEPTION,                                   /*38*/
    IPE_DISCARD_L2_EXCEPTION,                                   /*39*/

    /* 40~49 */
    IPE_DISCARD_TRILL_MCAST_ADDR_CHK_ERR,                       /*40*/
    IPE_DISCARD_TRILL_VERSION_CHK_ERR,                          /*41*/
    IPE_DISCARD_PTP_VERSION_CHK_ERR,                            /*42*/
    IPE_DISCARD_PTPT_P2P_TRANS_CLOCK_DELAY_DISCARD,             /*43*/
    IPE_DISCARD_OAM_NOT_FOUND_DISCARD,                          /*44*/
    IPE_DISCARD_OAM_STP_VLAN_FILTER_DISCARD,                    /*45*/
    IPE_DISCARD_BFD_SINGLE_HOP_OAM_TTL_CHK_ERR,                 /*46*/
    IPE_DISCARD_CAPWAP_DTLS_DISCARD,                            /*47*/
    IPE_DISCARD_NO_MEP_MIP_DISCARD,                             /*48*/
    IPE_DISCARD_OAM_DIS,                                        /*49*/

    /* 50~59 */
    IPE_DISCARD_PBB_DECAP_DISCARD,                              /*50*/
    IPE_DISCARD_MPLS_TMPLS_OAM_DISCARD,                         /*51*/
    IPE_DISCARD_MPLSTP_MCC_SCC_DISCARD,                         /*52*/
    IPE_DISCARD_ICMP_ERR_MSG_DISCARD,                           /*53*/
    IPE_DISCARD_PTP_ACL_EXCEPTION,                              /*54*/
    IPE_DISCARD_ETHER_SERVICE_OAM_DISCARD,                      /*55*/
    IPE_DISCARD_LINK_OAM_DISCARD,                               /*56*/
    IPE_DISCARD_TUNNEL_DECAP_OUTER_MARTIAN_ADDR_DISCARD,        /*57*/
    IPE_DISCARD_CAPWAP_BSSID_LKP_OR_LOGIC_PORT_CHK_DISCARD,     /*58*/
    IPE_DISCARD_USER_ID_FWD_PTR_ALL_F_DISCARD,                  /*59*/

    /* 60~62 */
    IPE_DISCARD_CAPWAP_FRAGMEN_DISCARD,                         /*60*/
    IPE_DISCARD_TRILL_RPF_CHK_FAIL,                             /*61*/
    IPE_DISCARD_MUX_PORT_ERR,                                   /*62*/
    IPE_DISCARD_RESERVED2,                                      /*63*/

    IPE_DISCARD_TYPE_MAX_NUM
};
typedef enum ipe_pktinfo_discard_type_e ipe_pktinfo_discard_type_t;

enum user_id_hash_level_e
{
    USER_ID_HASH_LEVEL1,
    USER_ID_HASH_LEVEL2,
    USER_ID_HASH_LEVEL_NUM
};
typedef enum user_id_hash_level_e user_id_hash_leve_t;

enum roaming_state_e
{
    ROAMING_NONE,
    ROAMING_HA = 1,
    ROAMING_FA = 2,
    NONE_HA_FA_MODEL = 3
};
typedef enum roaming_state_e roaming_state_t;

enum header_type_e
{
    HEADER_TYPE_INGRESS_EDIT = 0,
    HEADER_TYPE_EGRESS_EDIT = 1
};
typedef enum header_type_e header_type_t;

/* 4 uint32 in front is the old bay header, do not change because of compatibility */
#if CTC_HOST_IS_LITTLE_ENDIAN
struct humber_packet_header_s
{
    uint32 dest_id                                         :16;
    uint32 dest_chip_id                                    :5;
    uint32 mcast                                           :1;
    uint32 packet_offset                                   :7;
    uint32 dest_id_discard                                 :1;
    uint32 header_type                                     :2;

    uint32 source_port                                     :14;
    uint32 untagged_packet                                 :1;
    uint32 vpls_port_type                                  :1;
    uint32 header_hash_2_0                                 :3;
    uint32 src_queue_select                                :1;
    uint32 source_cos                                      :3;
    uint32 packet_type                                     :3;
    uint32 priority                                        :6;

    uint32 next_hop_ptr                                    :18;
    uint32 color                                           :2;
    uint32 src_vlan_id                                     :12;

    uint32 header_crc                                      :8;
    uint32 ttl_or_oam_defect                               :8;
    uint32 packet_length                                   :14;
    uint32 critical_packet                                 :1;
    uint32 length_adjust_type                              :1;

    uint32 src_cvlan_id                                    :12;
    uint32 src_cvlan_id_valid                              :1;
    uint32 src_svlan_id_valid                              :1;
    uint32 deny_replace_dscp                               :1;
    uint32 deny_replace_cos                                :1;
    uint32 svlan_tpid_index_1_0                            :2;
    uint32 next_hop_ptr_19_18                              :2;
    uint32 next_hop_ext                                    :1;
    uint32 source_cfi                                      :1;
    uint32 communicate_port                                :1;
    uint32 pbb_srcport_type_or_l4srcport_vld               :3;
    uint32 source_port_isolate_id                          :6;

    uint32 vrfid_timestamp_63_48                           :16;
    uint32 src_vlanptr_or_timestamp_79_64                  :16;

    uint32 hd_hash_7_to_3                                  :5;
    uint32 operation_type                                  :3;
    uint32 mirror                                          :1;
    uint32 oam_tunnel_en                                   :1;
    uint32 pfm                                             :2;
    uint32 use_outer_vrfid                                 :1;
    uint32 src_tagged                                      :1;
    uint32 rsv2                                            :2;
    uint32 l4srcport_or_vplssrcport_oamtype                :16;

    uint32 flowid_servecid_or_oamportid                    :32;
};

struct humber_exception_info_s
{
    uint32 exception_vector_11_0                           :12;
    uint32 qos_log_id                                      :2;
    uint32 acl_log_id                                      :2;
    uint32 l3_span_id                                      :2;
    uint32 l2_span_id                                      :2;
    uint32 exception_packet_type                           :3;
    uint32 egress_exception                                :1;
    uint32 exception_sub_idx                               :4;
    uint32 exception_vector_12                             :1;
    uint32 exception_vector_13                             :1;
    uint32 exception_vector_14                             :1;
    uint32 exception_vector_15                             :1;

    uint32 mac_valid                                       :1;
    uint32 loopback_en                                     :1;
    uint32 reserved                                        :30;
};

#else
struct humber_packet_header_s
{
    uint32 header_type                                     :2;
    uint32 dest_id_discard                                 :1;
    uint32 packet_offset                                   :7;
    uint32 mcast                                           :1;
    uint32 dest_chip_id                                    :5;
    uint32 dest_id                                         :16;

    uint32 priority                                        :6;
    uint32 packet_type                                     :3;
    uint32 source_cos                                      :3;
    uint32 src_queue_select                                :1;
    uint32 header_hash_2_0                                 :3;
    uint32 vpls_port_type                                  :1;
    uint32 untagged_packet                                 :1;
    uint32 source_port                                     :14;

    uint32 src_vlan_id                                     :12;
    uint32 color                                           :2;
    uint32 next_hop_ptr                                    :18;

    uint32 length_adjust_type                              :1;
    uint32 critical_packet                                 :1;
    uint32 packet_length                                   :14;
    uint32 ttl_or_oam_defect                               :8;
    uint32 header_crc                                      :8;

    uint32 source_port_isolate_id                          :6;
    uint32 pbb_srcport_type_or_l4srcport_vld               :3;
    uint32 communicate_port                                :1;
    uint32 source_cfi                                      :1;
    uint32 next_hop_ext                                    :1;
    uint32 next_hop_ptr_19_18                              :2;
    uint32 svlan_tpid_index                                :2;
    uint32 deny_replace_cos                                :1;
    uint32 deny_replace_dscp                               :1;
    uint32 src_svlan_id_valid                              :1;
    uint32 src_cvlan_id_valid                              :1;
    uint32 src_cvlan_id                                    :12;

    uint32 src_vlanptr_or_timestamp_79_64                  :16;
    uint32 vrfid_timestamp_63_48                           :16;

    uint32 l4srcport_or_vplssrcport_oamtype                :16;
    uint32 rsv2                                            :2;
    uint32 src_tagged                                      :1;
    uint32 use_outer_vrfid                                 :1;
    uint32 pfm                                             :2;
    uint32 oam_tunnel_en                                   :1;
    uint32 mirror                                          :1;
    uint32 operation_type                                  :3;
    uint32 hd_hash_7_3                                     :5;

    uint32 flowid_servecid_or_oamportid                    :32;
};

struct humber_exception_info_s
{
    uint32 reserved                                        :30;
    uint32 loopback_en                                     :1;
    uint32 mac_valid                                       :1;

    uint32 exception_vector_15                             :1;
    uint32 exception_vector_14                             :1;
    uint32 exception_vector_13                             :1;
    uint32 exception_vector_12                             :1;
    uint32 exception_sub_idx                               :4;
    uint32 egress_exception                                :1;
    uint32 exception_packet_type                           :3;
    uint32 l2_span_id                                      :2;
    uint32 l3_span_id                                      :2;
    uint32 acl_log_id                                      :2;
    uint32 qos_log_id                                      :2;
    uint32 exception_vector_11_0                           :12;
};
#endif

typedef struct humber_packet_header_s humber_packet_header_t;
typedef struct humber_exception_info_s humber_exception_info_t;
typedef ms_excp_info_t greatbelt_exception_info_t;

/* GreatBelt header's detail define in cmodel */
struct cm_greatbelt_packet_header_s
{
   uint32 source_port15_14                                 :2;
   uint32 packet_offset                                    :8;
   uint32 mcast                                            :1;
   uint32 dest_chip_id                                     :5;
   uint32 dest_id                                          :16;

   uint32 priority                                         :6;
   uint32 packet_type                                      :3;
   uint32 source_cos                                       :3;
   uint32 src_queue_select                                 :1;
   uint32 header_hash2_0                                   :3;
   uint32 logic_port_type                                  :1;
   gbhdr_src_ctag_offset_type_t src_ctag_offset_type_u;
   uint32 source_port                                      :14;

   gbhdr_src_vlanid_t src_vlan_id_u;
   uint32 color                                            :2;
   uint32 bridge_operation                                 :1;
   uint32 rsv                                              :1;
   uint32 next_hop_ptr                                     :16;

   uint32 length_adjust_type                               :1;
   uint32 critical_packet                                  :1;
   gbhdr_rxtx_fcl_22_17_t rxtx_fcl_22_17_u;
   gdhdr_flow_t flow_u;
   gbhdr_ttl_t ttl_u;
   uint32 from_fabric                                      :1;
   uint32 bypass_ingress_edit                              :1;
   uint32 source_port_extender                             :1;
   gdhdr_loopback_discard_t loopback_discard_u;
   uint32 header_crc                                       :4;

   gdhdr_src_port_isolate_id_t source_port_isolate_id_u;
   gbhdr_pbb_src_port_type_t pbb_src_port_type_u;
   uint32 svlan_tag_operation_valid                        :1;
   uint32 source_cfi                                       :1;
   uint32 next_hop_ext                                     :1;
   uint32 non_crc                                          :1;
   uint32 from_cpu_or_oam                                  :1;
   gbhdr_svlan_tpid_index_t svlan_tpid_index_u;
   uint32 stag_action                                      :2;
   uint32 src_svlan_id_valid                               :1;
   gdhdr_src_cvlanid_valid_t src_cvlan_id_valid_u;
   gdhdr_src_cvlanid_t src_cvlan_id_u;

   gdhdr_src_vlan_ptr_t src_vlan_ptr_t;
   gbhdr_fid_t fid_u;

   gbhdr_logic_src_port_t logic_src_port_u;
   gbhdr_rxtx_fcl_3_t rxtx_fcl3_u;
   uint32 cut_through                                      :1;
   gbhdr_rxtx_fcl_2_1_t rxtx_fcl2_1_u;
   uint32 mux_length_type                                  :2;
   uint32 oam_tunnel_en                                    :1;
   gbhdr_rxtx_fcl_0_t rxtx_fcl0_u;
   uint32 operation_type                                   :3;
   uint32 header_hash7_3                                   :5;

   gbhdr_ip_sa_t ip_sa_u;
};
typedef struct cm_greatbelt_packet_header_s cm_greatbelt_packet_header_t;

typedef struct cm_greatbelt_packet_header_s greatbelt_packet_header_t;

struct cm_greatbelt_packet_header_outer_s
{
   uint32 header_type                                                      :1;
   uint32 header_version                                                   :3;
   uint32 svlan_tpid_index                                                 :2;
   uint32 mirrored_packet                                                  :1;
   uint32 mcast                                                            :1;
   uint32 dest_chip_id                                                     :5;
   uint32 dest_id                                                          :16;

   uint32 from_cpu_lm_down_disable                                         :1;
   uint32 bypass_all                                                       :1;
   uint32 outer_vlan_is_c_vlan                                             :1;
   uint32 src_vlan_ptr                                                     :13;
   uint32 source_port                                                      :16;

   uint32 priority                                                         :6;
   uint32 packet_type                                                      :3;
   uint32 mac_known                                                        :1;
   uint32 critical_packet                                                  :1;
   uint32 is_leaf                                                          :1;
   uint32 color                                                            :2;
   gbhdr_outer_oam_tunnel_en_t oam_tunnel_en_u;
   uint32 source_port_extender                                             :1;
   uint32 ttl                                                              :8;
   uint32 bridge_operation                                                 :1;
   uint32 port_mac_sa_en                                                   :1;
   uint32 source_port_isolate_id                                           :6;

   uint32 logic_src_port                                                   :16;
   uint32 header_hash                                                      :8;
   uint32 logic_port_type                                                  :1;
   uint32 operation_type                                                   :4;

   uint32 from_cpu_lm_up_disable                                           :1;
   uint32 next_hop_ext                                                     :1;
   uint32 next_hop_ptr                                                     :18;

   gbhdr_outer_timestamp_107_96_t timestamp107_96_u;

   gbhdr_outer_timestamp_95_64_t timestamp95_64_u;

   gbhdr_outer_timestamp_63_32_t timestamp63_32_u;

   gbhdr_outer_timestamp_31_0_t timestamp31_0_u;

};
typedef struct cm_greatbelt_packet_header_outer_s cm_greatbelt_packet_header_outer_t;
typedef struct cm_greatbelt_packet_header_outer_s greatbelt_packet_header_outer_t;

union share_fields_u
{
    struct
    {
        uint32 res                            :32;
        uint32 new_ip_sa_39_32                :8;
        uint32 new_ip_sa_31_0                 :32;
        uint32 new_l4_source_port             :16;
        uint32 new_ip_sa_valid                :1;
        uint32 new_l4_source_port_valid       :1;
        uint32 pt_enable                      :1;
        uint32 ipv4_src_embeded_mode          :1;
        uint32 ip_sa_mode                     :2;
        uint32 src_address_mode               :1;
        uint32 ip_sa_prefix_length            :3;
    }nat;

    struct
    {
        uint32 res                            :27;
        uint32 ptp_snooping_non_event         :1;
        uint32 ptp_edit_type                  :2;
        uint32 ptp_squence_id                 :2;
        uint32 ptp_extra_offset               :2;
        uint32 time_stamp_61_32               :30;
        uint32 time_stamp_31_0                :32;
    }ptp;

    struct
    {
        uint32 lm_packet_type                 :2;
        uint32 tx_fcb                         :32;
        uint32 rx_fcb                         :32;
        uint32 rxtx_fcl                       :32;
    }lmtx;

    struct
    {
        uint32 res                            :5;
        uint32 gal_exist                      :1;
        uint32 entropy_label_exist            :1;
        uint32 oam_dest_chip_id               :5;
        uint32 mep_index                      :14;
        uint32 rx_oam_type                    :4;
        uint32 mip_en                         :1;
        uint32 link_or_section_oam            :1;
        uint32 lm_received_packet             :1;
        uint32 dm_en                          :1;
        uint32 rx_fcb_or_time_stamp_63_32      :32;
        uint32 rxtx_fcl_or_time_stamp_31_0   :32;
    }oam;

    struct
    {
        uint32 res1                           :29;
        uint32 dm_offset                      :8;
        uint32 time_stamp_61_32               :30;
        uint32 time_stamp_31_0                :32;
    }dmtx;

    struct
    {
        uint32 res1                           :32;
        uint32 res2                           :3;
        uint32 ptp_extra_offset               :2;
        uint32 time_stamp_61_32               :30;
        uint32 time_stamp_31_0                :32;
    }none;
};
typedef union share_fields_u share_fields_t;

struct ipe_packet_info_s
{
    void *parser_rslt;
    void *parser_rslt1;

    greatbelt_exception_info_t *bexception;
    ms_packet_header_t *bheader;
    packet_header_outer_t *ingress_header;
    share_fields_t share_fields_u;

    void *ip_hash_mac_da_data;     /* used by lookup manager */
    void *ip_tcam_mac_da_data;     /* used by lookup manager */
    void *hash_mac_da_data;        /* used by lookup manager */
    void *tcam_mac_da_data;        /* used by lookup manager */
    void *hash_mac_sa_data;        /* used by lookup manager */
    void *tcam_mac_sa_data;        /* used by lookup manager */
    void *hash_outer_mac_sa_data;  /* used by lookup manager */
    void *tcam_outer_mac_sa_data;  /* used by lookup manager */

    void *acl_data0;               /* used by acl */
    void *acl_data1;               /* used by acl */
    void *acl_data2;               /* used by acl */
    void *acl_data3;               /* used by acl */
    void *acl_hash_data;           /* used by acl */

    void *ipda_tcam_data;          /*used by routing*/
    void *ipsa_tcam_data;          /*used by routing*/
    void *ipda_fib_data;           /*used by routing*/
    void *ipsa_fib_data;           /*used by routing*/

    void *fcoe_da_data_tcam; /* used by lookup manager */
    void *fcoe_sa_data_tcam; /* used by lookup manager */
    void *fcoe_da_data_fib; /* used by lookup manager */
    void *fcoe_sa_data_fib; /* used by lookup manager */

    void *trill_da_data_tcam;    /* used by lookup manager */
    void *trill_da_data_fib;    /* used by lookup manager */
    void *trill_vlan_da_data_fib;    /* used by lookup manager */

    void *mpls_data[4];

    //void *oam_info;
    void *lm_info0;     /* used by lookup manager */
    void *lm_info0_tcam;
    void *lm_chan_data0;
    void *lm_chan_data0_tcam;

    uint32 share_type                       :3;
    uint32 ip_da_lookup_mode                :2;
    uint32 ip_sa_lookup_mode                :2;  /*routing*/
    uint32 packet_length                    :14; /* used by classification */
    uint32 local_phy_port                   :7;
    uint32 discard_type                     :6;  /* user id */
    uint32 ingress_header_valid              :1; /*used by ipe header adjust*/
    uint32 packet_ttl                       :8;
    uint32 mac_security_discard             :1;  /*learning*/
    uint32 l2_acl_en0                       :1;
    uint32 l2_acl_en1                       :1;
    uint32 l2_acl_en2                       :1;
    uint32 l2_acl_en3                       :1;
    uint32 acl_en0                          :1; /* used by acl */
    uint32 acl_en1                          :1; /* used by acl */
    uint32 acl_en2                          :1; /* used by acl */
    uint32 acl_en3                          :1; /* used by acl */
    uint32 bridge_en                        :1;
    uint32 interface_id                     :10;/*routing*/
    uint32 port_policer_valid               :1; /* used by classification */
    uint32 qos_policy                       :3; /* used by acl */
    uint32 ptp_valid                        :1;

    uint32 routed_port                      :1;
    uint32 vlan_flow_policer_valid          :1;
    uint32 l2_acl_label                     :10;    /*used by interface mapper*/
    uint32 link_lm_type                     :2;     /*used by interface mapper*/
    uint32 link_lm_cos_type                 :2;     /*used by interface mapper*/
    uint32 link_lm_cos                      :3;     /*used by interface mapper*/
    uint32 link_lm_index_base               :14;    /*used by interface mapper*/

    uint32 ipg_index                        :2; /* used by acl */
    uint32 qos_domain                       :3; /* used by acl */
    uint32 port_security_en                 :1; /*learning*/
    uint32 port_security_exception_en       :1; /*learning*/
    uint32 learning_disable                 :1;
    uint32 port_check_en                    :1; /* bridge*/
    uint32 force_acl_qos_ipv4_to_mac_key    :1;
    uint32 force_acl_qos_ipv6_to_mac_key    :1;
    uint32 trill_en                         :1;
    uint32 fcoe_en                          :1;
    uint32 fcoe_rpf_en                      :1;
    uint32 speed                            :2;

    uint32 acl_use_label                    :1;
    uint32 l2_ipv6_acl_en0                  :1;
    uint32 l2_ipv6_acl_en1                  :1;

    uint32 acl_port_num                     :6;
    uint32 link_oam_mep_index               :13;
    uint32 route_disable                    :1;
    uint32 oam_tunnel_en                    :1;
    uint32 is_loop                          :1;
    uint32 is_leaf                          :1;
    uint32 from_cpu_or_oam                  :1;
    uint32 ds_fwd_ptr_valid                 :1;  /* user id */

    uint32 vrfid_or_ds_fwd_ptr              :16; /* user id */
    uint32 vsi_id                           :14;
    uint32 outer_vsi_id                     :14;
    uint32 discard                          :1;  /* user id */
    uint32 logic_src_port_valid             :1;  /* user id */

    uint32 ds_fwd_ptr                       :16; /* user id */
    uint32 payload_packet_type              :3;  /* used by acl */
    uint32 packet_type                      :3;  /*forward*/
    uint32 logic_port_type                  :1;  /*forward*/
    uint32 mux_length_type                  :2;  /* used by classification */
    uint32 use_default_logic_src_port       :1;
    uint32 roaming_state                    :2;  /*forward*/
    uint32 capwap_tunnel_type               :1;  /*forward*/
    uint32 capwap_tunnel_valid              :1;  /*forward*/
    uint32 use_default_vlan_tag_valid       :1;

    uint32 logic_src_port                   :14; /* user id */
    uint32 dst_mod_id_md_id                 :16;
    uint32 mux_destination_valid            :1;
    uint32 port_extender_use_logic_port     :1;

    uint32 dlm_en                           :1;
    uint32 use_default_vlan_tag             :1;
    uint32 user_default_vlan_id             :12;
    uint32 user_default_cos                 :3;
    uint32 user_default_cfi                 :1;
    uint32 default_logic_src_port           :14; /* user id */

    /* greatbelt variable */
    uint32 packet_length_adjust             :8;  /* used by classification */
    uint32 mux_header_type                  :2;
    uint32 src_port_isolate_id              :6;  /* user id*/
    uint32 bypass_all                       :1;  /* user id */
    uint32 fatal_exception                  :4;  /*routing*/
    uint32 l2_span_en                       :1;  /* user id */
    uint32 l2_span_id                       :2;  /* user id */
    uint32 header_hash                      :8;

    uint32 default_hash_type                :1;  /* user id */
    uint32 src_queue_select                 :1;
    uint32 remove_vlan_tag                  :1;
    uint32 priority_path_select             :3; /* used by acl */
    uint32 is_ipv6_ucast_nat                :1;
    uint32 v6_ucast_sa_type                 :2;
    uint32 bridge_packet                    :1; /*routing*/
    uint32 source_cos                       :3; /* aclqos */
    uint32 source_cfi                       :1; /* aclqos */
    uint32 default_vlan_id                  :12; /* user id */
    uint32 priority                         :6; /* used by acl */
    uint32 packet_cos0                      :3;
    uint32 packet_cos1                      :3;
    uint32 packet_cos2                      :3;


    uint32 customer_id                      :32;

    uint32 new_ip_sa                        :32; /*routing*/

    uint32 new_ip_sa_39_32                  :8; /*routing*/
    uint32 customer_id_valid                :1;
    uint32 new_l4_source_port               :16;/*routing*/
    uint32 new_l4_source_port_valid         :1; /*routing*/
    uint32 new_ip_sa_valid                  :1; /*routing*/
    uint32 mpls_lbl_out_rang                :4;
    uint32 color                            :2; /* used by acl */
    uint32 flow_policer_valid               :1; /* used by acl */

    uint32 flow_policer_ptr                 :13; /* used by acl */
    uint32 acl_log_en0                      :1; /* used by acl */
    uint32 acl_log_id0                      :2; /* used by acl */
    uint32 acl_log_en1                      :1; /* used by acl */
    uint32 acl_log_id1                      :2; /* used by acl */
    uint32 acl_log_en2                      :1; /* used by acl */
    uint32 acl_log_id2                      :2; /* used by acl */
    uint32 acl_log_en3                      :1; /* used by acl */
    uint32 acl_log_id3                      :2; /* used by acl */
    uint32 user_priority                    :6;

    uint32 deny_learning                    :1; /* used by acl */
    uint32 deny_route                       :1; /* used by acl */
    uint32 deny_bridge                      :1; /* used by acl */
    uint32 user_priority_valid              :1; /* used by acl */
    uint32 user_color                       :2;
    uint32 is_ipv4_ucast_rpf                :1; /*routing*/
    uint32 is_ipv6_ucast_rpf                :1; /*routing*/
    uint32 is_ipv4_pbr                      :1; /*routing*/
    uint32 is_ipv6_pbr                      :1; /*routing*/
    uint32 outer_color                      :2; /* used by acl */
    uint32 payload_offset                   :8; /* user id */
    uint32 mark_drop                        :1;  /* used by classification */
    uint32 is_ipv4_ucast_nat                :1;
    uint32 is_mpls_switched                 :1; /*routing*/
    uint32 is_mpls_packet                   :1;
    uint32 is_ipv6_mcast                    :1; /*routing*/

    uint32 is_ipv6_ucast                    :1; /*routing*/
    uint32 is_ipv4_mcast                    :1; /*routing*/
    uint32 is_ipv4_ucast                    :1; /*routing*/
    uint32 acl_tcam_result_valid0           :1; /* used by acl */
    uint32 acl_tcam_result_valid1           :1; /* used by acl */
    uint32 acl_tcam_result_valid2           :1; /* used by acl */
    uint32 acl_tcam_result_valid3           :1; /* used by acl */
    uint32 acl_hash_result_valid            :1; /* used by acl */
    uint32 is_router_mac                    :1;
    uint32 stp_state                        :2;
    uint32 l3_acl_routed_only               :1;
    uint32 l3_span_id                       :2;
    uint32 l3_span_en                       :1;
    uint32 l3_acl_en0                       :1;
    uint32 l3_acl_en1                       :1;
    uint32 l3_acl_en2                       :1;
    uint32 l3_acl_en3                       :1;
    uint32 l3_ipv6_acl_en0                  :1;
    uint32 l3_ipv6_acl_en1                  :1;
    uint32 l3_if_type                       :1; /*routing*/

    uint32 v4_ucast_en                      :1;
    uint32 v4_mcast_en                      :1;
    uint32 v6_ucast_en                      :1;
    uint32 l3_acl_label                     :10; /* used by interface mapper */
    uint32 v6_mcast_en                      :1;
    uint32 v4_ucast_sa_type                 :2;
    uint32 mpls_en                          :1;
    uint32 mcast_mac_address                :1; /* bridge*/
    uint32 bcast_mac_address                :1; /* bridge*/
    uint32 default_pcp                      :3;  /* user id */

    uint32 igmp_snoop_en                    :1; /*bridge*/
    uint32 mac_security_vlan_discard        :1; /*learning*/
    uint32 global_src_port                  :14; /*fcoe*/
    uint32 user_vrf_id_valid                :1;
    uint32 fatal_exception_valid            :1;/*routing*/
    uint32 flow_stats_ptr                   :14;


    uint32 flow_stats1_ptr                  :16;/* used by acl */
    uint32 flow_stats2_ptr                  :16;

    uint32 flow_stats0_ptr                  :16;/* used by acl */
    uint32 flow_stats_valid                 :1;
    uint32 flow_stats1_valid                :1;/* used by acl */
    uint32 flow_stats2_valid                :1;
    uint32 flow_stats0_valid                :1; /* used by acl */
    uint32 ipg                              :8; /* used by acl */
    uint32 pbb_src_port_type                :3; /* bridge*/
    uint32 vpls_sgmac_valid                 :1;

    uint32 outer_ttl                        :8;
    uint32 outer_priority                   :6; /* used by acl */
    uint32 user_vrf_id                      :16;
    uint32 service_acl_qos_en               :1;
    uint32 service_policer_valid            :1;  /* used by classification */

    uint32 vpls_dest_port                   :14;
    uint32 service_policer_ptr              :13;  /* used by classification */
    uint32 src_outer_vlan_is_svlan          :1; /* user id */
    uint32 rx_oam_type                      :4; /* used by acl */

    uint32 from_sgmac                       :1;
    uint32 ether_oam_discard                :1; /* bridge*/
    uint32 user_vlan_ptr                    :13;
    uint32 user_vlan_ptr_valid              :1;
    uint32 user_cvlan_id                    :12;

    uint32 user_svlan_id                    :12;
    uint32 svlan_id_action                  :2;
    uint32 cvlan_id_action                  :2;
    uint32 svlan_tpid_index                 :2; /* aclqos */
    uint32 cvlan_id_valid                   :1;
    uint32 svlan_id_valid                   :1;
    uint32 cvlan_id                         :12;/*learning*/

    uint32 svlan_id                         :12;/*learning*/
    uint32 vlan_ptr                         :13;
    uint32 force_bridge                     :1; /* bridge*/
    uint32 exception_sub_index              :6; /* user id */

    uint32 time_stamp61_32                  :30; /* lkp */
    uint32 time_stamp31_0                   :32; /* lkp */

    uint32 ptp_exception_en                 :1;  /* user id */
    uint32 pbr_label                        :6;
    uint32 pfm                              :2;
    uint32 mirror                           :1;
    uint32 op_code                          :3;
    uint32 l3                               :1;
    uint32 dst_mod_id_mg_id                 :16;
    uint32 mac_known                        :1; /* bridge*/
    uint32 outer_vlan_is_cvlan              :1; /* aclqos */
    uint32 outer_mac_sa_lookup_en           :1; /* outer learning */

    uint32 route_lookup_mode                :1;
    uint32 mpls_section_lm_en               :1;
    uint32 ether_lm_valid                   :1;
    uint32 bytes_remove_error               :1;

    uint32 aps_select_valid0                :1;/*learning*/
    uint32 aps_select_valid1                :1;
    uint32 aps_select_valid2                :1;
    uint32 aps_select_group_id              :10; /*routing*/
    uint32 aps_select_group_id0             :10; /*bridge*/
    uint32 aps_select_group_id1             :10;
    uint32 aps_select_group_id2             :10;
    uint32 aps_select_protecting_path       :1; /*routing*/
    uint32 aps_select_protecting_path0      :1; /*learning*/
    uint32 aps_select_protecting_path1      :1;
    uint32 aps_select_protecting_path2      :1;
    uint32 default_dei                      :1;  /* user id */
    uint32 priority_path_en                 :1; /* used by acl */
    uint32 src_tagged                       :1;  /* user id */
    uint32 src_dscp                         :6; /*routing*/
    uint32 src_dscp_valid                   :1; /*routing*/
    uint32 ip_sa_mode                       :2; /*routing*/
    uint32 bridge_aps_select_en             :1; /*bridge*/
    uint32 port_log_en                      :1;  /* user id */
    uint32 igmp_packet                      :1; /*routing*/
    uint32 mcast_address_check_failure      :1;
    uint32 isatap_check_ok                  :1; /*routing*/

    uint32 mpls_label_space                 :8;
    uint32 ppd_type                         :3;
    uint32 eth_multicast_header_hash        :8;
    uint32 ip_multicast_header_hash         :8;
    uint32 layer3_exception                 :1; /*routing*/
    uint32 unknown_gre_protocol             :1;
    uint32 gre_payload_packet_type          :3;

    uint32 layer3_exception_sub_index       :6;
    uint32 oam_result_valid                 :1;
    uint32 is_fcoe                          :1; /*fcoe*/
    uint32 is_trill_ucast                   :1; /*routing*/
    uint32 is_trill_mcast                   :1; /*routing*/
    uint32 esp_id                           :14;/* outer learning */
    uint32 mac_security_vsi_discard         :1; /*learning*/
    uint32 hash_conflict0                   :1;
    uint32 hash_conflict1                   :1;
    uint32 hash_conflict2                   :1;
    uint32 efm_loopback_en                  :1; /* user id */
    uint32 ptp_en                           :1;
    uint32 use_default_vlan_lookup          :1; /* user id */
    uint32 lm_result_valid0                 :1;
    uint32 lm_result_valid1                 :1;
    uint32 lm_result_valid2                 :1;

    /*uint32 mep_index                        :13;*/ /*forward*/
    uint32 random_log_en                    :1; /* user id */
    /*uint32 oam_dest_chip_id                 :5;*/
    uint32 lm_lookup_type                   :2;
    uint32 link_lm_default_svlan            :1;

    uint32 lm_packet_type                   :3;
    uint32 lm_write_packet                  :1;
    /*uint32 lm_received_packet               :1;*/
    /*uint32 mip_en                           :1;*/
    uint32 vrf_id                           :14;
    uint32 is_port_mac                      :1;   /*used by interface mapper*/
    uint32 arp_exception_type               :2;
    uint32 dhcp_exception_type              :2;
    uint32 is_decap                         :1; /*routing*/
    uint32 inner_packet_lookup              :1;
    uint32 is_fcoe_rpf                      :1; /*fcoe*/

    /*uint32 rx_fcl                           :32;*/
    //uint32 tx_fcl                           :32;
    /*uint32 rx_fcb                           :32;*/
    //uint32 tx_fcb                           :32;
    uint32 ach_lm_64_en                     :1;

    uint32 tunnel_lookup_result1_valid      :1;
    uint32 tunnel_lookup_result2_valid      :1;
    uint32 vsi_learning_disable             :1;
    uint32 mpls_oam_check                   :1;
    uint32 mpls_oam_label                   :2;
    uint32 oam_label_exist                  :1;
    uint32 mac_sa_hash_result_valid         :1;
    uint32 outer_mac_sa_hash_result_valid   :1; /* lkp */
    uint32 mac_da_hash_result_valid         :1;
    uint32 mac_sa_tcam_result_valid         :1;
    uint32 tcam_outer_mac_sa_result_valid   :1; /* lkp */
    uint32 mac_da_tcam_result_valid         :1;
    uint32 new_color                        :2;  /* used by classification */
    uint32 ipsa_tcam_result_valid           :1;
    uint32 ipda_tcam_result_valid           :1; /*routing*/
    uint32 ipsa_fib_result_valid            :1;
    uint32 ipda_fib_result_valid            :1; /*routing*/
    uint32 oam_exception_en                 :1;
    uint32 oam_lookup_en                    :1;
    uint32 oam_tcam_en                      :1;
    uint32 oam_lookup_num                   :2;
    uint32 lm_lookup_en0                    :1;
    uint32 lm_lookup_en1                    :1;
    uint32 lm_lookup_en2                    :1;
    uint32 mac_da_lookup_en                 :1; /* lookup manager */
    uint32 mac_sa_lookup_en                 :1; /* lookup manager */
    uint32 acl_hash_lookup_en               :1; /* lookup manager */
    uint32 acl_lookup_en                    :1;
    uint32 qos_lookup_en                    :1;
    uint32 layer3_da_lookup_en              :1;
    uint32 layer3_sa_lookup_en              :1;
    uint32 layer3_da_lookup_mode            :2;
    uint32 layer3_sa_lookup_mode            :2;
    uint32 time_stamp_valid                 :1; /*userd by acl */
    uint32 ptp_transparent_clock_en         :1;
    uint32 oam_obey_user_id                 :1; /* user id */

    uint32 user_id_label1                   :6; /* user id */
    uint32 user_id_label2                   :6; /* user id */
    uint32 fid                              :14;
    uint32 mac_sa_hash_conflict             :1; /* lkp */
    uint32 outer_mac_sa_hash_conflict       :1; /* lkp */
    uint32 oam_use_fid                      :1;
    uint32 service_policer_mode             :1;
    uint32 egress_oam_use_fid               :1;

    uint32 user_vsi_id_valid                :1;
    uint32 user_vsi_id                      :16; /*used interface mapper*/
    uint32 user_fid_valid                   :1;
    uint32 vsi_id_valid                     :1;
    uint32 inner_vsi_id                     :14;

    uint32 ipv4_mcast_address_check_failure :1;  /*routing*/
    uint32 ipv6_mcast_address_check_failure :1;
    uint32 inner_vsi_id_valid               :1; /* lkp */
    uint32 mpls_mip_en                      :1;
    uint32 itag_decap                       :1;
    uint32 new_isid                         :24;
    uint32 ip_header_error                  :1;
    uint32 ipv4_mcast_address               :1; /*routing*/
    uint32 ipv6_mcast_address               :1;

    uint32 classify_tos                     :8; /* used by acl */
    uint32 classify_layer3_type             :4; /* used by acl */
    uint32 classify_source_cos              :3;  /* used by acl */
    uint32 classify_source_cfi              :1;  /* used by acl */
    uint32 vlan_tag_operation_valid         :1;
    uint32 stag_action                      :2; /* aclqos */
    uint32 ctag_action                      :2; /* aclqos */
    uint32 ctag_cos                         :3; /* aclqos */
    uint32 ctag_cfi                         :1; /* aclqos */
    uint32 src_ctag_offset_type             :1;
    uint32 ptp_extra_offset                 :2;
    uint32 mpls_overwrite_priority          :1; /* used by acl */
    uint32 ptp_id                           :1;

    uint32 ecmp_hash                        :8; /*routing*/
    uint32 vlan_storm_ctl_ptr               :6; /* bridge*/
    uint32 vlan_storm_ctl_en                :1;
    uint32 ptp_lable_valid                  :1;
    uint32 ttl_update                       :1;
    uint32 tunnel_rpf_check_request         :1;
    uint32 mpls_lm_valid0                   :1;
    uint32 mpls_lm_valid1                   :1;
    uint32 mpls_lm_valid2                   :1;
    uint32 mpls_lm_label0                   :2;
    uint32 mpls_lm_label1                   :2;
    uint32 mpls_lm_label2                   :2;
    uint32 pt_enable                        :1; /*routing*/
    uint32 ipv4_src_embeded_mode            :1; /*routing*/

    uint32 mpls_oam_dest_chipid             :5;
    uint32 mpls_mep_index                   :13;
    uint32 mpls_mep_check                   :1;
    uint32 mpls_single_lm_stats_cos_en0     :1;
    uint32 mpls_single_lm_stats_cos_en1     :1;
    uint32 mpls_single_lm_stats_cos_en2     :1;
    uint32 mpls_lm_type0                    :1;
    uint32 mpls_lm_type1                    :1;
    uint32 mpls_lm_type2                    :1;
    uint32 mpls_lm_base0                    :14;    /* used by tunnel terminate */
    uint32 mpls_lm_base1                    :14;    /* used by tunnel terminate */
    uint32 mpls_lm_base2                    :14;    /* used by tunnel terminate */
    uint32 mpls_lm_cos0                     :3; /* used by tunnel terminate */
    uint32 mpls_lm_cos1                     :3; /* used by tunnel terminate */
    uint32 mpls_lm_cos2                     :3; /* used by tunnel terminate */
    uint32 lm_type0                         :2;
    uint32 lm_type1                         :2;
    uint32 lm_type2                         :2;
    uint32 mpls_lm_cos_type0                :2;
    uint32 mpls_lm_cos_type1                :2;
    uint32 mpls_lm_cos_type2                :2;

    uint32 next_hop_ptr_valid               :1;
    uint32 next_hop_ptr                     :16;
    uint32 dest_map                         :22;
    uint32 length_adjust_type               :1;
    uint32 critical_packet                  :1;
    uint32 next_hop_ext                     :1;
    uint32 send_local_phy_port              :1;
    uint32 aps_type                         :2;

    uint32 mpls_hash                        :8;
    uint32 mpls_section_oam                 :1;
    uint32 mpls_extra_payload_offset        :3;
    uint32 scos_action                      :2;
    uint32 ccos_action                      :2;
    uint32 user_scos                        :3;
    uint32 user_scfi                        :1;
    uint32 user_ccos                        :3;
    uint32 user_ccfi                        :1;
    uint32 ctag_add_mode                    :1;
    uint32 ctag_modify_mode                 :1;
    uint32 stag_modify_mode                 :1;
    uint32 mac_tcam_lookup_en               :1; /* outer learing */
    uint32 port_storm_ctl_ptr               :6; /* bridge*/
    uint32 acl_qos_use_outer_info           :1;
    uint32 port_storm_ctl_en                :1;
    uint32 link_oam_lm_cos                  :3;
    uint32 ip_sa_prefix_length              :3; /*routing*/
    uint32 trill_da_tcam_result_valid       :1; /*lkp*/
    uint32 trill_da_fib_result_valid        :1; /*lkp*/
    uint32 trill_vlan_da_fib_result_valid   :1; /*lkp*/
    uint32 trill_version_match              :1;
    uint32 pbb_mcast_loopback               :1; /* user id */
    uint32 mux_destination                  :16; /* pe format adjust*/
    uint32 mux_destination_type             :1;  /* ipe header adjust */
    uint32 non_crc                          :1;  /* ipe header adjust */

    uint32 svlan_key_first                  :1; /* user id */
    uint32 classify_stag_cos                :3; /* user id */
    uint32 classify_stag_cfi                :1; /* user id */
    uint32 classify_ctag_cos                :3; /* user id */
    uint32 classify_ctag_cfi                :1; /* user id */
    uint32 flow_id                          :4; /* used by acl */
    uint32 agg_flow_policer_valid           :1; /* used by acl */
    uint32 agg_flow_policer_ptr             :13;/* used by acl */
    uint32 rpf_type                         :1; /* routing*/
    uint32 src_address_mode                 :1; /* routing*/
    uint32 svlan_tag_operation_valid        :1; /* user id */
    uint32 cvlan_tag_operation_valid        :1; /* user id */
    uint32 is_conversation                  :1; /* bridge*/
    uint32 isid_translate_en                :1; /* forward*/

    uint32 mpls_mip_check_en                :1; /* used in MPLS and IPE OAM*/
    uint32 extra_payload_offset             :3;
    uint32 is_mpls_ttl_one                  :1;
    uint32 cmac_ecmp_hash                   :8; /* lkp */
    uint32 cmac_header_hash                 :8; /* lkp */
    uint32 mac_ecmp_hash                    :8; /* lkp */
    uint32 ecn_en                           :1; /* lkp */
    uint32 ecn_priority_en                  :1; /* lkp */
    uint32 ecn_aware                        :1; /* lkp */
    uint32 tunnel_ptp_en                    :1; /* lkp */
    uint32 tunnel_ptp_id                    :1; /* lkp */
    uint32 acl_dscp_valid                   :1; /*aclqos*/
    uint32 acl_dscp                         :6; /*aclqos*/
    uint32 gal_exist                        :1; /*oam*/
    uint32 entropy_label_exist              :1; /*oam*/
    uint32 ipv4_key_use_label               :1; /* lkp */
    uint32 ipv6_key_use_label               :1; /* lkp */
    uint32 mac_key_use_label                :1; /* lkp */
    uint32 mpls_key_use_label               :1; /* lkp */
    uint32 oam_tcam_lookup_en               :1; /* lkp */
    uint32 inter_laken_en                   :1; /*forward*/

    uint32 pip_bypass_learning              :1; /*tunnel*/
    uint32 ipda_fib_default_entry_valid     :1; /*lookup*/
    uint32 ipsa_fib_default_entry_valid     :1; /*lookup*/
    uint32 fcoe_lookup_mode                 :2; /*lookup*/
    uint32 fcoe_da_tcam_result_valid        :1; /*lookup*/
    uint32 fcoe_sa_tcam_result_valid        :1; /*lookup*/
    uint32 fcoe_da_fib_result_valid         :1; /*lookup*/
    uint32 fcoe_sa_fib_result_valid         :1; /*lookup*/
    uint32 fcoe_da_fib_default_entry_valid  :1; /*lookup*/
    uint32 fcoe_sa_fib_default_entry_valid  :1; /*lookup*/
    uint32 trill_lookup_mode                :2;
    uint32 trill_da_fib_default_entry_valid :1; /*lookup*/
    uint32 mac_da_default_entry_valid       :1; /*lookup*/
    uint32 mac_sa_default_entry_valid       :1; /*lookup*/
    uint32 outer_mac_sa_default_entry_valid :1; /*lookup*/

    uint32 pbb_outer_learning_enable        :1; /* used by tunnel terminate */
    uint32 pbb_outer_learning_disable       :1; /* used by tunnel terminate */
    uint32 exception_en                     :1; /*userid*/
    uint32 exception_index                  :3; /*userid*/
    uint32 scfi_action                      :2; /*userid*/
    uint32 ccfi_action                      :2; /*userid*/
    uint32 is_ipv4                          :1; /*oam*/

    uint32 bfd_single_hop_ttl_match         :1;
    uint32 ip_martian_address               :1;
    uint32 ip_link_scope_address            :1;
    uint32 is_ipv4_icmp_err_msg             :1;
    uint32 is_ipv6_icmp_err_msg             :1;
    uint32 source_port_extender             :1;     /* used by ipe_header_adjust */
    uint32 mpls_label_space_valid           :1;     /* used by ipe_header_adjust */
    uint32 tx_dm_en                         :1;     /* used by ipe_header_adjust */
    uint32 link_oam_en                      :1;     /* used by ipe_interface_mapper */
    uint32 fast_learning_en                 :1;     /* used by ipe_interface_mapper */
    uint32 port_mac_limit_ptr               :8;     /* used by ipe_interface_mapper */
    uint32 port_mac_threshold_id            :4;     /* used by ipe_interface_mapper */
    uint32 pbb_check_discard                :1;     /* used by ipe_interface_mapper */
    uint32 vlan_mac_limit_ptr               :8;     /* used by ipe_interface_mapper */
    uint32 vlan_mac_threshold_id            :4;     /* used by ipe_interface_mapper */
    uint32 force_ip_lookup                  :1;     /* used by ipe_interface_mapper */
    uint32 rpf_permit_default               :1;     /* used by ipe_interface_mapper */
    uint32 mac_ip_lookup_en                 :1;     /* used by ipe_mac_bridge */
    uint32 mac_hash_lookup_en               :1;     /* used by ipe_mac_bridge */
    uint32 ad_next_hop_ptr                  :16;    /* used by ipe_mac_bridge */
    uint32 ad_dest_map                      :22;    /* used by ipe_mac_bridge */
    uint32 ad_length_adjust_type            :1;     /* used by ipe_mac_bridge */
    uint32 ad_critical_packet               :1;     /* used by ipe_mac_bridge */
    uint32 ad_next_hop_ext                  :1;     /* used by ipe_mac_bridge */
    uint32 ad_send_local_phy_port           :1;     /* used by ipe_mac_bridge */
    uint32 ad_aps_type                      :2;     /* used by ipe_mac_bridge */
    uint32 ad_speed                         :2;     /* used by ipe_mac_bridge */
    uint32 storm_ctl_drop                   :1;     /* used by ipe_mac_bridge */
    uint32 storm_ctl_exception_en           :1;     /* used by ipe_mac_bridge */
    uint32 self_address                     :1;     /* used by ipe_classification */
    /*uint32 dm_en                            :1; */    /* used by ipe_forwarding */
    uint32 dm_offset                        :8;     /* used by ipe_header_adjust */
    uint32 second_parser                    :1;     /* tunnelModule out, lookupManager use */
    uint32 force_parser                     :1;     /* tunnelModule out, lookupManager use */
    uint32 is_esadi                         :1;
    uint32 mac_isolated_groupid             :6;     /* used by ipe_user_id */
    uint32 force_ipv6_key                   :1;     /* used by ipe_user_id */
    uint32 ucast_discard                    :1;     /* used by ipe_interface_map */
    uint32 mcast_discard                    :1;     /* used by ipe_interface_map */
    uint32 inner_logic_src_port_valid       :1;     /* used by ipe_tunnel */
    uint32 inner_logic_src_port             :14;    /* used by ipe_tunnel */
    uint32 aps_level_for_oam                :2;     /* used by ipe_tunnel */
    uint32 outer_learning_logic_src_port    :14;    /* used by ipe_outer_learning */

    uint32 header_mac_da_check_en           :1;    /* used by header_adjust */
    uint32 header_mac_da_check              :1;    /* used by header_adjust */
    uint32 header_mac_da47_32               :16;   /* used by header_adjust */
    uint32 header_mac_da31_0                :32;   /* used by header_adjust */
    uint32 outer_vlan_is_cvlan_valid        :1;    /* used by header_adjust */
    uint32 ether_oam_edge_port              :1;    /* used by interface map */
    uint32 fid_type                         :1;    /* used by mpls_tunnel   */
    uint32 link_or_section_OAM              :1;    /* used by mpls_tunnel   */
    uint32 is_icmp                          :1;    /* used by lookup manager*/
    uint32 force_ipv4_lookup                :1;    /* used by interfacemapper */
    uint32 force_ipv6_lookup                :1;    /* used by interfacemapper */
    uint32 ip_mac_da_hash_result_valid         :1;
    uint32 ip_mac_da_tcam_result_valid         :1;
    uint32 ip_mac_da_default_entry_valid       :1; /*lookup*/

    uint32 vlan_range_type                  :1;
    uint32 vlan_range_profile_en            :1;
    uint32 vlan_range_profile               :6;
    uint32 qcn_port_id                      :4;

    uint32 port_mac_label                   :8;
    uint32 port_mac_type                    :2;
    uint32 is_all_rbridge_address           :1;
    uint32 app_data_valid                   :1;  /* used by ipe_lookupmanager */

    uint32 exception2_lm_en                 :1;
    uint32 exception2_lm_down_en            :1;
    uint32 exception2_lm_up_en              :1;

    ds_tunnel_id_t userid_tunnel_lkp1_ad;
    ds_tunnel_id_t userid_tunnel_lkp2_ad;

};
typedef struct ipe_packet_info_s ipe_packet_info_t;


struct mep_level_info_s
{
    uint32  valid      :1;
    uint32  mep_index  :13;
    uint32  res        :18;
};
typedef struct mep_level_info_s mep_level_info_t;

struct oam_info_s
{
    uint32 lm_bitmap          :7;
    uint32 mip_bitmap         :7;
    uint32 lm_index_base      :14;
    uint32 rsv                :4;
};
typedef struct oam_info_s oam_info_t;

struct cm_oam_chan_info_s
{
    ds_eth_oam_chan_t* p_ds_eth_oam_chan;
    oam_info_t *p_oam_chan_info;
    uint8 next_lm;
    uint8 parser_oam_level;
};
typedef struct cm_oam_chan_info_s cm_oam_chan_info_t;

struct cm_oam_chan_rslt_s
{
    /*
    mep_level_info_t *mep_up_info[MAX_MEP_LEVEL];
    mep_level_info_t *mep_down_info[MAX_MEP_LEVEL];
    */
    mep_level_info_t *mep_up_info;
    mep_level_info_t *mep_down_info;
    cm_oam_lm_info_t *lm_info;
    uint8 down_min_valid_lvl;
    uint8 down_max_valid_lvl;
    uint8 up_min_valid_lvl;
    uint8 up_max_valid_lvl;
};
typedef struct cm_oam_chan_rslt_s cm_oam_chan_rslt_t;


struct ipe_learn_proc_input_info_s
{
    uint32 fast_learning_en     :1;
    uint32 learning_source_port :14;
    uint32 is_global_src_port   :1;
    uint32 vsi_id               :14;
    uint32 ether_oam_level      :3;
    uint32 is_ether_oam         :1;
    uint32 aps_select_valid     :1;
    uint32 aps_select_group_id  :11;
    uint32 old_svlan_id         :12;
    uint32 old_cvlan_id         :12;
    uint32 new_svlan_id         :12;
    uint32 new_cvlan_id         :12;
    uint32 mac_sa_47_32         :16;
    uint32 mac_sa_31_0          :32;
    uint32 is_outer_learning    :1;
};
typedef struct ipe_learn_proc_input_info_s ipe_learn_proc_input_info_t;

enum modify_mode_e
{
    MODIFY_MODE_UPGRADE_NONE,
    MODIFY_MODE_UPGRADE_ADD,
    MODIFY_MODE_UPGRADE_NUM,
};
typedef enum modify_mode_e modify_mode_t;

extern int32 cm_ipe_header_adjust_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_dcpt_and_parsing_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_user_identify_user_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_interface_mapper(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_tunnel_terminate_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_lookup_manager_lookup_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_oam_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_aging_intialize(void);

extern int32 cm_ipe_aging_release(void);

extern int32 cm_sim_get_aging_exception(uint8 chip_id, bool *excepton);

extern int32 cm_sim_wait_aging_event(void);

extern int32 cm_update_aging_cache(uint8 chip_id, uint32 type, uint32 aging_ptr, uint32 valid);

extern int32 cm_ipe_storm_intialize(void);

extern int32 cm_ipe_storm_release(void);

extern int32 cm_ipe_acl_qos_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_classification_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_routing_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_fcoe_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_trill_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_bridge_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_learning_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_learning_intialize(void);

extern int32 cm_ipe_learning_release_os_objects(void);

extern int32 cm_sim_get_learn_exception(uint8 chip_id, bool *excepton);

extern int32 cm_sim_wait_learn_event(void);

extern int32 cm_ipe_forwarding_handle(ipe_in_pkt_t *in_pkt);

extern int32 cm_ipe_exception3_cam_lookup(uint8 chip_id, uint8 l3_header_protocol,
                                          uint8 *exp_esp_cam_hit, uint8 *exp_sub_index);

extern int32 cm_ipe_exception3_cam_lookup2(uint8 chip_id,uint8 is_udp, uint8 is_tcp, uint16 dst_port,
                                           uint8 *exp_esp_cam_hit, uint8 *exp_sub_index);

extern int32 cm_ipe_outer_learning_handle(ipe_in_pkt_t *p_inpkt);

extern int32 cm_com_oam_get_mep_info(cm_oam_chan_info_t *chan_info, cm_oam_chan_rslt_t *chan_rslt);


extern int32 cm_ipe_learning_learn_mac_sa(ipe_in_pkt_t *in_packet, ipe_learn_proc_input_info_t *p_learn_info);

#endif

