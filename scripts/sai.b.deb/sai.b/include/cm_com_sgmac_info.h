/****************************************************************************
 * cm_com_sgmac_info.h: All packet type Deinfines.
 * Copyright:  (c)2010 Centec Networks Inc. All rights reserved.
 *
 * Revision:      V1.0.
 * Author:       Zhouw.
 * Date:         2008-09-17.
 * Reason:       First Create.
 *
 * Modify History:
 * Revision:      R0.02.
 * Reviser        Xuzx.
 * Date:         2010-10-08.
 * Reason:       Change file name to cm_com_sgmac_info.h
 ****************************************************************************/
#ifndef _CM_COM_SGMAC_INFO_H_
#define _CM_COM_SGMAC_INFO_H_

#include "cm_com_common.h"
/****************************************************************************
 *
* Defines and Macros
*
****************************************************************************/
#define CM_SGMAC_PLUS_HEADER_LEN  12
#define CM_SGMAC2_HEADER_LEN      16

#define CM_SGMAC_PLUS_VERSION      1
#define CM_SGMAC2_VERSION          0

#if CTC_HOST_IS_LITTLE_ENDIAN                                                    /* little endian */
struct cm_sgmac_plus_header_s
{
    uint32 sgmac_plus_vid_low                                                                :8;
    uint32 sgmac_plus_vid_high                                                               :8;
    uint32 sgmac_plus_dst_modid_6                                                        :1;
    uint32 sgmac_plus_src_modid_6                                                        :1;
    uint32 sgmac_plus_hdr_ext_len                                                         :3;
    uint32 sgmac_plus_rsv1                                                                      :1;
    uint32 sgmac_plus_hgi                                                                       :2;
    uint32 sgmac_plus_start                                                                    :8;

 /*   uint32 sgmac_plus_ppd_type                                                              :3;*/
    uint32 sgmac_plus_dst_modid                                                            :5;
    uint32 sgmac_plus_cng                                                                       :1;
    uint32 sgmac_plus_header_type                                                        :2;
    uint32 sgmac_plus_cos                                                                       :3;
    uint32 sgmac_plus_dst_port                                                               :5;
    uint32 sgmac_plus_src_pid                                                                 :6;
    uint32 sgmac_plus_pfm                                                                      :2;
    uint32 sgmac_plus_opcode                                                                 :3;
    uint32 sgmac_plus_src_modid                                                            :5;

    uint32 sgmac_plus_vc_label_7_0                                                        :8;
    uint32 sgmac_plus_vc_label_15_8                                                      :8;
    uint32 sgmac_plus_vc_label_19_16                                                    :4;
    uint32 sgmac_plus_label_present                                                       :1;
    uint32 sgmac_plus_l3                                                                           :1;
    uint32 sgmac_plus_dst_mod_5                                                            :1;
    uint32 sgmac_plus_src_mod_5                                                            :1;
    uint32 sgmac_plus_mirror                                                                   :1;
    uint32 sgmac_plus_mirror_done                                                         :1;
    uint32 sgmac_plus_mirror_only                                                          :1;
    uint32 sgmac_plus_ingress_tagged                                                    :1;
    uint32 sgmac_plus_dst_tgid                                                                :3;
    uint32 sgmac_plus_dst_t                                                                     :1;
};


union cm_sgmac2_header_u
{
    struct {
        uint8 byte[16];
    } overlay0;

    struct {    /*ppd type 0*/
        uint32 sgmac2_dst_port_mgidl    :8;
        uint32 sgmac2_dst_modid_mgidh   :8;
        uint32 sgmac2_tc                :4;
        uint32 sgmac2_mcst              :1;
        uint32 sgmac2_rsv1              :3;
        uint32 sgmac2_sop               :8;

        uint32 sgmac2_ppd_ty            :3;
        uint32 sgmac2_rsvd_6            :3;
        uint32 sgmac2_dp                :2;
        uint32 sgmac2_lbid              :8;
        uint32 sgmac2_src_pid           :8;
        uint32 sgmac2_src_modid         :8;

        uint32 sgmac2_vc_label_7_0      :8;
        uint32 sgmac2_vc_label_15_8     :8;
        uint32 sgmac2_vc_label_19_16    :4;
        uint32 sgmac2_label_precent     :1;
        uint32 sgmac2_l3                :1;
        uint32 sgmac2_rsvd_55_54        :2;
        uint32 sgmac2_mirror            :1;
        uint32 sgmac2_mirror_done       :1;
        uint32 sgmac2_mirror_only       :1;
        uint32 sgmac2_ingress_tagged    :1;
        uint32 sgmac2_dst_tgid          :3;
        uint32 sgmac2_dst_t             :1;

        uint32 sgmac2_rsvd_4_0          :5;
        uint32 sgmac2_hdr_ext_len       :3;
        uint32 sgmac2_opcode            :3;
        uint32 sgmac2_rsvd_12_11        :2;
        uint32 sgmac2_src_t             :1;
        uint32 sgmac2_pfm               :2;
        uint32 sgmac2_vid_low           :8;
        uint32 sgmac2_vid_high          :8;

    } ppd_ty0;

    struct {    /*ppd type 2*/
        uint32 sgmac2_dst_port_mgidl    :8;
        uint32 sgmac2_dst_modid_mgidh   :8;
        uint32 sgmac2_tc                :4;
        uint32 sgmac2_mcst              :1;
        uint32 sgmac2_rsv1              :3;
        uint32 sgmac2_sop               :8;

        uint32 sgmac2_ppd_ty            :3;
        uint32 sgmac2_rsvd_6            :3;
        uint32 sgmac2_dp                :2;
        uint32 sgmac2_lbid              :8;
        uint32 sgmac2_src_pid           :8;
        uint32 sgmac2_src_modid         :8;

        uint32 sgmac2_dest_vp_low       :8;
        uint32 sgmac2_dest_vp_high      :8;
        uint32 sgmac2_rsvd_25_16        :10;
        uint32 sgmac2_fwd_type          :5;
        uint32 sgmac2_multi_point       :1;

        uint32 sgmac2_rsvd_7_0          :8;
        uint32 sgmac2_opcode            :3;
        uint32 sgmac2_rsvd_11           :1;
        uint32 sgmac2_lag_failover      :1;
        uint32 sgmac2_donot_learn       :1;
        uint32 sgmac2_donot_modify      :1;
        uint32 sgmac2_mirror            :1;
        uint32 sgmac2_src_vp_low        :8;
        uint32 sgmac2_src_vp_high       :8;

    } ppd_ty2;
};
#else                                                                                                /* big endian */
struct cm_sgmac_plus_header_s
{
    uint32 sgmac_plus_start                                                                    :8;
    uint32 sgmac_plus_hgi                                                                       :2;
    uint32 sgmac_plus_rsv1                                                                      :1;
    uint32 sgmac_plus_hdr_ext_len                                                         :3;
    uint32 sgmac_plus_src_modid_6                                                        :1;
    uint32 sgmac_plus_dst_modid_6                                                        :1;
    uint32 sgmac_plus_vid_high                                                               :8;
    uint32 sgmac_plus_vid_low                                                                :8;

    uint32 sgmac_plus_src_modid                                                            :5;
    uint32 sgmac_plus_opcode                                                                 :3;
    uint32 sgmac_plus_pfm                                                                      :2;
    uint32 sgmac_plus_src_pid                                                                 :6;
    uint32 sgmac_plus_dst_port                                                               :5;
    uint32 sgmac_plus_cos                                                                       :3;
    uint32 sgmac_plus_header_type                                                        :2;
    uint32 sgmac_plus_cng                                                                       :1;
    uint32 sgmac_plus_dst_modid                                                            :5;
  /*  uint32 sgmac_plus_ppd_type                                                              :3;*/

    uint32 sgmac_plus_dst_t                                                                     :1;
    uint32 sgmac_plus_dst_tgid                                                                :3;
    uint32 sgmac_plus_ingress_tagged                                                    :1;
    uint32 sgmac_plus_mirror_only                                                          :1;
    uint32 sgmac_plus_mirror_done                                                         :1;
    uint32 sgmac_plus_mirror                                                                   :1;
    uint32 sgmac_plus_src_mod_5                                                            :1;
    uint32 sgmac_plus_dst_mod_5                                                            :1;
    uint32 sgmac_plus_l3                                                                           :1;
    uint32 sgmac_plus_label_present                                                       :1;
    uint32 sgmac_plus_vc_label_19_16                                                    :4;
    uint32 sgmac_plus_vc_label_15_8                                                      :8;
    uint32 sgmac_plus_vc_label_7_0                                                        :8;

};


union cm_sgmac2_header_u
{
    struct {
        uint8 byte[16];
    } overlay0;

    struct {    /*ppd type 0*/
        uint32 sgmac2_sop               :8;
        uint32 sgmac2_rsv1              :3;
        uint32 sgmac2_mcst              :1;
        uint32 sgmac2_tc                :4;
        uint32 sgmac2_dst_modid_mgidh   :8;
        uint32 sgmac2_dst_port_mgidl    :8;

        uint32 sgmac2_src_modid         :8;
        uint32 sgmac2_src_pid           :8;
        uint32 sgmac2_lbid              :8;
        uint32 sgmac2_dp                :2;
        uint32 sgmac2_rsvd_6            :3;
        uint32 sgmac2_ppd_ty            :3;

        uint32 sgmac2_dst_t             :1;
        uint32 sgmac2_dst_tgid          :3;
        uint32 sgmac2_ingress_tagged    :1;
        uint32 sgmac2_mirror_only       :1;
        uint32 sgmac2_mirror_done       :1;
        uint32 sgmac2_mirror            :1;
        uint32 sgmac2_rsvd_55_54        :2;
        uint32 sgmac2_l3                :1;
        uint32 sgmac2_label_precent     :1;
        uint32 sgmac2_vc_label_19_16    :4;
        uint32 sgmac2_vc_label_15_8     :8;
        uint32 sgmac2_vc_label_7_0      :8;

        uint32 sgmac2_vid_high          :8;
        uint32 sgmac2_vid_low           :8;
        uint32 sgmac2_pfm               :2;
        uint32 sgmac2_src_t             :1;
        uint32 sgmac2_rsvd_12_11        :2;
        uint32 sgmac2_opcode            :3;
        uint32 sgmac2_hdr_ext_len       :3;
        uint32 sgmac2_rsvd_4_0          :5;

    } ppd_ty0;

    struct {    /*ppd type 2*/
        uint32 sgmac2_sop               :8;
        uint32 sgmac2_rsv1              :3;
        uint32 sgmac2_mcst              :1;
        uint32 sgmac2_tc                :4;
        uint32 sgmac2_dst_modid_mgidh   :8;
        uint32 sgmac2_dst_port_mgidl    :8;

        uint32 sgmac2_src_modid         :8;
        uint32 sgmac2_src_pid           :8;
        uint32 sgmac2_lbid              :8;
        uint32 sgmac2_dp                :2;
        uint32 sgmac2_rsvd_6            :3;
        uint32 sgmac2_ppd_ty            :3;

        uint32 sgmac2_multi_point       :1;
        uint32 sgmac2_fwd_type          :5;
        uint32 sgmac2_rsvd_25_16        :10;
        uint32 sgmac2_dest_vp_high      :8;
        uint32 sgmac2_dest_vp_low       :8;

        uint32 sgmac2_src_vp_high       :8;
        uint32 sgmac2_src_vp_low        :8;
        uint32 sgmac2_mirror            :1;
        uint32 sgmac2_donot_modify      :1;
        uint32 sgmac2_donot_learn       :1;
        uint32 sgmac2_lag_failover      :1;
        uint32 sgmac2_rsvd_11           :1;
        uint32 sgmac2_opcode            :3;
        uint32 sgmac2_rsvd_7_0          :8;

    } ppd_ty2;
};
#endif

typedef struct cm_sgmac_plus_header_s cm_sgmac_plus_header_t;

typedef union cm_sgmac2_header_u cm_sgmac2_header_t;

enum sgmac_header_opcode_e
{
    SGMAC_HDR_OPCODE_CONTROL_FRAME = 0,
    SGMAC_HDR_OPCODE_UCAST_PACKET = 1,
    SGMAC_HDR_OPCODE_BCAST_PACKET = 2,
    SGMAC_HDR_OPCODE_L2_MCAST_PACKET = 3,
    SGMAC_HDR_OPCODE_IP_MCAST_PACKET = 4,
};
typedef enum sgmac_header_opcode_e sgmac_header_opcode;

#endif
