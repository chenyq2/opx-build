/****************************************************************************
 * cm_com_parser_le.h: Useful utility and const for ASIC C-Model packet
                    parsing module.
 * Copyright (c)2010 Centec Networks Inc. All rights reserved.
 *
 * Revision:     V1.0.
 * Author:       XuZx.
 * Date:         2010-07-11.
 * Reason:       First Create.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Mengzw.
 * Date:         2011-06-11.
 * Reason:       Redefine struct parse_result.
 *
 * Revision:     V4.31.0
 * Author:       XuZx.
 * Date:         2011-10-21.
 * Reason:       Sync spec v4.31.0.
 *
 * Revision:     V4.33.0
 * Author:       XuZx.
 * Date:         2011-10-25.
 * Reason:       Sync spec v4.33.0.
 *
 * Revision:     V5.0.0
 * Author:       XuZx.
 * Date:         2011-11-11.
 * Reason:       Sync spec v5.0.0.
 *
 * Revision:     V5.9.0
 * Author:       XuZx.
 * Date:         2012-02-02.
 * Reason:       Sync spec v5.9.0.
 *
 * Revision:     V5.11.0
 * Author:       XuZx.
 * Date:         2012-02-29.
 * Reason:       Sync spec v5.11.0.
 ****************************************************************************/
#ifndef _CM_COM_PARSER_LE_H_
#define _CM_COM_PARSER_LE_H_
/****************************************************************************
 *
* Header Files
*
****************************************************************************/

/****************************************************************************
 *
* Defines and Macros
*
****************************************************************************/
#define ETH_V2_MIN_LEN              14  /* Dmac(6B) + Smac(6B) + Type/Len(2B) */
#define ETH_SAP_MIN_LEN             17  /* Dmac(6B) + Smac(6B) + Len(2B) + DSAP(1B)
                                           + SSAP(1B)+ CTL0(1B) */
#define ETH_SNAP_MIN_LEN            22  /* Dmac(6B) + Smac(6B) + Len(2B) + DSAP(1B:0xAA)
                                           + SSAP(1B:0xAA)+ CTL(1B:0x03) */
#define RAW_SNAP_MIN_LEN            8   /* DSAP(1B:0xAA) + SSAP(1B:0xAA) + CTL(1B:0x03)
                                           + OUI(3B) + TYPE(2B) */
#define PPP2B_MIN_LEN               2   /* Protocol(2B) + CRC(4B) */
#define PPP1B_MIN_LEN               1   /* Protocol(1B) + CRC(4B) */
#define IPV4_MIN_LEN                20  /* From Version to DIPAddress(20B) */
#define IPV6_MIN_LEN                40  /* From Version to DIPAddress(40B) */
#define ARP_RARP_MIN_LEN            28
#define PBB_NO_CMAC_MIN_LEN         (4 + 2)  /* ISID(4B) + TYPE(2B) */
#define PBB_CMAC_MIN_LEN            18  /* ISID(4B) + TYPE(2B) + CMAC(12B)*/
#define TCP_MIN_LEN                 20  /* From SPort to UrgentPointer(20B) */
#define UDP_MIN_LEN                 8   /* From SPort to CheckSum(8B) */
#define IPV6_IN_IP_MIN_LEN          40
#define IGMP_MIN_LEN                8   /* From Type to GroupAddress(8B) */
#define IPV6_HOPBYHOP_MIN_LEN       (40 + 8)  /* ipv6 header(40B)+ hop by hop header(8B) */
#define IPV6_FRAGMENT_MIN_LEN       (40 + 8)  /* ipv6 header(40B)+ fragment header(8B) */
#define L3_OAM_CCM_MIN_LEN          75
#define L3_OAM_LMM_MIN_LEN          17
#define L3_FCOE_MIN_LEN             (14 + 20)
#define L3_TRILL_MIN_LEN            6
#define L3_PTP_V2_MIN_LEN           44
#define L3_PTP_V1_MIN_LEN           48
#define L4_UDP_PTP_V2_MIN_LEN       (8 + 44)
#define L4_UDP_PTP_V1_MIN_LEN       (8 + 48)
#define L4_OAM_BFD_MIN_LEN          (8 + 24)
#define L4_OAM_ACH_MIN_LEN          (4 + 4)
#define L4_OAM_CCM_MIN_LEN          (4 + 75)
#define L4_OAM_LMM_LMR_MIN_LEN      (4 + 17)
#define L4_OAM_ACH_BFD_MIN_LEN      (4 + 24)
#define L4_OAM_ACH_BFD_CC_MIN_LEN   (4 + 24)
#define L4_OAM_ACH_DLM_MIN_LEN      (4 + 52)
#define L4_OAM_ACH_DLMDM_MIN_LEN    (4 + 76)
#define L4_OAM_ACH_DM_MIN_LEN       (4 + 44)
#define L4_OAM_ACH_ILM_MIN_LEN      (4 + 52)
#define L4_OAM_ACH_DLMDM_MIN_LEN    (4 + 76)
#define L4_OAM_ACH_ILMDM_MIN_LEN    (4 + 76)
#define L4_RDP_MIN_LEN              18
#define L4_SCTP_MIN_LEN             12
#define L4_DCCP_MIN_LEN             16
#define IPV6_HEADER_LEN             40

union itag_tci_u
{
    uint32 itag_tci   :32;

    struct
    {
        uint32  isid    :24;
        uint32  res2    :2;
        uint32  res1    :1;
        uint32  nca     :1;
        uint32  i_dei   :1;
        uint32  pcp     :3;
    }share;
};
typedef union itag_tci_u itag_tci_t;

/* Layer3 parser union */
union ip_da_u
{
    /* for IPv6 */
    struct
    {
        uint32 ipda_127_96;
        uint32 ipda_95_64;
        uint32 ipda_63_32;
        uint32 ipda_31_0;
    }ipv6;

    /* for IPv4 */
    struct
    {
        uint32  res[3];

        uint32  ipda;
    }ipv4;

    /* for ARP */
    struct
    {
        uint32  protocel_add_len           :8;
        uint32  hardware_add_len           :8;
        uint32  res1                       :16;

        uint32  target_mac_47_32           :16;
        uint32  arp_op_code                :16;

        uint32  target_mac_31_0            :32;

        uint32  target_ip;
    }arp;

    /* for MPLS */
    struct
    {
        uint32 mpls_label0;
        uint32 mpls_label1;
        uint32 mpls_label2;
        uint32 mpls_label3;
    }mpls;

    /* for PBB */
    struct
    {
        itag_tci_t itag_tci;

        uint32 cmac_svlan_valid             :1;
        uint32 res                          :31;

        uint32 cmac_da_47_32                :16;
        uint32 cmac_svlan_id                :12;
        uint32 cmac_stag_cfi                :1;
        uint32 cmac_stag_cos                :3;

        uint32 cmac_da_31_0;
    }cmac;

    /* for slow protocol */
    struct
    {
        uint32 res[3];

        uint32 slow_protocol_code           :8;
        uint32 slow_protocol_flags          :16;
        uint32 slow_protocol_sub_type       :8;
    }slow_ptl;

    /* for Ethrenet OAM */
    struct
    {
        uint32 res1[3];

        uint32 eth_oam_op_code              :8;
        uint32 ether_oam_version            :5;
        uint32 eth_oam_level                :3;
        uint32 res2                         :16;
    }eth_oam;

    /* for PTP */
    struct
    {
       uint32 res1;

       uint32 ptp_message_type              :4;
       uint32 ptp_version                   :2;
       uint32 res2                          :26;

       uint32 ptp_correction_field_63_32;

       uint32 ptp_correction_field_31_0;
    }ptp;

    /* for FCoE */
    struct
    {
        uint32 res1[3];

        uint32 fcoe_did                     :24;
        uint32 res2                         :8;
    }fcoe;

    /* for TRILL */
    struct
    {
        uint32 res1                           :32;

        uint32 trill_bfd_my_discriminator31_13:19;
        uint32 res2                           :13;

        uint32 trill_version                  :2;
        uint32 is_trill_bfd                   :1;
        uint32 trill_length                   :14;
        uint32 is_trill_bfd_echo              :1;
        uint32 trill_multi_hop                :1;
        uint32 trill_bfd_my_discriminator12_0 :13;

        uint32 egress_nick_name               :16;
        uint32 trill_multicast                :1;
        uint32 trill_inner_vlan_valid         :1;
        uint32 trill_inner_vlan_id            :12;
        uint32 is_esadi                       :1;
        uint32 is_trill_channel               :1;
    }trill;

    /* for FLEXL3 */
    struct
    {
        uint32 res[2];

        uint32 flex_data_63_32;

        uint32 flex_data_31_0;
    }flex_l3;
};
typedef union ip_da_u ip_da_t;

union ip_sa_u
{
    /* for IPv6 */
    struct
    {
        uint32 ipsa_127_96;
        uint32 ipsa_95_64;
        uint32 ipsa_63_32;
        uint32 ipsa_31_0;
    }ipv6;

    /* for IPv4 */
    struct
    {
        uint32  res1[2];

        uint32  ip_check_sum       :16;
        uint32  res2               :16;

        uint32  ipsa;
    }ipv4;

    /* for ARP */
    struct
    {
        uint32  hardware_type      :16;
        uint32  res1               :16;

        uint32  sender_mac_47_32   :16;
        uint32  protocol_type      :16;

        uint32  sender_mac_31_0    :32;

        uint32  sender_ip;
    }arp;

    /* for MPLS */
    struct
    {
        uint32 mpls_label4;
        uint32 mpls_label5;
        uint32 mpls_label6;
        uint32 mpls_label7;
    }mpls;

    /* for PBB */
    struct
    {
        uint32 res1                :32;

        uint32 cmac_cvlan_valid    :1;
        uint32 cmac_ecmp_hash      :8;
        uint32 cmac_header_hash    :8;
        uint32 res2                :15;

        uint32 cmac_sa_47_32       :16;
        uint32 cmac_cvlan_id       :12;
        uint32 cmac_ctag_cfi       :1;
        uint32 cmac_ctag_cos       :3;

        uint32 cmac_sa_31_0        :32;
    }cmac;

    /* for Ethernet/Y.1731 OAM */
    struct
    {
        uint32 res;
        uint32 rx_fcb;
        uint32 tx_fcf;
        uint32 tx_fcb;
    }eth_oam;

    struct
    {
        uint32 res[2];
        uint32 ptp_timestamp_63_32;
        uint32 ptp_timestamp_31_0;
    }ptp;

    /* for FCoE */
    struct
    {
        uint32 res1[3];

        uint32 fcoe_sid            :24;
        uint32 res2                :8;
    }fcoe;

    /* for TRILL */
    struct
    {
        uint32 res1[3];

        uint32 ingress_nick_name   :16;
        uint32 res2                :16;
    }trill;

    /* for FLEXL3 */
    struct
    {
        uint32 res[4];
    }flex_l3;
};
typedef union ip_sa_u ip_sa_t;

union tos_u
{
    uint32 ip_tos                  :8;

    struct
    {
        uint32 label_num           :4;
        uint32 ip_over_mpls        :1;
        uint32 res                 :3;
    }mpls;
};
typedef union tos_u tos_t;

/* Layer4 parser union */
union l4_src_port_u
{
    uint32 l4_source_port          :16;
    uint32 gre_flags               :16;
};
typedef union l4_src_port_u l4_src_port_t;

union l4_dst_port_u
{
    uint32 l4_dest_port            :16;
    uint32 gre_protocol_type       :16;
};
typedef union l4_dst_port_u l4_dst_port_t;

union isatap_ptp_ver_u
{
    uint8 is_isatap_interface      :1;
    uint8 udp_ptp_version1         :1;
};
typedef union isatap_ptp_ver_u isatap_ptp_ver_t;

union gre_bfd_ptp_u
{
    uint32 gre_key;
    uint32 bfd_my_discriminator;
    uint32 radio_mac_31_0;
    uint32 udp_ptp_correction_field_31_0;
};
typedef union gre_bfd_ptp_u gre_bfd_ptp_t;

union ptp_oam_ach_u
{
    uint32 udp_ptp_correction_field_63_32      :32;

    struct
    {
        uint32 radio_mac_47_32                 :16;
        uint32 capwap_flags                    :8;
        uint32 capwap_header_length            :5;
        uint32 capwap_dtls                     :1;
        uint32 res                             :2;
    }wtp2ac_radio_mac;

    struct
    {
        uint32 y1731_oam_op_code               :8;
        uint32 y1731_oam_version               :5;
        uint32 y1731_oam_level                 :3;
        uint32 res                             :16;
    }y1731_oam;

    struct
    {
        uint32 ach_lm_flag                     :8;
        uint32 ach_lm_version                  :4;
        uint32 ach_lm_dscp                     :6;
        uint32 res                             :14;
    }ach_lm;
};
typedef union ptp_oam_ach_u ptp_oam_ach_t;

union rid_ptp_bfd_u
{
    struct
    {
        uint32 rid                    :5;
    }rid_t;

    struct
    {
        uint32 udp_ptp_message_type   :4;
        uint32 udp_ptp_version0       :1;
    }ptp_msg_type;

    struct
    {
        uint32 ntp_version            :3;
        uint32 res                    :2;
    }ntp_version;

    struct
    {
        uint32 tcp_ecn                :3;
        uint32 res                    :2;
    }tcp_ecn;
};
typedef union rid_ptp_bfd_u rid_ptp_bfd_t;

/* Define parser result */
struct parsing_result_s
{
    /* Layer2 parsing structure */
    struct
    {
        /* MAC */
        uint32  mac_da5                 :8; /* MacDA */
        uint32  mac_da4                 :8;
        uint32  mac_da3                 :8;
        uint32  mac_da2                 :8;
        uint32  mac_da1                 :8;
        uint32  mac_da0                 :8;

        uint32  mac_sa5                 :8; /* MacSA */
        uint32  mac_sa4                 :8;
        uint32  mac_sa3                 :8;
        uint32  mac_sa2                 :8;
        uint32  mac_sa1                 :8;
        uint32  mac_sa0                 :8;

        /* VLAN */
        uint32  svlan_id_valid          :1; /* S-VLAN info */
        uint32  svlan_id                :12;
        uint32  stag_cos                :3;
        uint32  stag_cfi                :1;

        uint32  cvlan_id_valid          :1; /* C-VLAN info */
        uint32  cvlan_id                :12;
        uint32  ctag_cos                :3;
        uint32  ctag_cfi                :1;

        /* MISC */
        uint32  layer2_header_protocol  :16;
        uint32  mac_ecmp_hash           :8;
        uint32  layer3_offset           :8;
        uint32  cn_tag_valid            :1;
        uint32  cn_flow_id              :16;
    }l2_s;

    /* Layer3 parsing structure */
    struct
    {
        ip_da_t ip_da;
        ip_sa_t ip_sa;
        tos_t   tos;

        uint32  ttl                     :8;
        uint32  ipv6_flow_label         :20;

        /* Fragment info */
        uint32  dont_frag               :1;
        uint32  more_frag               :1;
        uint32  frag_info               :2;
        uint32  frag_offset             :13;

        uint32  ip_header_error         :1;
        uint32  ip_options              :1;
        uint32  ip_identification       :16;
        uint32  ip_length               :14;

        uint32  layer3_header_protocol  :8;
        uint32  ip_ecmp_hash            :8;
        uint32  layer4_offset           :8;
    }l3_s;

    /* Layer4 parsing structure */
    struct
    {
        l4_src_port_t l4_src_port;
        l4_dst_port_t l4_dst_port;
        gre_bfd_ptp_t  gre_bfd_ptp;
        ptp_oam_ach_t  ptp_oam_ach;
        rid_ptp_bfd_t  rid_ptp_bfd;
        isatap_ptp_ver_t  isatap_ptp_ver;

        uint32  is_tcp                       :1;
        uint32  is_udp                       :1;

        uint32  layer4_info_mapped           :12;
        uint32  layer4_user_type             :4;
        uint32  layer4_check_sum             :16;

        uint32  app_data_valid0              :1;
        uint32  app_data_valid1              :1;
        uint32  app_data                     :32;
        uint32  udp_ptp_timestamp_31_to_0    :32;
        uint32  udp_ptp_timestamp_63_to_32   :32;
    }l4_s;

    uint32  layer2_type             :4;
    uint32  layer3_type             :4;
    uint32  layer4_type             :4;
    uint32  layer2_offset           :8;
    uint32  header_hash             :8;
    uint32  parser_length_error     :1;
    uint32  udf_byte0               :8;
    uint32  udf_byte1               :8;
    uint32  udf_byte2               :8;
    uint32  udf_byte3               :8;
    uint32  l4_error_bits           :5;

};
typedef struct parsing_result_s parsing_result_t;

/* Define pbb_port_type */
enum pbb_port_type_e
{
    PBB_PORT_TYPE_PBB_NONE,
    PBB_PORT_TYPE_PIP,
    PBB_PORT_TYPE_CBP,
    PBB_PORT_TYPE_PNP,
    PBB_PORT_TYPE_CNP
};
typedef enum pbb_port_type_e  pbb_port_type_t;

struct parser_info_s
{
    parsing_result_t *parser_result;
    uint8 *pkt;

    uint32 mux_length_type         :2;
    uint32 port_id                 :7;
    uint32 chip_id                 :5;
    uint32 outer_vlan_is_cvlan     :1;
    uint32 svlan_tpid_index        :2;
    uint32 parser_layer4_type      :4;
    uint32 packet_type             :3;
    uint32 parser_length           :9;

    uint32 rsv                     :16;
    uint32 mpls_hash_en            :8;
    uint32 payload_offset          :8;
    uint32 non_crc                 :1;
};
typedef struct parser_info_s parser_info_t;

/****************************************************************************
 *
* Global and Declarations
*
****************************************************************************/

/****************************************************************************
 *
* Functions
*
***************************************************************************/

extern int32 cm_com_parser_packet_parsing(parser_info_t *parser_info);

#endif
