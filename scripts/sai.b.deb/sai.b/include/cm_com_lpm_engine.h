/****************************************************************************
 * cm_com_hash.h  All error code Deinfines, include SDK error code.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     v1.0.
 * Author:       XuZx
 * Date:         2011-1-10.
 * Reason:       Create for GreatBelt.
 *
 * Revision:     v5.13.0.1
 * Author:       XuZx
 * Date:         2012-03-12.
 * Reason:       Sync for GreatBelt v5.13.0.1
 ****************************************************************************/


#define HASH1_PREFIX_LENGTH                   16
#define HASH2_PREFIX_LENGTH                    8

#define KEY_INDEX(index, is_right)            (((index) << 2) + (is_right))

enum lpm_hash_lookup_step_e
{
    LPM_HASH_LOOKUP_STEP1,
    LPM_HASH_LOOKUP_STEP2,
    LPM_HASH_LOOKUP_STEP_NUM
};
typedef enum lpm_hash_lookup_step_e lpm_hash_lookup_step_t;

enum lpm_80bit_bucket_num_e
{
    LPM_80BIT_BUCKET0,
    LPM_80BIT_BUCKET1,
    LPM_80BIT_BUCKET_NUM
};
typedef enum lpm_80bit_bucket_num_e lpm_80bit_bucket_num_t;

enum lpm_160bit_key_bucket_num_e
{
    LPM_160BIT_KEY_BUCKET,
    LPM_160BIT_KEY_BUCKET_NUM,
};
typedef enum lpm_160bit_key_bucket_num_e lpm_160bit_key_bucket_num_t;

struct ds_lpm_request_s
{
    uint16 old_pointer;
    uint16 new_pointer;
    uint16 nexthop;
    uint8  test_mask_start_index;
    uint16 old_entry_number;
    uint8  ip;
    uint8  mask;
    uint8  type;
    uint8  add;
};
typedef struct ds_lpm_request_s ds_lpm_request_t;

struct ds_lpm_result_s
{
    uint8  new_test_mask;
    uint8  new_test_mask_valid;
};
typedef struct ds_lpm_result_s ds_lpm_result_t;

struct lpm_extra_info_s
{
    uint32 aging_en     :1;
    uint32 ipv6_mid     :31;
};
typedef struct lpm_extra_info_s lpm_extra_info_t;

extern int32
cm_com_lpm_engine_perform_lpm_lookup(uint8, fib_key_t*, fib_key_type_t, lookup_result_t*);

