/****************************************************************************
 * sim_epe_interface.h
 *
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V4.29.3.
 * Author:       ZhouW
 * Date:         2011-11-12
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#ifndef _SIM_COMMON_H_
#define _SIM_COMMON_H_

#include "sal.h"
//#include "ctckal.h"
#include "ctcutil_lib.h"
#include "drv_lib.h"
#include "sim_bus.h"

#define TEMP_NOTE_ZHOUW 0

#define SIM_MAX_CHANN_NUM 256
#define COSIM_PRINT_BUF_MAX_SIZE 128
#define ASIC_DEBUG_BUS_CMP(string, fmt, args...)     \
do{                                     \
    if (1)            \
    {                                   \
        sal_snprintf(string, 128, fmt, ##args);  \
        cio_printf(string);              \
    }                                   \
}while(0)

enum sim_module_s
{
   SIM_MODULE_IPE = 0,
   SIM_MODULE_EPE = 1,
   SIM_MODULE_OAM = 2,
   SIM_MODULE_FWD = 3,
   SIM_MODULE_NUM,
};
typedef enum sim_module_s sim_module_t;
enum sim_ipe_bus_s
{
   SIM_IPE_HA2PR = 0,
   SIM_IPE_HA2IM = 1,
   SIM_IPE_IM2PP = 2,
   SIM_IPE_ILREQ = 3,
   SIM_IPE_OLREQ = 4,
   SIM_IPE_IMPI2LM = 5,
   SIM_IPE_IMPR2LM = 6,
   SIM_IPE_LR2FW = 7,
   SIM_IPE_LM2PP = 8,
   SIM_IPE_OM2FW = 9,
   SIM_IPE_PR2IM = 10,
   SIM_IPE_PR2LM = 11,
   SIM_IPE_RT2FW = 12,
   SIM_IPE_UI2PP = 13,
   SIM_IPE_EXCP = 14,
   SIM_IPE_SHA_FLD_OM2FW_LM_BUS = 15,
   SIM_IPE_SHA_FLD_OM2FW_NAT_BUS = 16,
   SIM_IPE_SHA_FLD_OM2FW_OAM_BUS = 17,
   SIM_IPE_SHA_FLD_OM2FW_PTP_BUS = 18,
   SIM_IPE_SHA_FLD_OM2FW_DMTX_BUS = 19,

   SIM_IPE_NUM,
};
typedef enum sim_ipe_bus_s sim_ipe_bus_t;

enum sim_bsr_bus_s
{
   SIM_FWD_MS_MET_FIFO = 0,
   SIM_FWD_MS_ENQUEUE = 1,
   SIM_FWD_MS_DEQUEUE = 2,
   SIM_BSR_NUM,
};
typedef enum sim_bsr_bus_s sim_bsr_bus_t;

enum sim_epe_bus_s
{
   SIM_EPE_AQ2CS = 0,
   SIM_EPE_CS2OM = 1,
   SIM_EPE_HA2HP = 2,
   SIM_EPE_HA2NH = 3,
   SIM_EPE_HA2PR = 4,
   SIM_EPE_HP2AQ = 5,
   SIM_EPE_HP2HE = 6,
   SIM_EPE_HP2OM = 7,
   SIM_EPE_NH2HP = 8,
   SIM_EPE_OM2HE = 9,
   SIM_EPE_PR2HP = 10,
   SIM_EPE_NETTX = 11,
   SIM_EPE_EXCP = 12,
   SIM_EPE_SHA_FLD_HA2NH_LM_BUS = 13,
   SIM_EPE_SHA_FLD_HA2NH_NAT_BUS = 14,
   SIM_EPE_SHA_FLD_HA2NH_OAM_BUS = 15,
   SIM_EPE_SHA_FLD_HA2NH_PTP_BUS = 16,
   SIM_EPE_SHA_FLD_HA2NH_DMTX_BUS = 17,
   SIM_EPE_SHA_FLD_HP2OM_LM_BUS = 18,
   SIM_EPE_SHA_FLD_HP2OM_NAT_BUS = 19,
   SIM_EPE_SHA_FLD_HP2OM_OAM_BUS = 20,
   SIM_EPE_SHA_FLD_HP2OM_PTP_BUS = 21,
   SIM_EPE_SHA_FLD_HP2OM_DMTX_BUS = 22,
   SIM_EPE_SHA_FLD_NH2HP_LM_BUS = 23,
   SIM_EPE_SHA_FLD_NH2HP_NAT_BUS = 24,
   SIM_EPE_SHA_FLD_NH2HP_OAM_BUS = 25,
   SIM_EPE_SHA_FLD_NH2HP_PTP_BUS = 26,
   SIM_EPE_SHA_FLD_NH2HP_DMTX_BUS = 27,
   SIM_EPE_SHA_FLD_OM2HE_LM_BUS = 28,
   SIM_EPE_SHA_FLD_OM2HE_NAT_BUS = 29,
   SIM_EPE_SHA_FLD_OM2HE_OAM_BUS = 30,
   SIM_EPE_SHA_FLD_OM2HE_PTP_BUS = 31,
   SIM_EPE_SHA_FLD_OM2HE_DMTX_BUS = 32,

   SIM_EPE_NUM,
};
typedef enum sim_epe_bus_s sim_epe_bus_t;

enum sim_oam_bus_s
{
   SIM_OAM_HA2PP = 0,
   SIM_OAM_PP2FW,
   SIM_OAM_PR2PP,
   SIM_OAM_NUM,
};
typedef enum sim_oam_bus_s sim_oam_bus_t;

enum cosim_oam_update_type_s
{
    COSIM_OAM_UPDATE,
    COSIM_OAM_DEFECT_SCAN,
    COSIM_OAM_GEN_PKT,
    COSIM_OAM_MAX,
};
typedef enum cosim_oam_update_type_s cosim_oam_update_type_t;

enum sim_key_type_e
{
    SIM_KEY_TYPE_HASH,
    SIM_KEY_TYPE_TCAM,
    SIM_KEY_TYPE_NUM
};
typedef enum sim_key_type_e sim_key_type_t;

enum sim_oam_write_ds_e
{
    SIM_DSOAM_DsEthMep,
    SIM_DSOAM_DsEthRmep,
    SIM_DSOAM_DsBfdMep,
    SIM_DSOAM_DsBfdRmep,
    SIM_DSOAM_AutoGenPktRxPktStats,
    SIM_DSOAM_AutoGenPktPktCfg,
    SIM_DSOAM_OamDefectCache,
    SIM_DSOAM_OamErrorDefectCtl,
    SIM_DSOAM_DsOamDefectStatus,
    SIM_DSOAM_MAX
};
typedef enum sim_oam_write_ds_e sim_oam_write_ds_t;

enum sim_all_linklist_opcode_s
{
   SIM_LINKLIST_OP_CREAT = 0,
   SIM_LINKLIST_OP_DELETE = 1,
};
typedef enum sim_all_linklist_opcode_s sim_all_linklist_opcode_t;

struct rtl_tbl_info_s
{
    uint32 table_id;
    uint32 index;
    uint32 word_num_entry;
    uint32 *data;
    bool is_cmp_oam_wr_table; /* for compare Oam DS write table (DsEthMep_t/DsEthRmep_t/DsBfdMep_t/DsBfdRmep_t)*/
};
typedef struct rtl_tbl_info_s rtl_tbl_info_t;

struct cosim_db_s
{
    bool sim_dump_flag;            /* control whether dump each cmodel all linklist remained content to a file or not */

    bool sim_read_tbl_cosim_flag;  /* control whether do read table's cosim compare or not */
    bool sim_write_tbl_cosim_flag; /* control whether do write table's cosim compare or not (now only OAM table) */
    bool sim_chk_read_tbl_flag;    /* control whether check read tables linklist remained content */
    bool sim_chk_write_tbl_flag;   /* control whether check write tables linklist remained content (now only OAM table) */
    list_head_t sim_table_info_list[MaxTblId_t];
    list_head_t sim_oam_wt_table_info_list[SIM_DSOAM_MAX];
    int32(*store_table)(uint8, uint32, uint32, uint32*, bool);

    /* per-module per-bus control cosim switch */
    uint32 sim_cosim_bus_flag[SIM_MODULE_NUM]; /* control whether do each module each bus cosim compare or not (bitmap flag) */

    uint8 sim_key_cosim_flag[SIM_KEY_TYPE_NUM];/* control whether do Hash or Tcam key's cosim compare or not */
    list_head_t sim_key_list[SIM_KEY_TYPE_NUM];

    int32(*store_key)(void*, tbls_id_t);

    list_head_t sim_ipe_list[SIM_IPE_NUM];
    int32(*store_ipe_bus[SIM_IPE_NUM])(void*);

    list_head_t sim_epe_list[SIM_EPE_NUM];
    int32(*store_epe_bus[SIM_EPE_NUM])(void*);

    list_head_t sim_oam_list[SIM_OAM_NUM];
    int32(*store_oam_bus[SIM_OAM_NUM])(void*);

    list_head_t sim_fwd_list[SIM_BSR_NUM];
    int32(*store_bsr_bus[SIM_BSR_NUM])(void*);

    int32(*store_bheader)(void*, uint8);
    list_head_t sim_bheader_list[SIM_MODULE_NUM];

    /* store simlar node information in MsEnqueue and MsDequeue */
    list_head_t enq_simular_list;
    list_head_t deq_simular_list;
    list_head_t hdr_simular_list;

    list_head_t sim_outpkt_list[SIM_MODULE_NUM][SIM_MAX_CHANN_NUM];
    list_head_t pkt_simular_list[SIM_MODULE_NUM];
    int32 (*store_outpkt)(uint32, uint32, uint32, uint8*, uint8, uint8, uint32);

    void (*store_discard_type)(uint8, uint32);
};
typedef struct cosim_db_s cosim_cm_db_t;

struct cosim_brg_header_s
{
    list_head_t head;

    uint8 discard;
    uint32 discard_type;

    ms_pkt_hdr_t *pkt_header;
};
typedef struct cosim_brg_header_s cosim_brg_header_t;

struct cosim_discard_info_s
{
    uint8 discard;
    uint32 discard_type;
};
typedef struct cosim_discard_info_s cosim_discard_info_t;

extern void cio_printf(char *str);

extern bool sim_interface_initialize;
extern cosim_cm_db_t cosim_db;
extern cosim_discard_info_t cosim_discard_info;

#endif

