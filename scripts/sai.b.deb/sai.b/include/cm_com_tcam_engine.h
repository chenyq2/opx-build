/****************************************************************************
 * cm_com_tcam_engine.h  All TCAM Engine code Deinfines.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Vision:       V1.0.
 * Author:       Mengzhw
 * Date:         2010-12-02.
 * Reason:       Create for GreatBelt.
 *
 * Modify History:
 ****************************************************************************/
#ifndef _CM_COM_TCAM_ENGINE_H
#define _CM_COM_TCAM_ENGINE_H

#include "sal.h"
#include "drv_tbl_reg.h"

/**********************************************************************************
              Define Typedef, define and Data Structure
***********************************************************************************/
enum tcam_moduel_type_e
{
    TCAM_MODUEL_TYPE_NORMAL,
    TCAM_MODUEL_TYPE_LPM,
};
typedef enum tcam_moduel_type_e tcam_moduel_type_t;

enum tcam_key_type_e
{
    /* for ACL/Qos */
    TCAM_TYPE_IPV6_ACL_QOS     = 0x0,
    TCAM_TYPE_IPV4_ACL_QOS     = 0x1,
    TCAM_TYPE_MAC_ACL_QOS      = 0x2,

    /* IPE Forwarding */
    TCAM_TYPE_IPV4_UCAST       = 0x10,
    TCAM_TYPE_IPV4_MCAST       = 0x11,
    TCAM_TYPE_IPV6_UCAST       = 0x12,
    TCAM_TYPE_IPV6_MCAST       = 0x13,
    TCAM_TYPE_IPV4_RPF         = 0x14,
    TCAM_TYPE_IPV6_RPF         = 0x15,
    TCAM_TYPE_IPV4_NAT         = 0x16,
    TCAM_TYPE_IPV6_NAT         = 0x17,
    TCAM_TYPE_IPV4_PBR         = 0x18,
    TCAM_TYPE_IPV6_PBR         = 0x19,
    TCAM_TYPE_MAC_DA           = 0x1A,
    TCAM_TYPE_MAC_SA           = 0X1B,
    TCAM_TYPE_FCOE_DA          = 0x1C,
    TCAM_TYPE_FCOE_SA          = 0x1D,
    TCAM_TYPE_TRILl_UCAST_DA   = 0x1E,
    TCAM_TYPE_TRILl_MCAST_DA   = 0x1F,

    /* UserID, 160 bits AD */
    TCAM_TYPE_MAC_USERID       = 0x20,
    TCAM_TYPE_IPV6_USERID      = 0x21,
    TCAM_TYPE_IPV4_USERID      = 0x22,
    TCAM_TYPE_VLAN_USERID      = 0x23,
    TCAM_TYPE_IPV6_TUNNELID    = 0x24,
    TCAM_TYPE_IPV4_TUNNELID    = 0x25,
    TCAM_TYPE_PBB_TUNNELID     = 0x26,
    TCAM_TYPE_CAPWAP_TUNNELID  = 0x27,
    TCAM_TYPE_TRILL_TUNNELID   = 0x28,

    TCAM_TYPE_MAC_IPV6_MCAST   = 0x30,
    TCAM_TYPE_MAC_IPV4_MCAST   = 0x31,
    TCAM_TYPE_NUM
};
typedef enum tcam_key_type_e tcam_key_type_t;

enum userid_port_tcam_type_e
{
    USERID_PORT_TCAM_TYPE_MAC_SA = 0x0,
    USERID_PORT_TCAM_TYPE_IP = 0x1,
    USERID_PORT_TCAM_TYPE_VLAN = 0x2,
    USERID_PORT_TCAM_TYPE_IP_TUNNEL = 0x3,
    USERID_PORT_TCAM_TYPE_PBB = 0x4,
    USERID_PORT_TCAM_TYPE_CAPWAP = 0x5,
    USERID_PORT_TCAM_TYPE_TRILL = 0x6
};
typedef enum userid_port_tcam_type_e userid_port_tcam_type_t;

enum tcam_key_direction_e
{
    TCAM_KEY_DIR_IPE,
    TCAM_KEY_DIR_EPE,
    TCAM_KEY_DIR_NUM
};
typedef enum tcam_key_direction_e tcam_key_direction_t;

/* Tcam lookup input information */
struct tcam_lkp_inputs_s
{
    uint32 chip_id;
    void *tcam_key;
    tcam_key_type_t tcam_key_type   :7;
    uint8 tcam_key_size             :2;
};
typedef struct tcam_lkp_inputs_s tcam_lkp_inputs_t;

struct tcam_lkp_sub_output_s
{
    void *ds_ad;
    oam_info_t *oam_info;
    uint8 tcam_lkp_result_valid  :1;
};
typedef struct tcam_lkp_sub_output_s tcam_lkp_sub_output_t;

/* Tcam lookup output result */
struct tcam_lkp_outputs_s
{
    tcam_lkp_sub_output_t tcam_lkp_output[DRV_TCAM_LOOKUP_NUM];
    void *ds_ipmc_sa;
};
typedef struct tcam_lkp_outputs_s tcam_lkp_outputs_t;

struct tcam_lookup_info_s
{
    uint32  chip_id;
    void*   tcam_key;
    uint8   tcam_key_type;
};
typedef struct tcam_lookup_info_s tcam_lookup_info_t;

struct tcam_lookup_result_s
{
    uint8 valid;
    uint32 key_index;
};
typedef struct tcam_lookup_result_s tcam_lookup_result_t;

/**********************************************************************************
                      Define API function interfaces
***********************************************************************************/
extern int32
cm_com_tcam_engine_handle(tcam_lkp_inputs_t*, tcam_lkp_outputs_t*);

extern int32
cm_com_tcam_conflict_resolve(tcam_lookup_info_t*, tcam_lookup_result_t*);

#endif

