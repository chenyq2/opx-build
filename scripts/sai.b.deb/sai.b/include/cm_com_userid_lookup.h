/****************************************************************************
 * cm_com_userid_lookup.h  Define for userid hash.
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V2.0.
 * Author:       XuZx
 * Date:         2011-4-12.
 * Reason:       Create for GreatBelt.
 *
 * Revision:     V4.5.1
 * Revisor:      XuZx
 * Date:         2011-07-22
 * Reason:       Revise for GreatBelt v4.5.1
 *
 * Revision:     V5.6.0
 * Revisor:      XuZx
 * Date:         2012-01-07
 * Reason:       Revise for GreatBelt v5.6.0
 ****************************************************************************/

enum userid_stag_action_e
{
    USERID_STAG_ACTION_NONE,                  /* 0 */
    USERID_STAG_ACTION_MODIFY,                /* 1 */
    USERID_STAG_ACTION_ADD,                   /* 2 */
    USERID_STAG_ACTION_DELETE,                /* 3 */
};
typedef enum userid_stag_action_e userid_stag_action_t;

enum userid_ctag_action_e
{
    USERID_CTAG_ACTION_NONE,                  /* 0 */
    USERID_CTAG_ACTION_MODIFY,                /* 1 */
    USERID_CTAG_ACTION_ADD,                   /* 2 */
    USERID_CTAG_ACTION_DELETE,                /* 3 */
};
typedef enum userid_ctag_action_e userid_ctag_action_t;

enum userid_svlan_id_action_e
{
    USERID_SVLAN_ID_ACTION_NONE,              /* 0 */
    USERID_SVLAN_ID_ACTION_SWAP,              /* 1 */
    USERID_SVLAN_ID_ACTION_USER,              /* 2 */
    USERID_SVLAN_ID_ACTION_RESV,              /* 3 */
};
typedef enum userid_svlan_id_action_e userid_svlan_id_action_t;

enum userid_cvlan_id_action_e
{
    USERID_CVLAN_ID_ACTION_NONE,              /* 0 */
    USERID_CVLAN_ID_ACTION_SWAP,              /* 1 */
    USERID_CVLAN_ID_ACTION_USER,              /* 2 */
    USERID_CVLAN_ID_ACTION_RESV,              /* 3 */
};
typedef enum userid_cvlan_id_action_e userid_cvlan_id_action_t;

enum userid_s_cos_action_e
{
    USERID_SCOS_ACTION_NONE,                 /* 0 */
    USERID_SCOS_ACTION_SWAP,                 /* 1 */
    USERID_SCOS_ACTION_USER,                 /* 2 */
    USERID_SCOS_ACTION_RESV,                 /* 3 */
};
typedef enum userid_s_cos_action_e userid_s_cos_action_t;

enum userid_c_cos_action_e
{
    USERID_CCOS_ACTION_NONE,                 /* 0 */
    USERID_CCOS_ACTION_SWAP,                 /* 1 */
    USERID_CCOS_ACTION_USER,                 /* 2 */
    USERID_CCOS_ACTION_RESV,                 /* 3 */
};
typedef enum userid_c_cos_action_e userid_c_cos_action_t;

enum userid_s_cfi_action_e
{
    USERID_SCFI_ACTION_NONE,                 /* 0 */
    USERID_SCFI_ACTION_SWAP,                 /* 1 */
    USERID_SCFI_ACTION_USER,                 /* 2 */
    USERID_SCFI_ACTION_RESV,                 /* 3 */
};
typedef enum userid_s_cfi_action_e userid_s_cfi_action_t;

enum userid_c_cfi_action_e
{
    USERID_CCFI_ACTION_NONE,                 /* 0 */
    USERID_CCFI_ACTION_SWAP,                 /* 1 */
    USERID_CCFI_ACTION_USER,                 /* 2 */
    USERID_CCFI_ACTION_RESV,                 /* 3 */
};
typedef enum userid_c_cfi_action_e userid_c_cfi_action_t;

struct oam_extra_result_s
{
    void *chan;
    void *info;
};
typedef struct oam_extra_result_s  oam_extra_result_t;

struct userid_key_type_two_vlan_s
{
    uint32 svlan_id             :12;
    uint32 cvlan_id             :12;
    uint32 is_label             :1;
    uint32 rsv                  :7;
};
typedef struct userid_key_type_two_vlan_s userid_key_type_two_vlan_t;

struct userid_key_type_svlan_s
{
    uint32 svlan_id             :12;
    uint32 is_label             :1;
    uint32 rsv                  :19;
};
typedef struct userid_key_type_svlan_s userid_key_type_svlan_t;

struct userid_key_type_cvlan_s
{
    uint32 cvlan_id             :12;
    uint32 is_label             :1;
    uint32 rsv                  :19;
};
typedef struct userid_key_type_cvlan_s userid_key_type_cvlan_t;

struct userid_key_type_svlan_cos_s
{
    uint32 svlan_id             :12;
    uint32 is_label             :1;
    uint32 stag_cos             :3;
    uint32 rsv                  :16;
};
typedef struct userid_key_type_svlan_cos_s userid_key_type_svlan_cos_t;

struct userid_key_type_cvlan_cos_s
{
    uint32 cvlan_id             :12;
    uint32 is_label             :1;
    uint32 ctag_cos             :3;
    uint32 rsv                  :16;
};
typedef struct userid_key_type_cvlan_cos_s userid_key_type_cvlan_cos_t;

struct userid_key_type_mac_sa_s
{
    uint32 is_mac_da             :1;
    uint32 rsv                   :15;
    uint32 mac_sa_47_32          :16;
    uint32 mac_sa_31_0           :32;
};
typedef struct userid_key_type_mac_sa_s userid_key_type_mac_sa_t;

struct userid_key_type_port_mac_sa_s
{
    uint32 is_label               :1;
    uint32 is_mac_da              :1;
    uint32 rsv                   :14;
    uint32 mac_sa_47_32          :16;
    uint32 mac_sa_31_0           :32;
};
typedef struct userid_key_type_port_mac_sa_s userid_key_type_port_mac_sa_t;

struct userid_key_type_ipv4_sa_s
{
    uint32 ip_sa                 :32;
    uint32 is_label              :1;
    uint32 vlan_id               :12;
    uint32 rsv                   :19;
};
typedef struct userid_key_type_ipv4_sa_s userid_key_type_ipv4_sa_t;

struct userid_key_type_port_ipv4_sa_s
{
    uint32 ip_sa                 :32;
    uint32 is_label              :1;
    uint32 rsv                   :31;
};
typedef struct userid_key_type_port_ipv4_sa_s userid_key_type_port_ipv4_sa_t;

struct userid_key_type_port_s
{
    uint32 is_label              :1;
    uint32 rsv                   :31;
};
typedef struct userid_key_type_port_s userid_key_type_port_t;

struct userid_key_type_L2_s
{
    uint32 cos              :3;
    uint32 ether_type       :16;
    uint32 vlan_id          :12;
    uint32 is_ipv4_key      :1;

    uint32 mac_da_47_32     :16;
    uint32 mac_sa_47_32     :16;

    uint32 mac_da_31_0      :32;
    uint32 mac_sa_31_0      :32;
};
typedef struct userid_key_type_L2_s userid_key_type_L2_t;

struct userid_key_type_ipv6_sa_s
{
    uint32 ip_sa_127_96;
    uint32 ip_sa_95_64;
    uint32 ip_sa_63_32;
    uint32 ip_sa_31_0;
};
typedef struct userid_key_type_ipv6_sa_s userid_key_type_ipv6_sa_t;

struct userid_key_type_pbb_s
{
    uint32 is_label              :1;
    uint32 is_id                 :24;
    uint32 rsv                   :7;
};
typedef struct userid_key_type_pbb_s userid_key_type_pbb_t;

struct userid_key_type_ipv4_tunnel_s
{
    uint32 ip_sa                 :32;
    uint32 ip_da                 :32;

    uint32 layer4_type           :4;
    uint32 rsv                   :28;
};
typedef struct userid_key_type_ipv4_tunnel_s userid_key_type_ipv4_tunnel_t;

struct userid_key_type_capwap_s
{
    uint32 rid                   :5;
    uint32 rsv                   :11;
    uint32 radio_mac_47_32       :16;
    uint32 radio_mac_31_0        :32;
};
typedef struct userid_key_type_capwap_s userid_key_type_capwap_t;

struct userid_key_type_trill_uc_rpf_s
{
    uint32 ingress_nick_name     :16;
    uint32 rsv                   :16;
};
typedef struct userid_key_type_trill_uc_rpf_s userid_key_type_trill_uc_rpf_t;

struct userid_key_type_trill_mc_rpf_s
{
    uint32 ingress_nick_name     :16;
    uint32 egress_nick_name      :16;
};
typedef struct userid_key_type_trill_mc_rpf_s userid_key_type_trill_mc_rpf_t;

struct userid_key_type_trill_mc_adj_s
{
    uint32 egress_nick_name     :16;
    uint32 is_label             :1;
    uint32 rsv                  :15;
};
typedef struct userid_key_type_trill_mc_adj_s userid_key_type_trill_mc_adj_t;

struct userid_key_type_trill_uc_s
{
    uint32 ingress_nick_name     :16;
    uint32 egress_nick_name      :16;
};
typedef struct userid_key_type_trill_uc_s userid_key_type_trill_uc_t;

struct userid_key_type_trill_mc_s
{
    uint32 ingress_nick_name     :16;
    uint32 egress_nick_name      :16;
};
typedef struct userid_key_type_trill_mc_s userid_key_type_trill_mc_t;

struct userid_key_type_ipv4_rpf_s
{
    uint32 ip_sa                 :32;
};
typedef struct userid_key_type_ipv4_rpf_s userid_key_type_ipv4_rpf_t;

struct userid_key_type_mpls_section_oam_s
{
    uint32 interface_id          :10;
    uint32 rsv                   :22;
};
typedef struct userid_key_type_mpls_section_oam_s userid_key_type_mpls_section_oam_t;

struct userid_key_type_pbt_oam_s
{
    uint32 vrf_id                :14;
    uint32 rsv                   :2;
    uint32 mac_sa_47_32          :16;
    uint32 mac_sa_31_0           :32;
};
typedef struct userid_key_type_pbt_oam_s userid_key_type_pbt_oam_t;

struct userid_key_type_mpls_label_oam_s
{
    uint32 mpls_label_space      :8;
    uint32 mpls_label            :20;
    uint32 rsv                   :4;
};
typedef struct userid_key_type_mpls_label_oam_s userid_key_type_mpls_label_oam_t;

struct userid_key_type_bfd_oam_s
{
    uint32 my_discriminator      :32;
};
typedef struct userid_key_type_bfd_oam_s userid_key_type_bfd_oam_t;

struct userid_key_type_ether_fid_oam_s
{
    uint32 vlan_id              :14;
    uint32 is_fid               :1;
    uint32 rsv                  :17;
};
typedef struct userid_key_type_ether_fid_oam_s userid_key_type_ether_fid_oam_t;

struct userid_key_type_ether_vlan_oam_s
{
    uint32 vlan_id              :12;
    uint32 is_fid               :1;
    uint32 rsv                  :19;
};
typedef struct userid_key_type_ether_vlan_oam_s userid_key_type_ether_vlan_oam_t;

struct userid_key_type_ether_rmep_s
{
    uint32 rmep_id               :13;
    uint32 mep_index            :13;
    uint32 rsv                  :6;
};
typedef struct userid_key_type_ether_rmep_s userid_key_type_ether_rmep_t;

struct userid_key_s
{
    union
    {
        /* UserId, VLAN related */
        userid_key_type_two_vlan_t          two_vlan;
        userid_key_type_svlan_t             svlan;
        userid_key_type_cvlan_t             cvlan;
        userid_key_type_svlan_cos_t         svlan_cos;
        userid_key_type_cvlan_cos_t         cvlan_cos;

        /* UserId, MAC related */
        userid_key_type_mac_sa_t            mac_sa;
        userid_key_type_port_mac_sa_t       port_mac_sa;

        /* UserId, IP related */
        userid_key_type_ipv4_sa_t           ipv4_sa;
        userid_key_type_port_ipv4_sa_t      port_ipv4_sa;

        /* UserId, port based */
        userid_key_type_port_t              port;
        userid_key_type_L2_t                L2;
        userid_key_type_ipv6_sa_t           ipv6_sa;

        /* TunnelId */
        userid_key_type_pbb_t               pbb;
        userid_key_type_ipv4_tunnel_t       ipv4_tunnel;
        userid_key_type_ipv4_tunnel_t       ipv4_gre;
        userid_key_type_ipv4_tunnel_t       ipv4_udp;
        userid_key_type_capwap_t            capwap;
        userid_key_type_trill_uc_rpf_t      trill_uc_rpf;
        userid_key_type_trill_mc_rpf_t      trill_mc_rpf;
        userid_key_type_trill_mc_adj_t      trill_mc_adj;
        userid_key_type_trill_uc_t          trill_uc;
        userid_key_type_trill_mc_t          trill_mc;
        userid_key_type_ipv4_rpf_t          ipv4_rpf;

        /* OAM */
        userid_key_type_mpls_section_oam_t  mpls_section_oam;
        userid_key_type_pbt_oam_t           pbt_oam;
        userid_key_type_mpls_label_oam_t    mpls_label_oam;
        userid_key_type_bfd_oam_t           bfd_oam;
        userid_key_type_ether_fid_oam_t     ether_fid_oam;
        userid_key_type_ether_vlan_oam_t    ether_vlan_oam;
        userid_key_type_ether_rmep_t        ether_rmep_oam;
    }key;

    union
    {
        struct
        {
            uint32 src    :14;
            uint32 dest   :14;
            uint32 rsv     :4;
        }global;

        struct
        {
            uint32 src    :16;
            uint32 dest   :16;
        }udp;
    }xport;
};
typedef struct userid_key_s userid_key_t;

#if (HOST_IS_LE == 0)
union fib_userid_ip_sa_u
{
    uint32 ip_sa                 :32;
    struct
    {
        uint32 rsv               :7;
        uint32 is_label          :1;
        uint32 isid              :24;
    }u1;
    uint32 radio_mac_31_0        :32;

    struct
    {
        uint32 egress_nick_name  :16;
        uint32 ingress_nick_name :16;
    }u2;

    struct
    {
        uint32 rsv               :22;
        uint32 interface_id      :10;
    }u3;

    struct
    {
        uint32 rsv               :18;
        uint32 esp_id            :14;
    }u4;

    struct
    {
        uint32 rsv               :4;
        uint32 mpls_label_space  :8;
        uint32 mpls_label        :20;
    }u5;

    uint32 my_discriminator      :32;

    struct
    {
        uint32 rsv               :17;
        uint32 is_fid            :1;
        uint32 vlan_id           :14;
    }u6;

    struct
    {
        uint32 rsv               :5;
        uint32 rmep_id           :13;
        uint32 mep_index         :14;
    }u7;

    uint32 mac_sa                :32;

    struct
    {
        uint32 stag_cfi          :1;
        uint32 stag_cos          :3;
        uint32 svlan_id          :12;
        uint32 ctag_cfi          :1;
        uint32 ctag_cos          :3;
        uint32 cvlan_id          :12;
    }u8;

    struct
    {
        uint32 rsv               :20;
        uint32 vlan_id           :12;
    }u9;
};
typedef union fib_userid_ip_sa_u fib_userid_ip_sa_t;

union fib_userid_rid_u
{
    struct
    {
        uint32 rsv                  :27;
        uint32 rid                   :5;
    }u1;

    struct
    {
        uint32 rsv                  :31;
        uint32 is_mac_da             :1;
    }u2;

    uint32 rid                      :32;
};
typedef union fib_userid_rid_u fib_userid_rid_t;

union fib_userid_radio_mac_47_32_u
{
    uint16 radio_mac47_32;
    uint16 mac_sa47_32;

    struct
    {
        uint16 rsv                   :2;
        uint16 global_src_port      :14;
    }__attribute__((packed))u1;
};
typedef union fib_userid_radio_mac_47_32_u fib_userid_radio_mac_47_32_t;

union fib_userid_udp_dest_port_u
{
    uint16 udp_dest_port;
    uint16 ip_sa_127_112;

    struct
    {
        uint16 is_ipv4_key   :1;
        uint16 cos           :3;
        uint16 vlan_id      :12;
    }__attribute__((packed))u1;
};
typedef union fib_userid_udp_dest_port_u fib_userid_udp_dest_port_t;

union fib_userid_global_src_port_u
{
    struct
    {
        uint16 rsv              :2;
        uint16 global_src_port :14;
    }__attribute__((packed))u1;

    struct
    {
        uint16 rsv             :5;
        uint16 ip_sa_63_53    :11;
    }__attribute__((packed))u2;
};
typedef union fib_userid_global_src_port_u fib_userid_global_src_port_t;

#else
union fib_userid_ip_sa_u
{
    uint32 ip_sa                 :32;
    struct
    {
        uint32 isid              :24;
        uint32 is_label          :1;
        uint32 rsv               :7;

    }u1;
    uint32 radio_mac_31_0        :32;

    struct
    {
        uint32 ingress_nick_name :16;
        uint32 egress_nick_name  :16;
    }u2;

    struct
    {
        uint32 interface_id      :10;
        uint32 rsv               :22;
    }u3;

    struct
    {
        uint32 esp_id            :14;
        uint32 rsv               :18;
    }u4;

    struct
    {
        uint32 mpls_label        :20;
        uint32 mpls_label_space  :8;
        uint32 rsv               :4;
    }u5;

    uint32 my_discriminator      :32;

    struct
    {
        uint32 vlan_id           :14;
        uint32 is_fid            :1;
        uint32 rsv               :17;
    }u6;

    struct
    {
        uint32 mep_index         :14;
        uint32 rmep_id           :13;
        uint32 rsv               :5;
    }u7;

    uint32 mac_sa                :32;

    struct
    {
        uint32 cvlan_id          :12;
        uint32 ctag_cos          :3;
        uint32 ctag_cfi          :1;
        uint32 svlan_id          :12;
        uint32 stag_cos          :3;
        uint32 stag_cfi          :1;
    }u8;

    struct
    {
        uint32 vlan_id           :12;
        uint32 rsv               :20;
    }u9;

};
typedef union fib_userid_ip_sa_u fib_userid_ip_sa_t;

union fib_userid_rid_u
{
    struct
    {
        uint32 rid                   :5;
        uint32 rsv                  :27;
    }u1;

    struct
    {
        uint32 is_mac_da             :1;
        uint32 rsv                  :31;
    }u2;

    uint32 rid                      :32;
};
typedef union fib_userid_rid_u fib_userid_rid_t;

union fib_userid_radio_mac_47_32_u
{
    uint16 radio_mac47_32;
    uint16 mac_sa47_32;

    struct
    {
        uint32 global_src_port      :14;
        uint32 rsv                   :2;
    }__attribute__((packed))u1;
};
typedef union fib_userid_radio_mac_47_32_u fib_userid_radio_mac_47_32_t;

union fib_userid_udp_dest_port_u
{
    uint16 udp_dest_port;
    uint16 ip_sa_127_112;

    struct
    {
        uint16 vlan_id       :12;
        uint16 cos           :3;
        uint16 is_ipv4_key   :1;
    }__attribute__((packed)) u1;
};
typedef union fib_userid_udp_dest_port_u fib_userid_udp_dest_port_t;

union fib_userid_global_src_port_u
{
    struct
    {
        uint16 rsv              :2;
        uint16 global_src_port :14;
    }__attribute__((packed)) u1;

    struct
    {
        uint16 rsv             :5;
        uint16 ip_sa_63_53    :11;
    }__attribute__((packed)) u2;
};
typedef union fib_userid_global_src_port_u fib_userid_global_src_port_t;

#endif

extern int32
cm_com_userid_hash_lookup_request(uint8, uint8, userid_key_t*, userid_key_type_t, userid_direction_t, lookup_result_t*);
