/****************************************************************************
 * sim_ipe_interface.h
 *
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V4.29.3.
 * Author:       ZhouW
 * Date:         2011-11-12
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#ifndef _SIM_IPE_INTERFACE_H_
#define _SIM_IPE_INTERFACE_H_

#include "sim_common.h"

extern int32 cosim_do_ipe(uint32 chipid, uint32 chanid, uint32 pkt_len, bool ptp_en, uint8 *pkt);

extern int32 sim_store_ipe_ha2pr_bus(void *in_pkt);
extern int32 sim_store_ipe_ha2im_bus(void *in_pkt);
extern int32 sim_store_ipe_im2pp_bus(void *in_pkt);
extern int32 sim_store_ipe_impi2lm_bus(void *in_pkt);
extern int32 sim_store_ipe_impr2lm_bus(void *in_pkt);
extern int32 sim_store_ipe_lr2fw_bus(void *in_pkt);
extern int32 sim_store_ipe_lm2pp_bus(void *in_pkt);
extern int32 sim_store_ipe_om2fw_bus(void *in_pkt);
extern int32 sim_store_ipe_pr2im_bus(void *in_pkt);
extern int32 sim_store_ipe_pr2lm_bus(void *in_pkt);
extern int32 sim_store_ipe_rt2fw_bus(void *in_pkt);
extern int32 sim_store_ipe_ui2pp_bus(void *in_pkt);
extern int32 sim_store_ipe_excp_bus(void *in_pkt);
extern int32 sim_store_ipe_ilreq_bus(void *learning_info);
extern int32 sim_store_ipe_olreq_bus(void *learning_info);
extern int32 sim_store_ipe_oam2fwd_sharelm_bus(void *in_pkt);
extern int32 sim_store_ipe_oam2fwd_sharenat_bus(void *in_pkt);
extern int32 sim_store_ipe_oam2fwd_shareoam_bus(void *in_pkt);
extern int32 sim_store_ipe_oam2fwd_shareptp_bus(void *in_pkt);
extern int32 sim_store_ipe_oam2fwd_sharedm_bus(void *in_pkt);

extern int32 cosim_ipe_ha2pr_verify(void *bus, bool *succ);
extern int32 cosim_ipe_ha2im_verify(void *bus, bool *succ);
extern int32 cosim_ipe_im2pp_verify(void *bus, bool *succ);
extern int32 cosim_ipe_impi2lm_verify(void *bus, bool *succ);
extern int32 cosim_ipe_impr2lm_verify(void *bus, bool *succ);
extern int32 cosim_ipe_lr2fw_verify(void *bus, bool *succ);
extern int32 cosim_ipe_lm2pp_verify(void *bus, bool *succ);
extern int32 cosim_ipe_om2fw_verify(void *bus, bool *succ);
extern int32 cosim_ipe_pr2im_verify(void *bus, bool *succ);
extern int32 cosim_ipe_pr2lm_verify(void *bus, bool *succ);
extern int32 cosim_ipe_rt2fw_verify(void *bus, bool *succ);
extern int32 cosim_ipe_ui2pp_verify(void *bus, bool *succ);
extern int32 cosim_ipe_excp_verify(void *bus, bool *succ);
extern int32 cosim_ipe_ilreq_verify(void *bus,bool *succ);
extern int32 cosim_ipe_olreq_verify(void *bus,bool *succ);
extern int32 cosim_ipe_oam2fwd_sharelm_verify(void *bus,bool *succ);
extern int32 cosim_ipe_oam2fwd_sharenat_verify(void *bus,bool *succ);
extern int32 cosim_ipe_oam2fwd_shareoam_verify(void *bus,bool *succ);
extern int32 cosim_ipe_oam2fwd_shareptp_verify(void *bus,bool *succ);
extern int32 cosim_ipe_oam2fwd_sharedm_verify(void *bus,bool *succ);

#endif

