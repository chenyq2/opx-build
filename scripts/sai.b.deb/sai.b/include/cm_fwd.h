/****************************************************************************
* cm_fwd.h  All packet type Deinfines.
*
* Copyright: (c)2011 Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision:     GB V2.0
* Author:       Zhouw.
* Date:         2011-05-04.
* Reason:       First Create.
****************************************************************************/
#ifndef _CM_FWD_H_
#define _CM_FWD_H_

#include "ctcutil_list.h"
#include "cm_com_common.h"
#include "cm_ipe.h"
#include "drv_chip_info.h"

struct fwd_ms_dequeue_s
{
   list_head_t head;
   uint8 discard;
   ms_dequeue_t msg_dequeue;
};
typedef struct fwd_ms_dequeue_s fwd_ms_dequeue_t;

struct fwd_ms_enqueue_s
{
   list_head_t head;

   ms_enqueue_t msg_enqueue;
};
typedef struct fwd_ms_enqueue_s fwd_ms_enqueue_t;

struct fwd_ms_met_fifo_s
{
   list_head_t head;

   ms_met_fifo_t msg_metfifo;

   /* met fifo external info */
   uint32 rsv_11                                                           :11;
   uint32 port_bitmap_replication_ctl_index                                :1;
   uint32 last_dest_map_15_12                                              :4;
   uint32 end_local_rep                                                    :1;
   uint32 next_met_entry_ptr                                               :15;
   uint32 current_met_entry                                                :15;

   uint32 resv_12                                                          :7;
   uint32 is_link_aggregation_bitmap                                       :1;
   uint32 port_bitmap_55_32                                                :24;

   uint32 port_bitmap_31_0                                                 :32;

};
typedef struct fwd_ms_met_fifo_s fwd_ms_met_fifo_t;

struct fwd_queue_entry_s
{
   list_head_t head;
   uint8 discard     :1;
   uint16 queue_id   :10;
   uint8 replication_ctl_ext :1;
   //uint8 logical_rep_count  :4;
   ds_queue_entry_t ds_queueentry;
};
typedef struct fwd_queue_entry_s fwd_queue_entry_t;

struct pkt_buf_store_info_s
{
    uint32 head_buffer_ptr;
    uint32 tail_buffer_ptr;
    uint32 buffer_count;
    uint32 head_buf_offset;
    uint32 msg_type;
};
typedef struct pkt_buf_store_info_s pkt_buf_store_info_t;

struct queue_packet_info_s
{
    fwd_ms_met_fifo_t *ms_met_fifo;

    greatbelt_exception_info_t *bexception;

    //ms_packet_header_t *bheader;

    uint16 src_vlan_id;
 //   uint16 packet_length;

    uint16 rx_oam_type;
    uint16 reserved;

    list_head_t ms_enqueue_list;
    list_head_t ms_dequeue_list;
};
typedef struct queue_packet_info_s queue_packet_info_t;

enum exception_vector_e
{
    EXCEPTION_VECT_BIT_EXCEPTION,
    EXCEPTION_VECT_BIT_L2_SPAN,
    EXCEPTION_VECT_BIT_L3_SPAN,
    EXCEPTION_VECT_BIT_ACL_LOG0,
    EXCEPTION_VECT_BIT_ACL_LOG1,
    EXCEPTION_VECT_BIT_ACL_LOG2,
    EXCEPTION_VECT_BIT_ACL_LOG3,
    EXCEPTION_VECT_BIT_PORT_LOG,
    EXCEPTION_VECT_BIT_CPU_LOG,
    MAX_EXCEPTION_VECT_BIT_NUM,
};
typedef enum exception_vector_e exception_vector_t;

extern int32
cm_qmgt_buffer_store_handle(queue_in_pkt_t *qpkt, pkt_buf_store_info_t *pkt_buf_info);

extern int32
cm_qmgt_met_fifo_handle(queue_in_pkt_t *qpkt);

extern int32
cm_qmgt_qmanager_handle(queue_in_pkt_t *qpkt);

extern int32
cm_qmgt_buffer_retrieve_handle(queue_in_pkt_t *qpkt, list_head_t *out_pkt);

#endif
