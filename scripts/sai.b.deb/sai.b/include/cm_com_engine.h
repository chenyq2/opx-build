/****************************************************************************
 * cm_com_engine.h: All packet type Deinfines.
 *
 * Copyright: (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiang.
 * Date:         2010-11-1.
 * Reason:       First Create.
 ****************************************************************************/
#ifndef _CM_COM_ENGINE_H_
#define _CM_COM_ENGINE_H_

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "ctckal.h"
#include "drv_enum.h"
#include "cm_com_common.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/
enum queue_type_e
{
    SIM_IPE_Q,
    SIM_FWD_Q,
    SIM_EPE_Q,
    SIM_OAM_Q,
    SIM_NETTX_Q,
    SIM_MAX_Q,
};
typedef enum queue_type_e queue_type_t;

enum thread_type_e
{
    SIM_IPE_T,
    SIM_FWD_T,
    SIM_EPE_T,
    SIM_OAM_T,
    SIM_NETRX_T,
    SIM_NETTX_T,
    SIM_MAX_T,
};
typedef enum thread_type_e thread_type_t;

enum mux_type_e
{
    SIM_IPE_M,
    SIM_FWD_M,
    SIM_EPE_M,
    SIM_OAM_M,
    SIM_MAX_M,
};
typedef enum mux_type_e mux_type_t;


/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/
extern ctckal_queue_t sim_queue[];
extern sim_model_t g_sim_model[];


/****************************************************************************
 *
 * Functions
 *
****************************************************************************/
extern int32 sim_model_component_install(uint8 chip_id_offset);

extern int32 sim_emu_show_fwd_lbk_humber(uint8* inpkt_file, char* outpkt_file);

extern int32 sim_ioctl(uint8 chip_id, int32 index, uint32 cmd, void* val);

#endif

