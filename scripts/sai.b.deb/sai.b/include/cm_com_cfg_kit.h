/****************************************************************************
 * cm_sim_cfg_kit.h: Cmodel configuration command tools
 *
 * Centec 2011 (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:
 * Author:       Zhouw
 * Date:         2010-11-25
 * Reason:       First Create.
****************************************************************************/
#ifndef _CM_SIM_CFG_KIT_H_
#define _CM_SIM_CFG_KIT_H_

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "ctcutil_list.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/
struct cm_cfg_lpm_hash_result_s
{
    uint32 result_index;
    uint32 result_status;
};
typedef struct cm_cfg_lpm_hash_result_s cm_cfg_lpm_hash_result_t;

/* table allocation information structure */
struct cm_table_allocation_info_s
{
    uint32 index_num;
    tbls_id_t table_id;
    uint32 key_size; /* in bytes, only used for tcam key, other tables key size equals entry size */
};
typedef struct cm_table_allocation_info_s cm_table_allocation_info_t;



struct share_mem_profile_info_s
{
    uint16 mem_profile_bitmap;      /* bitmap store this share list is in each memory block */
    uint32 mem_profile_hw_data_base_offset[MAX_MEMORY_BLOCK_NUM];   /* offset = (hw_address of share list) - (hw_address of each block) */
    uint32 mem_profile_entry_num[MAX_MEMORY_BLOCK_NUM];         /* entry num of share list in each block */
    uint16 mem_profile_chked_flg[MAX_MEMORY_BLOCK_NUM];         /* flag indicate if the share list in each block is checked, only used for profile check */
    uint8 access_mode_care_flag;                                /* TRUE: table in this share list should care access mode,
                                                                FALSE: table in this share list needn't care access mode */
};
typedef struct share_mem_profile_info_s share_mem_profile_info_t;

/* shared table informations */
struct share_mem_info_s
{
    uint32 table_num;               /* share list num */
    uint32 *p_share_mem_table_list;     /* ptr show the share list */
    uint8 is_allocated;             /* indicated if this share list is allocated */
    share_mem_profile_info_t *share_mem_profile_info_ptr; /* memory profile info of share list , used by dynamic table */
};
typedef struct share_mem_info_s share_mem_info_t;

/* outer list info struct */
struct mem_external_declare_tbl_list_s
{
    uint32 tbl_num;
    uint32 *tbl_list;
};
typedef struct mem_external_declare_tbl_list_s mem_external_declare_tbl_list_t;

enum cm_mem_profile_e
{
    CM_MEM_PROFILE_DEFAULT = 0,

    CM_MEM_PROFILE_ENTERPRISE0 = 1,
    CM_MEM_PROFILE_ENTERPRISE1 = 2,
    CM_MEM_PROFILE_ENTERPRISE2 = 3,
    CM_MEM_PROFILE_ENTERPRISE3 = 4,
    CM_MEM_PROFILE_ENTERPRISE4 = 5,
    CM_MEM_PROFILE_ENTERPRISE5 = 6,
    CM_MEM_PROFILE_ENTERPRISE6 = 7,

    CM_MEM_PROFILE_METRO0,
    CM_MEM_PROFILE_METRO1,
    CM_MEM_PROFILE_METRO2,
    CM_MEM_PROFILE_METRO3,
    CM_MEM_PROFILE_METRO4,
    CM_MEM_PROFILE_METRO5,

    CM_MEM_PROFILE_OAM_PERF = 14,

    CM_MEM_PROFILE_UNKOWN,
};
typedef enum cm_mem_profile_e cm_mem_profile_t;

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/
extern int32 cm_sim_cfg_kit_allocate_process(void);
extern int32 cm_sim_cfg_kit_init_mem_allocation_profile(cm_mem_profile_t mem_profile_index);
extern int32 cm_sim_cfg_kit_allocate_tcam_key_process(cm_table_allocation_info_t *table_alloc_info);

extern int32 cm_sim_cfg_kit_allocate_tcam_ad_process(cm_table_allocation_info_t *table_alloc_info);

extern void cm_sim_allocate_tcam_key_extend_info(void);

extern void cm_sim_cfg_kit_show_tcam_allocation(void);
extern void cm_sim_cfg_kit_show_hash_allocation(void);
extern void cm_sim_cfg_kit_show_dynamic_allocation(void);

extern void cm_sim_cfg_kit_show_table_allocation(void);

extern int32 cm_sim_cfg_kit_show_rtl_register_info(uint8 info_flag);
extern int32 cm_sim_cfg_kit_allocate_dynamic_tbl_chk(uint32 chip_id);
extern int32 cm_sim_cfg_kit_allocate_tcam_tbl_chk(uint32 chip_id);

extern int32 cm_sim_cfg_kit_update_lpm_prefix_table(uint8 chip_id, ds_lpm_request_t* p_ds_lpm_request);
extern int32 cm_sim_cfg_kit_allocate_lpm_tcam_key_process(cm_table_allocation_info_t *table_alloc_info);
extern int32 cm_sim_cfg_kit_allocate_lpm_tcam_ad_process(cm_table_allocation_info_t *table_alloc_info);

extern int32 cm_sim_lpm_engine_update_routing_table(uint8*, uint16*, uint8, uint16);

extern int32 cm_sim_cfg_kit_add_fib_key(uint8, fib_hash_type_t, void*);
extern int32 cm_sim_cfg_kit_delete_fib_key(uint8, fib_hash_type_t, void*);

extern int32 cm_sim_cfg_kit_add_userid_key(uint8, userid_hash_type_t, void*);
extern int32 cm_sim_cfg_kit_delete_userid_key(uint8, userid_hash_type_t, void*);

extern int32 cm_sim_cfg_kit_add_lpm_hash_key(uint8, lpm_hash_type_t, void*);
extern int32 cm_sim_cfg_kit_delete_lpm_hash_key(uint8, lpm_hash_type_t, void*);

extern int32 cm_sim_cfg_kit_add_queue_key(uint8, void*);
extern int32 cm_sim_cfg_kit_del_queue_key(uint8, void*);

/* temp clear LPM key process */
extern int32 cm_sim_cfg_kit_delete_lpm_lookup_key(uint8 chip_id);


extern share_mem_info_t sram_share_mem_info[];

extern mem_external_declare_tbl_list_t mem_extern_userid_dft_list;
extern mem_external_declare_tbl_list_t mem_extern_tcam_ad_list;
extern mem_external_declare_tbl_list_t mem_extern_tcam_key_list;
extern mem_external_declare_tbl_list_t mem_extern_lpm_tcam_ad_list;

#endif

