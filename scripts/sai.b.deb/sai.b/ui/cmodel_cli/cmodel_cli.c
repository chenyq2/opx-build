/****************************************************************************
 * cmodel_cli.c   cmodel cli implementation
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0
 * Author:       Jiang
 * Date:         2010-11-1.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "ctc_cli.h"
#include "ctcutil_lib.h"
#include "cm_lib.h"
#if (SDK_WORK_PLATFORM == 0)
#if 0 /*SDK Remove*/
#include "dbg_tool_cli.h"
#include "dbg_tool_cli_process.h"
#endif
#endif
#include "cmodel_cli.h"

#define CTC_CLI_EGRESS_NICKNAME "<0-0xFFFF>"
#define CTC_CLI_IPV6_FORMAT "IPv6 address in X:X::X:X format"



/*-----------------
 define global var
------------------*/
extern bool cmodel_debug_on;
extern bool ctc_cmodel_debug_on;
extern uint32 ctc_cmodel_debug_flag;

bool cmodel_store_cfg_on = TRUE;  /* if TRUE, enable store cfg during running cases, FALSE, disable store cfg */
/*-------------------------
define hash cli cmd use var
---------------------------*/

/* use for Humber&BCM interOp test Environment, mac entity need know higig
 version to add/remove HuaWei higig2/higig+ header */
extern uint8 hg_plus_version;

/* Store the last input tableID when load default config (use for cmodel load config) */
tbls_id_t store_table_id;

uint32
cm_hash_calculate_lpm_ipv6_mcast(uint8* p_data, uint32 bit_num)
{
    uint32 seed = 0;

    return drv_hash_crc_data(&seed, p_data, bit_num, DRV_POLY_CCITT_CRC16, 16, LPM_POINTER_BUCKET_WIDTH);
}

void cio_printf(char * str)
{
    printf(str);
}
/* Cmd format: cmodel debug (on | off) */
CTC_CLI(cli_cmodel_debug_on,
    cli_cmodel_debug_on_cmd,
    "cmodel debug (on | off)",
    "Cmodel debug",
    "Debugging function",
    "Cmodel debug on",
    "Cmodel debug off")
{
    if(0 == sal_memcmp(argv[0], "on", 2))
    {
        cmodel_debug_on = TRUE;
    }
    else if(0 == sal_memcmp(argv[0], "off", 3))
    {
        cmodel_debug_on = FALSE;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_ctc_debug_on,
    cli_cmodel_ctc_debug_on_cmd,
    "cmodel fwd-info global (on | off)",
    "Cmodel debug",
    "cmodel forward information function",
    "show global cmodel fwd info",
    "Cmodel fwd info on",
    "Cmodel fwd info off")
{
    if(0 == sal_memcmp(argv[0], "on", 2))
    {
        ctc_cmodel_debug_on = TRUE;
    }
    else if(0 == sal_memcmp(argv[0], "off", 3))
    {
        ctc_cmodel_debug_on = FALSE;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_ctc_debug_flag,
    cli_cmodel_ctc_debug_flag_cmd,
    "cmodel fwd-info (on {fwd_path | parser_info | key_info | lookup_key | tbl_ptr | discard_type | qmgr_msg | qmgr_hdr | qmgr_linkagg | aging | all} | off)",
    "Cmodel debug",
    "cmodel forward information function",
    "Cmodel fwd info on",
    "packet forwarding path",
    "packet parser information",
    "packet process key information",
    "packet lookup key info",
    "packet forwarding table Ptr",
    "packet discard reason",
    "packet in queue manager msg information",
    "packet in queue manager packet header information",
    "packet in queue manager link aggregation information",
    "aging timer",
    "all information above",
    "Cmodel fwd info off")
{
    uint8 index = 0;

    uint32 flag = 0;
    index = ctc_cli_get_prefix_item(&argv[0], argc, "on", sal_strlen("on"));
    if (0xFF != index)
    {
        index = ctc_cli_get_prefix_item(&argv[0], argc, "fwd_path", sal_strlen("fwd_path"));
        if(0xFF != index)
        {
            flag |=  CTC_CMODEL_DEBUG_FLAG_FWD_PATH;
        }

        index = ctc_cli_get_prefix_item(&argv[0], argc, "parser_info", sal_strlen("parser_info"));
        if(0xFF != index)
        {
            flag |=  CTC_CMODEL_DEBUG_FLAG_PARSER_INFO;
        }

        index = ctc_cli_get_prefix_item(&argv[0], argc, "key_info", sal_strlen("key_info"));
        if(0xFF != index)
        {
            flag |=  CTC_CMODEL_DEBUG_FLAG_KEY_INFO;
        }

        index = ctc_cli_get_prefix_item(&argv[0], argc, "lookup_key", sal_strlen("lookup_key"));
        if(0xFF != index)
        {
            flag |=  CTC_CMODEL_DEBUG_FLAG_LOOKUP_KEY;
        }

        index = ctc_cli_get_prefix_item(&argv[0], argc, "tbl_ptr", sal_strlen("tbl_ptr"));
        if(0xFF != index)
        {
            flag |=  CTC_CMODEL_DEBUG_FLAG_TABLE_PTR;
        }

        index = ctc_cli_get_prefix_item(&argv[0], argc, "discard_type", sal_strlen("discard_type"));
        if(0xFF != index)
        {
            flag |=  CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE;
        }

        index = ctc_cli_get_prefix_item(&argv[0], argc, "qmgt_pkt", sal_strlen("qmgt_pkt"));
        if(0xFF != index)
        {
            flag |=  CTC_CMODEL_DEBUG_FLAG_QMGT_HDR;
        }

        index = ctc_cli_get_prefix_item(&argv[0], argc, "qmgt_msg", sal_strlen("qmgt_msg"));
        if(0xFF != index)
        {
            flag |=  CTC_CMODEL_DEBUG_FLAG_QMGT_MSG;
        }

        index = ctc_cli_get_prefix_item(&argv[0], argc, "qmgt_linkagg", sal_strlen("qmgt_linkagg"));
        if(0xFF != index)
        {
            flag |=  CTC_CMODEL_DEBUG_FLAG_QMGT_LINKAGG;
        }

        index = ctc_cli_get_prefix_item(&argv[0], argc, "aging", sal_strlen("aging"));
        if(0xFF != index)
        {
            flag |=  CTC_CMODEL_DEBUG_FLAG_AGING;
        }

        index = ctc_cli_get_prefix_item(&argv[0], argc, "all", sal_strlen("all"));
        if(0xFF != index)
        {
            flag = 0x3FF;
        }

    }
    else
    {
        index = ctc_cli_get_prefix_item(&argv[0], argc, "off", sal_strlen("off"));
        if(0xFF != index)
        {
            flag = 0;
        }
    }
    ctc_cmodel_debug_flag = flag;

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_tcpdump,
     cli_cmodel_tcpdump_cmd,
     "tcpdump FILENAME",
     "Use tcpdump to check captured file",
     "Filename")
{
#define CMD_LEN_MAX 256
    int32 ret = 0;
    char cmd[CMD_LEN_MAX];
    snprintf(cmd, CMD_LEN_MAX, "/usr/sbin/tcpdump -vv -r %s", argv[0]);
    ret = system(cmd);
    if (ret)
    {
        ctc_cli_out("%% Error with rv = %d\n", ret);
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

/* Cmd format: hash debug (on | off) */
CTC_CLI(cli_hash_debug_on,
    cli_hash_debug_on_cmd,
    "hash debug (on | off)",
    "Hash debug",
    "Debugging function",
    "Hash debug on",
    "Hash debug off")
{
    if(0 == sal_memcmp(argv[0], "on", 2))
    {
        hash_debug_on = TRUE;
    }
    else if(0 == sal_memcmp(argv[0], "off", 3))
    {
        hash_debug_on = FALSE;
    }

    return CLI_SUCCESS;
}


/*********************************
 Driver use cli cmd
**********************************/
/* Cmd format: init driver <chip_num> <chip_id_base> */
CTC_CLI(cli_driver_init,
    cli_driver_init_cmd,
    "init driver <1-2> CHIP_ID_BASE",
    "Driver cmd",
    "Initialize driver information cmd",
    "Initialize chip num <1-2>",
    "Chip ID start base")
{
    uint8 chip_num = 0;
    uint8 chip_id_base = 0;
    int32 ret = DRV_E_NONE;

    CTC_CLI_GET_INTEGER("chip_num", chip_num, argv[0]);
    CTC_CLI_GET_INTEGER("chip_id_base", chip_id_base, argv[1]);

    if (chip_num == 0)
    {
        return CLI_ERROR;
    }

    ret = drv_init(chip_num, chip_id_base);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

#if (SDK_WORK_PLATFORM == 0)
#if 0 /*SDK Remove*/
    ctc_dbg_tool_init(CTC_CMODEL_MODE);
#endif
#endif

    return CLI_SUCCESS;
}


/* Cmd format: (set-field | set-mask-field) <chip_id> <tbl_id> <index> <field_id> <value> (tcam-key-write-trigger|)*/
CTC_CLI(cli_driver_drv_set_field,
    cli_driver_drv_set_field_cmd,
    "(set-field | set-mask-field) CHIP_ID TAB_ID INDEX FIELD_ID VALUE (tcam-key-write-trigger|)",
    "Set table's field value cmd",
    "Set Tcam mask field value cmd",
    "chipid",
    "Table name",
    "Table index",
    "Field name",
    "Setted value",
    "tcam key setting trigger on emulation")
{
    proc_field_t field_info;
    int32 ret = DRV_E_NONE;
    char *tbl_name = NULL, *fld_name = NULL;
    uint32 chip_id = 0;

    sal_memset(&field_info, 0, sizeof(proc_field_t));

    if (0 == sal_strncmp(argv[0], "set-mask-field", sal_strlen("set-mask-field")))
    {
        field_info.mask = TRUE;
    }

    CTC_CLI_GET_INTEGER("chip_id", chip_id, argv[1]);
    chip_id = 0;
    if ((chip_id < drv_init_chip_info.drv_init_chipid_base)
        || (chip_id >= drv_init_chip_info.drv_init_chipid_base
                                + drv_init_chip_info.drv_init_chip_num))

    {
        ctc_cli_out("\nINVALID chip ID during setting table field process!\n");
        return CLI_ERROR;
    }

    field_info.chip_id_offset = chip_id - drv_init_chip_info.drv_init_chipid_base;

    tbl_name = argv[2];
    if (0 == sal_strcmp(tbl_name, TABLE_NAME(store_table_id))) /* firstly compare the last input tableName */
    {
        field_info.tbl_id = store_table_id;
    }
    else if(drv_get_tbl_id_by_string(&(field_info.tbl_id), tbl_name) < 0)
    {
        ctc_cli_out("%% Fail to search tbl_id = %s, ret = 0x%08x\n",
                    tbl_name,
                    field_info.tbl_id);
        return CLI_ERROR;
    }

    CTC_CLI_GET_INTEGER("index", field_info.index, argv[3]);

    fld_name = argv[4];
    if(drv_get_field_id_by_string(field_info.tbl_id, &(field_info.field_id), fld_name) < 0)
    {
         ctc_cli_out("%% Fail to search field_id = %s, ret = 0x%08x\n",
                     fld_name,
                     field_info.field_id);
         return CLI_ERROR;
     }

    CTC_CLI_GET_INTEGER("value", field_info.value, argv[5]);

#if (SDK_WORK_PLATFORM == 0)
    if (drv_table_is_tcam_key(field_info.tbl_id))
    {
        if (argc > 6)
        {
            uint32 index = ctc_cli_get_prefix_item(&argv[6], argc, "tcam-key-write-trigger", sal_strlen("tcam-key-write-trigger"));
            if (index != 0xFF)
            {
                field_info.tcam_write_trigger = TRUE;
            }
        }

        ret = sim_cfg_emu_set_tcam_field(&field_info);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Fail to set Emu tcam table %s's field %s value\n", tbl_name, fld_name);
            return CLI_ERROR;
        }
        else
        {
            return CLI_SUCCESS;
        }
    }

    /* temp code */
    if (((field_info.tbl_id == IpeLearningCacheValid_t)
        && (field_info.field_id == IpeLearningCacheValid_LearningEntryValid_f)) ||
        ((field_info.tbl_id == OamErrorDefectCtl_t)
        && (field_info.field_id == OamErrorDefectCtl_CacheEntryValid_f)))
    {
        if (field_info.value == 0)
        {
            field_info.value = 0xFFFF;
        }
    }
    else if ((field_info.tbl_id == DsOamDefectStatus_t)
        && (field_info.field_id == DsOamDefectStatus_DefectStatus_f))
    {
        if (field_info.value == 0)
        {
            field_info.value = 0xFFFFFFFF;
        }
    }
    else if ((field_info.tbl_id == OamDefectCache_t)
        && (field_info.field_id == OamDefectCache_ScanPtr_f))
    {
        if (field_info.value == 0)
        {
            field_info.value = 0x1FF;
        }
    }
#endif

    ret = sim_cfg_set_field(&field_info);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to set table %s's field %s value\n",
                    tbl_name,
                    fld_name);
        return CLI_ERROR;
    }
    else
    {
        store_table_id = field_info.tbl_id; /* Store the tableId, and use for the next driver setting */
        return CLI_SUCCESS;
    }
}

/* Cmd format: (get-field | get-mask-field) <chip_id> <tbl_id> <index> <field_id> */
CTC_CLI(cli_driver_drv_get_field,
    cli_driver_drv_get_field_cmd,
    "(get-field | get-mask-field) CHIP_ID TAB_ID INDEX FIELD_ID",
    "Get Table's field value cmd",
    "Get Tcam Mask's field value cmd",
    "chipid",
    "Table name",
    "Table index",
    "Field name")
{
    proc_field_t field_info;
    int32 ret = DRV_E_NONE;
    char *tbl_name = NULL, *fld_name = NULL;
    uint32 chip_id = 0;

    sal_memset(&field_info, 0, sizeof(proc_field_t));

    if (0 == sal_strncmp(argv[0], "get-mask-field", sal_strlen("get-mask-field")))
    {
        field_info.mask = TRUE;
    }

    CTC_CLI_GET_INTEGER("chip_id", chip_id, argv[1]);
    chip_id = 0;
    if ((chip_id < drv_init_chip_info.drv_init_chipid_base)
        || (chip_id >= drv_init_chip_info.drv_init_chipid_base
                                + drv_init_chip_info.drv_init_chip_num))
    {
        ctc_cli_out("\nINVALID chip ID during getting table field process!\n");
        return CLI_ERROR;
    }

    field_info.chip_id_offset = chip_id - drv_init_chip_info.drv_init_chipid_base;

    tbl_name = argv[2];
    if(drv_get_tbl_id_by_string(&(field_info.tbl_id), tbl_name) < 0)
    {
        ctc_cli_out("%% Fail to search tbl_id = %s, ret = 0x%08x\n",
                    tbl_name,
                    field_info.tbl_id);
        return CLI_ERROR;
    }

    CTC_CLI_GET_INTEGER("index", field_info.index, argv[3]);

    fld_name = argv[4];
    if(drv_get_field_id_by_string(field_info.tbl_id, &(field_info.field_id), fld_name) < 0)
    {
         ctc_cli_out("%% Fail to search field_id = %s, ret = 0x%08x\n",
                     fld_name,
                     field_info.field_id);
         return CLI_ERROR;
    }

    ret = sim_cfg_get_field(&field_info);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to get table %s's field %s value\n",
                    tbl_name,
                    fld_name);
        return CLI_ERROR;
    }
    else
    {
        ctc_cli_out("\nsim_cfg_get_field = 0x%08x\n", field_info.value);
        return CLI_SUCCESS;
    }
}

/* Cmd format: drv remove tcam-key <chip_id> <table_id> <index> */
CTC_CLI(cli_driver_drv_remove_tcam,
    cli_driver_drv_remove_tcam_cmd,
    "drv remove tcam-key CHIP_ID TAB_ID INDEX",
    "drv cmd",
    "drv remove cmd",
    "drv remove tcam-key",
    "chipid",
    "tcam key id",
    "index")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    char * key_name = NULL;
    uint32 index = 0;
    uint32 tcam_key_table_id = 0;

    CTC_CLI_GET_INTEGER("chip_id", chip_id, argv[0]);
    chip_id = 0;
    if ((chip_id < drv_init_chip_info.drv_init_chipid_base)
        || (chip_id >= drv_init_chip_info.drv_init_chipid_base
                                + drv_init_chip_info.drv_init_chip_num))
    {
        ctc_cli_out("\nINVALID chip ID during getting register field process!\n");
        return CLI_ERROR;
    }
    key_name = argv[1];
    if (drv_get_tbl_id_by_string(&tcam_key_table_id, key_name) < 0)
    {
        ctc_cli_out("%% Fail to search table_id = %s, ret = 0x%08x\n",
                    key_name,
                    tcam_key_table_id);
        return CLI_ERROR;
    }
    CTC_CLI_GET_INTEGER("index", index, argv[2]);

    ret = drv_io_api.drv_tcam_tbl_remove(chip_id, tcam_key_table_id, index);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

/*********************************
 Cmodel use cli cmd
**********************************/
/* Cmd format: init cmodel */
CTC_CLI(cli_cmodel_sim_init_cmodel,
    cli_cmodel_sim_init_cmodel_cmd,
    "init cmodel",
    "Cmodel cmd",
    "Initialize cmodel information cmd")
{
    int32 ret = DRV_E_NONE;

    ret = sim_model_init(UM_EMU_MODE_CMODEL);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to init cmodel\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

/* Cmd format: release cmodel */
CTC_CLI(cli_cmodel_sim_release_cmodel,
    cli_cmodel_sim_release_cmodel_cmd,
    "release cmodel",
    "Cmodel cmd",
    "release cmodel information cmd")
{
    int32 ret = DRV_E_NONE;

    ret = sim_model_release();
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to release cmodel\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

/* Cmd format: init sram module */
CTC_CLI(cli_cmodel_sim_init_model,
    cli_cmodel_sim_init_model_cmd,
    "model init",
    "model cmd",
    "Initialize sram model and tcam modelinformation cmd")
{
#if (SDK_WORK_PLATFORM == 1)
    int32 ret = DRV_E_NONE;
    uint8 chip_id = 0;
    uint8 chip_num = 0;
    uint8 chip_id_base = 0;
    uint8 chip_id_offset = 0;

    DRV_IF_ERROR_RETURN(drv_get_chipnum(&chip_num));
    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chip_id_base));

    for (chip_id = chip_id_base; chip_id < chip_id_base + chip_num; chip_id++)
    {
        chip_id_offset = chip_id - chip_id_base;

        ret = sram_model_initialize(chip_id_offset);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Fail to init sram model, chip_id = %d\n", chip_id);
            return CLI_ERROR;
        }

        ret = tcam_model_initialize(chip_id_offset);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Fail to init tcam model, chip_id = %d\n", chip_id);
            return CLI_ERROR;
        }
    }
#endif

    return CLI_SUCCESS;

}

/* Cmd format: release sram module */
CTC_CLI(cli_cmodel_sim_release_model,
    cli_cmodel_sim_release_model_cmd,
    "model release",
    "model cmd",
    "release sram model and tcam model information cmd")
{
#if (SDK_WORK_PLATFORM == 1)
    int32 ret = DRV_E_NONE;
    uint8 chip_id = 0;
    uint8 chip_num = 0;
    uint8 chip_id_base = 0;
    uint8 chip_id_offset = 0;

    DRV_IF_ERROR_RETURN(drv_get_chipnum(&chip_num));
    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chip_id_base));

    for (chip_id = chip_id_base; chip_id < chip_id_base + chip_num; chip_id++)
    {
        chip_id_offset = chip_id - chip_id_base;

        ret = sram_model_release(chip_id_offset);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Fail to release sram model, chip_id = %d\n", chip_id);
            return CLI_ERROR;
        }

        ret = tcam_model_release(chip_id_offset);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Fail to init tcam model, chip_id = %d\n", chip_id);
            return CLI_ERROR;
        }
    }
#endif

    return CLI_SUCCESS;

}

/* Cmd format: set <chipid> higig-version (higigplus | higig2) */
CTC_CLI(cli_cmodel_set_higig_version_mode,
    cli_cmodel_set_higig_version_mode_cmd,
    "set CHIP_ID higig-version (higigplus|higig2)",
    "Driver cmd",
    "Chip id",
    "Setting higig version for mac position control",
    "Higigplus",
    "higig2")
{
    uint8 chip_id;

    CTC_CLI_GET_INTEGER("chip_id", chip_id, argv[0]);
    chip_id = 0;
    if ((chip_id < drv_init_chip_info.drv_init_chipid_base)
        || (chip_id >= drv_init_chip_info.drv_init_chipid_base
                       + drv_init_chip_info.drv_init_chip_num))
    {
        ctc_cli_out("\nINVALID chip ID during setting higig version process!\n");
        return CLI_ERROR;
    }

    if (0 == sal_strncmp(argv[1], "higigplus", sal_strlen("higigplus")))
    {
        hg_plus_version = TRUE;
    }
    else if (0 == sal_strncmp(argv[1], "higig2", sal_strlen("higig2")))
    {
        hg_plus_version = FALSE;
    }
    else
    {
        ctc_cli_out("%% Error! the 2th para is Invalid, %s\n",argv[1]);
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

/* Cmd format: store asic-in-pkt (ipe | epe | qmgt | oam|...) <file_name> */
CTC_CLI(cli_cmodel_sim_store_model_inpkt,
    cli_cmodel_sim_store_model_inpkt_cmd,
    "store asic-in-pkt (ipe|epe|qmgt|oam\
    |pktcnt-rx|pktcnt-tx|cpu-netrx|epe-bhdr\
    |ipe-bhdr|out-pkt|oam-pkt) STORE_INPKT_FILE",
    "Cmodel cmd",
    "Store pkt or header cmd",
    "Ipe module",
    "Epe module",
    "Qmgr module",
    "OAM module",
    "PktCntRx module",
    "PktCntTx module",
    "CpuNetRx module",
    "EpeBHdr module",
    "IpeBHdr module",
    "Outpkt",
    "OAM packet",
    "Store file name")
{
    uint32 type;
    char *file_name = NULL;
    int32 ret = DRV_E_NONE;

    file_name = argv[1];

    if (0 == sal_strncmp(argv[0], "ipe-bhdr", sal_strlen("ipe-bhdr")))
    {
        type = 12;
    }
    else if (0 == sal_strncmp(argv[0], "out-pkt", sal_strlen("out-pkt")))
    {
        type = 11;
    }
    else if (0 == sal_strncmp(argv[0], "oam-pkt", sal_strlen("oam-pkt")))
    {
        type = 10;
    }
    else if (0 == sal_strncmp(argv[0], "epe-bhdr", sal_strlen("epe-bhdr")))
    {
        type = 9;
    }
    else if (0 == sal_strncmp(argv[0], "pktcnt-tx", sal_strlen("pktcnt-tx")))
    {
        type = 8;
    }
    else if (0 == sal_strncmp(argv[0], "pktcnt-rx", sal_strlen("pktcnt-rx")))
    {
        type = 7;
    }
    else if (0 == sal_strncmp(argv[0], "oam", sal_strlen("oam")))
    {
        type = 5;
    }
    else if (0 == sal_strncmp(argv[0], "cpu-netrx", sal_strlen("cpu-netrx")))
    {
        type = 4;
    }
    else if (0 == sal_strncmp(argv[0], "epe", sal_strlen("epe")))
    {
        type = 3;
    }
    else if (0 == sal_strncmp(argv[0], "qmgt", sal_strlen("qmgt")))
    {
        type = 2;
    }
    else if (0 == sal_strncmp(argv[0], "ipe", sal_strlen("ipe")))
    {
        type = 1;
    }
    else
    {
        ctc_cli_out("%% Error! Invalid 1th para!\n");
        return CLI_ERROR;
    }

    switch (type)
    {
        case 1:
            ret = sim_asic_ipe_inpkt(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store IPE inpkt! And return value = %d\n", ret);
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        case 2:
            ret = sim_asic_qmgt_inpkt(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store QMGR inpkt! And return value = %d\n", ret);
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        case 3:
            ret = sim_asic_epe_inpkt(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store EPE inpkt! And return value = %d\n", ret);
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        case 4:
            sim_asic_cpu_netrx_inpkt(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store CPU NetRX inpkt! And return value = %d\n", ret);
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        case 5:
            ret = sim_asic_oam_inpkt(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store OAM inpkt! And return value = %d\n", ret);
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        case 7:
            ret = sim_asic_rx_pkt_cnt(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store NetRX inpkt! And return value = %d\n", ret);
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        case 8:
            ret = sim_asic_tx_pkt_cnt(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store NetTX inpkt! And return value = %d\n", ret);
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        case 9:
            ret = sim_asic_epe_bhdr_inpkt(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store EPE Bridge Header inpkt! And return value = %d\n", ret);
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        case 10:
            ret = sim_store_oam_outpkt_filename(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store OAM outpkt\n");
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        case 11:
            ret = sim_store_outpkt_filename(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store outpkt\n");
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        case 12:
            ret = sim_asic_ipe_bhdr_inpkt(file_name);
            if (ret < DRV_E_NONE)
            {
                ctc_cli_out("%% Error! Fail to store IPE Bridge Header inpkt! And return value = %d\n", ret);
                return CLI_ERROR;
            }
            else
            {
                break;
            }
        default:
            break;
    }

    return CLI_SUCCESS;
}

/* Cmd format: store (tx-higig-hdr|mux-higig-hdr) <file_name> */
CTC_CLI(cli_cmodel_sim_model_store_higig_header,
    cli_cmodel_sim_model_store_higig_header_cmd,
    "store (tx-higig-hdr|mux-higig-hdr) HIGIG_HEADER_FILE",
    "Cmodel cmd",
    "Cmodel cmd",
    "Store higig header cmd in ipeMux or epeNetTx module",
    "tx-higig:epeNetTx moduel(humber->BCM)",
    "mux-higig:ipeMux moduel(BCM->humber)",
    "Higig header store file name")
{
    char *file_name = NULL;
    uint8 type = 0;

    if (0 == sal_strncmp(argv[0], "tx-higig-hdr", sal_strlen("tx-higig-hdr")))
    {
        type = 1;
    }
    else if (0 == sal_strncmp(argv[0], "mux-higig-hdr", sal_strlen("mux-higig-hdr")))
    {
        type = 2;
    }


    file_name = argv[1];

    if (type == 1)
    {
        store_file_name.sghdr_tx_store_en = 1;
        unlink(file_name);
        sal_strcpy(store_file_name.sghdr_tx_outpkt_name, file_name);
    }
    else if (type == 2)
    {
        store_file_name.sghdr_mux_store_en = 1;
        unlink(file_name);
        sal_strcpy(store_file_name.sghdr_mux_inpkt_name, file_name);
    }
    else
    {
        ctc_cli_out("%% Error! Store higig header cmd error\n");
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

/* Cmd format: outpkt-file compare <outpkt_file> <expect_pkt_file> */
CTC_CLI(cli_cmodel_sim_whole_compare_file,
    cli_cmodel_sim_whole_compare_file_cmd,
    "outpkt-file compare REAL_OUTPKT_FILE EXPECT_OUTPKT_FILE \
    ({ignore-ip-checksum | ignore-tcp-checksum | ignore-udp-checksum | ignore-all-checksum \
     | ignore-ipv4-totallength | ignore-ipv6-totallength | ignore-udp-totallength | ignore-all-totallength} | )",
    "Cmodel cmd",
    "Compare real outpkt and expect outpkt and record result",
    "Real outpkt file name",
    "Expect outpkt file name",
    "ignore ip checksum",
    "ignore tcp checksum",
    "ignore udp checksum",
    "ignore all checksum",
    "ignore ipv4 totallength",
    "ignore ipv6 totallength",
    "ignore udp totallength",
    "ignore all totallength")
{
    int32 ret = DRV_E_NONE;
    char *src_file = NULL, *dest_file = NULL;
    chk_checksum_flag_t ignor_check_sum; /* control whether check each checksum */
    chk_total_length_flag_t ignor_total_length;  /* control whether check totallength */
    uint32 index = 0xFF;

    src_file = argv[0];
    dest_file = argv[1];

    sal_memset(&ignor_check_sum, 0, sizeof(chk_checksum_flag_t));
    sal_memset(&ignor_total_length, 0, sizeof(chk_total_length_flag_t));

    index = ctc_cli_get_prefix_item(&argv[0], argc, "ignore-ip-checksum", sal_strlen("ignore-ip-checksum"));
    if (index != 0xFF)
    {
        ignor_check_sum.ignore_ip_checksum = TRUE;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "ignore-tcp-checksum", sal_strlen("ignore-tcp-checksum"));
    if (index != 0xFF)
    {
        ignor_check_sum.ignore_tcp_checksum = TRUE;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "ignore-udp-checksum", sal_strlen("ignore-udp-checksum"));
    if (index != 0xFF)
    {
        ignor_check_sum.ignore_udp_checksum = TRUE;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "ignore-all-checksum", sal_strlen("ignore-all-checksum"));
    if (index != 0xFF)
    {
        ignor_check_sum.ignore_ip_checksum = TRUE;
        ignor_check_sum.ignore_tcp_checksum = TRUE;
        ignor_check_sum.ignore_udp_checksum = TRUE;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "ignore-ipv4-totallength", sal_strlen("ignore-ipv4-totallength"));
    if (index != 0xFF)
    {
        ignor_total_length.ignore_ipv4_total_length = TRUE;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "ignore-ipv6-totallength", sal_strlen("ignore-ipv6-totallength"));
    if (index != 0xFF)
    {
        ignor_total_length.ignore_ipv6_total_length = TRUE;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "ignore-udp-totallength", sal_strlen("ignore-udp-totallength"));
    if (index != 0xFF)
    {
        ignor_total_length.ignore_udp_total_length = TRUE;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "ignore-all-totallength", sal_strlen("ignore-all-totallength"));
    if (index != 0xFF)
    {
        ignor_total_length.ignore_ipv4_total_length = TRUE;
        ignor_total_length.ignore_ipv6_total_length = TRUE;
        ignor_total_length.ignore_udp_total_length = TRUE;
    }

    ret = sim_whole_compare_file(src_file, dest_file, &ignor_check_sum,&ignor_total_length);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to do whole pkt compare\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}


/* Cmd format: outpkt-file cmp-rslt <file_name> */
CTC_CLI(cli_cmodel_sim_compare_rslt_file,
    cli_cmodel_sim_compare_rslt_file_cmd,
    "outpkt-file cmp-rslt CMP_FILE",
    "Cmodel cmd",
    "Creat outpkt cmp result file cmd",
    "Cmp result file name")
{
    int32 ret = DRV_E_NONE;
    char *file_name = NULL;

    file_name = argv[0];

    ret = sim_compare_rslt_file(file_name);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to creat outpkt compare result file\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

/* Cmd format: discard-type check result file <file_name> */
CTC_CLI(cli_cmodel_sim_check_discard_type_rslt_file,
    cli_cmodel_sim_check_discard_type_rslt_file_cmd,
    "discard-type check result file DISCARD_CHECK_RESULT_FILE",
    "Cmodel cmd",
    "Creat discard type check result file cmd",
    "Creat discard type check result file cmd",
    "Creat discard type check result file cmd",
    "Check result file name")
{
    int32 ret = DRV_E_NONE;
    char *file_name = NULL;

    file_name = argv[0];

    ret = sim_discard_check_file(file_name);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to creat check discard type result file\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}


/* Cmd format: check ipe discard-type <discard_type> (pkt-cnt PKT_CNT | byte-cnt BYTE_CNT|)*/
CTC_CLI(cli_cmodel_sim_check_ipe_discard_type,
    cli_cmodel_sim_check_ipe_discard_type_cmd,
    "check ipe discard-type ((userid-bind-discard | hdr-adjust-byte-remove-error | psr-len-error | mac-isolated-discard \
     | exception2-discard | userid-discard | port-receive-discard | itag-check-fail | protocol-valn-discard \
     | vlan-tag-ctl-discard | no-allow-mcast-smac | stp-discard | vlan-receive-discard | pbb-oam-discard | arp-dhcp-discard \
     | phyport-port-discard | vlan-filtering | aclqos-discard | routing-mcast-ip-addr-discard | brg-bpdu-etc \
     | storm-ctl-discard | learning-discard | policing-discard | fwd-ptr-invalid | discard-fwd-ptr | fatal-excp-discard \
     | aps-discard | fwd-destid-discard | seqnum-check-discard | hdr-adj-small-pkt | hdr-adj-error | loopback-discard \
     | trill-esadi-discard | efm-discard | capwap-from-ac-error-or-unexpectable | stacking-networking-header-error | trill-discard | capwap-control-excep\
     | layer3-excep | layer2-excep | trill-mcast-addr-check-error | trill-version-check-error | ptp-version-check-error\
     | ptptp2p-trans-clock-delay | oam-not-found | oam-stp-vlan-filter | single-hop-bfd-ttl-discard | capwap-dtls \
     | no-mep-mip | oam-disable | pbb-decap | mpls-tmpls-oam | mplstp-mcc-scc | icmp-error | ptp-acl-excep | ether-service-oam\
     | link-oam | tunnel-outer-martian-addr | capwap-bssid-lookup-or-logic-port-check-fail | userid-dsfwdptr-all-f-discard \
     | capwap-fragment | trill-rpf-fail | mux-port-error) ({chip-id CHIP_ID | pkt-cnt PKT_CNT | byte-cnt BYTE_CNT}|))",
    "Cmodel cmd",
    "ipe",
    "discardType",
    "userid-bind-discard",
    "hdr-adjust-byte-remove-error",
    "psr-len-error",
    "mac-isolated-discard",
    "exception2-discard",
    "userid-discard",
    "port-receive-discard",
    "itag-check-fail",
    "protocol-valn-discard",
    "vlan-tag-ctl-discard",
    "no-allow-mcast-smac",
    "stp-discard",
    "vlan-receive-discard",
    "pbb-oam-discard",
    "arp-dhcp-discard",
    "phyport-port-discard",
    "vlan-filtering",
    "aclqos-discard",
    "routing-mcast-ip-addr-discard",
    "brg-bpdu-etc",
    "storm-ctl-discard",
    "learning-discard",
    "policing-discard",
    "fwd-ptr-invalid",
    "discard-fwd-ptr",
    "fatal-excp-discard",
    "aps-discard",
    "fwd-destid-discard",
    "seqnum-check-discard",
    "hdr-adj-small-pkt",
    "hdr-adj-error",
    "trill-esadi-discard",
    "loopback-discard",
    "efm-discard",
    "capwap-from-ac-error",
    "capwap-from-wtp-error",
    "trill-discard",
    "capwap-control-excep",
    "layer3-excep",
    "layer2-excep",
    "trill-mcast-addr-check-error",
    "trill-version-check-error",
    "ptp-version-check-error",
    "ptptp2p-trans-clock-delay",
    "oam-not-found",
    "oam-stp-vlan-filter",
    "single-hop-bfd-ttl-discard",
    "capwap-dtls",
    "no-mep-mip",
    "oam-disable",
    "pbb-decap",
    "mpls-tmpls-oam",
    "mplstp-mcc-scc",
    "icmp-error",
    "ptp-acl-excep",
    "ether-service-oam",
    "link-oam",
    "tunnel-outer-martian-addr",
    "capwap-bssid-lookup-or-logic-port-check-fail",
    "userid-dsfwdptr-all-f-discard",
    "capwap-fragment",
    "trill-rpf-fail",
    "mux-port-error",
    "chip-id",
    "chip id value",
    "pkt-cnt",
    "pkt count value",
    "byte-cnt",
    "byte count value")
{
    int32 ret = DRV_E_NONE;
    uint32 discard_type = IPE_DISCARD_TYPE_MAX_NUM;
    uint32 moduleid = DISCARD_CHECK_IPE_MODULE;
    uint32 chip_id = 0;
    uint32 expect_pkt_cnt = 0, expect_byte_cnt = 0;  /* >32 bits process TBD??? */
    bool is_pkt_cnt = TRUE;
    uint32 index = 0;

    if(sal_strncmp(argv[0], "userid-bind-discard", sal_strlen("userid-bind-discard")) == 0)
    {
        discard_type = IPE_DISCARD_USER_ID_BINDING_DISCARD;       /*0*/
    }
    else if (sal_strncmp(argv[0], "hdr-adjust-byte-remove-error", sal_strlen("hdr-adjust-byte-remove-error")) == 0)
    {
        discard_type = IPE_DISCARD_HDR_ADJ_BYTE_RMV_ERR_DISCARD; /*1*/
    }
    else if (sal_strncmp(argv[0], "psr-len-error", sal_strlen("psr-len-error")) == 0)
    {
        discard_type = IPE_DISCARD_PSR_LEN_ERR;                  /*2*/
    }
    else if (sal_strncmp(argv[0], "mac-isolated-discard", sal_strlen("mac-isolated-discard")) == 0)
    {
        discard_type = IPE_DISCARD_MAC_ISOLATED_DISCARD;         /*3*/
    }
    else if (sal_strncmp(argv[0], "exception2-discard", sal_strlen("exception2-discard")) == 0)
    {
        discard_type = IPE_DISCARD_EXCEP_2_DISCARD;              /*4*/
    }
    else if (sal_strncmp(argv[0], "userid-discard", sal_strlen("userid-discard")) == 0)
    {
        discard_type = IPE_DISCARD_USER_ID_DISCARD;              /*5*/
    }
    else if (sal_strncmp(argv[0], "itag-check-fail", sal_strlen("itag-check-fail")) == 0)
    {
        discard_type = IPE_DISCARD_ITAG_CHK_FAIL;               /*7*/
    }
    else if (sal_strncmp(argv[0], "protocol-valn-discard", sal_strlen("protocol-valn-discard")) == 0)
    {
        discard_type = IPE_DISCARD_PTL_VLAN_DISCARD;               /*8*/
    }
    else if (sal_strncmp(argv[0], "vlan-tag-ctl-discard", sal_strlen("vlan-tag-ctl-discard")) == 0)
    {
        discard_type = IPE_DISCARD_VLAN_TAG_CTL_DISCARD;                /*9*/
    }
    else if (sal_strncmp(argv[0], "no-allow-mcast-smac", sal_strlen("no-allow-mcast-smac")) == 0)
    {
        discard_type = IPE_DISCARD_NOT_ALLOW_MCAST_MAC_SA_DISCARD;    /*10*/
    }
    else if (sal_strncmp(argv[0], "stp-discard", sal_strlen("stp-discard")) == 0)
    {
        discard_type = IPE_DISCARD_STP_DISCARD;                 /*11*/
    }
    else if (sal_strncmp(argv[0], "port-or-vlan-receive-discard", sal_strlen("port-or-vlan-receive-discard")) == 0)
    {
        discard_type = IPE_DISCARD_PORT_OR_DS_VLAN_RCV_DIS;      /*12*/
    }
    /* XuZx: port-receive-discard and vlan-receive-discard merge to discard type port-or-vlan-receive-discard
     *       Just compatible with previous test case.
     */
    else if (sal_strncmp(argv[0], "port-receive-discard", sal_strlen("port-receive-discard")) == 0)
    {
        discard_type = IPE_DISCARD_PORT_OR_DS_VLAN_RCV_DIS;      /*6*/
    }
    else if (sal_strncmp(argv[0], "vlan-receive-discard", sal_strlen("vlan-receive-discard")) == 0)
    {
        discard_type = IPE_DISCARD_PORT_OR_DS_VLAN_RCV_DIS;      /*12*/
    }
    else if (sal_strncmp(argv[0], "pbb-oam-discard", sal_strlen("pbb-oam-discard")) == 0)
    {
        discard_type = IPE_DISCARD_PBB_OAM_DISCARD;             /*13*/
    }
    else if (sal_strncmp(argv[0], "arp-dhcp-discard", sal_strlen("arp-dhcp-discard")) == 0)
    {
        discard_type = IPE_DISCARD_ARP_DHCP_DISCARD;         /*14*/
    }
    else if (sal_strncmp(argv[0], "phyport-port-discard", sal_strlen("phyport-port-discard")) == 0)
    {
        discard_type = IPE_DISCARD_DS_PHYPORT_SRC_DISCARD;   /*15*/
    }
    else if (sal_strncmp(argv[0], "vlan-filtering", sal_strlen("vlan-filtering")) == 0)
    {
        discard_type = IPE_DISCARD_VLAN_STATUS_FILTER_DISCARD;    /*16*/
    }
    else if (sal_strncmp(argv[0], "aclqos-discard", sal_strlen("aclqos-discard")) == 0)
    {
        discard_type = IPE_DISCARD_ACLQOS_DISCARD_PKT;      /*17*/
    }
    else if (sal_strncmp(argv[0], "routing-mcast-ip-addr-discard", sal_strlen("routing-mcast-ip-addr-discard")) == 0)
    {
        discard_type = IPE_DISCARD_ROUTING_MCAST_IP_ADDR_CHK_DISCARD;    /*18*/
    }
    else if (sal_strncmp(argv[0], "brg-bpdu-etc", sal_strlen("brg-bpdu-etc")) == 0)
    {
        discard_type = IPE_DISCARD_BRG_BPDU_ETC_DISCARD;            /*19*/
    }
    else if (sal_strncmp(argv[0], "storm-ctl-discard", sal_strlen("storm-ctl-discard")) == 0)
    {
        discard_type = IPE_DISCARD_STORM_CTL_DISCARD;               /*20*/
    }
    else if (sal_strncmp(argv[0], "learning-discard", sal_strlen("learning-discard")) == 0)
    {
        discard_type = IPE_DISCARD_LEARNING_DISCARD;       /*21*/
    }
    else if (sal_strncmp(argv[0], "policing-discard", sal_strlen("policing-discard")) == 0)
    {
        discard_type = IPE_DISCARD_POLICING_DISCARD;       /*22*/
    }
    else if (sal_strncmp(argv[0], "fwd-ptr-invalid", sal_strlen("fwd-ptr-invalid")) == 0)
    {
        discard_type = IPE_DISCARD_NO_FWD_PTR_DISCARD;     /*23*/
    }
    else if (sal_strncmp(argv[0], "discard-fwd-ptr", sal_strlen("discard-fwd-ptr")) == 0)
    {
        discard_type = IPE_DISCARD_FWD_PTR_ALL_F_OR_VALID_DISCARD;     /*24*/
    }
    else if (sal_strncmp(argv[0], "fatal-excp-discard", sal_strlen("fatal-excp-discard")) == 0)
    {
        discard_type = IPE_DISCARD_FATAL_EXCEPTION_DSCD;    /*25*/
    }
    else if (sal_strncmp(argv[0], "aps-discard", sal_strlen("aps-discard")) == 0)
    {
        discard_type = IPE_DISCARD_APS_DISCARD;            /*26*/
    }
    else if (sal_strncmp(argv[0], "fwd-destid-discard", sal_strlen("fwd-destid-discard")) == 0)
    {
        discard_type = IPE_DISCARD_FWD_DEST_ID_DISCARD;     /*27*/
    }
    else if (sal_strncmp(argv[0], "hdr-adj-small-pkt", sal_strlen("hdr-adj-small-pkt")) == 0)
    {
        discard_type = IPE_DISCARD_HDR_AJUST_SMALL_PKT_DISCARD;     /*29*/
    }
    else if (sal_strncmp(argv[0], "hdr-adj-error", sal_strlen("hdr-adj-error")) == 0)
    {
        discard_type = IPE_DISCARD_HDR_ADJUST_PKT_ERR;       /*30*/
    }
    else if (sal_strncmp(argv[0], "trill-esadi-discard", sal_strlen("trill-esadi-discard")) == 0)
    {
        discard_type = IPE_DISCARD_TRILL_ESADI_PKT_DISCARD;       /*31*/
    }
    else if (sal_strncmp(argv[0], "loopback-discard", sal_strlen("loopback-discard")) == 0)
    {
        discard_type = IPE_DISCARD_LOOPBACK_DISCARD;       /*31*/
    }
    else if (sal_strncmp(argv[0], "efm-discard", sal_strlen("efm-discard")) == 0)
    {
        discard_type = IPE_DISCARD_EFM_DISCARD;              /*33*/
    }
    else if (sal_strncmp(argv[0], "capwap-from-ac-error-or-unexpectable", sal_strlen("capwap-from-ac-error-or-unexpectable")) == 0)
    {
        discard_type = IPE_DISCARD_CAPWAP_FROM_AC_ERR_OR_UNEXPECTABLE;     /*34*/
    }
    else if (sal_strncmp(argv[0], "stacking-networking-header-error", sal_strlen("stacking-networking-header-error")) == 0)
    {
        discard_type = IPE_DISCARD_STACKING_NETWORK_HEADER_CHK_ERR;       /*35*/
    }
    else if (sal_strncmp(argv[0], "trill-discard", sal_strlen("trill-discard")) == 0)
    {
        discard_type = IPE_DISCARD_TRILL_FILTER_ERR;              /*36*/
    }
    else if (sal_strncmp(argv[0], "capwap-control-excep", sal_strlen("capwap-control-excep")) == 0)
    {
        discard_type = IPE_DISCARD_CAPWAP_CONTROL_EXCEPTION;     /*37*/
    }
    else if (sal_strncmp(argv[0], "layer3-excep", sal_strlen("layer3-excep")) == 0)
    {
        discard_type = IPE_DISCARD_L3_EXCEPTION;                /*38*/
    }
    else if (sal_strncmp(argv[0], "layer2-excep", sal_strlen("layer2-excep")) == 0)
    {
        discard_type = IPE_DISCARD_L2_EXCEPTION;                /*39*/
    }
    else if (sal_strncmp(argv[0], "trill-mcast-addr-check-error", sal_strlen("trill-mcast-addr-check-error")) == 0)
    {
        discard_type = IPE_DISCARD_TRILL_MCAST_ADDR_CHK_ERR;   /*40*/
    }
    else if (sal_strncmp(argv[0], "trill-version-check-error", sal_strlen("trill-version-check-error")) == 0)
    {
        discard_type = IPE_DISCARD_TRILL_VERSION_CHK_ERR;     /*41*/
    }
    else if (sal_strncmp(argv[0], "ptp-version-check-error", sal_strlen("ptp-version-check-error")) == 0)
    {
        discard_type = IPE_DISCARD_PTP_VERSION_CHK_ERR;       /*42*/
    }
    else if (sal_strncmp(argv[0], "ptptp2p-trans-clock-delay", sal_strlen("ptptp2p-trans-clock-delay")) == 0)
    {
        discard_type = IPE_DISCARD_PTPT_P2P_TRANS_CLOCK_DELAY_DISCARD;    /*43*/
    }
    else if (sal_strncmp(argv[0], "oam-not-found", sal_strlen("oam-not-found")) == 0)
    {
        discard_type = IPE_DISCARD_OAM_NOT_FOUND_DISCARD;                /*44*/
    }
    else if (sal_strncmp(argv[0], "oam-stp-vlan-filter", sal_strlen("oam-stp-vlan-filter")) == 0)
    {
        discard_type = IPE_DISCARD_OAM_STP_VLAN_FILTER_DISCARD;          /*45*/
    }
    else if (sal_strncmp(argv[0], "single-hop-bfd-ttl-discard", sal_strlen("single-hop-bfd-ttl-discard")) == 0)
    {
        discard_type = IPE_DISCARD_BFD_SINGLE_HOP_OAM_TTL_CHK_ERR;   /*46*/
    }
    else if (sal_strncmp(argv[0], "capwap-dtls", sal_strlen("capwap-dtls")) == 0)
    {
        discard_type = IPE_DISCARD_CAPWAP_DTLS_DISCARD;                  /*47*/
    }
    else if (sal_strncmp(argv[0], "no-mep-mip", sal_strlen("no-mep-mip")) == 0)
    {
        discard_type = IPE_DISCARD_NO_MEP_MIP_DISCARD;                   /*48*/
    }
    else if (sal_strncmp(argv[0], "oam-disable", sal_strlen("oam-disable")) == 0)
    {
        discard_type = IPE_DISCARD_OAM_DIS;                  /*49*/
    }
    else if (sal_strncmp(argv[0], "pbb-decap", sal_strlen("pbb-decap")) == 0)
    {
        discard_type = IPE_DISCARD_PBB_DECAP_DISCARD;                    /*50*/
    }
    else if (sal_strncmp(argv[0], "mpls-tmpls-oam", sal_strlen("mpls-tmpls-oam")) == 0)
    {
        discard_type = IPE_DISCARD_MPLS_TMPLS_OAM_DISCARD;               /*51*/
    }
    else if (sal_strncmp(argv[0], "mplstp-mcc-scc", sal_strlen("mplstp-mcc-scc")) == 0)
    {
        discard_type = IPE_DISCARD_MPLSTP_MCC_SCC_DISCARD;               /*52*/
    }
    else if (sal_strncmp(argv[0], "icmp-error", sal_strlen("icmp-error")) == 0)
    {
        discard_type = IPE_DISCARD_ICMP_ERR_MSG_DISCARD;                   /*53*/
    }
    else if (sal_strncmp(argv[0], "ptp-acl-excep", sal_strlen("ptp-acl-excep")) == 0)
    {
        discard_type = IPE_DISCARD_PTP_ACL_EXCEPTION;            /*54*/
    }
    else if (sal_strncmp(argv[0], "ether-service-oam", sal_strlen("ether-service-oam")) == 0)
    {
        discard_type = IPE_DISCARD_ETHER_SERVICE_OAM_DISCARD;            /*55*/
    }
    else if (sal_strncmp(argv[0], "link-oam", sal_strlen("link-oam")) == 0)
    {
        discard_type = IPE_DISCARD_LINK_OAM_DISCARD;                     /*56*/
    }
    else if (sal_strncmp(argv[0], "tunnel-outer-martian-addr", sal_strlen("tunnel-outer-martian-addr")) == 0)
    {
        discard_type = IPE_DISCARD_TUNNEL_DECAP_OUTER_MARTIAN_ADDR_DISCARD;    /*57*/
    }
    else if (sal_strncmp(argv[0], "capwap-bssid-lookup-or-logic-port-check-fail", sal_strlen("capwap-bssid-lookup-or-logic-port-check-fail")) == 0)
    {
        discard_type = IPE_DISCARD_CAPWAP_BSSID_LKP_OR_LOGIC_PORT_CHK_DISCARD;     /*58*/
    }
    else if (sal_strncmp(argv[0], "userid-dsfwdptr-all-f-discard", sal_strlen("userid-dsfwdptr-all-f-discard")) == 0)
    {
        discard_type = IPE_DISCARD_USER_ID_FWD_PTR_ALL_F_DISCARD; /*59*/
    }
    else if (sal_strncmp(argv[0], "capwap-fragment", sal_strlen("capwap-fragment")) == 0)
    {
        discard_type = IPE_DISCARD_CAPWAP_FRAGMEN_DISCARD;       /*60*/
    }
    else if (sal_strncmp(argv[0], "trill-rpf-fail", sal_strlen("trill-rpf-fail")) == 0)
    {
        discard_type = IPE_DISCARD_TRILL_RPF_CHK_FAIL;               /*61*/
    }
    else if (sal_strncmp(argv[0], "mux-port-error", sal_strlen("mux-port-error")) == 0)
    {
        discard_type = IPE_DISCARD_MUX_PORT_ERR;       /*62*/
    }
    else
    {
        discard_type = IPE_DISCARD_TYPE_MAX_NUM;                 /*63*/
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "chip-id", sal_strlen("chip-id"));
    if (index != 0xFF)
    {
        CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[index+1]);
        chip_id = 0;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "pkt-cnt", sal_strlen("pkt-cnt"));
    if (index != 0xFF)
    {
        is_pkt_cnt= TRUE;
        CTC_CLI_GET_INTEGER("pkt-cnt", expect_pkt_cnt, argv[index+1]);
        ret = sim_check_discard_type(chip_id, moduleid, discard_type, is_pkt_cnt, expect_pkt_cnt);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Fail to check ipe discard type!\n");
            return CLI_ERROR;
        }
        else
        {
            return CLI_SUCCESS;
        }
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "byte-cnt", sal_strlen("byte-cnt"));
    if (index != 0xFF)
    {
        is_pkt_cnt= FALSE;
        CTC_CLI_GET_INTEGER("byte-cnt", expect_byte_cnt, argv[index+1]);
        ret = sim_check_discard_type(chip_id, moduleid, discard_type, is_pkt_cnt, expect_byte_cnt);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Fail to check ipe discard type!\n");
            return CLI_ERROR;
        }
        else
        {
            return CLI_SUCCESS;
        }
    }

    ret = sim_check_discard_type(chip_id, moduleid, discard_type, TRUE, 1); /* default check packet counter = 1 */
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to check ipe discard type!\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

/* Cmd format: check epe discard-type <discard_type> */
CTC_CLI(cli_cmodel_sim_check_epe_discard_type,
    cli_cmodel_sim_check_epe_discard_type_cmd,
    "check epe discard-type ((epe_hdr_adj_pkt_error_discard | epe-hdr-adj-byte-remove-err | epe-hdr-adj-destid-discard \
    | epe-hdr-adj-pkt-err-discard | epe-hdr-adj-byte-remove-err | dest-phy-port-destid-discard | port-isolate-discard \
    | ds-vlan-transen-zero | brg-to-same-port | vpls-horizon-split | egress-vlan-filter | egress-stp-discard \
    | egress-parser-len-err-discard | egress-pbb-chk-discard | ucast-mcast-flood | 802-3-oam-discard | egress-ttl-failed-discard \
    | remote-mirror-escape-discard | tunnel-mtu-chk | interface-mtu-chk | logic-port-chk | egress-acl-discard \
    | egress-qos-discard | egress-policing-discard | crc-error-discard | route-payload-operation-discard \
    | brg-payload-operation-discard | strip-offset-over | bfd | port-reflective-chk-discard | ip-mpls-ttl-chk-err-discard \
    | oam-egde-port-discard | nat-pt-icmp-err-discard | l2-match-tx-oam-discard | oam-filtering-discard | oam-hash-confilict-discard \
    | ipda-equals-to-ipsa-discard | mpls-payload-operation-discard | trill-payload-operation-discard | epe-pbb-itag-check-fail-discard \
    | epe-ds-next-hop-data-violate | epe-dest-vlan-ptr-discard | epe-ds-l3-edit-data-violate-1 | epe-ds-l3-edit-data-violate-2 \
    | epe-ds-l3-edit-nat-data-violate | epe-ds-l2-edit-data-violate-1 | epe-ds-l2-edit-data-violate-2 | epe-packet-header-c2c-ttl-zero \
    | epe-pt-udp-checksum-is-zero | epe-oam-to-local-discard) \
    ({chip-id CHIP_ID |pkt-cnt PKT_CNT | byte-cnt BYTE_CNT}|))",
    "Cmodel cmd",
    "epe",
    "discardType",
    "epe-hdr-adj-destid-discard",
    "epe-hdr-adj-pkt-err-discard",
    "epe-hdr-adj-byte-remove-err",
    "dest-phy-port-destid-discard",
    "port-isolate-discard",
    "ds-vlan-transen-zero",
    "brg-to-same-port",
    "vpls-horizon-split",
    "egress-vlan-filter",
    "egress-stp-discard",
    "egress-parser-len-err-discard",
    "egress-pbb-chk-discard",
    "ucast-mcast-flood",
    "802-3-oam-discard",
    "egress-ttl-failed-discard",
    "remote-mirror-escape-discard",
    "tunnel-mtu-chk",
    "interface-mtu-chk",
    "logic-port-chk",
    "egress-acl-discard",
    "egress-qos-discard",
    "egress-policing-discard",
    "crc-error-discard",
    "route-payload-operation-discard",
    "brg-payload-operation-discard",
    "strip-offset-over",
    "bfd",
    "port-reflective-chk-discard",
    "ip-mpls-ttl-chk-err-discard",
    "oam-egde-port-discard",
    "nat-pt-icmp-err-discard",
    "l2-match-tx-oam-discard",
    "oam-filtering-discard",
    "oam-hash-confilict-discard",
    "ipda-equals-to-ipsa-discard",
    "mpls-payload-operation-discard",
    "trill-payload-operation-discard",
    "epe-pbb-itag-check-fail-discard",
    "epe-ds-next-hop-data-violate",
    "epe-dest-vlan-ptr-discard",
    "epe-ds-l3-edit-data-violate-1",
    "epe-ds-l3-edit-data-violate-2",
    "epe-ds-l3-edit-nat-data-violate",
    "epe-ds-l2-edit-data-violate-1",
    "epe-ds-l2-edit-data-violate-2",
    "epe-packet-header-c2c-ttl-zero",
    "epe-pt-udp-checksum-is-zero",
    "epe-oam-to-local-discard",
    "chip-id",
    "chip id value",
    "pkt-cnt",
    "pkt count value",
    "byte-cnt",
    "byte count value")
{
    int32 ret = DRV_E_NONE;
    uint32 discard_type = EPE_DISCARD_TYPE_MAX_NUM;
    uint32 moduleid = DISCARD_CHECK_EPE_MODULE;
    uint32 chip_id = 0;
    uint32 expect_pkt_cnt = 0, expect_byte_cnt = 0;  /* >32 bits process TBD??? */
    bool is_pkt_cnt = TRUE;
    uint32 index = 0;


    if(sal_strncmp(argv[0], "epe-hdr-adj-destid-discard", sal_strlen("epe-hdr-adj-destid-discard")) == 0)
    {
        discard_type = EPE_DISCARD_EPE_HDR_ADJ_DEST_ID_DISCARD;  /*0*/
    }
    else if (sal_strncmp(argv[0], "epe-hdr-adj-pkt-err-discard", sal_strlen("epe-hdr-adj-pkt-err-discard")) == 0)
    {
        discard_type = EPE_DISCARD_EPE_HDR_ADJ_PKT_ERR_DISCARD; /*1*/
    }
    else if (sal_strncmp(argv[0], "epe-hdr-adj-byte-remove-err", sal_strlen("epe-hdr-adj-byte-remove-err")) == 0)
    {
        discard_type = EPE_DISCARD_EPE_HDR_ADJ_BYTE_REMOVE_ERR;  /*2*/
    }
    else if (sal_strncmp(argv[0], "dest-phy-port-destid-discard", sal_strlen("dest-phy-port-destid-discard")) == 0)
    {
        discard_type = EPE_DISCARD_DEST_PHY_PORT_DEST_ID_DISCARD;  /*3*/
    }
    else if (sal_strncmp(argv[0], "port-isolate-discard", sal_strlen("port-isolate-discard")) == 0)
    {
        discard_type = EPE_DISCARD_PORT_ISOLATE_DISCARD;                  /*4*/
    }
    else if (sal_strncmp(argv[0], "ds-vlan-transen-zero", sal_strlen("ds-vlan-transen-zero")) == 0)
    {
        discard_type = EPE_DISCARD_DS_VLAN_TRANS_DIS;              /*5*/
    }
    else if (sal_strncmp(argv[0], "brg-to-same-port", sal_strlen("brg-to-same-port")) == 0)
    {
        discard_type = EPE_DISCARD_BRG_TO_SAME_PORT_DISCARD;              /*6*/
    }
    else if (sal_strncmp(argv[0], "vpls-horizon-split", sal_strlen("vpls-horizon-split")) == 0)
    {
        discard_type = EPE_DISCARD_VPLS_HORIZON_SPLIT_DISCARD;                /*7*/
    }
    else if (sal_strncmp(argv[0], "egress-vlan-filter", sal_strlen("egress-vlan-filter")) == 0)
    {
        discard_type = EPE_DISCARD_EGRESS_VLAN_FILTER_DISCARD;               /*8*/
    }
    else if (sal_strncmp(argv[0], "egress-stp-discard", sal_strlen("egress-stp-discard")) == 0)
    {
        discard_type = EPE_DISCARD_EGRESS_STP_DISCARD;               /*9*/
    }
    else if (sal_strncmp(argv[0], "egress-parser-len-err-discard", sal_strlen("egress-parser-len-err-discard")) == 0)
    {
        discard_type = EPE_DISCARD_EGRESS_PARSER_LEN_ERR_DISCARD;                /*10*/
    }
    else if (sal_strncmp(argv[0], "egress-pbb-chk-discard", sal_strlen("egress-pbb-chk-discard")) == 0)
    {
        discard_type = EPE_DISCARD_EGRESS_PBB_CHK_DISCARD;    /*11*/
    }
    else if (sal_strncmp(argv[0], "ucast-mcast-flood", sal_strlen("ucast-mcast-flood")) == 0)
    {
        discard_type = EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD;               /*12*/
    }
    else if (sal_strncmp(argv[0], "802-3-oam-discard", sal_strlen("802-3-oam-discard")) == 0)
    {
        discard_type = EPE_DISCARD_802_3_OAM_DISCARD;             /*13*/
    }
    else if (sal_strncmp(argv[0], "egress-ttl-failed-discard", sal_strlen("egress-ttl-failed-discard")) == 0)
    {
        discard_type = EPE_DISCARD_EGRESS_TTL_FAIL;           /*14*/
    }
    else if (sal_strncmp(argv[0], "remote-mirror-escape-discard", sal_strlen("remote-mirror-escape-discard")) == 0)
    {
        discard_type = EPE_DISCARD_REMOTE_MIRROR_ESCAPE_DISCARD;           /*15*/
    }
    else if (sal_strncmp(argv[0], "tunnel-mtu-chk", sal_strlen("tunnel-mtu-chk")) == 0)
    {
        discard_type = EPE_DISCARD_TUNNEL_MTU_CHK_DISCARD;   /*16*/
    }
    else if (sal_strncmp(argv[0], "interface-mtu-chk", sal_strlen("interface-mtu-chk")) == 0)
    {
        discard_type = EPE_DISCARD_INTERFACE_MTU_CHK_DISCARD;    /*17*/
    }
    else if (sal_strncmp(argv[0], "logic-port-chk", sal_strlen("logic-port-chk")) == 0)
    {
        discard_type = EPE_DISCARD_LOGIC_PORT_CHK_DISCARD;      /*18*/
    }
    else if (sal_strncmp(argv[0], "egress-acl-discard", sal_strlen("egress-acl-discard")) == 0)
    {
        discard_type = EPE_DISCARD_EGRESS_ACL_DISCARD;    /*19*/
    }
    else if (sal_strncmp(argv[0], "egress-qos-discard", sal_strlen("egress-qos-discard")) == 0)
    {
        discard_type = EPE_DISCARD_EGRESS_QOS_DISCARD;            /*20*/
    }
    else if (sal_strncmp(argv[0], "egress-policing-discard", sal_strlen("egress-policing-discard")) == 0)
    {
        discard_type = EPE_DISCARD_EGRESS_POLICING_DISCARD;               /*21*/
    }
    else if (sal_strncmp(argv[0], "crc-error-discard", sal_strlen("crc-error-discard")) == 0)
    {
        discard_type = EPE_DISCARD_CRC_ERR;       /*22*/
    }
    else if (sal_strncmp(argv[0], "route-payload-operation-discard", sal_strlen("route-payload-operation-discard")) == 0)
    {
        discard_type = EPE_DISCARD_ROUTE_PAYLOAD_OPERATION_DISCARD;       /*23*/
    }
    else if (sal_strncmp(argv[0], "brg-payload-operation-discard", sal_strlen("brg-payload-operation-discard")) == 0)
    {
        discard_type = EPE_DISCARD_BRG_PAYLOAD_OPERATION_DISCARD;     /*24*/
    }
    else if (sal_strncmp(argv[0], "strip-offset-over", sal_strlen("strip-offset-over")) == 0)
    {
        discard_type = EPE_DISCARD_PT_LAYER4_OFFSET_LAGER_DISCARD;     /*25*/
    }
    else if (sal_strncmp(argv[0], "bfd", sal_strlen("bfd")) == 0)
    {
        discard_type = EPE_DISCARD_BFD_DISCARD;    /*26*/
    }
    else if (sal_strncmp(argv[0], "port-reflective-chk-discard", sal_strlen("port-reflective-chk-discard")) == 0)
    {
        discard_type = EPE_DISCARD_PORT_REFLECTIVE_CHK_DISCARD;    /*27*/
    }
    else if (sal_strncmp(argv[0], "ip-mpls-ttl-chk-err-discard", sal_strlen("ip-mpls-ttl-chk-err-discard")) == 0)
    {
        discard_type = EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD;    /*28*/
    }
    else if (sal_strncmp(argv[0], "oam-egde-port-discard", sal_strlen("oam-egde-port-discard")) == 0)
    {
        discard_type = EPE_DISCARD_OAM_EGDE_PORT_DISCARD;    /*29*/
    }
    else if (sal_strncmp(argv[0], "nat-pt-icmp-err-discard", sal_strlen("nat-pt-icmp-err-discard")) == 0)
    {
        discard_type = EPE_DISCARD_NAT_PT_ICMP_ERR;    /*30*/
    }
    else if (sal_strncmp(argv[0], "l2-match-tx-oam-discard", sal_strlen("l2-match-tx-oam-discard")) == 0)
    {
        discard_type = EPE_DISCARD_LOCAL_OAM_DISCARD;    /*32*/
    }
    else if (sal_strncmp(argv[0], "oam-filtering-discard", sal_strlen("oam-filtering-discard")) == 0)
    {
        discard_type = EPE_DISCARD_OAM_FILTERING_DISCARD;    /*33*/
    }
    else if (sal_strncmp(argv[0], "oam-hash-confilict-discard", sal_strlen("oam-hash-confilict-discard")) == 0)
    {
        discard_type = EPE_DISCARD_OAM_HASH_CONFILICT_DISCARD;    /*34*/
    }
    else if (sal_strncmp(argv[0], "ipda-equals-to-ipsa-discard", sal_strlen("ipda-equals-to-ipsa-discard")) == 0)
    {
        discard_type = EPE_DISCARD_IPDA_EQUALS_TO_IPSA_DISCARD;    /*35*/
    }
    else if (sal_strncmp(argv[0], "trill-payload-operation-discard", sal_strlen("trill-payload-operation-discard")) == 0)
    {
        discard_type = EPE_DISCARD_TRILL_PAYLOAD_OPERATION_DISCARD;    /*37*/
    }
    else if (sal_strncmp(argv[0], "epe-pbb-itag-check-fail-discard", sal_strlen("epe-pbb-itag-check-fail-discard")) == 0)
    {
        discard_type = EPE_DISCARD_PBB_CHK_FAIL_DISCARD;    /*38*/
    }
    else if (sal_strncmp(argv[0], "epe-ds-next-hop-data-violate", sal_strlen("epe-ds-next-hop-data-violate")) == 0)
    {
        discard_type = EPE_DISCARD_DS_NEXT_HOP_DATA_VIOLATE;    /*39*/
    }
    else if (sal_strncmp(argv[0], "epe-dest-vlan-ptr-discard", sal_strlen("epe-dest-vlan-ptr-discard")) == 0)
    {
        discard_type = EPE_DISCARD_DEST_VLAN_PTR_DISCARD;    /*40*/
    }
    else if (sal_strncmp(argv[0], "epe-ds-l3-edit-data-violate-1", sal_strlen("epe-ds-l3-edit-data-violate-1")) == 0)
    {
        discard_type = EPE_DISCARD_DS_L3_EDIT_DATA_VIOLATE_1;    /*41*/
    }
    else if (sal_strncmp(argv[0], "epe-ds-l3-edit-data-violate-2", sal_strlen("epe-ds-l3-edit-data-violate-2")) == 0)
    {
        discard_type = EPE_DISCARD_DS_L3_EDIT_DATA_VIOLATE_2;    /*42*/
    }
    else if (sal_strncmp(argv[0], "epe-ds-l3-edit-nat-data-violate", sal_strlen("epe-ds-l3-edit-nat-data-violate")) == 0)
    {
        discard_type = EPE_DISCARD_DS_L3_EDIT_NAT_DATA_VIOLATE;    /*43*/
    }
    else if (sal_strncmp(argv[0], "epe-ds-l2-edit-data-violate-1", sal_strlen("epe-ds-l2-edit-data-violate-1")) == 0)
    {
        discard_type = EPE_DISCARD_DS_L2_EDIT_DATA_VIOLATE_1;    /*44*/
    }
    else if (sal_strncmp(argv[0], "epe-ds-l2-edit-data-violate-2", sal_strlen("epe-ds-l2-edit-data-violate-2")) == 0)
    {
        discard_type = EPE_DISCARD_DS_L2_EDIT_DATA_VIOLATE_2;    /*45*/
    }
    else if (sal_strncmp(argv[0], "epe-packet-header-c2c-ttl-zero", sal_strlen("epe-packet-header-c2c-ttl-zero")) == 0)
    {
        discard_type = EPE_DISCARD_PACKET_HEADER_C2C_TTL_ZERO;    /*46*/
    }
    else if (sal_strncmp(argv[0], "epe-pt-udp-checksum-is-zero", sal_strlen("epe-pt-udp-checksum-is-zero")) == 0)
    {
        discard_type = EPE_DISCARD_PT_UDP_CHECKSUM_IS_ZERO;    /*47*/
    }
    else if (sal_strncmp(argv[0], "epe-oam-to-local-discard", sal_strlen("epe-oam-to-local-discard")) == 0)
    {
        discard_type = EPE_DISCARD_OAM_TO_LOCAL_DISCARD;    /*48*/
    }
    else
    {
        discard_type = EPE_DISCARD_TYPE_MAX_NUM;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "chip-id", sal_strlen("chip-id"));
    if (index != 0xFF)
    {
        CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[index+1]);
        chip_id = 0;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "pkt-cnt", sal_strlen("pkt-cnt"));
    if (index != 0xFF)
    {
        is_pkt_cnt= TRUE;
        CTC_CLI_GET_INTEGER("pkt-cnt", expect_pkt_cnt, argv[index+1]);
        ret = sim_check_discard_type(chip_id, moduleid, discard_type, is_pkt_cnt, expect_pkt_cnt);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Fail to check ipe discard type!\n");
            return CLI_ERROR;
        }
        else
        {
            return CLI_SUCCESS;
        }
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "byte-cnt", sal_strlen("byte-cnt"));
    if (index != 0xFF)
    {
        is_pkt_cnt= FALSE;
        CTC_CLI_GET_INTEGER("byte-cnt", expect_byte_cnt, argv[index+1]);
        ret = sim_check_discard_type(chip_id, moduleid, discard_type, is_pkt_cnt, expect_byte_cnt);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Fail to check ipe discard type!\n");
            return CLI_ERROR;
        }
        else
        {
            return CLI_SUCCESS;
        }
    }

    ret = sim_check_discard_type(chip_id, moduleid, discard_type, TRUE, 1); /* default check packet counter = 1 */
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to check ipe discard type!\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

/* Cmd format: creat check no-any-discard result-file DISCARD_CHECK_RESULT_FILE */
CTC_CLI(cli_cmodel_sim_check_no_any_discard_rslt_file,
    cli_cmodel_sim_check_no_any_discard_rslt_file_cmd,
    "creat check no-any-discard result-file DISCARD_CHECK_RESULT_FILE",
    "Cmodel cmd",
    "check",
    "no-any-discard",
    "result-file",
    "Check result file name")
{
    int32 ret = DRV_E_NONE;
    char *file_name = NULL;

    file_name = argv[0];

    ret = sim_creat_check_no_any_discard_result_file(file_name);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to creat check all discard type result file\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

CTC_CLI(cli_cmodel_sim_check_no_any_discard_type,
    cli_cmodel_sim_check_no_any_discard_type_cmd,
    "check ( CHIP_ID |) no-any-discard ",
    "Cmodel cmd",
    "chip id value",
    "no-any-discard")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;

    if (argc != 0)
    {
        CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
        chip_id = 0;
    }
    ret = sim_check_all_discard_type_is_null(chip_id);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to check all discard type!\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

CTC_CLI(cli_cmodel_sim_chk_learning_cache_is_null_rslt_file,
    cli_cmodel_sim_chk_learning_cache_is_null_rslt_file_cmd,
    "creat check learning-table-is-null result-file DISCARD_CHECK_RESULT_FILE",
    "Cmodel cmd",
    "check",
    "learning-table-is-null",
    "result-file",
    "Check result file name")
{
    int32 ret = DRV_E_NONE;
    char *file_name = NULL;

    file_name = argv[0];

    ret = sim_check_table_is_null_result_file(file_name);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Fail to creat check learning tbl is null result file\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

/* Cmd format: check learning-cache is-null */
CTC_CLI(cli_cmodel_sim_chk_learning_cache_is_null,
    cli_cmodel_sim_chk_learning_cache_is_null_cmd,
    "check (CHIP_ID|) learning-cache is-null",
    "Cmodel cmd",
    "chip id value"
    "learning-cache",
    "is-null")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;

    if (argc != 0)
    {
        CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
        chip_id = 0;
    }

    ret = sim_check_table_is_null(chip_id, IpeLearningCacheValid_t);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Failed to check IpeLearningCacheValid table is NULL!\n");
        return CLI_ERROR;
    }

    ret = sim_check_table_is_null(chip_id, IpeLearningCache_t);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Failed to check IpeLearningCache table is NULL!\n");
        return CLI_ERROR;
    }

    ret = sim_flush_table(chip_id, IpeLearningCache_t);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Failed to flush IpeLearningCache table is NULL!\n");
        return CLI_ERROR;
    }

    ret = sim_flush_table(chip_id, IpeLearningCacheValid_t);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Failed to flush IpeLearningCacheValid table is NULL!\n");
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

/* Cmd format: cmodel store-config (on|off) */
/* control whether store cfg or not during running case on UML(for example runing GCOV) */
CTC_CLI(cli_cmodel_sim_model_store_on,
        cli_cmodel_sim_model_store_on_cmd,
        "cmodel store-config (on | off)",
        "cmodel config store on or off cmd",
        "config store control function",
        "cmodel store-config on",
        "cmodel store-config off")
{
#if (SDK_WORK_PLATFORM==1)
    if(0 == sal_memcmp(argv[0], "on", 2))
    {
        cmodel_store_cfg_on = TRUE;
    }
    else if(0 == sal_memcmp(argv[0], "off", 3))
    {
        cmodel_store_cfg_on = FALSE;
    }
#endif
    return CLI_SUCCESS;
}

/* Cmd format: store asic-config <cfg_file_name> */
CTC_CLI(cli_cmodel_sim_model_store_asic_cfg,
        cli_cmodel_sim_model_store_asic_cfg_cmd,
        "store asic-config ASIC_CFG_FILE_NAME",
        "Cmodel cmd",
        "Store the dumped asic config cmd",
        "Store cfg file name")
{
#if (SDK_WORK_PLATFORM == 1)
    int32 ret = DRV_E_NONE;
    char *file_name = NULL;

    if (cmodel_store_cfg_on)
    {
        file_name = argv[0];

        ret = sim_model_sram_mem_dump(file_name);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Store asic sram configuration error\n");
            return CLI_ERROR;
        }
        else
        {
            return CLI_SUCCESS;
        }
    }
    else
    {
        return CLI_SUCCESS;
    }
#else
    return CLI_SUCCESS;
#endif
}

/* Cmd format: store tcam-config <tcam_cfg_file_name> */
CTC_CLI(cli_cmodel_sim_model_store_tcam_cfg,
        cli_cmodel_sim_model_store_tcam_cfg_cmd,
        "store tcam-config TCAM_CFG_FILE_NAME",
        "Cmodel cmd",
        "Store the dumped tcam config cmd",
        "Tcam cfg store file name")
{
#if (SDK_WORK_PLATFORM == 1)
    int32 ret = DRV_E_NONE;
    char *file_name = NULL;

    if (cmodel_store_cfg_on)
    {
        file_name = argv[0];

        ret = sim_model_tcam_mem_dump(file_name);
        if (ret < DRV_E_NONE)
        {
            ctc_cli_out("%% Error! Store tcam configuration error\n");
            return CLI_ERROR;
        }
        else
        {
            return CLI_SUCCESS;
        }
    }
    else
    {
        return CLI_SUCCESS;
    }
#else
    return CLI_SUCCESS;
#endif
}

/* Cmd format: file tbl-chk-rslt <result_file_name> */
CTC_CLI(cli_cmodel_sim_chk_tbl_rslt_file,
    cli_cmodel_sim_chk_tbl_rslt_file_cmd,
    "file tbl-chk-rslt CHECK_RESULT_FILE",
    "Cmodel cmd",
    "Creat Table value check result file cmd",
    "Store check result's file name")
{
    int32 ret = DRV_E_NONE;
    char *file_name = NULL;

    file_name = argv[0];

    ret = sim_chk_tbl_rslt_file(file_name);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Error! Store tcam configuration error\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

CTC_CLI(cli_cmodel_lpm_update,
    cli_cmodel_lpm_update_cmd,
    "lpm update chip-id CHIP_ID old-pointer OLD_POINTER new-pointer NEW_POINTER add ADD ip IP mask MASK type TYPE nexthop-pointer NEXTHOP test-mask-start-index TEST_MASK_START_INDEX old-entry-number OLD_ENTRY_NUMBER",
    "Cmodel cmd",
    "update LPM prefix entry",
    "chip id",
    "chip id value",
    "old pointer",
    "old pointer value",
    "new pointer",
    "new pointer value",
    "add",
    "add 1, remove 0",
    "ip",
    "ip value",
    "mask",
    "mask value",
    "LPM node type",
    "0:nexthop or 1:pointer",
    "nexthop-pointer",
    "nexthop or pointer value",
    "test-mask-start-index",
    "test-mask-start-index value",
    "old entry number",
    "old ds_lpm_lookup_key counter")
{
    uint8   chip_id = 0;
    ds_lpm_request_t  ds_lpm_request;
    int32 ret = DRV_E_NONE;

    sal_memset(&ds_lpm_request, 0, sizeof(ds_lpm_request));

    CTC_CLI_GET_INTEGER("chip_id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("old_pointer", ds_lpm_request.old_pointer, argv[1]);
    CTC_CLI_GET_INTEGER("new_pointer", ds_lpm_request.new_pointer, argv[2]);
    CTC_CLI_GET_INTEGER("add", ds_lpm_request.add, argv[3]);
    CTC_CLI_GET_INTEGER("ip", ds_lpm_request.ip, argv[4]);
    CTC_CLI_GET_INTEGER("mask", ds_lpm_request.mask, argv[5]);
    CTC_CLI_GET_INTEGER("type", ds_lpm_request.type, argv[6]);
    CTC_CLI_GET_INTEGER("nexthop-pointer", ds_lpm_request.nexthop, argv[7]);
    CTC_CLI_GET_INTEGER("test-mask-start-index", ds_lpm_request.test_mask_start_index, argv[8]);
    CTC_CLI_GET_INTEGER("old-entry-number", ds_lpm_request.old_entry_number, argv[9]);

    ret = cm_sim_cfg_kit_update_lpm_prefix_table(chip_id, &ds_lpm_request);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

/* Cmd format: tblcheck <chip_id> <tbl_name> <index> <field_name> <expect_value> */
CTC_CLI(cli_cmodel_sim_chk_tbl_field_value,
    cli_cmodel_sim_chk_tbl_field_value_cmd,
    "tblcheck CHIP_ID TABLE_NAME TABLE_IDX FIELD_NAME EXPECT_VALUE",
    "Cmodel cmd",
    "Chip_id",
    "Table name",
    "Table's index",
    "Field name",
    "Expect value")
{
    uint32 chip_id = 0;
    uint32 tbl_id = 0, fld_id = 0;
    uint32 tbl_idx = 0;
    uint32 real_value = 0, expect_value = 0;
    char  *tbl_name = NULL, *fld_name = NULL;
    uint32 cmd = 0;
    int32 ret = DRV_E_NONE;
    bool succ_flag = FALSE;

    CTC_CLI_GET_INTEGER("chip_id", chip_id, argv[0]);
    chip_id = 0;
    tbl_name = argv[1];
    CTC_CLI_GET_INTEGER("tbl_idx", tbl_idx, argv[2]);
    fld_name = argv[3];
    CTC_CLI_GET_INTEGER("expect_value", expect_value, argv[4]);

    ret = drv_get_tbl_id_by_string(&tbl_id, tbl_name);
    if (DRV_E_NONE != ret)
    {
        ctc_cli_out("%% Fail to search tbl_name = %s, ret = 0x%08x\n", tbl_name, tbl_id);
        goto RELEASE;
    }

    ret = drv_get_field_id_by_string(tbl_id, &fld_id, fld_name);
    if (DRV_E_NONE != ret)
    {
        ctc_cli_out("%% Fail to search table field_name = %s, ret = 0x%08x\n",  fld_name, fld_id);
        goto RELEASE;
    }

    if (tbl_id == IpeLearningCache_t)
    {
        tbl_idx = IPE_LEARNING_CACHE_MAX_INDEX - 1 - tbl_idx;
    }

    if ((tbl_id == IpeLearningCacheValid_t) && (fld_id == IpeLearningCacheValid_LearningEntryValid_f))
    {
        uint16 expect_value_tmp = expect_value;
        uint32 i = 0;
        for (i = 0; i < IPE_LEARNING_CACHE_MAX_INDEX; i++)
        {
            if (IS_BIT_SET(expect_value_tmp, i))
            {
                SET_BIT(expect_value, IPE_LEARNING_CACHE_MAX_INDEX-i-1);
            }
            else
            {
                CLEAR_BIT(expect_value, IPE_LEARNING_CACHE_MAX_INDEX-i-1);
            }
        }
    }

    cmd = DRV_IOR(tbl_id, fld_id);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, tbl_idx, cmd, &real_value));

    if (real_value == expect_value)
    {
        CMODEL_DEBUG_OUT_INFO("\n==================== TBL CHECK PASS! =================");
        CMODEL_DEBUG_OUT_INFO("\nGet and expect value is both 0x%x", real_value);
        CMODEL_DEBUG_OUT_INFO("\n===================================================\n");
        CMODEL_DEBUG_OUT_INFO("PASSED! Check tblcheck Passed\n");
        succ_flag = TRUE;
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("\n************************* TBL CHECK FAILED!! ***********************");
        CMODEL_DEBUG_OUT_INFO("\nTable name:%s", tbl_name);
        CMODEL_DEBUG_OUT_INFO("\nField name:%s", fld_name);
        CMODEL_DEBUG_OUT_INFO("\nReal Value:0x%-16xExpect Value:0x%-16x", real_value, expect_value);
        CMODEL_DEBUG_OUT_INFO("\n*******************************************************************\n");
        CMODEL_DEBUG_OUT_INFO("FAILED! Check tblcheck failed\n");
        succ_flag = FALSE;
    }

RELEASE:
#if (SDK_WORK_PLATFORM == 1)
    ret = sim_store_chk_tbl_result(&succ_flag);
#endif

    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Failed to Check Table filed value!\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}


/* Cmd format: load topo-file <topo_file> */
CTC_CLI(cli_cmodel_swemu_environment_setting,
    cli_cmodel_swemu_environment_setting_cmd,
    "load topo-file TOPO_FILE",
    "cmodel cmd",
    "Read cmodel test topo file",
    "Topo file")
{
    int32 ret = DRV_E_NONE;
    char *topo_filename = NULL;

    topo_filename = argv[0];
    ret = swemu_environment_setting(topo_filename);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Failed to Read cmodel test topo file!\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

extern int32
cm_oam_update_ccm_timer(uint32 chip_id, uint32 min_ptr, uint32 max_ptr, uint32 update_times);

CTC_CLI(cli_cmodel_oam_update_ccm_timer,
    cli_cmodel_oam_update_ccm_timer_cmd,
    "oam update CHIP_ID MIN_PTR MAX_PTR UPDATE_TIMES",
    "Cmodel cmd",
    "Update oam status",
    "Chip id",
    "Min ptr",
    "Max ptr"
    "update time count")
{
    uint32 chip_id = 0;
    uint32 cmd = 0;
    uint32 update_en = 1;
    chip_id     = (uint32)atoll(argv[0]);
    chip_id = 0;
    cmd = DRV_IOW(OamUpdateCtl_t, OamUpdateCtl_UpdEn_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &update_en));
#if (SDK_WORK_PLATFORM == 1)
    int32 ret = DRV_E_NONE;
    uint32 upd_min_ptr = 0;
    uint32 upd_max_ptr = 0;
    uint32 upd_times = 1;

    upd_min_ptr = (uint32)atoll(argv[1]);
    upd_max_ptr = (uint32)atoll(argv[2]);
    upd_times   = (uint32)atoll(argv[3]);

    cmd = DRV_IOW(OamUpdateCtl_t, OamUpdateCtl_CcmMinPtr_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &upd_min_ptr));

    cmd = DRV_IOW(OamUpdateCtl_t, OamUpdateCtl_OamUpPhyNum_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &upd_max_ptr));

    cmd = DRV_IOW(OamUpdateCtl_t, OamUpdateCtl_CcmMaxPtr_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &upd_max_ptr));

    ret = cm_oam_update_ccm_timer(chip_id, upd_min_ptr, upd_max_ptr, upd_times);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
#endif
    return CLI_SUCCESS;
}

extern int32
cm_oam_scan_defect_timer(uint32 chip_id, uint32 scan_times);
CTC_CLI(cli_cmodel_oam_update_scan_defect_timer,
    cli_cmodel_oam_update_scan_defect_timer_cmd,
    "oam scan-defect CHIP_ID UPDATE_TIMES",
    "Cmodel cmd",
    "Update oam scan defect timer",
    "Chip id",
    "update times count")
{
#if (SDK_WORK_PLATFORM == 1)
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 upd_times = 0;

    chip_id     = (uint32)atoll(argv[0]);
    chip_id = 0;
    upd_times   = (uint32)atoll(argv[1]);

    ret = cm_oam_scan_defect_timer(chip_id, upd_times);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
#endif
    return CLI_SUCCESS;
}

extern int32
cm_oam_auto_gen_pkt_tick_update(uint32 chip_id, uint32 update_times);
CTC_CLI(cli_cmodel_oam_update_auto_gen_pkt_timer,
    cli_cmodel_oam_update_auto_gen_pkt_timer_cmd,
    "oam auto-gen-pkt CHIP_ID UPDATE_TIMES",
    "Cmodel cmd",
    "Update oam auto gen timer",
    "Chip id",
    "update times count")
{
    uint32 chip_id = 0;
    uint32 upd_times = 0;
    uint32 cmd = 0;
    uint32 tick_gen_en = 0;

    chip_id     = (uint32)atoll(argv[0]);
    chip_id = 0;
    upd_times   = (uint32)atoll(argv[1]);

    tick_gen_en = 1;
    cmd = DRV_IOW(AutoGenPktCtl_t, AutoGenPktCtl_TickGenEn_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &tick_gen_en));
#if (SDK_WORK_PLATFORM == 1)
    int32 ret = DRV_E_NONE;
    ret = cm_oam_auto_gen_pkt_tick_update(chip_id, upd_times);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
#endif
    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_oam_auto_gen_pkt_enable,
    cli_cmodel_oam_auto_gen_pkt_enable_cmd,
    "oam auto-gen-pkt-enable CHIP_ID (1|2|3|4)",
    "Cmodel cmd",
    "Set oam auto gen enable",
    "Chip id",
    "Set session number")
{
    uint32 chip_id = 0;
    uint8 session_num = 0;
    uint8 i = 0;
    uint32 cmd = 0;
    auto_gen_pkt_ctl_t auto_gen_pkt_ctl;

    chip_id = (uint32)atoll(argv[0]);
    chip_id = 0;
    session_num = (uint32)atoll(argv[1]);

    cmd = DRV_IOR(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));
    for(i = 0 ; i < session_num ; i++)
    {
        SET_BIT(auto_gen_pkt_ctl.auto_gen_en, i);
    }
    auto_gen_pkt_ctl.tick_gen_en = 1;
    cmd = DRV_IOW(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));

    return DRV_E_NONE;
}


CTC_CLI(cli_cmodel_oam_auto_gen_pkt_set_packet_header,
    cli_cmodel_oam_auto_gen_pkt_set_packet_header_cmd,
    "oam auto-gen-pkt-set-config CHIP_ID PACKET_SIZE (0|1|2|3|full) (LBM|TST|DATA) TX_PKT_CNT PATTERN_TYPE \
    ({first-session-port PORT0 | second-session-port PORT1 | third-session-port PORT2 | fourth-session-port PORT3}|) (tx-mode-en|)",
    "Cmodel cmd",
    "Set oam auto gen config",
    "Chip id",
    "Packet size",
    "Set DsPktCfgPtr=0",
    "Set DsPktCfgPtr=1",
    "Set DsPktCfgPtr=2",
    "Set DsPktCfgPtr=3",
    "Set 4 DsPktCfg",
    "Send LBM PDU",
    "Send TST PDU",
    "Send DATA",
    "Set tx packet number",
    "Set pattern type"
    "First session corresponding output port",
    "PORT0",
    "Second session corresponding output port",
    "PORT1",
    "Third session corresponding output port",
    "PORT2",
    "Fourth session corresponding output port",
    "PORT3",
    "Tx mode enable, continue send")
{

    int32 ret = DRV_E_NONE;

    uint32 index = 0;
    uint32 chip_id = 0;
    uint32 size = 0;
    uint32 packet_header_len = 0;
    uint32 ds_pkt_cfg_ptr = 0;
    uint32 ds_pkt_hdr_ptr = 0;
    uint32 cmd = 0;
    uint8 i = 0;
    uint8 tx_seq_num_en = 0;
    uint16 seq_num_offset = 0;
    uint32 tx_pkt_cnt = 0;
    uint32 pattern_type = 0;
    uint32 session0_port = 5;
    uint32 session1_port = 6;
    uint32 session2_port = 7;
    uint32 session3_port = 8;
    uint32 tx_mode = 0;
    struct auto_gen_pkt_header_s
    {
       ms_packet_header_t auto_gen_pkt_bridge_header;
       uint32 mac_da_high;
       uint32 mac_da_low     :16;
       uint32 mac_sa_high;
       uint32 mac_sa_low     :16;
       uint16 tpid;
       uint8  vlan_cos       :3;
       uint8  vlan_cfi       :1;
       uint16 vlan_id        :14;
       uint16 length_type;
       uint8  mel            :3;
       uint8  version        :5;
       uint8 opcode;
       uint8 flags;
       uint8 tlv_offset;
       uint32 seq_num;
       uint8  type;
       uint16 length         :14;
       uint8 pattern_type;
    };

    typedef struct auto_gen_pkt_header_s auto_gen_pkt_header_t;
    auto_gen_pkt_pkt_cfg_t ds_pkt_cfg;
    auto_gen_pkt_pkt_hdr_t ds_pkt_hdr;
    auto_gen_pkt_header_t ds_auto_gen_pkt_header;
    chip_id     = (uint32)atoll(argv[0]);
    chip_id = 0;
    size   = (uint32)atoll(argv[1]);
    tx_pkt_cnt = (uint32)atoll(argv[4]);
    pattern_type = (uint32)atoll(argv[5]);
    index = ctc_cli_get_prefix_item(&argv[0], argc, "first-session-port", sal_strlen("first-session-port"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("first-session-port", session0_port, argv[index+1]);
    }
    index = ctc_cli_get_prefix_item(&argv[0], argc, "second-session-port", sal_strlen("second-session-port"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("second-session-port", session1_port, argv[index+1]);
    }
    index = ctc_cli_get_prefix_item(&argv[0], argc, "third-session-port", sal_strlen("third-session-port"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("third-session-port", session2_port, argv[index+1]);
    }
    index = ctc_cli_get_prefix_item(&argv[0], argc, "fourth-session-port", sal_strlen("fourth-session-port"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("fourth-session-port", session3_port, argv[index+1]);
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "tx-mode", sal_strlen("tx-mode"));
    if(0xFF != index)
    {
        tx_mode = 1;
    }

    sal_memset(&ds_auto_gen_pkt_header , 0 ,sizeof(ds_auto_gen_pkt_header));
    sal_memset(&ds_pkt_hdr , 0 ,sizeof(ds_pkt_hdr));
    /*
    bridge_header.dest_chip_id = 2;
    */
    ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map = (2 << 16);

    ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.source_port = 0x43c;
    ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.next_hop_ptr = 1;
    ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.color = 3;
    ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.src_vlan_id = 1;
#if 0
    ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.packet_length = size;
#endif
    ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.from_cpu_or_oam = 1;
    ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.src_vlan_ptr = 0x1fff;
    ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.operation_type = OPERATION_TYPE_OAM;
    ds_auto_gen_pkt_header.mac_da_high = 0x00000a01;

    ds_auto_gen_pkt_header.mac_sa_high = 0x00000a01;
    ds_auto_gen_pkt_header.mac_sa_low = 0x3c01;
    ds_auto_gen_pkt_header.tpid = 0x8100;
    ds_auto_gen_pkt_header.vlan_cos = 0;
    ds_auto_gen_pkt_header.vlan_cfi = 0;
    ds_auto_gen_pkt_header.vlan_id = 1;

    if (!sal_memcmp(argv[3], "LBM", sizeof("LBM")))
    {
        packet_header_len = 61;
        tx_seq_num_en = 1;
        seq_num_offset = 54;
        ds_auto_gen_pkt_header.mel = 0;
        ds_auto_gen_pkt_header.version= 0;
        ds_auto_gen_pkt_header.opcode = 3;
        ds_auto_gen_pkt_header.flags = 0;
        ds_auto_gen_pkt_header.tlv_offset = 4;
        ds_auto_gen_pkt_header.seq_num = 0;
        ds_auto_gen_pkt_header.type = 3;
        ds_auto_gen_pkt_header.length = size - 34;
        ds_auto_gen_pkt_header.length_type = 0x8902;

    }
    else if (!sal_memcmp(argv[3], "TST", sizeof("TST")))
    {
        packet_header_len = 62;
        tx_seq_num_en = 1;
        seq_num_offset = 54;
        ds_auto_gen_pkt_header.mel = 0;
        ds_auto_gen_pkt_header.version= 0;
        ds_auto_gen_pkt_header.opcode = 0x25;
        ds_auto_gen_pkt_header.flags = 0;
        ds_auto_gen_pkt_header.tlv_offset = 4;
        ds_auto_gen_pkt_header.seq_num = 0;
        ds_auto_gen_pkt_header.type = 0x20;
        ds_auto_gen_pkt_header.length = size - 34;
        ds_auto_gen_pkt_header.pattern_type = 0;
        ds_auto_gen_pkt_header.length_type = 0x8902;
    }
    else if (!sal_memcmp(argv[3], "DATA", sizeof("DATA")))
    {
        packet_header_len = 50;
        ds_auto_gen_pkt_header.length_type = 0x55aa;
    }

    if (!sal_memcmp(argv[2], "full", sizeof("full")))
    {
        for (i = 0; i < 4; i++)
        {
            if(i == 0)
            {
                ds_auto_gen_pkt_header.mac_da_low = 0x0001 + (session0_port << 8);
                ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map = (2 << 16) | session0_port;
            }
            else if (i == 1)
            {
                ds_auto_gen_pkt_header.mac_da_low = 0x0001 + (session1_port << 8);
                ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map = (2 << 16) | session1_port;
            }
            else if (i == 2)
            {
                ds_auto_gen_pkt_header.mac_da_low = 0x0001 + (session2_port << 8);
                ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map = (2 << 16) | session2_port;
            }
            else
            {
                ds_auto_gen_pkt_header.mac_da_low = 0x0001 + (session3_port << 8);
                ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map = (2 << 16) | session3_port;
            }

            cmd = DRV_IOR(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);/*1 DsOamLmStats entry*/
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, i, cmd, &ds_pkt_cfg));
            ds_pkt_cfg.pkt_hdr_len = packet_header_len;
            ds_pkt_cfg.seq_num_offset = seq_num_offset;
            ds_pkt_cfg.tx_seq_num_en = tx_seq_num_en;
            ds_pkt_cfg.tx_pkt_cnt = tx_pkt_cnt;
            ds_pkt_cfg.tx_pkt_size = size;
            ds_pkt_cfg.repeat_pattern = 0x12345678;
            ds_pkt_cfg.pattern_type = pattern_type;
            ds_pkt_cfg.tx_mode = tx_mode;
            cmd = DRV_IOW(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);/*1 DsOamLmStats entry*/
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, i, cmd, &ds_pkt_cfg));

            ds_pkt_hdr.pkt_hdr_userdata0 = ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map;
            ds_pkt_hdr.pkt_hdr_userdata1 = ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.source_port;
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*i, cmd, &ds_pkt_hdr));


            ds_pkt_hdr.pkt_hdr_userdata0 = (ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.src_vlan_id << 20)\
                                            | (ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.color << 18 )\
                                            | (ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.next_hop_ptr);
            ds_pkt_hdr.pkt_hdr_userdata1 = 0;

            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*i + 1, cmd, &ds_pkt_hdr));

            ds_pkt_hdr.pkt_hdr_userdata0 = (ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.from_cpu_or_oam << 18);
            ds_pkt_hdr.pkt_hdr_userdata1 = ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.src_vlan_ptr << 16;
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*i + 2, cmd, &ds_pkt_hdr));

            cmd = DRV_IOR(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*i + 3, cmd, &ds_pkt_hdr));
            ds_pkt_hdr.pkt_hdr_userdata0 = (ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.operation_type << 5);
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*i + 3, cmd, &ds_pkt_hdr));

            ds_pkt_hdr.pkt_hdr_userdata0 = ds_auto_gen_pkt_header.mac_da_high;
            ds_pkt_hdr.pkt_hdr_userdata1 = (ds_auto_gen_pkt_header.mac_da_low << 16 )\
                                            | ((ds_auto_gen_pkt_header.mac_sa_high >> 16) & 0xff);
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*i + 4, cmd, &ds_pkt_hdr));

            ds_pkt_hdr.pkt_hdr_userdata0 = ((ds_auto_gen_pkt_header.mac_sa_high & 0xffff )<< 16)\
                                            | (ds_auto_gen_pkt_header.mac_sa_low);
            ds_pkt_hdr.pkt_hdr_userdata1 = ds_auto_gen_pkt_header.tpid << 16 \
                                            | ds_auto_gen_pkt_header.vlan_cos << 13\
                                            | ds_auto_gen_pkt_header.vlan_cfi << 12\
                                            | ds_auto_gen_pkt_header.vlan_id;
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*i + 5, cmd, &ds_pkt_hdr));

            ds_pkt_hdr.pkt_hdr_userdata0 = (ds_auto_gen_pkt_header.length_type << 16)\
                                            | (ds_auto_gen_pkt_header.mel << 13)\
                                            | (ds_auto_gen_pkt_header.version<< 8)\
                                            | ds_auto_gen_pkt_header.opcode;
            ds_pkt_hdr.pkt_hdr_userdata1 = (ds_auto_gen_pkt_header.flags << 24)\
                                            | (ds_auto_gen_pkt_header.tlv_offset <<16)\
                                            |((ds_auto_gen_pkt_header.seq_num >> 16) & 0xffff);
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*i + 6, cmd, &ds_pkt_hdr));


            ds_pkt_hdr.pkt_hdr_userdata0 = ((ds_auto_gen_pkt_header.seq_num & 0xffff) << 16)\
                                            | (ds_auto_gen_pkt_header.type << 8)
                                            | ((ds_auto_gen_pkt_header.length >> 8)&0xff);
            ds_pkt_hdr.pkt_hdr_userdata1 = ((ds_auto_gen_pkt_header.length &0xff) << 24)\
                                            | (ds_auto_gen_pkt_header.pattern_type << 16);
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*i + 7, cmd, &ds_pkt_hdr));


        }
    }
    else
    {
        ds_pkt_cfg_ptr = (uint32)atoll(argv[2]);
        ds_pkt_hdr_ptr = (uint32)atoll(argv[2]);
        if(ds_pkt_hdr_ptr == 0)
        {
            ds_auto_gen_pkt_header.mac_da_low = 0x0001 + (session0_port << 8);
            ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map |= session0_port;
        }
        else if (ds_pkt_hdr_ptr == 1)
        {
            ds_auto_gen_pkt_header.mac_da_low = 0x0001 + (session1_port << 8);
            ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map |= session1_port;
        }
        else if (ds_pkt_hdr_ptr == 2)
        {
            ds_auto_gen_pkt_header.mac_da_low = 0x0001 + (session2_port << 8);
            ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map |= session2_port;
        }
        else
        {
            ds_auto_gen_pkt_header.mac_da_low = 0x0001 + (session3_port << 8);
            ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map |= session3_port;
        }
        cmd = DRV_IOR(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);/*1 DsOamLmStats entry*/
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, i, cmd, &ds_pkt_cfg));
            ds_pkt_cfg.pkt_hdr_len = packet_header_len;
            ds_pkt_cfg.seq_num_offset = seq_num_offset;
            ds_pkt_cfg.tx_seq_num_en = tx_seq_num_en;
            ds_pkt_cfg.tx_pkt_cnt = tx_pkt_cnt;
            ds_pkt_cfg.tx_pkt_size = size;
            ds_pkt_cfg.repeat_pattern = 0x12345678;
            ds_pkt_cfg.pattern_type = pattern_type;
            ds_pkt_cfg.tx_mode = tx_mode;
            cmd = DRV_IOW(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);/*1 DsOamLmStats entry*/
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_pkt_hdr_ptr, cmd, &ds_pkt_cfg));

            ds_pkt_hdr.pkt_hdr_userdata0 = ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.dest_map;
            ds_pkt_hdr.pkt_hdr_userdata1 = ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.source_port;
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*ds_pkt_hdr_ptr, cmd, &ds_pkt_hdr));


            ds_pkt_hdr.pkt_hdr_userdata0 = (ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.src_vlan_id << 20)\
                                            | (ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.color << 18 )\
                                            | (ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.next_hop_ptr);
            ds_pkt_hdr.pkt_hdr_userdata1 = 0;

            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*ds_pkt_hdr_ptr + 1, cmd, &ds_pkt_hdr));

            ds_pkt_hdr.pkt_hdr_userdata0 = (ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.from_cpu_or_oam << 18);
            ds_pkt_hdr.pkt_hdr_userdata1 = ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.src_vlan_ptr << 16;
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*ds_pkt_hdr_ptr + 2, cmd, &ds_pkt_hdr));

            cmd = DRV_IOR(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*ds_pkt_hdr_ptr + 3, cmd, &ds_pkt_hdr));
            ds_pkt_hdr.pkt_hdr_userdata0 = (ds_auto_gen_pkt_header.auto_gen_pkt_bridge_header.operation_type << 5);
            ds_pkt_hdr.pkt_hdr_userdata1 = 0;
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*ds_pkt_hdr_ptr + 3, cmd, &ds_pkt_hdr));

            ds_pkt_hdr.pkt_hdr_userdata0 = ds_auto_gen_pkt_header.mac_da_high;
            ds_pkt_hdr.pkt_hdr_userdata1 = (ds_auto_gen_pkt_header.mac_da_low << 16 )\
                                            | ((ds_auto_gen_pkt_header.mac_sa_high >> 16) & 0xff);
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*ds_pkt_hdr_ptr + 4, cmd, &ds_pkt_hdr));

            ds_pkt_hdr.pkt_hdr_userdata0 = ((ds_auto_gen_pkt_header.mac_sa_high & 0xffff )<< 16)\
                                            | (ds_auto_gen_pkt_header.mac_sa_low);
            ds_pkt_hdr.pkt_hdr_userdata1 = ds_auto_gen_pkt_header.tpid << 16 \
                                            | ds_auto_gen_pkt_header.vlan_cos << 13\
                                            | ds_auto_gen_pkt_header.vlan_cfi << 12\
                                            | ds_auto_gen_pkt_header.vlan_id;
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*ds_pkt_hdr_ptr + 5, cmd, &ds_pkt_hdr));

            ds_pkt_hdr.pkt_hdr_userdata0 = (ds_auto_gen_pkt_header.length_type << 16)\
                                            | (ds_auto_gen_pkt_header.mel << 13)\
                                            | (ds_auto_gen_pkt_header.version<< 8)\
                                            | ds_auto_gen_pkt_header.opcode;
            ds_pkt_hdr.pkt_hdr_userdata1 = (ds_auto_gen_pkt_header.flags << 24)\
                                            | (ds_auto_gen_pkt_header.tlv_offset <<16)\
                                            |((ds_auto_gen_pkt_header.seq_num >> 16) & 0xffff);
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*ds_pkt_hdr_ptr + 6, cmd, &ds_pkt_hdr));


            ds_pkt_hdr.pkt_hdr_userdata0 = ((ds_auto_gen_pkt_header.seq_num & 0xffff) << 16)\
                                            | (ds_auto_gen_pkt_header.type << 8)
                                            | ((ds_auto_gen_pkt_header.length >> 8)&0xff);
            ds_pkt_hdr.pkt_hdr_userdata1 = ((ds_auto_gen_pkt_header.length &0xff) << 24)\
                                            | (ds_auto_gen_pkt_header.pattern_type << 16);
            cmd = DRV_IOW(AutoGenPktPktHdr_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 12*ds_pkt_hdr_ptr + 7, cmd, &ds_pkt_hdr));
    }

    return ret;
}


CTC_CLI(cli_cmodel_oam_auto_gen_pkt_set_rate,
    cli_cmodel_oam_auto_gen_pkt_set_rate_cmd,
    "oam auto-gen-pkt-set-rate CHIP_ID PACKET_SIZE (0|1|2|3|full) BAND_WIDTH",
    "Cmodel cmd",
    "Set oam auto gen rate",
    "Chip id",
    "Packet size",
    "Set DsPktCfgPtr",
    "Set band_width")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 size = 0;
    uint32 band_width = 0;
    uint32 ds_pkt_cfg_ptr = 0;
    auto_gen_pkt_pkt_cfg_t ds_pkt_cfg;
    auto_gen_pkt_ctl_t auto_gen_pkt_ctl;
    uint32 rate_cnt;
    uint32 rate_frac_cnt;
    uint32 tick_gen_interval = 0;
    uint32 tick_gen_interval_min = 0;
    uint32 tick_gen_interval_max = 0;
    uint32 cmd = 0;
    uint8 i;
    chip_id     = (uint32)atoll(argv[0]);
    chip_id = 0;
    size   = (uint32)atoll(argv[1]);
    band_width = (uint32)atoll(argv[3]);

    cmd = DRV_IOR(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));
    auto_gen_pkt_ctl.upd_valid_ptr = 3;
    cmd = DRV_IOW(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));

    if(band_width == 1000)
    {
        cmd = DRV_IOR(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));
        auto_gen_pkt_ctl.upd_valid_ptr = 3;
        cmd = DRV_IOW(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));
        if (size == 64)
        {
            tick_gen_interval = 74;
            rate_cnt = 1;
            rate_frac_cnt = 524;
        }
        else if (size == 128)
        {
            tick_gen_interval = 65;
            rate_cnt = 2;
            rate_frac_cnt = 1191;
        }
        else if (size == 256)
        {
            tick_gen_interval = 120;
            rate_cnt = 2;
            rate_frac_cnt = 3466;
        }
        else if (size == 512)
        {
            tick_gen_interval = 158;
            rate_cnt = 3;
            rate_frac_cnt = 741;
        }
        else if (size == 1024)
        {
            tick_gen_interval = 310;
            rate_cnt = 3;
            rate_frac_cnt = 1390;
        }
        else if (size == 1280)
        {
            tick_gen_interval = 290;
            rate_cnt = 4;
            rate_frac_cnt = 1351;
        }
        else if (size == 1518)
        {
            tick_gen_interval = 275;
            rate_cnt = 5;
            rate_frac_cnt = 997;
        }
        else if (size == 2048)
        {
            tick_gen_interval = 370;
            rate_cnt = 5;
            rate_frac_cnt = 1095;
        }
        else if (size == 9600)
        {
            tick_gen_interval = 1700;
            rate_cnt = 5;
            rate_frac_cnt = 5894;
        }
        else
        {
            if(!((size+32)*8%64))
            {
                tick_gen_interval_min = ((size+32)*8/64 + 2);
            }
            else
            {
                tick_gen_interval_min = ((size+32)*8/64 + 3);
            }
            tick_gen_interval_max = (size+12+8)*8*450/4000 + 2;
            if(tick_gen_interval_max < tick_gen_interval_min)
            {
                return CLI_ERROR;
            }
            tick_gen_interval = (tick_gen_interval_min + tick_gen_interval_max)/2;
            rate_cnt = ((size+12+8)*8*450)/(4*1000*tick_gen_interval);
            rate_frac_cnt = (((size+12+8)*8*450)%(4*1000*tick_gen_interval))*65536;
        }
    }
    else if(band_width == 10000)
    {
        cmd = DRV_IOR(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));
        auto_gen_pkt_ctl.upd_valid_ptr = 0;
        cmd = DRV_IOW(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));
        if (size == 64)
        {
            tick_gen_interval = 28;
            rate_cnt = 1;
            rate_frac_cnt = 2802;
        }
        else if (size == 128)
        {
            tick_gen_interval = 50;
            rate_cnt = 1;
            rate_frac_cnt = 2929;
        }
        else if (size == 256)
        {
            tick_gen_interval = 97;
            rate_cnt = 1;
            rate_frac_cnt = 909;
        }
        else if (size == 512)
        {
            tick_gen_interval = 180;
            rate_cnt = 1;
            rate_frac_cnt = 3809;
        }
        else if (size == 1024)
        {
            tick_gen_interval = 370;
            rate_cnt = 1;
            rate_frac_cnt = 854;
        }
        else if (size == 1280)
        {
            tick_gen_interval = 460;
            rate_cnt = 1;
            rate_frac_cnt = 995;
        }
        else if (size == 1518)
        {
            tick_gen_interval = 550;
            rate_cnt = 1;
            rate_frac_cnt = 318;
        }
        else if (size == 2048)
        {
            tick_gen_interval = 740;
            rate_cnt = 1;
            rate_frac_cnt = 307;
        }
        else if (size == 9600)
        {
            tick_gen_interval = 3400;
            rate_cnt = 1;
            rate_frac_cnt = 1198;
        }
        else
        {
            if(!((size+32)*8%64))
            {
                tick_gen_interval_min = ((size+32)*8/64 + 2);
            }
            else
            {
                tick_gen_interval_min = ((size+32)*8/64 + 3);
            }
            tick_gen_interval_max = (size+12+8)*8*450/4000 + 2;
            if(tick_gen_interval_max < tick_gen_interval_min)
            {
                return CLI_ERROR;
            }
            tick_gen_interval = (tick_gen_interval_min + tick_gen_interval_max)/2;
            rate_cnt = ((size+12+8)*8*450)/(4*1000*tick_gen_interval);
            rate_frac_cnt = (((size+12+8)*8*450)%(4*1000*tick_gen_interval))*65536;
        }
    }
    else
    {
        if(!((size+32)*8%64))
        {
            tick_gen_interval_min = ((size+32)*8/64 + 2);
        }
        else
        {
            tick_gen_interval_min = ((size+32)*8/64 + 3);
        }
        tick_gen_interval_max = (size+12+8)*8*450/(4*band_width) + 2;
        if(tick_gen_interval_max < tick_gen_interval_min)
        {
            return CLI_ERROR;
        }
        tick_gen_interval = (tick_gen_interval_min + tick_gen_interval_max)/2;
        rate_cnt = ((size+12+8)*8*450)/(4*band_width*tick_gen_interval);
        rate_frac_cnt = (((size+12+8)*8*450)%(4*band_width*tick_gen_interval))*65536;
    }

    sal_memset(&auto_gen_pkt_ctl, 0, sizeof(auto_gen_pkt_ctl));
    cmd = DRV_IOR(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));
    auto_gen_pkt_ctl.tick_gen_interval = tick_gen_interval;
    cmd = DRV_IOW(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));

    sal_memset(&ds_pkt_cfg, 0, sizeof(ds_pkt_cfg));
    if (!sal_memcmp(argv[2], "full", sizeof("full")))
    {
        for (i = 0; i < 4; i++)
        {
            cmd = DRV_IOR(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);/*1 DsOamLmStats entry*/
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, i, cmd, &ds_pkt_cfg));
            ds_pkt_cfg.rate_cnt = rate_cnt;
            ds_pkt_cfg.rate_cnt_cfg = rate_cnt;
            ds_pkt_cfg.rate_frac_cnt = rate_frac_cnt;
            ds_pkt_cfg.rate_frac_cnt_cfg = rate_frac_cnt;
            cmd = DRV_IOW(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);/*1 DsOamLmStats entry*/
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, i, cmd, &ds_pkt_cfg));

        }
    }
    else
    {
        ds_pkt_cfg_ptr = (uint32)atoll(argv[2]);
        cmd = DRV_IOR(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);/*1 DsOamLmStats entry*/
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_pkt_cfg_ptr, cmd, &ds_pkt_cfg));
        ds_pkt_cfg.rate_cnt = rate_cnt;
        ds_pkt_cfg.rate_cnt_cfg = rate_cnt;
        ds_pkt_cfg.rate_frac_cnt = rate_frac_cnt;
        ds_pkt_cfg.rate_frac_cnt_cfg = rate_frac_cnt;
        cmd = DRV_IOW(AutoGenPktPktCfg_t, DRV_ENTRY_FLAG);/*1 DsOamLmStats entry*/
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_pkt_cfg_ptr, cmd, &ds_pkt_cfg));

    }

    return ret;
}
CTC_CLI(cli_cmodel_fib_fcoe_key,
    cli_cmodel_fib_fcoe_key_cmd,
    "cmodel (add|del) fcoe chipid CHIPID (fcoe-did|fcoe-sid) FCID fid FID (adindex INDEX|)",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel del cmd",
    "Cmodel fcoe cmd",
    "chipid",
    "chipid value",
    "dest fcid",
    "source fcid",
    "<0-0xFFFFFF>",
    "fid or vsi",
    "<0-16383>",
    "associate data index if add",
    "<0-0xFFFF>")
{
    int32 ret = DRV_E_NONE;
    uint8 add_cmd = FALSE;
    uint8 fcoe_key = FALSE;
    uint8  fib_key_type = FIB_KEY_TYPE_FCOE;
    uint8  fib_hash_type = FIB_HASH_TYPE_FCOE;
    uint32 chip_id = 0;
    uint32 fcid = 0;
    uint32 fid = 0;
    uint32 adindex = 0;

    ds_fcoe_hash_key_t fcoe_hash_key;
    ds_fcoe_rpf_hash_key_t  fcoe_rpf_hash_key;

    sal_memset(&fcoe_hash_key, 0, sizeof(ds_fcoe_hash_key_t));
    sal_memset(&fcoe_rpf_hash_key, 0, sizeof(ds_fcoe_rpf_hash_key_t));

    if (!sal_memcmp(argv[0], "add", sizeof("add")))
    {
        add_cmd = TRUE;
    }

    if ((!add_cmd) && (argc > 5))
    {
        ctc_cli_out("Fail to delete, the adindex is unnecessary.\n");
        return CLI_ERROR;
    }
    else if (add_cmd && (argc < 7))
    {
        ctc_cli_out("Fail to add, the adindex is necessary.\n");
        return CLI_ERROR;
    }

    if (!sal_memcmp(argv[2],"fcoe-did", sizeof("fcoe-did")))
    {
        fcoe_key = TRUE;
    }

    CTC_CLI_GET_UINT32("chip id", chip_id, argv[1]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("fid", fid, argv[4]);

    if (fcoe_key)
    {
        CTC_CLI_GET_UINT32("fcoe-did", fcid, argv[3]);

        fib_key_type = FIB_KEY_TYPE_FCOE;
        fib_hash_type = FIB_HASH_TYPE_FCOE;
        fcoe_hash_key.is_mac_hash = FALSE;
        fcoe_hash_key.hash_type_low = fib_key_type & 0x1;
        fcoe_hash_key.hash_type_high = (fib_key_type >> 1) & 0x7;
        fcoe_hash_key.fcoe_did = fcid & 0xFFFFFF;
        fcoe_hash_key.vsi_id = fid;
        fcoe_hash_key.valid = TRUE;
        fcoe_hash_key.fcoe_did = fcid & 0xFFFFFF;

        if (add_cmd)
        {
            CTC_CLI_GET_UINT32("adindex", adindex, argv[6]);
            fcoe_hash_key.ds_ad_index5_0 = adindex & 0x3F;
            fcoe_hash_key.ds_ad_index14_6 = (adindex >> 6) & 0x1FF;
            fcoe_hash_key.ds_ad_index15 = (adindex >> 15) & 0x1;
            ret = cm_sim_cfg_kit_add_fib_key(chip_id, fib_hash_type, &fcoe_hash_key);
        }
        else
        {
            ret = cm_sim_cfg_kit_delete_fib_key(chip_id, fib_hash_type, &fcoe_hash_key);
        }
    }
    else
    {
        CTC_CLI_GET_UINT32("fcoe-sid", fcid, argv[3]);

        fib_key_type = FIB_KEY_TYPE_FCOE_RPF;
        fib_hash_type = FIB_HASH_TYPE_FCOE_RPF;
        fcoe_rpf_hash_key.is_mac_hash = FALSE;
        fcoe_rpf_hash_key.hash_type_low = fib_key_type & 0x1;
        fcoe_rpf_hash_key.hash_type_high = (fib_key_type >> 1) & 0x7;
        fcoe_rpf_hash_key.fcoe_sid = fcid & 0xFFFFFF;
        fcoe_rpf_hash_key.vsi_id = fid;
        fcoe_rpf_hash_key.valid = TRUE;

        if (add_cmd)
        {
            CTC_CLI_GET_UINT32("adindex", adindex, argv[6]);
            fcoe_rpf_hash_key.ds_ad_index5_0 = adindex & 0x3F;
            fcoe_rpf_hash_key.ds_ad_index14_6 = (adindex >> 6) & 0x1FF;
            fcoe_rpf_hash_key.ds_ad_index15 = (adindex >> 15) & 0x1;
            ret = cm_sim_cfg_kit_add_fib_key(chip_id, fib_hash_type, &fcoe_rpf_hash_key);
        }
        else
        {
            ret = cm_sim_cfg_kit_delete_fib_key(chip_id, fib_hash_type, &fcoe_rpf_hash_key);
        }
    }

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_fib_trill_key,
    cli_cmodel_fib_trill_key_cmd,
    "cmodel (add|del) trill chipid CHIPID (is-mcast MCAST|vlan-id VLANID) egress-nickname EGRESS_NICKNAME (adindex INDEX|)",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel del cmd",
    "Cmodel trill cmd",
    "chipid",
    "chipid value",
    "is mcast trill key",
    "<0-1> 0:is ucast trill key; 1:is mcast trill key",
    "trill vlan id",
    "<0-0xFFF>",
    "egress nickname",
    CTC_CLI_EGRESS_NICKNAME,
    "associate data index for add",
    "<0-0xFFFF>")
{
    int32 ret = DRV_E_NONE;
    uint8 is_add = FALSE;
    uint8 is_vlan_key = FALSE;
    uint8 fib_key_type = FIB_KEY_TYPE_TRILL_UCAST;
    uint8 fib_hash_type = FIB_HASH_TYPE_TRILL_UCAST;
    uint32 vlan_id = 0;
    uint32 egress_nickname = 0;
    uint32 chip_id = 0;
    uint32 adindex = 0;
    uint32 is_mcast_key = FALSE;

    ds_trill_mcast_hash_key_t ds_trill_mcast_hash_key;
    ds_trill_mcast_vlan_hash_key_t ds_trill_mcast_vlan_hash_key;
    ds_trill_ucast_hash_key_t ds_trill_ucast_hash_key;

    sal_memset(&ds_trill_mcast_hash_key, 0, sizeof(ds_trill_mcast_hash_key_t));
    sal_memset(&ds_trill_mcast_vlan_hash_key, 0, sizeof(ds_trill_mcast_vlan_hash_key_t));
    sal_memset(&ds_trill_ucast_hash_key, 0, sizeof(ds_trill_ucast_hash_key_t));

    if (!sal_memcmp(argv[0], "add", sizeof("add")))
    {
        is_add = TRUE;
    }

    if ((!is_add) && (argc > 5))
    {
        ctc_cli_out("Fail to delete, the adindex is unnecessary.\n");
        return CLI_ERROR;
    }
    else if (is_add && (argc < 7))
    {
        ctc_cli_out("Fail to add, the adindex is necessary.\n");
        return CLI_ERROR;
    }

    CTC_CLI_GET_UINT32("chip id", chip_id, argv[1]);
    chip_id = 0;
    if (!sal_memcmp(argv[2],"vlan-id", sizeof("vlan-id")))
    {
        is_vlan_key = TRUE;
        CTC_CLI_GET_UINT32("vlan-id", vlan_id, argv[3]);
    }
    else if (!sal_memcmp(argv[2],"is-mcast", sizeof("is-mcast")))
    {
        CTC_CLI_GET_UINT32("is-mcast", is_mcast_key, argv[3]);
    }

    CTC_CLI_GET_UINT32("egress-nickname", egress_nickname, argv[4]);


    if (is_vlan_key)
    {
        fib_key_type = FIB_KEY_TYPE_TRILL_MCAST_VLAN;
        fib_hash_type = FIB_HASH_TYPE_TRILL_MCAST_VLAN;
        ds_trill_mcast_vlan_hash_key.is_mac_hash = FALSE;
        ds_trill_mcast_vlan_hash_key.hash_type_low = fib_key_type & 0x1;
        ds_trill_mcast_vlan_hash_key.hash_type_high = (fib_key_type >> 1) & 0x7;
        ds_trill_mcast_vlan_hash_key.egress_nickname = egress_nickname & 0xFFFF;
        ds_trill_mcast_vlan_hash_key.vlan_id = vlan_id;
        ds_trill_mcast_vlan_hash_key.valid = TRUE;

        if (is_add)
        {
            CTC_CLI_GET_UINT32("adindex", adindex, argv[6]);
            ds_trill_mcast_vlan_hash_key.ds_ad_index5_0 = adindex & 0x3F;
            ds_trill_mcast_vlan_hash_key.ds_ad_index14_6 = (adindex >> 6) & 0x1FF;
            ds_trill_mcast_vlan_hash_key.ds_ad_index15 = (adindex >> 15) & 0x1;
            ret = cm_sim_cfg_kit_add_fib_key(chip_id, fib_hash_type, &ds_trill_mcast_vlan_hash_key);
        }
        else
        {
            ret = cm_sim_cfg_kit_delete_fib_key(chip_id, fib_hash_type, &ds_trill_mcast_vlan_hash_key);
        }
    }
    else if (is_mcast_key)
    {
        fib_key_type = FIB_KEY_TYPE_TRILL_MCAST;
        fib_hash_type = FIB_HASH_TYPE_TRILL_MCAST;
        ds_trill_mcast_hash_key.is_mac_hash = FALSE;
        ds_trill_mcast_hash_key.hash_type_low = fib_key_type & 0x1;
        ds_trill_mcast_hash_key.hash_type_high = (fib_key_type >> 1) & 0x7;
        ds_trill_mcast_hash_key.egress_nickname = egress_nickname & 0xFFFF;
        ds_trill_mcast_hash_key.valid = TRUE;

        if (is_add)
        {
            CTC_CLI_GET_UINT32("adindex", adindex, argv[6]);
            ds_trill_mcast_hash_key.ds_ad_index5_0 = adindex & 0x3F;
            ds_trill_mcast_hash_key.ds_ad_index14_6 = (adindex >> 6) & 0x1FF;
            ds_trill_mcast_hash_key.ds_ad_index15 = (adindex >> 15 ) & 0x1;
            ret = cm_sim_cfg_kit_add_fib_key(chip_id, fib_hash_type, &ds_trill_mcast_hash_key);
        }
        else
        {
            ret = cm_sim_cfg_kit_delete_fib_key(chip_id, fib_hash_type, &ds_trill_mcast_hash_key);
        }

    }
    else
    {
        fib_key_type = FIB_KEY_TYPE_TRILL_UCAST;
        fib_hash_type = FIB_HASH_TYPE_TRILL_UCAST;
        ds_trill_ucast_hash_key.is_mac_hash = FALSE;
        ds_trill_ucast_hash_key.hash_type_low = fib_key_type & 0x1;
        ds_trill_ucast_hash_key.hash_type_high = (fib_key_type >> 1) & 0x7;
        ds_trill_ucast_hash_key.egress_nickname = egress_nickname & 0xFFFF;
        ds_trill_ucast_hash_key.valid = TRUE;

        if (is_add)
        {
            CTC_CLI_GET_UINT32("adindex", adindex, argv[6]);
            ds_trill_ucast_hash_key.ds_ad_index5_0 = adindex & 0x3F;
            ds_trill_ucast_hash_key.ds_ad_index14_6 = (adindex >> 6) & 0x1FF;
            ds_trill_ucast_hash_key.ds_ad_index15 = (adindex >> 15) & 0x1;
            ret = cm_sim_cfg_kit_add_fib_key(chip_id, fib_hash_type, &ds_trill_ucast_hash_key);
        }
        else
        {
            ret = cm_sim_cfg_kit_delete_fib_key(chip_id, fib_hash_type, &ds_trill_ucast_hash_key);
        }
    }

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

#if 0
/* Cmd format: cmodel del fdb chipid <chipid> mac <mac_address> fid <fid> */
CTC_CLI(cli_cmodel_fib_mac_key,
    cli_cmodel_fib_mac_key_cmd,
    "cmodel (add|del) fdb chipid CHIPID mac MAC fid FID (adindex INDEX|)",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel del cmd",
    "Cmodel fdb cmd",
    "chipid",
    "chipid value",
    "MAC address",
    "MAC address in HHHH.HHHH.HHHH format",
    "fid or vsi",
    "<0-16383>",
    "associate data index when add",
    "<0-0xFFFF>")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 vsi_id = 0;
    uint16 mac_addr[3] = {0};
    uint32 ad_index = 0;
    uint8 is_add = FALSE;

    ds_mac_hash_key_t ds_mac_hash_key;

    if (!sal_memcmp(argv[0], "add", sizeof("add")))
    {
        is_add = TRUE;
    }

    if ((!is_add) && (argc > 4))
    {
        ctc_cli_out("Fail to delete, the adindex is unnecessary.\n");
        return CLI_ERROR;
    }
    else if (is_add && (argc < 6))
    {
        ctc_cli_out("Fail to add, the adindex is necessary.\n");
        return CLI_ERROR;
    }

    sal_memset(&ds_mac_hash_key, 0, sizeof(ds_mac_hash_key_t));
    CTC_CLI_GET_UINT32("chipid", chip_id, argv[1]);

    if (3 != sal_sscanf(argv[2], "%4hx.%4hx.%4hx", &mac_addr[2], &mac_addr[1], &mac_addr[0]))
    {
        ctc_cli_out("%% CLI get MAC address ERROR! Input MAC address %s\n", argv[1]);
        return CLI_ERROR;
    }
#endif

#if 0
CTC_CLI(cli_cmodel_add_userid_svlan,
    cli_cmodel_add_userid_svlan_cmd,
    "cmodel add userid-svlan chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL svlanid SVLAN_ID direction DIRECTION ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid svlan cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
#endif

#if 0
    uint32 global_src_port = 0;
    ds_user_id_svlan_hash_key_t userid_svlan_key;

    sal_memset(&userid_svlan_key, 0, sizeof(userid_svlan_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
#endif


CTC_CLI(cli_cmodel_fib_acl_mac_key,
    cli_cmodel_fib_acl_mac_key_cmd,
    "cmodel (add|del) acl-mac chipid CHIPID mac MAC is-logic-port IS_LOGIC_PORT globalsrcport GLOBAL_SRC_PORT\
     cos COS vlanid VLAN_ID ethertype ETHER_TYPE(adindex ADINDEX|)",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel del cmd",
    "Cmodel acl-mac cmd",
    "chipid",
    "chipid value",
    "MAC address",
    "MAC address in HHHH.HHHH.HHHH format",
    "is-logic-port",
    "is-logic-port value 1 or 0",
    "global-src-port",
    "global src port value",
    "cos",
    "cos value",
    "vlanid",
    "vlanid value",
    "ethertype",
    "ethertype value",
    "associate data index for add",
    "<0-0xFFFF>")
{
    int32  ret = DRV_E_NONE;
    uint8  is_add = FALSE;
    uint8  fib_key_type = FIB_KEY_TYPE_ACL;
    uint8  fib_hash_type = FIB_HASH_TYPE_ACL_MAC;
    uint8 is_ipv4_key = FALSE;
    uint8  cos = 0;
    uint32 chip_id = 0;
    uint16 mac_addr[3] = {0};
    uint32 global_src_port = 0;
    uint32 ad_index = 0;
    uint8 is_logic_port = FALSE;
    uint32 vlan_id = 0;
    uint32 ether_type = 0;
    uint32 cmd = 0;

    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;
    ds_acl_qos_mac_hash_key_t ds_acl_qos_mac_hash_key;

    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl));
    sal_memset(&ds_acl_qos_mac_hash_key, 0, sizeof(ds_acl_qos_mac_hash_key));

    if (!sal_memcmp(argv[0], "add", sizeof("add")))
    {
        is_add = TRUE;
    }

    if ((!is_add) && (argc > 8))
    {
        ctc_cli_out("Fail to delete, the adindex is unnecessary.\n");
        return CLI_ERROR;
    }
    else if (is_add && (argc < 10))
    {
        ctc_cli_out("Fail to add, the adindex is necessary.\n");
        return CLI_ERROR;
    }

    CTC_CLI_GET_UINT32("chipid", chip_id, argv[1]);
    chip_id = 0;

    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_ctl));

    if (3 != sal_sscanf(argv[2], "%4hx.%4hx.%4hx", &mac_addr[2], &mac_addr[1], &mac_addr[0]))
    {
        ctc_cli_out("%% CLI get MAC address ERROR! Input MAC address %s\n", argv[1]);
        return CLI_ERROR;
    }

    CTC_CLI_GET_UINT32("is-logic-port", is_logic_port, argv[3]);
    CTC_CLI_GET_UINT32("globalsrcport", global_src_port, argv[4]);
    CTC_CLI_GET_UINT32("cos", cos, argv[5]);
    CTC_CLI_GET_UINT32("vlanid", vlan_id, argv[6]);
    CTC_CLI_GET_UINT32("ethertype", ether_type, argv[7]);

    ds_acl_qos_mac_hash_key.hash_type0_low = fib_key_type & 0x1;
    ds_acl_qos_mac_hash_key.hash_type0_high = (fib_key_type >> 1) & 0x7;
    ds_acl_qos_mac_hash_key.is_mac_hash0 = FALSE;
    ds_acl_qos_mac_hash_key.valid0 = TRUE;
    ds_acl_qos_mac_hash_key.global_src_port10_0 = global_src_port & 0x7FF;
    ds_acl_qos_mac_hash_key.global_src_port13_11 = (global_src_port >> 11) & 0x7;

    if (fib_engine_lookup_ctl.mac_acl_cos_en)
    {
        ds_acl_qos_mac_hash_key.cos = cos;
    }
    else
    {
        ds_acl_qos_mac_hash_key.cos = 0;
    }

    ds_acl_qos_mac_hash_key.mac_da31_0 = (mac_addr[1] << 16) | mac_addr[0];
    ds_acl_qos_mac_hash_key.mac_da47_32 = mac_addr[2];
    ds_acl_qos_mac_hash_key.hash_type1_low = fib_key_type & 0x1;
    ds_acl_qos_mac_hash_key.hash_type1_high = (fib_key_type >> 1) & 0x7;
    ds_acl_qos_mac_hash_key.is_mac_hash1 = FALSE;
    ds_acl_qos_mac_hash_key.valid1 = TRUE;
    ds_acl_qos_mac_hash_key.is_logic_port = is_logic_port;
    ds_acl_qos_mac_hash_key.ether_type11_0 = ether_type & 0xFFF;
    ds_acl_qos_mac_hash_key.ether_type15_12 = (ether_type >> 12) & 0xF;
    ds_acl_qos_mac_hash_key.vlan_id = vlan_id;
    ds_acl_qos_mac_hash_key.is_ipv4_key = is_ipv4_key;


    if (is_add)
    {
        CTC_CLI_GET_UINT32("adindex", ad_index, argv[9]);
        ds_acl_qos_mac_hash_key.ds_ad_index15 = (ad_index >> 15) & 0x1;
        ds_acl_qos_mac_hash_key.ds_ad_index14_7 = (ad_index >> 7) & 0xFF;
        ds_acl_qos_mac_hash_key.ds_ad_index6_0 = ad_index & 0x7F;
        ret = cm_sim_cfg_kit_add_fib_key(chip_id, fib_hash_type, &ds_acl_qos_mac_hash_key);
    }
    else
    {
        ret = cm_sim_cfg_kit_delete_fib_key(chip_id, fib_hash_type, &ds_acl_qos_mac_hash_key);
    }

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


/* Cmd format: cmodel (add|del) acl-ipv4 chipid CHIP_ID ipda x.x.x.x ipsa x.x.x.x l4destport <0-0xFFFF> l4sourceport <0-0xFFFF>
 global-src-port <0-0x3FFF> l3-header-protocol <0-0xFF> dscp <0-0x3F> is-arp-key <0-1> is-ipv4-key <0-1> adindex ADINDEX
*/
CTC_CLI(cli_cmodel_fib_acl_ipv4_key,
    cli_cmodel_fib_acl_ipv4_key_cmd,
    "cmodel (add|del) acl-ipv4 chipid CHIP_ID ipda IPDA ipsa IPSA l4destport L4_DEST_PORT l4sourceport L4_SOUECE_PORT\
    is-logic-port IS_LOGIC_PORT global-src-port GLOBAL_SEC_PORT l3-header-protocol L3_HEADER_PROTOCOL\
    dscp DSCP (adindex ADINDEX|)",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel del cmd",
    "Cmodel acl-ipv4 cmd",
    "chipid",
    "chipid value",
    "IPDA address",
    "IPDA address in A.B.C.D format",
    "IPSA address",
    "IPSA address in A.B.C.D format",
    "l4-dest-port",
    "l4 dest port value",
    "l4-source-port",
    "l4 source port value",
    "is-logic-port",
    "is-logic-port value 1 or 0",
    "global-src-port",
    "global src port value",
    "l3-header-protocol",
    "layer3 header protocol value",
    "dscp",
    "dscp value",
    "associate data index for add",
    "<0-0xFFFF>")
{
    int32  ret = DRV_E_NONE;
    uint8  is_add = FALSE;
    uint8  fib_key_type = FIB_KEY_TYPE_ACL;
    uint8  fib_hash_type = FIB_HASH_TYPE_ACL_IPV4;

    uint32 chip_id = 0;
    cm_ipv4_addr_t ipda;
    cm_ipv4_addr_t ipsa;
    uint16 l4_dest_port = 0;
    uint16 l4_source_port = 0;
    uint16 global_src_port = 0;
    uint8 l3_header_protocol = 0;
    uint8 dscp = 0;
    uint8 is_arp_key = FALSE;
    uint8 is_ipv4_key = TRUE;
    uint8 is_logic_port = FALSE;
    uint32 cmd = 0;

    uint32 ad_index = 0;

    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;
    ds_acl_qos_ipv4_hash_key_t ds_acl_qos_ipv4_hash_key;
    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl));
    sal_memset(&ds_acl_qos_ipv4_hash_key, 0, sizeof(ds_acl_qos_ipv4_hash_key));

    if (!sal_memcmp(argv[0], "add", sizeof("add")))
    {
        is_add = TRUE;
    }

    if ((!is_add) && (argc > 10))
    {
        ctc_cli_out("Fail to delete, the adindex is unnecessary.\n");
        return CLI_ERROR;
    }
    else if (is_add && (argc < 12))
    {
        ctc_cli_out("Fail to add, the adindex is necessary.\n");
        return CLI_ERROR;
    }

    CTC_CLI_GET_UINT32("chipid", chip_id, argv[1]);
    chip_id = 0;

    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_ctl));

    sal_memset(&ipda, 0, sizeof(cm_ipv4_addr_t));
    sal_memset(&ipsa, 0, sizeof(cm_ipv4_addr_t));

    CTC_CLI_GET_IPV4_ADDRESS("ipda", ipda.ip32[0], argv[2]);
    CTC_CLI_GET_IPV4_ADDRESS("ipsa", ipsa.ip32[0], argv[3]);
    CTC_CLI_GET_UINT32("l4destport", l4_dest_port, argv[4]);
    CTC_CLI_GET_UINT32("l4sourceport", l4_source_port, argv[5]);
    CTC_CLI_GET_UINT32("is-logic-port", is_logic_port, argv[6]);
    CTC_CLI_GET_UINT32("globalsrcport", global_src_port, argv[7]);

    CTC_CLI_GET_UINT32("l3-header-protocol", l3_header_protocol, argv[8]);
    CTC_CLI_GET_UINT32("dscp", dscp, argv[9]);

    ds_acl_qos_ipv4_hash_key.hash_type0_low = fib_key_type & 0x1;
    ds_acl_qos_ipv4_hash_key.hash_type0_high = (fib_key_type >> 1) & 0x7;
    ds_acl_qos_ipv4_hash_key.is_mac_hash0 = FALSE;
    ds_acl_qos_ipv4_hash_key.valid0 = TRUE;
    ds_acl_qos_ipv4_hash_key.hash_type1_low = fib_key_type & 0x1;
    ds_acl_qos_ipv4_hash_key.hash_type1_high = (fib_key_type >> 1) & 0x7;
    ds_acl_qos_ipv4_hash_key.is_mac_hash1 = FALSE;
    ds_acl_qos_ipv4_hash_key.valid1 = TRUE;

    ds_acl_qos_ipv4_hash_key.ip_da = ipda.ip32[0];
    ds_acl_qos_ipv4_hash_key.ip_sa = ipsa.ip32[0];

    ds_acl_qos_ipv4_hash_key.l4_dest_port8_0 = l4_dest_port & 0x1FF;
    ds_acl_qos_ipv4_hash_key.l4_dest_port12_9 = (l4_dest_port >> 9) &0xF;
    ds_acl_qos_ipv4_hash_key.l4_dest_port13 = (l4_dest_port >> 13) & 0x1;
    ds_acl_qos_ipv4_hash_key.l4_dest_port15_14 = (l4_dest_port >> 14) & 0x3;

    ds_acl_qos_ipv4_hash_key.l4_source_port = l4_source_port;
    ds_acl_qos_ipv4_hash_key.global_src_port2_0 = global_src_port & 0x7;
    ds_acl_qos_ipv4_hash_key.global_src_port13_3 = (global_src_port >> 3) & 0x7FF;

    ds_acl_qos_ipv4_hash_key.layer3_header_protocol = l3_header_protocol;

    if (fib_engine_lookup_ctl.ipv4_acl_dscp_en)
    {
        ds_acl_qos_ipv4_hash_key.dscp = dscp;
    }
    else
    {
        ds_acl_qos_ipv4_hash_key.dscp = 0;
    }

    ds_acl_qos_ipv4_hash_key.is_arp_key = is_arp_key;
    ds_acl_qos_ipv4_hash_key.is_ipv4_key = is_ipv4_key;
    ds_acl_qos_ipv4_hash_key.is_logic_port = is_logic_port;

    if (is_add)
    {
        CTC_CLI_GET_UINT32("adindex", ad_index, argv[11]);
        ds_acl_qos_ipv4_hash_key.ds_ad_index15 = (ad_index >> 15) & 0x1;
        ds_acl_qos_ipv4_hash_key.ds_ad_index14_7 = (ad_index >> 7) & 0xFF;
        ds_acl_qos_ipv4_hash_key.ds_ad_index6_0 = ad_index & 0x7F;
        ret = cm_sim_cfg_kit_add_fib_key(chip_id, fib_hash_type, &ds_acl_qos_ipv4_hash_key);
    }
    else
    {
        ret = cm_sim_cfg_kit_delete_fib_key(chip_id, fib_hash_type, &ds_acl_qos_ipv4_hash_key);
    }

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


/* Cmd format: cmodel (add|del) acl-arp chipid CHIP_ID ipda x.x.x.x ipsa x.x.x.x arp-op-code <0-0xFFFF>
 global-src-port <0-0x3FFF> adindex ADINDEX
*/
CTC_CLI(cli_cmodel_fib_acl_arp_key,
    cli_cmodel_fib_acl_arp_key_cmd,
    "cmodel (add|del) acl-arp chipid CHIP_ID ipda IPDA ipsa IPSA arp-op-code ARP_OP_CODE\
    is-logic-port IS_LOGIC_PORT global-src-port GLOBAL_SEC_PORT (adindex ADINDEX|)",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel del cmd",
    "Cmodel acl-ipv4 cmd",
    "chipid",
    "chipid value",
    "IPDA address",
    "IPDA address in A.B.C.D format",
    "IPSA address",
    "IPSA address in A.B.C.D format",
    "arp-op-code",
    "arp op code value",
    "global-src-port",
    "global src port value",
    "associate data index for add",
    "<0-0xFFFF>")
{
    int32  ret = DRV_E_NONE;
    uint8  is_add = FALSE;
    uint8  fib_key_type = FIB_KEY_TYPE_ACL;
    uint8  fib_hash_type = FIB_HASH_TYPE_ACL_IPV4;

    uint32 chip_id = 0;
    cm_ipv4_addr_t ipda;
    cm_ipv4_addr_t ipsa;
    uint16 arp_op_code = 0;
    uint16 global_src_port = 0;
    uint8 is_arp_key = TRUE;
    uint8 is_ipv4_key = TRUE;
    uint8 is_logic_port = FALSE;

    uint32 ad_index = 0;

    ds_acl_qos_ipv4_hash_key_t ds_acl_qos_ipv4_hash_key;
    sal_memset(&ds_acl_qos_ipv4_hash_key, 0, sizeof(ds_acl_qos_ipv4_hash_key));

    if (!sal_memcmp(argv[0], "add", sizeof("add")))
    {
        is_add = TRUE;
    }

    if ((!is_add) && (argc > 7))
    {
        ctc_cli_out("Fail to delete, the adindex is unnecessary.\n");
        return CLI_ERROR;
    }
    else if (is_add && (argc < 9))
    {
        ctc_cli_out("Fail to add, the adindex is necessary.\n");
        return CLI_ERROR;
    }

    CTC_CLI_GET_UINT32("chipid", chip_id, argv[1]);
    chip_id = 0;

    sal_memset(&ipda, 0, sizeof(cm_ipv4_addr_t));
    sal_memset(&ipsa, 0, sizeof(cm_ipv4_addr_t));

    CTC_CLI_GET_IPV4_ADDRESS("ipda", ipda.ip32[0], argv[2]);
    CTC_CLI_GET_IPV4_ADDRESS("ipsa", ipsa.ip32[0], argv[3]);
    CTC_CLI_GET_UINT32("arp-op-code", arp_op_code, argv[4]);
    CTC_CLI_GET_UINT32("is-logic-port", is_logic_port, argv[5]);
    CTC_CLI_GET_UINT32("globalsrcport", global_src_port, argv[6]);

    ds_acl_qos_ipv4_hash_key.hash_type0_low = fib_key_type & 0x1;
    ds_acl_qos_ipv4_hash_key.hash_type0_high = (fib_key_type >> 1) & 0x7;
    ds_acl_qos_ipv4_hash_key.is_mac_hash0 = FALSE;
    ds_acl_qos_ipv4_hash_key.valid0 = TRUE;
    ds_acl_qos_ipv4_hash_key.hash_type1_low = fib_key_type & 0x1;
    ds_acl_qos_ipv4_hash_key.hash_type1_high = (fib_key_type >> 1) & 0x7;
    ds_acl_qos_ipv4_hash_key.is_mac_hash1 = FALSE;
    ds_acl_qos_ipv4_hash_key.valid1 = TRUE;

    ds_acl_qos_ipv4_hash_key.ip_da = ipda.ip32[0];
    ds_acl_qos_ipv4_hash_key.ip_sa = ipsa.ip32[0];

    ds_acl_qos_ipv4_hash_key.l4_dest_port8_0 = 0;
    ds_acl_qos_ipv4_hash_key.l4_dest_port12_9 = 0;
    ds_acl_qos_ipv4_hash_key.l4_dest_port13 = 0;
    ds_acl_qos_ipv4_hash_key.l4_dest_port15_14 = 0;

    ds_acl_qos_ipv4_hash_key.l4_source_port = arp_op_code;
    ds_acl_qos_ipv4_hash_key.global_src_port2_0 = global_src_port & 0x7;
    ds_acl_qos_ipv4_hash_key.global_src_port13_3 = (global_src_port >> 3) & 0x7FF;

    ds_acl_qos_ipv4_hash_key.layer3_header_protocol = 0;
    ds_acl_qos_ipv4_hash_key.dscp = 0;
    ds_acl_qos_ipv4_hash_key.is_arp_key = is_arp_key;
    ds_acl_qos_ipv4_hash_key.is_ipv4_key = is_ipv4_key;
    ds_acl_qos_ipv4_hash_key.is_logic_port = is_logic_port;


    if (is_add)
    {
        CTC_CLI_GET_UINT32("adindex", ad_index, argv[8]);
        ds_acl_qos_ipv4_hash_key.ds_ad_index15 = (ad_index >> 15) & 0x1;
        ds_acl_qos_ipv4_hash_key.ds_ad_index14_7 = (ad_index >> 7) & 0xFF;
        ds_acl_qos_ipv4_hash_key.ds_ad_index6_0 = ad_index & 0x7F;
        ret = cm_sim_cfg_kit_add_fib_key(chip_id, fib_hash_type, &ds_acl_qos_ipv4_hash_key);
    }
    else
    {
        ret = cm_sim_cfg_kit_delete_fib_key(chip_id, fib_hash_type, &ds_acl_qos_ipv4_hash_key);
    }

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}



/* Cmd format: cmodel add queue-hash-key hash-type <0-0x3F> (mcast-disable | mcast-enable)
               channel-id <0-0x3F> service-id <0-0x1FFFF> sgmac <0-0x3> dest-chipid <0-0x1F> dest-queue <0-0x7FFF>
*/
/* hashType[5:0] = {mcastEn, channelIdEn, serviceQueueEn, sgmacEn, destChipidEn, destQueueEn}*/
CTC_CLI(cli_cmodel_add_queue_hash_key,
        cli_cmodel_add_queue_hash_key_cmd,
        "cmodel add queue-hash-key chipid CHIP_ID hash-type <0-63> (mcast-disable | mcast-enable) channel-id <0-63>\
         service-id <0-131071> sgmac <0-63> dest-chipid <0-31> dest-queue <0-32767> queue-base <0-1023>",
        "Cmodel cmd",
        "Cmodel add queue hash key cmd",
        "queue-hash-key",
        "chip id",
        "chip id value",
        "hash-type",
        "hash type vlaue: {mcastEn, channelIdEn, serviceQueueEn, sgmacEn, destChipidEn, destQueueEn}",
        "mcast-disable (key: mcast = 0)",
        "mcast-enable (key: mcast = 1)",
        "channel-id",
        "channel id key value: 0 - 0x3F",
        "service-id",
        "service id key value: 0 - 0x1FFFF",
        "sgmac",
        "sgmac id hashe key vlaue: 0 - 7",
        "dest-chipid",
        "dest chip hash key value: 0 - 0x1F",
        "dest-queue",
        "dest queue hash key value: 0 - 0x7FFF",
        "queue-base",
        "queue base value: 0 - 0x3FF")
{

    int32 ret = DRV_E_NONE;
    uint32 index = 0;
    ds_queue_hash_key_t queue_key;
    uint8 chip_id = 0;

    sal_memset(&queue_key, 0, sizeof(ds_queue_hash_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("hash-type", queue_key.hash_type0, argv[1]);
    queue_key.hash_type1 = queue_key.hash_type0;

    index = ctc_cli_get_prefix_item(&argv[1], argc, "mcast-disable", sal_strlen("mcast-disable"));
    if (0xFF != index)
    {
        queue_key.mcast0 = FALSE;
        index++;
    }
    else
    {
        index = 2;
    }

    CTC_CLI_GET_INTEGER("channel-id", queue_key.channel_id0, argv[index+1]);

    CTC_CLI_GET_INTEGER("service-id", queue_key.service_id0, argv[index+2]);

    CTC_CLI_GET_INTEGER("sgmac", queue_key.sgmac0, argv[index+3]);

    CTC_CLI_GET_INTEGER("dest-chipid", queue_key.dest_chip_id0, argv[index+4]);

    CTC_CLI_GET_INTEGER("dest-queue", queue_key.dest_queue0, argv[index+5]);

    CTC_CLI_GET_INTEGER("queue_base", queue_key.queue_base0, argv[index+6]);
    queue_key.valid0 = TRUE;

    ret = cm_sim_cfg_kit_add_queue_key(chip_id, &queue_key);
#if 0
    if (DRV_E_NONE == ret)
    {
        CMODEL_DEBUG_OUT_INFO("+++++++++++++++++ Add Queue hash +++++++++++++++++\n");
        CMODEL_DEBUG_OUT_INFO("$$$ QueueNumGenControl info:\n");
        CMODEL_DEBUG_OUT_INFO("Note: hashType[5:0] = {mcastEn, channelIdEn\n");
        CMODEL_DEBUG_OUT_INFO("                       serviceQueueEn, sgmacEn\n");
        CMODEL_DEBUG_OUT_INFO("                       destChipidEn, destQueueEn}\n");
        CMODEL_DEBUG_OUT_INFO("hashType     = 0x%x\n", queue_key.hash_type0);
        CMODEL_DEBUG_OUT_INFO("\n");
        CMODEL_DEBUG_OUT_INFO("$$$ Queue Hash Key info:\n");
        CMODEL_DEBUG_OUT_INFO("dest_chip_id = 0x%x\n", queue_key.dest_chip_id0);
        CMODEL_DEBUG_OUT_INFO("dest_queue   = 0x%x\n", queue_key.dest_queue0);
        CMODEL_DEBUG_OUT_INFO("service_id   = 0x%x\n", queue_key.service_id0);
        CMODEL_DEBUG_OUT_INFO("channel_id   = 0x%x\n", queue_key.channel_id0);
        CMODEL_DEBUG_OUT_INFO("sgmac        = 0x%x\n", queue_key.sgmac0);
        CMODEL_DEBUG_OUT_INFO("mcast        = 0x%x\n", queue_key.mcast0);
        CMODEL_DEBUG_OUT_INFO("\n");
        CMODEL_DEBUG_OUT_INFO("$$$ Other info in key:\n");
        CMODEL_DEBUG_OUT_INFO("queue_base    = 0x%x\n", queue_key.queue_base0);
        CMODEL_DEBUG_OUT_INFO("++++++++++++++++++++++++++++++++++++++++++++++++++\n");
        return CLI_SUCCESS;
    }
    else
    {
        return CLI_ERROR;
    }
#endif
 return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_del_queue_hash_key,
        cli_cmodel_del_queue_hash_key_cmd,
        "cmodel del queue-hash-key chipid CHIP_ID hash-type <0-63> (mcast-disable | mcast-enable) channel-id <0-63>\
         service-id <0-131071> sgmac <0-63> dest-chipid <0-31> dest-queue <0-32767>",
        "Cmodel cmd",
        "Cmodel add queue hash key cmd",
        "queue-hash-key",
        "chip id",
        "chip id value",
        "hash-type",
        "hash type vlaue: {mcastEn, channelIdEn, serviceQueueEn, sgmacEn, destChipidEn, destQueueEn}",
        "mcast-disable (key: mcast = 0)",
        "mcast-enable (key: mcast = 1)",
        "channel-id",
        "channel id key value: 0 - 0x3F",
        "service-id",
        "service id key value: 0 - 0x1FFFF",
        "sgmac",
        "sgmac id hashe key vlaue: 0 - 7",
        "dest-chipid",
        "dest chip hash key value: 0 - 0x1F",
        "dest-queue",
        "dest queue hash key value: 0 - 0x7FFF")
{
    int32 ret = DRV_E_NONE;
    uint32 index = 0;
    ds_queue_hash_key_t queue_key;
    uint8 chip_id = 0;

    sal_memset(&queue_key, 0, sizeof(ds_queue_hash_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("hash-type", queue_key.hash_type0, argv[1]);
    queue_key.hash_type1 = queue_key.hash_type0;

    index = ctc_cli_get_prefix_item(&argv[1], argc, "mcast-disable", sal_strlen("mcast-disable"));
    if (0xFF != index)
    {
        queue_key.mcast0 = FALSE;
        index++;
    }
    else
    {
        index = 2;
    }

    CTC_CLI_GET_INTEGER("channel-id", queue_key.channel_id0, argv[index+1]);
    queue_key.channel_id1 = queue_key.channel_id0;

    CTC_CLI_GET_INTEGER("service-id", queue_key.service_id0, argv[index+2]);
    queue_key.service_id1 = queue_key.service_id0;

    CTC_CLI_GET_INTEGER("sgmac", queue_key.sgmac0, argv[index+3]);
    queue_key.sgmac1 = queue_key.sgmac0;

    CTC_CLI_GET_INTEGER("dest-chipid", queue_key.dest_chip_id0, argv[index+4]);
    queue_key.dest_chip_id1 = queue_key.dest_chip_id0;

    CTC_CLI_GET_INTEGER("dest-queue", queue_key.dest_queue0, argv[index+5]);
    queue_key.dest_queue1 = queue_key.dest_queue0;

    queue_key.valid0 = TRUE;
    queue_key.valid1 = TRUE;

    ret = cm_sim_cfg_kit_del_queue_key(chip_id, &queue_key);
    if (DRV_E_NONE == ret)
    {
#if 0
        CMODEL_DEBUG_OUT_INFO("+++++++++++++++++ Delete Queue hash +++++++++++++++\n");
        CMODEL_DEBUG_OUT_INFO("$$$ QueueNumGenControl info:\n");
        CMODEL_DEBUG_OUT_INFO("Note: hashType[5:0] = {mcastEn, channelIdEn\n");
        CMODEL_DEBUG_OUT_INFO("                       serviceQueueEn, sgmacEn\n");
        CMODEL_DEBUG_OUT_INFO("                       destChipidEn, destQueueEn}\n");
        CMODEL_DEBUG_OUT_INFO("hashType     = 0x%x\n", queue_key.hash_type0);
        CMODEL_DEBUG_OUT_INFO("\n");
        CMODEL_DEBUG_OUT_INFO("$$$ Queue Hash Key info:\n");
        CMODEL_DEBUG_OUT_INFO("dest_chip_id = 0x%x\n", queue_key.dest_chip_id0);
        CMODEL_DEBUG_OUT_INFO("dest_queue   = 0x%x\n", queue_key.dest_queue0);
        CMODEL_DEBUG_OUT_INFO("service_id   = 0x%x\n", queue_key.service_id0);
        CMODEL_DEBUG_OUT_INFO("channel_id   = 0x%x\n", queue_key.channel_id0);
        CMODEL_DEBUG_OUT_INFO("sgmac        = 0x%x\n", queue_key.sgmac0);
        CMODEL_DEBUG_OUT_INFO("mcast        = 0x%x\n", queue_key.mcast0);
        CMODEL_DEBUG_OUT_INFO("\n");
        CMODEL_DEBUG_OUT_INFO("++++++++++++++++++++++++++++++++++++++++++++++++++\n");
#endif
        return CLI_SUCCESS;
    }
    else
    {
        return CLI_ERROR;
    }
}

/* Cmd format: cmodel del fdb chipid <chipid> mac <mac_address> fid <fid> */
CTC_CLI(cli_cmodel_fib_mac_key,
    cli_cmodel_fib_mac_key_cmd,
    "cmodel (add|del) fdb chipid CHIPID mac MAC fid FID (adindex INDEX|)",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel del cmd",
    "Cmodel fdb cmd",
    "chipid",
    "chipid value",
    "MAC address",
    "MAC address in HHHH.HHHH.HHHH format",
    "fid or vsi",
    "<0-16383>",
    "associate data index when add",
    "<0-0xFFFF>")
{
    int32 ret = DRV_E_NONE;
    uint8 is_add = FALSE;
    uint32 chip_id = 0;
    uint32 vsi_id = 0;
    uint16 mac_addr[3] = {0};
    uint32 ad_index = 0;
    uint32 cmd = 0;
    ds_mac_hash_key_t ds_mac_hash_key;
    dynamic_ds_fdb_hash_ctl_t dynamic_ds_fdb_hash_ctl;

    if (!sal_memcmp(argv[0], "add", sizeof("add")))
    {
        is_add = TRUE;
    }

    if ((!is_add) && (argc > 4))
    {
        ctc_cli_out("Fail to delete, the adindex is unnecessary.\n");
        return CLI_ERROR;
    }
    else if (is_add && (argc < 6))
    {
        ctc_cli_out("Fail to add, the adindex is necessary.\n");
        return CLI_ERROR;
    }

    sal_memset(&ds_mac_hash_key, 0, sizeof(ds_mac_hash_key_t));
    CTC_CLI_GET_UINT32("chipid", chip_id, argv[1]);
    chip_id = 0;
    sal_memset(&dynamic_ds_fdb_hash_ctl, 0, sizeof(dynamic_ds_fdb_hash_ctl_t));
    cmd = DRV_IOR(DynamicDsFdbHashCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &dynamic_ds_fdb_hash_ctl));

    if (3 != sal_sscanf(argv[2], "%4hx.%4hx.%4hx", &mac_addr[2], &mac_addr[1], &mac_addr[0]))
    {
        ctc_cli_out("%% CLI get MAC address ERROR! Input MAC address %s\n", argv[1]);
        return CLI_ERROR;
    }

    CTC_CLI_GET_UINT32("fid", vsi_id, argv[3]);
    vsi_id = vsi_id & 0x3FFF;

    ds_mac_hash_key.mapped_mac47_32 = mac_addr[2];
    ds_mac_hash_key.mapped_mac31_0 = (mac_addr[1] << 16) | mac_addr[0];
    ds_mac_hash_key.is_mac_hash = TRUE;

    if (is_add)
    {
        CTC_CLI_GET_UINT32("adindex", ad_index, argv[5]);
    }

    if ((dynamic_ds_fdb_hash_ctl.ad_bits_type) && (IS_BIT_SET(vsi_id, 13)))
    {
        ctc_cli_out("%s %d CLI get vsi ERROR! 16bits ad-index is enabled, max vsi value is 0x1FFFF\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    if ((!dynamic_ds_fdb_hash_ctl.ad_bits_type) && (IS_BIT_SET(ad_index, 15)))
    {
        ctc_cli_out("%s %d CLI get vsi ERROR! 16bits ad-index is disabled, max ad-index value is 0x7FFF %s\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    ds_mac_hash_key.vsi_id = vsi_id;

    if (IS_BIT_SET(ad_index, 15))
    {
        SET_BIT(ds_mac_hash_key.vsi_id, 13);
    }
    ds_mac_hash_key.ds_ad_index1_0 = ad_index & 0x3;
    ds_mac_hash_key.ds_ad_index2_2 = (ad_index >> 2) & 0x1;
    ds_mac_hash_key.ds_ad_index14_3 = (ad_index >> 3) & 0xFFF;
    ds_mac_hash_key.valid = TRUE;

    if (is_add)
    {
        ret = cm_sim_cfg_kit_add_fib_key(chip_id, FIB_HASH_TYPE_MAC, &ds_mac_hash_key);
    }
    else
    {
        ret = cm_sim_cfg_kit_delete_fib_key(chip_id, FIB_HASH_TYPE_MAC, &ds_mac_hash_key);
    }

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_ipv4_mcast,
    cli_cmodel_add_ipv4_mcast_cmd,
    "ipv4-mcast add ({chip-id CHIPID} | ) ({ismac ISMAC} | ) ipda A.B.C.D ipsa A.B.C.D vrfid VRF_ID nexthop NEXTHOP ",
    "Cmodel cmd",
    "add ipv4-mcast route",
    "chipid",
    "chipid value",
    "ismac",
    "is mac",
    "ip da",
    "A.B.C.D",
    "ip sa",
    "A.B.C.D (0.0.0.0 means (* G))",
    "vrfid",
    "(0~0x3FFF)",
    "nexthop",
    "(0~0xFFFF)")
{
    uint32 nexthop = 0;
    cm_ipv4_addr_t ipda;
    cm_ipv4_addr_t ipsa;
    int32 vrf_id = 0;
    uint32 chip_id = 0;
    uint32 index1 = 0;
    uint32 index2 = 0;
    uint32 is_mac = FALSE;

    ds_lpm_ipv4_mcast_hash32_key_t ds_lpm_ipv4_mcast_hash32_key;
    ds_lpm_ipv4_mcast_hash64_key_t ds_lpm_ipv4_mcast_hash64_key;

    sal_memset(&ds_lpm_ipv4_mcast_hash32_key, 0, sizeof(ds_lpm_ipv4_mcast_hash32_key_t));
    sal_memset(&ds_lpm_ipv4_mcast_hash64_key, 0, sizeof(ds_lpm_ipv4_mcast_hash64_key_t));

    sal_memset(&ipda, 0, sizeof(cm_ipv4_addr_t));
    sal_memset(&ipsa, 0, sizeof(cm_ipv4_addr_t));

    index1 = ctc_cli_get_prefix_item(&argv[0], argc, "chip-id", sal_strlen("chip-id"));

    if (index1 != 0xFF)
    {
        CTC_CLI_GET_UINT32("chip-id", chip_id, argv[index1 + 1]);
        chip_id = 0;
        index1 += 2;
    }
    else
    {
        chip_id = 0;
        index1 = 0;
    }

    index2 = ctc_cli_get_prefix_item(&argv[0], argc, "ismac", sal_strlen("ismac"));

    if (index2 != 0xFF)
    {
        CTC_CLI_GET_UINT32("ismac", is_mac, argv[index2 + 1]);
        index2 = index1 + 2;
    }
    else
    {
        is_mac = 0;
        index2 = index1;
    }

    CTC_CLI_GET_IPV4_ADDRESS("ipda", ipda.ip32[0], argv[index2 + 0]);
    CTC_CLI_GET_IPV4_ADDRESS("ipsa", ipsa.ip32[0], argv[index2 + 1]);
    CTC_CLI_GET_INTEGER("vrfid", vrf_id, argv[index2 + 2]);
    CTC_CLI_GET_INTEGER("nexthop", nexthop, argv[index2+3]);

    if (0 == ipsa.ip32[0])
    {
        ds_lpm_ipv4_mcast_hash32_key.hash_type = LPM_HASH_TYPE_IPV4_XG;
        ds_lpm_ipv4_mcast_hash32_key.ip_da = ipda.ip32[0];
        ds_lpm_ipv4_mcast_hash32_key.vrf_id = vrf_id;
        ds_lpm_ipv4_mcast_hash32_key.nexthop = nexthop;
        ds_lpm_ipv4_mcast_hash32_key.valid = TRUE;
        ds_lpm_ipv4_mcast_hash32_key.is_mac = is_mac;
        DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_add_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV4_XG, &ds_lpm_ipv4_mcast_hash32_key));
    }
    else
    {
        ds_lpm_ipv4_mcast_hash64_key.hash_type0 = LPM_HASH_TYPE_IPV4_SG;
        ds_lpm_ipv4_mcast_hash64_key.hash_type1 = LPM_HASH_TYPE_IPV4_SG;
        ds_lpm_ipv4_mcast_hash64_key.ip_da = ipda.ip32[0];
        ds_lpm_ipv4_mcast_hash64_key.ip_sa = ipsa.ip32[0];
        ds_lpm_ipv4_mcast_hash64_key.vrf_id = vrf_id;
        ds_lpm_ipv4_mcast_hash64_key.nexthop = nexthop;
        ds_lpm_ipv4_mcast_hash64_key.valid0 = TRUE;
        ds_lpm_ipv4_mcast_hash64_key.valid1 = TRUE;
        ds_lpm_ipv4_mcast_hash64_key.is_mac = is_mac;
        DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_add_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV4_SG, &ds_lpm_ipv4_mcast_hash64_key));
    }
    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_del_ipv4_mcast,
    cli_cmodel_del_ipv4_mcast_cmd,
    "ipv4-mcast del ({chipid CHIPID} | ) ({ismac ISMAC} | ) ipda A.B.C.D ipsa A.B.C.D vrfid VRF_ID",
    "Cmodel cmd",
    "add ipv4-mcast route",
    "chipid",
    "chipid value",
    "ismac",
    "is mac",
    "ip da",
    "A.B.C.D",
    "ip sa",
    "A.B.C.D (0.0.0.0 means (* G))",
    "vrfid",
    "(0~0x3FFF)")
{
    cm_ipv4_addr_t ipda;
    cm_ipv4_addr_t ipsa;
    int32 vrf_id = 0;
    uint32 chip_id = 0;
    uint32 index1 = 0;
    uint32 index2 = 0;
    uint32 is_mac = FALSE;

    ds_lpm_ipv4_mcast_hash32_key_t ds_lpm_ipv4_mcast_hash32_key;
    ds_lpm_ipv4_mcast_hash64_key_t ds_lpm_ipv4_mcast_hash64_key;

    sal_memset(&ds_lpm_ipv4_mcast_hash32_key, 0, sizeof(ds_lpm_ipv4_mcast_hash32_key_t));
    sal_memset(&ds_lpm_ipv4_mcast_hash64_key, 0, sizeof(ds_lpm_ipv4_mcast_hash64_key_t));

    sal_memset(&ipda, 0, sizeof(cm_ipv4_addr_t));
    sal_memset(&ipsa, 0, sizeof(cm_ipv4_addr_t));

    index1 = ctc_cli_get_prefix_item(&argv[0], argc, "chip-id", sal_strlen("chip-id"));

    if (index1 != 0xFF)
    {
        CTC_CLI_GET_UINT32("chip-id", chip_id, argv[index1 + 1]);
        chip_id = 0;
        index1 += 2;
    }
    else
    {
        chip_id = 0;
        index1 = 0;
    }

    index2 = ctc_cli_get_prefix_item(&argv[0], argc, "ismac", sal_strlen("ismac"));

    if (index2 != 0xFF)
    {
        CTC_CLI_GET_UINT32("ismac", is_mac, argv[index2 + 1]);
        index2 = index1 + 2;
    }
    else
    {
        is_mac = 0;
        index2 = index1;
    }

    CTC_CLI_GET_IPV4_ADDRESS("ipda", ipda.ip32[0], argv[index2+0]);
    CTC_CLI_GET_IPV4_ADDRESS("ipsa", ipsa.ip32[0], argv[index2+1]);
    CTC_CLI_GET_INTEGER("vrfid", vrf_id, argv[index2+2]);

    if (0 == ipsa.ip32[0])
    {
        ds_lpm_ipv4_mcast_hash32_key.hash_type = LPM_HASH_TYPE_IPV4_XG;
        ds_lpm_ipv4_mcast_hash32_key.ip_da = ipda.ip32[0];
        ds_lpm_ipv4_mcast_hash32_key.vrf_id = vrf_id;
        ds_lpm_ipv4_mcast_hash32_key.valid = TRUE;
        ds_lpm_ipv4_mcast_hash32_key.is_mac = is_mac;
        DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_delete_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV4_XG, &ds_lpm_ipv4_mcast_hash32_key));
    }
    else
    {
        ds_lpm_ipv4_mcast_hash64_key.hash_type0 = LPM_HASH_TYPE_IPV4_SG;
        ds_lpm_ipv4_mcast_hash64_key.hash_type1 = LPM_HASH_TYPE_IPV4_SG;
        ds_lpm_ipv4_mcast_hash64_key.ip_da = ipda.ip32[0];
        ds_lpm_ipv4_mcast_hash64_key.ip_sa = ipsa.ip32[0];
        ds_lpm_ipv4_mcast_hash64_key.vrf_id = vrf_id;
        ds_lpm_ipv4_mcast_hash64_key.valid0 = TRUE;
        ds_lpm_ipv4_mcast_hash64_key.valid1 = TRUE;
        ds_lpm_ipv4_mcast_hash64_key.is_mac = is_mac;
        DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_delete_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV4_SG, &ds_lpm_ipv4_mcast_hash64_key));
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_ipv4_nat_sa,
    cli_cmodel_add_ipv4_nat_sa_cmd,
    "ipv4-nat-sa add ({chip-id CHIPID} | ) ipsa A.B.C.D vrfid VRF_ID nexthop NEXTHOP",
    "Cmodel cmd",
    "add ipv4-nat route",
    "chip id",
    "chip id value",
    "ip sa",
    "A.B.C.D",
    "vrfid",
    "(0~0x3FFF)",
    "nexthop",
    "(0~0xFFFF)")
{
    uint32 nexthop = 0;
    cm_ipv4_addr_t ipsa;
    uint16 vrf_id = 0;
    uint8 chipid = 2;
    uint32 index = 0;

    ds_lpm_ipv4_nat_sa_hash_key_t ds_lpm_ipv4_nat_sa_hash_key;

    sal_memset(&ipsa, 0, sizeof(cm_ipv4_addr_t));
    sal_memset(&ds_lpm_ipv4_nat_sa_hash_key, 0, sizeof(ds_lpm_ipv4_nat_sa_hash_key_t));

    index = ctc_cli_get_prefix_item(&argv[0], argc, "chip-id", sal_strlen("chip-id"));

    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("chip-id", chipid, argv[index + 1]);
        index += 2;
    }
    else
    {
        chipid = 2;
        index = 0;
    }
    CTC_CLI_GET_IPV4_ADDRESS("ipsa", ipsa.ip32[0], argv[index + 0]);
    CTC_CLI_GET_INTEGER("vrfid", vrf_id, argv[index + 1]);
    CTC_CLI_GET_INTEGER("nexthop", nexthop, argv[index +2]);

    ds_lpm_ipv4_nat_sa_hash_key.valid = TRUE;
    ds_lpm_ipv4_nat_sa_hash_key.hash_type = LPM_HASH_TYPE_IPV4_NAT_SA;
    ds_lpm_ipv4_nat_sa_hash_key.type = LPM_HASH_KEY_TYPE_NEXTHOP;
    ds_lpm_ipv4_nat_sa_hash_key.ip_sa = ipsa.ip32[0];
    ds_lpm_ipv4_nat_sa_hash_key.vrf_id0 = vrf_id & 0xFF;
    ds_lpm_ipv4_nat_sa_hash_key.vrf_id1 = (vrf_id >> 8) & 0x3F;
    ds_lpm_ipv4_nat_sa_hash_key.nexthop = nexthop;

    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_add_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV4_NAT_SA, &ds_lpm_ipv4_nat_sa_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_ipv6_nat_sa,
            cli_cmodel_add_ipv6_nat_sa_cmd,
            "ipv6-nat-sa add chipid CHIP_ID ipsa X:X::X:X nexthop NEXTHOP",
            "Cmodel cmd",
            "add ipv6-nat route",
            "chip id",
            "chip id value",
            "ipv6 ip sa",
            CTC_CLI_IPV6_FORMAT,
            "nexthop",
            "(0~0xFFFF)")
{
    uint32 nexthop = 0;
    uint32 chipid = 0;
    uint32* ip32 = NULL;
    cm_ipv6_addr_t ipv6_address;
    ds_lpm_ipv6_nat_sa_hash_key_t ds_lpm_ipv6_nat_sa_hash_key;

    sal_memset(&ipv6_address, 0, sizeof(cm_ipv6_addr_t));
    sal_memset(&ds_lpm_ipv6_nat_sa_hash_key, 0, sizeof(ds_lpm_ipv6_nat_sa_hash_key_t));

    CTC_CLI_GET_UINT32("chipid", chipid, argv[0]);
    chipid = 0;
    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address.ip32, argv[1]);
    CTC_CLI_GET_INTEGER("nexthop", nexthop, argv[2]);

    ipv6_address.ip32[3] = sal_htonl(ipv6_address.ip32[3]);
    ipv6_address.ip32[2] = sal_htonl(ipv6_address.ip32[2]);
    ipv6_address.ip32[1] = sal_htonl(ipv6_address.ip32[1]);
    ipv6_address.ip32[0] = sal_htonl(ipv6_address.ip32[0]);

    ip32 = ipv6_address.ip32;
    ds_lpm_ipv6_nat_sa_hash_key.valid0 = TRUE;
    ds_lpm_ipv6_nat_sa_hash_key.valid1 = TRUE;
    ds_lpm_ipv6_nat_sa_hash_key.hash_type0 = LPM_HASH_TYPE_IPV6_NAT_SA;
    ds_lpm_ipv6_nat_sa_hash_key.hash_type1 = LPM_HASH_TYPE_IPV6_NAT_SA;
    ds_lpm_ipv6_nat_sa_hash_key.type = LPM_HASH_KEY_TYPE_NEXTHOP;
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa31_0 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_96_103),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_104_111),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_112_119),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_120_127));
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa47_32 = MAKE_UINT16(CM_ROCTO(ip32, CM_IP_OCTO_80_87),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_88_95));
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa79_48 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_48_55),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_56_63),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_64_71),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_72_79));
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa111_80 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_16_23),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_24_31),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_32_39),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_40_47));
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa119_112 = CM_ROCTO(ip32, CM_IP_OCTO_8_15);
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa127_120 = CM_ROCTO(ip32, CM_IP_OCTO_0_7);
    ds_lpm_ipv6_nat_sa_hash_key.nexthop = nexthop;

    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_add_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV6_NAT_SA, &ds_lpm_ipv6_nat_sa_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_del_ipv6_nat_sa,
            cli_cmodel_del_ipv6_nat_sa_cmd,
            "ipv6-nat-sa del chipid CHIP_ID ipsa X:X::X:X",
            "Cmodel cmd",
            "del ipv6-nat route",
            "chip id",
            "chip id value",
            "ipv6 ip sa",
            CTC_CLI_IPV6_FORMAT)
{
    uint32 chipid = 0;
    uint32* ip32 = NULL;
    cm_ipv6_addr_t ipv6_address;
    ds_lpm_ipv6_nat_sa_hash_key_t ds_lpm_ipv6_nat_sa_hash_key;

    sal_memset(&ipv6_address, 0, sizeof(cm_ipv6_addr_t));
    sal_memset(&ds_lpm_ipv6_nat_sa_hash_key, 0, sizeof(ds_lpm_ipv6_nat_sa_hash_key_t));

    CTC_CLI_GET_UINT32("chipid", chipid, argv[0]);
    chipid = 0;
    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address.ip32, argv[1]);

    ip32 = ipv6_address.ip32;
    ds_lpm_ipv6_nat_sa_hash_key.valid0 = TRUE;
    ds_lpm_ipv6_nat_sa_hash_key.valid1 = TRUE;
    ds_lpm_ipv6_nat_sa_hash_key.hash_type0 = LPM_HASH_TYPE_IPV6_NAT_SA;
    ds_lpm_ipv6_nat_sa_hash_key.hash_type1 = LPM_HASH_TYPE_IPV6_NAT_SA;
    ds_lpm_ipv6_nat_sa_hash_key.type = LPM_HASH_KEY_TYPE_NEXTHOP;
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa31_0 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_24_31),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_16_23),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_8_15),
                                                        CM_ROCTO(ip32, CM_IP_OCTO_0_7));
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa47_32 = MAKE_UINT16(CM_ROCTO(ip32, CM_IP_OCTO_40_47),
                                                         CM_ROCTO(ip32, CM_IP_OCTO_32_39));
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa79_48 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_72_79),
                                                         CM_ROCTO(ip32, CM_IP_OCTO_64_71),
                                                         CM_ROCTO(ip32, CM_IP_OCTO_56_63),
                                                         CM_ROCTO(ip32, CM_IP_OCTO_48_55));
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa111_80 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_104_111),
                                                         CM_ROCTO(ip32, CM_IP_OCTO_96_103),
                                                         CM_ROCTO(ip32, CM_IP_OCTO_88_95),
                                                         CM_ROCTO(ip32, CM_IP_OCTO_80_87));
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa119_112 = CM_ROCTO(ip32, CM_IP_OCTO_112_119);
    ds_lpm_ipv6_nat_sa_hash_key.ip_sa127_120 = CM_ROCTO(ip32, CM_IP_OCTO_120_127);

    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_delete_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV6_NAT_SA, &ds_lpm_ipv6_nat_sa_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_ipv6_nat_sa_port,
            cli_cmodel_add_ipv6_nat_sa_port_cmd,
            "ipv6-nat-sa-port add chipid CHIP_ID ipsa X:X::X:X layer4-port-type PORT_TYPE port PORT nexthop NEXTHOP",
            "Cmodel cmd",
            "add ipv6-nat-sa-port route",
            "chip id",
            "chip id value",
            "ipv6 ip sa",
            CTC_CLI_IPV6_FORMAT,
            "layer4-port-type",
            "3:TCP, 2:UDP",
            "layer4 src port",
            "layer4 src port value",
            "nexthop",
            "(0~0xFFFF)")
{
    uint32* ip32 = NULL;
    uint32 nexthop = 0;
    uint32 chipid = 0;
    uint32 port = 0;
    uint32 cmd = 0;
    uint32 layer4_port_type = 0;
    uint16 ipv6_sa_prefix = 0;

    cm_ipv6_addr_t ipv6_address;
    ds_lpm_ipv6_nat_sa_port_hash_key_t ds_lpm_ipv6_nat_sa_port_hash_key;
    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;

    sal_memset(&ipv6_address, 0, sizeof(cm_ipv6_addr_t));
    sal_memset(&ds_lpm_ipv6_nat_sa_port_hash_key, 0, sizeof(ds_lpm_ipv6_nat_sa_port_hash_key_t));
    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));

    CTC_CLI_GET_UINT32("chipid", chipid, argv[0]);
    chipid = 0;
    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address.ip32, argv[1]);
    CTC_CLI_GET_UINT32("port-type", layer4_port_type, argv[2]);
    CTC_CLI_GET_UINT32("port", port, argv[3]);
    CTC_CLI_GET_INTEGER("nexthop", nexthop, argv[4]);

    if ((2 != layer4_port_type) && (3 != layer4_port_type))
    {
        sal_printf("%s %d:layer4 port type error!\n", __FUNCTION__, __LINE__);
        return CLI_SUCCESS;
    }
    else
    {
        ds_lpm_ipv6_nat_sa_port_hash_key.l4_port_type = layer4_port_type;
    }
    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));
    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(2, 0, cmd, &fib_engine_lookup_ctl));

    ipv6_address.ip32[3] = sal_htonl(ipv6_address.ip32[3]);
    ipv6_address.ip32[2] = sal_htonl(ipv6_address.ip32[2]);
    ipv6_address.ip32[1] = sal_htonl(ipv6_address.ip32[1]);
    ipv6_address.ip32[0] = sal_htonl(ipv6_address.ip32[0]);

    ip32 = ipv6_address.ip32;
    ds_lpm_ipv6_nat_sa_port_hash_key.valid0 = TRUE;
    ds_lpm_ipv6_nat_sa_port_hash_key.valid1 = TRUE;
    ds_lpm_ipv6_nat_sa_port_hash_key.hash_type0 = LPM_HASH_TYPE_IPV6_NAT_SA_PORT;
    ds_lpm_ipv6_nat_sa_port_hash_key.hash_type1 = LPM_HASH_TYPE_IPV6_NAT_SA_PORT;
    ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa31_0 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_96_103),
                                                                CM_ROCTO(ip32, CM_IP_OCTO_104_111),
                                                                CM_ROCTO(ip32, CM_IP_OCTO_112_119),
                                                                CM_ROCTO(ip32, CM_IP_OCTO_120_127));
    ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa47_32 = MAKE_UINT16(CM_ROCTO(ip32, CM_IP_OCTO_80_87),
                                                                CM_ROCTO(ip32, CM_IP_OCTO_88_95));
    ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa79_48 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_48_55),
                                                                CM_ROCTO(ip32, CM_IP_OCTO_56_63),
                                                                CM_ROCTO(ip32, CM_IP_OCTO_64_71),
                                                                CM_ROCTO(ip32, CM_IP_OCTO_72_79));
    ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa111_80 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_16_23),
                                                                CM_ROCTO(ip32, CM_IP_OCTO_24_31),
                                                                CM_ROCTO(ip32, CM_IP_OCTO_32_39),
                                                                CM_ROCTO(ip32, CM_IP_OCTO_40_47));
    ds_lpm_ipv6_nat_sa_port_hash_key.l4_source_port7_0 = port;
    ds_lpm_ipv6_nat_sa_port_hash_key.l4_source_port15_8 = (port >> 8) & 0xFF;
    ds_lpm_ipv6_nat_sa_port_hash_key.nexthop = nexthop;

    ipv6_sa_prefix = MAKE_UINT16(CM_ROCTO(ip32, CM_IP_OCTO_0_7), CM_ROCTO(ip32, CM_IP_OCTO_8_15));

    if (fib_engine_lookup_ctl.ipv6_sa0_prefix0 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 0;
    }
    else if (fib_engine_lookup_ctl.ipv6_sa0_prefix1 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 1;
    }
    else if (fib_engine_lookup_ctl.ipv6_sa0_prefix2 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 2;
    }
    else
    {
        ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 3;
    }

    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_add_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV6_NAT_SA_PORT, &ds_lpm_ipv6_nat_sa_port_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_del_ipv6_nat_sa_port,
            cli_cmodel_del_ipv6_nat_sa_port_cmd,
            "ipv6-nat-sa-port del chipid CHIP_ID ipsa X:X::X:X port PORT",
            "Cmodel cmd",
            "del ipv6-nat-sa-port route",
            "chip id",
            "chip id value",
            "ipv6 ip sa",
            CTC_CLI_IPV6_FORMAT,
            "layer4 src port",
            "layer4 src port value")
{
    uint32* ip32 = NULL;
    uint32 chipid = 0;
    uint32 port = 0;
    uint32 cmd = 0;
    uint16 ipv6_sa_prefix = 0;

    cm_ipv6_addr_t ipv6_address;
    ds_lpm_ipv6_nat_sa_port_hash_key_t ds_lpm_ipv6_nat_sa_port_hash_key;
    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;

    sal_memset(&ipv6_address, 0, sizeof(cm_ipv6_addr_t));
    sal_memset(&ds_lpm_ipv6_nat_sa_port_hash_key, 0, sizeof(ds_lpm_ipv6_nat_sa_port_hash_key_t));
    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));

    CTC_CLI_GET_UINT32("chipid", chipid, argv[0]);
    chipid = 0;
    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address.ip32, argv[1]);
    CTC_CLI_GET_UINT32("port", port, argv[2]);

    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));
    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(2, 0, cmd, &fib_engine_lookup_ctl));

    ip32 = ipv6_address.ip32;
    ds_lpm_ipv6_nat_sa_port_hash_key.valid0 = TRUE;
    ds_lpm_ipv6_nat_sa_port_hash_key.valid1 = TRUE;
    ds_lpm_ipv6_nat_sa_port_hash_key.hash_type0 = LPM_HASH_TYPE_IPV6_NAT_SA_PORT;
    ds_lpm_ipv6_nat_sa_port_hash_key.hash_type1 = LPM_HASH_TYPE_IPV6_NAT_SA_PORT;
    ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa31_0 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_24_31),
                                                             CM_ROCTO(ip32, CM_IP_OCTO_16_23),
                                                             CM_ROCTO(ip32, CM_IP_OCTO_8_15),
                                                             CM_ROCTO(ip32, CM_IP_OCTO_0_7));
    ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa47_32 = MAKE_UINT16(CM_ROCTO(ip32, CM_IP_OCTO_40_47),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_32_39));
    ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa79_48 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_72_79),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_64_71),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_56_63),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_48_55));
    ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa111_80 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_104_111),
                                                               CM_ROCTO(ip32, CM_IP_OCTO_96_103),
                                                               CM_ROCTO(ip32, CM_IP_OCTO_88_95),
                                                               CM_ROCTO(ip32, CM_IP_OCTO_80_87));
    ds_lpm_ipv6_nat_sa_port_hash_key.l4_source_port7_0 = port;
    ds_lpm_ipv6_nat_sa_port_hash_key.l4_source_port15_8 = (port >> 8) & 0xFF;

    ipv6_sa_prefix = MAKE_UINT16(CM_IP_OCTO_120_127, CM_IP_OCTO_112_119);

    if (fib_engine_lookup_ctl.ipv6_sa0_prefix0 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 0;
    }
    else if (fib_engine_lookup_ctl.ipv6_sa0_prefix1 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 1;
    }
    else if (fib_engine_lookup_ctl.ipv6_sa0_prefix2 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 2;
    }
    else
    {
        ds_lpm_ipv6_nat_sa_port_hash_key.ip_sa_prefix_index = 3;
    }

    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_delete_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV6_NAT_SA_PORT, &ds_lpm_ipv6_nat_sa_port_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_ipv6_nat_da_port,
            cli_cmodel_add_ipv6_nat_da_port_cmd,
            "ipv6-nat-da-port add chipid CHIP_ID ipda X:X::X:X layer4-port-type PORT_TYPE port PORT nexthop NEXTHOP",
            "Cmodel cmd",
            "add ipv6-nat-da-port route",
            "chip id",
            "chip id value",
            "ipv6 ip da",
            CTC_CLI_IPV6_FORMAT,
            "layer4-port-type",
            "3:TCP, 2:UDP, 0:otherwise",
            "layer4 dest port",
            "layer4 dest port value",
            "nexthop",
            "(0~0xFFFF)")
{
    uint32* ip32 = NULL;
    uint16 ipv6_sa_prefix = 0;
    uint32 nexthop = 0;
    uint32 chipid = 0;
    uint32 port = 0;
    uint32 cmd = 0;
    uint32 layer4_port_type = 0;

    cm_ipv6_addr_t ipv6_address;
    ds_lpm_ipv6_nat_da_port_hash_key_t ds_lpm_ipv6_nat_da_port_hash_key;
    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;

    sal_memset(&ipv6_address, 0, sizeof(cm_ipv6_addr_t));
    sal_memset(&ds_lpm_ipv6_nat_da_port_hash_key, 0, sizeof(ds_lpm_ipv6_nat_da_port_hash_key_t));
    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));

    CTC_CLI_GET_UINT32("chipid", chipid, argv[0]);
    chipid = 0;
    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address.ip32, argv[1]);
    CTC_CLI_GET_UINT32("port-type", layer4_port_type, argv[2]);
    CTC_CLI_GET_UINT32("port", port, argv[3]);
    CTC_CLI_GET_INTEGER("nexthop", nexthop, argv[4]);

    if ((2 != layer4_port_type) && (3 != layer4_port_type) && (0 != layer4_port_type))
    {
        sal_printf("%s %d:layer4 port type error!\n", __FUNCTION__, __LINE__);
        return CLI_SUCCESS;
    }
    else
    {
        ds_lpm_ipv6_nat_da_port_hash_key.l4_port_type = layer4_port_type;
    }

    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));
    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(2, 0, cmd, &fib_engine_lookup_ctl));

    ipv6_address.ip32[3] = sal_htonl(ipv6_address.ip32[3]);
    ipv6_address.ip32[2] = sal_htonl(ipv6_address.ip32[2]);
    ipv6_address.ip32[1] = sal_htonl(ipv6_address.ip32[1]);
    ipv6_address.ip32[0] = sal_htonl(ipv6_address.ip32[0]);

    ip32 = ipv6_address.ip32;
    ds_lpm_ipv6_nat_da_port_hash_key.valid0 = TRUE;
    ds_lpm_ipv6_nat_da_port_hash_key.valid1 = TRUE;
    ds_lpm_ipv6_nat_da_port_hash_key.hash_type0 = LPM_HASH_TYPE_IPV6_NAT_DA_PORT;
    ds_lpm_ipv6_nat_da_port_hash_key.hash_type1 = LPM_HASH_TYPE_IPV6_NAT_DA_PORT;

    ds_lpm_ipv6_nat_da_port_hash_key.ip_da31_0 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_96_103),
                                                             CM_ROCTO(ip32, CM_IP_OCTO_104_111),
                                                             CM_ROCTO(ip32, CM_IP_OCTO_112_119),
                                                             CM_ROCTO(ip32, CM_IP_OCTO_120_127));

    ds_lpm_ipv6_nat_da_port_hash_key.ip_da47_32 = MAKE_UINT16(CM_ROCTO(ip32, CM_IP_OCTO_80_87),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_88_95));

    ds_lpm_ipv6_nat_da_port_hash_key.ip_da79_48 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_48_55),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_56_63),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_64_71),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_72_79));

    ds_lpm_ipv6_nat_da_port_hash_key.ip_da111_80 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_16_23),
                                                               CM_ROCTO(ip32, CM_IP_OCTO_24_31),
                                                               CM_ROCTO(ip32, CM_IP_OCTO_32_39),
                                                               CM_ROCTO(ip32, CM_IP_OCTO_40_47));
    ds_lpm_ipv6_nat_da_port_hash_key.l4_dest_port7_0 = port;
    ds_lpm_ipv6_nat_da_port_hash_key.l4_dest_port15_8 = (port >> 8) & 0xFF;
    ds_lpm_ipv6_nat_da_port_hash_key.nexthop = nexthop;
    ipv6_sa_prefix = MAKE_UINT16(CM_ROCTO(ip32, CM_IP_OCTO_0_7), CM_ROCTO(ip32, CM_IP_OCTO_8_15));

    if (fib_engine_lookup_ctl.ipv6_sa0_prefix0 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 0;
    }
    else if (fib_engine_lookup_ctl.ipv6_sa0_prefix1 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 1;
    }
    else if (fib_engine_lookup_ctl.ipv6_sa0_prefix2 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 2;
    }
    else
    {
        ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 3;
    }

    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_add_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV6_NAT_DA_PORT, &ds_lpm_ipv6_nat_da_port_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_del_ipv6_nat_da_port,
            cli_cmodel_del_ipv6_nat_da_port_cmd,
            "ipv6-nat-da-port del chipid CHIP_ID ipda X:X::X:X port PORT",
            "Cmodel cmd",
            "del ipv6-nat-da-port route",
            "chip id",
            "chip id value",
            "ipv6 ip da",
            CTC_CLI_IPV6_FORMAT,
            "layer4 dest port",
            "layer4 dest port value")
{
    uint32 cmd = 0;
    uint32 chipid = 0;
    uint32 port = 0;
    uint32* ip32 = NULL;
    uint16 ipv6_sa_prefix = 0;
    cm_ipv6_addr_t ipv6_address;
    ds_lpm_ipv6_nat_da_port_hash_key_t ds_lpm_ipv6_nat_da_port_hash_key;
    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;

    sal_memset(&ipv6_address, 0, sizeof(cm_ipv6_addr_t));
    sal_memset(&ds_lpm_ipv6_nat_da_port_hash_key, 0, sizeof(ds_lpm_ipv6_nat_da_port_hash_key_t));

    CTC_CLI_GET_UINT32("chipid", chipid, argv[0]);
    chipid = 0;
    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address.ip32, argv[1]);
    CTC_CLI_GET_UINT32("port", port, argv[2]);

    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));
    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(2, 0, cmd, &fib_engine_lookup_ctl));

    ipv6_address.ip32[3] = sal_htonl(ipv6_address.ip32[3]);
    ipv6_address.ip32[2] = sal_htonl(ipv6_address.ip32[2]);
    ipv6_address.ip32[1] = sal_htonl(ipv6_address.ip32[1]);
    ipv6_address.ip32[0] = sal_htonl(ipv6_address.ip32[0]);

    ip32 = ipv6_address.ip32;
    ds_lpm_ipv6_nat_da_port_hash_key.valid0 = TRUE;
    ds_lpm_ipv6_nat_da_port_hash_key.valid1 = TRUE;
    ds_lpm_ipv6_nat_da_port_hash_key.hash_type0 = LPM_HASH_TYPE_IPV6_NAT_DA_PORT;
    ds_lpm_ipv6_nat_da_port_hash_key.hash_type1 = LPM_HASH_TYPE_IPV6_NAT_DA_PORT;

    ds_lpm_ipv6_nat_da_port_hash_key.ip_da31_0 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_96_103),
                                                             CM_ROCTO(ip32, CM_IP_OCTO_104_111),
                                                             CM_ROCTO(ip32, CM_IP_OCTO_112_119),
                                                             CM_ROCTO(ip32, CM_IP_OCTO_120_127));

    ds_lpm_ipv6_nat_da_port_hash_key.ip_da47_32 = MAKE_UINT16(CM_ROCTO(ip32, CM_IP_OCTO_80_87),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_88_95));

    ds_lpm_ipv6_nat_da_port_hash_key.ip_da79_48 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_48_55),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_56_63),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_64_71),
                                                              CM_ROCTO(ip32, CM_IP_OCTO_72_79));

    ds_lpm_ipv6_nat_da_port_hash_key.ip_da111_80 = MAKE_UINT32(CM_ROCTO(ip32, CM_IP_OCTO_16_23),
                                                               CM_ROCTO(ip32, CM_IP_OCTO_24_31),
                                                               CM_ROCTO(ip32, CM_IP_OCTO_32_39),
                                                               CM_ROCTO(ip32, CM_IP_OCTO_40_47));

    ipv6_sa_prefix = MAKE_UINT16(CM_ROCTO(ip32, CM_IP_OCTO_0_7), CM_ROCTO(ip32, CM_IP_OCTO_8_15));

    if (fib_engine_lookup_ctl.ipv6_sa0_prefix0 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 0;
    }
    else if (fib_engine_lookup_ctl.ipv6_sa0_prefix1 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 1;
    }
    else if (fib_engine_lookup_ctl.ipv6_sa0_prefix2 == ipv6_sa_prefix)
    {
        ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 2;
    }
    else
    {
        ds_lpm_ipv6_nat_da_port_hash_key.ip_da_prefix_index = 3;
    }

    ds_lpm_ipv6_nat_da_port_hash_key.l4_dest_port7_0 = port;
    ds_lpm_ipv6_nat_da_port_hash_key.l4_dest_port15_8 = (port >> 8) & 0xFF;
    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_delete_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV6_NAT_DA_PORT, &ds_lpm_ipv6_nat_da_port_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_check_hash_key_mask,
            cli_cmodel_check_hash_key_mask_cmd,
            "check hash-mask hash-module HASH_MODULE",
            "Cmodel cmd",
            "check hash-mask",
            "hash-module",
            "hash-module value")
{
    int32 hash_module = 0;
    int32 hash_type = 0;

    CTC_CLI_GET_INTEGER("hash-module", hash_module, argv[0]);

    if (HASH_MODULE_USERID == hash_module)
    {
        for (hash_type = USERID_HASH_TYPE_TWO_VLAN; hash_type < USERID_HASH_TYPE_NUM; hash_type++)
        {
            DRV_IF_ERROR_RETURN(drv_hash_lookup_check_key_mask(HASH_MODULE_USERID, hash_type));
        }
    }
    else if (HASH_MODULE_FIB == hash_module)
    {
        for (hash_type = FIB_HASH_TYPE_MAC; hash_type < FIB_HASH_TYPE_NUM; hash_type++)
        {
            DRV_IF_ERROR_RETURN(drv_hash_lookup_check_key_mask(HASH_MODULE_FIB, hash_type));
        }
    }
    else if (HASH_MODULE_LPM == hash_module)
    {
        for (hash_type = LPM_HASH_TYPE_IPV4_16; hash_type < LPM_HASH_TYPE_NUM; hash_type++)
        {
            DRV_IF_ERROR_RETURN(drv_hash_lookup_check_key_mask(HASH_MODULE_LPM, hash_type));
        }
    }
    else if (HASH_MODULE_QUEUE == hash_module)
    {
        DRV_IF_ERROR_RETURN(drv_hash_lookup_check_key_mask(HASH_MODULE_QUEUE, hash_type));
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_del_ipv4_nat_sa,
    cli_cmodel_del_ipv4_nat_sa_cmd,
    "ipv4-nat-sa del ({chip-id CHIPID} | ) ipsa A.B.C.D vrfid VRF_ID",
    "Cmodel cmd",
    "add ipv4-nat route",
    "chip id",
    "chip id value",
    "ip sa",
    "A.B.C.D",
    "vrfid",
    "(0~0x3FFF)")
{
    cm_ipv4_addr_t ipsa;
    uint16 vrf_id = 0;
    uint8 chipid = 2;
    uint32 index = 0;

    ds_lpm_ipv4_nat_sa_hash_key_t ds_lpm_ipv4_nat_sa_hash_key;

    sal_memset(&ipsa, 0, sizeof(cm_ipv4_addr_t));
    sal_memset(&ds_lpm_ipv4_nat_sa_hash_key, 0, sizeof(ds_lpm_ipv4_nat_sa_hash_key_t));

    index = ctc_cli_get_prefix_item(&argv[0], argc, "chip-id", sal_strlen("chip-id"));

    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("chip-id", chipid, argv[index + 1]);
        index += 2;
    }
    else
    {
        chipid = 2;
        index = 0;
    }
    CTC_CLI_GET_IPV4_ADDRESS("ipsa", ipsa.ip32[0], argv[index + 0]);
    CTC_CLI_GET_INTEGER("vrfid", vrf_id, argv[index + 1]);

    ds_lpm_ipv4_nat_sa_hash_key.valid = TRUE;
    ds_lpm_ipv4_nat_sa_hash_key.hash_type = LPM_HASH_TYPE_IPV4_NAT_SA;
    ds_lpm_ipv4_nat_sa_hash_key.type = LPM_HASH_KEY_TYPE_NEXTHOP;
    ds_lpm_ipv4_nat_sa_hash_key.ip_sa = ipsa.ip32[0];
    ds_lpm_ipv4_nat_sa_hash_key.vrf_id0 = vrf_id & 0xFF;
    ds_lpm_ipv4_nat_sa_hash_key.vrf_id1 = (vrf_id >> 8) & 0x3F;

    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_delete_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV4_NAT_SA, &ds_lpm_ipv4_nat_sa_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_ipv4_nat_sa_port,
    cli_cmodel_add_ipv4_nat_sa_port_cmd,
    "ipv4-nat-sa-port add ipsa A.B.C.D layer4-port-type PORT_TYPE port PORT vrfid VRF_ID nexthop NEXTHOP",
    "Cmodel cmd",
    "add ipv4-nat-sa-port route",
    "ip sa",
    "A.B.C.D",
    "layer4-port-type",
    "3:TCP, 2:UDP",
    "source port",
    "[0~0xFFFF]",
    "vrfid",
    "[0~0xFF]",
    "nexthop",
    "[0~0xFFFF]")
{
    uint32 nexthop = 0;
    cm_ipv4_addr_t ipsa;
    uint32 vrf_id = 0;
    uint32 port;
    uint32 layer4_port_type = 0;
    uint8 chipid = 2;

    ds_lpm_ipv4_nat_sa_port_hash_key_t ds_lpm_ipv4_nat_sa_port_hash_key;

    sal_memset(&ipsa, 0, sizeof(cm_ipv4_addr_t));
    sal_memset(&ds_lpm_ipv4_nat_sa_port_hash_key, 0, sizeof(ds_lpm_ipv4_nat_sa_port_hash_key_t));

    CTC_CLI_GET_IPV4_ADDRESS("ipsa", ipsa.ip32[0], argv[0]);
    CTC_CLI_GET_UINT32("port-type", layer4_port_type, argv[1]);
    CTC_CLI_GET_UINT32("port", port, argv[2]);
    CTC_CLI_GET_UINT32("vrfid", vrf_id, argv[3]);
    CTC_CLI_GET_UINT32("nexthop", nexthop, argv[4]);

    if (port > 0xFFFF)
    {
        return CLI_ERROR;
    }

    if (vrf_id > 0xFF)
    {
        return CLI_ERROR;
    }


    if (nexthop > 0xFFFF)
    {
        return CLI_ERROR;
    }
    if ((2 != layer4_port_type) && (3 != layer4_port_type))
    {
        sal_printf("%s %d:layer4 port type error!\n", __FUNCTION__, __LINE__);
        return CLI_SUCCESS;
    }
    else
    {
        ds_lpm_ipv4_nat_sa_port_hash_key.l4_port_type = layer4_port_type;
    }
    ds_lpm_ipv4_nat_sa_port_hash_key.valid = TRUE;
    ds_lpm_ipv4_nat_sa_port_hash_key.hash_type = LPM_HASH_TYPE_IPV4_NAT_SA_PORT;
    ds_lpm_ipv4_nat_sa_port_hash_key.ip_sa = ipsa.ip32[0];
    ds_lpm_ipv4_nat_sa_port_hash_key.vrf_id = vrf_id & 0xFF;
    ds_lpm_ipv4_nat_sa_port_hash_key.nexthop = nexthop & 0xFFFF;
    ds_lpm_ipv4_nat_sa_port_hash_key.l4_source_port7_0 = port & 0xFF;
    ds_lpm_ipv4_nat_sa_port_hash_key.l4_source_port15_8 = (port >> 8) & 0xFF;
    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_add_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV4_NAT_SA_PORT, &ds_lpm_ipv4_nat_sa_port_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_del_ipv4_nat_sa_port,
    cli_cmodel_del_ipv4_nat_sa_port_cmd,
    "ipv4-nat-sa-port del ipsa A.B.C.D layer4-port-type PORT_TYPE port PORT vrfid VRF_ID",
    "Cmodel cmd",
    "del ipv4-nat-sa-port route",
    "ip sa",
    "A.B.C.D",
    "layer4-port-type",
    "3:TCP, 2:UDP",
    "source port",
    "[0~0xFFFF]",
    "vrfid",
    "[0~0x3FFF]")
{
    cm_ipv4_addr_t ipsa;
    uint32 vrf_id = 0;
    uint32 port;
    uint32 layer4_port_type = 0;
    uint8 chipid = 2;

    ds_lpm_ipv4_nat_sa_port_hash_key_t ds_lpm_ipv4_nat_sa_port_hash_key;

    sal_memset(&ipsa, 0, sizeof(cm_ipv4_addr_t));
    sal_memset(&ds_lpm_ipv4_nat_sa_port_hash_key, 0, sizeof(ds_lpm_ipv4_nat_sa_port_hash_key_t));

    CTC_CLI_GET_IPV4_ADDRESS("ipsa", ipsa.ip32[0], argv[0]);
    CTC_CLI_GET_UINT32("port-type", layer4_port_type, argv[1]);
    CTC_CLI_GET_UINT32("port", port, argv[2]);
    CTC_CLI_GET_UINT32("vrfid", vrf_id, argv[3]);

    if (port > 0xFFFF)
    {
        return CLI_ERROR;
    }

    if (vrf_id > 0xFF)
    {
        return CLI_ERROR;
    }
    if ((2 != layer4_port_type) && (3 != layer4_port_type))
    {
        sal_printf("%s %d:layer4 port type error!\n", __FUNCTION__, __LINE__);
        return CLI_SUCCESS;
    }
    else
    {
        ds_lpm_ipv4_nat_sa_port_hash_key.l4_port_type = layer4_port_type;
    }
    ds_lpm_ipv4_nat_sa_port_hash_key.valid = TRUE;
    ds_lpm_ipv4_nat_sa_port_hash_key.hash_type = LPM_HASH_TYPE_IPV4_NAT_SA_PORT;
    ds_lpm_ipv4_nat_sa_port_hash_key.ip_sa = ipsa.ip32[0];
    ds_lpm_ipv4_nat_sa_port_hash_key.vrf_id = vrf_id;
    ds_lpm_ipv4_nat_sa_port_hash_key.l4_source_port7_0 = port & 0xFF;
    ds_lpm_ipv4_nat_sa_port_hash_key.l4_source_port15_8 = (port >> 8) & 0xFF;
    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_delete_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV4_NAT_SA_PORT, &ds_lpm_ipv4_nat_sa_port_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_ipv4_nat_da_port,
    cli_cmodel_add_ipv4_nat_da_port_cmd,
    "ipv4-nat-da-port add ipda A.B.C.D layer4-port-type PORT_TYPE port PORT vrfid VRF_ID nexthop NEXTHOP",
    "Cmodel cmd",
    "add ipv4-nat-dest-port route",
    "ip da",
    "A.B.C.D",
    "layer4-port-type",
    "3:TCP, 2:UDP, 0: otherwise",
    "dest port",
    "(0~0xFFFF)",
    "vrfid",
    "(0~0x3FFF)",
    "nexthop",
    "(0~0xFFFF)")
{
    uint32 nexthop = 0;
    cm_ipv4_addr_t ipda;
    uint32 vrf_id = 0;
    uint32 port;
    uint32 layer4_port_type = 0;
    uint8 chipid = 2;

    ds_lpm_ipv4_nat_da_port_hash_key_t ds_lpm_ipv4_nat_da_port_hash_key;

    sal_memset(&ipda, 0, sizeof(cm_ipv4_addr_t));
    sal_memset(&ds_lpm_ipv4_nat_da_port_hash_key, 0, sizeof(ds_lpm_ipv4_nat_da_port_hash_key_t));

    CTC_CLI_GET_IPV4_ADDRESS("ipda", ipda.ip32[0], argv[0]);
    CTC_CLI_GET_UINT32("port-type", layer4_port_type, argv[1]);
    CTC_CLI_GET_UINT32("port", port, argv[2]);
    CTC_CLI_GET_UINT32("vrfid", vrf_id, argv[3]);
    CTC_CLI_GET_UINT32("nexthop", nexthop, argv[4]);

    if (port > 0xFFFF)
    {
        return CLI_ERROR;
    }

    if (vrf_id > 0xFF)
    {
        return CLI_ERROR;
    }

    if (nexthop > 0xFFFF)
    {
        return CLI_ERROR;
    }

    if ((2 != layer4_port_type) && (3 != layer4_port_type) && (0 != layer4_port_type))
    {
        sal_printf("%s %d:layer4 port type error!\n", __FUNCTION__, __LINE__);
        return CLI_SUCCESS;
    }
    else
    {
        ds_lpm_ipv4_nat_da_port_hash_key.l4_port_type = layer4_port_type;
    }
    ds_lpm_ipv4_nat_da_port_hash_key.valid = TRUE;
    ds_lpm_ipv4_nat_da_port_hash_key.hash_type = LPM_HASH_TYPE_IPV4_NAT_DA_PORT;
    ds_lpm_ipv4_nat_da_port_hash_key.ip_da = ipda.ip32[0];
    ds_lpm_ipv4_nat_da_port_hash_key.vrf_id7_0 = vrf_id;
    ds_lpm_ipv4_nat_da_port_hash_key.nexthop = nexthop;
    ds_lpm_ipv4_nat_da_port_hash_key.l4_dest_port7_0 = port & 0xFF;
    ds_lpm_ipv4_nat_da_port_hash_key.l4_dest_port15_8 = (port >> 8) & 0xFF;
    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_add_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV4_NAT_DA_PORT, &ds_lpm_ipv4_nat_da_port_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_del_ipv4_nat_da_port,
    cli_cmodel_del_ipv4_nat_da_port_cmd,
    "ipv4-nat-da-port del ipda A.B.C.D layer4-port-type PORT_TYPE port PORT vrfid VRF_ID",
    "Cmodel cmd",
    "del ipv4-nat-dest-port route",
    "ip da",
    "A.B.C.D",
    "layer4-port-type",
    "3:TCP, 2:UDP",
    "dest port",
    "(0~0xFFFF)",
    "vrfid",
    "(0~0x3FFF)")
{
    cm_ipv4_addr_t ipda;
    uint32 vrf_id = 0;
    uint8 chipid = 2;
    uint32 layer4_port_type = 0;
    uint32 dest_port = 0;

    ds_lpm_ipv4_nat_da_port_hash_key_t ds_lpm_ipv4_nat_da_port_hash_key;

    sal_memset(&ipda, 0, sizeof(cm_ipv4_addr_t));
    sal_memset(&ds_lpm_ipv4_nat_da_port_hash_key, 0, sizeof(ds_lpm_ipv4_nat_da_port_hash_key_t));

    CTC_CLI_GET_IPV4_ADDRESS("ipda", ipda.ip32[0], argv[0]);
    CTC_CLI_GET_UINT32("port-type", layer4_port_type, argv[1]);
    CTC_CLI_GET_INTEGER("port",  dest_port, argv[2]);
    CTC_CLI_GET_INTEGER("vrfid", vrf_id,    argv[3]);

    if (dest_port > 0xFFFF)
    {
        return CLI_ERROR;
    }

    if (vrf_id > 0x3FFF)
    {
        return CLI_ERROR;
    }
     if ((2 != layer4_port_type) && (3 != layer4_port_type))
    {
        sal_printf("%s %d:layer4 port type error!\n", __FUNCTION__, __LINE__);
        return CLI_SUCCESS;
    }
    else
    {
        ds_lpm_ipv4_nat_da_port_hash_key.l4_port_type = layer4_port_type;
    }
    ds_lpm_ipv4_nat_da_port_hash_key.hash_type = LPM_HASH_TYPE_IPV4_NAT_DA_PORT;
    ds_lpm_ipv4_nat_da_port_hash_key.ip_da = ipda.ip32[0];
    ds_lpm_ipv4_nat_da_port_hash_key.l4_dest_port7_0 = dest_port & 0xFF;
    ds_lpm_ipv4_nat_da_port_hash_key.l4_dest_port15_8 = (dest_port >> 8) & 0xFF;
    ds_lpm_ipv4_nat_da_port_hash_key.vrf_id7_0 = vrf_id & 0xFF;
    ds_lpm_ipv4_nat_da_port_hash_key.valid = TRUE;
    DRV_IF_ERROR_RETURN(cm_sim_cfg_kit_delete_lpm_hash_key(chipid, LPM_HASH_TYPE_IPV4_NAT_DA_PORT, &ds_lpm_ipv4_nat_da_port_hash_key));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_two_vlan,
    cli_cmodel_add_userid_two_vlan_cmd,
    "cmodel add userid-twovlan chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL svlanid SVLAN_ID cvlanid CVLAN_ID direction DIRECTION ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid twovlan cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "svlan_id",
    "svlan-id value",
    "cvlan-id",
    "cvlan-id value",
    "direction",
    "direction value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;

    uint32 chip_id = 0;
    uint32 cvlan_id = 0;
    ds_user_id_double_vlan_hash_key_t double_vlan;
    uint32 global_src_port = 0;

    sal_memset(&double_vlan, 0, sizeof(ds_user_id_double_vlan_hash_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", double_vlan.is_label, argv[2]);
    CTC_CLI_GET_INTEGER("svlanid", double_vlan.svlan_id, argv[3]);
    CTC_CLI_GET_INTEGER("cvlanid", cvlan_id, argv[4]);
    double_vlan.cvlan_id11_1 = cvlan_id>>1;
    double_vlan.cvlan_id0_0 = IS_BIT_SET(cvlan_id, 0);
    CTC_CLI_GET_INTEGER("direction", double_vlan.direction, argv[5]);
    CTC_CLI_GET_INTEGER("ad-index", double_vlan.ad_index, argv[6]);

    double_vlan.global_src_port12_0 = global_src_port & 0x1FFF;
    double_vlan.global_src_port13_13 = IS_BIT_SET(global_src_port, 13);

    if (double_vlan.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    double_vlan.hash_type = USERID_KEY_TYPE_TWO_VLAN;
    double_vlan.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_TWO_VLAN, &double_vlan);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_l2,
    cli_cmodel_add_userid_l2_cmd,
    "cmodel add userid-l2 chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT  \
     macda MAC_DA macsa MAC_SA vlanid VLAN_ID cos COS ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid l2 cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "macda",
    "mac_da address in HHHH.HHHH.HHHH format",
    "macsa",
    "mac_sa address in HHHH.HHHH.HHHH format",
    "vlan_id",
    "vlan-id value",
    "cos",
    "cos value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0,cos=0,mac_sa47_32=0;
    uint32 vlan_id = 0;
    ds_user_id_l2_hash_key_t l2_hash_key;
    cm_mac_addr_t mac_da;
    cm_mac_addr_t mac_sa;
    uint32 global_src_port = 0;
    sal_memset(&l2_hash_key, 0, sizeof(ds_user_id_l2_hash_key_t));
    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_MAC_ADDRESS("macda", mac_da, argv[2]);
    CTC_CLI_GET_MAC_ADDRESS("macsa", mac_sa, argv[3]);
    CTC_CLI_GET_INTEGER("vlanid", vlan_id, argv[4]);
    l2_hash_key.vlan_id=vlan_id;
    CTC_CLI_GET_INTEGER("cos", cos, argv[5]);
    l2_hash_key.cos=cos;
    CTC_CLI_GET_INTEGER("ad-index", l2_hash_key.ad_index, argv[6]);
    l2_hash_key.global_src_port10_0= global_src_port & 0x7FF;
    l2_hash_key.global_src_port13_11= (global_src_port>> 11) & 0x7;
    mac_sa47_32 = MAKE_UINT16(mac_sa[0], mac_sa[1]);
    l2_hash_key.mac_sa47_41= (mac_sa47_32 >> 9) & 0x7F;
    l2_hash_key.mac_sa40_32= mac_sa47_32 & 0x1FF;
    l2_hash_key.mac_sa31_0 = MAKE_UINT32(mac_sa[2], mac_sa[3], mac_sa[4], mac_sa[5]);
    l2_hash_key.mac_da47_32= MAKE_UINT16(mac_da[0], mac_da[1]);
    l2_hash_key.mac_da31_0 = MAKE_UINT32(mac_da[2], mac_da[3], mac_da[4], mac_da[5]);
    if (l2_hash_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }
    l2_hash_key.hash_type0= USERID_KEY_TYPE_L2;
    l2_hash_key.hash_type1= USERID_KEY_TYPE_L2;
    l2_hash_key.valid0= TRUE;
    l2_hash_key.valid1= TRUE;
    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_L2, &l2_hash_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}
CTC_CLI(cli_cmodel_add_userid_svlan,
    cli_cmodel_add_userid_svlan_cmd,
    "cmodel add userid-svlan chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL svlanid SVLAN_ID direction DIRECTION ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid svlan cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "svlan_id",
    "svlan-id value",
    "direction",
    "direction value",
    "ad-index",
    "ds ad index(0~0x7FFF)")

{
    int32 ret = DRV_E_NONE;

    uint32 chip_id = 0;
    uint32 global_src_port = 0;
    ds_user_id_svlan_hash_key_t userid_svlan_key;

    sal_memset(&userid_svlan_key, 0, sizeof(userid_svlan_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", userid_svlan_key.is_label, argv[2]);
    CTC_CLI_GET_INTEGER("svlanid", userid_svlan_key.svlan_id, argv[3]);
    CTC_CLI_GET_INTEGER("direction", userid_svlan_key.direction, argv[4]);
    CTC_CLI_GET_INTEGER("ad-index", userid_svlan_key.ad_index, argv[5]);

    userid_svlan_key.global_src_port = global_src_port & 0x1FFF;
    userid_svlan_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    if (userid_svlan_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    userid_svlan_key.hash_type = USERID_KEY_TYPE_SVLAN;
    userid_svlan_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_SVLAN, &userid_svlan_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_svlan_cos,
    cli_cmodel_add_userid_svlan_cos_cmd,
    "cmodel add userid-svlan-cos chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL svlanid SVLAN_ID stagcos STAG_COS direction DIRECTION ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid svlan-cos cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "svlan_id",
    "svlan-id value",
    "stag_cos",
    "stag-cos value",
    "direction",
    "direction value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;

    uint32 chip_id = 0;
    uint32 global_src_port = 0;
    ds_user_id_svlan_cos_hash_key_t userid_svlan_cos_key;

    sal_memset(&userid_svlan_cos_key, 0, sizeof(userid_svlan_cos_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", userid_svlan_cos_key.is_label, argv[2]);
    CTC_CLI_GET_INTEGER("svlanid", userid_svlan_cos_key.svlan_id, argv[3]);
    CTC_CLI_GET_INTEGER("stagcos", userid_svlan_cos_key.stag_cos, argv[4]);
    CTC_CLI_GET_INTEGER("direction", userid_svlan_cos_key.direction, argv[5]);
    CTC_CLI_GET_INTEGER("ad-index", userid_svlan_cos_key.ad_index, argv[6]);

    userid_svlan_cos_key.global_src_port = global_src_port & 0x1FFF;
    userid_svlan_cos_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    if (userid_svlan_cos_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    userid_svlan_cos_key.hash_type = USERID_KEY_TYPE_SVLAN_COS;
    userid_svlan_cos_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_SVLAN_COS, &userid_svlan_cos_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_userid_cvlan,
    cli_cmodel_add_userid_cvlan_cmd,
    "cmodel add userid-cvlan chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL cvlanid CVLAN_ID direction DIRECTION ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid cvlan cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "cvlan_id",
    "cvlan-id value",
    "direction",
    "direction value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;

    uint32 chip_id = 0;
    uint32 global_src_port = 0;
    uint32 cvlan_id = 0;
    ds_user_id_cvlan_hash_key_t userid_cvlan_key;

    sal_memset(&userid_cvlan_key, 0, sizeof(userid_cvlan_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", userid_cvlan_key.is_label, argv[2]);
    CTC_CLI_GET_INTEGER("cvlanid", cvlan_id, argv[3]);
    userid_cvlan_key.cvlan_id11_1 = cvlan_id>>1;
    userid_cvlan_key.cvlan_id0 = IS_BIT_SET(cvlan_id, 0);
    CTC_CLI_GET_INTEGER("direction", userid_cvlan_key.direction, argv[4]);
    CTC_CLI_GET_INTEGER("ad-index", userid_cvlan_key.ad_index, argv[5]);

    userid_cvlan_key.global_src_port = global_src_port & 0x1FFF;
    userid_cvlan_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    if (userid_cvlan_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    userid_cvlan_key.hash_type = USERID_KEY_TYPE_CVLAN;
    userid_cvlan_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_CVLAN, &userid_cvlan_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_cvlan_cos,
    cli_cmodel_add_userid_cvlan_cos_cmd,
    "cmodel add userid-cvlan-cos chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL cvlanid CVLAN_ID ctagcos CTAG_COS direction DIRECTION ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid cvlan-cos cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "cvlan_id",
    "cvlan-id value",
    "ctag_cos",
    "ctag-cos value",
    "direction",
    "direction value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;

    uint32 chip_id = 0;
    uint32 global_src_port = 0;
    uint32 cvlan_id = 0;
    ds_user_id_cvlan_cos_hash_key_t userid_cvlan_cos_key;

    sal_memset(&userid_cvlan_cos_key, 0, sizeof(userid_cvlan_cos_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", userid_cvlan_cos_key.is_label, argv[2]);
    CTC_CLI_GET_INTEGER("cvlanid", cvlan_id, argv[3]);
    userid_cvlan_cos_key.cvlan_id11_1 = cvlan_id>>1;
    userid_cvlan_cos_key.cvlan_id0 = IS_BIT_SET(cvlan_id, 0);
    CTC_CLI_GET_INTEGER("ctagcos", userid_cvlan_cos_key.ctag_cos, argv[4]);
    CTC_CLI_GET_INTEGER("direction", userid_cvlan_cos_key.direction, argv[5]);
    CTC_CLI_GET_INTEGER("ad-index", userid_cvlan_cos_key.ad_index, argv[6]);

    userid_cvlan_cos_key.global_src_port = global_src_port & 0x1FFF;
    userid_cvlan_cos_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    if (userid_cvlan_cos_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    userid_cvlan_cos_key.hash_type = USERID_KEY_TYPE_CVLAN_COS;
    userid_cvlan_cos_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_CVLAN_COS, &userid_cvlan_cos_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_macsa,
    cli_cmodel_add_userid_macsa_cmd,
    "cmodel add userid-macsa chipid CHIP_ID macsa MAC_SA ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid macsa cmd",
    "chip",
    "chip value",
    "mac_sa",
    "mac_sa address in HHHH.HHHH.HHHH format",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    cm_mac_addr_t mac_sa;      /**< MAC-SA */
    ds_user_id_mac_hash_key_t userid_mac_sa_key;

    sal_memset(&userid_mac_sa_key, 0, sizeof(userid_mac_sa_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_MAC_ADDRESS("macsa", mac_sa, argv[1]);
    userid_mac_sa_key.mac_sa47_44 = (mac_sa[0]>>4);
    userid_mac_sa_key.mac_sa43 = IS_BIT_SET(mac_sa[0], 3);
    userid_mac_sa_key.mac_sa42_32 = MAKE_UINT16(mac_sa[0]&0x7, mac_sa[1]);
    userid_mac_sa_key.mac_sa31_0 = (mac_sa[2] << 24) | (mac_sa[3] << 16) | (mac_sa[4] << 8) | mac_sa[5];
    CTC_CLI_GET_INTEGER("ad-index", userid_mac_sa_key.ad_index, argv[2]);

    if (userid_mac_sa_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    userid_mac_sa_key.hash_type = USERID_KEY_TYPE_MAC_SA;
    userid_mac_sa_key.valid = TRUE;


    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_MAC_SA, &userid_mac_sa_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_macda,
    cli_cmodel_add_userid_macda_cmd,
    "cmodel add userid-macda chipid CHIP_ID macda MAC_DA ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid macda cmd",
    "chip",
    "chip value",
    "mac_da",
    "mac_da address in HHHH.HHHH.HHHH format",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    cm_mac_addr_t mac_da;      /**< MAC-SA */
    ds_user_id_mac_hash_key_t userid_mac_da_key;

    sal_memset(&userid_mac_da_key, 0, sizeof(userid_mac_da_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_MAC_ADDRESS("macda", mac_da, argv[1]);

    userid_mac_da_key.mac_sa47_44 = (mac_da[0]>>4);
    userid_mac_da_key.mac_sa43 = IS_BIT_SET(mac_da[0], 3);
    userid_mac_da_key.mac_sa42_32 = MAKE_UINT16(mac_da[0]&0x7, mac_da[1]);
    userid_mac_da_key.mac_sa31_0 = (mac_da[2] << 24) | (mac_da[3] << 16) | (mac_da[4] << 8) | mac_da[5];
    userid_mac_da_key.is_mac_da = TRUE;
    CTC_CLI_GET_INTEGER("ad-index", userid_mac_da_key.ad_index, argv[2]);

    if (userid_mac_da_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    userid_mac_da_key.hash_type = USERID_KEY_TYPE_MAC_SA;
    userid_mac_da_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_MAC_SA, &userid_mac_da_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_macsa_port,
    cli_cmodel_add_userid_macsa_port_cmd,
    "cmodel add userid-macsa-port chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL macsa MAC_SA ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid macsa cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "mac_sa",
    "mac_sa address in HHHH.HHHH.HHHH format",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    cm_mac_addr_t mac_sa;      /**< MAC-SA */
    uint32 global_src_port = 0;
    ds_user_id_mac_port_hash_key_t userid_mac_sa_port_key;

    sal_memset(&userid_mac_sa_port_key, 0, sizeof(userid_mac_sa_port_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    userid_mac_sa_port_key.global_src_port = global_src_port & 0x1FFF;
    userid_mac_sa_port_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    CTC_CLI_GET_INTEGER("islabel", userid_mac_sa_port_key.is_label, argv[2]);

    CTC_CLI_GET_MAC_ADDRESS("macsa", mac_sa, argv[3]);
    userid_mac_sa_port_key.mac_sa_high = MAKE_UINT16(mac_sa[0], mac_sa[1]);
    userid_mac_sa_port_key.mac_sa_low = MAKE_UINT32(mac_sa[2], mac_sa[3], mac_sa[4], mac_sa[5]);

    CTC_CLI_GET_INTEGER("ad-index", userid_mac_sa_port_key.ad_index, argv[4]);

    if (userid_mac_sa_port_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    userid_mac_sa_port_key.hash_type = USERID_KEY_TYPE_PORT_MAC_SA;
    userid_mac_sa_port_key.hash_type1 = USERID_KEY_TYPE_PORT_MAC_SA;
    userid_mac_sa_port_key.valid = TRUE;
    userid_mac_sa_port_key.valid1 = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_PORT_MAC_SA, &userid_mac_sa_port_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_macda_port,
    cli_cmodel_add_userid_macda_port_cmd,
    "cmodel add userid-macda-port chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL macda MAC_DA ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid macda cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "mac_da",
    "mac_da address in HHHH.HHHH.HHHH format",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    cm_mac_addr_t mac_da;      /**< MAC-DA */
    uint32 global_src_port = 0;
    ds_user_id_mac_port_hash_key_t userid_mac_da_port_key;

    sal_memset(&userid_mac_da_port_key, 0, sizeof(userid_mac_da_port_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    userid_mac_da_port_key.global_src_port = global_src_port & 0x1FFF;
    userid_mac_da_port_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);
    userid_mac_da_port_key.is_mac_da = TRUE;

    CTC_CLI_GET_INTEGER("islabel", userid_mac_da_port_key.is_label, argv[2]);

    CTC_CLI_GET_MAC_ADDRESS("macda", mac_da, argv[3]);
    userid_mac_da_port_key.mac_sa_high = MAKE_UINT16(mac_da[0], mac_da[1]);
    userid_mac_da_port_key.mac_sa_low = MAKE_UINT32(mac_da[2], mac_da[3], mac_da[4], mac_da[5]);

    CTC_CLI_GET_INTEGER("ad-index", userid_mac_da_port_key.ad_index, argv[4]);

    if (userid_mac_da_port_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    userid_mac_da_port_key.hash_type = USERID_KEY_TYPE_PORT_MAC_SA;
    userid_mac_da_port_key.hash_type1 = USERID_KEY_TYPE_PORT_MAC_SA;
    userid_mac_da_port_key.valid = TRUE;
    userid_mac_da_port_key.valid1 = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_PORT_MAC_SA, &userid_mac_da_port_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_ipv4sa,
    cli_cmodel_add_userid_ipsa_cmd,
    "cmodel add userid-ipv4sa chipid CHIP_ID ipv4sa IPV4_SA ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid ipsa cmd",
    "chip",
    "chip value",
    "ipv4_sa",
    "ipv4_sa address in A.B.C.D format",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ip_sa = 0;
    ds_user_id_ipv4_hash_key_t userid_ipv4_sa_key;

    sal_memset(&userid_ipv4_sa_key, 0, sizeof(userid_ipv4_sa_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ip_sa, argv[1]);
    userid_ipv4_sa_key.ip_sa = ip_sa;
    CTC_CLI_GET_INTEGER("ad-index", userid_ipv4_sa_key.ad_index, argv[2]);

    if (userid_ipv4_sa_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    userid_ipv4_sa_key.hash_type = USERID_KEY_TYPE_IPV4_SA;
    userid_ipv4_sa_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_IPV4_SA, &userid_ipv4_sa_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_ipv6sa,
            cli_cmodel_add_userid_ipv6sa_cmd,
            "cmodel add userid-ipv6sa chipid CHIP_ID ipv6sa IPV6_SA ad-index AD_INDEX",
            "Cmodel cmd",
            "Cmodel add cmd",
            "Cmodel add userid ipv6sa cmd",
            "chip",
            "chip value",
            "ipv6_sa",
            CTC_CLI_IPV6_FORMAT,
            "ad-index",
            "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    ds_user_id_ipv6_hash_key_t ds_user_id_ipv6_hash_key;
    cm_ipv6_addr_t ipv6_address;

    sal_memset(&ds_user_id_ipv6_hash_key, 0, sizeof(ds_user_id_ipv6_hash_key_t));

    CTC_CLI_GET_UINT32("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_IPV6_ADDRESS("ipv6sa", ipv6_address.ip32, argv[1]);
    CTC_CLI_GET_UINT32("ad-index", ds_user_id_ipv6_hash_key.ad_index, argv[2]);

    ipv6_address.ip32[3] = sal_htonl(ipv6_address.ip32[3]);
    ipv6_address.ip32[2] = sal_htonl(ipv6_address.ip32[2]);
    ipv6_address.ip32[1] = sal_htonl(ipv6_address.ip32[1]);
    ipv6_address.ip32[0] = sal_htonl(ipv6_address.ip32[0]);

    ds_user_id_ipv6_hash_key.valid0 = TRUE;
    ds_user_id_ipv6_hash_key.valid1 = TRUE;

    ds_user_id_ipv6_hash_key.hash_type0 = USERID_KEY_TYPE_IPV6_SA;
    ds_user_id_ipv6_hash_key.hash_type1 = USERID_KEY_TYPE_IPV6_SA;

    ds_user_id_ipv6_hash_key.ip_sa31_0 = ipv6_address.ip32[3];
    ds_user_id_ipv6_hash_key.ip_sa32 = ipv6_address.ip32[2] & 0x1;
    ds_user_id_ipv6_hash_key.ip_sa43_33 = (ipv6_address.ip32[2] >> 1) & 0x7FF;
    ds_user_id_ipv6_hash_key.ip_sa45_44 = (ipv6_address.ip32[2] >> 12) & 0x3;
    ds_user_id_ipv6_hash_key.ip_sa57_46 = (ipv6_address.ip32[2] >> 14) & 0xFFF;
    ds_user_id_ipv6_hash_key.ip_sa89_58 = ((ipv6_address.ip32[1] & 0x3FFFFFF) << 6)
                                          | ((ipv6_address.ip32[2] >> 26) & 0x3F);
    ds_user_id_ipv6_hash_key.ip_sa116_90 = ((ipv6_address.ip32[0] & 0x1FFFFF) << 6)
                                           | ((ipv6_address.ip32[1] >> 26) & 0x3F);
    ds_user_id_ipv6_hash_key.ip_sa127_117 = (ipv6_address.ip32[0] >> 21) & 0x7FF;

    if (ds_user_id_ipv6_hash_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_IPV6_SA, &ds_user_id_ipv6_hash_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_ipv4sa_port,
    cli_cmodel_add_userid_ipv4sa_port_cmd,
    "cmodel add userid-ipv4sa-port chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL ipv4sa IPV4_SA ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid macsa cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "ipv4_sa",
    "ipv4_sa address in A.B.C.D format",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ip_sa = 0;
    uint32 global_src_port = 0;
    ds_user_id_ipv4_port_hash_key_t userid_ipv4_sa_port_key;

    sal_memset(&userid_ipv4_sa_port_key, 0, sizeof(userid_ipv4_sa_port_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    userid_ipv4_sa_port_key.global_src_port0 = IS_BIT_SET(global_src_port, 0);
    userid_ipv4_sa_port_key.global_src_port1 = ((global_src_port>>1) & 0x1FFF);
    userid_ipv4_sa_port_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    CTC_CLI_GET_INTEGER("islabel", userid_ipv4_sa_port_key.is_label, argv[2]);

    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ip_sa, argv[3]);
    userid_ipv4_sa_port_key.ip_sa = ip_sa;
    CTC_CLI_GET_INTEGER("ad-index", userid_ipv4_sa_port_key.ad_index, argv[4]);

    if (userid_ipv4_sa_port_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }
    userid_ipv4_sa_port_key.hash_type = USERID_KEY_TYPE_PORT_IPV4_SA;
    userid_ipv4_sa_port_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_PORT_IPV4_SA, &userid_ipv4_sa_port_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_userid_port,
    cli_cmodel_add_userid_port_cmd,
    "cmodel add userid-port chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL direction DIRECTION ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add userid port cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "direction",
    "direction value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;

    uint32 chip_id = 0;
    uint32 global_src_port = 0;
    ds_user_id_port_hash_key_t ds_user_id_port_hash_key;

    sal_memset(&ds_user_id_port_hash_key, 0, sizeof(ds_user_id_port_hash_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", ds_user_id_port_hash_key.is_label, argv[2]);
    CTC_CLI_GET_INTEGER("direction", ds_user_id_port_hash_key.direction, argv[3]);
    CTC_CLI_GET_INTEGER("ad-index", ds_user_id_port_hash_key.ad_index, argv[4]);

    ds_user_id_port_hash_key.global_src_port = global_src_port & 0x1FFF;
    ds_user_id_port_hash_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    if (ds_user_id_port_hash_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    ds_user_id_port_hash_key.hash_type = USERID_KEY_TYPE_PORT;
    ds_user_id_port_hash_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_PORT, &ds_user_id_port_hash_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_tunnelid_capwap,
    cli_cmodel_add_tunnelid_capwap_cmd,
    "cmodel add tunnelid-capwap chipid CHIP_ID rid RID radiomac RADIO_MAC ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid-capwap cmd",
    "chip",
    "chip-value",
    "rid",
    "rid-value",
    "radiomac",
    "radiomac address in HHHH.HHHH.HHHH format",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    cm_mac_addr_t radio_mac;
    ds_tunnel_id_capwap_hash_key_t tunnel_capwap_key;

    sal_memset(&tunnel_capwap_key, 0, sizeof(tunnel_capwap_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("rid", tunnel_capwap_key.rid, argv[1]);

    CTC_CLI_GET_MAC_ADDRESS("radio_mac", radio_mac, argv[2]);
    tunnel_capwap_key.radio_mac47_39 = ((radio_mac[0] << 1) | IS_BIT_SET(radio_mac[1], 7));
    tunnel_capwap_key.radio_mac38 = IS_BIT_SET(radio_mac[1], 6);
    tunnel_capwap_key.radio_mac37_32= (radio_mac[1] & 0x3F);
    tunnel_capwap_key.radio_mac31_0 = MAKE_UINT32(radio_mac[2], radio_mac[3], radio_mac[4], radio_mac[5]);

    CTC_CLI_GET_INTEGER("ad-index", tunnel_capwap_key.ad_index, argv[3]);

    if (tunnel_capwap_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    tunnel_capwap_key.hash_type = USERID_KEY_TYPE_CAPWAP;
    tunnel_capwap_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_CAPWAP, &tunnel_capwap_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_tunnelid_capwap,
    cli_cmodel_remove_tunnelid_capwap_cmd,
    "cmodel remove tunnelid-capwap chipid CHIP_ID rid RID radiomac RADIO_MAC",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid-capwap cmd",
    "chip",
    "chip-value",
    "rid",
    "rid-value",
    "radiomac",
    "radiomac address in HHHH.HHHH.HHHH format")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    cm_mac_addr_t radio_mac;
    ds_tunnel_id_capwap_hash_key_t tunnel_capwap_key;

    sal_memset(&tunnel_capwap_key, 0, sizeof(tunnel_capwap_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("rid", tunnel_capwap_key.rid, argv[1]);

    CTC_CLI_GET_MAC_ADDRESS("radio_mac", radio_mac, argv[2]);
    tunnel_capwap_key.radio_mac47_39 = ((radio_mac[0] << 1) | IS_BIT_SET(radio_mac[1], 7));
    tunnel_capwap_key.radio_mac38 = IS_BIT_SET(radio_mac[1], 6);
    tunnel_capwap_key.radio_mac37_32= (radio_mac[1] & 0x3F);
    tunnel_capwap_key.radio_mac31_0 = MAKE_UINT32(radio_mac[2], radio_mac[3], radio_mac[4], radio_mac[5]);
    tunnel_capwap_key.hash_type = USERID_KEY_TYPE_CAPWAP;
    tunnel_capwap_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_CAPWAP, &tunnel_capwap_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}



CTC_CLI(cli_cmodel_add_tunnelid_ipv4,
    cli_cmodel_add_tunnelid_ipv4_cmd,
    "cmodel add tunnelid-ipv4 chipid CHIP_ID ipv4sa IPV4_SA ipv4da IPV4_DA\
    udpsrcport UDP_SRC_PORT udpdstport UDP_DST_PORT layer4type LAYER4_TYPE ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid-capwap cmd",
    "chip",
    "chip-value",
    "ipv4sa",
    "ipv4_sa address in A.B.C.D format",
    "ipv4da",
    "ipv4_da address in A.B.C.D format",
    "udpsrcport",
    "udp-src-port-value",
    "udpdstport",
    "udp-dst-port-value",
    "layer4type",
    "layer4type-value"
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    uint32 chip_id = 0;
    uint32 ipsa, ipda;
    uint32 udp_src_port, udp_dst_port, layer4type;
    ds_tunnel_id_ipv4_hash_key_t tunnel_ipv4_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&tunnel_ipv4_key, 0, sizeof(tunnel_ipv4_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ipsa, argv[1]);
    tunnel_ipv4_key.ip_sa = ipsa;

    CTC_CLI_GET_IPV4_ADDRESS("ipv4da", ipda, argv[2]);
    tunnel_ipv4_key.ip_da = ipda;

    CTC_CLI_GET_INTEGER("udpsrcport", udp_src_port, argv[3]);
    tunnel_ipv4_key.udp_src_port_l = (udp_src_port & 0x7FF);
    tunnel_ipv4_key.udp_src_port_h = ((udp_src_port>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("udpdstport", udp_dst_port, argv[4]);
    tunnel_ipv4_key.udp_dest_port = (udp_dst_port & 0xFFFF);

    CTC_CLI_GET_INTEGER("layer4type", layer4type, argv[5]);
    tunnel_ipv4_key.layer4_type = (layer4type & 0xF);

    CTC_CLI_GET_INTEGER("ad-index", tunnel_ipv4_key.ad_index, argv[6]);

    if (tunnel_ipv4_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    tunnel_ipv4_key.hash_type0 = USERID_KEY_TYPE_IPV4_TUNNEL;
    tunnel_ipv4_key.hash_type1 = USERID_KEY_TYPE_IPV4_TUNNEL;
    tunnel_ipv4_key.valid0 = TRUE;
    tunnel_ipv4_key.valid1 = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_IPV4_TUNNEL, &tunnel_ipv4_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_tunnelid_ipv4,
    cli_cmodel_remove_tunnelid_ipv4_cmd,
    "cmodel remove tunnelid-ipv4 chipid CHIP_ID ipv4sa IPV4_SA ipv4da IPV4_DA\
    udpsrcport UDP_SRC_PORT udpdstport UDP_DST_PORT layer4type LAYER4_TYPE",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid-capwap cmd",
    "chip",
    "chip-value",
    "ipv4sa",
    "ipv4_sa address in A.B.C.D format",
    "ipv4da",
    "ipv4_da address in A.B.C.D format",
    "udpsrcport",
    "udp-src-port-value",
    "udpdstport",
    "udp-dst-port-value",
    "layer4type",
    "layer4type-value")
{
    uint32 chip_id = 0;
    uint32 ipsa, ipda;
    uint32 udp_src_port, udp_dst_port,layer4type;
    ds_tunnel_id_ipv4_hash_key_t tunnel_ipv4_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&tunnel_ipv4_key, 0, sizeof(tunnel_ipv4_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ipsa, argv[1]);
    tunnel_ipv4_key.ip_sa = ipsa;

    CTC_CLI_GET_IPV4_ADDRESS("ipv4da", ipda, argv[2]);
    tunnel_ipv4_key.ip_da = ipda;

    CTC_CLI_GET_INTEGER("udpsrcport", udp_src_port, argv[3]);
    tunnel_ipv4_key.udp_src_port_l = (udp_src_port & 0x7FF);
    tunnel_ipv4_key.udp_src_port_h = ((udp_src_port>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("udpdstport", udp_dst_port, argv[4]);
    tunnel_ipv4_key.udp_dest_port = (udp_dst_port & 0xFFFF);

    CTC_CLI_GET_INTEGER("layer4type", layer4type, argv[5]);
    tunnel_ipv4_key.layer4_type = (layer4type & 0xF);

    tunnel_ipv4_key.hash_type0 = USERID_KEY_TYPE_IPV4_TUNNEL;
    tunnel_ipv4_key.hash_type1 = USERID_KEY_TYPE_IPV4_TUNNEL;
    tunnel_ipv4_key.valid0 = TRUE;
    tunnel_ipv4_key.valid1 = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_IPV4_TUNNEL, &tunnel_ipv4_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_tunnelid_ipv4_udp,
    cli_cmodel_add_tunnelid_ipv4_udp_cmd,
    "cmodel add tunnelid-ipv4-udp chipid CHIP_ID ipv4sa IPV4_SA ipv4da IPV4_DA\
    udpsrcport UDP_SRC_PORT udpdstport UDP_DST_PORT layer4type LAYER4_TYPE ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid-capwap cmd",
    "chip",
    "chip-value",
    "ipv4sa",
    "ipv4_sa address in A.B.C.D format",
    "ipv4da",
    "ipv4_da address in A.B.C.D format",
    "udpsrcport",
    "udp-src-port-value",
    "udpdstport",
    "udp-dst-port-value",
    "layer4type",
    "layer4type-value"
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    uint32 chip_id = 0;
    uint32 ipsa, ipda;
    uint32 udp_src_port, udp_dst_port, layer4type;
    ds_tunnel_id_ipv4_hash_key_t tunnel_ipv4_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&tunnel_ipv4_key, 0, sizeof(tunnel_ipv4_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ipsa, argv[1]);
    tunnel_ipv4_key.ip_sa = ipsa;

    CTC_CLI_GET_IPV4_ADDRESS("ipv4da", ipda, argv[2]);
    tunnel_ipv4_key.ip_da = ipda;

    CTC_CLI_GET_INTEGER("udpsrcport", udp_src_port, argv[3]);
    tunnel_ipv4_key.udp_src_port_l = (udp_src_port & 0x7FF);
    tunnel_ipv4_key.udp_src_port_h = ((udp_src_port>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("udpdstport", udp_dst_port, argv[4]);
    tunnel_ipv4_key.udp_dest_port = (udp_dst_port & 0xFFFF);

    CTC_CLI_GET_INTEGER("layer4type", layer4type, argv[5]);
    tunnel_ipv4_key.layer4_type = (layer4type & 0xF);

    CTC_CLI_GET_INTEGER("ad-index", tunnel_ipv4_key.ad_index, argv[6]);

    if (tunnel_ipv4_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    tunnel_ipv4_key.hash_type0 = USERID_KEY_TYPE_IPV4_UDP;
    tunnel_ipv4_key.hash_type1 = USERID_KEY_TYPE_IPV4_UDP;
    tunnel_ipv4_key.valid0 = TRUE;
    tunnel_ipv4_key.valid1 = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_IPV4_UDP, &tunnel_ipv4_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_tunnelid_ipv4_udp,
    cli_cmodel_remove_tunnelid_ipv4_udp_cmd,
    "cmodel remove tunnelid-ipv4-udp chipid CHIP_ID ipv4sa IPV4_SA ipv4da IPV4_DA\
    udpsrcport UDP_SRC_PORT udpdstport UDP_DST_PORT layer4type LAYER4_TYPE",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid-capwap cmd",
    "chip",
    "chip-value",
    "ipv4sa",
    "ipv4_sa address in A.B.C.D format",
    "ipv4da",
    "ipv4_da address in A.B.C.D format",
    "udpsrcport",
    "udp-src-port-value",
    "udpdstport",
    "udp-dst-port-value",
    "layer4type",
    "layer4type-value")
{
    uint32 chip_id = 0;
    uint32 ipsa, ipda;
    uint32 udp_src_port, udp_dst_port,layer4type;
    ds_tunnel_id_ipv4_hash_key_t tunnel_ipv4_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&tunnel_ipv4_key, 0, sizeof(tunnel_ipv4_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ipsa, argv[1]);
    tunnel_ipv4_key.ip_sa = ipsa;

    CTC_CLI_GET_IPV4_ADDRESS("ipv4da", ipda, argv[2]);
    tunnel_ipv4_key.ip_da = ipda;

    CTC_CLI_GET_INTEGER("udpsrcport", udp_src_port, argv[3]);
    tunnel_ipv4_key.udp_src_port_l = (udp_src_port & 0x7FF);
    tunnel_ipv4_key.udp_src_port_h = ((udp_src_port>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("udpdstport", udp_dst_port, argv[4]);
    tunnel_ipv4_key.udp_dest_port = (udp_dst_port & 0xFFFF);

    CTC_CLI_GET_INTEGER("layer4type", layer4type, argv[5]);
    tunnel_ipv4_key.layer4_type = (layer4type & 0xF);

    tunnel_ipv4_key.hash_type0 = USERID_KEY_TYPE_IPV4_UDP;
    tunnel_ipv4_key.hash_type1 = USERID_KEY_TYPE_IPV4_UDP;
    tunnel_ipv4_key.valid0 = TRUE;
    tunnel_ipv4_key.valid1 = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_IPV4_UDP, &tunnel_ipv4_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_tunnelid_ipv4_rpf,
    cli_cmodel_add_tunnelid_ipv4_rpf_cmd,
    "cmodel add tunnelid-ipv4-rpf chipid CHIP_ID ipv4sa IPV4_SA ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid-ipv4-rpf cmd",
    "chip",
    "chip-value",
    "ipv4sa",
    "ipv4_sa address in A.B.C.D format",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    uint32 chip_id = 0;
    uint32 ipsa = 0;
    ds_tunnel_id_ipv4_rpf_hash_key_t tunnel_ipv4_rpf_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&tunnel_ipv4_rpf_key, 0, sizeof(tunnel_ipv4_rpf_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ipsa, argv[1]);
    tunnel_ipv4_rpf_key.ip_sa = ipsa;

    CTC_CLI_GET_INTEGER("ad-index", tunnel_ipv4_rpf_key.ad_index, argv[2]);

    if (tunnel_ipv4_rpf_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    tunnel_ipv4_rpf_key.hash_type = USERID_KEY_TYPE_IPV4_RPF;
    tunnel_ipv4_rpf_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_IPV4_RPF, &tunnel_ipv4_rpf_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_tunnelid_ipv4_rpf,
    cli_cmodel_remove_tunnelid_ipv4_rpf_cmd,
    "cmodel remove tunnelid-ipv4-rpf chipid CHIP_ID ipv4sa IPV4_SA ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid-ipv4-rpf cmd",
    "chip",
    "chip-value",
    "ipv4sa",
    "ipv4_sa address in A.B.C.D format")
{
    uint32 chip_id = 0;
    uint32 ipsa = 0;
    ds_tunnel_id_ipv4_rpf_hash_key_t tunnel_ipv4_rpf_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&tunnel_ipv4_rpf_key, 0, sizeof(tunnel_ipv4_rpf_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ipsa, argv[1]);
    tunnel_ipv4_rpf_key.ip_sa = ipsa;

    tunnel_ipv4_rpf_key.hash_type = USERID_KEY_TYPE_IPV4_RPF;
    tunnel_ipv4_rpf_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_IPV4_RPF, &tunnel_ipv4_rpf_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_tunnelid_ipv4_gre,
    cli_cmodel_add_tunnelid_ipv4_gre_cmd,
    "cmodel add tunnelid-ipv4-gre chipid CHIP_ID layer4type LAYER4_TYPE ipsa IP_SA ipda IP_DA\
    grekey GRE_KEY ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid ipv4 gre cmd",
    "chip",
    "chip value",
    "layer4type",
    "layer4type value",
    "ip_sa",
    "ip_sa address in A.B.C.D format",
    "ip_da",
    "ip_da address in A.B.C.D format",
    "gre_key",
    "gre_key value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    uint32 chip_id = 0;
    uint32 ipsa, ipda;
    uint32 ad_index, gre_key;
    ds_tunnel_id_ipv4_hash_key_t tunnel_ipv4_gre_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&tunnel_ipv4_gre_key, 0, sizeof(ds_tunnel_id_ipv4_hash_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("layer4type", tunnel_ipv4_gre_key.layer4_type, argv[1]);

    CTC_CLI_GET_IPV4_ADDRESS("ipsa", ipsa, argv[2]);
    CTC_CLI_GET_IPV4_ADDRESS("ipda", ipda, argv[3]);

    CTC_CLI_GET_INTEGER("grekey", gre_key, argv[4]);
    CTC_CLI_GET_INTEGER("ad_index", ad_index, argv[5]);

    tunnel_ipv4_gre_key.hash_type0 = USERID_KEY_TYPE_IPV4_GRE_KEY;
    tunnel_ipv4_gre_key.hash_type1 = USERID_KEY_TYPE_IPV4_GRE_KEY;
    tunnel_ipv4_gre_key.valid0 = TRUE;
    tunnel_ipv4_gre_key.valid1 = TRUE;

    tunnel_ipv4_gre_key.ip_sa = ipsa;
    tunnel_ipv4_gre_key.ip_da = ipda;
    tunnel_ipv4_gre_key.udp_dest_port = (gre_key >> 16) & 0xFFFF;
    tunnel_ipv4_gre_key.udp_src_port_h = (gre_key >> 11) & 0x1F;
    tunnel_ipv4_gre_key.udp_src_port_l = gre_key & 0x7FF;
    tunnel_ipv4_gre_key.ad_index = ad_index;

    if (tunnel_ipv4_gre_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_IPV4_GRE_KEY, &tunnel_ipv4_gre_key);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_port_vlan_cross,
    cli_cmodel_add_port_vlan_cross_cmd,
    "cmodel add port-vlan-cross chipid CHIP_ID islabel IS_LABEL global-src-port GLOBAL_SRC_PORT global-dest-port GLOBAL_DEST_PORT vlanid VLAN_ID ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add port vlan cross cmd",
    "chip id",
    "chip id value",
    "islabel",
    "1: is lable, 0: isn't label",
    "global src port",
    "global src port value",
    "global dest port",
    "global src port value",
    "vlan id",
    "vlan id value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    uint32 chip_id = 0;
    uint32 is_label = FALSE;
    uint32 ad_index = 0;
    uint32 global_src_port = 0;
    uint32 global_dest_port = 0;
    uint32 vlan_id = 0;
    ds_user_id_port_vlan_cross_hash_key_t ds_user_id_port_vlan_cross_hash_key;
    int32 ret = DRV_E_NONE;
    sal_memset(&ds_user_id_port_vlan_cross_hash_key, 0, sizeof(ds_user_id_port_vlan_cross_hash_key_t));
    CTC_CLI_GET_UINT32("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("islabel", is_label, argv[1]);
    CTC_CLI_GET_UINT32("global-src-port", global_src_port, argv[2]);
    CTC_CLI_GET_UINT32("global-dst-port", global_dest_port, argv[3]);
    CTC_CLI_GET_UINT32("vlanid", vlan_id, argv[4]);
    CTC_CLI_GET_UINT32("ad_index", ad_index, argv[5]);
    if (ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }
    ds_user_id_port_vlan_cross_hash_key.direction = USERID_DIRECTION_OTHER;
    ds_user_id_port_vlan_cross_hash_key.global_dest_port = global_dest_port;
    ds_user_id_port_vlan_cross_hash_key.global_src_port12_0 = global_src_port & 0x1FFF;
    ds_user_id_port_vlan_cross_hash_key.global_src_port13_13 = (global_src_port >> 13) & 0x1;
    ds_user_id_port_vlan_cross_hash_key.valid = TRUE;
    ds_user_id_port_vlan_cross_hash_key.vlan_id0_0 = vlan_id & 0x1;
    ds_user_id_port_vlan_cross_hash_key.vlan_id11_1 = (vlan_id >> 1) & 0x7FF;
    ds_user_id_port_vlan_cross_hash_key.hash_type = USERID_KEY_TYPE_IPV4_SA;
    ds_user_id_port_vlan_cross_hash_key.is_label = is_label;
    ds_user_id_port_vlan_cross_hash_key.ad_index = ad_index;
    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_PORT_VLAN_CROSS, &ds_user_id_port_vlan_cross_hash_key);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}
CTC_CLI(cli_cmodel_remove_port_vlan_cross,
    cli_cmodel_remove_port_vlan_cross_cmd,
    "cmodel remove port-vlan-cross chipid CHIP_ID islabel IS_LABEL global-src-port GLOBAL_SRC_PORT global-dest-port GLOBAL_DEST_PORT vlanid VLAN_ID",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove port vlan cross cmd",
    "chip id",
    "chip id value",
    "islabel",
    "1: is lable, 0: isn't label",
    "global src port",
    "global src port value",
    "global dest port",
    "global src port value",
    "vlan id",
    "vlan id value")
{
    uint32 chip_id = 0;
    uint32 is_label = FALSE;
    uint32 global_src_port = 0;
    uint32 global_dest_port = 0;
    uint32 vlan_id = 0;
    ds_user_id_port_vlan_cross_hash_key_t ds_user_id_port_vlan_cross_hash_key;
    int32 ret = DRV_E_NONE;
    sal_memset(&ds_user_id_port_vlan_cross_hash_key, 0, sizeof(ds_user_id_port_vlan_cross_hash_key_t));
    CTC_CLI_GET_UINT32("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("islabel", is_label, argv[1]);
    CTC_CLI_GET_UINT32("global-src-port", global_src_port, argv[2]);
    CTC_CLI_GET_UINT32("global-dst-port", global_dest_port, argv[3]);
    CTC_CLI_GET_UINT32("vlanid", vlan_id, argv[4]);
    ds_user_id_port_vlan_cross_hash_key.direction = USERID_DIRECTION_OTHER;
    ds_user_id_port_vlan_cross_hash_key.global_dest_port = global_dest_port;
    ds_user_id_port_vlan_cross_hash_key.global_src_port12_0 = global_src_port & 0x1FFF;
    ds_user_id_port_vlan_cross_hash_key.global_src_port13_13 = (global_src_port >> 13) & 0x1;
    ds_user_id_port_vlan_cross_hash_key.valid = TRUE;
    ds_user_id_port_vlan_cross_hash_key.vlan_id0_0 = vlan_id & 0x1;
    ds_user_id_port_vlan_cross_hash_key.vlan_id11_1 = (vlan_id >> 1) & 0x7FF;
    ds_user_id_port_vlan_cross_hash_key.hash_type = USERID_KEY_TYPE_IPV4_SA;
    ds_user_id_port_vlan_cross_hash_key.is_label = is_label;
    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_PORT_VLAN_CROSS, &ds_user_id_port_vlan_cross_hash_key);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}
CTC_CLI(cli_cmodel_add_port_cross,
    cli_cmodel_add_port_cross_cmd,
    "cmodel add port-cross chipid CHIP_ID islabel IS_LABEL global-src-port GLOBAL_SRC_PORT global-dest-port GLOBAL_DEST_PORT ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add port vlan cross cmd",
    "chip id",
    "chip id value",
    "islabel",
    "1: is lable, 0: isn't label",
    "global src port",
    "global src port value",
    "global dest port",
    "global src port value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    uint32 chip_id = 0;
    uint32 is_label = FALSE;
    uint32 ad_index = 0;
    uint32 global_src_port = 0;
    uint32 global_dest_port = 0;
    ds_user_id_port_cross_hash_key_t ds_user_id_port_cross_hash_key;
    int32 ret = DRV_E_NONE;
    sal_memset(&ds_user_id_port_cross_hash_key, 0, sizeof(ds_user_id_port_cross_hash_key_t));
    CTC_CLI_GET_UINT32("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("islabel", is_label, argv[1]);
    CTC_CLI_GET_UINT32("global-src-port", global_src_port, argv[2]);
    CTC_CLI_GET_UINT32("global-dst-port", global_dest_port, argv[3]);
    CTC_CLI_GET_UINT32("ad_index", ad_index, argv[4]);
    if (ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }
    ds_user_id_port_cross_hash_key.direction = USERID_DIRECTION_OTHER;
    ds_user_id_port_cross_hash_key.global_dest_port = global_dest_port & 0x3FFF;
    ds_user_id_port_cross_hash_key.global_src_port = global_src_port & 0x1FFF;
    ds_user_id_port_cross_hash_key.valid = TRUE;
    ds_user_id_port_cross_hash_key.hash_type = USERID_KEY_TYPE_PORT_IPV4_SA;
    ds_user_id_port_cross_hash_key.is_label = is_label;
    ds_user_id_port_cross_hash_key.ad_index = ad_index;
    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_PORT_CROSS, &ds_user_id_port_cross_hash_key);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}
CTC_CLI(cli_cmodel_remove_port_cross,
    cli_cmodel_remove_port_cross_cmd,
    "cmodel remove port-cross chipid CHIP_ID islabel IS_LABEL global-src-port GLOBAL_SRC_PORT global-dest-port GLOBAL_DEST_PORT",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove port vlan cross cmd",
    "chip id",
    "chip id value",
    "islabel",
    "1: is lable, 0: isn't label",
    "global src port",
    "global src port value",
    "global dest port",
    "global src port value")
{
    uint32 chip_id = 0;
    uint32 is_label = FALSE;
    uint32 global_src_port = 0;
    uint32 global_dest_port = 0;
    ds_user_id_port_cross_hash_key_t ds_user_id_port_cross_hash_key;
    int32 ret = DRV_E_NONE;
    sal_memset(&ds_user_id_port_cross_hash_key, 0, sizeof(ds_user_id_port_cross_hash_key_t));
    CTC_CLI_GET_UINT32("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("islabel", is_label, argv[1]);
    CTC_CLI_GET_UINT32("global-src-port", global_src_port, argv[2]);
    CTC_CLI_GET_UINT32("global-dst-port", global_dest_port, argv[3]);
    ds_user_id_port_cross_hash_key.direction = USERID_DIRECTION_OTHER;
    ds_user_id_port_cross_hash_key.global_dest_port = global_dest_port & 0x3FFF;
    ds_user_id_port_cross_hash_key.global_src_port = global_src_port & 0x1FFF;
    ds_user_id_port_cross_hash_key.valid = TRUE;
    ds_user_id_port_cross_hash_key.hash_type = USERID_KEY_TYPE_PORT_IPV4_SA;
    ds_user_id_port_cross_hash_key.is_label = is_label;
    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_PORT_CROSS, &ds_user_id_port_cross_hash_key);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}
CTC_CLI(cli_cmodel_remove_tunnelid_ipv4_gre,
    cli_cmodel_remove_tunnelid_ipv4_gre_cmd,
    "cmodel remove tunnelid-ipv4-gre chipid CHIP_ID layer4type LAYER4_TYPE ipsa IP_SA ipda IP_DA\
    grekey GRE_KEY",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid ipv4 gre cmd",
    "chip",
    "chip value",
    "layer4type",
    "layer4type value",
    "ip_sa",
    "ip_sa address in A.B.C.D format",
    "ip_da",
    "ip_da address in A.B.C.D format",
    "gre_key",
    "gre_key value")
{
    uint32 chip_id = 0;
    uint32 ipsa, ipda;
    uint32 gre_key;
    ds_tunnel_id_ipv4_hash_key_t tunnel_ipv4_gre_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&tunnel_ipv4_gre_key, 0, sizeof(ds_tunnel_id_ipv4_hash_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("layer4type", tunnel_ipv4_gre_key.layer4_type, argv[1]);

    CTC_CLI_GET_IPV4_ADDRESS("ipsa", ipsa, argv[2]);
    CTC_CLI_GET_IPV4_ADDRESS("ipda", ipda, argv[3]);

    CTC_CLI_GET_INTEGER("grekey", gre_key, argv[4]);

    tunnel_ipv4_gre_key.hash_type0 = USERID_KEY_TYPE_IPV4_GRE_KEY;
    tunnel_ipv4_gre_key.hash_type1 = USERID_KEY_TYPE_IPV4_GRE_KEY;
    tunnel_ipv4_gre_key.valid0 = TRUE;
    tunnel_ipv4_gre_key.valid1 = TRUE;

    tunnel_ipv4_gre_key.ip_sa = ipsa;
    tunnel_ipv4_gre_key.ip_da = ipda;
    tunnel_ipv4_gre_key.udp_dest_port = (gre_key >> 16) & 0xFFFF;
    tunnel_ipv4_gre_key.udp_src_port_h = (gre_key >> 11) & 0x1F;
    tunnel_ipv4_gre_key.udp_src_port_l = gre_key & 0x7FF;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_IPV4_GRE_KEY, &tunnel_ipv4_gre_key);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_tunnelid_pbb,
    cli_cmodel_add_tunnelid_pbb_cmd,
    "cmodel add tunnelid-pbb chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL isid ISID direction DIRECTION ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid pbb cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "isid",
    "isid-value",
    "direction",
    "direction value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, isid = 0;
    uint32 global_src_port = 0;
    ds_tunnel_id_pbb_hash_key_t tunnel_pbb_key;

    sal_memset(&tunnel_pbb_key, 0, sizeof(tunnel_pbb_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    tunnel_pbb_key.global_src_port = (global_src_port & 0x1FFF);
    tunnel_pbb_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    CTC_CLI_GET_INTEGER("islabel", tunnel_pbb_key.is_label, argv[2]);

    CTC_CLI_GET_INTEGER("isid", isid, argv[3]);
    tunnel_pbb_key.isid_low = (isid & 0x7FFFF);
    tunnel_pbb_key.isid_high = ((isid>>19) & 0x1F);

    CTC_CLI_GET_INTEGER("direction", tunnel_pbb_key.direction, argv[4]);

    CTC_CLI_GET_INTEGER("ad-index", tunnel_pbb_key.ad_index, argv[5]);

    if (tunnel_pbb_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    tunnel_pbb_key.hash_type = USERID_KEY_TYPE_PBB;
    tunnel_pbb_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_PBB, &tunnel_pbb_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_tunnelid_pbb,
    cli_cmodel_remove_tunnelid_pbb_cmd,
    "cmodel remove tunnelid-pbb chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL isid ISID direction DIRECTION",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid pbb cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "isid",
    "isid-value",
    "direction",
    "direction value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, isid = 0;
    uint32 global_src_port = 0;
    ds_tunnel_id_pbb_hash_key_t tunnel_pbb_key;

    sal_memset(&tunnel_pbb_key, 0, sizeof(tunnel_pbb_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    tunnel_pbb_key.global_src_port = (global_src_port & 0x1FFF);
    tunnel_pbb_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    CTC_CLI_GET_INTEGER("islabel", tunnel_pbb_key.is_label, argv[2]);

    CTC_CLI_GET_INTEGER("isid", isid, argv[3]);
    tunnel_pbb_key.isid_low = (isid & 0x7FFFF);
    tunnel_pbb_key.isid_high = ((isid>>19) & 0x1F);

    CTC_CLI_GET_INTEGER("direction", tunnel_pbb_key.direction, argv[4]);

    tunnel_pbb_key.hash_type = USERID_KEY_TYPE_PBB;
    tunnel_pbb_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_PBB, &tunnel_pbb_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_tunnelid_trill_mc_adjust_check,
    cli_cmodel_add_tunnelid_trill_mc_adjust_check_cmd,
    "cmodel add tunnelid-trill-mc-adj-check chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL egress-nickname EGR_NICKNAME ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid-trill-mc-adj-check cmd",
    "chip",
    "chip value",
    "globalsrcport",
    "globalsrcport value",
    "islabel",
    "islabel value",
    "egressnickname",
    "egressnickname value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, egress_nickname = 0;
    uint32 global_src_port = 0;
    ds_tunnel_id_trill_mc_adj_check_hash_key_t tunnel_mc_adjchk_key;

    sal_memset(&tunnel_mc_adjchk_key, 0, sizeof(tunnel_mc_adjchk_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    tunnel_mc_adjchk_key.global_src_port = (global_src_port & 0x1FFF);
    tunnel_mc_adjchk_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    CTC_CLI_GET_INTEGER("islabel", tunnel_mc_adjchk_key.is_label, argv[2]);

    CTC_CLI_GET_INTEGER("egress_nickname", egress_nickname, argv[3]);
    tunnel_mc_adjchk_key.egress_nickname = egress_nickname;

    CTC_CLI_GET_INTEGER("ad-index", tunnel_mc_adjchk_key.ad_index, argv[4]);

    if (tunnel_mc_adjchk_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    tunnel_mc_adjchk_key.hash_type = USERID_KEY_TYPE_TRILL_MC_ADJ;
    tunnel_mc_adjchk_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_TRILL_MC_ADJ, &tunnel_mc_adjchk_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(cli_cmodel_remove_tunnelid_trill_mc_adjust_check,
    cli_cmodel_remove_tunnelid_trill_mc_adjust_check_cmd,
    "cmodel remove tunnelid-trill-mc-adj-check chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL egress-nickname EGR_NICKNAME",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid-trill-mc-adj-check cmd",
    "chip",
    "chip value",
    "globalsrcport",
    "globalsrcport value",
    "islabel",
    "islabel value",
    "egressnickname",
    "egressnickname value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, egress_nickname = 0;
    uint32 global_src_port = 0;
    ds_tunnel_id_trill_mc_adj_check_hash_key_t tunnel_mc_adjchk_key;

    sal_memset(&tunnel_mc_adjchk_key, 0, sizeof(tunnel_mc_adjchk_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    tunnel_mc_adjchk_key.global_src_port = (global_src_port & 0x1FFF);
    tunnel_mc_adjchk_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    CTC_CLI_GET_INTEGER("islabel", tunnel_mc_adjchk_key.is_label, argv[2]);

    CTC_CLI_GET_INTEGER("egress_nickname", egress_nickname, argv[3]);
    tunnel_mc_adjchk_key.egress_nickname = egress_nickname;

    tunnel_mc_adjchk_key.hash_type = USERID_KEY_TYPE_TRILL_MC_ADJ;
    tunnel_mc_adjchk_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_TRILL_MC_ADJ, &tunnel_mc_adjchk_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}



CTC_CLI(cli_cmodel_add_tunnelid_trill_mc_decap,
    cli_cmodel_add_tunnelid_trill_mc_decap_cmd,
    "cmodel add tunnelid-trill-mc-decap chipid CHIP_ID ingress-nickname ING_NICKNAME\
    egress-nickname EGR_NICKNAME ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid-trill-mc-decap cmd",
    "chip",
    "chip value",
    "ingressnickname",
    "ingressnickname value",
    "egressnickname",
    "egressnickname value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ingress_nickname = 0, egress_nickname = 0;
    ds_tunnel_id_trill_mc_decap_hash_key_t tunnel_mc_decap_key;

    sal_memset(&tunnel_mc_decap_key, 0, sizeof(tunnel_mc_decap_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("ingressnickname", ingress_nickname, argv[1]);
    tunnel_mc_decap_key.ingress_nickname_low = (ingress_nickname & 0x7FF);
    tunnel_mc_decap_key.ingress_nickname_high = ((ingress_nickname>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("egressnickname", egress_nickname, argv[2]);
    tunnel_mc_decap_key.egress_nickname = egress_nickname;

    CTC_CLI_GET_INTEGER("ad-index", tunnel_mc_decap_key.ad_index, argv[3]);

    if (tunnel_mc_decap_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    tunnel_mc_decap_key.hash_type = USERID_KEY_TYPE_TRILL_MC;
    tunnel_mc_decap_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_TRILL_MC, &tunnel_mc_decap_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(cli_cmodel_remove_tunnelid_trill_mc_decap,
    cli_cmodel_remove_tunnelid_trill_mc_decap_cmd,
    "cmodel remove tunnelid-trill-mc-decap chipid CHIP_ID ingress-nickname ING_NICKNAME\
    egress-nickname EGR_NICKNAME",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid-trill-mc-decap cmd",
    "chip",
    "chip value",
    "ingressnickname",
    "ingressnickname value",
    "egressnickname",
    "egressnickname value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ingress_nickname = 0, egress_nickname = 0;
    ds_tunnel_id_trill_mc_decap_hash_key_t tunnel_mc_decap_key;

    sal_memset(&tunnel_mc_decap_key, 0, sizeof(tunnel_mc_decap_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("ingressnickname", ingress_nickname, argv[1]);
    tunnel_mc_decap_key.ingress_nickname_low = (ingress_nickname & 0x7FF);
    tunnel_mc_decap_key.ingress_nickname_high = ((ingress_nickname>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("egressnickname", egress_nickname, argv[2]);
    tunnel_mc_decap_key.egress_nickname = egress_nickname;

    tunnel_mc_decap_key.hash_type = USERID_KEY_TYPE_TRILL_MC;
    tunnel_mc_decap_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_TRILL_MC, &tunnel_mc_decap_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(cli_cmodel_add_tunnelid_trill_mc_rpf,
    cli_cmodel_add_tunnelid_trill_mc_rpf_cmd,
    "cmodel add tunnelid-trill-mc-rpf chipid CHIP_ID ingress-nickname ING_NICKNAME\
    egress-nickname EGR_NICKNAME ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid-trill-mc-rpf cmd",
    "chip",
    "chip value",
    "ingressnickname",
    "ingressnickname value",
    "egressnickname",
    "egressnickname value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ingress_nickname = 0, egress_nickname = 0;
    ds_tunnel_id_trill_mc_rpf_hash_key_t tunnel_mc_rpf_key;

    sal_memset(&tunnel_mc_rpf_key, 0, sizeof(tunnel_mc_rpf_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("ingressnickname", ingress_nickname, argv[1]);
    tunnel_mc_rpf_key.ingress_nickname_low = (ingress_nickname & 0x7FF);
    tunnel_mc_rpf_key.ingress_nickname_high = ((ingress_nickname>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("egressnickname", egress_nickname, argv[2]);
    tunnel_mc_rpf_key.egress_nickname = egress_nickname;

    CTC_CLI_GET_INTEGER("ad-index", tunnel_mc_rpf_key.ad_index, argv[3]);

    if (tunnel_mc_rpf_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    tunnel_mc_rpf_key.hash_type = USERID_KEY_TYPE_TRILL_MC_RPF;
    tunnel_mc_rpf_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_TRILL_MC_RPF, &tunnel_mc_rpf_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(cli_cmodel_remove_tunnelid_trill_mc_rpf,
    cli_cmodel_remove_tunnelid_trill_mc_rpf_cmd,
    "cmodel remove tunnelid-trill-mc-rpf chipid CHIP_ID ingress-nickname ING_NICKNAME\
    egress-nickname EGR_NICKNAME",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid-trill-mc-rpf cmd",
    "chip",
    "chip value",
    "ingressnickname",
    "ingressnickname value",
    "egressnickname",
    "egressnickname value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ingress_nickname = 0, egress_nickname = 0;
    ds_tunnel_id_trill_mc_rpf_hash_key_t tunnel_mc_rpf_key;

    sal_memset(&tunnel_mc_rpf_key, 0, sizeof(tunnel_mc_rpf_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("ingressnickname", ingress_nickname, argv[1]);
    tunnel_mc_rpf_key.ingress_nickname_low = (ingress_nickname & 0x7FF);
    tunnel_mc_rpf_key.ingress_nickname_high = ((ingress_nickname>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("egressnickname", egress_nickname, argv[2]);
    tunnel_mc_rpf_key.egress_nickname = egress_nickname;

    tunnel_mc_rpf_key.hash_type = USERID_KEY_TYPE_TRILL_MC_RPF;
    tunnel_mc_rpf_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_TRILL_MC_RPF, &tunnel_mc_rpf_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}


CTC_CLI(cli_cmodel_add_tunnelid_trill_uc_decap,
    cli_cmodel_add_tunnelid_trill_uc_decap_cmd,
    "cmodel add tunnelid-trill-uc-decap chipid CHIP_ID ingress-nickname ING_NICKNAME\
    egress-nickname EGR_NICKNAME ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid-trill-uc-decap cmd",
    "chip",
    "chip value",
    "ingressnickname",
    "ingressnickname value",
    "egressnickname",
    "egressnickname value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ingress_nickname = 0, egress_nickname = 0;
    ds_tunnel_id_trill_uc_decap_hash_key_t tunnel_uc_decap_key;

    sal_memset(&tunnel_uc_decap_key, 0, sizeof(tunnel_uc_decap_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("ingressnickname", ingress_nickname, argv[1]);
    tunnel_uc_decap_key.ingress_nickname_low = (ingress_nickname & 0x7FF);
    tunnel_uc_decap_key.ingress_nickname_high = ((ingress_nickname>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("egressnickname", egress_nickname, argv[2]);
    tunnel_uc_decap_key.egress_nickname = egress_nickname;

    CTC_CLI_GET_INTEGER("ad-index", tunnel_uc_decap_key.ad_index, argv[3]);

    if (tunnel_uc_decap_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    tunnel_uc_decap_key.hash_type = USERID_KEY_TYPE_TRILL_UC;
    tunnel_uc_decap_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_TRILL_UC, &tunnel_uc_decap_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(cli_cmodel_remove_tunnelid_trill_uc_decap,
    cli_cmodel_remove_tunnelid_trill_uc_decap_cmd,
    "cmodel remove tunnelid-trill-uc-decap chipid CHIP_ID ingress-nickname ING_NICKNAME\
    egress-nickname EGR_NICKNAME",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid-trill-uc-decap cmd",
    "chip",
    "chip value",
    "ingressnickname",
    "ingressnickname value",
    "egressnickname",
    "egressnickname value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ingress_nickname = 0, egress_nickname = 0;
    ds_tunnel_id_trill_uc_decap_hash_key_t tunnel_uc_decap_key;

    sal_memset(&tunnel_uc_decap_key, 0, sizeof(tunnel_uc_decap_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("ingressnickname", ingress_nickname, argv[1]);
    tunnel_uc_decap_key.ingress_nickname_low = (ingress_nickname & 0x7FF);
    tunnel_uc_decap_key.ingress_nickname_high = ((ingress_nickname>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("egressnickname", egress_nickname, argv[2]);
    tunnel_uc_decap_key.egress_nickname = egress_nickname;

    tunnel_uc_decap_key.hash_type = USERID_KEY_TYPE_TRILL_UC;
    tunnel_uc_decap_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_TRILL_UC, &tunnel_uc_decap_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(cli_cmodel_add_tunnelid_trill_uc_rpf,
    cli_cmodel_add_tunnelid_trill_uc_rpf_cmd,
    "cmodel add tunnelid-trill-uc-rpf chipid CHIP_ID ingress-nickname ING_NICKNAME ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid-trill-uc-rpf cmd",
    "chip",
    "chip value",
    "ingressnickname",
    "ingressnickname value",
    "ad-index",
    "ds ad index(0~0x7FFF)")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ingress_nickname = 0;
    ds_tunnel_id_trill_uc_rpf_hash_key_t tunnel_uc_rpf_key;

    sal_memset(&tunnel_uc_rpf_key, 0, sizeof(tunnel_uc_rpf_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("ingressnickname", ingress_nickname, argv[1]);
    tunnel_uc_rpf_key.ingress_nickname_low = (ingress_nickname & 0x7FF);
    tunnel_uc_rpf_key.ingress_nickname_high = ((ingress_nickname>>11) & 0x1F);

    CTC_CLI_GET_INTEGER("ad-index", tunnel_uc_rpf_key.ad_index, argv[2]);

    if (tunnel_uc_rpf_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    tunnel_uc_rpf_key.hash_type = USERID_KEY_TYPE_TRILL_UC_RPF;
    tunnel_uc_rpf_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_TRILL_UC_RPF, &tunnel_uc_rpf_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(cli_cmodel_remove_tunnelid_trill_uc_rpf,
    cli_cmodel_remove_tunnelid_trill_uc_rpf_cmd,
    "cmodel remove tunnelid-trill-uc-rpf chipid CHIP_ID ingress-nickname ING_NICKNAME",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove tunnelid-trill-uc-rpf cmd",
    "chip",
    "chip value",
    "ingressnickname",
    "ingressnickname value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ingress_nickname = 0;
    ds_tunnel_id_trill_uc_rpf_hash_key_t tunnel_uc_rpf_key;

    sal_memset(&tunnel_uc_rpf_key, 0, sizeof(tunnel_uc_rpf_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("ingressnickname", ingress_nickname, argv[1]);
    tunnel_uc_rpf_key.ingress_nickname_low = (ingress_nickname & 0x7FF);
    tunnel_uc_rpf_key.ingress_nickname_high = ((ingress_nickname>>11) & 0x1F);

    tunnel_uc_rpf_key.hash_type = USERID_KEY_TYPE_TRILL_UC_RPF;
    tunnel_uc_rpf_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_TRILL_UC_RPF, &tunnel_uc_rpf_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(cli_cmodel_remove_userid_ipv6sa,
            cli_cmodel_remove_userid_ipv6sa_cmd,
            "cmodel remove userid-ipv6sa chipid CHIP_ID ipv6sa IPV6_SA",
            "Cmodel cmd",
            "Cmodel remove cmd",
            "Cmodel remove userid ipv6sa cmd",
            "chip",
            "chip value",
            "ipv6_sa",
            CTC_CLI_IPV6_FORMAT)
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    ds_user_id_ipv6_hash_key_t ds_user_id_ipv6_hash_key;
    cm_ipv6_addr_t ipv6_address;

    sal_memset(&ds_user_id_ipv6_hash_key, 0, sizeof(ds_user_id_ipv6_hash_key_t));

    CTC_CLI_GET_UINT32("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_IPV6_ADDRESS("ipv6sa", ipv6_address.ip32, argv[1]);

    ipv6_address.ip32[3] = sal_htonl(ipv6_address.ip32[3]);
    ipv6_address.ip32[2] = sal_htonl(ipv6_address.ip32[2]);
    ipv6_address.ip32[1] = sal_htonl(ipv6_address.ip32[1]);
    ipv6_address.ip32[0] = sal_htonl(ipv6_address.ip32[0]);

    ds_user_id_ipv6_hash_key.valid0 = TRUE;
    ds_user_id_ipv6_hash_key.valid1 = TRUE;

    ds_user_id_ipv6_hash_key.hash_type0 = USERID_KEY_TYPE_IPV6_SA;
    ds_user_id_ipv6_hash_key.hash_type1 = USERID_KEY_TYPE_IPV6_SA;

    ds_user_id_ipv6_hash_key.ip_sa31_0 = ipv6_address.ip32[3];
    ds_user_id_ipv6_hash_key.ip_sa32 = ipv6_address.ip32[2] & 0x1;
    ds_user_id_ipv6_hash_key.ip_sa43_33 = (ipv6_address.ip32[2] >> 1) & 0x7FF;
    ds_user_id_ipv6_hash_key.ip_sa45_44 = (ipv6_address.ip32[2] >> 12) & 0x3;
    ds_user_id_ipv6_hash_key.ip_sa57_46 = (ipv6_address.ip32[2] >> 14) & 0xFFF;
    ds_user_id_ipv6_hash_key.ip_sa89_58 = ((ipv6_address.ip32[1] & 0x3FFFFFF) << 6)
                                          | ((ipv6_address.ip32[2] >> 26) & 0x3F);
    ds_user_id_ipv6_hash_key.ip_sa116_90 = ((ipv6_address.ip32[0] & 0x1FFFFF) << 6)
                                           | ((ipv6_address.ip32[1] >> 26) & 0x3F);
    ds_user_id_ipv6_hash_key.ip_sa127_117 = (ipv6_address.ip32[0] >> 21) & 0x7FF;

    if (ds_user_id_ipv6_hash_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_IPV6_SA, &ds_user_id_ipv6_hash_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_mpls_section_oam,
    cli_cmodel_add_mpls_section_oam_cmd,
    "cmodel add mpls-section-oam chip-id CHIP_ID interface-id INTERFACE_ID ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add mpls_section_oam",
    "chip-id",
    "chip value",
    "interface-id",
    "interface-id value",
    "ad-index",
    "chan index value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 ad_index = 0;

    ds_mpls_oam_label_hash_key_t mpls_oam_label_key;

    sal_memset(&mpls_oam_label_key, 0, sizeof(ds_mpls_oam_label_hash_key_t));

    CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("interface-id", mpls_oam_label_key.mpls_label, argv[1]);
    CTC_CLI_GET_INTEGER("ad-index", ad_index, argv[2]);

    mpls_oam_label_key.hash_type = USERID_KEY_TYPE_MPLS_SECTION_OAM;
    mpls_oam_label_key.valid = TRUE;
    mpls_oam_label_key.ad_index = ad_index;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_MPLS_SECTION_OAM, &mpls_oam_label_key);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_pbt_oam,
    cli_cmodel_add_pbt_oam_cmd,
    "cmodel add pbt-oam chip-id CHIP_ID esp-id ESP_ID ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add pbt_oam",
    "chip-id",
    "chip id value",
    "esp-id",
    "esp-id value",
    "ad-index",
    "chan index value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 ad_index = 0x0;

    ds_pbt_oam_hash_key_t pbt_oam_key;

    sal_memset(&pbt_oam_key, 0, sizeof(ds_pbt_oam_hash_key_t));

    CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("esp-id", pbt_oam_key.vrf_id, argv[1]);
    CTC_CLI_GET_INTEGER("ad-index", ad_index, argv[2]);

    pbt_oam_key.hash_type = USERID_KEY_TYPE_PBT_OAM;
    pbt_oam_key.valid = TRUE;
    pbt_oam_key.ad_index = ad_index;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_PBT_OAM, &pbt_oam_key);
    if(ret < 0)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_mpls_label_oam,
    cli_cmodel_add_mpls_label_oam_cmd,
    "cmodel add mpls-label-oam chip-id CHIP_ID mplslabel MPLS_LABEL ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add mpls_label_oam",
    "chip-id",
    "chip value",
    "mplslabel",
    "mplslabel value",
    "ad-index",
    "chan index value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 ad_index = 0;

    ds_mpls_oam_label_hash_key_t mpls_oam_label_key;

    sal_memset(&mpls_oam_label_key, 0, sizeof(ds_mpls_oam_label_hash_key_t));

    CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("mplslabel", mpls_oam_label_key.mpls_label, argv[1]);
    CTC_CLI_GET_INTEGER("ad-index", ad_index, argv[2]);

    mpls_oam_label_key.hash_type = USERID_KEY_TYPE_MPLS_LABEL_OAM;
    mpls_oam_label_key.valid = TRUE;
    mpls_oam_label_key.ad_index = ad_index;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_MPLS_LABEL_OAM,&mpls_oam_label_key);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_bfd_oam,
    cli_cmodel_add_bfd_oam_cmd,
    "cmodel add bfd-oam chip-id CHIP_ID my-discriminator MY_DIS ad-index AD_INDEX",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add bfd_oam",
    "chip",
    "chip value",
    "my-discriminator",
    "my-discriminator value",
    "ad-index",
    "chan index value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 ad_index = 0;
    ds_bfd_oam_hash_key_t bfd_oam_key;

    sal_memset(&bfd_oam_key, 0, sizeof(ds_bfd_oam_hash_key_t));

    CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("my-discriminator", bfd_oam_key.my_discriminator, argv[1]);
    CTC_CLI_GET_INTEGER("ad-index", ad_index, argv[2]);

    bfd_oam_key.hash_type = USERID_KEY_TYPE_BFD_OAM;
    bfd_oam_key.valid = TRUE;
    bfd_oam_key.ad_index = ad_index;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_BFD_OAM, &bfd_oam_key);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_eth_oam,
    cli_cmodel_add_eth_oam_cmd,
    "cmodel add eth-oam chip-id CHIP_ID global-src-port GLOBAL_SRC_PORT vlan-id VLAN_ID is-fid IS_FID ad-index AD_INDEX\
    {lm-type LM_TYPE | mip-bitmap MIP_BITMAP | lm-bitmap LM_BITMAP | lm-idx-base LM_IDX_BASE }",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add eth_oam",
    "chip-id",
    "chip value",
    "global-src-port",
    "global-src-port value",
    "vlan-id",
    "vlanid value",
    "is-fid",
    "isfid value",
    "ad-index",
    "ether oam chan index",
    "lm-type",
    "DS_ETH_OAM_CHAN.lm-type value"
    "mip-bitmap",
    "DS_ETH_OAM_CHAN.mip-bitmap",
    "lm-bitmap",
    "DS_ETH_OAM_CHAN.lm-bitmap",
    "lm-idx-base",
    "DS_ETH_OAM_CHAN.lm-idx-base")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 ad_index = 0;
    uint32 global_src_port = 0;
    uint32 lm_idx_base = 0;
    uint32 hash_type = 0;

    uint8 index = 0xFF;
    ds_eth_oam_hash_key_t eth_oam_key;

    sal_memset(&eth_oam_key, 0, sizeof(ds_bfd_oam_hash_key_t));

    CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("global-src-port", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("vlan-id", eth_oam_key.vlan_id, argv[2]);
    CTC_CLI_GET_INTEGER("is-fid", eth_oam_key.is_fid, argv[3]);
    CTC_CLI_GET_INTEGER("ad-index", ad_index, argv[4]);

    index = ctc_cli_get_prefix_item(&argv[0], argc, "mip-bitmap", sal_strlen("mip-bitmap"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("mip-bitmap", eth_oam_key.mip_bitmap, argv[index+1]);
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "lm-bitmap", sal_strlen("lm-bitmap"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lm-bitmap", eth_oam_key.lm_bitmap, argv[index+1]);
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "lm-idx-base", sal_strlen("lm-idx-base"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lm-idx-base", lm_idx_base, argv[index+1]);
        eth_oam_key.lm_index_base1_0 = (lm_idx_base & 0x3);
        eth_oam_key.lm_index_base4_2 = ((lm_idx_base >> 2) & 0x7);
        eth_oam_key.lm_index_base6_5 = ((lm_idx_base >> 5) & 0x3);
        eth_oam_key.lm_index_base8_7 = ((lm_idx_base >> 7) & 0x3);
        eth_oam_key.lm_index_base13_9 = ((lm_idx_base >> 9) & 0x1F);
    }

    if(eth_oam_key.is_fid)
    {
        eth_oam_key.hash_type = USERID_KEY_TYPE_ETHER_FID_OAM;
        hash_type = USERID_HASH_TYPE_ETHER_FID_OAM;
    }
    else
    {
        eth_oam_key.hash_type = USERID_KEY_TYPE_ETHER_VLAN_OAM;
        hash_type = USERID_HASH_TYPE_ETHER_VLAN_OAM;
    }
    eth_oam_key.valid = TRUE;
    eth_oam_key.ad_index = ad_index;
    eth_oam_key.global_src_port = global_src_port&0x1FFF;
    eth_oam_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, hash_type, &eth_oam_key);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_eth_oam_rmep,
    cli_cmodel_add_eth_oam_rmep_cmd,
    "cmodel add eth-oam-rmep chip-id CHIP_ID mep-index MEP_INDEX rmep-id RMEP_ID rmep-index RMEP_IDX ",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add eth_oam_rmep",
    "chip",
    "chip value",
    "mep-index",
    "mep-index value",
    "rmep-id",
    "rmep-id value",
    "rmep-index",
    "rmep-index value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 rmep_index = 0;
    ds_eth_oam_rmep_hash_key_t eth_oam_rmep_key;

    sal_memset(&eth_oam_rmep_key, 0, sizeof(ds_eth_oam_rmep_hash_key_t));

    CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("mep-index", eth_oam_rmep_key.mep_index, argv[1]);
    CTC_CLI_GET_INTEGER("rmep-id", eth_oam_rmep_key.rmep_id, argv[2]);
    CTC_CLI_GET_INTEGER("rmep-index", rmep_index, argv[3]);

    eth_oam_rmep_key.ad_index         = rmep_index;
    eth_oam_rmep_key.hash_type = USERID_KEY_TYPE_ETHER_RMEP;
    eth_oam_rmep_key.valid = TRUE;

    ret = cm_sim_cfg_kit_add_userid_key(chip_id, USERID_HASH_TYPE_ETHER_RMEP, &eth_oam_rmep_key);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_userid_two_vlan,
    cli_cmodel_remove_userid_two_vlan_cmd,
    "cmodel remove userid-twovlan chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel\
    IS_LABEL svlanid SVLAN_ID cvlanid CVLAN_ID direction DIRECTION",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid twovlan cmd",
    "chip",
    "chip value",
    "global_src_port",
    "global src port value",
    "is_label",
    "is_label value",
    "svlan_id",
    "svlan_id value",
    "cvlan_id",
    "cvlan_id value",
    "direction",
    "0:ipe, 1:epe")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 cvlan_id = 0;
    uint32 global_src_port = 0;
    ds_user_id_double_vlan_hash_key_t ds_user_id_double_vlan_hash_key;
    sal_memset(&ds_user_id_double_vlan_hash_key, 0, sizeof(ds_user_id_double_vlan_hash_key_t));

    CTC_CLI_GET_UINT32("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_UINT32("islabel", ds_user_id_double_vlan_hash_key.is_label, argv[2]);

    CTC_CLI_GET_UINT32("svlanid", ds_user_id_double_vlan_hash_key.svlan_id, argv[3]);
    CTC_CLI_GET_UINT32("cvlanid", cvlan_id, argv[4]);
    ds_user_id_double_vlan_hash_key.cvlan_id11_1 = cvlan_id >> 1;
    ds_user_id_double_vlan_hash_key.cvlan_id0_0 = IS_BIT_SET(cvlan_id, 0);
    CTC_CLI_GET_UINT32("direction", ds_user_id_double_vlan_hash_key.direction, argv[5]);

    ds_user_id_double_vlan_hash_key.hash_type = USERID_KEY_TYPE_TWO_VLAN;
    ds_user_id_double_vlan_hash_key.valid = TRUE;
    ds_user_id_double_vlan_hash_key.global_src_port12_0 = global_src_port & 0x1FFF;
    ds_user_id_double_vlan_hash_key.global_src_port13_13 = IS_BIT_SET(global_src_port, 13);

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_TWO_VLAN, &ds_user_id_double_vlan_hash_key);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_userid_svlan,
    cli_cmodel_remove_userid_svlan_cmd,
    "cmodel remove userid-svlan chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel\
     IS_LABEL svlanid SVLAN_ID direction DIRECTION",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid svlan cmd",
    "chip",
    "chip value",
    "global_src_port",
    "global src port value",
    "is_label",
    "is_label value",
    "svlan_id",
    "svlan_id value",
    "direction",
    "0:ipe, 1:epe")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;

    ds_user_id_svlan_hash_key_t userid_svlan;

    sal_memset(&userid_svlan, 0, sizeof(userid_svlan));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", userid_svlan.global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", userid_svlan.is_label, argv[2]);

    CTC_CLI_GET_INTEGER("svlanid", userid_svlan.svlan_id, argv[3]);
    CTC_CLI_GET_INTEGER("direction", userid_svlan.direction, argv[4]);

    userid_svlan.hash_type = USERID_KEY_TYPE_SVLAN;
    userid_svlan.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_SVLAN, &userid_svlan);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_userid_cvlan,
    cli_cmodel_remove_userid_cvlan_cmd,
    "cmodel remove userid-cvlan chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel\
     IS_LABEL cvlanid CVLAN_ID direction DIRECTION",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid cvlan cmd",
    "chip",
    "chip value",
    "global_src_port",
    "global src port value",
    "is_label",
    "is_label value",
    "cvlan_id",
    "cvlan_id value",
    "direction",
    "0:ipe, 1:epe")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 cvlan_id = 0;
    ds_user_id_cvlan_hash_key_t userid_cvlan;

    sal_memset(&userid_cvlan, 0, sizeof(userid_cvlan));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", userid_cvlan.global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", userid_cvlan.is_label, argv[2]);

    CTC_CLI_GET_INTEGER("cvlanid", cvlan_id, argv[3]);
    userid_cvlan.cvlan_id11_1 = cvlan_id>>1;
    userid_cvlan.cvlan_id0 = IS_BIT_SET(cvlan_id, 0);
    CTC_CLI_GET_INTEGER("direction", userid_cvlan.direction, argv[4]);

    userid_cvlan.hash_type = USERID_KEY_TYPE_CVLAN;
    userid_cvlan.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_CVLAN, &userid_cvlan);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_userid_svlan_cos,
    cli_cmodel_remove_userid_svlan_cos_cmd,
    "cmodel remove userid-svlan-cos chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL svlanid SVLAN_ID stagcos STAG_COS direction DIRECTION",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid svlan-cos cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "svlan_id",
    "svlan-id value",
    "stag_cos",
    "stag-cos value",
    "direction",
    "0:ipe, 1:epe")
{
    int32 ret = DRV_E_NONE;

    uint32 chip_id = 0;
    uint32 global_src_port = 0;
    ds_user_id_svlan_cos_hash_key_t userid_svlan_cos_key;

    sal_memset(&userid_svlan_cos_key, 0, sizeof(userid_svlan_cos_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", userid_svlan_cos_key.is_label, argv[2]);
    CTC_CLI_GET_INTEGER("svlanid", userid_svlan_cos_key.svlan_id, argv[3]);
    CTC_CLI_GET_INTEGER("stagcos", userid_svlan_cos_key.stag_cos, argv[4]);
    CTC_CLI_GET_INTEGER("direction", userid_svlan_cos_key.direction, argv[5]);

    userid_svlan_cos_key.global_src_port = global_src_port & 0x1FFF;
    userid_svlan_cos_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);
    userid_svlan_cos_key.hash_type = USERID_KEY_TYPE_SVLAN_COS;
    userid_svlan_cos_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_SVLAN_COS, &userid_svlan_cos_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_userid_cvlan_cos,
    cli_cmodel_remove_userid_cvlan_cos_cmd,
    "cmodel remove userid-cvlan-cos chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL cvlanid CVLAN_ID ctagcos CTAG_COS direction DIRECTION",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid cvlan-cos cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "cvlan_id",
    "cvlan-id value",
    "ctag_cos",
    "ctag-cos value",
    "direction",
    "0:ipe, 1:epe")
{
    int32 ret = DRV_E_NONE;

    uint32 chip_id = 0;
    uint32 global_src_port = 0;
    uint32 cvlan_id = 0;
    ds_user_id_cvlan_cos_hash_key_t userid_cvlan_cos_key;

    sal_memset(&userid_cvlan_cos_key, 0, sizeof(userid_cvlan_cos_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", userid_cvlan_cos_key.is_label, argv[2]);
    CTC_CLI_GET_INTEGER("cvlanid", cvlan_id, argv[3]);
    userid_cvlan_cos_key.cvlan_id11_1 = cvlan_id>>1;
    userid_cvlan_cos_key.cvlan_id0 = IS_BIT_SET(cvlan_id, 0);
    CTC_CLI_GET_INTEGER("ctagcos", userid_cvlan_cos_key.ctag_cos, argv[4]);
    CTC_CLI_GET_INTEGER("direction", userid_cvlan_cos_key.direction, argv[5]);

    userid_cvlan_cos_key.global_src_port = global_src_port & 0x1FFF;
    userid_cvlan_cos_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);
    userid_cvlan_cos_key.hash_type = USERID_KEY_TYPE_CVLAN_COS;
    userid_cvlan_cos_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_CVLAN_COS, &userid_cvlan_cos_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_remove_userid_macsa,
    cli_cmodel_remove_userid_macsa_cmd,
    "cmodel remove userid-macsa chipid CHIP_ID macsa MAC_SA",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid macsa cmd",
    "chip",
    "chip value",
    "mac_sa",
    "mac_sa address in HHHH.HHHH.HHHH format")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    cm_mac_addr_t mac_sa;      /**< MAC-SA */
    ds_user_id_mac_hash_key_t userid_mac_sa_key;

    sal_memset(&userid_mac_sa_key, 0, sizeof(userid_mac_sa_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_MAC_ADDRESS("macsa", mac_sa, argv[1]);
    userid_mac_sa_key.mac_sa47_44 = mac_sa[0]>>4;
    userid_mac_sa_key.mac_sa43 = IS_BIT_SET(mac_sa[0], 3);
    userid_mac_sa_key.mac_sa42_32= MAKE_UINT16(mac_sa[0]&0x7, mac_sa[1]);
    userid_mac_sa_key.mac_sa31_0 = (mac_sa[2] << 24) | (mac_sa[3] << 16) | (mac_sa[4] << 8) | mac_sa[5];
    userid_mac_sa_key.hash_type = USERID_KEY_TYPE_MAC_SA;
    userid_mac_sa_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_MAC_SA, &userid_mac_sa_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_userid_macda,
    cli_cmodel_remove_userid_macda_cmd,
    "cmodel remove userid-macda chipid CHIP_ID macda MAC_DA",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid macda cmd",
    "chip",
    "chip value",
    "mac_da",
    "mac_da address in HHHH.HHHH.HHHH format")
    {
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    cm_mac_addr_t mac_da;      /**< MAC-DA */
    ds_user_id_mac_hash_key_t userid_mac_da_key;

    sal_memset(&userid_mac_da_key, 0, sizeof(userid_mac_da_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_MAC_ADDRESS("macda", mac_da, argv[1]);
    userid_mac_da_key.mac_sa47_44 = mac_da[0]>>4;
    userid_mac_da_key.mac_sa43 = IS_BIT_SET(mac_da[0], 3);
    userid_mac_da_key.mac_sa42_32= MAKE_UINT16(mac_da[0]&0x7, mac_da[1]);
    userid_mac_da_key.mac_sa31_0 = (mac_da[2] << 24) | (mac_da[3] << 16) | (mac_da[4] << 8) | mac_da[5];
    userid_mac_da_key.hash_type = USERID_KEY_TYPE_MAC_SA;
    userid_mac_da_key.is_mac_da = TRUE;
    userid_mac_da_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_MAC_SA, &userid_mac_da_key);

    if (ret < DRV_E_NONE)
    {
    return CLI_ERROR;
    }

    return CLI_SUCCESS;
    }


 //   "cmodel remove userid-macsa chipid CHIP_ID macsa MAC_SA direction DIRECTION ad-index AD_INDEX",
CTC_CLI(cli_cmodel_remove_userid_macsa_port,
    cli_cmodel_remove_userid_macsa_port_cmd,
    "cmodel remove userid-macsa-port chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT\
    islabel IS_LABEL macsa MAC_SA",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid macsa-port cmd",
    "chip",
    "chip value",
    "global_src_port",
    "global src port value",
    "is_label",
    "is_label value",
    "mac_sa",
    "mac_sa address in HHHH.HHHH.HHHH format")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    cm_mac_addr_t mac_sa;      /**< MAC-SA */
    uint32 global_src_port = 0;
    ds_user_id_mac_port_hash_key_t userid_mac_sa_port_key;

    sal_memset(&userid_mac_sa_port_key, 0, sizeof(userid_mac_sa_port_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    userid_mac_sa_port_key.global_src_port = global_src_port & 0x1FFF;
    userid_mac_sa_port_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    CTC_CLI_GET_INTEGER("islabel", userid_mac_sa_port_key.is_label, argv[2]);

    CTC_CLI_GET_MAC_ADDRESS("macsa", mac_sa, argv[3]);
    userid_mac_sa_port_key.mac_sa_high = MAKE_UINT16(mac_sa[0], mac_sa[1]);
    userid_mac_sa_port_key.mac_sa_low = MAKE_UINT32(mac_sa[2], mac_sa[3], mac_sa[4], mac_sa[5]);
    userid_mac_sa_port_key.hash_type = USERID_KEY_TYPE_PORT_MAC_SA;
    userid_mac_sa_port_key.hash_type1 = USERID_KEY_TYPE_PORT_MAC_SA;
    userid_mac_sa_port_key.valid = TRUE;
    userid_mac_sa_port_key.valid1 = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_PORT_MAC_SA, &userid_mac_sa_port_key);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_userid_l2,
    cli_cmodel_remove_userid_l2_cmd,
    "cmodel remove userid-l2 chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT  \
     macda MAC_DA macsa MAC_SA vlanid VLAN_ID cos COS",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid l2 cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "macda",
    "mac_da address in HHHH.HHHH.HHHH format",
    "macsa",
    "mac_sa address in HHHH.HHHH.HHHH format",
    "vlan_id",
    "vlan-id value",
    "cos",
    "cos value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0,mac_sa47_32 =0;
    ds_user_id_l2_hash_key_t l2_hash_key;
    cm_mac_addr_t mac_da,mac_sa;
    uint32 global_src_port = 0;
    sal_memset(&l2_hash_key, 0, sizeof(ds_user_id_l2_hash_key_t));
    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_MAC_ADDRESS("macda", mac_da, argv[2]);
    CTC_CLI_GET_MAC_ADDRESS("macsa", mac_sa, argv[3]);
    CTC_CLI_GET_INTEGER("vlanid", l2_hash_key.vlan_id, argv[4]);
    CTC_CLI_GET_INTEGER("cos", l2_hash_key.cos, argv[5]);
    CTC_CLI_GET_INTEGER("ad-index", l2_hash_key.ad_index, argv[6]);
    l2_hash_key.global_src_port10_0= global_src_port & 0x7FF;
    l2_hash_key.global_src_port13_11= (global_src_port>> 11) & 0x7;
    mac_sa47_32 = MAKE_UINT16(mac_sa[0], mac_sa[1]);
    l2_hash_key.mac_sa47_41= (mac_sa47_32 >> 9) & 0x7F;
    l2_hash_key.mac_sa40_32= mac_sa47_32 & 0x1FF;
    l2_hash_key.mac_sa31_0 = MAKE_UINT32(mac_sa[2], mac_sa[3], mac_sa[4], mac_sa[5]);
    l2_hash_key.mac_da47_32= MAKE_UINT16(mac_da[0], mac_da[1]);
    l2_hash_key.mac_da31_0 = MAKE_UINT32(mac_da[2], mac_da[3], mac_da[4], mac_da[5]);
    if (l2_hash_key.ad_index % 2)
    {
        CMODEL_DEBUG_OUT_INFO("%s %d The ad index value must be even!\n", __FUNCTION__, __LINE__);
        return CLI_ERROR;
    }
    l2_hash_key.hash_type0 = USERID_KEY_TYPE_L2;
    l2_hash_key.hash_type1 = USERID_KEY_TYPE_L2;
    l2_hash_key.valid0 = TRUE;
    l2_hash_key.valid1 = TRUE;
    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_L2, &l2_hash_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}
CTC_CLI(cli_cmodel_remove_userid_macda_port,
    cli_cmodel_remove_userid_macda_port_cmd,
    "cmodel remove userid-macda-port chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT\
    islabel IS_LABEL macda MAC_DA",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid macda-port cmd",
    "chip",
    "chip value",
    "global_src_port",
    "global src port value",
    "is_label",
    "is_label value",
    "mac_da",
    "mac_da address in HHHH.HHHH.HHHH format")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    cm_mac_addr_t mac_da;      /**< MAC-DA */
    uint32 global_src_port = 0;
    ds_user_id_mac_port_hash_key_t userid_mac_da_port_key;

    sal_memset(&userid_mac_da_port_key, 0, sizeof(userid_mac_da_port_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    userid_mac_da_port_key.global_src_port = global_src_port & 0x1FFF;
    userid_mac_da_port_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);
    userid_mac_da_port_key.is_mac_da = TRUE;

    CTC_CLI_GET_INTEGER("islabel", userid_mac_da_port_key.is_label, argv[2]);

    CTC_CLI_GET_MAC_ADDRESS("macda", mac_da, argv[3]);
    userid_mac_da_port_key.mac_sa_high = MAKE_UINT16(mac_da[0], mac_da[1]);
    userid_mac_da_port_key.mac_sa_low = MAKE_UINT32(mac_da[2], mac_da[3], mac_da[4], mac_da[5]);
    userid_mac_da_port_key.hash_type = USERID_KEY_TYPE_PORT_MAC_SA;
    userid_mac_da_port_key.hash_type1 = USERID_KEY_TYPE_PORT_MAC_SA;
    userid_mac_da_port_key.valid = TRUE;
    userid_mac_da_port_key.valid1 = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_PORT_MAC_SA, &userid_mac_da_port_key);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_userid_ipsa,
    cli_cmodel_remove_userid_ipsa_cmd,
    "cmodel remove userid-ipv4sa chipid CHIP_ID ipv4sa IPV4_SA",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid ipsa cmd",
    "chip",
    "chip value",
    "ip_sa",
    "ip_sa address in A.B.C.D format")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ip_sa = 0;
    ds_user_id_ipv4_hash_key_t userid_ipv4_sa_key;

    sal_memset(&userid_ipv4_sa_key, 0, sizeof(userid_ipv4_sa_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ip_sa, argv[1]);
    userid_ipv4_sa_key.ip_sa = ip_sa;

    userid_ipv4_sa_key.hash_type = USERID_KEY_TYPE_IPV4_SA;
    userid_ipv4_sa_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_IPV4_SA, &userid_ipv4_sa_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_userid_ipv4sa_port,
    cli_cmodel_remove_userid_ipv4sa_port_cmd,
    "cmodel remove userid-ipv4sa-port chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL ipv4sa IPV4_SA",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid macsa cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "ipv4_sa",
    "ipv4_sa address in A.B.C.D format")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0, ip_sa = 0;
    uint32 global_src_port = 0;
    ds_user_id_ipv4_port_hash_key_t userid_ipv4_sa_port_key;

    sal_memset(&userid_ipv4_sa_port_key, 0, sizeof(userid_ipv4_sa_port_key));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    userid_ipv4_sa_port_key.global_src_port0 = IS_BIT_SET(global_src_port, 0);
    userid_ipv4_sa_port_key.global_src_port1 = ((global_src_port>>1) & 0x1FFF);
    userid_ipv4_sa_port_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    CTC_CLI_GET_INTEGER("islabel", userid_ipv4_sa_port_key.is_label, argv[2]);

    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ip_sa, argv[3]);
    userid_ipv4_sa_port_key.ip_sa = ip_sa;
    userid_ipv4_sa_port_key.hash_type = USERID_KEY_TYPE_PORT_IPV4_SA;
    userid_ipv4_sa_port_key.valid = TRUE;
    userid_ipv4_sa_port_key.direction = USERID_DIRECTION_IPE_USERID;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_PORT_IPV4_SA, &userid_ipv4_sa_port_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_userid_port,
    cli_cmodel_remove_userid_port_cmd,
    "cmodel remove userid-port chipid CHIP_ID globalsrcport GLOBAL_SRC_PORT islabel \
     IS_LABEL direction DIRECTION",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove userid port cmd",
    "chip",
    "chip value",
    "global-src-port",
    "global src port value",
    "is-label",
    "is-label value",
    "direction",
    "direction value")
{
    int32 ret = DRV_E_NONE;

    uint32 chip_id = 0;
    uint32 global_src_port = 0;
    ds_user_id_port_hash_key_t ds_user_id_port_hash_key;

    sal_memset(&ds_user_id_port_hash_key, 0, sizeof(ds_user_id_port_hash_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("globalsrcport", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("islabel", ds_user_id_port_hash_key.is_label, argv[2]);
    CTC_CLI_GET_INTEGER("direction", ds_user_id_port_hash_key.direction, argv[3]);

    ds_user_id_port_hash_key.global_src_port = global_src_port & 0x1FFF;
    ds_user_id_port_hash_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);

    ds_user_id_port_hash_key.hash_type = USERID_KEY_TYPE_PORT;
    ds_user_id_port_hash_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_PORT, &ds_user_id_port_hash_key);
    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_mpls_section_oam,
    cli_cmodel_remove_mpls_section_oam_cmd,
    "cmodel remove mpls-section-oam chip-id CHIP_ID interface-id INTERFACE_ID ",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove mpls_section_oam",
    "chip-id",
    "chip value",
    "interface-id",
    "interfaceid value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;

    ds_mpls_oam_label_hash_key_t mpls_oam_label_key;

    sal_memset(&mpls_oam_label_key, 0, sizeof(ds_mpls_oam_label_hash_key_t));

    CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("interface-id", mpls_oam_label_key.mpls_label, argv[1]);

    mpls_oam_label_key.hash_type = USERID_KEY_TYPE_MPLS_SECTION_OAM;
    mpls_oam_label_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_MPLS_SECTION_OAM, &mpls_oam_label_key);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}



CTC_CLI(cli_cmodel_remove_pbt_oam,
    cli_cmodel_remove_pbt_oam_cmd,
    "cmodel remove pbt-oam chip-id CHIP_ID esp-id ESP_ID ",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove pbt_oam",
    "chip-id",
    "chip value",
    "esp-id",
    "esp-id value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    ds_pbt_oam_hash_key_t pbt_oam_key;

    sal_memset(&pbt_oam_key, 0, sizeof(ds_pbt_oam_hash_key_t));

    CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("esp-id", pbt_oam_key.vrf_id, argv[1]);

    pbt_oam_key.hash_type = USERID_KEY_TYPE_PBT_OAM;
    pbt_oam_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_PBT_OAM, &pbt_oam_key);
    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_mpls_label_oam,
    cli_cmodel_remove_mpls_label_oam_cmd,
    "cmodel remove mpls-label-oam chip-id CHIP_ID mplslabel MPLS_LABEL ",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove mpls_label_oam",
    "chip-id",
    "chip value",
    "mplslabel",
    "mplslabel value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    ds_mpls_oam_label_hash_key_t mpls_oam_label_key;

    sal_memset(&mpls_oam_label_key, 0, sizeof(ds_mpls_oam_label_hash_key_t));

    CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("mplslabel", mpls_oam_label_key.mpls_label, argv[1]);

    mpls_oam_label_key.hash_type = USERID_KEY_TYPE_MPLS_LABEL_OAM;
    mpls_oam_label_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_MPLS_LABEL_OAM, &mpls_oam_label_key);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_bfd_oam,
    cli_cmodel_remove_bfd_oam_cmd,
    "cmodel remove bfd-oam chip-id CHIP_ID my-discriminator MY_DIS ",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove bfd_oam",
    "chip-id",
    "chip value",
    "my-discriminator",
    "my-discriminator value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    ds_bfd_oam_hash_key_t bfd_oam_key;

    sal_memset(&bfd_oam_key, 0, sizeof(ds_bfd_oam_hash_key_t));

    CTC_CLI_GET_INTEGER("chip-id", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("my-discriminator", bfd_oam_key.my_discriminator, argv[1]);

    bfd_oam_key.hash_type = USERID_KEY_TYPE_BFD_OAM;
    bfd_oam_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_BFD_OAM, &bfd_oam_key);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_eth_oam,
    cli_cmodel_remove_eth_oam_cmd,
    "cmodel remove eth-oam chipid CHIP_ID global-src-port GLOBAL_SRC_PORT vlanid VLAN_ID isfid IS_FID ",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove eth_oam",
    "chip",
    "chip value",
    "global-src-port",
    "global-src-port value",
    "vlanid",
    "vlanid value",
    "isfid",
    "isfid value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 global_src_port = 0;
    ds_eth_oam_hash_key_t eth_oam_key;
    uint32 hash_type = 0;

    sal_memset(&eth_oam_key, 0, sizeof(ds_bfd_oam_hash_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("global-src-port", global_src_port, argv[1]);
    CTC_CLI_GET_INTEGER("vlanid", eth_oam_key.vlan_id, argv[2]);
    CTC_CLI_GET_INTEGER("isfid", eth_oam_key.is_fid, argv[3]);

    eth_oam_key.global_src_port = global_src_port&0x1FFF;
    eth_oam_key.global_src_port13 = IS_BIT_SET(global_src_port, 13);
    if(eth_oam_key.is_fid)
    {
        eth_oam_key.hash_type = USERID_KEY_TYPE_ETHER_FID_OAM;
        hash_type = USERID_HASH_TYPE_ETHER_FID_OAM;
    }
    else
    {
        eth_oam_key.hash_type = USERID_KEY_TYPE_ETHER_VLAN_OAM;
        hash_type = USERID_HASH_TYPE_ETHER_VLAN_OAM;
    }

    eth_oam_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, hash_type, &eth_oam_key);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_remove_eth_oam_rmep,
    cli_cmodel_remove_eth_oam_rmep_cmd,
    "cmodel remove eth-oam-rmep chipid CHIP_ID mep-index MEP_INDEX rmep-id RMEP_ID ",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove eth_oam_rmep",
    "chip",
    "chip value",
    "mep-index",
    "mep-index value",
    "rmep-id",
    "rmep-id value")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    ds_eth_oam_rmep_hash_key_t eth_oam_rmep_key;

    sal_memset(&eth_oam_rmep_key, 0, sizeof(ds_eth_oam_rmep_hash_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("mep-index", eth_oam_rmep_key.mep_index, argv[1]);
    CTC_CLI_GET_INTEGER("rmep-id", eth_oam_rmep_key.rmep_id, argv[2]);

    eth_oam_rmep_key.hash_type = USERID_KEY_TYPE_ETHER_RMEP;
    eth_oam_rmep_key.valid = TRUE;

    ret = cm_sim_cfg_kit_delete_userid_key(chip_id, USERID_HASH_TYPE_ETHER_RMEP, &eth_oam_rmep_key);

    if(ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_eth_oam_tcam_key,
    cli_cmodel_add_eth_oam_tcam_key_cmd,
    "cmodel add eth-oam-key chipid CHIP_ID index KEY_INDEX global-srcport PORT is-fid IS_FID vlan-id VLAN",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove eth_oam_rmep",
    "chip",
    "chip value",
    "mep-index",
    "mep-index value",
    "rmep-id",
    "rmep-id value")
{

    uint32 cmd = 0;
    uint32 chip_id  = 0;
    uint32 idx = 0;
    uint32 src_port = 0;
    uint32 is_fid =0 ;
    uint32 vlan_id = 0;
    ds_fib_user_id80_key_t  ds_fib_user_id80_key;
    ds_fib_user_id80_key_t  ds_fib_user_id80_mask;

    tbl_entry_t entry;

    sal_memset(&ds_fib_user_id80_key, 0 ,sizeof(ds_fib_user_id80_key_t));
    sal_memset(&ds_fib_user_id80_mask, 0 ,sizeof(ds_fib_user_id80_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("index", idx, argv[1]);
    CTC_CLI_GET_INTEGER("global_src_port", src_port, argv[2]);
    CTC_CLI_GET_INTEGER("is_fid", is_fid, argv[3]);
    CTC_CLI_GET_INTEGER("vlanid", vlan_id, argv[4]);

    ds_fib_user_id80_key.table_id   = 0;
    ds_fib_user_id80_key.is_user_id = 1;
    ds_fib_user_id80_key.global_src_port = src_port;
    if(is_fid)
    {
        ds_fib_user_id80_key.user_id_hash_type = USERID_KEY_TYPE_ETHER_FID_OAM;
    }
    else
    {
        ds_fib_user_id80_key.user_id_hash_type = USERID_KEY_TYPE_ETHER_VLAN_OAM;
    }

    ds_fib_user_id80_key.ip_sa = ((is_fid << 14) | (vlan_id & 0x3FFF));

    /*
    ds_fib_user_id80_key.direction;
    ds_fib_user_id80_key.is_label;
    ds_fib_user_id80_key.radio_mac47_32;
    ds_fib_user_id80_key.rid;
    */
    ds_fib_user_id80_mask.table_id = 0x3;
    ds_fib_user_id80_mask.is_user_id = 1;
    ds_fib_user_id80_mask.global_src_port = 0x3FFF;
    ds_fib_user_id80_mask.user_id_hash_type = 0x1F;
    ds_fib_user_id80_mask.ip_sa = 0xFFFFFFFF;

    entry.data_entry = (uint32 *)&ds_fib_user_id80_key;
    entry.mask_entry = (uint32 *)&ds_fib_user_id80_mask;


    cmd = DRV_IOW(DsLpmTcam80Key_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, idx, cmd, &entry));

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_tunnel_id_capwap_confit_tcam_key,
    cli_cmodel_add_tunnel_id_capwap_confit_tcam_key_cmd,
    "cmodel add tunnel_id_capwap_confit_tcam_key chipid CHIP_ID index KEY_INDEX rid RID radiomac RADIO_MAC",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnel_id_capwap_confit_tcam_key",
    "chip",
    "chip value",
    "index",
    "index value"
    "rid",
    "rid value",
    "radiomac",
    "radiomac value")
{
    uint32 chip_id = 0;
    uint32 rid = 0;
    uint32 index = 0;
    uint32 cmd = 0;
    cm_mac_addr_t radio_mac;
    ds_fib_user_id80_key_t  ds_fib_user_id80_key;
    ds_fib_user_id80_key_t  ds_fib_user_id80_mask;

    tbl_entry_t entry;

    sal_memset(&ds_fib_user_id80_key, 0 ,sizeof(ds_fib_user_id80_key_t));
    sal_memset(&ds_fib_user_id80_mask, 0 ,sizeof(ds_fib_user_id80_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("index", index, argv[1]);
    CTC_CLI_GET_INTEGER("rid", rid, argv[2]);
    CTC_CLI_GET_MAC_ADDRESS("radio_mac", radio_mac, argv[3]);

    ds_fib_user_id80_key.table_id   = 0;
    ds_fib_user_id80_key.is_user_id = 1;
    ds_fib_user_id80_key.rid = rid;
    ds_fib_user_id80_key.radio_mac47_32 = MAKE_UINT16(radio_mac[0],radio_mac[1]);
    ds_fib_user_id80_key.ip_sa = MAKE_UINT32(radio_mac[2],radio_mac[3],radio_mac[4],radio_mac[5]);
    ds_fib_user_id80_key.user_id_hash_type = USERID_KEY_TYPE_CAPWAP;

    ds_fib_user_id80_mask.table_id = 0x3;
    ds_fib_user_id80_mask.is_user_id = 1;
    ds_fib_user_id80_mask.rid = 0x1F;
    ds_fib_user_id80_mask.user_id_hash_type = 0x1F;
    ds_fib_user_id80_mask.radio_mac47_32 = 0xFFFF;
    ds_fib_user_id80_mask.ip_sa = 0xFFFFFFFF;

    entry.data_entry = (uint32 *)&ds_fib_user_id80_key;
    entry.mask_entry = (uint32 *)&ds_fib_user_id80_mask;


    cmd = DRV_IOW(DsLpmTcam80Key_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, index, cmd, &entry));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_tunnelid_ipv4_udp_confit_tcam_key,
    cli_cmodel_add_tunnelid_ipv4_udp_confit_tcam_key_cmd,
    "cmodel add tunnelid-ipv4-udp-confit-tcam-key index INDEX chipid CHIP_ID ipv4sa IPV4_SA ipv4da IPV4_DA\
    udpsrcport UDP_SRC_PORT udpdstport UDP_DST_PORT layer4type LAYER4_TYPE",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnelid-ipv4-udp-confit-tcam-key cmd",
    "index",
    "index value"
    "chip",
    "chip-value",
    "ipv4sa",
    "ipv4_sa address in A.B.C.D format",
    "ipv4da",
    "ipv4_da address in A.B.C.D format",
    "udpsrcport",
    "udp-src-port-value",
    "udpdstport",
    "udp-dst-port-value",
    "layer4type",
    "layer4type-value")
{
    uint32 chip_id = 0;
    uint32 ipsa, ipda;
    uint32 udp_src_port, udp_dst_port,layer4type;
    uint32 index = 0;
    uint32 cmd = 0;

    ds_fib_user_id160_key_t  ds_fib_user_id160_key;
    ds_fib_user_id160_key_t  ds_fib_user_id160_mask;

    tbl_entry_t entry;

    sal_memset(&ds_fib_user_id160_key, 0 ,sizeof(ds_fib_user_id160_key_t));
    sal_memset(&ds_fib_user_id160_mask, 0 ,sizeof(ds_fib_user_id160_key_t));

    CTC_CLI_GET_INTEGER("index", index, argv[0]);

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[1]);
    chip_id = 0;
    CTC_CLI_GET_IPV4_ADDRESS("ipv4sa", ipsa, argv[2]);

    CTC_CLI_GET_IPV4_ADDRESS("ipv4da", ipda, argv[3]);

    CTC_CLI_GET_INTEGER("udpsrcport", udp_src_port, argv[4]);

    CTC_CLI_GET_INTEGER("udpdstport", udp_dst_port, argv[5]);

    CTC_CLI_GET_INTEGER("layer4type", layer4type, argv[6]);

    ds_fib_user_id160_key.table_id0   = 0;
    ds_fib_user_id160_key.table_id1   = 0;
    ds_fib_user_id160_key.is_user_id0 = 1;
    ds_fib_user_id160_key.is_user_id1 = 1;
    ds_fib_user_id160_key.udp_src_port = udp_src_port;
    ds_fib_user_id160_key.udp_dest_port9_0 = udp_dst_port & 0x3FF;
    ds_fib_user_id160_key.udp_dest_port15_10 = (udp_dst_port >> 10) & 0x3F;
    ds_fib_user_id160_key.layer4_type = layer4type;
    ds_fib_user_id160_key.ip_da = ipda;
    ds_fib_user_id160_key.ip_sa = ipsa;

    ds_fib_user_id160_key.user_id_hash_type0 = USERID_KEY_TYPE_IPV4_UDP;
    ds_fib_user_id160_key.user_id_hash_type1 = USERID_KEY_TYPE_IPV4_UDP;

    ds_fib_user_id160_mask.table_id0 = 0x3;
    ds_fib_user_id160_mask.table_id1 = 0x3;
    ds_fib_user_id160_mask.is_user_id0 = 1;
    ds_fib_user_id160_mask.is_user_id1 = 1;
    ds_fib_user_id160_mask.user_id_hash_type0 = 0x1F;
    ds_fib_user_id160_mask.user_id_hash_type1 = 0x1F;
    ds_fib_user_id160_mask.udp_src_port = 0xFFFF;
    ds_fib_user_id160_mask.udp_dest_port9_0 = 0x3FF;
    ds_fib_user_id160_mask.udp_dest_port15_10 = 0x3F;
    ds_fib_user_id160_mask.layer4_type = 0xF;
    ds_fib_user_id160_mask.ip_sa = 0xFFFFFFFF;
    ds_fib_user_id160_mask.ip_da = 0xFFFFFFFF;

    entry.data_entry = (uint32 *)&ds_fib_user_id160_key;
    entry.mask_entry = (uint32 *)&ds_fib_user_id160_mask;


    cmd = DRV_IOW(DsLpmTcam160Key_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, index, cmd, &entry));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_tunnel_id_tcam_ad,
    cli_cmodel_add_tunnel_id_tcam_ad_cmd,
    "cmodel add tunnel-id-ad chipid CHIP_ID index KEY_INDEX dsfwdptr-valid  DSFWDPTR_VALID fid FID  is-tunnel IS_TUNNEL  binding-datalow BINDING_DATALOW",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add tunnel-id-ad",
    "chip",
    "chip value",
    "index",
    "index value",
    "dsfwdptr_valid",
    "dsfwdptr_valid value",
    "fid",
    "fid value",
    "is_tunnel",
    "is_tunnel value",
    "binding_datalow",
    "binding_datalow value")
{
    uint32 cmd = 0;

    uint32 chip_id  = 0;
    uint32 idx = 0;
    uint32 dsfwdptr_valid = 0;
    uint32 fid = 0;
    uint32 is_tunnel = 0;
    uint32 binding_datalow = 0;
    void     *ad = NULL;
    ds_tunnel_id_t        ds_tunnel_id;

    sal_memset(&ds_tunnel_id, 0 ,sizeof(ds_tunnel_id));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("index", idx, argv[1]);

    CTC_CLI_GET_INTEGER("dsfwdptr-valid", dsfwdptr_valid, argv[2]);
    CTC_CLI_GET_INTEGER("fid", fid, argv[3]);
    CTC_CLI_GET_INTEGER("is-tunnel", is_tunnel, argv[4]);
    CTC_CLI_GET_INTEGER("binding-datalow", binding_datalow, argv[5]);

    ds_tunnel_id.ds_fwd_ptr_valid = dsfwdptr_valid;
    ds_tunnel_id.fid = fid;
    ds_tunnel_id.is_tunnel = is_tunnel;
    ds_tunnel_id.binding_data_low = binding_datalow;


    ad = &ds_tunnel_id;

    cmd = DRV_IOW(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, idx, cmd, ad));

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_eth_oam_tcam_ad,
    cli_cmodel_add_eth_oam_tcam_ad_cmd,
    "cmodel add eth-oam-ad chipid CHIP_ID index KEY_INDEX oam-dest-chip DEST_CHIP mep-idx MEP_IDX down-mep-bit DOWN_BIT_MAP up-mep-bit UP_BIT_MAP",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove eth_oam_rmep",
    "chip",
    "chip value",
    "mep-index",
    "mep-index value",
    "rmep-id",
    "rmep-id value")
{
    uint32 cmd = 0;

    uint32 chip_id  = 0;
    uint32 idx = 0;
    uint32 mep_idx = 0;
    uint32 dest_chip_id = 0;
    uint32 down_bit_map = 0;
    uint32 up_bit_map = 0;
    void     *ad = NULL;
    ds_eth_oam_tcam_chan_t        ds_eth_oam_tcam_ad;

    sal_memset(&ds_eth_oam_tcam_ad, 0 ,sizeof(ds_eth_oam_tcam_chan_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("index", idx, argv[1]);

    CTC_CLI_GET_INTEGER("oam_dest_chip", dest_chip_id, argv[2]);
    CTC_CLI_GET_INTEGER("mep_idx", mep_idx, argv[3]);
    CTC_CLI_GET_INTEGER("down_bitmap", down_bit_map, argv[4]);
    CTC_CLI_GET_INTEGER("up_bitmap", up_bit_map, argv[5]);

    ds_eth_oam_tcam_ad.mep_index0 = mep_idx;
    ds_eth_oam_tcam_ad.oam_dest_chip_id = dest_chip_id;
    ds_eth_oam_tcam_ad.mep_down_bitmap_low = down_bit_map&0xF;
    ds_eth_oam_tcam_ad.mep_down_bitmap_high = (down_bit_map >> 4)&0x7;

    ds_eth_oam_tcam_ad.mep_up_bitmap_low  = up_bit_map&0xF;
    ds_eth_oam_tcam_ad.mep_up_bitmap_high = (up_bit_map >> 4)&0x7;


    ad = &ds_eth_oam_tcam_ad;

    cmd = DRV_IOW(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, idx, cmd, ad));

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_eth_oam_rmep_tcam_key,
    cli_cmodel_add_eth_oam_rmep_tcam_key_cmd,
    "cmodel add eth-oam-rmep-key chipid CHIP_ID index KEY_INDEX mep-index MEP_IDX rmep-id RMEP_ID",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add eth_oam_rmep",
    "chip",
    "chip value",
    "mep-index",
    "mep-index value",
    "rmep-id",
    "rmep-id value")
{

    uint32 cmd = 0;
    uint32 chip_id  = 0;
    uint32 idx = 0;
    uint32 mep_idx = 0;
    uint32 rmep_id =0 ;

    ds_fib_user_id80_key_t  ds_fib_user_id80_key;
    ds_fib_user_id80_key_t  ds_fib_user_id80_mask;

    tbl_entry_t entry;

    sal_memset(&ds_fib_user_id80_key, 0 ,sizeof(ds_fib_user_id80_key_t));
    sal_memset(&ds_fib_user_id80_mask, 0 ,sizeof(ds_fib_user_id80_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("index", idx, argv[1]);
    CTC_CLI_GET_INTEGER("mep-index", mep_idx, argv[2]);
    CTC_CLI_GET_INTEGER("rmep-id", rmep_id, argv[3]);

    ds_fib_user_id80_key.table_id   = 0;
    ds_fib_user_id80_key.is_user_id = 1;
    ds_fib_user_id80_key.user_id_hash_type = USERID_KEY_TYPE_ETHER_RMEP;

    ds_fib_user_id80_key.ip_sa = ((rmep_id << 14) | (mep_idx & 0x3FFF));

    /*
    ds_fib_user_id80_key.direction;
    ds_fib_user_id80_key.is_label;
    ds_fib_user_id80_key.radio_mac47_32;
    ds_fib_user_id80_key.rid;
    */
    ds_fib_user_id80_mask.table_id = 0x3;
    ds_fib_user_id80_mask.is_user_id = 1;
    ds_fib_user_id80_mask.user_id_hash_type = 0x1F;
    ds_fib_user_id80_mask.ip_sa = 0xFFFFFFFF;

    entry.data_entry = (uint32 *)&ds_fib_user_id80_key;
    entry.mask_entry = (uint32 *)&ds_fib_user_id80_mask;


    cmd = DRV_IOW(DsLpmTcam80Key_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, idx, cmd, &entry));

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_eth_oam_rmep_tcam_ad,
    cli_cmodel_add_eth_oam_tcam_rmep_ad_cmd,
    "cmodel add eth-oam-rmep-ad chipid CHIP_ID index KEY_INDEX ad-idx AD_IDX",
    "Cmodel cmd",
    "Cmodel remove cmd",
    "Cmodel remove eth_oam_rmep",
    "chip",
    "chip value",
    "mep-index",
    "mep-index value",
    "rmep-id",
    "rmep-id value")
{
    uint32 cmd = 0;

    uint32 chip_id  = 0;
    uint32 idx = 0;
    uint32 rmep_idx = 0;

    lpm_tcam_ad_mem_t lpm_tcam_ad_mem;
    ds_eth_rmep_chan_t ds_eth_rmep_chan;
    sal_memset(&ds_eth_rmep_chan, 0 ,sizeof(ds_eth_rmep_chan_t));
    sal_memset(&lpm_tcam_ad_mem, 0 ,sizeof(lpm_tcam_ad_mem_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("index", idx, argv[1]);

    CTC_CLI_GET_INTEGER("ad_index", rmep_idx, argv[2]);

    ds_eth_rmep_chan.ad_index = rmep_idx;

    sal_memcpy((uint8*)&lpm_tcam_ad_mem + sizeof(ds_eth_rmep_chan_t), (uint8*)&ds_eth_rmep_chan, sizeof(ds_eth_rmep_chan_t));

    cmd = DRV_IOW(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, idx, cmd, &lpm_tcam_ad_mem));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_add_mpls_label_oam_tcam_key,
    cli_cmodel_add_mpls_label_oam_tcam_key_cmd,
    "cmodel add mpls-label-key chipid CHIP_ID index KEY_INDEX mpls-label LABEL mpls-label-space LABEL_SPACE",
    "Cmodel cmd",
    "Cmodel add lpm tcam cmd",
    "Cmodel add mpls label tcam key",
    "chip",
    "chip value",
    "key-index",
    "tcam-key-index value",
    "mpls label",
    "mpls label value",
    "mpls label space",
    "mpls label space value")
{

    uint32 cmd = 0;
    uint32 chip_id  = 0;
    uint32 idx = 0;
    uint32 mpls_label =0 ;
    uint32 mpls_label_space  = 0;
    ds_fib_user_id80_key_t  ds_fib_user_id80_key;
    ds_fib_user_id80_key_t  ds_fib_user_id80_mask;

    tbl_entry_t entry;

    sal_memset(&ds_fib_user_id80_key, 0 ,sizeof(ds_fib_user_id80_key_t));
    sal_memset(&ds_fib_user_id80_mask, 0 ,sizeof(ds_fib_user_id80_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("index", idx, argv[1]);
    CTC_CLI_GET_INTEGER("mpls-label", mpls_label, argv[2]);
    CTC_CLI_GET_INTEGER("mpls-label-space", mpls_label_space, argv[3]);

    ds_fib_user_id80_key.table_id   = 0;
    ds_fib_user_id80_key.is_user_id = 1;
    ds_fib_user_id80_key.user_id_hash_type = USERID_KEY_TYPE_MPLS_LABEL_OAM;
    ds_fib_user_id80_key.ip_sa = ((mpls_label_space << 20) | (mpls_label & 0xFFFFF));

    ds_fib_user_id80_mask.table_id = 0x3;
    ds_fib_user_id80_mask.is_user_id = 1;
    ds_fib_user_id80_mask.user_id_hash_type = 0x1F;
    ds_fib_user_id80_mask.ip_sa = 0xFFFFFFFF;

    entry.data_entry = (uint32 *)&ds_fib_user_id80_key;
    entry.mask_entry = (uint32 *)&ds_fib_user_id80_mask;


    cmd = DRV_IOW(DsLpmTcam80Key_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, idx, cmd, &entry));

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_mpls_section_oam_tcam_key,
    cli_cmodel_add_mpls_section_oam_tcam_key_cmd,
    "cmodel add mpls-section-key chipid CHIP_ID index KEY_INDEX interface-id INTERFACE_ID",
    "Cmodel cmd",
    "Cmodel add lpm tcam cmd",
    "Cmodel add mpls section tcam key",
    "chip",
    "chip value",
    "key-index",
    "tcam-key-index value",
    "interface id",
    "interface id value")
{

    uint32 cmd = 0;
    uint32 chip_id  = 0;
    uint32 idx = 0;
    uint32 interface_id =0 ;
    ds_fib_user_id80_key_t  ds_fib_user_id80_key;
    ds_fib_user_id80_key_t  ds_fib_user_id80_mask;

    tbl_entry_t entry;

    sal_memset(&ds_fib_user_id80_key, 0 ,sizeof(ds_fib_user_id80_key_t));
    sal_memset(&ds_fib_user_id80_mask, 0 ,sizeof(ds_fib_user_id80_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("index", idx, argv[1]);
    CTC_CLI_GET_INTEGER("interface-id", interface_id, argv[2]);

    ds_fib_user_id80_key.table_id   = 0;
    ds_fib_user_id80_key.is_user_id = 1;
    ds_fib_user_id80_key.user_id_hash_type = USERID_KEY_TYPE_MPLS_SECTION_OAM;
    ds_fib_user_id80_key.ip_sa =  (interface_id & 0x3FF);

    ds_fib_user_id80_mask.table_id = 0x3;
    ds_fib_user_id80_mask.is_user_id = 1;
    ds_fib_user_id80_mask.user_id_hash_type = 0x1F;
    ds_fib_user_id80_mask.ip_sa = 0x3FF;

    entry.data_entry = (uint32 *)&ds_fib_user_id80_key;
    entry.mask_entry = (uint32 *)&ds_fib_user_id80_mask;


    cmd = DRV_IOW(DsLpmTcam80Key_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, idx, cmd, &entry));

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_bfd_oam_tcam_key,
    cli_cmodel_add_bfd_oam_tcam_key_cmd,
    "cmodel add bfd-oam-key chipid CHIP_ID index KEY_INDEX my-disc MY_DISC",
    "Cmodel cmd",
    "Cmodel add lpm tcam cmd",
    "Cmodel add bfd oam tcam key",
    "chip",
    "chip value",
    "key-index",
    "tcam-key-index value",
    "myDiscriminator",
    "myDiscriminator value")
{

    uint32 cmd = 0;
    uint32 chip_id  = 0;
    uint32 idx = 0;
    uint32 my_disc =0 ;
    ds_fib_user_id80_key_t  ds_fib_user_id80_key;
    ds_fib_user_id80_key_t  ds_fib_user_id80_mask;

    tbl_entry_t entry;

    sal_memset(&ds_fib_user_id80_key, 0 ,sizeof(ds_fib_user_id80_key_t));
    sal_memset(&ds_fib_user_id80_mask, 0 ,sizeof(ds_fib_user_id80_key_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("index", idx, argv[1]);
    CTC_CLI_GET_INTEGER("my-disc", my_disc, argv[2]);

    ds_fib_user_id80_key.table_id   = 0;
    ds_fib_user_id80_key.is_user_id = 1;
    ds_fib_user_id80_key.user_id_hash_type = USERID_KEY_TYPE_BFD_OAM;
    ds_fib_user_id80_key.ip_sa =  my_disc ;

    ds_fib_user_id80_mask.table_id = 0x3;
    ds_fib_user_id80_mask.is_user_id = 1;
    ds_fib_user_id80_mask.user_id_hash_type = 0x1F;
    ds_fib_user_id80_mask.ip_sa = 0xFFFFFFFF;

    entry.data_entry = (uint32 *)&ds_fib_user_id80_key;
    entry.mask_entry = (uint32 *)&ds_fib_user_id80_mask;


    cmd = DRV_IOW(DsLpmTcam80Key_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, idx, cmd, &entry));

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_add_mpls_label_oam_tcam_ad,
    cli_cmodel_add_mpls_label_oam_tcam_ad_cmd,
    "cmodel add mpls-label-oam-ad chipid CHIP_ID index KEY_INDEX oam-dest-chip DEST_CHIP mep-idx MEP_IDX ( { lm-type LM_TYPE | lm-index-base LM_IDX | lm-cos-type LM_COS_TYPE |  lm-cos LM_COS | mpls-lm-type MPLS_LM_TYPE | bfd-single-hop BFD_SINGLE_HOP } | )",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel add mpls pbt bfd tcam ad",
    "chip",
    "chip value",
    "mep-index",
    "mep-index value",
    "lm type",
    "lm type value",
    "lm index base",
    "lm index base vlaue",
    "lm cos type",
    "lm cos type value",
    "lm-cos",
    "lm-cos value",
    "mpls-lm-type",
    "mpls-lm-type value",
    "bfd-single-hop",
    "bfd-single-hop value")
{
    uint32 cmd = 0;

    uint32 chip_id  = 0;
    uint32 idx = 0;
    uint32 mep_idx = 0;
    uint32 dest_chip_id = 0;
    uint32 lm_type = 0;
    uint32 lm_index_base = 0;
    uint32 lm_cos_type = 0;
    uint32 lm_cos = 0;
    uint32 mpls_lm_type = 0;
    uint32 bfd_single_hop = 0;
    uint8 index = 0;

    ds_lpm_tcam_ad_t  ad;
    ds_mpls_pbt_bfd_oam_chan_t *ds_mpls_pbt_bfd_oam_chan;
    ds_mpls_pbt_bfd_oam_chan = (ds_mpls_pbt_bfd_oam_chan_t *)((uint8*)&ad + sizeof(ds_3word_hash_key_t));

    sal_memset((void *)&ad, 0 ,sizeof(ds_lpm_tcam_ad_t));

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;
    CTC_CLI_GET_INTEGER("index", idx, argv[1]);

    CTC_CLI_GET_INTEGER("oam_dest_chip", dest_chip_id, argv[2]);
    CTC_CLI_GET_INTEGER("mep_idx", mep_idx, argv[3]);

    index = ctc_cli_get_prefix_item(&argv[0], argc, "lm-type", sal_strlen("lm-type"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lm-type", lm_type, argv[index+1]);
    }


    index = ctc_cli_get_prefix_item(&argv[0], argc, "lm-index-base", sal_strlen("lm-index-base"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lm-index-base", lm_index_base, argv[index+1]);
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "lm-cos-type", sal_strlen("lm-cos-type"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lm-cos-type", lm_cos_type, argv[index+1]);
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "lm-cos", sal_strlen("lm-cos"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lm-cos", lm_cos, argv[index+1]);
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "mpls-lm-type", sal_strlen("mpls-lm-type"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("mpls-lm-type", mpls_lm_type, argv[index+1]);
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "bfd-single-hop", sal_strlen("bfd-single-hop"));
    if(0xFF != index)
    {
        CTC_CLI_GET_INTEGER("bfd-single-hop", bfd_single_hop, argv[index+1]);
    }


    ds_mpls_pbt_bfd_oam_chan->oam_dest_chip_id  = dest_chip_id;
    ds_mpls_pbt_bfd_oam_chan->mep_index         = mep_idx;

    ds_mpls_pbt_bfd_oam_chan->lm_type       = lm_type;
    ds_mpls_pbt_bfd_oam_chan->lm_index_base = lm_index_base;
    ds_mpls_pbt_bfd_oam_chan->lm_cos_type   = lm_cos_type;
    ds_mpls_pbt_bfd_oam_chan->lm_cos        = lm_cos;
    ds_mpls_pbt_bfd_oam_chan->mpls_lm_type  = mpls_lm_type;
    ds_mpls_pbt_bfd_oam_chan->bfd_single_hop = bfd_single_hop;

    ds_mpls_pbt_bfd_oam_chan->lm_level = 0;

    cmd = DRV_IOW(LpmTcamAdMem_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, idx, cmd, &ad));

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_ipv6_mcast_key,
    cli_cmodel_ipv6_mcast_key_cmd,
    "cmodel (add|del) ipv6-mcast chipid CHIPID ipsa X:X::X:X ipda X:X::X:X vrf-id VRF_ID is-mac IS_MAC ({nexthop NEXTHOP} | )",
    "Cmodel cmd",
    "Cmodel add cmd",
    "Cmodel del cmd",
    "Cmodel ipv6 mcast cmd",
    "chipid",
    "chipid value",
    "IPv6 sa address",
    "IP address in X:X::X:X format",
    "IPv6 da address",
    "IP address in X:X::X:X format",
    "vrf id",
    "<0-0x800>",
    "nexthop when add",
    "<0-0xFFFF>")
{
    int32 ret = DRV_E_NONE;
    uint32 chip_id = 0;
    uint32 vrf_id = 0;
    cm_ipv6_addr_t ip_sa;
    cm_ipv6_addr_t ip_da;
    uint32 nexthop = 0;
    uint32 is_add = FALSE;
    uint32 is_mac = FALSE;
    uint16 ipv6_sa_prefix = 0;
    uint32 cmd = 0;
    key_info_t key_info;
    uint8 hash_key[(LPM_VRF_ID_DATA_WIDTH / 8) + 1] = {0};
    uint32 crc = 0;

    fib_engine_lookup_ctl_t fib_engine_lookup_ctl;
    ds_lpm_ipv6_mcast_hash0_key_t ds_lpm_ipv6_mcast_hash0_key;
    ds_lpm_ipv6_mcast_hash1_key_t ds_lpm_ipv6_mcast_hash1_key;

    if (!sal_memcmp(argv[0], "add", sizeof("add")))
    {
        is_add = TRUE;
    }

    if ((!is_add) && (argc > 6))
    {
        ctc_cli_out("Fail to delete, the nexthop is unnecessary.\n");
        return CLI_ERROR;
    }
    else if (is_add && (argc < 8))
    {
        ctc_cli_out("Fail to add, the nexthop is necessary.\n");
        return CLI_ERROR;
    }

    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));
    sal_memset(&ds_lpm_ipv6_mcast_hash0_key, 0, sizeof(ds_lpm_ipv6_mcast_hash0_key_t));
    sal_memset(&ds_lpm_ipv6_mcast_hash1_key, 0, sizeof(ds_lpm_ipv6_mcast_hash1_key_t));

    CTC_CLI_GET_UINT32("chipid", chip_id, argv[1]);
    chip_id = 0;
    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ip_sa.ip32, argv[2]);
    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ip_da.ip32, argv[3]);
    CTC_CLI_GET_UINT32("vrf-id", vrf_id, argv[4]);
    CTC_CLI_GET_UINT32("is-mac", is_mac, argv[5]);

    /* adjust endian */
    ip_da.ip32[3] = sal_htonl(ip_da.ip32[3]);
    ip_da.ip32[2] = sal_htonl(ip_da.ip32[2]);
    ip_da.ip32[1] = sal_htonl(ip_da.ip32[1]);
    ip_da.ip32[0] = sal_htonl(ip_da.ip32[0]);

    ip_sa.ip32[3] = sal_htonl(ip_sa.ip32[3]);
    ip_sa.ip32[2] = sal_htonl(ip_sa.ip32[2]);
    ip_sa.ip32[1] = sal_htonl(ip_sa.ip32[1]);
    ip_sa.ip32[0] = sal_htonl(ip_sa.ip32[0]);

    sal_memset(&fib_engine_lookup_ctl, 0, sizeof(fib_engine_lookup_ctl_t));
    cmd = DRV_IOR(FibEngineLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &fib_engine_lookup_ctl));

    if (is_add)
    {
        CTC_CLI_GET_UINT32("nexthop", nexthop, argv[7]);

        if (!(ip_sa.ip32[0]) && (!ip_sa.ip32[1]) && (!ip_sa.ip32[2]) && (!ip_sa.ip32[0]))
        {
            ds_lpm_ipv6_mcast_hash0_key.ip_da31_0 = ip_da.ip32[3];
            ds_lpm_ipv6_mcast_hash0_key.ip_da47_32 = ip_da.ip32[2] & 0xFFFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da55_48 = (ip_da.ip32[2] >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da87_56 =((ip_da.ip32[1] & 0xFFFFFF) << 8)
                                                     | ((ip_da.ip32[2] >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da109_88 = ((ip_da.ip32[0] & 0x3FFF) << 8)
                                                     | ((ip_da.ip32[1] >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da111_110 = (ip_da.ip32[0] >> 14) & 0x3;
            ds_lpm_ipv6_mcast_hash0_key.ip_da119_112 = (ip_da.ip32[0] >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id0_0 = vrf_id & 0x1;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id10_1 = (vrf_id >> 1) & 0x3FF;
            ds_lpm_ipv6_mcast_hash0_key.hash_type0 = LPM_HASH_TYPE_IPV6_XG;
            ds_lpm_ipv6_mcast_hash0_key.hash_type1 = LPM_HASH_TYPE_IPV6_XG;
            ds_lpm_ipv6_mcast_hash0_key.nexthop = nexthop;
            ds_lpm_ipv6_mcast_hash0_key.valid0  = TRUE;
            ds_lpm_ipv6_mcast_hash0_key.valid1 =  TRUE;
            ds_lpm_ipv6_mcast_hash0_key.is_mac = is_mac;
            ret = cm_sim_cfg_kit_add_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV6_XG, &ds_lpm_ipv6_mcast_hash0_key);
        }
        else
        {
            sal_memset(&key_info, 0, sizeof(key_info_t));
            key_info.p_hash_key = hash_key;

            drv_hash_lookup_add_field(ip_da.ip32[3], 32, &key_info.key_length, key_info.p_hash_key);
            drv_hash_lookup_add_field(ip_da.ip32[2], 32, &key_info.key_length, key_info.p_hash_key);
            drv_hash_lookup_add_field(ip_da.ip32[1], 32, &key_info.key_length, key_info.p_hash_key);
            drv_hash_lookup_add_field(ip_da.ip32[0] & 0xFFFFFF, 24, &key_info.key_length, key_info.p_hash_key);
            drv_hash_lookup_add_field(vrf_id, 11, &key_info.key_length, key_info.p_hash_key);

            crc = cm_hash_calculate_lpm_ipv6_mcast(key_info.p_hash_key, LPM_VRF_ID_DATA_WIDTH);

            ds_lpm_ipv6_mcast_hash0_key.ip_da31_0 = ip_da.ip32[3];
            ds_lpm_ipv6_mcast_hash0_key.ip_da47_32 = ip_da.ip32[2] & 0xFFFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da55_48 = (ip_da.ip32[2] >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da87_56 =((ip_da.ip32[1] & 0xFFFFFF) << 8)
                                                     | ((ip_da.ip32[2] >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da109_88 = ((ip_da.ip32[0] & 0x3FFF) << 8)
                                                     | ((ip_da.ip32[1] >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da111_110 = (ip_da.ip32[0] >> 14) & 0x3;
            ds_lpm_ipv6_mcast_hash0_key.ip_da119_112 = (ip_da.ip32[0] >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id0_0 = vrf_id & 0x1;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id10_1 = (vrf_id >> 1) & 0x3FF;
            ds_lpm_ipv6_mcast_hash0_key.hash_type0 = LPM_HASH_TYPE_IPV6_SG0;
            ds_lpm_ipv6_mcast_hash0_key.hash_type1 = LPM_HASH_TYPE_IPV6_SG0;
            ds_lpm_ipv6_mcast_hash0_key.nexthop = crc;
            ds_lpm_ipv6_mcast_hash0_key.valid0  = TRUE;
            ds_lpm_ipv6_mcast_hash0_key.valid1 =  TRUE;
            ds_lpm_ipv6_mcast_hash0_key.is_mac = is_mac;

            ret = cm_sim_cfg_kit_add_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV6_SG0, &ds_lpm_ipv6_mcast_hash0_key);

            ds_lpm_ipv6_mcast_hash1_key.ip_sa31_0 = ip_sa.ip32[3];
            ds_lpm_ipv6_mcast_hash1_key.ip_sa47_32 = ip_sa.ip32[2] & 0xFFFF;
            ds_lpm_ipv6_mcast_hash1_key.ip_sa55_48 = (ip_sa.ip32[2] >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash1_key.ip_sa87_56 = ((ip_sa.ip32[1] & 0xFFFFFF) << 8)| ((ip_sa.ip32[2] >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash1_key.ip_sa117_88 = ((ip_sa.ip32[0] & 0x3FFFFF) << 8) | (ip_sa.ip32[1] >> 24);

            ds_lpm_ipv6_mcast_hash1_key.hash0_result1_0 = crc & 0x3;
            ds_lpm_ipv6_mcast_hash1_key.hash0_result2_2 = (crc >> 2) & 0x1;
            ds_lpm_ipv6_mcast_hash1_key.hash0_result10_3 = (crc >> 3) & 0xFF;
            ds_lpm_ipv6_mcast_hash1_key.hash_type0 = LPM_HASH_TYPE_IPV6_SG1;
            ds_lpm_ipv6_mcast_hash1_key.hash_type1 = LPM_HASH_TYPE_IPV6_SG1;
            ds_lpm_ipv6_mcast_hash1_key.nexthop = nexthop;
            ds_lpm_ipv6_mcast_hash1_key.valid0  = TRUE;
            ds_lpm_ipv6_mcast_hash1_key.valid1 =  TRUE;

            ipv6_sa_prefix = ip_sa.ip32[0] >> 22;

            if (fib_engine_lookup_ctl.ipv6_sa1_prefix0 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 0;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix1 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 1;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix2 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 2;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix3 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 3;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix4 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 0;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix5 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 1;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix6 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 2;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }
            else
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 3;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }

            ret = cm_sim_cfg_kit_add_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV6_SG1, &ds_lpm_ipv6_mcast_hash1_key);
        }
    }
    else
    {
        if (!(ip_sa.ip32[0]) && (!ip_sa.ip32[1]) && (!ip_sa.ip32[2]) && (!ip_sa.ip32[0]))
        {
            ds_lpm_ipv6_mcast_hash0_key.ip_da31_0 = ip_da.ip32[3];
            ds_lpm_ipv6_mcast_hash0_key.ip_da47_32 = ip_da.ip32[2] & 0xFFFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da55_48 = (ip_da.ip32[2] >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da87_56 =((ip_da.ip32[1] & 0xFFFFFF) << 8)
                                                     | ((ip_da.ip32[2] >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da109_88 = ((ip_da.ip32[0] & 0x3FFF) << 8)
                                                     | ((ip_da.ip32[1] >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da111_110 = (ip_da.ip32[0] >> 14) & 0x3;
            ds_lpm_ipv6_mcast_hash0_key.ip_da119_112 = (ip_da.ip32[0] >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id0_0 = vrf_id & 0x1;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id10_1 = (vrf_id >> 1) & 0x3FF;
            ds_lpm_ipv6_mcast_hash0_key.hash_type0 = LPM_HASH_TYPE_IPV6_XG;
            ds_lpm_ipv6_mcast_hash0_key.hash_type1 = LPM_HASH_TYPE_IPV6_XG;
            ds_lpm_ipv6_mcast_hash0_key.valid0  = TRUE;
            ds_lpm_ipv6_mcast_hash0_key.valid1 =  TRUE;
            ds_lpm_ipv6_mcast_hash0_key.is_mac = is_mac;

            ret = cm_sim_cfg_kit_delete_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV6_XG, &ds_lpm_ipv6_mcast_hash0_key);
        }
        else
        {
            sal_memset(&key_info, 0, sizeof(key_info_t));
            key_info.p_hash_key = hash_key;

            drv_hash_lookup_add_field(ip_da.ip32[3], 32, &key_info.key_length, key_info.p_hash_key);
            drv_hash_lookup_add_field(ip_da.ip32[2], 32, &key_info.key_length, key_info.p_hash_key);
            drv_hash_lookup_add_field(ip_da.ip32[1], 32, &key_info.key_length, key_info.p_hash_key);
            drv_hash_lookup_add_field(ip_da.ip32[0] & 0xFFFFFF, 24, &key_info.key_length, key_info.p_hash_key);
            drv_hash_lookup_add_field(vrf_id, 11, &key_info.key_length, key_info.p_hash_key);

            crc = cm_hash_calculate_lpm_ipv6_mcast(key_info.p_hash_key, key_info.key_length);

            ds_lpm_ipv6_mcast_hash0_key.ip_da31_0 = ip_da.ip32[3];
            ds_lpm_ipv6_mcast_hash0_key.ip_da47_32 = ip_da.ip32[2] & 0xFFFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da55_48 = (ip_da.ip32[2] >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.ip_da87_56 =((ip_da.ip32[1] & 0xFFFFFF) << 8)
                                                     | ((ip_da.ip32[2] >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da109_88 = ((ip_da.ip32[0] & 0x3FFF) << 8)
                                                     | ((ip_da.ip32[1] >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash0_key.ip_da111_110 = (ip_da.ip32[0] >> 14) & 0x3;
            ds_lpm_ipv6_mcast_hash0_key.ip_da119_112 = (ip_da.ip32[0] >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id0_0 = vrf_id & 0x1;
            ds_lpm_ipv6_mcast_hash0_key.vrf_id10_1 = (vrf_id >> 1) & 0x3FF;
            ds_lpm_ipv6_mcast_hash0_key.hash_type0 = LPM_HASH_TYPE_IPV6_SG0;
            ds_lpm_ipv6_mcast_hash0_key.hash_type1 = LPM_HASH_TYPE_IPV6_SG0;
            ds_lpm_ipv6_mcast_hash0_key.nexthop = crc;
            ds_lpm_ipv6_mcast_hash0_key.valid0  = TRUE;
            ds_lpm_ipv6_mcast_hash0_key.valid1 =  TRUE;
            ds_lpm_ipv6_mcast_hash0_key.is_mac = is_mac;

            ret = cm_sim_cfg_kit_delete_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV6_SG0, &ds_lpm_ipv6_mcast_hash0_key);

            ds_lpm_ipv6_mcast_hash1_key.ip_sa31_0 = ip_sa.ip32[3];
            ds_lpm_ipv6_mcast_hash1_key.ip_sa47_32 = ip_sa.ip32[2] & 0xFFFF;
            ds_lpm_ipv6_mcast_hash1_key.ip_sa55_48 = (ip_sa.ip32[2] >> 16) & 0xFF;
            ds_lpm_ipv6_mcast_hash1_key.ip_sa87_56 = ((ip_sa.ip32[1] & 0xFFFFFF) << 8)| ((ip_sa.ip32[2] >> 24) & 0xFF);
            ds_lpm_ipv6_mcast_hash1_key.ip_sa117_88 = ((ip_sa.ip32[0] & 0x3FFFFF) << 8) | (ip_sa.ip32[1] >> 24);

            ds_lpm_ipv6_mcast_hash1_key.hash0_result1_0 = crc & 0x3;
            ds_lpm_ipv6_mcast_hash1_key.hash0_result2_2 = (crc >> 2) & 0x1;
            ds_lpm_ipv6_mcast_hash1_key.hash0_result10_3 = (crc >> 3) & 0xFF;
            ds_lpm_ipv6_mcast_hash1_key.hash_type0 = LPM_HASH_TYPE_IPV6_SG1;
            ds_lpm_ipv6_mcast_hash1_key.hash_type1 = LPM_HASH_TYPE_IPV6_SG1;
            ds_lpm_ipv6_mcast_hash1_key.nexthop = nexthop;
            ds_lpm_ipv6_mcast_hash1_key.valid0  = TRUE;
            ds_lpm_ipv6_mcast_hash1_key.valid1 =  TRUE;

            ipv6_sa_prefix = ip_sa.ip32[0] >> 22;

            if (fib_engine_lookup_ctl.ipv6_sa1_prefix0 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 0;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix1 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 1;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix2 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 2;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix3 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 3;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 0;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix4 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 0;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix5 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 1;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }
            else if (fib_engine_lookup_ctl.ipv6_sa1_prefix6 == ipv6_sa_prefix)
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 2;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }
            else
            {
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index1_0 = 3;
                ds_lpm_ipv6_mcast_hash1_key.ip_sa_prefix_index2_2 = 1;
            }

            ret = cm_sim_cfg_kit_delete_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV6_SG1, &ds_lpm_ipv6_mcast_hash1_key);
        }
    }

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}
#if (SDK_WORK_PLATFORM == 1)
/* ����cmodelʹ�ã���Ϊcmodel��ģ��PTP engine,��ͨ��cmodel cli����MacRx,MacTx,NextHopPtp����ץȡʱ����ֵ */
extern uint8 mac_rx_gen_ts[TIME_STAMP_LENGTH];
extern uint8 mac_tx_gen_ts[TIME_STAMP_LENGTH];
extern uint8 epe_nhp_ptp_gen_ts[TIME_STAMP_LENGTH];
extern uint8 ipe_oam_ptp_gen_ts[TIME_STAMP_LENGTH];

CTC_CLI(cli_cmodel_sim_pseudo_ptpengine_gen_timestamp_set,
    cli_cmodel_sim_pseudo_ptpengine_gen_timestamp_set_cmd,
    "cmodel set (macrx | mactx |epenhp | ipeoam) ts TIMESTAMP",
    "Cmodel cmd",
    "Cmodel generate ts at macrx, mactx and epenhp",
    "MacRX",
    "MacTx",
    "EpeNhp",
    "IpeOam",
    "timestamp",
    "TS value format: HH.HH.HH.HH.HH.HH.HH.HH, 64 bits valid")
{
    uint32 index = 0xFF;
    uint8 *gen_ts = NULL;

    index = ctc_cli_get_prefix_item(&argv[0], argc, "macrx", sal_strlen("macrx"));
    if (0xFF != index)
    {
        gen_ts = mac_rx_gen_ts;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "mactx", sal_strlen("mactx"));
    if (0xFF != index)
    {
        gen_ts = mac_tx_gen_ts;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "epenhp", sal_strlen("epenhp"));
    if (0xFF != index)
    {
        gen_ts = epe_nhp_ptp_gen_ts;
    }

    index = ctc_cli_get_prefix_item(&argv[0], argc, "ipeoam", sal_strlen("ipeoam"));
    if (0xFF != index)
    {
        gen_ts = ipe_oam_ptp_gen_ts;
    }
    /* parse TS Value */
    if (sal_sscanf (argv[1], "%2hhx.%2hhx.%2hhx.%2hhx.%2hhx.%2hhx.%2hhx.%2hhx",
                   &(gen_ts[0]), &(gen_ts[1]), &(gen_ts[2]), &(gen_ts[3]),
                   &(gen_ts[4]), &(gen_ts[5]), &(gen_ts[6]), &(gen_ts[7]))!= 8)
    {
        ctc_cli_out("%% Unable to translate TimeStamp input value %s\n", argv[1]);
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}
#else

static int32
_ptp_adpt_adjust_offset(uint8 chip_id, int64 offset)

{
#define GLB_PTP_NS_PER_SEC 1000000000
    ptp_offset_adjust_t ptp_offset_adjust;
    uint32 cmd = 0;

    bool is_neg = (offset < 0);
    if (is_neg)
    {
        offset = -offset;
    }
    uint32 second = offset / GLB_PTP_NS_PER_SEC;
    uint32 ns = offset % GLB_PTP_NS_PER_SEC;
    if (is_neg)
    {
        ns = GLB_PTP_NS_PER_SEC - ns;
        second = -second;
        second--;
    }

    sal_memset(&ptp_offset_adjust, 0, sizeof(ptp_offset_adjust_t));

    ptp_offset_adjust.offset_second_ref = second;
    ptp_offset_adjust.offset_ns_ref     = ns;
    cmd = DRV_IOW(PtpOffsetAdjust_t, DRV_ENTRY_FLAG);

    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ptp_offset_adjust));
    return DRV_E_NONE;

}


CTC_CLI(cli_cmodel_sim_pseudo_ptpengine_gen_timestamp_set,
    cli_cmodel_sim_pseudo_ptpengine_gen_timestamp_set_cmd,
    "cmodel set (macrx | mactx |epenhp | ipeoam) ts TIMESTAMP",
    "Cmodel cmd",
    "Cmodel generate ts at macrx, mactx and epenhp",
    "MacRX",
    "MacTx",
    "EpeNhp",
    "IpeOam",
    "timestamp",
    "TS value format: HH.HH.HH.HH.HH.HH.HH.HH, 64 bits valid")
{
    uint8 gen_ts[8] = {0};
    uint32 cmd = 0;
    uint8 chip_id = 2;
    uint32 value = 0;
    uint32 ts_sec = 0, ts_ns = 0;
    int64 remote_ts = 0;
    int64 local_ts = 0;
    int64 offset = 0;
    ptp_ref_frc_t   ptp_ref_frc;

    /* parse TS Value */
    if (sal_sscanf (argv[1], "%2hhx.%2hhx.%2hhx.%2hhx.%2hhx.%2hhx.%2hhx.%2hhx",
                   &(gen_ts[0]), &(gen_ts[1]), &(gen_ts[2]), &(gen_ts[3]),
                   &(gen_ts[4]), &(gen_ts[5]), &(gen_ts[6]), &(gen_ts[7]))!= 8)
    {
        ctc_cli_out("%% Unable to translate TimeStamp input value %s\n", argv[1]);
        return CLI_ERROR;
    }
    /*
    1. Set PtpFrcQuanta.quanta to 0;
    2. Read PtpRefFrc.frcSecondRef to second, PtpRefFrc.frcNsRef to ns.
    3. The cli_cmodel_sim_pseudo_ptpengine_gen_timestamp_set_cmd TIMESTAMP[63:32] is ts_sec
    , TIMESTAMP[31:0] is ts_ns.
    */
    value = 0;
    cmd = DRV_IOW(PtpFrcQuanta_t, PtpFrcQuanta_Quanta_f);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &value));

    sal_memset(&ptp_ref_frc, 0, sizeof(ptp_ref_frc_t));
    cmd = DRV_IOR(PtpRefFrc_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ptp_ref_frc));

    ts_sec  = MAKE_UINT32(gen_ts[0], gen_ts[1], gen_ts[2], gen_ts[3]);
    ts_ns   = MAKE_UINT32(gen_ts[4], gen_ts[5], gen_ts[6], gen_ts[7]);

    local_ts = 1000000000LL * ptp_ref_frc.frc_second_ref + ptp_ref_frc.frc_ns_ref;
    remote_ts = 1000000000LL * ts_sec + ts_ns;
    offset = remote_ts - local_ts;

    _ptp_adpt_adjust_offset(chip_id, offset);

    return CLI_SUCCESS;
}
#endif

CTC_CLI(cli_cmodel_clear_register_table_wbit,
    cli_cmodel_clear_register_table_wbit_cmd,
    "wbit-clear CHIPID MEM_NAME INDEX_ID (INDEX_NUM |)",
    "wbit clear cmd(only work on UML)",
    "chipid",
    "table ID value",
    "index base value",
    "index number")
{
    uint32 tbl_id = MaxTblId_t;
    char *mem_name_ptr = NULL;
    uint32 index_base = 0, index_num = 1, index_tmp = 0, cmd = 0;
    uint8 chipid = 0, chip_id_offset = 0;
    uint32 data_entry[MAX_ENTRY_WORD] = {0};

    CTC_CLI_GET_INTEGER("chipid", chipid, argv[0]);
    chipid = 0;
    if ((drv_init_chip_info.drv_init_chipid_base + drv_init_chip_info.drv_init_chip_num) <= chipid)
    {
        ctc_cli_out("%% ERROR! Clear wbit but input invalid chipid value: %d!\n", chipid);
        return CLI_ERROR;
    }
    chip_id_offset = chipid - drv_init_chip_info.drv_init_chipid_base;

    CTC_CLI_GET_INTEGER("index_base", index_base, argv[2]);
    if (argc > 3)
    {
        CTC_CLI_GET_INTEGER("index_num", index_num, argv[3]);
    }

    mem_name_ptr = argv[1];
    if(drv_get_tbl_id_by_string(&tbl_id, mem_name_ptr) < 0)
    {
        ctc_cli_out("%% Fail to search tbl_name = %s, ret = 0x%08x\n",
                    mem_name_ptr, tbl_id);
        return CLI_ERROR;
    }

    if (tbl_id == IpeLearningCache_t)
    {
        for (index_tmp = 0; index_tmp < index_num; index_tmp++)
        {
            if ((IPE_LEARNING_CACHE_MAX_INDEX-1-index_base-index_tmp) >= TABLE_MAX_INDEX(tbl_id))
            {
                ctc_cli_out("%% ERROR! table clear wbit but index is exceed maxIndex!\n");
                ctc_cli_out("%% Input index = %d; maxIndex = %d!\n",
                    (IPE_LEARNING_CACHE_MAX_INDEX-1-index_base-index_tmp), TABLE_MAX_INDEX(tbl_id));
                return CLI_ERROR;
            }

            cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chipid,
                (IPE_LEARNING_CACHE_MAX_INDEX-1-index_base-index_tmp), cmd, (void *)data_entry));

#if (SDK_WORK_PLATFORM == 1)
            drv_model_sram_tbl_clear_wbit(chip_id_offset, tbl_id, (IPE_LEARNING_CACHE_MAX_INDEX-1-index_base-index_tmp));
#endif
        }
    }
    else
    {
        for (index_tmp = 0; index_tmp < index_num; index_tmp++)
        {
            if ((index_base+index_tmp) >= TABLE_MAX_INDEX(tbl_id))
            {
                ctc_cli_out("%% ERROR! table clear wbit but index is exceed maxIndex!\n");
                ctc_cli_out("%% Input index = %d; maxIndex = %d!\n", (index_base+index_tmp), TABLE_MAX_INDEX(tbl_id));
                return CLI_ERROR;
            }

            cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chipid, (index_base+index_tmp), cmd, (void *)data_entry));

#if (SDK_WORK_PLATFORM == 1)
            drv_model_sram_tbl_clear_wbit(chip_id_offset, tbl_id, (index_base+index_tmp));
#endif
        }
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_flush_lpm_hash_key,
    cli_cmodel_flush_lpm_hash_key_cmd,
    "flush CHIPID lpm hash key",
    "flush",
    "lpm",
    "table ID value",
    "index base value",
    "index number")
{
    uint8 chipid = 0;
    int32 ret = DRV_E_NONE;

    CTC_CLI_GET_INTEGER("chipid", chipid, argv[0]);
    chipid = 0;
    ret = cm_sim_cfg_kit_delete_lpm_lookup_key(chipid);
    if (ret < 0)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

extern int32 _cm_prbs31(uint32 len, uint8 *seq);
CTC_CLI(cli_cmodel_prbs,
    cli_cmodel_prbs_cmd,
    "prbs LEN",
    "prbs",
    "len")
{
    uint32 len = 0;
    int32 ret = DRV_E_NONE;
    uint32 len_byte = 0;
    uint8* seq = NULL;

    CTC_CLI_GET_INTEGER("len", len, argv[0]);

    len_byte = len/8 + ((len%8)?1:0);
    seq = sal_malloc(len_byte);
    sal_memset(seq, 0, len_byte);

    ret = _cm_prbs31(len,seq);
    if (ret < 0)
    {
        return CLI_ERROR;
    }

    if (seq != NULL)
    {
        sal_free(seq);
        seq = NULL;
    }

    return CLI_SUCCESS;
}


#if (SDK_WORK_PLATFORM == 1)
extern bool higig_en;
CTC_CLI(cli_cmodel_higig_en,
    cli_cmodel_higig_en_cmd,
    "higig (disable | enable)",
    "higig header cmd",
    "disable higig",
    "enable higig")
{
    uint32 index = 0;

    index = ctc_cli_get_prefix_item(&argv[0], argc, "disable", sal_strlen("disable"));
    if (0xFF != index)
    {
        higig_en = FALSE;
    }
    else
    {
        higig_en = TRUE;
    }


    return CLI_SUCCESS;
}
#endif

#if 0
CTC_CLI(cli_cmodel_fib_crc_test,
            cli_cmodel_fib_crc_test_cmd,
            "crc-test mac-level-bitmap MAC_LEVEL_BITMAP key-mode KEY_MODE key-num KYE_NUM",
            "Cmodel cmd",
            "mac-level-bitmap",
            "mac level bitmap value",
            "key-mode",
            "key mode value",
            "key-num",
            "key-num value")
{
    uint8 mac_level_bitmap = 0x1;

    cm_com_fib_crc_test(mac_level_bitmap, CRC_EMU_KEY_MODE_RANDOM, 32 * 1024);

    return CLI_SUCCESS;
}
#endif

/********************************************************************************************/
/*CoSim test cli*/
/********************************************************************************************/
#if (SDK_WORK_PLATFORM == 1)
extern int32
sim_interface_init(char*, char*, bool);

CTC_CLI(cosim_init,
    cosim_init_cmd,
    "cosim init mem_alloc_file MEM_ALLOC_FILE config_file CONFIG_FILE dump_flag (0|1)",
    "Cosim cmd",
    "init cmd",
    "memory alloc file cmd",
    "memory alloc file",
    "config file cmd",
    "config_file",
    "dump floag cmd",
    "0: don't dump",
    "1: dump")
{
    char *mem_alloc_file = NULL;
    char *config_file = NULL;
    uintptr flag;
    int32 ret;

    mem_alloc_file = (char *)argv[0];
    config_file = (char *)argv[1];
    flag = (uintptr)argv[2];
    ret = sim_interface_init(config_file, mem_alloc_file, (bool)flag);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

extern int32 sim_cfg_read_debug_bus_cfg(uint8*);

CTC_CLI(cosim_set_debug_flag,
    cosim_set_debug_flag_cmd,
    "cosim debug_cfg MEM_ALLOC_FILE",
    "Cosim cmd",
    "Set debug cfg file")
{
    sim_interface_load_debug_bus_cfg("cosim_debug_flag.cfg");

    return CLI_SUCCESS;
}
#endif

CTC_CLI(cli_cmodel_add_lpm_hash16,
        cli_cmodel_add_lpm_hash16_cmd,
        "cmodel add lpm-hash16 chipid CHIPID ip IP vrf-id VRF_ID type TYPE nexthop-pointer NEXTHOP_POINTER index-mask INDEX_MASK",
        "Cmodel cmd",
        "Cmodel add lpm-hash16 cmd",
        "Cmodel add lpm-hash16 cmd",
        "chip id",
        "chip id value",
        "IPv4 address",
        "[31 16] 16 bits in IPv4",
        "vrf id",
        "vrf id value",
        "LPM node type",
        "0:nexthop or 1:pointer",
        "nexthop or pointer",
        "nexthop or pointer node value",
        "index mask",
        "index mask value")
{
    uint8 chip_id;
    uint32 ad_index = 0;
    ds_lpm_ipv4_hash16_key_t ds_lpm_ipv4_hash16_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&ds_lpm_ipv4_hash16_key, 0, sizeof(ds_lpm_ipv4_hash16_key_t));

    CTC_CLI_GET_UINT32("chipid",          chip_id,                            argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("ip",              ds_lpm_ipv4_hash16_key.ip,          argv[1]);
    CTC_CLI_GET_UINT32("vrf-id",          ds_lpm_ipv4_hash16_key.vrf_id,      argv[2]);
    CTC_CLI_GET_UINT32("type",            ds_lpm_ipv4_hash16_key.type,        argv[3]);
    CTC_CLI_GET_UINT32("nexthop-pointer", ad_index,                           argv[4]);
    CTC_CLI_GET_UINT32("index-mask",      ds_lpm_ipv4_hash16_key.index_mask,  argv[5]);

    ds_lpm_ipv4_hash16_key.nexthop = ad_index & 0xFFFF;
    ds_lpm_ipv4_hash16_key.pointer16 = IS_BIT_SET(ad_index, 16);
    ds_lpm_ipv4_hash16_key.pointer17 = IS_BIT_SET(ad_index, 17);
    ds_lpm_ipv4_hash16_key.valid = TRUE;
    ds_lpm_ipv4_hash16_key.hash_type = LPM_HASH_TYPE_IPV4_16;

    ret = cm_sim_cfg_kit_add_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV4_16, &ds_lpm_ipv4_hash16_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

CTC_CLI(cli_cmodel_del_lpm_hash16,
        cli_cmodel_del_lpm_hash16_cmd,
        "cmodel del lpm-hash16 chipid CHIPID ip IP vrf-id VRF_ID type TYPE",
        "Cmodel cmd",
        "Cmodel del lpm-hash16 cmd",
        "Cmodel del lpm-hash16 cmd",
        "chip id",
        "chip id value",
        "IPv4 address",
        "[31 16] 16 bits in IPv4",
        "vrf id",
        "vrf id value",
        "LPM node type",
        "0:nexthop or 1:pointer")
{
    uint8 chip_id;
    ds_lpm_ipv4_hash16_key_t ds_lpm_ipv4_hash16_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&ds_lpm_ipv4_hash16_key, 0, sizeof(ds_lpm_ipv4_hash16_key_t));

    CTC_CLI_GET_UINT32("chipid",          chip_id,                            argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("ip",              ds_lpm_ipv4_hash16_key.ip,          argv[1]);
    CTC_CLI_GET_UINT32("vrf-id",          ds_lpm_ipv4_hash16_key.vrf_id,      argv[2]);
    CTC_CLI_GET_UINT32("type",            ds_lpm_ipv4_hash16_key.type,        argv[3]);

    ds_lpm_ipv4_hash16_key.valid = TRUE;
    ds_lpm_ipv4_hash16_key.hash_type = LPM_HASH_TYPE_IPV4_16;

    ret = cm_sim_cfg_kit_delete_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV4_16, &ds_lpm_ipv4_hash16_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

CTC_CLI(cli_cmodel_add_lpm_hash_high32,
        cli_cmodel_add_lpm_hash_high32_cmd,
        "cmodel add lpm-hash-high32 chipid CHIPID ip IP vrf-id VRF_ID type TYPE nexthop-pointer NEXTHOP_POINTER index-mask INDEX_MASK",
        "Cmodel cmd",
        "Cmodel add lpm-hash-high32 cmd",
        "Cmodel add lpm-hash-high32 cmd",
        "chip id",
        "chip id value",
        "IPv6 address",
        "[127, 96] bits in IPv6",
        "vrf id",
        "vrf id value",
        "LPM node type",
        "0:nexthop or 1:pointer",
        "nexthop or pointer",
        "nexthop or pointer node value",
        "index mask",
        "index mask value")
{
    uint8  chip_id;
    uint32 ad_index = 0;
    uint32 vrf_id = 0;
    int32  ret = DRV_E_NONE;

    ds_lpm_ipv6_hash32_high_key_t ds_lpm_ipv6_hash32_high_key;

    sal_memset(&ds_lpm_ipv6_hash32_high_key, 0, sizeof(ds_lpm_ipv6_hash32_high_key_t));

    CTC_CLI_GET_UINT32("chipid",          chip_id,                                 argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("ip",              ds_lpm_ipv6_hash32_high_key.ip,          argv[1]);
    CTC_CLI_GET_UINT32("vrf-id",          vrf_id,                                  argv[2]);
    CTC_CLI_GET_UINT32("type",            ds_lpm_ipv6_hash32_high_key.type,        argv[3]);
    CTC_CLI_GET_UINT32("nexthop-pointer", ad_index,                                argv[4]);
    CTC_CLI_GET_UINT32("index-mask",      ds_lpm_ipv6_hash32_high_key.index_mask,  argv[5]);

    ds_lpm_ipv6_hash32_high_key.nexthop = ad_index & 0xFFFF;
    ds_lpm_ipv6_hash32_high_key.pointer16 = IS_BIT_SET(ad_index, 16);
    ds_lpm_ipv6_hash32_high_key.pointer17_17 = IS_BIT_SET(ad_index, 17);
    ds_lpm_ipv6_hash32_high_key.valid = TRUE;
    ds_lpm_ipv6_hash32_high_key.hash_type = LPM_HASH_TYPE_IPV6_HIGH32;
    ds_lpm_ipv6_hash32_high_key.vrf_id0 = vrf_id & 0xFF;
    ds_lpm_ipv6_hash32_high_key.vrf_id13_8 = (vrf_id >> 8) & 0x3F;

    ret = cm_sim_cfg_kit_add_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV6_HIGH32, &ds_lpm_ipv6_hash32_high_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

CTC_CLI(cli_cmodel_add_lpm_hash_mid32,
        cli_cmodel_add_lpm_hash_mid32_cmd,
        "cmodel add lpm-hash-mid32 chipid CHIPID ip IP pointer POINTER",
        "Cmodel cmd",
        "Cmodel add lpm-hash-mid32 cmd",
        "Cmodel add lpm-hash-mid32 cmd",
        "chip id",
        "chip id value",
        "IPv6 address",
        "[64, 31] 32 bits in IPv6",
        "pointer",
        "pointer value")
{
    uint8 chip_id;
    uint32 ad_index = 0;

    ds_lpm_ipv6_hash32_mid_key_t ds_lpm_ipv6_hash32_mid_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&ds_lpm_ipv6_hash32_mid_key, 0, sizeof(ds_lpm_ipv6_hash32_mid_key_t));

    CTC_CLI_GET_UINT32("chipid",          chip_id,                                 argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("ip",              ds_lpm_ipv6_hash32_mid_key.ip_da,        argv[1]);
    CTC_CLI_GET_UINT32("pointer",         ad_index,                                argv[2]);

    ds_lpm_ipv6_hash32_mid_key.nexthop = ad_index & 0xFFFF;
    ds_lpm_ipv6_hash32_mid_key.pointer16 = IS_BIT_SET(ad_index, 16);
    ds_lpm_ipv6_hash32_mid_key.pointer17_17 = IS_BIT_SET(ad_index, 17);
    ds_lpm_ipv6_hash32_mid_key.valid = TRUE;
    ds_lpm_ipv6_hash32_mid_key.hash_type = LPM_HASH_TYPE_IPV6_MID32;

    ret = cm_sim_cfg_kit_add_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV6_MID32, &ds_lpm_ipv6_hash32_mid_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

CTC_CLI(cli_cmodel_add_lpm_hash_low32,
        cli_cmodel_add_lpm_hash_low32_cmd,
        "cmodel add lpm-hash-low32 chipid CHIPID ip IP pointer POINTER mid MID nexthop NEXTHOP",
        "Cmodel cmd",
        "Cmodel add lpm-hash-low32 cmd",
        "Cmodel add lpm-hash-low32 cmd",
        "chip id",
        "chip id value",
        "IPv6 address",
        "[64, 31] 32 bits in IPv6",
        "pointer",
        "pointer value")
{
    uint8 chip_id;
    uint32 pointer = 0;

    ds_lpm_ipv6_hash32_low_key_t ds_lpm_ipv6_hash32_low_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&ds_lpm_ipv6_hash32_low_key, 0, sizeof(ds_lpm_ipv6_hash32_low_key_t));

    CTC_CLI_GET_UINT32("chipid",          chip_id,                                 argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("ip",              ds_lpm_ipv6_hash32_low_key.ip_da31_0,    argv[1]);
    CTC_CLI_GET_UINT32("pointer",         pointer,                                 argv[2]);
    CTC_CLI_GET_UINT32("mid",             ds_lpm_ipv6_hash32_low_key.mid,          argv[3]);
    CTC_CLI_GET_UINT32("nexthop",         ds_lpm_ipv6_hash32_low_key.nexthop,      argv[4]);

    ds_lpm_ipv6_hash32_low_key.pointer2_0 = pointer & 0x7;
    ds_lpm_ipv6_hash32_low_key.pointer4_3 = (pointer >> 3) & 0x3;
    ds_lpm_ipv6_hash32_low_key.pointer12_5 = (pointer >> 5) & 0xFF;
    ds_lpm_ipv6_hash32_low_key.valid0 = TRUE;
    ds_lpm_ipv6_hash32_low_key.hash_type0 = LPM_HASH_TYPE_IPV6_LOW32;

    ret = cm_sim_cfg_kit_add_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV6_LOW32, &ds_lpm_ipv6_hash32_low_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

CTC_CLI(cli_cmodel_add_lpm_hash8,
        cli_cmodel_add_lpm_hash8_cmd,
        "cmodel add lpm-hash8 chipid CHIPID ip IP vrf-id VRF_ID type TYPE nexthop-pointer NEXTHOP_POINTER index-mask INDEX_MASK",
        "Cmodel cmd",
        "Cmodel add lpm-hash8 cmd",
        "Cmodel add lpm-hash8 cmd",
        "chip id",
        "chip id value",
        "IPv4 address",
        "[31, 24] bits in IPv4",
        "vrf id",
        "vrf id value",
        "LPM node type",
        "0:nexthop or 1:pointer",
        "nexthop or pointer",
        "nexthop or pointer node value",
        "index mask",
        "index mask value")
{
    uint8 chip_id;
    uint32 ad_index = 0;
    ds_lpm_ipv4_hash8_key_t ds_lpm_ipv4_hash8_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&ds_lpm_ipv4_hash8_key, 0, sizeof(ds_lpm_ipv4_hash8_key_t));

    CTC_CLI_GET_UINT32("chipid",          chip_id,                           argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("ip",              ds_lpm_ipv4_hash8_key.ip,          argv[1]);
    CTC_CLI_GET_UINT32("vrf-id",          ds_lpm_ipv4_hash8_key.vrf_id,      argv[2]);
    CTC_CLI_GET_UINT32("type",            ds_lpm_ipv4_hash8_key.type,        argv[3]);
    CTC_CLI_GET_UINT32("nexthop-pointer", ad_index,                          argv[4]);
    CTC_CLI_GET_UINT32("index-mask",      ds_lpm_ipv4_hash8_key.index_mask,  argv[5]);

    ds_lpm_ipv4_hash8_key.nexthop = ad_index & 0xFFFF;
    ds_lpm_ipv4_hash8_key.pointer16 = IS_BIT_SET(ad_index, 16);
    ds_lpm_ipv4_hash8_key.pointer17 = IS_BIT_SET(ad_index, 17);
    ds_lpm_ipv4_hash8_key.valid = TRUE;
    ds_lpm_ipv4_hash8_key.hash_type = 4;

    ret = cm_sim_cfg_kit_add_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV4_8, &ds_lpm_ipv4_hash8_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

CTC_CLI(cli_cmodel_del_lpm_hash8,
        cli_cmodel_del_lpm_hash8_cmd,
        "cmodel del lpm-hash8 chipid CHIPID ip IP vrf-id VRF_ID type TYPE",
        "Cmodel cmd",
        "Cmodel del lpm-hash8 cmd",
        "Cmodel del lpm-hash8 cmd",
        "chip id",
        "chip id value",
        "IPv4 address",
        "[31, 24] bits in IPv4",
        "vrf id",
        "vrf id value",
        "LPM node type",
        "0:nexthop or 1:pointer")
{
    uint8 chip_id;
    ds_lpm_ipv4_hash8_key_t ds_lpm_ipv4_hash8_key;
    int32 ret = DRV_E_NONE;

    sal_memset(&ds_lpm_ipv4_hash8_key, 0, sizeof(ds_lpm_ipv4_hash8_key_t));

    CTC_CLI_GET_UINT32("chipid",          chip_id,                           argv[0]);
    chip_id = 0;
    CTC_CLI_GET_UINT32("ip",              ds_lpm_ipv4_hash8_key.ip,          argv[1]);
    CTC_CLI_GET_UINT32("vrf-id",          ds_lpm_ipv4_hash8_key.vrf_id,      argv[2]);
    CTC_CLI_GET_UINT32("type",            ds_lpm_ipv4_hash8_key.type,        argv[3]);

    ds_lpm_ipv4_hash8_key.valid = TRUE;
    ds_lpm_ipv4_hash8_key.hash_type = 4;

    ret = cm_sim_cfg_kit_delete_lpm_hash_key(chip_id, LPM_HASH_TYPE_IPV4_8, &ds_lpm_ipv4_hash8_key);

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

extern int32 _swemu_dump_topo_mac_description_info();
CTC_CLI(cli_cmodel_show_topo_mac_desc,
        cli_cmodel_show_topo_mac_desc_cmd,
        "cmodel show dut topo cfg",
        "Cmodel cmd",
        "show",
        "dut",
        "topo",
        "cfg")
{
    int32 ret = 0;

    ret = _swemu_dump_topo_mac_description_info();

    if (ret < DRV_E_NONE)
    {
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}


int32 ctc_cmodel_cli_init(uint8 cli_tree_mode)
{
    /* register driver cli command */
    install_element(cli_tree_mode, &cli_driver_init_cmd);
    install_element(cli_tree_mode, &cli_driver_drv_set_field_cmd);
    install_element(cli_tree_mode, &cli_driver_drv_get_field_cmd);
    install_element(cli_tree_mode, &cli_driver_drv_remove_tcam_cmd);

    /* register cmodel cli command */
    install_element(cli_tree_mode, &cli_cmodel_sim_init_cmodel_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_release_cmodel_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_store_model_inpkt_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_compare_rslt_file_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_whole_compare_file_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_check_ipe_discard_type_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_check_epe_discard_type_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_check_discard_type_rslt_file_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_check_no_any_discard_rslt_file_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_check_no_any_discard_type_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_chk_learning_cache_is_null_rslt_file_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_chk_learning_cache_is_null_cmd);
    install_element(cli_tree_mode, &cli_cmodel_debug_on_cmd);
    install_element(cli_tree_mode, &cli_cmodel_ctc_debug_on_cmd);
    install_element(cli_tree_mode, &cli_cmodel_ctc_debug_flag_cmd);

    install_element(cli_tree_mode, &cli_cmodel_swemu_environment_setting_cmd);
    install_element(cli_tree_mode, &cli_cmodel_set_higig_version_mode_cmd);

    /* FDB hash key add & delete cmd */
    install_element(cli_tree_mode, &cli_cmodel_fib_mac_key_cmd);

    /* FCOE hash key add & delete cmd */
    install_element(cli_tree_mode, &cli_cmodel_fib_fcoe_key_cmd);

    /* TRILL hash key add & delete cmd */
    install_element(cli_tree_mode, &cli_cmodel_fib_trill_key_cmd);

    /* ACL MAC hash key add & delete cmd */
    install_element(cli_tree_mode, &cli_cmodel_fib_acl_mac_key_cmd);

    /* ACL ipv4 hash key add & delete cmd */
    install_element(cli_tree_mode, &cli_cmodel_fib_acl_ipv4_key_cmd);

    /* ACL ipv4 hash key add & delete cmd */
    install_element(cli_tree_mode, &cli_cmodel_fib_acl_arp_key_cmd);

    /* Queue hash key add cmd (delete cmd ???) */
    install_element(cli_tree_mode, &cli_cmodel_add_queue_hash_key_cmd);
    install_element(cli_tree_mode, &cli_cmodel_del_queue_hash_key_cmd);

    /* LPM key add & delete cmd */
    install_element(cli_tree_mode, &cli_cmodel_add_ipv4_mcast_cmd);
    install_element(cli_tree_mode, &cli_cmodel_del_ipv4_mcast_cmd);

    install_element(cli_tree_mode, &cli_cmodel_add_ipv4_nat_sa_cmd);
    install_element(cli_tree_mode, &cli_cmodel_del_ipv4_nat_sa_cmd);

    install_element(cli_tree_mode, &cli_cmodel_add_ipv4_nat_sa_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_del_ipv4_nat_sa_port_cmd);

    install_element(cli_tree_mode, &cli_cmodel_add_ipv4_nat_da_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_del_ipv4_nat_da_port_cmd);

    /* userid hash key add cmd */
    install_element(cli_tree_mode, &cli_cmodel_add_userid_two_vlan_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_two_vlan_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_svlan_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_svlan_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_cvlan_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_cvlan_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_svlan_cos_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_svlan_cos_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_cvlan_cos_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_cvlan_cos_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_macsa_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_macsa_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_macda_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_macda_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_macsa_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_macsa_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_macda_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_macda_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_ipsa_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_ipsa_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_ipv4sa_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_ipv4sa_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_ipv6sa_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_ipv6sa_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_port_vlan_cross_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_port_vlan_cross_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_userid_l2_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_userid_l2_cmd);


    /* tunnel hash key add cmd */
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_capwap_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_capwap_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_ipv4_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_ipv4_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_ipv4_udp_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_ipv4_udp_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_ipv4_rpf_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_ipv4_rpf_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_ipv4_gre_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_ipv4_gre_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_pbb_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_pbb_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_trill_mc_adjust_check_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_trill_mc_adjust_check_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_trill_mc_decap_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_trill_mc_decap_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_trill_mc_rpf_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_trill_mc_rpf_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_trill_uc_decap_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_trill_uc_decap_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_trill_uc_rpf_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_tunnelid_trill_uc_rpf_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_port_cross_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_port_cross_cmd);

    /* OAM hash key add & delete cmd */
    install_element(cli_tree_mode, &cli_cmodel_add_mpls_section_oam_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_pbt_oam_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_mpls_label_oam_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_bfd_oam_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_eth_oam_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_eth_oam_rmep_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_mpls_section_oam_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_pbt_oam_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_mpls_label_oam_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_bfd_oam_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_eth_oam_cmd);
    install_element(cli_tree_mode, &cli_cmodel_remove_eth_oam_rmep_cmd);

    /*oam lpm tcam key & add*/
    install_element(cli_tree_mode, &cli_cmodel_add_eth_oam_tcam_key_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_eth_oam_tcam_ad_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_eth_oam_rmep_tcam_key_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_eth_oam_tcam_rmep_ad_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_mpls_label_oam_tcam_key_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_mpls_section_oam_tcam_key_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_bfd_oam_tcam_key_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_mpls_label_oam_tcam_ad_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnel_id_capwap_confit_tcam_key_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnelid_ipv4_udp_confit_tcam_key_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_tunnel_id_tcam_ad_cmd);

    install_element(cli_tree_mode, &cli_cmodel_clear_register_table_wbit_cmd);

    install_element(cli_tree_mode, &cli_cmodel_sim_chk_tbl_rslt_file_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_chk_tbl_field_value_cmd);

    install_element(cli_tree_mode, &cli_cmodel_oam_update_ccm_timer_cmd);
    install_element(cli_tree_mode, &cli_cmodel_oam_update_scan_defect_timer_cmd);
    install_element(cli_tree_mode, &cli_cmodel_oam_update_auto_gen_pkt_timer_cmd);
    install_element(cli_tree_mode, &cli_cmodel_oam_auto_gen_pkt_enable_cmd);
    install_element(cli_tree_mode, &cli_cmodel_oam_auto_gen_pkt_set_packet_header_cmd);
    install_element(cli_tree_mode, &cli_cmodel_oam_auto_gen_pkt_set_rate_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_model_store_higig_header_cmd);

    /* lpm test */
    install_element(cli_tree_mode, &cli_cmodel_add_lpm_hash8_cmd);
    install_element(cli_tree_mode, &cli_cmodel_del_lpm_hash8_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_lpm_hash16_cmd);
    install_element(cli_tree_mode, &cli_cmodel_del_lpm_hash16_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_lpm_hash_high32_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_lpm_hash_mid32_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_lpm_hash_low32_cmd);
    install_element(cli_tree_mode, &cli_cmodel_lpm_update_cmd);
    install_element(cli_tree_mode, &cli_cmodel_check_hash_key_mask_cmd);

    install_element(cli_tree_mode, &cli_cmodel_flush_lpm_hash_key_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_ipv6_nat_sa_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_ipv6_nat_sa_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_add_ipv6_nat_da_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_del_ipv6_nat_sa_cmd);
    install_element(cli_tree_mode, &cli_cmodel_del_ipv6_nat_sa_port_cmd);
    install_element(cli_tree_mode, &cli_cmodel_del_ipv6_nat_da_port_cmd);

    install_element(cli_tree_mode, &cli_cmodel_tcpdump_cmd);
    install_element(cli_tree_mode, &cli_hash_debug_on_cmd);
    install_element(cli_tree_mode, &cli_cmodel_ipv6_mcast_key_cmd);
    /* model cmd */
    install_element(cli_tree_mode, &cli_cmodel_sim_init_model_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_release_model_cmd);

    /* memory allocation cli */
    install_mem_allocation_cli(cli_tree_mode);

#if (SDK_WORK_PLATFORM == 0)
#if 0 /*SDK Remove*/
    ctc_dbg_tool_cli_init(cli_tree_mode);
    install_element(cli_tree_mode, &cli_cmodel_higig_en_cmd);
#endif

#else
 //   ctc_com_cli_init(cli_tree_mode);

    /* cosim interface unit-test debug use */
    install_element(cli_tree_mode, &cosim_init_cmd);
    install_element(cli_tree_mode, &cosim_set_debug_flag_cmd);
    install_element(cli_tree_mode, &cli_cmodel_show_topo_mac_desc_cmd);

#endif
    install_element(cli_tree_mode, &cli_cmodel_sim_pseudo_ptpengine_gen_timestamp_set_cmd);

    install_element(cli_tree_mode, &cli_cmodel_sim_model_store_on_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_model_store_asic_cfg_cmd);
    install_element(cli_tree_mode, &cli_cmodel_sim_model_store_tcam_cfg_cmd);

    install_element(cli_tree_mode, &cli_cmodel_prbs_cmd);

#if (SDK_WORK_PLATFORM == 1)
    install_element(cli_tree_mode, &cli_cmodel_higig_en_cmd);
#endif

    return CLI_SUCCESS;
}


