/****************************************************************************
 * cmodel_cli.c   cmodel mem allocation cli implementation
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0
 * Author:       Jiang
 * Date:         2010-11-1.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "ctc_cli.h"
#include "cmodel_cli.h"
#include "ctcutil_lib.h"
#include "cm_lib.h"

CTC_CLI(cli_cmodel_mem_allocation_profile_init,
    cli_cmodel_mem_allocation_profile_cmd,
    "mem-profile init <0-14>",
    "Memory allocation profile ",
    "Init profile",
    "Profile index, <0-14>")
{
    int32 ret = DRV_E_NONE;
    uint8 mem_profile_index = 0;

    CTC_CLI_GET_UINT8_RANGE("profile index", mem_profile_index, argv[0], 0, 0xff);


    ret = cm_sim_cfg_kit_init_mem_allocation_profile(mem_profile_index);

    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% Mem profile init failed!\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}


CTC_CLI(cli_cmodel_initialize_tcam_key_process,
    cli_cmodel_initialize_tcam_key_process_cmd,
    "tcam-key initialize",
    "Tcam key tables",
    "Init tcam key")
{

    cm_sim_allocate_tcam_key_extend_info();

    return CLI_SUCCESS;

}



CTC_CLI(cli_cmodel_allocation_process,
    cli_cmodel_allocation_process_cmd,
    "do allocation",
    "do allocation action",
    "Memory allocation")
{
    int32 ret = DRV_E_NONE;

    ret = cm_sim_cfg_kit_allocate_process();

    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%%  allocation failed!\n");
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}


CTC_CLI(cli_cmodel_tcam_key_allocation_process,
    cli_cmodel_tcam_key_allocation_process_cmd,
    "tcam-key allocation (acl-ipv6-key0| acl-ipv6-key1| acl-mpls-key0 | acl-mpls-key1 | acl-mpls-key2 | acl-mpls-key3| \
    acl-ipv4-key0| acl-ipv4-key1| acl-ipv4-key2| acl-ipv4-key3| acl-mac-key0| acl-mac-key1| acl-mac-key2| acl-mac-key3| \
    ipv4-ucast-route-key| ipv4-mcast-route-key| ipv6-ucast-route-key| ipv6-mcast-route-key| ipv4-nat-key| ipv6-nat-key \
    |ipv4-pbr-key |ipv6-pbr-key |mac-bridge-key| fcoe-route-key| trill-ucast-key |trill-mcast-key\
    |user-id-mac-key |user-id-ipv6-key |user-id-ipv4-key |user-id-vlan-key \
    |tunnel-id-ipv6-key |tunnel-id-ipv4-key | tunnel-id-pbb-key |tunnel-id-capwap-key |tunnel-id-trill-key \
    |eth-oam-key |bfd-oam-key |mpls-oam-key |pbt-oam-key| eth-rmep-key | mac-ipv4-key | mac-ipv6-key) \
    INDEX_NUM KEY_SIZE",
    "Tcam key tables",
    "Memory allocation",
    "DS_ACL_IPV6_KEY0",
    "DS_ACL_IPV6_KEY1",
    "DS_ACL_MPLS_KEY0",
    "DS_ACL_MPLS_KEY1",
    "DS_ACL_MPLS_KEY2",
    "DS_ACL_MPLS_KEY3",
    "DS_ACL_IPV4_KEY0",
    "DS_ACL_IPV4_KEY1",
    "DS_ACL_IPV4_KEY2",
    "DS_ACL_IPV4_KEY3",
    "DS_ACL_MAC_KEY0",
    "DS_ACL_MAC_KEY1",
    "DS_ACL_MAC_KEY2",
    "DS_ACL_MAC_KEY3",
    "DS_IPV4_UCAST_ROUTE_KEY",
    "DS_IPV4_MCAST_ROUTE_KEY",
    "DS_IPV6_UCAST_ROUTE_KEY",
    "DS_IPV6_MCAST_ROUTE_KEY",
    "DS_IPV4_NAT_KEY",
    "DS_IPV6_NAT_KEY",
    "DS_IPV4_PBR_KEY",
    "DS_IPV6_PBR_KEY",
    "DS_MAC_BRIDGE_KEY",
    "DS_FCOE_ROUTE_KEY",
    "trill-ucast-key",
    "trill-mcast-key",
    "DS_USER_ID_MAC_KEY",
    "DS_USER_ID_IPV6_KEY",
    "DS_USER_ID_IPV4_KEY",
    "DS_USER_ID_VLAN_KEY",
    "DS_TUNNEL_ID_IPV6_KEY",
    "DS_TUNNEL_ID_IPV4_KEY",
    "DS_TUNNEL_ID_PBB_KEY",
    "DS_TUNNEL_ID_CAPWAP_KEY",
    "DS_TUNNEL_ID_TRILL_KEY",
    "DsEthOamKey",
    "DsBfdOamKey",
    "DsMplsOamLabelKey",
    "DsPbtOamKey",
    "DsEthOamRmepKey",
    "DsMacIpv4Key",
    "DsMacIpv6Key",
    "Max index num",
    "Key size in words")
{
    cm_table_allocation_info_t table_alloc_info;
    int32 ret = DRV_E_NONE;

    if(sal_strncmp(argv[0],"acl-ipv6-key0", sal_strlen("acl-ipv6-key0")) == 0)
    {
        table_alloc_info.table_id = DsAclIpv6Key0_t;
    }
    if(sal_strncmp(argv[0],"acl-ipv6-key1", sal_strlen("acl-ipv6-key1")) == 0)
    {
        table_alloc_info.table_id = DsAclIpv6Key1_t;
    }
    else if(sal_strncmp(argv[0], "acl-mpls-key0", sal_strlen("acl-mpls-key0")) ==0)
    {
        table_alloc_info.table_id = DsAclMplsKey0_t;
    }
    else if(sal_strncmp(argv[0], "acl-mpls-key1", sal_strlen("acl-mpls-key1")) ==0)
    {
        table_alloc_info.table_id = DsAclMplsKey1_t;
    }
    else if(sal_strncmp(argv[0], "acl-mpls-key2", sal_strlen("acl-mpls-key2")) ==0)
    {
        table_alloc_info.table_id = DsAclMplsKey2_t;
    }
    else if(sal_strncmp(argv[0], "acl-mpls-key3", sal_strlen("acl-mpls-key3")) ==0)
    {
        table_alloc_info.table_id = DsAclMplsKey3_t;
    }
    else if(sal_strncmp(argv[0], "acl-ipv4-key0", sal_strlen("acl-ipv4-key0")) ==0)
    {
        table_alloc_info.table_id = DsAclIpv4Key0_t;
    }
    else if(sal_strncmp(argv[0], "acl-ipv4-key1", sal_strlen("acl-ipv4-key1")) ==0)
    {
        table_alloc_info.table_id = DsAclIpv4Key1_t;
    }
    else if(sal_strncmp(argv[0], "acl-ipv4-key2", sal_strlen("acl-ipv4-key2")) ==0)
    {
        table_alloc_info.table_id = DsAclIpv4Key2_t;
    }
    else if(sal_strncmp(argv[0], "acl-ipv4-key3", sal_strlen("acl-ipv4-key3")) ==0)
    {
        table_alloc_info.table_id = DsAclIpv4Key3_t;
    }
    else if(sal_strncmp(argv[0], "acl-mac-key0", sal_strlen("acl-mac-key0"))== 0)
    {
        table_alloc_info.table_id = DsAclMacKey0_t;
    }
    else if(sal_strncmp(argv[0], "acl-mac-key1", sal_strlen("acl-mac-key1"))== 0)
    {
        table_alloc_info.table_id = DsAclMacKey1_t;
    }
    else if(sal_strncmp(argv[0], "acl-mac-key2", sal_strlen("acl-mac-key2"))== 0)
    {
        table_alloc_info.table_id = DsAclMacKey2_t;
    }
    else if(sal_strncmp(argv[0], "acl-mac-key3", sal_strlen("acl-mac-key3"))== 0)
    {
        table_alloc_info.table_id = DsAclMacKey3_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-ucast-route-key", sal_strlen("ipv4-ucast-route-key"))== 0)
    {
        table_alloc_info.table_id = DsIpv4UcastRouteKey_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-mcast-route-key", sal_strlen("ipv4-mcast-route-key"))==0)
    {
        table_alloc_info.table_id = DsIpv4McastRouteKey_t;
    }
    else if(sal_strncmp(argv[0], "ipv6-ucast-route-key", sal_strlen("ipv6-ucast-route-key")) ==0)
    {
        table_alloc_info.table_id = DsIpv6UcastRouteKey_t;
    }
    else if(sal_strncmp(argv[0], "ipv6-mcast-route-key", sal_strlen("ipv6-mcast-route-key")) ==0)
    {
        table_alloc_info.table_id = DsIpv6McastRouteKey_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-nat-key", sal_strlen("ipv4-nat-key")) ==0)
    {
        table_alloc_info.table_id = DsIpv4NatKey_t;
    }
    else if(sal_strncmp(argv[0], "ipv6-nat-key", sal_strlen("ipv6-nat-key")) ==0)
    {
        table_alloc_info.table_id = DsIpv6NatKey_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-pbr-key", sal_strlen("ipv4-pbr-key")) == 0)
    {
        table_alloc_info.table_id = DsIpv4PbrKey_t;
    }
    else if(sal_strncmp(argv[0], "ipv6-pbr-key", sal_strlen("ipv6-pbr-key")) == 0)
    {
        table_alloc_info.table_id = DsIpv6PbrKey_t;
    }
    else if(sal_strncmp(argv[0], "mac-bridge-key", sal_strlen("mac-bridge-key")) == 0)
    {
        table_alloc_info.table_id = DsMacBridgeKey_t;
    }
    else if(sal_strncmp(argv[0], "fcoe-route-key", sal_strlen("fcoe-route-key")) == 0)
    {
        table_alloc_info.table_id = DsFcoeRouteKey_t;
    }
    else if(sal_strncmp(argv[0], "trill-ucast-key", sal_strlen("trill-ucast-key")) == 0)
    {
        table_alloc_info.table_id = DsTrillUcastRouteKey_t;
    }
    else if(sal_strncmp(argv[0], "trill-mcast-key", sal_strlen("trill-mcast-key")) == 0)
    {
        table_alloc_info.table_id = DsTrillMcastRouteKey_t;
    }
    else if(sal_strncmp(argv[0], "user-id-mac-key", sal_strlen("user-id-mac-key")) ==0)
    {
        table_alloc_info.table_id = DsUserIdMacKey_t;
    }
    else if(sal_strncmp(argv[0], "user-id-ipv6-key", sal_strlen("user-id-ipv6-key")) ==0)
    {
        table_alloc_info.table_id = DsUserIdIpv6Key_t;
    }
    else if(sal_strncmp(argv[0], "user-id-ipv4-key", sal_strlen("user-id-ipv4-key"))==0)
    {
        table_alloc_info.table_id = DsUserIdIpv4Key_t;
    }
    else if(sal_strncmp(argv[0], "user-id-vlan-key", sal_strlen("user-id-vlan-key")) ==0)
    {
        table_alloc_info.table_id = DsUserIdVlanKey_t;
    }
    else if(sal_strncmp(argv[0], "tunnel-id-ipv6-key", sal_strlen("tunnel-id-ipv6-key")) ==0)
    {
        table_alloc_info.table_id = DsTunnelIdIpv6Key_t;
    }
    else if(sal_strncmp(argv[0], "tunnel-id-ipv4-key", sal_strlen("tunnel-id-ipv4-key")) ==0)
    {
        table_alloc_info.table_id = DsTunnelIdIpv4Key_t;
    }
    else if(sal_strncmp(argv[0], "tunnel-id-pbb-key", sal_strlen("tunnel-id-pbb-key")) ==0)
    {
        table_alloc_info.table_id = DsTunnelIdPbbKey_t;
    }
    else if(sal_strncmp(argv[0], "tunnel-id-capwap-key", sal_strlen("tunnel-id-capwap-key")) ==0)
    {
        table_alloc_info.table_id = DsTunnelIdCapwapKey_t;
    }
    else if(sal_strncmp(argv[0], "tunnel-id-trill-key", sal_strlen("tunnel-id-trill-key")) ==0)
    {
        table_alloc_info.table_id = DsTunnelIdTrillKey_t;
    }
#if V5_20_NOTE
    else if(sal_strncmp(argv[0], "eth-oam-key", sal_strlen("eth-oam-key")) ==0)
    {
        table_alloc_info.table_id = DsEthOamKey_t;
    }
    else if(sal_strncmp(argv[0], "bfd-oam-key", sal_strlen("bfd-oam-key")) ==0)
    {
        table_alloc_info.table_id = DsBfdOamKey_t;
    }
    else if(sal_strncmp(argv[0], "mpls-oam-key", sal_strlen("mpls-oam-key")) ==0)
    {
        table_alloc_info.table_id = DsMplsOamLabelKey_t;
    }
    else if(sal_strncmp(argv[0], "pbt-oam-key", sal_strlen("pbt-oam-key")) ==0)
    {
        table_alloc_info.table_id = DsPbtOamKey_t;
    }
    else if(sal_strncmp(argv[0], "eth-rmep-key", sal_strlen("eth-rmep-key")) ==0)
    {
        table_alloc_info.table_id = DsEthOamRmepKey_t;
    }
#endif
    else if(sal_strncmp(argv[0], "mac-ipv4-key", sal_strlen("mac-ipv4-key")) ==0)
    {
        table_alloc_info.table_id = DsMacIpv4Key_t;
    }
    else if(sal_strncmp(argv[0], "mac-ipv6-key", sal_strlen("mac-ipv6-key")) ==0)
    {
        table_alloc_info.table_id = DsMacIpv6Key_t;
    }

    CTC_CLI_GET_UINT32_RANGE("index num", table_alloc_info.index_num, argv[1], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT32_RANGE("key size", table_alloc_info.key_size, argv[2], 0, CTC_MAX_UINT32_VALUE);

    ret = cm_sim_cfg_kit_allocate_tcam_key_process(&table_alloc_info);

    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% TCAM key allocation failed for key id %d, ret=%d!\n", table_alloc_info.table_id, ret);
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}


CTC_CLI(cli_cmodel_tcam_ad_allocation_process,
    cli_cmodel_tcam_ad_allocation_process_cmd,
    "tcam-ad allocation (ipv6-acl0| ipv6-acl1| ipv4-acl0| ipv4-acl1| ipv4-acl2| ipv4-acl3| \
    mac-acl0| mac-acl1| mac-acl2| mac-acl3 |ipv4-ucast-da|ipv4-mcast-da\
    |ipv6-ucast-da |ipv6-mcast-da |ipv4-sa-nat\
    |ipv6-sa-nat|ipv4-ucast-pbr-dual-da|ipv6-ucast-pbr-dual-da|mac-tcam|fcoe-da|fcoe-sa|trill-ucast-da |trill-mcast-da \
    |user-id-mac |user-id-ipv4|user-id-ipv6 |user-id-vlan|tunnel-id-ipv6|tunnel-id-ipv4 \
    |tunnel-id-pbb|tunnel-id-capwap|tunnel-id-trill \
    |eth-oam-chan | bfd-oam-chan |mpls-oam-chan |pbt-oam-chan |eth-rmep-chan | mac-ipv4-ad | mac-ipv6-ad) INDEX_NUM",
    "Tcam AD tables",
    "Memory allocation",
    "DS_IPV6_ACL0",
    "DS_IPV6_ACL1",
    "DS_IPV4_ACL0",
    "DS_IPV4_ACL1",
    "DS_IPV4_ACL2",
    "DS_IPV4_ACL3",
    "DS_MAC_ACL0",
    "DS_MAC_ACL1",
    "DS_MAC_ACL2",
    "DS_MAC_ACL3",
    "DS_IPV4_UCAST_DA",
    "DS_IPV4_MCAST_DA",
    "DS_IPV6_UCAST_DA",
    "DS_IPV6_MCAST_DA",
    "DS_IPV4_SA_NAT",
    "DS_IPV6_SA_NAT",
    "DS_IPV4_UCAST_PBR_DUAL_DA",
    "DS_IPV6_UCAST_PBR_DUAL_DA",
    "DS_MAC_TCAM",
    "DS_FCOE_DA_TCAM",
    "DS_FCOE_SA_TCAM",
    "DS_TRILL_DA_Ucast_TCAM",
    "DS_TRILL_DA_Mcast_TCAM",
    "DS_USER_ID_MAC",
    "DS_USER_ID_IPV6",
    "DS_USER_ID_IPV4",
    "DS_USER_ID_VLAN",
    "DS_TUNNEL_ID_IPV6",
    "DS_TUNNEL_ID_IPV4",
    "DS_TUNNEL_ID_PBB",
    "DS_TUNNEL_ID_CAPWAP",
    "DS_TUNNEL_ID_TRILL",
    "DsEthOamChanTcam",
    "DsBfdOamChanTcam",
    "DsMplsOamChanTcam",
    "DsPbtOamChanTcam",
    "DsEthOamRmepChan",
    "DsMacIpv4Tcam",
    "DsMacIpv6Tcam",
    "Max index num")
{
    cm_table_allocation_info_t table_alloc_info;
    int32 ret = DRV_E_NONE;

    if(sal_strncmp(argv[0],"ipv6-acl0", sal_strlen("ipv6-acl0")) == 0)
    {
        table_alloc_info.table_id = DsIpv6Acl0Tcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv6-acl1", sal_strlen("ipv6-acl1")) ==0)
    {
        table_alloc_info.table_id = DsIpv6Acl1Tcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-acl0", sal_strlen("ipv4-acl0")) ==0)
    {
        table_alloc_info.table_id = DsIpv4Acl0Tcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-acl1", sal_strlen("ipv4-acl1")) ==0)
    {
        table_alloc_info.table_id = DsIpv4Acl1Tcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-acl2", sal_strlen("ipv4-acl2")) ==0)
    {
        table_alloc_info.table_id = DsIpv4Acl2Tcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-acl3", sal_strlen("ipv4-acl3")) ==0)
    {
        table_alloc_info.table_id = DsIpv4Acl3Tcam_t;
    }
    else if(sal_strncmp(argv[0], "mac-acl0", sal_strlen("mac-acl0"))== 0)
    {
        table_alloc_info.table_id = DsMacAcl0Tcam_t;
    }
    else if(sal_strncmp(argv[0], "mac-acl1", sal_strlen("mac-acl1"))== 0)
    {
        table_alloc_info.table_id = DsMacAcl1Tcam_t;
    }
    else if(sal_strncmp(argv[0], "mac-acl2", sal_strlen("mac-acl2"))== 0)
    {
        table_alloc_info.table_id = DsMacAcl2Tcam_t;
    }
    else if(sal_strncmp(argv[0], "mac-acl3", sal_strlen("mac-acl3"))== 0)
    {
        table_alloc_info.table_id = DsMacAcl3Tcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-ucast-da", sal_strlen("ipv4-ucast-da"))== 0)
    {
        table_alloc_info.table_id = DsIpv4UcastDaTcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-mcast-da", sal_strlen("ipv4-mcast-da"))== 0)
    {
        table_alloc_info.table_id = DsIpv4McastDaTcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv6-ucast-da", sal_strlen("ipv6-ucast-da")) ==0)
    {
        table_alloc_info.table_id = DsIpv6UcastDaTcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv6-mcast-da", sal_strlen("ipv6-mcast-da")) ==0)
    {
        table_alloc_info.table_id = DsIpv6McastDaTcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-sa-nat", sal_strlen("ipv4-sa-nat")) ==0)
    {
        table_alloc_info.table_id = DsIpv4SaNatTcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv6-sa-nat", sal_strlen("ipv6-sa-nat")) ==0)
    {
        table_alloc_info.table_id = DsIpv6SaNatTcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv4-ucast-pbr-dual-da", sal_strlen("ipv4-ucast-pbr-dual-da")) == 0)
    {
        table_alloc_info.table_id = DsIpv4UcastPbrDualDaTcam_t;
    }
    else if(sal_strncmp(argv[0], "ipv6-ucast-pbr-dual-da", sal_strlen("ipv6-ucast-pbr-dual-da")) == 0)
    {
        table_alloc_info.table_id = DsIpv6UcastPbrDualDaTcam_t;
    }
    else if(sal_strncmp(argv[0], "mac-tcam", sal_strlen("mac-tcam")) == 0)
    {
        table_alloc_info.table_id = DsMacTcam_t;
    }
    else if(sal_strncmp(argv[0], "fcoe-da", sal_strlen("fcoe-da")) == 0)
    {
        table_alloc_info.table_id = DsFcoeDaTcam_t;
    }
    else if(sal_strncmp(argv[0], "fcoe-sa", sal_strlen("fcoe-sa")) == 0)
    {
        table_alloc_info.table_id = DsFcoeSaTcam_t;
    }
    else if(sal_strncmp(argv[0], "trill-ucast-da", sal_strlen("trill-ucast-da")) == 0)
    {
        table_alloc_info.table_id = DsTrillDaUcastTcam_t;
    }
    else if(sal_strncmp(argv[0], "trill-mcast-da", sal_strlen("trill-mcast-da")) == 0)
    {
        table_alloc_info.table_id = DsTrillDaMcastTcam_t;
    }
    else if(sal_strncmp(argv[0], "user-id-mac", sal_strlen("user-id-mac")) ==0)
    {
        table_alloc_info.table_id = DsUserIdMacTcam_t;
    }
    else if(sal_strncmp(argv[0], "user-id-ipv6", sal_strlen("user-id-ipv6")) ==0)
    {
        table_alloc_info.table_id = DsUserIdIpv6Tcam_t;
    }
    else if(sal_strncmp(argv[0], "user-id-ipv4", sal_strlen("user-id-ipv4"))==0)
    {
        table_alloc_info.table_id = DsUserIdIpv4Tcam_t;
    }
    else if(sal_strncmp(argv[0], "user-id-vlan", sal_strlen("user-id-vlan")) ==0)
    {
        table_alloc_info.table_id = DsUserIdVlanTcam_t;
    }
    else if(sal_strncmp(argv[0], "tunnel-id-ipv6", sal_strlen("tunnel-id-ipv6")) ==0)
    {
        table_alloc_info.table_id = DsTunnelIdIpv6Tcam_t;
    }
    else if(sal_strncmp(argv[0], "tunnel-id-ipv4", sal_strlen("tunnel-id-ipv4")) ==0)
    {
        table_alloc_info.table_id = DsTunnelIdIpv4Tcam_t;
    }
    else if(sal_strncmp(argv[0], "tunnel-id-pbb", sal_strlen("tunnel-id-pbb")) ==0)
    {
        table_alloc_info.table_id = DsTunnelIdPbbTcam_t;
    }
    else if(sal_strncmp(argv[0], "tunnel-id-capwap", sal_strlen("tunnel-id-capwap")) ==0)
    {
        table_alloc_info.table_id = DsTunnelIdCapwapTcam_t;
    }
    else if(sal_strncmp(argv[0], "tunnel-id-trill", sal_strlen("tunnel-id-trill")) ==0)
    {
        table_alloc_info.table_id = DsTunnelIdTrillTcam_t;
    }
    else if(sal_strncmp(argv[0], "eth-oam-chan", sal_strlen("eth-oam-chan ")) ==0)
    {
        table_alloc_info.table_id = DsEthOamTcamChan_t;
    }
    else if(sal_strncmp(argv[0], "bfd-oam-chan", sal_strlen("bfd-oam-chan")) ==0)
    {
        table_alloc_info.table_id = DsBfdOamChanTcam_t;
    }
    else if(sal_strncmp(argv[0], "mpls-oam-chan", sal_strlen("mpls-oam-chan")) ==0)
    {
        table_alloc_info.table_id = DsMplsOamChanTcam_t;
    }
    else if(sal_strncmp(argv[0], "pbt-oam-chan", sal_strlen("pbt-oam-chan")) ==0)
    {
        table_alloc_info.table_id = DsPbtOamChanTcam_t;
    }
    else if(sal_strncmp(argv[0], "eth-rmep-chan", sal_strlen("eth-rmep-chan")) ==0)
    {
        table_alloc_info.table_id = DsEthRmepChan_t;
    }
    else if(sal_strncmp(argv[0], "mac-ipv4-ad", sal_strlen("mac-ipv4-ad")) ==0)
    {
        table_alloc_info.table_id = DsMacIpv4Tcam_t;
    }
    else if(sal_strncmp(argv[0], "mac-ipv6-ad", sal_strlen("mac-ipv6-ad")) ==0)
    {
        table_alloc_info.table_id = DsMacIpv6Tcam_t;
    }

    CTC_CLI_GET_UINT32_RANGE("index num", table_alloc_info.index_num, argv[1], 0, CTC_MAX_UINT32_VALUE);

    ret = cm_sim_cfg_kit_allocate_tcam_ad_process(&table_alloc_info);

    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% TCAM ADs allocation failed, ret = %d!\n", ret);
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}

CTC_CLI(cli_cmodel_lpm_tcam_key_allocation_process,
    cli_cmodel_lpm_tcam_key_allocation_process_cmd,
    "lpm-tcam-key allocation INDEX_NUM",
    "LPM Tcam key tables",
    "Max index num")
{
    cm_table_allocation_info_t table_alloc_info;
    sal_memset(&table_alloc_info, 0, sizeof(cm_table_allocation_info_t));
    int32 ret = DRV_E_NONE;

    table_alloc_info.table_id = DsLpmTcam80Key_t;

    CTC_CLI_GET_UINT32_RANGE("index num", table_alloc_info.index_num, argv[0], 0, CTC_MAX_UINT32_VALUE);
    table_alloc_info.key_size = 4;
    ret = cm_sim_cfg_kit_allocate_lpm_tcam_key_process(&table_alloc_info);

    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% LPM TCAM key allocation failed, ret=%d!\n", ret);
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}


CTC_CLI(cli_cmodel_lpm_tcam_ad_allocation_process,
    cli_cmodel_lpm_tcam_ad_allocation_process_cmd,
    "lpm-tcam-ad allocation INDEX_NUM",
    "LPM Tcam ad tables",
    "Max index num")
{
    cm_table_allocation_info_t table_alloc_info;
    sal_memset(&table_alloc_info, 0, sizeof(cm_table_allocation_info_t));
    int32 ret = DRV_E_NONE;

    table_alloc_info.table_id = LpmTcamAdMem_t;

    CTC_CLI_GET_UINT32_RANGE("index num", table_alloc_info.index_num, argv[0], 0, CTC_MAX_UINT32_VALUE);
    table_alloc_info.key_size = 4;
    ret = cm_sim_cfg_kit_allocate_lpm_tcam_ad_process(&table_alloc_info);

    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("%% LPM TCAM ad allocation failed, ret=%d!\n", ret);
        return CLI_ERROR;
    }
    else
    {
        return CLI_SUCCESS;
    }
}



CTC_CLI(cli_cmodel_show_allocation,
    cli_cmodel_show_allocation_cmd,
    "show memory-allocation (tcam| hash | dynamic-table | all)",
    "Show system information",
    "Memory allocation",
    "Tcam key and AD allocation",
    "Hash key and AD allocation",
    "Dynamci tables",
    "All allocated tables")
{
    if(sal_strncmp(argv[0], "tcam", sal_strlen("tcam")) ==0)
    {
        cm_sim_cfg_kit_show_tcam_allocation();
    }
    else if(sal_strncmp(argv[0], "hash", sal_strlen("hash")) ==0)
    {
        cm_sim_cfg_kit_show_hash_allocation();
    }
    else if(sal_strncmp(argv[0], "dynamic-table", sal_strlen("dynamic-table")) ==0)
    {
        cm_sim_cfg_kit_show_dynamic_allocation();
    }
    else if(sal_strncmp(argv[0], "all", sal_strlen("all")) ==0)
    {
        cm_sim_cfg_kit_show_tcam_allocation();
        cm_sim_cfg_kit_show_hash_allocation();
        cm_sim_cfg_kit_show_dynamic_allocation();
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_show_allocation_none_allocated_tbl,
    cli_cmodel_show_allocation_none_allocated_tbl_cmd,
    "show memory-allocation none-allocated-table",
    "Show system information",
    "Memory allocation",
    "Show dynamic and Tcam table which is not allocated")
{

    cm_sim_cfg_kit_show_table_allocation();

    return CLI_SUCCESS;
}

CTC_CLI(cli_cmodel_show_allocation_rtl_register_info,
    cli_cmodel_show_allocation_rtl_register_info_cmd,
    "show memory-allocation rtl-register (detail |)",
    "Show system information",
    "Memory allocation",
    "Show allocation rtl register")
{
    uint8 detail_info_flag = FALSE;

    if (argc == 1)
    {
       if(sal_strncmp(argv[0], "detail", sal_strlen("detail")) ==0)
       {
            detail_info_flag = TRUE;
       }

    }

    cm_sim_cfg_kit_show_rtl_register_info(detail_info_flag);


    return CLI_SUCCESS;
}


CTC_CLI(cli_cmodel_check_allocation_dynamic_tbl,
    cli_cmodel_check_allocation_dynamic_tbl_cmd,
    "check memory-allocation chip CHIP (dynamic-tbl | tcam)",
    "check memory-allocation",
    "Memory allocation",
    "check chip",
    "chip id value",
    "check allocation dynamic tbl register",
    "check allocation tcam tbl register")
{
    uint32 chip_id = 0;
    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);

    if(0 == (sal_strcmp(argv[1], "dynamic-tbl" )))
    {
        cm_sim_cfg_kit_allocate_dynamic_tbl_chk(chip_id);
    }
    else
    {
        cm_sim_cfg_kit_allocate_tcam_tbl_chk(chip_id);
    }

    return CLI_SUCCESS;
}


void install_mem_allocation_cli(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_cmodel_mem_allocation_profile_cmd);

    install_element(cli_tree_mode, &cli_cmodel_tcam_key_allocation_process_cmd);
    install_element(cli_tree_mode, &cli_cmodel_lpm_tcam_key_allocation_process_cmd);
    install_element(cli_tree_mode, &cli_cmodel_lpm_tcam_ad_allocation_process_cmd);

    install_element(cli_tree_mode, &cli_cmodel_tcam_ad_allocation_process_cmd);
    install_element(cli_tree_mode, &cli_cmodel_show_allocation_cmd);

    install_element(cli_tree_mode, &cli_cmodel_allocation_process_cmd);
    install_element(cli_tree_mode, &cli_cmodel_initialize_tcam_key_process_cmd);
    install_element(cli_tree_mode, &cli_cmodel_show_allocation_none_allocated_tbl_cmd);

    install_element(cli_tree_mode, &cli_cmodel_show_allocation_rtl_register_info_cmd);

    install_element(cli_tree_mode, &cli_cmodel_check_allocation_dynamic_tbl_cmd);

}


