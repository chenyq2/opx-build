/****************************************************************************
 * cmodel_cli_master.h   cmodel cli main thread
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0
 * Author:       Jiang
 * Date:         2010-11-1.
 * Reason:       First Create.
 ****************************************************************************/

#include "ctc_cli.h"
#include "sal.h"
#include "drv_lib.h"
#include "dal.h"


extern int32 ctc_cmodel_cli_init(uint8 cli_tree_mode);
extern int32 ctc_dbg_tool_cli_init(uint8 cli_tree_mode);
extern int32 sram_model_initialize(uint8 chip_id_offset);
extern int32 tcam_model_initialize(uint8 chip_id_offset);
extern int32 sram_model_allocate_sram_tbl_info(void);
extern int32 sim_model_init(void);

/* "exit" function.  */
void
ctc_cli_mode_exit(void)
{
  switch(g_ctc_vti->node)
  {
    case EXEC_MODE:
        restore_terminal_mode();
        exit(0);
        break;
    case CTC_SDK_MODE:
    case CTC_CMODEL_MODE:
        g_ctc_vti->node = EXEC_MODE;
        break;
    case CTC_SDK_OAM_CHAN_MODE:
        g_ctc_vti->node = CTC_SDK_MODE;
        break;
    default:
        g_ctc_vti->node = EXEC_MODE;
        break;
  }
}


CTC_CLI(exit_config,
    exit_cmd,
    "exit",
    "End current mode and down to previous mode")
{

   ctc_cli_mode_exit ();
    return CLI_SUCCESS;
}

CTC_CLI(quit_config,
    quit_cmd,
    "quit",
    "Exit current mode and down to previous mode")
{
    ctc_cli_mode_exit();
    return CLI_SUCCESS;
}

CTC_CLI(cli_enter_cmodel_mode,
        enter_cmodel_mode_cmd,
        "enter cmodel mode",
        "Enter",
        "Ctc cmodel mode",
        "Mode")
{
    g_ctc_vti->node  = CTC_CMODEL_MODE;
    return CLI_SUCCESS;
}

CTC_CLI(fast_enter_dbg_mode,
        fast_enter_dbg_mode_cmd,
        "debug",
        "Enter debug mode")
{
    g_ctc_vti->node  = CTC_DBG_TOOL_MODE;
    return CLI_SUCCESS;
}

CTC_CLI(fast_enter_cmodel_mode,
        fast_enter_cmodel_mode_cmd,
        "cmodel",
        "Enter cmodel mode")
{
    g_ctc_vti->node  = CTC_CMODEL_MODE;
    return CLI_SUCCESS;
}

ctc_cmd_node_t exec_node =
{
  EXEC_MODE,
  "\rCTC_CLI# ",
};

ctc_cmd_node_t sdk_node =
{
  CTC_SDK_MODE,
  "\rCTC_CLI(ctc-sdk)# ",
};

ctc_cmd_node_t cmodel_node =
{
  CTC_CMODEL_MODE,
  "\rCTC_CLI(ctc-cmodel)# ",
};

ctc_cmd_node_t oam_chan_node =
{
  CTC_SDK_OAM_CHAN_MODE,
  "\rCTC_CLI(oam_chan)# ",
};

ctc_cmd_node_t debug_tool_node =
{
    CTC_DBG_TOOL_MODE,
    "\rCTC_CLI(ctc-dt)# ",
};

int cmodel_cli_master(void)
{

    ctc_install_node (&cmodel_node, NULL);
    ctc_install_node (&oam_chan_node, NULL);
    ctc_vti_init(CTC_CMODEL_MODE);

    install_element(CTC_CMODEL_MODE, &exit_cmd);
    install_element(CTC_CMODEL_MODE, &quit_cmd);
    install_element(CTC_CMODEL_MODE, &fast_enter_dbg_mode_cmd);

    ctc_cmodel_cli_init(CTC_CMODEL_MODE);

    return 0;
}

int dbgtool_cli_master(void)
{
    ctc_install_node(&debug_tool_node, NULL);
    ctc_vti_init(CTC_DBG_TOOL_MODE);

    install_element(CTC_DBG_TOOL_MODE, &exit_cmd);
    install_element(CTC_DBG_TOOL_MODE, &quit_cmd);
    install_element(CTC_DBG_TOOL_MODE, &fast_enter_cmodel_mode_cmd);
    ctc_com_cli_init(CTC_CMODEL_MODE);

    ctc_dbg_tool_cli_init(CTC_CMODEL_MODE);

    return 0;
}

int main ()
{
    int ret = 0;
    mem_mgr_init();

    if (0 == SDK_WORK_PLATFORM)
    {
        /* dal module init */
        ret = dal_set_device_access_type(DAL_SPECIAL_EMU);
        if (ret < 0)
        {
            sal_printf("Failed to register dal callback\r\n");
            return ret;
        }

        ret = dal_op_init(NULL);
        if (ret != 0)
        {
            sal_printf("Failed to register dal callback\r\n");
            return ret;
        }
    }

    /* drv module init */
    drv_init(1, 0);

    ctc_cmd_init (0);
    /* Install top nodes. */
    ctc_install_node (&exec_node, NULL);

    install_element(EXEC_MODE, &exit_cmd);
    install_element(EXEC_MODE, &quit_cmd);

    install_element(EXEC_MODE, &enter_cmodel_mode_cmd);

    cmodel_cli_master();
    dbgtool_cli_master();

    ctc_sort_node();

    set_terminal_raw_mode();

    while(1)
    {
        ctc_vti_read();
    }

    restore_terminal_mode();

   return 0;
}



