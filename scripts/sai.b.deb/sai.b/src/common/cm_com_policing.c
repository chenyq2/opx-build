/****************************************************************************
 * cm_com_policing.c    Provides SHARE policing handle function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Version:        V1.0
 * Author:         Jiang
 * Date:           2010-10-15.
 * Reason:         First Create.
 *
 * Modify History:
 * Reversion:    V1.01
 * Author:       XuZx
 * Date:         2010-11-15.
 * Reason:       Revise for first formal spec.
 *
 * Reversion:    V1.02
 * Author:       XuZx
 * Date:         2010-11-22.
 * Reason:       Revise for second formal spec.
 *
 * Reversion:    V2.0
 * Author:       Jiangsz
 * Date:         2011-04-11.
 * Reason:       Sync spec v2.0.
 *
 * Revision:     V4.28.0
 * Author:       TaoJ.
 * Date:         2011-9-29.
 * Reason:       Sync spec revision 4.28.0.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/

#include "sal.h"
#include "ctckal.h"
#include "cm_lib.h"
#include "drv_lib.h"
#include "cm_com_policing.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

struct policing_meter_info_s
{
    uint32 chip_id         :5;
    uint32 packet_length   :14;
    uint32 color           :2;
    uint32 layer3_offset   :8;
    uint32 policer_ptr     :14;
    uint32 policer_valid   :1;
    uint32 ipg             :8;

    uint32 sop             :1;
    uint32 eop             :1;
    uint32 sop_color       :2;
};

typedef struct policing_meter_info_s  policing_meter_info_t;

struct policing_meter_result_s
{
    uint32  mark_drop   :1;
    uint32  new_color   :2;
    uint32  resv        :29;
};

typedef struct policing_meter_result_s  policing_meter_result_t;



/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/

static uint32
_cm_com_policing_func_subtract(uint32 a, uint32 b)
{
    uint32 c = 0;
    uint32 ret = 0;

    if (!IS_BIT_SET(a, 23) && ((a & 0x7FFFFF) >= (b & 0x7FFFFF)))
    {
        c = (a & 0x7FFFFF) - (b & 0x7FFFFF);
        ret = (IS_BIT_SET(a, 23) << 23) | (c & 0x7FFFFF);
    }
    else if (!IS_BIT_SET(a, 23) && ((a & 0x7FFFFF) < (b & 0x7FFFFF)))
    {
        c = (b & 0x7FFFFF) - (a & 0x7FFFFF);
        ret = (1 << 23) | (c & 0x7FFFFF);
    }
    else
    {
        c = (((a & 0x7FFFFF) + (b & 0x7FFFFF)) > 0x7FFFFF) ? ((a & 0x7FFFFF) + (b & 0x7FFFFF)) : 0x7FFFFF;
        ret = (IS_BIT_SET(a, 23) << 23) | (c & 0x7FFFFF);
    }

    return ret;
}

/****************************************************************************
 * Name:       _cm_ipe_policing_metering_operation
 * Purpose:    IPE policing handle process.
 * Parameters:
 * Input:      chip_id       -- physical chip identity
 *             packet_length -- packet length
 *             color         -- color
 *             layer3_offset -- layer 3 offset
 *             policer_ptr   -- policer pointer
 *             ipg
 * Output:     mark_drop     -- if marked drop
 *             new_color     -- new color
 * Return:     DRV_E_NONE    -- success.
 *             Other         -- Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_com_policing_metering_operation(policing_meter_info_t* meter_info, policing_meter_result_t *meter_result)
{
    ipe_policing_ctl_t ipe_policing_ctl;
    policing_misc_ctl_t  policer_misc_ctl;
    ds_policer_control_t ds_policer_ctl;
    ds_policer_count_t ds_policer_count;
    ds_policer_profile_t ds_policer_profile;

    uint8 chip_id = meter_info->chip_id;
    uint8 min_length = 0;
    uint8 ds_policer_profile_ptr = 0;
    uint8 ds_policer_sr_tcm_mode = 0;
    uint8 ds_policer_user_layer3_length = 0;
    uint8 ds_policer_color_drop_code = 0;
    uint8 ds_policer_color_blind_mode = 0;
    uint8 ds_policer_rfc_4115_mode = 0;
    uint8 ds_policer_stats_en = 0;
    uint8 commit_count_shift = 0, peak_count_shift = 0;
    uint8 is_color_blind = FALSE, sr_tcm_mode = FALSE, tr_tcm_mode = FALSE;
    uint8 is_green = FALSE, is_yellow = FALSE, is_red = FALSE;
    uint8 is_tc_more_length = FALSE, is_tp_more_length = FALSE;
    uint16 policer_ptr = meter_info->policer_ptr;
    uint16 length = 0, layer2_length = 0;
    uint32 stats_ptr = 0;
    uint32 value_tc = 0, value_tp = 0;
    uint32 commit_length = 0, peak_length = 0;
    uint32 ds_policer_count_commit_count = 0, ds_policer_count_peak_count = 0;
    uint32 cmd = 0;

    /* read policer control register */
    sal_memset(&ipe_policing_ctl, 0, sizeof(ipe_policing_ctl));
    cmd = DRV_IOR(IpePolicingCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_policing_ctl));

    sal_memset(&ds_policer_ctl, 0, sizeof(ds_policer_control_t));
    cmd = DRV_IOR(DsPolicerControl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ((policer_ptr >> 2) & 0x7FF), cmd, &ds_policer_ctl));

    sal_memset(&policer_misc_ctl, 0, sizeof(policer_misc_ctl));
    cmd = DRV_IOR(PolicingMiscCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &policer_misc_ctl));

    switch (policer_ptr & 0x3)
    {
        case 0:
            ds_policer_profile_ptr = ds_policer_ctl.profile0;
            ds_policer_sr_tcm_mode = ds_policer_ctl.sr_tcm_mode0;
            ds_policer_user_layer3_length = ds_policer_ctl.use_layer3_length0;
            ds_policer_color_drop_code = ds_policer_ctl.color_drop_code0;
            ds_policer_color_blind_mode = ds_policer_ctl.color_blind_mode0;
            ds_policer_rfc_4115_mode = ds_policer_ctl.rfc4115_mode0;
            ds_policer_stats_en = ds_policer_ctl.stats_en0;
            break;
        case 1:
            ds_policer_profile_ptr = ds_policer_ctl.profile1;
            ds_policer_sr_tcm_mode = ds_policer_ctl.sr_tcm_mode1;
            ds_policer_user_layer3_length = ds_policer_ctl.use_layer3_length1;
            ds_policer_color_drop_code = ds_policer_ctl.color_drop_code1;
            ds_policer_color_blind_mode = ds_policer_ctl.color_blind_mode1;
            ds_policer_rfc_4115_mode = ds_policer_ctl.rfc4115_mode1;
            ds_policer_stats_en = ds_policer_ctl.stats_en1;
            break;
        case 2:
            ds_policer_profile_ptr = ds_policer_ctl.profile2;
            ds_policer_sr_tcm_mode = ds_policer_ctl.sr_tcm_mode2;
            ds_policer_user_layer3_length = ds_policer_ctl.use_layer3_length2;
            ds_policer_color_drop_code = ds_policer_ctl.color_drop_code2;
            ds_policer_color_blind_mode = ds_policer_ctl.color_blind_mode2;
            ds_policer_rfc_4115_mode = ds_policer_ctl.rfc4115_mode2;
            ds_policer_stats_en = ds_policer_ctl.stats_en2;
            break;
        case 3:
            ds_policer_profile_ptr = ds_policer_ctl.profile3;
            ds_policer_sr_tcm_mode = ds_policer_ctl.sr_tcm_mode3;
            ds_policer_user_layer3_length = ds_policer_ctl.use_layer3_length3;
            ds_policer_color_drop_code = ds_policer_ctl.color_drop_code3;
            ds_policer_color_blind_mode = ds_policer_ctl.color_blind_mode3;
            ds_policer_rfc_4115_mode = ds_policer_ctl.rfc4115_mode3;
            ds_policer_stats_en = ds_policer_ctl.stats_en3;
            break;
        default:
            break;
    }

    sal_memset(&ds_policer_profile, 0, sizeof(ds_policer_profile_t));
    cmd = DRV_IOR(DsPolicerProfile_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ds_policer_profile_ptr, cmd, &ds_policer_profile));

    meter_result->new_color = meter_info->color;    /* intial assign */

    if (0 != meter_info->packet_length)
    {
        /* for EOP and SOP&EOP */
        min_length = ipe_policing_ctl.min_length_check_en && (meter_info->packet_length < 64);
        layer2_length = min_length ? 64 : meter_info->packet_length;
        length = ds_policer_user_layer3_length ? (layer2_length - meter_info->layer3_offset - 4) : layer2_length;

        if (ipe_policing_ctl.ipg_en)
        {
            length += meter_info->ipg;
        }
    }
    else
    {
        length = 0;   /*for SOP */
    }

    is_green  = (COLOR_GREEN == meter_info->color);
    is_yellow = (COLOR_YELLOW == meter_info->color);
    is_red = (COLOR_GREEN != meter_info->color) && (COLOR_YELLOW != meter_info->color);

    is_color_blind = ds_policer_color_blind_mode;
    sr_tcm_mode = ds_policer_sr_tcm_mode;
    tr_tcm_mode = !ds_policer_sr_tcm_mode;

    commit_count_shift = ds_policer_profile.commit_count_shift;
    peak_count_shift = ds_policer_profile.peak_count_shift;

    if (IS_BIT_SET(commit_count_shift, 3))   /* Left shift */
    {
        commit_length = (length & 0x3FFF) << (commit_count_shift & 0x7);
    }
    else                                     /* Right shift */
    {
        if ((commit_count_shift & 0x7) > 0)
        {
            commit_length = ((length & 0x3FFF) >> (commit_count_shift & 0x7))
                            + IS_BIT_SET(length, ((commit_count_shift & 0x7) - 1));
        }
        else
        {
            commit_length = length & 0x3FFF;
        }
    }
    if (IS_BIT_SET(peak_count_shift, 3))     /* Left shift */
    {
        peak_length = ((length & 0x3FFF) << (peak_count_shift & 0x7));
    }
    else
    {
        if ((peak_count_shift & 0x7) > 0)    /* Right shift */
        {
            peak_length = ((length & 0x3FFF) >> (peak_count_shift & 0x7))
                          + IS_BIT_SET(length, ((commit_count_shift & 0x7) - 1));
        }
        else
        {
            peak_length = length & 0x3FFF;
        }
    }

    /* zhouw note: Use the policer update function flow chart */
    /* UpdatePolicer(policerPtr[12:2]); */

    /* read ds policer count */
    sal_memset(&ds_policer_count, 0, sizeof(ds_policer_count_t));
    cmd = DRV_IOR(DsPolicerCount_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ((policer_ptr >> 2) & 0x7FF), cmd, &ds_policer_count));

    switch (policer_ptr & 0x3)
    {
        case 0:
            ds_policer_count_commit_count = ds_policer_count.commit_count0;
            ds_policer_count_peak_count = ds_policer_count.peak_count0;
            break;
        case 1:
            ds_policer_count_commit_count = ds_policer_count.commit_count1;
            ds_policer_count_peak_count = ds_policer_count.peak_count1;
            break;
        case 2:
            ds_policer_count_commit_count = ds_policer_count.commit_count2;
            ds_policer_count_peak_count = ds_policer_count.peak_count2;
            break;
        case 3:
            ds_policer_count_commit_count = ds_policer_count.commit_count3;
            ds_policer_count_peak_count = ds_policer_count.peak_count3;
            break;
        default:
            break;
    }

    if (sr_tcm_mode)          /* SrTCM MODE */
    {
        value_tc = ds_policer_count_commit_count & 0x7FFFFF;
        value_tp = ds_policer_count_peak_count & 0x7FFFFF;
        is_tc_more_length = (value_tc >= commit_length) && !IS_BIT_SET(ds_policer_count_commit_count, 23)
                            && (value_tc != 0);
        is_tp_more_length = (value_tp >= peak_length) && !IS_BIT_SET(ds_policer_count_peak_count, 23)
                            && (value_tp != 0);

        if (is_color_blind)   /* color blind mode */
        {
            if ((is_tc_more_length && meter_info->sop)
                || (!meter_info->sop && meter_info->eop && (COLOR_GREEN == meter_info->sop_color)))
            {
                meter_result->new_color = COLOR_GREEN;
                ds_policer_count_commit_count = _cm_com_policing_func_subtract(ds_policer_count_commit_count,
                                                                               commit_length);
            }
            else
            {
                if ((is_tp_more_length && meter_info->sop)
                    || (!meter_info->sop && meter_info->eop && (COLOR_YELLOW == meter_info->sop_color)))
                {
                    meter_result->new_color = COLOR_YELLOW;
                    ds_policer_count_peak_count = _cm_com_policing_func_subtract(ds_policer_count_peak_count,
                                                                                 commit_length);
                }
                else
                {
                    meter_result->new_color  = COLOR_RED;
                }
            }
        }
        else                  /* color aware mode */
        {
            if ((is_green && is_tc_more_length && meter_info->sop) ||
                (!meter_info->sop && meter_info->eop && (COLOR_GREEN == meter_info->sop_color)))
            {
                meter_result->new_color = COLOR_GREEN;
                ds_policer_count_commit_count = _cm_com_policing_func_subtract(ds_policer_count_commit_count,
                                                                               commit_length);
            }
            else
            {
                if (((is_green || is_yellow) && is_tp_more_length && meter_info->sop)
                    || (!meter_info->sop && meter_info->eop && (COLOR_YELLOW == meter_info->sop_color)))
                {
                    meter_result->new_color = COLOR_YELLOW;
                    ds_policer_count_peak_count = _cm_com_policing_func_subtract(ds_policer_count_peak_count,
                                                                                 commit_length);
                }
                else
                {
                    meter_result->new_color = COLOR_RED;
                }
            }
        }

        cmd = DRV_IOW(DsPolicerCount_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, (policer_ptr >> 2), cmd, &ds_policer_count));
    }
    else if (tr_tcm_mode)                                    /* TrTCM MODE */
    {
        value_tc = ds_policer_count_commit_count & 0x7FFFFF;
        value_tp = ds_policer_count_peak_count & 0x7FFFFF;
        is_tc_more_length = (value_tc >= commit_length) && !IS_BIT_SET(ds_policer_count_commit_count, 23)
                            && (value_tc != 0);
        is_tp_more_length = (value_tp >= peak_length) && !IS_BIT_SET(ds_policer_count_peak_count, 23)
                            && (value_tp != 0);

        if (is_color_blind && (!ds_policer_rfc_4115_mode))   /* color blind mode */
        {
            if ((!is_tp_more_length && meter_info->sop)
                || (!meter_info->sop && meter_info->eop && (COLOR_RED == meter_info->sop_color)))
            {
                meter_result->new_color = COLOR_RED;
            }
            else
            {
                if ((!is_tc_more_length && meter_info->sop)
                    || (!meter_info->sop && meter_info->eop && (COLOR_YELLOW == meter_info->sop_color)))
                {
                    meter_result->new_color = COLOR_YELLOW;
                    ds_policer_count_peak_count = _cm_com_policing_func_subtract(ds_policer_count_peak_count,
                                                                                 peak_length);
                }
                else
                {
                    meter_result->new_color = COLOR_GREEN;
                    ds_policer_count_commit_count = _cm_com_policing_func_subtract(ds_policer_count_commit_count,
                                                                                   commit_length);
                    ds_policer_count_peak_count = _cm_com_policing_func_subtract(ds_policer_count_peak_count,
                                                                                 peak_length);
                }
            }
        }
        else if (!ds_policer_rfc_4115_mode)                  /* color aware mode */
        {
            if (((!is_tp_more_length || is_red) && meter_info->sop)
                || (!meter_info->sop && meter_info->eop && (COLOR_RED == meter_info->sop_color)))
            {
                meter_result->new_color = COLOR_RED;
            }
            else
            {
                if (((!is_tc_more_length || is_yellow) && meter_info->sop)
                    || (!meter_info->sop && meter_info->eop && (COLOR_YELLOW == meter_info->sop_color)))
                {
                    meter_result->new_color = COLOR_YELLOW;
                    ds_policer_count_peak_count = _cm_com_policing_func_subtract(ds_policer_count_peak_count,
                                                                                 peak_length);
                }
                else
                {
                    meter_result->new_color = COLOR_GREEN;
                    ds_policer_count_commit_count = _cm_com_policing_func_subtract(ds_policer_count_commit_count,
                                                                                   commit_length);
                    ds_policer_count_peak_count = _cm_com_policing_func_subtract(ds_policer_count_peak_count,
                                                                                 peak_length);
                }
            }
        }
        else                  /* RFC 4115 mode */
        {
            if (is_color_blind)
            {
                is_green = TRUE;
                is_yellow = FALSE;
                is_red = FALSE;
            }

            if ((is_green && is_tc_more_length && meter_info->sop)
                || (!meter_info->sop && meter_info->eop && (COLOR_GREEN == meter_info->sop_color)))
            {
                meter_result->new_color = COLOR_GREEN;
                ds_policer_count_commit_count = _cm_com_policing_func_subtract(ds_policer_count_commit_count,
                                                                               commit_length);
            }
            else
            {
                if (((is_green || is_yellow) && is_tp_more_length && meter_info->sop)
                    || (!meter_info->sop && meter_info->eop && (COLOR_YELLOW == meter_info->sop_color)))
                {
                    meter_result->new_color = COLOR_YELLOW;
                    ds_policer_count_peak_count = _cm_com_policing_func_subtract(ds_policer_count_peak_count,
                                                                                 peak_length);
                }
                else
                {
                    meter_result->new_color = COLOR_RED;
                }
            }
        }
    }

    /* COLOR DROP */
    if (0 != ds_policer_color_drop_code)
    {
        meter_result->mark_drop = (meter_result->new_color < ds_policer_color_drop_code);
    }

    if ((COLOR_RED == meter_result->new_color) && ipe_policing_ctl.stats_en_violate && ds_policer_stats_en)
    {
        stats_ptr = (policer_misc_ctl.stats_violate_base_ptr << 6) + (policer_ptr & 0x1FFF);
        DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, CM_STATS_DEFAULT,
                                                    stats_ptr, meter_info->packet_length));
    }

    if ((COLOR_YELLOW == meter_result->new_color) && ipe_policing_ctl.stats_en_not_confirm && ds_policer_stats_en)
    {
        stats_ptr = (policer_misc_ctl.stats_not_confirm_base_ptr << 6) + (policer_ptr & 0x1FFF);
        DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, CM_STATS_DEFAULT,
                                                    stats_ptr, meter_info->packet_length));
    }

    if ((COLOR_GREEN == meter_result->new_color) && ipe_policing_ctl.stats_en_confirm && ds_policer_stats_en)
    {
        stats_ptr = (policer_misc_ctl.stats_confirm_base_ptr << 6) + (policer_ptr & 0x1FFF);
        DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, CM_STATS_DEFAULT,
                                                    stats_ptr, meter_info->packet_length));
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_com_policing_operation
 * Purpose:     policing handle process.
 * Parameters:
 *  Input:     policing_info   -- pointer to packet informations for handle
 *
 * Output:     policing_info   -- pointer to packet informations for handle
 * Return:     DRV_E_NONE -- success.
 *             Other      -- Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_com_policing_operation(policing_info_t* policing_info)
{
    policing_meter_info_t meter_info;
    policing_meter_result_t meter_result0;
    policing_meter_result_t meter_result1;
    ipe_policing_ctl_t ipe_policing_ctl;

    uint8 chip_id = policing_info->chip_id;
    uint8 key = 0, ipg = 0, layer3_offset = 0;
    uint8 color = 0, color0 = 0, color1 = 0, new_color = 0;
    uint8 mark_drop = FALSE;
    uint8 policer_valid0 = FALSE, policer_valid1 = FALSE;
    uint16 policer_ptr0 = 0, policer_ptr1 = 0;
    uint16 packet_length = 0;
    uint32 cmd = 0;

    sal_memset(&meter_info, 0, sizeof(policing_meter_info_t));
    sal_memset(&meter_result0, 0, sizeof(policing_meter_result_t));
    sal_memset(&meter_result1, 0, sizeof(policing_meter_result_t));

    sal_memset(&ipe_policing_ctl, 0, sizeof(ipe_policing_ctl));
    cmd = DRV_IOR(IpePolicingCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_policing_ctl));

    color = policing_info->color;
    policer_valid0 = policing_info->policer_valid0;
    policer_valid1 = policing_info->policer_valid1;
    policer_ptr0 = policing_info->policer_ptr0;
    policer_ptr1 = policing_info->policer_ptr1;
    packet_length = policing_info->packet_length;
    layer3_offset = policing_info->layer3_offset;
    ipg = policing_info->ipg;

    /* INIT */
    meter_result0.mark_drop = 0;
    meter_result0.new_color = color;
    meter_result1.mark_drop = 0;
    meter_result1.new_color = color;

    if (policer_valid0)
    {
        /* FIRST_POLICER */
        color0 = color;

        meter_info.chip_id = chip_id;
        meter_info.packet_length = packet_length;
        meter_info.layer3_offset = layer3_offset;
        meter_info.color = color0;
        meter_info.policer_valid = policer_valid0;
        meter_info.policer_ptr = policer_ptr0;
        meter_info.ipg = ipg;

        meter_info.sop = policing_info->sop;
        meter_info.eop = policing_info->eop;
        meter_info.sop_color = policing_info->sop_color;
        DRV_IF_ERROR_RETURN(_cm_com_policing_metering_operation(&meter_info, &meter_result0));
    }

    /* SECEND_POLICING_VALID */
    if ((ipe_policing_ctl.sequential_policing) && meter_result0.mark_drop)
    {
        policer_valid1 = FALSE;   /* drop */
    }

    if (policer_valid1)
    {
        /* SENCOND_POLICER */
        if (ipe_policing_ctl.sequential_policing)
        {
            color1 = meter_result0.new_color;
        }
        else
        {
            color1 = color;
        }

        meter_info.chip_id = chip_id;
        meter_info.packet_length = packet_length;
        meter_info.layer3_offset = layer3_offset;
        meter_info.color = color1;
        meter_info.policer_valid = policer_valid1;
        meter_info.policer_ptr = policer_ptr1;
        meter_info.ipg = ipg;

        meter_info.sop = policing_info->sop;
        meter_info.eop = policing_info->eop;
        meter_info.sop_color = policing_info->sop_color;
        DRV_IF_ERROR_RETURN(_cm_com_policing_metering_operation(&meter_info, &meter_result1));
    }

    /* RESULT */
    mark_drop = meter_result0.mark_drop || meter_result1.mark_drop;

    if (ipe_policing_ctl.sequential_policing)
    {
        if (policer_valid1)
        {
            new_color = meter_result1.new_color;
        }
        else
        {
            new_color = meter_result0.new_color;
        }
    }
    else
    {
        key = (policer_valid0 << 1) | policer_valid1;

        switch (key & 0x3)
        {
            case 0:
                new_color = meter_result0.new_color;
                break;
            case 1:
                new_color = meter_result1.new_color;
                break;
            case 2:
                new_color = meter_result0.new_color;
                break;
            case 3:
                if (meter_result0.new_color < meter_result1.new_color)
                {
                    new_color = meter_result0.new_color;
                }
                else
                {
                    new_color = meter_result1.new_color;
                }
                break;
            default:
                break;
        }
    }

    policing_info->new_color = new_color;
    policing_info->mark_drop = mark_drop;

    return DRV_E_NONE;
}

