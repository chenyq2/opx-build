
/***************************************************************************
 * cm_com_swemu_sys_hw.c:    provides emulation net rx and tx interface on Hardware.
 * Copyright (C)  2010 Centec Networks Inc. All rights reserved.
 *
 * Revision:      V1.0.
 * Author:       Kcao.
 * Date:         2012-08-16.
 * Reason:       GreatBelt Init Version.
 *
 * Modify History:
****************************************************************************/
/***************************************************************************
 *
 * Header Files
 *
***************************************************************************/
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/ethernet.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

#define SET_FLAG(VAL,FLAG)          (VAL) = (VAL) | (FLAG)
#define UNSET_FLAG(VAL,FLAG)        (VAL) = (VAL) & ~(FLAG)
#define FLAG_ISSET(VAL,FLAG)        (((VAL) & (FLAG)) == (FLAG))

#define SW_BD_DEBUG_IS_ON(FLAG)     FLAG_ISSET(g_swemu_board_debug, FLAG)
#define SW_BD_DEBUG_OUT(fmt, args...)   \
{                                       \
    if (ctc_cmodel_debug_on)            \
    {                                   \
         char _buf[256];                \
         if (NULL == cmodel_debug_cb)   \
         {                              \
            sal_printf(fmt, ##args);    \
         }                              \
         else                           \
         {                              \
            sal_snprintf(_buf, 256, fmt, ##args);\
            cmodel_debug_cb(_buf, sal_strlen(_buf));\
         }                              \
    }                                   \
}

#define SW_BD_LOG                   sal_printf

#define HUMBER_BYPASS_NEXTHOP_PTR   0x3FFFD
#define HUMBER_BRGHDR_CRC_POS       15
#define SOCKET_TIME_OUT             1

#define SWEMU_BOARD_DEBUG_PKT_RAW   0x01

uint32 g_swemu_board_debug = 0;

/* default software emulation environment is a linecard with two humbers */
static mac_descriptor_t swemu_mac_proxy =
{
    1, SIM_IPE_Q, 1, -1, 0
};

/*CRC-8, poly= x^8 + x^2 + x^1 + x^0 ,init=0*/
static uint8 humber_bheader_crc8_table[]=
{
    0x00,   0x07,   0x0E,   0x09,   0x1C,   0x1B,   0x12,   0x15,
    0x38,   0x3F,   0x36,   0x31,   0x24,   0x23,   0x2A,   0x2D,
    0x70,   0x77,   0x7E,   0x79,   0x6C,   0x6B,   0x62,   0x65,
    0x48,   0x4F,   0x46,   0x41,   0x54,   0x53,   0x5A,   0x5D,
    0xE0,   0xE7,   0xEE,   0xE9,   0xFC,   0xFB,   0xF2,   0xF5,
    0xD8,   0xDF,   0xD6,   0xD1,   0xC4,   0xC3,   0xCA,   0xCD,
    0x90,   0x97,   0x9E,   0x99,   0x8C,   0x8B,   0x82,   0x85,
    0xA8,   0xAF,   0xA6,   0xA1,   0xB4,   0xB3,   0xBA,   0xBD,
    0xC7,   0xC0,   0xC9,   0xCE,   0xDB,   0xDC,   0xD5,   0xD2,
    0xFF,   0xF8,   0xF1,   0xF6,   0xE3,   0xE4,   0xED,   0xEA,
    0xB7,   0xB0,   0xB9,   0xBE,   0xAB,   0xAC,   0xA5,   0xA2,
    0x8F,   0x88,   0x81,   0x86,   0x93,   0x94,   0x9D,   0x9A,
    0x27,   0x20,   0x29,   0x2E,   0x3B,   0x3C,   0x35,   0x32,
    0x1F,   0x18,   0x11,   0x16,   0x03,   0x04,   0x0D,   0x0A,
    0x57,   0x50,   0x59,   0x5E,   0x4B,   0x4C,   0x45,   0x42,
    0x6F,   0x68,   0x61,   0x66,   0x73,   0x74,   0x7D,   0x7A,
    0x89,   0x8E,   0x87,   0x80,   0x95,   0x92,   0x9B,   0x9C,
    0xB1,   0xB6,   0xBF,   0xB8,   0xAD,   0xAA,   0xA3,   0xA4,
    0xF9,   0xFE,   0xF7,   0xF0,   0xE5,   0xE2,   0xEB,   0xEC,
    0xC1,   0xC6,   0xCF,   0xC8,   0xDD,   0xDA,   0xD3,   0xD4,
    0x69,   0x6E,   0x67,   0x60,   0x75,   0x72,   0x7B,   0x7C,
    0x51,   0x56,   0x5F,   0x58,   0x4D,   0x4A,   0x43,   0x44,
    0x19,   0x1E,   0x17,   0x10,   0x05,   0x02,   0x0B,   0x0C,
    0x21,   0x26,   0x2F,   0x28,   0x3D,   0x3A,   0x33,   0x34,
    0x4E,   0x49,   0x40,   0x47,   0x52,   0x55,   0x5C,   0x5B,
    0x76,   0x71,   0x78,   0x7F,   0x6A,   0x6D,   0x64,   0x63,
    0x3E,   0x39,   0x30,   0x37,   0x22,   0x25,   0x2C,   0x2B,
    0x06,   0x01,   0x08,   0x0F,   0x1A,   0x1D,   0x14,   0x13,
    0xAE,   0xA9,   0xA0,   0xA7,   0xB2,   0xB5,   0xBC,   0xBB,
    0x96,   0x91,   0x98,   0x9F,   0x8A,   0x8D,   0x84,   0x83,
    0xDE,   0xD9,   0xD0,   0xD7,   0xC2,   0xC5,   0xCC,   0xCB,
    0xE6,   0xE1,   0xE8,   0xEF,   0xFA,   0xFD,   0xF4,   0xF3
};

#if 0
extern uint32
chip_agent_get_cpu_mirror_port();
extern int32
chip_agent_server_send_pkt(uint8* pkt, uint32 len, uint32 mode);
#endif

extern int32
swemu_received_packet_process(uint8 *packet,
                                        uint32 len,
                                        uint32 chipid_offset,
                                        uint32 mac_num);

static int32
_swemu_pkt_dump8(uint8* data, uint32 len, uint32 is_log)
{
    uint32 cnt = 0;
    char line[256];
    char tmp[32];

    for (cnt = 0; cnt < len; cnt++)
    {
        if ((cnt%16) == 0)
        {
            if (cnt != 0)
            {
                SW_BD_DEBUG_OUT("%s", line);
            }
            sal_memset(line, 0, sizeof(line));
            sal_snprintf(tmp, 32, "\n0x%04x:  ", cnt);
            sal_strcat(line, tmp);
        }

        sal_snprintf(tmp, 32, "%02x", data[cnt]);
        sal_strcat(line, tmp);

        if ((cnt%2) == 1)
        {
            sal_strcat(line, " ");
        }
    }

    SW_BD_DEBUG_OUT("%s\n", line);
    return 0;
}

static INLINE uint8
_swemu_humber_bheader_crc8(uint8 *data, int32 len, uint8 init_crc)
{
    int32 cnt;
    uint8 crc = init_crc;

    for (cnt = 0; cnt < len; cnt++)
    {
        crc = humber_bheader_crc8_table[(crc ^ data[cnt])];
    }

    return crc;
}

static int32
_swemu_decode_hb_header(uint8 *buffer, int32 *len, uint32 *mac)
{
    humber_packet_header_t bheader;
    humber_packet_header_t *p_bheader = &bheader;
    uint32 gport = 0;

    if (*len < HUMBER_HEADER_LEN + HUMBER_CPUMAC_HDR_LEN)
    {
        return DRV_E_WRONG_SIZE;
    }

    /* Humber Bridge-Header */
    sal_memcpy(&bheader, buffer + HUMBER_CPUMAC_HDR_LEN, sizeof(humber_packet_header_t));
    DRV_IF_ERROR_RETURN(swap32((uint32*)p_bheader, HUMBER_HEADER_LEN /4, NETWORK_TO_HOST));
    gport = p_bheader->source_port;

    /* need mapping to panel port */
    *mac = gport;
    *len -= HUMBER_HEADER_LEN + HUMBER_CPUMAC_HDR_LEN;

    return DRV_E_NONE;
}

static int32
_swemu_encode_hb_header(uint8 *buffer, int32 *len, uint32 mac)
{
    struct ethhdr *eth;
    humber_packet_header_t bheader;
    humber_packet_header_t *p_bheader = &bheader;
    uint32 gport = 0;
    uint8* p_crc = NULL;

    /* need mapping to panel port */
    gport = mac;

    sal_memset(&bheader, 0, sizeof(bheader));
    p_bheader->header_type = 1;    /* humber header */
    p_bheader->dest_id = gport;
    p_bheader->dest_chip_id = 0;
    p_bheader->source_port = 53; /* HUMBER_CPU_CHAN_ID */
    p_bheader->critical_packet = 1;
    p_bheader->next_hop_ptr = HUMBER_BYPASS_NEXTHOP_PTR;
    p_bheader->packet_length = *len + 4;

    DRV_IF_ERROR_RETURN(swap32((uint32*)p_bheader, HUMBER_HEADER_LEN/4, HOST_TO_NETWORK));

    /* calc bridge header CRC */
    p_crc = (uint8*)(p_bheader);
    p_crc[HUMBER_BRGHDR_CRC_POS] = 0;
    p_crc[HUMBER_BRGHDR_CRC_POS] = _swemu_humber_bheader_crc8((uint8 *)p_bheader, HUMBER_HEADER_LEN, 0);
    sal_memcpy(buffer + HUMBER_CPUMAC_HDR_LEN, p_bheader, sizeof(humber_packet_header_t));

    eth = (struct ethhdr *)buffer;
    /* Modified by kcao 2011-06-13 : add for foam */
    eth->h_dest[0] = 0xFE;
    eth->h_dest[1] = 0xFD;
    eth->h_dest[2] = 0;
    eth->h_dest[3] = 0;
    eth->h_dest[4] = 0;
    eth->h_dest[5] = 1;

    eth->h_source[0] = 0xFE;
    eth->h_source[1] = 0xFD;
    eth->h_source[2] = 0;
    eth->h_source[3] = 0;
    eth->h_source[4] = 0;
    eth->h_source[5] = 0;
    eth->h_proto = htons(0x5A5A);

    *len += HUMBER_HEADER_LEN + HUMBER_CPUMAC_HDR_LEN;

    return DRV_E_NONE;
}

int32
swemu_sys_board_set_debug_net(uint32 flags, uint32 is_set)
{
    if (is_set)
    {
        SET_FLAG(g_swemu_board_debug, flags);
    }
    else
    {
        UNSET_FLAG(g_swemu_board_debug, flags);
    }
    return 0;
}

uint32
swemu_sys_board_get_debug_net()
{
    return g_swemu_board_debug;
}

int32
swemu_sys_board_clear_stats()
{
    sal_memset(g_pkt_cnt_rx, 0, sizeof(g_pkt_cnt_rx));
    sal_memset(g_pkt_cnt_tx, 0, sizeof(g_pkt_cnt_tx));
    return 0;
}

int32
swemu_sys_board_show_stats()
{
    uint32 i = 0;

    SW_BD_LOG("###### Packet TX ######\n");
    SW_BD_LOG("%-8s %-10s\n", "Port", "Count");
    SW_BD_LOG("-------------------\n");
    for (i = 0; i < MAX_MACNUM; i++)
    {
        if (g_pkt_cnt_tx[i])
        {
            SW_BD_LOG("%-8d %-10d\n", i, g_pkt_cnt_tx[i]);
        }
    }

    SW_BD_LOG("###### Packet RX ######\n");
    SW_BD_LOG("%-8s %-10s\n", "Port", "Count");
    SW_BD_LOG("-------------------\n");
    for (i = 0; i < MAX_MACNUM; i++)
    {
        if (g_pkt_cnt_rx[i])
        {
            SW_BD_LOG("%-8d %-10d\n", i, g_pkt_cnt_rx[i]);
        }
    }

    return 0;
}

int32
swemu_received_cpu_packet_process(uint8 *packet,
                                        uint32 len,
                                        uint32 chipid_offset)
{
    out_pkt_t indication;
    uint32 chanid = 0;
    queue_type_t queue_type;
    bool discard = FALSE;
    int32 ret = DRV_E_NONE;
    uint8 chip_id = chipid_offset + drv_init_chip_info.drv_init_chipid_base;
    uint32 mac_num = CPU_MACNUM;

    DRV_PTR_VALID_CHECK(packet);
    sal_memset(&indication, 0, sizeof(indication));

    queue_type = SIM_FWD_Q;
    indication.chip_id = chip_id;
    indication.packet_length = len;
    indication.pkt = packet;
    indication.mac_num = mac_num;

    if (SW_BD_DEBUG_IS_ON(SWEMU_BOARD_DEBUG_PKT_RAW))
    {
        SW_BD_DEBUG_OUT("Chip Agent RX Packet length %d from CPU port %d \n", len, mac_num);
        _swemu_pkt_dump8(packet, len, TRUE);
    }
    g_pkt_cnt_rx[mac_num]++;

    ret = g_sim_model[chipid_offset].macnum2chanid(chip_id, mac_num, &chanid);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Mapping mac number to chanid error!mac number=%d\n", mac_num);
        sal_free(packet);
        packet = NULL;
        return ret;
    }

    indication.chan_id = chanid;

    ret = g_sim_model[chipid_offset].mac_rx[mac_num](&indication, &discard);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Mac entity receives packet error!\n");
        sal_free(packet);
        packet = NULL;
        return ret;
    }

    if (discard)
    {
        sal_free(packet);
        packet = NULL;
        return DRV_E_NONE;
    }

    /* mac receive stats */
    if (g_sim_model[chipid_offset].mac_stats_receive != NULL)
    {
        DRV_IF_ERROR_RETURN(g_sim_model[chipid_offset].mac_stats_receive(&indication));
    }

    ret = ctckal_queue_send(sim_queue[queue_type], (void *)&indication, sizeof(indication));
    if(DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Netrx engine send outpkt to queue error ! ret = %d\n", ret);
        sal_free(packet);
        packet = NULL;
        return ret;
    }

    return DRV_E_NONE;
}

int32
swemu_receive_packet_from_board(void)
{
    int32 maxfdp=0, sock_selected = 0;
    uint8 buffer[PKT_BUFFER_SIZE]={0}, *packet = NULL;
    fd_set fds;
    struct timeval timeout={SOCKET_TIME_OUT, 0};
    int32 len, ret = DRV_E_NONE;
    uint32 chipid_offset = 0, macnum = 0;

    maxfdp = swemu_mac_proxy.sock+1;

    for (;;)
    {
        FD_ZERO(&fds);

        FD_SET(swemu_mac_proxy.sock, &fds);

        timeout.tv_sec = SOCKET_TIME_OUT;
        timeout.tv_usec = 0;

        sock_selected = select(maxfdp, &fds, NULL, NULL, &timeout);
        if (-1 == sock_selected)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Selecting socket error!\n");
            continue;
        }

        if (0 == sock_selected)
        {
            continue;
        }


        if (swemu_mac_proxy.error_sock
            || !FD_ISSET(swemu_mac_proxy.sock, &fds)
            || !swemu_mac_proxy.valid)
        {
            continue;
        }

        len = recvfrom(swemu_mac_proxy.sock, buffer, PKT_BUFFER_SIZE, 0, 0, 0);
        if (len < 0)
        {
            CMODEL_DEBUG_OUT_INFO("Warning:: Failed to receive socket, chipid_offset=%d, macnum=%d \n", chipid_offset, macnum);
            continue;
        }

        ret = _swemu_decode_hb_header(buffer, &len, &macnum);
        if (ret < 0)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Packet length %d less than 48 Bytes!\n", len);
            continue;
        }

        /* stats macnum receive pkt num */
        g_pkt_cnt_rx[macnum]++;

        if (SW_BD_DEBUG_IS_ON(SWEMU_BOARD_DEBUG_PKT_RAW))
        {
            SW_BD_DEBUG_OUT("Chip Agent RX Packet length %d from port %d \n", len, macnum);
            _swemu_pkt_dump8(buffer + HUMBER_HEADER_LEN + HUMBER_CPUMAC_HDR_LEN, len, TRUE);
        }

        packet=(uint8 *)sal_malloc(MTU);
        if (!packet)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Memory is exhausted!\n");
            continue;
        }

        sal_memset(packet, 0, MTU);
        if (!sal_memcpy(packet, buffer + HUMBER_HEADER_LEN + HUMBER_CPUMAC_HDR_LEN, len))
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Error in sal_memcpy!\n");
            continue;
        }

        /* store received inpkt  from mac */
        ret = sim_asic_gen_macrx_inpkt(chipid_offset, packet, len, macnum);
        if (ret < DRV_E_NONE)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Store received packet process error!\n");
            continue;
        }

        ret = swemu_received_packet_process(packet, len, chipid_offset, macnum);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Received packet process error!\n");
            continue;
        }

        /* stats receive pkt count */
        ret = sim_asic_gen_rx_pkt_cnt(g_pkt_cnt_rx);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Pkt cnt error on rx direction!\n");
        }
    }
}

/***************************************************************************
 * Name:     swemu_send_packet_to_board
 * Purpose:
 * Parameters:
 * Input:      none
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
swemu_send_packet_to_board(void)
{
    out_pkt_t request;
    uint32 size = 0, mac_num = 0;
    bool discard = FALSE;
    int32 ret = DRV_E_NONE;
    uint32 chipid_offset = 0;
    uint8 buffer[PKT_BUFFER_SIZE]={0};
    int32 len = 0;
    uint32 to_cpu = FALSE;
    uint32 to_nettx = FALSE;
    uint32 cpu_mirror_port = 0;
    uint8* p_tmp_pkt = NULL;

    size = sizeof(request);
    sal_memset(&request, 0, sizeof(request));

    for (;;)
    {
        if (CTCKAL_SUCCESS != ctckal_queue_receive(sim_queue[SIM_NETTX_Q], (void *)&request, &size, QUE_TIMEOUT_INFINITE))
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Nettx engine receive input packet error!\n");
            continue;
        }

        chipid_offset = request.chip_id - drv_init_chip_info.drv_init_chipid_base;

        ret = g_sim_model[chipid_offset].chanid2macnum(request.chip_id, request.chan_id, &mac_num);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Mapping chanid to macnum error, chipid=%d, chanid =%d!\n",
                                   request.chip_id, request.chan_id);
            sal_free(request.pkt);
            request.pkt = NULL;
            sal_free(request.exception);
            request.exception = NULL;
            continue;
        }

        request.mac_num = mac_num;

        ret = g_sim_model[chipid_offset].mac_tx[mac_num](&request, &discard);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Mac transmit packet error, chipid=%d, mac num =%d!\n",
                                      request.chip_id, mac_num);
            sal_free(request.pkt);
            request.pkt = NULL;
            sal_free(request.exception);
            request.exception = NULL;
            continue;
        }

        if (discard)
        {
            sal_free(request.pkt);
            request.pkt = NULL;
            sal_free(request.exception);
            request.exception = NULL;
            continue;
        }

        /* store received pkt from mac */
        ret = sim_asic_gen_mactx_outpkt(request.chip_id, request.pkt, request.packet_length, request.chan_id);
        if (ret < DRV_E_NONE)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Store received packet process error!\n");
            continue;
        }
        
        to_cpu = to_cpu;
        to_nettx = FALSE;
        cpu_mirror_port = 0;

        if (CPU_MACNUM == mac_num)
        {
            to_cpu = TRUE;


            /* support CPU Port mirror to NETTX */
           #if 0
            cpu_mirror_port = chip_agent_get_cpu_mirror_port();
           #endif
            if (cpu_mirror_port)
            {
                to_nettx = TRUE;
                mac_num = cpu_mirror_port;
            }
        }
        else
        {
            to_nettx = TRUE;
        }

        /* append packet to 64 bytes */
        if (request.packet_length < CM_PKT_MIN_SIZE)
        {
            p_tmp_pkt = sal_malloc(CM_PKT_MIN_SIZE);
            sal_memset(p_tmp_pkt, 0, CM_PKT_MIN_SIZE);
            sal_memcpy(p_tmp_pkt, request.pkt, (request.packet_length - CRC_LEN));
            sal_free(request.pkt);
            request.pkt = p_tmp_pkt;
            request.packet_length = CM_PKT_MIN_SIZE;
        }

        #if 0
        if (to_cpu)
        {
            len = request.packet_length - CRC_LEN;
            ret = chip_agent_server_send_pkt(request.pkt, len, 1);  /* CTC_PKT_MODE_ETH */

            if (SW_BD_DEBUG_IS_ON(SWEMU_BOARD_DEBUG_PKT_RAW))
            {
                SW_BD_DEBUG_OUT("Chip Agent TX Packet length %d to CPU port %d \n", len, CPU_MACNUM);
                _swemu_pkt_dump8(request.pkt, len, TRUE);
            }
            g_pkt_cnt_tx[CPU_MACNUM]++;
        }
        #endif

        if (to_nettx)
        {
            len = request.packet_length - CRC_LEN;
            sal_memcpy(buffer + HUMBER_HEADER_LEN + HUMBER_CPUMAC_HDR_LEN, request.pkt, len);
            if (SW_BD_DEBUG_IS_ON(SWEMU_BOARD_DEBUG_PKT_RAW))
            {
                SW_BD_DEBUG_OUT("Chip Agent TX Packet length %d to port %d \n", len, mac_num);
                _swemu_pkt_dump8(buffer + HUMBER_HEADER_LEN + HUMBER_CPUMAC_HDR_LEN, len, TRUE);
            }
            _swemu_encode_hb_header(buffer, &len, mac_num);
            ret = send(swemu_mac_proxy.sock, buffer, len, 0);
            g_pkt_cnt_tx[mac_num]++;
        }

        if (ret < DRV_E_NONE)
        {
            sal_free(request.pkt);
            request.pkt = NULL;
            sal_free(request.exception);
            request.exception = NULL;
            continue;
        }

        sal_free(request.pkt);
        request.pkt = NULL;
        sal_free(request.exception);
        request.exception = NULL;

        ret = sim_asic_gen_tx_pkt_cnt(g_pkt_cnt_tx);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("CModelTestEVN ERROR! Pkt cnt error on tx direction!\n");
        }
    }
}

int32
swemu_socket_init_board(void)
{
    struct sockaddr_ll me;
    struct ifreq  ifr;
    int32 chipid_offset = 0, macnum = 0;
    char if_name[MAX_ETH_NAME_LEN] = {0};
    mac_descriptor_t *mac = NULL;

    sal_memset(if_name, 0, MAX_ETH_NAME_LEN);

    mac = &swemu_mac_proxy;
    mac->valid = (chipid_offset == 0 && macnum == 0) ? 1 : 0;

    if (!mac->valid)
    {
        return DRV_E_INIT_FAILED;
    }

    mac->sock = socket(PF_PACKET, SOCK_RAW, sal_htons(ETH_P_ALL));

    if (mac->sock < 0)
    {
        mac->error_sock = TRUE;
        return DRV_E_INIT_FAILED;
    }

    sal_snprintf(if_name, MAX_ETH_NAME_LEN, "eth%d", mac->eth_if_id);
    sal_memset(&ifr, 0, sizeof(struct ifreq));
    sal_strncpy(ifr.ifr_name, if_name, MAX_ETH_NAME_LEN);

    if (ioctl(mac->sock, SIOCGIFINDEX, &ifr, sizeof(struct ifreq)) < 0)
    {
        mac->error_sock = TRUE;
        CMODEL_DEBUG_OUT_INFO("Warning:: Failed to get the interface information of <%s>\n",
                                    if_name);
        return DRV_E_INIT_FAILED;
    }

    sal_memset(&me, 0, sizeof(struct sockaddr_ll));
    me.sll_family = AF_PACKET;
    me.sll_ifindex = ifr.ifr_ifindex;
    me.sll_pkttype = PACKET_OTHERHOST;

    if (bind(mac->sock, (struct sockaddr *)&me, sizeof(struct sockaddr_ll))<0)
    {
        CMODEL_DEBUG_OUT_INFO("Warning:: Failed to bind socket for chipid_offset %d mac: %d\n",
                                  chipid_offset, macnum);
        mac->error_sock = TRUE;
        return DRV_E_INIT_FAILED;
    }

    mac->error_sock = FALSE;

    return DRV_E_NONE;
}

