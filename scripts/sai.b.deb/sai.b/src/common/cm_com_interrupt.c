/****************************************************************************
 * cm_com_interrupt.c  cmodel interrupt simulation
 * Copyright:    (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     
 * Author:       
 * Date:         2012-11-15
 * Reason:       
 *
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/


/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/

static int32
_cm_com_interrupt_set_value(uint8 lchip, uint32 tbl_id, uint32 bit_offset, uint32 enable)
{
    uint32 cmd = 0;
    uint32 value[CM_INTR_STAT_SIZE];
    uint32 value_set[CM_INTR_STAT_SIZE];
    uint32 value_reset[CM_INTR_STAT_SIZE];

    CM_BMP_INIT(value);
    CM_BMP_INIT(value_set);
    CM_BMP_INIT(value_reset);
      
    if (enable)
    {
        /* trigger/set */
        /* 1. read value */
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(lchip, CM_INTR_INDEX_VAL_SET, cmd, value_set));
        DRV_IF_ERROR_RETURN(CM_IOCTL(lchip, CM_INTR_INDEX_VAL_RESET, cmd, value_reset));

        /* 2. do reset action */
        if (CM_INTR_ALL != bit_offset)
        {
            CM_BMP_SET(value, bit_offset);
            value_set[0] |= value[0];
            value_set[1] |= value[1];
            value_set[2] |= value[2];
        }

        /* 3. write value */
        cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(lchip, CM_INTR_INDEX_VAL_SET, cmd, value_set));
        DRV_IF_ERROR_RETURN(CM_IOCTL(lchip, CM_INTR_INDEX_VAL_RESET, cmd, value_set));
    }
    else
    {
        /* clear */
    }
    
    return DRV_E_NONE;
}

int32
cm_com_interrupt_set(uint8 lchip, uint32 enable, uint32 intr, uint32 sub_intr)
{
    uint32 tbl_id = 0;
    uint32 bit_offset = 0;
    
    if (CM_INTR_GB_CHIP_FATAL == intr)
    {
        /* GbSupInterruptFatal */
        return DRV_E_INVAILD_TYPE;
    }
    else if (CM_INTR_GB_CHIP_NORMAL == intr)
    {
        /* GbSupInterruptNormal */
        return DRV_E_INVAILD_TYPE;
    }
    else if (CM_INTR_GB_FUNC_PTP_TS_CAPTURE <= intr && CM_INTR_GB_FUNC_MET_LINK_SCAN_DONE >= intr)
    {
        /* GbSupInterruptFunction */
        tbl_id = GbSupInterruptFunction_t;
        bit_offset = intr - CM_INTR_GB_SUP_FUNC_BIT_BEGIN;
        return _cm_com_interrupt_set_value(lchip, tbl_id, bit_offset, enable);
    }
    else if (CM_INTR_GB_DMA_FUNC == intr)
    {
        /* PcieFuncIntr */
        tbl_id = PcieFuncIntr_t;
        bit_offset = sub_intr;
        return _cm_com_interrupt_set_value(lchip, tbl_id, bit_offset, enable);
    }
    else if (CM_INTR_GB_DMA_NORMAL == intr)
    {
        /* PciExpCoreInterruptNormal */
        return DRV_E_INVAILD_TYPE;
    }
    else if (CM_INTR_GB_PCIE_SECOND == intr)
    {
        /* PCIe Interrupt */
        return DRV_E_INVAILD_TYPE;
    }
    else if (CM_INTR_GB_PCIE_PRIMARY == intr)
    {
        /* PCIe Interrupt */
        return DRV_E_INVAILD_TYPE;
    }
    else
    {
        return DRV_E_INVAILD_TYPE;
    }

    return DRV_E_NONE;
}

extern uint8
_cm_sim_intr_engine(void);

uint32
cm_sim_intr_engine(void)
{
    return  _cm_sim_intr_engine();
}

