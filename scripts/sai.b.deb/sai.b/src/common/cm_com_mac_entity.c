/***************************************************************************
 * cm_com_mac_entity.c
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Revision:     V1.0.
 * Author:
 * Date:         2010-11-1.
 * Reason:       First Create.
 * Modify History:
****************************************************************************/

/***************************************************************************
 *
 * Header Files
 *
***************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "ctcutil_lib.h"
#include "cm_lib.h"

/***************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/
#if (SDK_WORK_PLATFORM==1)
/* ����cmodelʹ�ã���Ϊcmodel��ģ��PTP engine,��ͨ��cmodel cli����MacRx,MacTx,NextHopPtp����ץȡʱ����ֵ */
uint8 mac_rx_gen_ts[TIME_STAMP_LENGTH];
uint8 mac_tx_gen_ts[TIME_STAMP_LENGTH];
uint8 epe_nhp_ptp_gen_ts[TIME_STAMP_LENGTH];
uint8 ipe_oam_ptp_gen_ts[TIME_STAMP_LENGTH];

int32
get_ptp_engine_timestamp(ptp_engine_access_module_t access_module, bool ns_format, uint32 *msb, uint32 *lsb)
{
    uint8 *ts = NULL;
    uint64 ns = 1ULL;
    sal_systime_t tv;

    switch (access_module)
    {
        case PTP_ENGINE_ACCESS_MAC_RX:
            ts = mac_rx_gen_ts;
            break;
        case PTP_ENGINE_ACCESS_MAC_TX:
            ts = mac_tx_gen_ts;
            break;
        case PTP_ENGINE_ACCESS_EPE_NEXTHOP:
            ts = epe_nhp_ptp_gen_ts;
            break;
        case PTP_ENGINE_ACCESS_IPE_OAM:
            ts = ipe_oam_ptp_gen_ts;
            break;
        default:
            return -1;
    }

    sal_gettime(&tv);

    if (ns_format)
    {
        ns = MAKE_UINT32(ts[0], ts[1], ts[2], ts[3]) * 1000000000ULL + MAKE_UINT32(ts[4], ts[5], ts[6], ts[7]);

        if (UM_EMU_MODE_SDK == swemu_get_um_emu_mode())
        {
            ns = tv.tv_sec * 1000000000ULL + tv.tv_usec * 1000;
        }

        *msb = ns >> 32;
        *lsb = ns & 0xFFFFFFFF;
    }
    else
    {
        *msb = MAKE_UINT32(ts[0], ts[1], ts[2], ts[3]);
        *lsb = MAKE_UINT32(ts[4], ts[5], ts[6], ts[7]);

        if (UM_EMU_MODE_SDK == swemu_get_um_emu_mode())
        {
            *msb = tv.tv_sec;
            *lsb = tv.tv_usec * 1000;
        }
    }

    return 0;
}
#endif

/* mac statistics type */
enum stats_mac_rec_stats_type_e
{
    STATS_MAC_RCV_GOOD_UCAST,
    STATS_MAC_RCV_GOOD_MCAST,
    STATS_MAC_RCV_GOOD_BCAST,
    STATS_MAC_RCV_GOOD_NORMAL_PAUSE,
    STATS_MAC_RCV_GOOD_PFC_PAUSE,
    STATS_MAC_RCV_GOOD_CONTROL,
    STATS_MAC_RCV_FCS_ERROR,
    STATS_MAC_RCV_MAC_OVERRUN,
    STATS_MAC_RCV_GOOD_63B,
    STATS_MAC_RCV_BAD_63B,
    STATS_MAC_RCV_GOOD_1519B,
    STATS_MAC_RCV_BAD_1519B,
    STATS_MAC_RCV_GOOD_JUMBO,
    STATS_MAC_RCV_BAD_JUMBO,
    STATS_MAC_RCV_64B,
    STATS_MAC_RCV_127B,
    STATS_MAC_RCV_255B,
    STATS_MAC_RCV_511B,
    STATS_MAC_RCV_1023B,
    STATS_MAC_RCV_1518B,

    STATS_MAC_RCV_MAX
};
typedef enum stats_mac_rec_stats_type_e stats_mac_rec_stats_type_t;

enum stats_mac_send_stats_type_e
{
    STATS_MAC_SEND_UCAST = 0x14,
    STATS_MAC_SEND_MCAST,
    STATS_MAC_SEND_BCAST,
    STATS_MAC_SEND_PAUSE,
    STATS_MAC_SEND_CONTROL,
    STATS_MAC_SEND_FCS_ERROR,
    STATS_MAC_SEND_MAC_UNDERRUN,
    STATS_MAC_SEND_63B,
    STATS_MAC_SEND_64B,
    STATS_MAC_SEND_127B,
    STATS_MAC_SEND_255B,
    STATS_MAC_SEND_511B,
    STATS_MAC_SEND_1023B,
    STATS_MAC_SEND_1518B,
    STATS_MAC_SEND_1519B,
    STATS_MAC_SEND_JUMBO,

    STATS_MAC_SEND_MAX
};
typedef enum stats_mac_send_stats_type_e stats_mac_send_stats_type_t;

struct cpu_mac_da_tmp_s
{
   uint32 cpu_mac_da31_to0                                                :32;

   uint32 cpu_mac_da47_to32                                               :16;
   uint32 rsv_0                                                           :16;
};
typedef struct cpu_mac_da_tmp_s  cpu_mac_da_tmp_t;

/***************************************************************************
 *
 * Global and Declarations
 *
***************************************************************************/
extern sim_model_t g_sim_model[];
extern uint8 hg_plus_version;

/***************************************************************************
 *
 * Functions
 *
****************************************************************************/

/***************************************************************************
 * Name:        _sim_mac_append_crc
 * Purpose:     Count Packet CRC32, add into packet
 * Parameters:
 * Input:       packet -- packet pointer.
                packet_length -- packet length
 * Output:
 * Return:      DRV_E_NONE = success.
                Other = Error, please refer to DRV_E_XXX.
 * Note:        none.
****************************************************************************/
static int32
_sim_mac_append_crc(uint8 *packet, uint32 packet_length)
{
    uint32 data32;
    uint8 *p_crc32 = NULL;

    ctcutil_crc32(0xFFFFFFFF, packet, packet_length - 4, &data32);
    swap32(&data32, 1, HOST_TO_NETWORK);
    p_crc32 = packet + packet_length  - 4;
    memcpy_data(&p_crc32, &data32, 4);

    return DRV_E_NONE;
}

static uint16
_sim_mac_reclac_ip_checksum(uint16 old_u16, uint16 new_u16, uint16 old_chksum)
{
    uint32 sum = 0;
    uint16 new_sum = 0;

    sum = (~old_chksum) & 0xFFFF;

    sum = sum + (~old_u16 & 0xFFFF);
    sum = (sum >> 16) + (sum & 0xFFFF);

    sum = sum + new_u16;
    new_sum = (sum >> 16) + (sum & 0xFFFF);
    return (~new_sum);
}

#if 1
static void
_sim_mac_show_higig_header(int header_mode, void* header)
{
   if (header_mode)
   {
       cm_sgmac_plus_header_t *sgmac_plus_hdr = (cm_sgmac_plus_header_t *) header;
       CMODEL_DEBUG_OUT_INFO("\n--------------- higig plus info ---------------------\n");
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_start",          sgmac_plus_hdr->sgmac_plus_start          );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_hgi",            sgmac_plus_hdr->sgmac_plus_hgi            );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_mirror",         sgmac_plus_hdr->sgmac_plus_mirror         );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_ingress_tagged", sgmac_plus_hdr->sgmac_plus_ingress_tagged );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_pfm",            sgmac_plus_hdr->sgmac_plus_pfm            );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_vid_low",        sgmac_plus_hdr->sgmac_plus_vid_low        );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_vid_high",       sgmac_plus_hdr->sgmac_plus_vid_high       );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_cos",            sgmac_plus_hdr->sgmac_plus_cos            );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_cng",            sgmac_plus_hdr->sgmac_plus_cng            );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_src_pid",        sgmac_plus_hdr->sgmac_plus_src_pid        );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_src_modid",      sgmac_plus_hdr->sgmac_plus_src_modid      );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_opcode",         sgmac_plus_hdr->sgmac_plus_opcode         );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_l3",             sgmac_plus_hdr->sgmac_plus_l3             );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_dst_tgid",       sgmac_plus_hdr->sgmac_plus_dst_tgid       );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_dst_modid",      sgmac_plus_hdr->sgmac_plus_dst_modid      );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_dst_mod_5",      sgmac_plus_hdr->sgmac_plus_dst_mod_5      );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "sgmac_plus_dst_port",       sgmac_plus_hdr->sgmac_plus_dst_port       );
       CMODEL_DEBUG_OUT_INFO("--------------------------------------------------------\n");

   }
   else
   {
       cm_sgmac2_header_t *sgmac2_hdr = (cm_sgmac2_header_t *) header;
       CMODEL_DEBUG_OUT_INFO("\n--------------- higig 2 info ---------------------\n");
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_sop",             sgmac2_hdr->ppd_ty0.sgmac2_sop             );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_lbid",            sgmac2_hdr->ppd_ty0.sgmac2_lbid            );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_tc",              sgmac2_hdr->ppd_ty0.sgmac2_tc              );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_dp",              sgmac2_hdr->ppd_ty0.sgmac2_dp              );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_dst_tgid",        sgmac2_hdr->ppd_ty0.sgmac2_dst_tgid        );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_mcst",            sgmac2_hdr->ppd_ty0.sgmac2_mcst            );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_opcode",          sgmac2_hdr->ppd_ty0.sgmac2_opcode          );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_dst_modid_mgidh", sgmac2_hdr->ppd_ty0.sgmac2_dst_modid_mgidh );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_dst_port_mgidl",  sgmac2_hdr->ppd_ty0.sgmac2_dst_port_mgidl  );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_src_modid",       sgmac2_hdr->ppd_ty0.sgmac2_src_modid       );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_src_pid",         sgmac2_hdr->ppd_ty0.sgmac2_src_pid         );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_ppd_ty",          sgmac2_hdr->ppd_ty0.sgmac2_ppd_ty          );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_mirror",          sgmac2_hdr->ppd_ty0.sgmac2_mirror          );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_ingress_tagged",  sgmac2_hdr->ppd_ty0.sgmac2_ingress_tagged  );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_pfm",             sgmac2_hdr->ppd_ty0.sgmac2_pfm             );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_vid_low",         sgmac2_hdr->ppd_ty0.sgmac2_vid_low         );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_vid_high",        sgmac2_hdr->ppd_ty0.sgmac2_vid_high        );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty0.sgmac2_l3",              sgmac2_hdr->ppd_ty0.sgmac2_l3              );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_src_vp_high",     sgmac2_hdr->ppd_ty2.sgmac2_src_vp_high     );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_src_vp_low",      sgmac2_hdr->ppd_ty2.sgmac2_src_vp_low      );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_ppd_ty",          sgmac2_hdr->ppd_ty2.sgmac2_ppd_ty          );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_dest_vp_high",    sgmac2_hdr->ppd_ty2.sgmac2_dest_vp_high    );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_dest_vp_low",     sgmac2_hdr->ppd_ty2.sgmac2_dest_vp_low     );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_dst_modid_mgidh", sgmac2_hdr->ppd_ty2.sgmac2_dst_modid_mgidh );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_dst_port_mgidl",  sgmac2_hdr->ppd_ty2.sgmac2_dst_port_mgidl  );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_opcode",          sgmac2_hdr->ppd_ty2.sgmac2_opcode          );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_donot_learn",     sgmac2_hdr->ppd_ty2.sgmac2_donot_learn     );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_mirror",          sgmac2_hdr->ppd_ty2.sgmac2_mirror          );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_multi_point",     sgmac2_hdr->ppd_ty2.sgmac2_multi_point     );
       CMODEL_DEBUG_OUT_INFO("%-30s: 0x%x\n", "ppd_ty2.sgmac2_fwd_type",        sgmac2_hdr->ppd_ty2.sgmac2_fwd_type        );
       CMODEL_DEBUG_OUT_INFO("----------------------------------------------------\n");
   }

   return;
}
#endif

static int32
_sim_mac_higig_header_generation(out_pkt_t *indication)
{
    #if 1

    greatbelt_packet_header_t cm_packet_header;
    cm_sgmac_plus_header_t sgmac_plus_hdr;
    cm_sgmac2_header_t sgmac2_hdr;
    sgmac_ctl_t sgmac_ctl;
    //sgmac_cfg_t sgmac_cfg;
    uint32 cmd_ctl = 0;
   // uint32 cmd_cfg = 0;
    uint32 mcast_id = 0;
    uint32 sgmac_hdr_len = 0;

    ms_packet_header_t* bheader = sal_malloc(sizeof(ms_packet_header_t));
    if (NULL == bheader)
    {
        return DRV_E_NO_MEMORY;
    }

    switch(indication->chan_id) /* 52-55 is SGMAC support Higig, now 48 + 4, and the 4 sgmac support 13G bandwith */
    {
        case SGMAC_MIN_CHANID_SUPPORT_HIGIG:
            //cmd_cfg = DRV_IOR(Sgmac8CtlCfg_t, DRV_ENTRY_FLAG);
            cmd_ctl = DRV_IOR(SgmacCtl8_t, DRV_ENTRY_FLAG);
            break;
        case (SGMAC_MIN_CHANID_SUPPORT_HIGIG + 1):
            //cmd_cfg = DRV_IOR(Sgmac9CtlCfg_t, DRV_ENTRY_FLAG);
            cmd_ctl = DRV_IOR(SgmacCtl9_t, DRV_ENTRY_FLAG);
            break;
        case (SGMAC_MIN_CHANID_SUPPORT_HIGIG + 2):
            //cmd_cfg = DRV_IOR(Sgmac10CtlCfg_t, DRV_ENTRY_FLAG);
            cmd_ctl = DRV_IOR(SgmacCtl10_t, DRV_ENTRY_FLAG);
            break;
        case (SGMAC_MIN_CHANID_SUPPORT_HIGIG + 3):
            //cmd_cfg = DRV_IOR(Sgmac11CtlCfg_t, DRV_ENTRY_FLAG);
            cmd_ctl = DRV_IOR(SgmacCtl11_t, DRV_ENTRY_FLAG);
            break;
        default:
            CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! Invalid SGMac channel %d, only 52 - 55 channel support Higig!\n", indication->chan_id);
            return DRV_E_NONE;
    }

#if 0
    DRV_IF_ERROR_RETURN(CM_IOCTL(indication->chip_id, 0, cmd_cfg, &sgmac_cfg));
    /*
        if SgmacModeEn = 1,  <- software can not cfg, is pin
        1: Xaui+             <- Higig+ 12G
        2: Xaui2             <- Higig2 13G
        others: Normal       <- Normal is XG
        else
        Normal
    */
    if ((sgmac_cfg.sgmac_mode != 1) || (sgmac_cfg.sgmac_mode != 2))
    {
        return DRV_E_NONE;
    }
#endif

    /* get bridge header */
    sal_memcpy(bheader, indication->module_bus.packet_header, sizeof(ms_packet_header_t));
    DRV_IF_ERROR_RETURN(swap32((uint32*)bheader, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));
    sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));
    cm_gen_greatbelt_packet_header(bheader, &cm_packet_header, TRUE);

    sal_memset(&sgmac_plus_hdr, 0, sizeof(cm_sgmac_plus_header_t));
    sal_memset(&sgmac2_hdr, 0, sizeof(cm_sgmac2_header_t));

    DRV_IF_ERROR_RETURN(CM_IOCTL(indication->chip_id, 0, cmd_ctl, &sgmac_ctl));
    if (sgmac_ctl.version)  /* Higig+ */
    {
        sgmac_plus_hdr.sgmac_plus_start= 0xFB;
        sgmac_plus_hdr.sgmac_plus_hgi = sgmac_ctl.format;
        sgmac_plus_hdr.sgmac_plus_vid_low = sgmac_ctl.vlan_id&0xFF;
        sgmac_plus_hdr.sgmac_plus_vid_high = sgmac_ctl.vlan_id>>8;
        sgmac_plus_hdr.sgmac_plus_cos = indication->mac_msg.tc & 0x7;
        sgmac_plus_hdr.sgmac_plus_cng = indication->mac_msg.dp & 0x1;
        sgmac_plus_hdr.sgmac_plus_src_pid = sgmac_ctl.source_port;
        sgmac_plus_hdr.sgmac_plus_src_modid = sgmac_ctl.chip_id;

        if ((!cm_packet_header.mcast)
            && (cm_packet_header.dest_chip_id == sgmac_ctl.cpu_chip_id)
            && ((cm_packet_header.dest_id&0xFF) == sgmac_ctl.cpu_port)
            && sgmac_ctl.cpu_port_en)
        {
            sgmac_plus_hdr.sgmac_plus_opcode = 0;
        }
        else
        {
            sgmac_plus_hdr.sgmac_plus_opcode = cm_packet_header.mcast ? 3 : 1;
        }

        sgmac_plus_hdr.sgmac_plus_dst_tgid = sgmac_ctl.gid; /* means don't learning in egress chip */

        if (sgmac_plus_hdr.sgmac_plus_opcode == 3)  /* L2MC */
        {
            cm_packet_header.dest_id = (cm_packet_header.dest_id & 0x7FF) + (sgmac_ctl.l2_met_ptr_base & 0x7FF);
            sgmac_plus_hdr.sgmac_plus_dst_modid = (cm_packet_header.dest_id >> 5) & 0x1F;
            sgmac_plus_hdr.sgmac_plus_dst_mod_5 = (cm_packet_header.dest_id >> 10) & 0x1;
            sgmac_plus_hdr.sgmac_plus_dst_port = cm_packet_header.dest_id & 0x1F;
        }
        else                                        /* Unicast */
        {
            sgmac_plus_hdr.sgmac_plus_dst_modid = cm_packet_header.dest_chip_id;
            sgmac_plus_hdr.sgmac_plus_dst_port = cm_packet_header.dest_id & 0x1F;
        }
    }
    else                    /* Higig2 */
    {
        sgmac2_hdr.ppd_ty0.sgmac2_sop = 0xFB;
        sgmac2_hdr.ppd_ty0.sgmac2_mcst = cm_packet_header.mcast;
        sgmac2_hdr.ppd_ty0.sgmac2_tc = indication->mac_msg.tc & 0xF;
        sgmac2_hdr.ppd_ty0.sgmac2_dp = indication->mac_msg.dp & 0x3;
        sgmac2_hdr.ppd_ty0.sgmac2_lbid = (cm_packet_header.header_hash7_3 << 3)
                                           | cm_packet_header.header_hash2_0;
        sgmac2_hdr.ppd_ty0.sgmac2_dst_tgid = sgmac_ctl.gid;
        sgmac2_hdr.ppd_ty0.sgmac2_src_modid = sgmac_ctl.chip_id;
        sgmac2_hdr.ppd_ty0.sgmac2_src_pid = sgmac_ctl.source_port;

        if ((!cm_packet_header.mcast)
            && (cm_packet_header.dest_chip_id == sgmac_ctl.cpu_chip_id)
            && ((cm_packet_header.dest_id&0xFF) == sgmac_ctl.cpu_port)
            && sgmac_ctl.cpu_port_en)
        {
            sgmac2_hdr.ppd_ty0.sgmac2_opcode = 0;
        }
        else
        {
            sgmac2_hdr.ppd_ty0.sgmac2_opcode = cm_packet_header.mcast ? 3 : 1;
        }

        if (sgmac2_hdr.ppd_ty0.sgmac2_opcode == 3) /* L2MC */
        {
            mcast_id = (cm_packet_header.dest_id + sgmac_ctl.l2_met_ptr_base) & 0xFFFF;
            sgmac2_hdr.ppd_ty0.sgmac2_dst_modid_mgidh = (mcast_id >> 8) & 0xFF;
            sgmac2_hdr.ppd_ty0.sgmac2_dst_port_mgidl = mcast_id & 0xFF;

        }
        else
        {
            sgmac2_hdr.ppd_ty0.sgmac2_dst_modid_mgidh = cm_packet_header.dest_chip_id;
            sgmac2_hdr.ppd_ty0.sgmac2_dst_port_mgidl = cm_packet_header.dest_id&0xFF;
        }

        sgmac2_hdr.ppd_ty2.sgmac2_ppd_ty = sgmac_ctl.ppd_type;
        if (sgmac2_hdr.ppd_ty0.sgmac2_ppd_ty == 0)
        {
            sgmac2_hdr.ppd_ty0.sgmac2_dst_tgid = sgmac_ctl.gid;
            sgmac2_hdr.ppd_ty0.sgmac2_vid_high = sgmac_ctl.vlan_id >> 8;
            sgmac2_hdr.ppd_ty0.sgmac2_vid_low = (sgmac_ctl.vlan_id & 0xFF);
            sgmac2_hdr.ppd_ty0.sgmac2_l3 = 0;
        }
        else
        {
            sgmac2_hdr.ppd_ty2.sgmac2_donot_learn = sgmac_ctl.dont_learn;
        }
    }

    if (sgmac_ctl.version)
    {
        /* print the sgmac+ header for testing */
        _sim_mac_show_higig_header(sgmac_ctl.version, &sgmac_plus_hdr);

        /* replace packetHeader with Sgmac+Header */
        sgmac_hdr_len = CM_SGMAC_PLUS_HEADER_LEN;
        DRV_IF_ERROR_RETURN(swap32((uint32 *)&sgmac_plus_hdr, CM_SGMAC_PLUS_HEADER_LEN/4, HOST_TO_NETWORK));
    }
    else
    {
        /* print the sgmac2 header for testing */
        _sim_mac_show_higig_header(sgmac_ctl.version, &sgmac2_hdr);

        /* replace packetHeader with Sgmac2Header */
        sgmac_hdr_len = CM_SGMAC2_HEADER_LEN;
        DRV_IF_ERROR_RETURN(swap32((uint32 *)&sgmac2_hdr, CM_SGMAC2_HEADER_LEN/4, HOST_TO_NETWORK));
    }

    /* prepend SgmacHeader */
    sal_memmove(indication->pkt + sgmac_hdr_len, indication->pkt, indication->packet_length);

    if (sgmac_ctl.version)
    {
        sal_memcpy(indication->pkt, &sgmac_plus_hdr, sgmac_hdr_len);
    }
    else
    {
        sal_memcpy(indication->pkt, &sgmac2_hdr, sgmac_hdr_len);
    }

    indication->packet_length += sgmac_hdr_len;

    if (NULL != bheader)
    {
        sal_free(bheader);
        bheader = NULL;
    }

    #endif

    return DRV_E_NONE;
}


static int32
_sim_mac_tx_ptp_process(out_pkt_t *indication)
{
    uint8 *pkt = indication->pkt;
    //timestamp for PTP/DM etc
    //MacMessage.ptpOffset[7:0] indicates start of header for PTP/NTPv4/DM
    mac_message_type_t *mac_ms = &(indication->mac_msg);
    cm_uint64_t ptp_timestamp;
    cm_uint64_t current_timestamp, correction_field;
    uint16 new_l4_checksum = 0;
    uint8 ptp_edit_type = 0;

    sal_memset(&correction_field, 0, sizeof(correction_field));
    sal_memset(&current_timestamp, 0, sizeof(current_timestamp));
    sal_memset(&ptp_timestamp, 0, sizeof(ptp_timestamp));

    if (mac_ms->time_stamp_valid) /* PTP */
    {
        /* ptpTimeStamp[61:0] = GetTimestamp(); ns format if (ptpEditType[1:0] == 2'b11, else s+ns) */
        /* CModel MacTx's timestamp use fixed value because of no PTP engine */
        /* ns format if ptpEditType[1:0] == 2b'11,else s + ns */

        /* get from CLI: "cmodel set mactx ts TIMESTAMP" */
        GET_PTP_ENGINE_TIMESTAMP(PTP_ENGINE_ACCESS_MAC_TX, (mac_ms->ptp_edit_type == PTP_CORRECTION),
            &ptp_timestamp.high_63_32, &ptp_timestamp.low_31_0);

        ptp_edit_type = mac_ms->ptp_edit_type;
        if (!mac_ms->is_ptp_offset)  /* DM */
        {
            if (IS_BIT_SET(ptp_edit_type, 0))
            {
                current_timestamp.high_63_32 = (((mac_ms->timestamp.high_63_32&0x3FFFFFFF)<<2)
                       | (mac_ms->timestamp.low_31_0>>30)); /* [61:30] */
                current_timestamp.low_31_0 = (mac_ms->timestamp.low_31_0&0x3FFFFFFF); /* [29:0] */
            }
            else if (((ptp_timestamp.low_31_0&0x3FFFFFFF)
                +(mac_ms->timestamp.low_31_0 & 0xFFFF)) >= TIME_ONE_S_TO_NS) //ns to s carry
            {
                current_timestamp.high_63_32 = 1 + ptp_timestamp.high_63_32;
                current_timestamp.low_31_0 &= 0xC0000000;
                current_timestamp.low_31_0 |= ((ptp_timestamp.low_31_0 + (mac_ms->timestamp.low_31_0 & 0xFFFF) - TIME_ONE_S_TO_NS)&0x3FFFFFFF);
            }
            else
            {
                current_timestamp.high_63_32 = ptp_timestamp.high_63_32;
                current_timestamp.low_31_0 &= 0xC0000000;
                current_timestamp.low_31_0 |= ((ptp_timestamp.low_31_0 + (mac_ms->timestamp.low_31_0 & 0xFFFF))&0x3FFFFFFF);
            }

            CLEAR_BIT(current_timestamp.low_31_0, 30);
            CLEAR_BIT(current_timestamp.low_31_0, 31);

            ptp_edit_type = PTP_REPLACE_ONLY; /* is temp var ?? add by zhouw */
        }
        else if (ptp_edit_type != PTP_CORRECTION) /* PTPv1/v2 OC/BC */
        {
            if (((ptp_timestamp.low_31_0&0x3FFFFFFF)
                +(mac_ms->timestamp.low_31_0 & 0xFFFF)) >= TIME_ONE_S_TO_NS) //ns to s carry
            {
                current_timestamp.high_63_32 = 1 + ptp_timestamp.high_63_32;
                current_timestamp.low_31_0 &= 0xC0000000;
                current_timestamp.low_31_0 |= ((ptp_timestamp.low_31_0 + (mac_ms->timestamp.low_31_0 & 0xFFFF) - TIME_ONE_S_TO_NS)&0x3FFFFFFF);
            }
            else
            {
                current_timestamp.high_63_32 = ptp_timestamp.high_63_32;
                current_timestamp.low_31_0 &= 0xC0000000;
                current_timestamp.low_31_0 |= ((ptp_timestamp.low_31_0 + (mac_ms->timestamp.low_31_0 & 0xFFFF))&0x3FFFFFFF);
            }

            CLEAR_BIT(current_timestamp.low_31_0, 30);
            CLEAR_BIT(current_timestamp.low_31_0, 31);
        }
        else                                 /* PTPv2 TC */
        {
            current_timestamp = cm_sub64(ptp_timestamp, mac_ms->timestamp);
            CLEAR_BIT(current_timestamp.high_63_32, 30);
            CLEAR_BIT(current_timestamp.high_63_32, 31);
        }

        switch (ptp_edit_type)
        {
            //replace 8 bytes timestamp from MacMessage.timestampOffset[7:0] with currentTimeStamp[63:0]
            case PTP_CAPTURE_ONLY:
                //capture timestamp and store in register with {macMessage.ptpSequenceId[1:0], currentTimestamp};
                break;
            case PTP_REPLACE_ONLY:
                //capture timestamp and replace to packet from macMessage.timestampoffset[7:0];
                /*
                sal_memmove(pkt+mac_ms->timestamp_offset +8, pkt+mac_ms->timestamp_offset, packet_len-mac_ms->timestamp_offset);
                */
                pkt[mac_ms->timestamp_offset+7] = current_timestamp.low_31_0&0xFF;
                pkt[mac_ms->timestamp_offset+6] = (current_timestamp.low_31_0>>8)&0xFF;
                pkt[mac_ms->timestamp_offset+5] = (current_timestamp.low_31_0>>16)&0xFF;
                pkt[mac_ms->timestamp_offset+4] = (current_timestamp.low_31_0>>24)&0xFF;
                pkt[mac_ms->timestamp_offset+3] = current_timestamp.high_63_32&0xFF;
                pkt[mac_ms->timestamp_offset+2] = (current_timestamp.high_63_32>>8)&0xFF;
                pkt[mac_ms->timestamp_offset+1] = (current_timestamp.high_63_32>>16)&0xFF;
                pkt[mac_ms->timestamp_offset+0] = (current_timestamp.high_63_32>>24)&0xFF;
                break;
            case PTP_CORRECTION:
                //correction_field[63:0] = {currentTimeStamp[47:0], 16'd0};
                correction_field.low_31_0 = current_timestamp.low_31_0<<16;
                correction_field.high_63_32 = ((current_timestamp.high_63_32<<16) | (current_timestamp.low_31_0>>16));

                pkt[mac_ms->timestamp_offset+7] = correction_field.low_31_0&0xFF;
                pkt[mac_ms->timestamp_offset+6] = (correction_field.low_31_0>>8)&0xFF;
                pkt[mac_ms->timestamp_offset+5] = (correction_field.low_31_0>>16)&0xFF;
                pkt[mac_ms->timestamp_offset+4] = (correction_field.low_31_0>>24)&0xFF;
                pkt[mac_ms->timestamp_offset+3] = correction_field.high_63_32&0xFF;
                pkt[mac_ms->timestamp_offset+2] = (correction_field.high_63_32>>8)&0xFF;
                pkt[mac_ms->timestamp_offset+1] = (correction_field.high_63_32>>16)&0xFF;
                pkt[mac_ms->timestamp_offset+0] = (correction_field.high_63_32>>24)&0xFF;
                break;
            default: /* replace */

                break;
        }

        if (mac_ms->udp_ptp && (mac_ms->layer4_checksum != 0) && (mac_ms->frag_info1 == 0))
        {
            if (ptp_edit_type == PTP_CORRECTION)
            {
                //newL4Checksum = incrementChecksum(1'b1, correctionField[63:0], 0, macMessage.layer4Checksum[15:0);
                new_l4_checksum
                    = _sim_mac_reclac_ip_checksum(0, correction_field.low_31_0&0xFFFF, mac_ms->layer4_checksum);
                new_l4_checksum
                    = _sim_mac_reclac_ip_checksum(0, (correction_field.low_31_0>>16)&0xFFFF, new_l4_checksum);
                new_l4_checksum
                    = _sim_mac_reclac_ip_checksum(0, correction_field.high_63_32&0xFFFF, new_l4_checksum);
                new_l4_checksum
                    = _sim_mac_reclac_ip_checksum(0, (correction_field.high_63_32>>16)&0xFFFF, new_l4_checksum);

                //update 2 byte UDP Checksum from (macMessage.ptpOffset[7:0]-2)
                pkt[mac_ms->udp_check_sum_offset] = new_l4_checksum>>8;
                pkt[mac_ms->udp_check_sum_offset+1] = new_l4_checksum&0xFF;
            }
            else if (ptp_edit_type == PTP_REPLACE_ONLY)
            {
                //newL4Checksum = incrementChecksum(1'b1, currentTiemStamp[63:0], 0, macMessage.layer4Checksum[15:0);
                new_l4_checksum
                    = _sim_mac_reclac_ip_checksum(0, current_timestamp.low_31_0&0xFFFF, mac_ms->layer4_checksum);
                new_l4_checksum
                    = _sim_mac_reclac_ip_checksum(0, (current_timestamp.low_31_0>>16)&0xFFFF, new_l4_checksum);
                new_l4_checksum
                    = _sim_mac_reclac_ip_checksum(0, current_timestamp.high_63_32&0xFFFF, new_l4_checksum);
                new_l4_checksum
                    = _sim_mac_reclac_ip_checksum(0, (current_timestamp.high_63_32>>16)&0xFFFF, new_l4_checksum);

                //update 2 byte UDP Checksum from (macMessage.ptpOffset[7:0]-2)
                pkt[mac_ms->udp_check_sum_offset] = new_l4_checksum>>8;
                pkt[mac_ms->udp_check_sum_offset+1] = new_l4_checksum&0xFF;
            }
        }
    }

    /* CPU Mac index */
    /* TBD? need to confirm???? add by zhouw */

    return DRV_E_NONE;
}

static int32
_sim_mac_rx_ptp_process(out_pkt_t *indication)
{
    /* MAC_RX */
    tbls_id_t table_id = MaxTblId_t;
    uint32 cmd = 0;
    quad_mac_gmac0_ptp_cfg_t mac_ptp_cfg;
    sgmac_cfg_t sgmac_cfg;
    bool append_ts = FALSE;
    uint32 ns_ts_msb =0;
    uint32 ns_ts_lsb = 0;
    tbls_id_t qmac_id[SGMAC_MIN_CHANID] =
    {
         QuadMacGmac0PtpCfg0_t, QuadMacGmac1PtpCfg0_t, QuadMacGmac2PtpCfg0_t,QuadMacGmac3PtpCfg0_t,
         QuadMacGmac0PtpCfg1_t, QuadMacGmac1PtpCfg1_t, QuadMacGmac2PtpCfg1_t,QuadMacGmac3PtpCfg1_t,
         QuadMacGmac0PtpCfg2_t, QuadMacGmac1PtpCfg2_t, QuadMacGmac2PtpCfg2_t,QuadMacGmac3PtpCfg2_t,
         QuadMacGmac0PtpCfg3_t, QuadMacGmac1PtpCfg3_t, QuadMacGmac2PtpCfg3_t,QuadMacGmac3PtpCfg3_t,
         QuadMacGmac0PtpCfg4_t, QuadMacGmac1PtpCfg4_t, QuadMacGmac2PtpCfg4_t,QuadMacGmac3PtpCfg4_t,
         QuadMacGmac0PtpCfg5_t, QuadMacGmac1PtpCfg5_t, QuadMacGmac2PtpCfg5_t,QuadMacGmac3PtpCfg5_t,
         QuadMacGmac0PtpCfg6_t, QuadMacGmac1PtpCfg6_t, QuadMacGmac2PtpCfg6_t,QuadMacGmac3PtpCfg6_t,
         QuadMacGmac0PtpCfg7_t, QuadMacGmac1PtpCfg7_t, QuadMacGmac2PtpCfg7_t,QuadMacGmac3PtpCfg7_t,
         QuadMacGmac0PtpCfg8_t, QuadMacGmac1PtpCfg8_t, QuadMacGmac2PtpCfg8_t,QuadMacGmac3PtpCfg8_t,
         QuadMacGmac0PtpCfg9_t, QuadMacGmac1PtpCfg9_t, QuadMacGmac2PtpCfg9_t,QuadMacGmac3PtpCfg9_t,
         QuadMacGmac0PtpCfg10_t, QuadMacGmac1PtpCfg10_t, QuadMacGmac2PtpCfg10_t,QuadMacGmac3PtpCfg10_t,
         QuadMacGmac0PtpCfg11_t, QuadMacGmac1PtpCfg11_t, QuadMacGmac2PtpCfg11_t,QuadMacGmac3PtpCfg11_t
    };

    /* get from CLI: "cmodel set macrx ts TIMESTAMP" */
    GET_PTP_ENGINE_TIMESTAMP(PTP_ENGINE_ACCESS_MAC_RX, TRUE, &ns_ts_msb, &ns_ts_lsb);

    /* timeStamp for PTP/DM etc */
    // if (packetLength[13:0] < 14'd249) append timestamp[61:0] to packet, timestamp[61:0] ns
    /* waitting to confirm RTL registers ??? add by zhouw? */
    if (indication->chan_id < SGMAC_MIN_CHANID)     /* 1GMac */
    {
        /* RTL table ptp info: one group indluce 12 channel */
        table_id = qmac_id[indication->chan_id];
        sal_memset(&mac_ptp_cfg, 0, sizeof(mac_ptp_cfg));
        cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(indication->chip_id, 0, cmd, &mac_ptp_cfg));

        if (mac_ptp_cfg.gmac0_ptp_en)
        {
            append_ts = TRUE;
        }
    }
    else if ((indication->chan_id >= SGMAC_MIN_CHANID) /* SGMac */
        && (indication->chan_id <= SGMAC_MAX_CHANID))
    {
        table_id = SgmacCfg0_t + (indication->chan_id - SGMAC_MIN_CHANID);
        sal_memset(&sgmac_cfg, 0, sizeof(sgmac_cfg));
        cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(indication->chip_id, 0, cmd, &sgmac_cfg));

        if (sgmac_cfg.ptp_en)
        {
            append_ts = TRUE;
        }
    }

    if (append_ts)
    {
        if (indication->packet_length < 249) /* ֻ��С��249Bytes�ı��Ĳſ��ܻ��timestamp������CRC֮��8��Bytesλ�� */
        {
            indication->pkt[indication->packet_length+0] = (ns_ts_msb>>24)&0xFF;
            indication->pkt[indication->packet_length+1] = (ns_ts_msb>>16)&0xFF;
            indication->pkt[indication->packet_length+2] = (ns_ts_msb>>8)&0xFF;
            indication->pkt[indication->packet_length+3] = (ns_ts_msb>>0)&0xFF;
            indication->pkt[indication->packet_length+4] = (ns_ts_lsb>>24)&0xFF;
            indication->pkt[indication->packet_length+5] = (ns_ts_lsb>>16)&0xFF;
            indication->pkt[indication->packet_length+6] = (ns_ts_lsb>>8)&0xFF;
            indication->pkt[indication->packet_length+7] = (ns_ts_lsb>>0)&0xFF;
            indication->channelinfo_ptpen = TRUE;  /* IPEDecyptionAndParsing using */
            indication->packet_length += TIME_STAMP_LENGTH;
        }
    }
    return DRV_E_NONE;
}

/***************************************************************************
 * Name:       _sim_mac_cpu_rx
 * Purpose:    CPU Mac receive function.
 * Parameters:
 * Input:      indication -- indication pointer,
               discard -- discard pointer.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
               Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_mac_cpu_rx(out_pkt_t *indication, bool *discard)
{
    int32 cmd;
    cpu_mac_misc_ctl_t mac_misc_ctl;

    cmd = DRV_IOR(CpuMacMiscCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(indication->chip_id, 0, cmd, &mac_misc_ctl));

    /* Allocate memory for exception */
    indication->exception = sal_malloc(sizeof(greatbelt_exception_info_t));
    sal_memset(indication->exception, 0, (sizeof(greatbelt_exception_info_t)));
    if (NULL == indication->exception)
    {
        return DRV_E_NO_MEMORY;
    }

    if (mac_misc_ctl.ingress_remove_en)
    {
        /* strip cpu mac header */
        sal_memmove(indication->pkt, indication->pkt + GREAT_BELT_CPUMAC_HDR_LEN,
                    indication->packet_length - GREAT_BELT_CPUMAC_HDR_LEN);

        /* re-cal and append crc */
        sal_memcpy(indication->module_bus.packet_header, indication->pkt, GREAT_BELT_HEADER_LEN);
        sal_memmove(indication->pkt, indication->pkt + GREAT_BELT_HEADER_LEN,
                    indication->packet_length - GREAT_BELT_CPUMAC_HDR_LEN - GREAT_BELT_HEADER_LEN);
        indication->packet_length = indication->packet_length - GREAT_BELT_CPUMAC_HDR_LEN - GREAT_BELT_HEADER_LEN + CRC_LEN;
        _sim_mac_append_crc(indication->pkt, indication->packet_length);
        indication->channelinfo_ptpen = FALSE;
    }
    return DRV_E_NONE;
}


/***************************************************************************
 * Name:       _sim_mac_cpu_tx
 * Purpose:    CPU Mac transmit function.
 * Parameters:
 * Input:      indication -- indication pointer,
               discard -- discard pointer.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_mac_cpu_tx(out_pkt_t *indication, bool *discard)
{
    uint32 cmd;
    uint32 data32;
    uint16 data16;
    uint8 chip_id=0;
    uint32 cpu_mac_index = 0;
    uint8 *hdr_ptr = NULL;

    cpu_mac_sa_cfg_t macsa;
    cpu_mac_da_cfg_t macda;
    cpu_mac_da_tmp_t macda_tmp;
    cpu_mac_ctl_t macctl;
    //cpu_mac_type_t mactype;
    cpu_mac_misc_ctl_t mac_misc_ctl;
    cpu_mac_priority_map_t mac_pri_map;
    uint32 packet_length = 0;

    uint8 bheader[GREAT_BELT_HEADER_LEN] = {0};
    greatbelt_packet_header_t cm_packet_header;

    uint32 tpid = 0, vlanid = 0, cos = 0, cfi = 0, vlan_tag = 0;

    sal_memmove(indication->pkt + GREAT_BELT_HEADER_LEN, indication->pkt, indication->packet_length);
    sal_memcpy(indication->pkt, indication->module_bus.packet_header, sizeof(ms_packet_header_t));
    indication->packet_length += GREAT_BELT_HEADER_LEN;

    chip_id = indication->chip_id;
    sal_memcpy(bheader, indication->pkt, sizeof(ms_packet_header_t));
    DRV_IF_ERROR_RETURN(swap32((uint32*)bheader, GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));
    sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));
    cm_gen_greatbelt_packet_header((ms_packet_header_t *)bheader, &cm_packet_header, TRUE);

    cmd = DRV_IOR(CpuMacCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &macctl));

    /* CPU Mac selection */
    if ((cm_packet_header.operation_type == OPERATION_TYPE_OAM) && macctl.oam_cpu_select_en)
    {
        cmd = DRV_IOR(CpuMacCtl_t, CpuMacCtl_Index0_f+cm_packet_header.ip_sa_u.share3.oam_type);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &cpu_mac_index));
    }
    else
    {
        if (macctl.nexthop_ptr_bits_type)
        {
            cpu_mac_index = (cm_packet_header.next_hop_ptr>>14); // [15:14]
        }
        else
        {
            cpu_mac_index = (cm_packet_header.next_hop_ptr&0x3); // [1:0]
        }
    }

    cmd = DRV_IOR(CpuMacSaCfg_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &macsa));

    cmd = DRV_IOR(CpuMacDaCfg_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &macda));
    switch (cpu_mac_index&0x3)
    {
        case 0:
            macda_tmp.cpu_mac_da31_to0 = macda.cpu_mac0_da31_to0;
            macda_tmp.cpu_mac_da47_to32 = macda.cpu_mac0_da47_to32;
            break;
        case 1:
            macda_tmp.cpu_mac_da31_to0 = macda.cpu_mac1_da31_to0;
            macda_tmp.cpu_mac_da47_to32 = macda.cpu_mac1_da47_to32;
            break;
        case 2:
            macda_tmp.cpu_mac_da31_to0 = macda.cpu_mac2_da31_to0;
            macda_tmp.cpu_mac_da47_to32 = macda.cpu_mac2_da47_to32;
            break;
        default:
            macda_tmp.cpu_mac_da31_to0 = macda.cpu_mac3_da31_to0;
            macda_tmp.cpu_mac_da47_to32 = macda.cpu_mac3_da47_to32;
            break;
    }

    //cmd = DRV_IOR(CpuMacType_t, DRV_ENTRY_FLAG);
    //DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &mactype));

    /* CPU Mac Header Vlan tag cos.cfi, must consistend with IEEE802.3 */
    /* DMA ??? */
    tpid = macctl.tpid;
    vlanid = macctl.vlan_id;
    cmd = DRV_IOR(CpuMacPriorityMap_t, DRV_ENTRY_FLAG);
    /* index syncup with RTLV5.9 */
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, cm_packet_header.priority, cmd, &mac_pri_map));
    cos = mac_pri_map.cos;
    cfi = 0;
    vlan_tag = ((tpid<<16) | (cos<<13) | (cfi<<12) | vlanid);
    hdr_ptr = indication->pkt;

    cmd = DRV_IOR(CpuMacMiscCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &mac_misc_ctl));
    if (mac_misc_ctl.egress_add_en)
    {
        sal_memmove(indication->pkt + GREAT_BELT_CPUMAC_HDR_LEN, indication->pkt, indication->packet_length);
        indication->packet_length += GREAT_BELT_CPUMAC_HDR_LEN;

        data16 = macda_tmp.cpu_mac_da47_to32;
        DRV_IF_ERROR_RETURN(memcpy_data(&hdr_ptr, &data16, 2));

        data32 = macda_tmp.cpu_mac_da31_to0;
        DRV_IF_ERROR_RETURN(memcpy_data(&hdr_ptr, &data32, 4));

        data16 = macsa.cpu_mac_sa47_to32;
        DRV_IF_ERROR_RETURN(memcpy_data(&hdr_ptr, &data16, 2));

        data32 = macsa.cpu_mac_sa31_to0;
        DRV_IF_ERROR_RETURN(memcpy_data(&hdr_ptr, &data32, 4));

        /* insert {tpid[15:0], cos[2:0], 0, vlanId[11:0], etherType[15:0], cpuMacReserved[15:0]} after macSa */
        data32 = vlan_tag;
        DRV_IF_ERROR_RETURN(memcpy_data(&hdr_ptr, &data32, 4));

        data16 = macctl.ether_type;
        DRV_IF_ERROR_RETURN(memcpy_data(&hdr_ptr, &data16, 2));

        data16 = macctl.cpu_mac_reserved;
        DRV_IF_ERROR_RETURN(memcpy_data(&hdr_ptr, &data16, 2));

        /* debug information */
        CMODEL_DEBUG_OUT_INFO("================ CPU MACTX debugInfo:================ START\n");
        if (macctl.nexthop_ptr_bits_type)
        {
            CMODEL_DEBUG_OUT_INFO("********** cpuMacIndex = %d, Select nextHopPtr[17:16]\n", cpu_mac_index);
        }
        else
        {
            CMODEL_DEBUG_OUT_INFO("********** cpuMacIndex = %d, Select nextHopPtr[1:0]\n", cpu_mac_index);
        }
        CMODEL_DEBUG_OUT_INFO("********** cpuMacDA = 0x%04x%08x\n", macda_tmp.cpu_mac_da47_to32, macda_tmp.cpu_mac_da31_to0);
        CMODEL_DEBUG_OUT_INFO("********** cpuMacSA = 0x%04x%08x (FIXED)\n", macsa.cpu_mac_sa47_to32, macsa.cpu_mac_sa31_to0);
        CMODEL_DEBUG_OUT_INFO("********** vlanTag = 0x%08x\n", vlan_tag);
        CMODEL_DEBUG_OUT_INFO("********** Tpid = 0x%04x, cos = %d, cfi = %d, vid = 0x%03x\n", tpid, cos, cfi, vlanid);
        CMODEL_DEBUG_OUT_INFO("================ CPU MACTX debugInfo:================ END\n");
    }

    /* CPU MAC learning packet tail stripped to 64B */
    packet_length = (indication->packet_length-GREAT_BELT_CPUMAC_HDR_LEN-GREAT_BELT_HEADER_LEN);
    if ((cm_packet_header.next_hop_ptr == macctl.learning_nexthop_ptr)
        && macctl.learning_nexthop_ptr_en
        && (packet_length > 64))
    {
        indication->packet_length = GREAT_BELT_HEADER_LEN + GREAT_BELT_CPUMAC_HDR_LEN + 64;
    }

    _sim_mac_append_crc(indication->pkt, indication->packet_length);

    /* store to cpu pkt */
    DRV_IF_ERROR_RETURN(sim_output_packet(indication->pkt, indication->packet_length,
                                           indication->chip_id, indication->chan_id));

    return DRV_E_NONE;
}

/***************************************************************************
 * Name:       _sim_mac_1g_rx
 * Purpose:    1G Mac receive function.
 * Parameters:
 * Input:      indication -- indication pointer,
               discard -- discard pointer.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_mac_1g_rx(out_pkt_t *indication, bool *discard)
{
    *discard = FALSE;
    indication->channelinfo_ptpen = FALSE;

    /* append crc */
    indication->packet_length += CRC_LEN;
    _sim_mac_append_crc(indication->pkt, indication->packet_length);

    DRV_IF_ERROR_RETURN(_sim_mac_rx_ptp_process(indication));
    return DRV_E_NONE;
}


/***************************************************************************
 * Name:       _sim_mac_1g_tx
 * Purpose:    1G Mac transmit function.
 * Parameters:
 * Input:      indication -- indication pointer,
               discard -- discard pointer.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_mac_1g_tx(out_pkt_t *indication, bool *discard)
{
    *discard = FALSE;

    DRV_IF_ERROR_RETURN(_sim_mac_tx_ptp_process(indication));

    return DRV_E_NONE;
}


/***************************************************************************
 * Name:       _sim_mac_sg_rx
 * Purpose:    10G Mac receive function.
 * Parameters:
 * Input:      indication -- indication pointer,
               discard -- discard pointer.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_mac_sg_rx(out_pkt_t *indication, bool *discard)
{
    *discard = FALSE;
    indication->channelinfo_ptpen = FALSE;

    /* append crc */
    indication->packet_length += CRC_LEN;
    _sim_mac_append_crc(indication->pkt, indication->packet_length);

    DRV_IF_ERROR_RETURN(_sim_mac_rx_ptp_process(indication));

    return DRV_E_NONE;
}


/***************************************************************************
*
 * Name:       _sim_mac_sg_tx
 * Purpose:    10G Mac transmit function.
 * Parameters:
 * Input:      indication -- indication pointer,
               discard -- discard pointer.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.

****************************************************************************/
bool higig_en = FALSE;
static int32
_sim_mac_sg_tx(out_pkt_t *indication, bool *discard)
{
    *discard = FALSE;

    DRV_IF_ERROR_RETURN(_sim_mac_tx_ptp_process(indication));

    if (higig_en && (indication->chan_id >= SGMAC_MIN_CHANID_SUPPORT_HIGIG)
        && (indication->chan_id <= SGMAC_MAX_CHANID_SUPPORT_HIGIG)) /* fixed 52-55 */
    {
        DRV_IF_ERROR_RETURN(_sim_mac_higig_header_generation(indication));
    }

    return DRV_E_NONE;
}

/***************************************************************************
 * Name:       _sim_mac_interlaken_rx
 * Purpose:    interlaken Mac receive function.
 * Parameters:
 * Input:      indication -- indication pointer,
               discard -- discard pointer.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_mac_interlaken_rx(out_pkt_t *indication, bool *discard)
{
    uint16 channel_id = 0;

    /* get channelId(2B) info from packet */
    channel_id = indication->pkt[1];
    channel_id |= indication->pkt[0]<<8;
    sal_memmove(indication->pkt, indication->pkt+2, indication->packet_length-2);

    /*
    channel_id = indication->pkt[indication->packet_length+1];
    channel_id |= indication->pkt[indication->packet_length]<<8;
    */
    indication->packet_length -= 2;

    *discard = FALSE;

    indication->chan_id &= 0x80;
    indication->chan_id |= channel_id; /* {interLakenEn, 0, channelId[5:0]} */

    /* append crc */
    indication->packet_length += CRC_LEN;
    indication->channelinfo_ptpen = FALSE;
    _sim_mac_append_crc(indication->pkt, indication->packet_length);
    return DRV_E_NONE;
}

/***************************************************************************
*
 * Name:       _sim_mac_interlaken_tx
 * Purpose:    interlaken Mac transmit function.
 * Parameters:
 * Input:      indication -- indication pointer,
               discard -- discard pointer.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.

****************************************************************************/
static int32
_sim_mac_interlaken_tx(out_pkt_t *indication, bool *discard)
{
    uint32 cmd = 0;
    net_tx_int_lk_ctl_t nettx_intlken_ctl;
    uint16 channel_id = indication->chan_id;
    ms_packet_header_t packet_header;
    uint16 sub_chan_id = indication->module_bus.sub_chan_id;

    /* Greatbelt Bridge-Header */
    sal_memset(&packet_header, 0, sizeof(ms_packet_header_t));
    sal_memcpy(&packet_header, indication->pkt, sizeof(ms_packet_header_t));
    DRV_IF_ERROR_RETURN(swap32((uint32*)(&packet_header), GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));

    sal_memset(&nettx_intlken_ctl, 0, sizeof(nettx_intlken_ctl));
    cmd = DRV_IOR(NetTxIntLkCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(indication->chip_id, 0, cmd, &nettx_intlken_ctl));

    if (channel_id == INTERLAKEN_CHANID)
    {
         sub_chan_id = (1<<7|sub_chan_id);
    }
    else
    {
        return DRV_E_NONE;
    }

    /* add channelId(2B) info into packet 's front */
    sal_memmove(indication->pkt+2, indication->pkt, indication->packet_length);
    indication->pkt[0] = (sub_chan_id>>8)&1;
    indication->pkt[1] = sub_chan_id&0xFF;

    /* MAYBE add channelId(2B) info into packet 's tail(crc's front)
    indication->pkt[indication->packet_length] = (channel_id>>8)&1;
    indication->pkt[indication->packet_length+1] = channel_id&0xFF;
    */

    indication->packet_length += 2;

    /* recal packet CRC */
    _sim_mac_append_crc(indication->pkt, indication->packet_length);
    *discard = FALSE;

    return DRV_E_NONE;
}


/**************************************************************************
 * Name:        _sim_mac_macnum2chanid
 * Purpose:     map the macnum to chanid for humber
 * Parameters:
 * Input:       macnum
 * Output:      chanid.
 * Return:      DRV_E_NONE = success.
                Other = Error, please refer to DRV_E_XXX.
 * Note:        none.
****************************************************************************/
static int32
_sim_mac_macnum2chanid(uint8 chip_id, uint32 macnum, uint32 *chanid)
{
    uint32 cmd = 0;
    net_rx_channel_map_t netrx_chan_map;

    sal_memset(&netrx_chan_map, 0, sizeof(netrx_chan_map));

    if (macnum < MAX_NETMAC_NUM)
    {
        cmd = DRV_IOR(NetRxChannelMap_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, macnum, cmd, &netrx_chan_map));

        *chanid = netrx_chan_map.chan_id;
    }
    else if (macnum == INTERLAKEN_MACNUM)
    {
        //SET_BIT(*chanid, 7); /* ChannelInfo.interLakenEn = 1 */
    }
    else if(macnum == CPU_MACNUM)
    {
        cmd = DRV_IOR(BufRetrvChanIdCfg_t, BufRetrvChanIdCfg_CfgCpuChanIdInt_f);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, chanid));
    }
    else
    {
        return DRV_E_INVALID_PARAMETER;
    }

    return DRV_E_NONE;
}


/***************************************************************************
 * Name:       _sim_mac_chanid2macnum
 * Purpose:    map the chanid to macnum for humber
 * Parameters:
 * Input:      macnum
 * Output:     chanid.
 * Return:     DRV_E_NONE = success.
               Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_sim_mac_chanid2macnum(uint8 chip_id, uint32 chanid, uint32 *macnum)
{
    uint32 cmd = 0;
    net_tx_chan_id_map_t nettx_chan_map;
    buf_retrv_chan_id_cfg_t buf_retrv_chan_id_cfg;

    sal_memset(&buf_retrv_chan_id_cfg, 0, sizeof(buf_retrv_chan_id_cfg_t));
    sal_memset(&nettx_chan_map, 0, sizeof(nettx_chan_map));

    cmd = DRV_IOR(BufRetrvChanIdCfg_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &buf_retrv_chan_id_cfg));

    if ((chanid == buf_retrv_chan_id_cfg.cfg_cpu_chan_id_int)
        ||(chanid == buf_retrv_chan_id_cfg.cfg_dma_chan_id_int))
    {
        *macnum = CPU_MACNUM;
    }
    else if(chanid == buf_retrv_chan_id_cfg.cfg_int_lk_chan_id_int)
    {
        *macnum = INTERLAKEN_MACNUM;
    }
    else if (chanid < MAX_CHANID)
    {
        cmd = DRV_IOR(NetTxChanIdMap_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, chanid, cmd, &nettx_chan_map));
       *macnum = nettx_chan_map.port_id;
    }
    else
    {
        return DRV_E_INVALID_PARAMETER;
    }

    return DRV_E_NONE;
}

/* macRx stats */
static int32
_sim_mac_stats_receive(out_pkt_t *npkt)
{
    uint32 mtu1 = 1518, mtu2 = 1536;
    uint8 stats_type, chip_id, chan_id;
    uint32 stats_base = 0, stats_offset = 0;
    uint8 *pkt = npkt->pkt;
    uint8 mac_da[6] = {0};
    bool is_mcast_pkt = FALSE, is_bcast_pkt = FALSE, is_ucast_pkt = FALSE, is_oam_mac = FALSE, is_oam = FALSE;

    mac_da[5] = pkt[0];
    mac_da[4] = pkt[1];
    mac_da[3] = pkt[2];
    mac_da[2] = pkt[3];
    mac_da[1] = pkt[4];
    mac_da[0] = pkt[5];

    chip_id = npkt->chip_id;
    chan_id = npkt->chan_id;

    if (chan_id < SGMAC_MIN_CHANID)  /* GMAC */
    {
        stats_type = CM_STATS_RAM0_1G + chan_id/4;
        stats_base = (chan_id % 4) * 36;

        //tbl_id = QuadMacStatsCfg0_t + chan_id/4;

        //cmd = DRV_IOR(tbl_id, QuadMacStatsCfg_PacketLenMtu1_f);
        //DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &mtu1));

        //cmd = DRV_IOR(tbl_id, QuadMacStatsCfg_PacketLenMtu2_f);
        //DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &mtu2));
    }
    else if (chan_id >= SGMAC_MIN_CHANID && chan_id <= SGMAC_MAX_CHANID) /* SGMac */
    {
        stats_type = CM_STATS_RAM0_10G + (chan_id - 48);
        stats_base = 0;
    }
    else if (chan_id == CPU_CHANID)/* CPUMacRx stats??? TBD, check it */
    {
        stats_type = CM_STATS_CPU_MAC;
        stats_base = 0;
    }
    else if (IS_BIT_SET(chan_id, 7)) /* Interlaken (per-channel stats)  */
    {
        stats_type = CM_STATS_INTERLAKEN_RX_MAC;
        stats_base = chan_id & 0x3F;
        DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, stats_type, stats_base, npkt->packet_length));

        return DRV_E_NONE;
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! Invalid channel ID! channel ID = %d \n", chan_id);
        return DRV_E_INVALID_CHANID;
    }

    /* write packetLen mac stats */
    if (npkt->packet_length < 64)
    {
        stats_offset = STATS_MAC_RCV_GOOD_63B;
    }
    else if (npkt->packet_length == 64)
    {
        stats_offset = STATS_MAC_RCV_64B;
    }
    else if (npkt->packet_length <= 127)
    {
        stats_offset = STATS_MAC_RCV_127B;
    }
    else if (npkt->packet_length <= 255)
    {
        stats_offset = STATS_MAC_RCV_255B;
    }
    else if (npkt->packet_length <= 511)
    {
        stats_offset = STATS_MAC_RCV_511B;
    }
    else if (npkt->packet_length <= 1023)
    {
        stats_offset = STATS_MAC_RCV_1023B;
    }
    else if (npkt->packet_length <= mtu1)
    {
        stats_offset = STATS_MAC_RCV_1518B;
    }
    else if ((npkt->packet_length > mtu1) && (npkt->packet_length <= mtu2))
    {
        stats_offset = STATS_MAC_RCV_GOOD_1519B;
    }
    else /* jumbo pkt */
    {
        stats_offset = STATS_MAC_RCV_GOOD_JUMBO;
    }

    DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, stats_type, stats_base+stats_offset, npkt->packet_length));

    /* Mac stats according pkt type */
    is_bcast_pkt = ((0xFF == mac_da[5]) && (0xFF == mac_da[4]) && (0xFF == mac_da[3])
                    && (0xFF == mac_da[2]) && (0xFF == mac_da[1]) && (0xFF == mac_da[0]));

    is_mcast_pkt = ((mac_da[5] & 0x01) && (!is_bcast_pkt));

    is_oam_mac = ((0x01 == mac_da[5]) && (0x80 == mac_da[4]) && (0xC2 == mac_da[3])
                    && (0 == mac_da[2]) && (0 == mac_da[1]) && (0x02 == mac_da[0]));

    is_oam = is_oam_mac && (pkt[12] == 0x88) && (pkt[13] == 0x09) && (pkt[14] == 0x03);

    is_ucast_pkt = ((!is_bcast_pkt) && (!is_mcast_pkt));

    if (is_ucast_pkt)
    {
        stats_offset = STATS_MAC_RCV_GOOD_UCAST;
    }
    else if (is_mcast_pkt)
    {
        stats_offset = STATS_MAC_RCV_GOOD_MCAST;
    }
    else if (is_bcast_pkt)
    {
        stats_offset = STATS_MAC_RCV_GOOD_BCAST;
    }

    DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, stats_type, stats_base+stats_offset, npkt->packet_length));

    return DRV_E_NONE;
}

/* macTx stats */
static int32
_sim_mac_stats_transmit(out_pkt_t *npkt)
{
    uint32 mtu1 = 1518, mtu2 = 1536;
    uint8 stats_type, chip_id, chan_id;
    uint32 stats_base = 0, stats_offset = 0;
    uint8 *pkt = npkt->pkt;
    uint8 mac_da[6] = {0};
    bool is_mcast_pkt = FALSE, is_bcast_pkt = FALSE, is_ucast_pkt = FALSE, is_oam_mac = FALSE, is_oam = FALSE;

    mac_da[5] = pkt[0];
    mac_da[4] = pkt[1];
    mac_da[3] = pkt[2];
    mac_da[2] = pkt[3];
    mac_da[1] = pkt[4];
    mac_da[0] = pkt[5];

    chip_id = npkt->chip_id;
    chan_id = npkt->chan_id;

    if (chan_id < SGMAC_MIN_CHANID)  /* GMAC */
    {
        stats_type = CM_STATS_RAM0_1G + chan_id/4;
        stats_base = (chan_id % 4) * 36;
    }
    else if (chan_id >= SGMAC_MIN_CHANID && chan_id <= SGMAC_MAX_CHANID) /* SGMac */
    {
        stats_type = CM_STATS_RAM0_10G + (chan_id - SGMAC_MIN_CHANID);
        stats_base = 0;
    }
    else if (chan_id == CPU_CHANID) /* CPUMacTx stats??? TBD, check!! */
    {
        stats_type = CM_STATS_CPU_MAC;
        stats_base = 0;
    }
    else if (chan_id == INTERLAKEN_CHANID) /* Interlaken (per-channel stats)  */
    {
        stats_type = CM_STATS_INTERLAKEN_TX_MAC;
        stats_base = chan_id & 0x3F;
        DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, stats_type, stats_base, npkt->packet_length));

        return DRV_E_NONE;
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! Invalid channel ID! channel ID = %d \n", chan_id);
        return DRV_E_INVALID_CHANID;
    }

    /* write packetLen mac stats */
    if (npkt->packet_length < 64)
    {
        stats_offset = STATS_MAC_SEND_63B;
    }
    else if (npkt->packet_length == 64)
    {
        stats_offset = STATS_MAC_SEND_64B;
    }
    else if (npkt->packet_length <= 127)
    {
        stats_offset = STATS_MAC_SEND_127B;
    }
    else if (npkt->packet_length <= 255)
    {
        stats_offset = STATS_MAC_SEND_255B;
    }
    else if (npkt->packet_length <= 511)
    {
        stats_offset = STATS_MAC_SEND_511B;
    }
    else if (npkt->packet_length <= 1023)
    {
        stats_offset = STATS_MAC_SEND_1023B;
    }
    else if (npkt->packet_length <= mtu1)
    {
        stats_offset = STATS_MAC_SEND_1518B;
    }
    else if ((npkt->packet_length > mtu1) && (npkt->packet_length <= mtu2))
    {
        stats_offset = STATS_MAC_SEND_1519B;
    }
    else /* jumbo pkt */
    {
        stats_offset = STATS_MAC_SEND_JUMBO;
    }

    DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, stats_type, stats_base+stats_offset, npkt->packet_length));

    /* Mac stats according pkt type */
    is_bcast_pkt = ((0xFF == mac_da[5]) && (0xFF == mac_da[4]) && (0xFF == mac_da[3])
                    && (0xFF == mac_da[2]) && (0xFF == mac_da[1]) && (0xFF == mac_da[0]));

    is_mcast_pkt = ((mac_da[5] & 0x01) && (!is_bcast_pkt));

    is_ucast_pkt = ((!is_bcast_pkt) && (!is_mcast_pkt));

    is_oam_mac = ((0x01 == mac_da[5]) && (0x80 == mac_da[4]) && (0xC2 == mac_da[3])
                    && (0 == mac_da[2]) && (0 == mac_da[1]) && (0x02 == mac_da[0]));

    is_oam = is_oam_mac && (pkt[12] == 0x88) && (pkt[13] == 0x09) && (pkt[14] == 0x03);

    is_ucast_pkt = ((!is_bcast_pkt) && (!is_mcast_pkt));

    if (is_ucast_pkt)
    {
        stats_offset = STATS_MAC_SEND_UCAST;
    }
    else if (is_mcast_pkt)
    {
        stats_offset = STATS_MAC_SEND_MCAST;
    }
    else if (is_bcast_pkt)
    {
        stats_offset = STATS_MAC_SEND_BCAST;
    }

    DRV_IF_ERROR_RETURN(sim_increase_statistics(chip_id, stats_type, stats_base+stats_offset, npkt->packet_length));

    return DRV_E_NONE;
}


/***************************************************************************
 * Name:      sim_mac_install
 * Purpose:    install mac for chip humber
 * Parameters:
 * Input:      chip_id_offset.
 * Output:     none.
 * Return:     DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
sim_mac_install(uint32 chip_id_offset)
{
    uint32 i;

    g_sim_model[chip_id_offset].chanid2macnum = _sim_mac_chanid2macnum;
    g_sim_model[chip_id_offset].macnum2chanid = _sim_mac_macnum2chanid;

    for (i = MIN_1G_MACNUM; i <= MAX_1G_MACNUM; i ++)
    {
        g_sim_model[chip_id_offset].mac_rx[i] = _sim_mac_1g_rx;
        g_sim_model[chip_id_offset].mac_tx[i] = _sim_mac_1g_tx;
    }

    for (i = MIN_SG_MACNUM; i <= MAX_SG_MACNUM; i ++)
    {
        g_sim_model[chip_id_offset].mac_rx[i] = _sim_mac_sg_rx;
        g_sim_model[chip_id_offset].mac_tx[i] = _sim_mac_sg_tx;
    }

    g_sim_model[chip_id_offset].mac_rx[CPU_MACNUM] = _sim_mac_cpu_rx;
    g_sim_model[chip_id_offset].mac_tx[CPU_MACNUM] = _sim_mac_cpu_tx;

    g_sim_model[chip_id_offset].mac_rx[INTERLAKEN_MACNUM] = _sim_mac_interlaken_rx;
    g_sim_model[chip_id_offset].mac_tx[INTERLAKEN_MACNUM] = _sim_mac_interlaken_tx;

    g_sim_model[chip_id_offset].mac_stats_receive = _sim_mac_stats_receive;
    g_sim_model[chip_id_offset].mac_stats_transmit = _sim_mac_stats_transmit;

    return DRV_E_NONE;
}

