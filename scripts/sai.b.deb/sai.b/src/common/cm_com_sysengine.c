/***************************************************************************
 * cm_com_systimer.c  provides timer of interrupt, aging, etc. for system simulation.
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Revision:     V1.0.
 * Author:       kcao.
 * Date:         2012-12-20.
 * Reason:       First Create.
 *
 * Modify History:
****************************************************************************/
/***************************************************************************
 *
 * Header Files
 *
***************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "ctcutil_lib.h"
#include "cm_lib.h"

/***************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/

extern void
cm_sim_aging_engine();
extern uint32
chip_agent_get_mode();

/***************************************************************************
 *
 * Global and Declarations
 *
***************************************************************************/
enum cm_sys_thread_type_e
{
    SIM_SYS_INTR_T,
    SIM_SYS_DMA_T,
    SIM_SYS_AGING_T,
    SIM_SYS_MAX_T,
};
typedef enum cm_sys_thread_type_e cm_sys_thread_type_t;

typedef int32 (*CM_INTR_CALLBACK)(uint32);

static ctckal_thread_t sim_sys_thread[SIM_SYS_MAX_T] = {0};
static CM_INTR_CALLBACK g_sim_intr_cb = NULL;

/***************************************************************************
*
*
* Functions
*
****************************************************************************/

static int32
_cm_sim_intr_get_intr_status(uint8 lchip, uint32 bmp[1])
{
    uint32 cmd = 0;
    uint32 index = 0; /* INTR_INDEX_VAL_SET */
    uint32 value[3];

    CM_BMP_INIT(bmp);

    /* 1. get gb_sup_interrupt_fatal_t */
    CM_BMP_INIT(value);
    cmd = DRV_IOR(GbSupInterruptFatal_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(sim_ioctl(lchip, index, cmd, &value));
    if (value[0] || value[1])
    {
        CM_BMP_SET(bmp, CM_INTR_GB_CHIP_FATAL);
    }

    /* 2. get gb_sup_interrupt_normal_t */
    CM_BMP_INIT(value);
    cmd = DRV_IOR(GbSupInterruptNormal_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(sim_ioctl(lchip, index, cmd, &value));
    if (value[0] || value[1] || value[2])
    {
        CM_BMP_SET(bmp, CM_INTR_GB_CHIP_NORMAL);
    }

    /* 3. get gb_sup_interrupt_function_t */
    CM_BMP_INIT(value);
    cmd = DRV_IOR(GbSupInterruptFunction_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(sim_ioctl(lchip, index, cmd, &value));
    if (value[0])
    {
        bmp[0] |= (value[0] << CM_INTR_GB_FUNC_PTP_TS_CAPTURE);
    }

    /* 4. get pcie_func_intr_t */
    CM_BMP_INIT(value);
    cmd = DRV_IOR(PcieFuncIntr_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(sim_ioctl(lchip, index, cmd, &value));
    if (value[0])
    {
        CM_BMP_SET(bmp, CM_INTR_GB_DMA_FUNC);
    }

    /* 5. get pci_exp_core_interrupt_normal_t */
    CM_BMP_INIT(value);
    cmd = DRV_IOR(PciExpCoreInterruptNormal_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(sim_ioctl(lchip, index, cmd, &value));
    if (value[0] || value[1])
    {
        CM_BMP_SET(bmp, CM_INTR_GB_DMA_NORMAL);
    }

    /* PCIe Pri/Sec is TODO */

    return DRV_E_NONE;
}

uint8
_cm_sim_intr_engine(void)
{
    uint32 bmp[1];
    uint8 lchip = 0;
    int32 ret = 0;

    interrupt_map_ctl_t map_ctl;
    uint32 cmd = 0;
    uint32 tbl_id = 0;
    uint32 group_id = 0;
    uint8  chip_num = 0;
    uint8 intr_occur = 0;

    sal_memset(&map_ctl, 0, sizeof(map_ctl));

    tbl_id = tbl_id;
    tbl_id = InterruptMapCtl_t;
    cmd = DRV_IOR(InterruptMapCtl_t, DRV_ENTRY_FLAG);

    drv_get_chipnum(&chip_num);

    sal_memset(bmp, 0, sizeof(bmp));
    for (lchip = 0; lchip < chip_num; lchip++)
    {
        ret = _cm_sim_intr_get_intr_status(lchip, bmp);
        if (ret < 0)
        {
            continue;
        }

        if (bmp[0])
        {
            ret = sim_ioctl(lchip, 0, cmd, &map_ctl);
            if (ret < 0)
            {
                continue;
            }
            if (map_ctl.sup_intr_map0 & bmp[0])
            {
                group_id = 0;
                intr_occur = 1;
            }
            else if (map_ctl.sup_intr_map1 & bmp[0])
            {
                group_id = 1;
                intr_occur = 1;
            }
            else if (map_ctl.sup_intr_map2 & bmp[0])
            {
                group_id = 2;
                intr_occur = 1;
            }
            else if (map_ctl.sup_intr_map3 & bmp[0])
            {
                group_id = 3;
                intr_occur = 1;
            }
            else if (map_ctl.sup_intr_map4 & bmp[0])
            {
                group_id = 4;
                intr_occur = 1;
            }
            else if (map_ctl.sup_intr_map5 & bmp[0])
            {
                group_id = 5;
                intr_occur = 1;
            }
            else
            {
                continue;
            }

        }

    }
    return (intr_occur)?group_id:0xff;
}

int32
cm_com_intr_register_cb(CM_INTR_CALLBACK cb)
{
    g_sim_intr_cb = cb;

    return DRV_E_NONE;
}

/***************************************************************************
 * Name:       cm_com_sysengine_enable
 * Purpose:    initialize engines for system simulation
 * Parameters:
 * Input:      enable -- TRUE = enable, and FALSE = disable.
 * Output:     N/A.
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
*****************************************************************************/
int32
cm_com_sysengine_enable(uint8 enable)
{
#ifdef CMODEL_WITH_AGENT
    uint32 chip_agent_mode = chip_agent_get_mode();
#endif
    uint32 attr = 0;
    uint32 i = 0;

#ifdef CMODEL_WITH_AGENT
    if (1 == chip_agent_mode)   /* CHIP_AGT_MODE_CLIENT : client need not start CM SIM engine */
    {
        return DRV_E_NONE;
    }
#endif

    if (enable)
    {
        if (0 == sim_sys_thread[SIM_SYS_INTR_T])
        {
            DRV_IF_ERROR_RETURN(ctckal_thread_create(&sim_sys_thread[SIM_SYS_INTR_T], (void*)&attr,
                                            _cm_sim_intr_engine, NULL));
        }

        if (0 == sim_sys_thread[SIM_SYS_DMA_T])
        {
            DRV_IF_ERROR_RETURN(ctckal_thread_create(&sim_sys_thread[SIM_SYS_DMA_T], (void*)&attr,
                                            cm_sim_dma_engine, NULL));
        }

        if (0 == sim_sys_thread[SIM_SYS_AGING_T])
        {
            DRV_IF_ERROR_RETURN(ctckal_thread_create(&sim_sys_thread[SIM_SYS_AGING_T], (void*)&attr,
                                            cm_sim_aging_engine, NULL));
        }
    }
    else
    {
        for (i = 0; i < SIM_MAX_T; i ++)
        {
            ctckal_thread_destroy(sim_sys_thread[i]);
            sim_sys_thread[i] = 0;
        }
    }

    return DRV_E_NONE;
}


