/****************************************************************************
 * sim_util.c    Useful untilities for all modules.
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       JiangJf
 * Date:         2010-07-08.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "ctcutil_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
#define MAX_PKT_FILE_NAME_SIZE 256

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/

/* cmodel debug on or off */
bool cmodel_debug_on = FALSE;
bool cmodel_internal_output = FALSE;
bool ctc_cmodel_debug_on = FALSE;
uint32 ctc_cmodel_debug_flag = 0x00;

CMODEL_DEBUG_OUT_CALLBACK cmodel_debug_cb = NULL;



/* global chip allocation status */
per_chip_allocate_status_t per_chip_allocate_status;

static char pkt_file_name[MAX_PKT_FILE_NAME_SIZE];
static char oam_pkt_file_name[MAX_PKT_FILE_NAME_SIZE];
static char file_compare_result[MAX_PKT_FILE_NAME_SIZE];
static char file_tbl_chk_result[MAX_PKT_FILE_NAME_SIZE];
static char file_discard_check_result[MAX_PKT_FILE_NAME_SIZE];
static char file_no_discard_check_result[MAX_PKT_FILE_NAME_SIZE];
static char file_tbl_isnull_check_result[MAX_PKT_FILE_NAME_SIZE];

struct outpkt_s
{
    list_head_t   head;
    uint8        *pkt;
    uint32      chan_id;
    uint32      chip_id;
    uint32      packet_length;
};
typedef struct outpkt_s outpkt_t;

/* use for store ipe and epe process's discard type information in Cmodel */
struct cm_discard_type_status_s
{
    uint32 ipe_discard_type;
    uint32 epe_discard_type;
};
typedef struct cm_discard_type_status_s cm_discard_type_status_t;

extern list_head_t oam_output_pkt_list;

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/


bool
ctc_cmodel_debug_check_flag(uint32 typeenum)
{
    if(0 == ctc_cmodel_debug_on)
    {
       return FALSE;
    }

    if(ctc_cmodel_debug_flag & (typeenum))
    {
        return TRUE;
    }
    return FALSE;
}

void
sim_cmodel_debug_show_tcam_tbl(tbls_id_t tcam_tbl_id, uint8 found_flag, uint32 index)
{
    switch(tcam_tbl_id)
    {
        case DsIpv4UcastRouteKey_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsIpv4UcastRouteKey_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsIpv4UcastRouteKey_t[Invalid]");
            }
            break;

        case DsIpv4McastRouteKey_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsIpv4McastRouteKey_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsIpv4McastRouteKey_t[Invalid]");
            }
            break;

        case DsIpv6UcastRouteKey_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsIpv6UcastRouteKey_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsIpv6UcastRouteKey_t[Invalid]");
            }
            break;

        case DsIpv6McastRouteKey_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsIpv6McastRouteKey_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsIpv6McastRouteKey_t[Invalid]");
            }
            break;

        case DsMacBridgeKey_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsMacBridgeKey_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsMacBridgeKey_t[Invalid]");
            }
            break;

        case DsUserIdMacKey_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsUserIdMacKey_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsUserIdMacKey_t[Invalid]");
            }
            break;

        case DsUserIdIpv6Key_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsUserIdIpv6Key_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsUserIdIpv6Key_t[Invalid]");
            }
            break;

        case DsUserIdIpv4Key_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsUserIdIpv4Key_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsUserIdIpv4Key_t[Invalid]");
            }
            break;

        case DsUserIdVlanKey_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsUserIdVlanKey_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsUserIdVlanKey_t[Invalid]");
            }
            break;

        case DsAclIpv6Key0_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsAclIpv6Key0_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsAclIpv6Key0_t[Invalid]");
            }
            break;

        case DsAclIpv4Key0_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsAclIpv4Key0_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsAclIpv4Key0_t[Invalid]");
            }
            break;

        case DsAclMacKey0_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsAclMacKey0_t", index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsAclMacKey0_t[Invalid]");
            }
            break;

        default:
            break;

    }

    return;
}

void
sim_cmodel_debug_show_hash_tbl(tbls_id_t debug_table_id, fib_key_type_t hash_type, uint8 found_flag, uint32 key_index)
{
    char MacInfo[5] = {0};

    if (hash_type == FIB_KEY_TYPE_MAC_DA)
    {
        sal_memcpy(MacInfo, "Da", sizeof("Da"));
    }

    if (hash_type == FIB_KEY_TYPE_MAC_SA)
    {
        sal_memcpy(MacInfo, "Sa", sizeof("Sa"));
    }

    switch(debug_table_id)
    {
        case DsMacHashKey_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s(%s)[0x%x]\n",
                                        "DsMacHashKey_t", MacInfo, key_index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s(%s)[%s]\n",
                                        "DsMacHashKey_t", MacInfo, "Invalid");
            }
            break;

        case DsAclQosMacHashKey_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsAclQosMacHashKey_t", key_index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsAclQosMacHashKey_t[Invalid]");
            }
            break;

        case DsAclQosIpv4HashKey_t:
            if (found_flag)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n",
                                        "DsAclQosIpv4HashKey_t", key_index);
            }
            else
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s\n",
                                        "DsAclQosIpv4HashKey_t[Invalid]");
            }
            break;
        default:
            break;
    }

    return;
}


uint32
sim_get_channel(uint32 chip_id, rsv_channel_type_t type)
{
    uint32 chan_id = 0;
    uint32 cmd = 0;
    buf_retrv_chan_id_cfg_t buf_retrv_chan_id_cfg;
    sal_memset(&buf_retrv_chan_id_cfg, 0, sizeof(buf_retrv_chan_id_cfg_t));

    cmd = DRV_IOR(BufRetrvChanIdCfg_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, 0, cmd, &buf_retrv_chan_id_cfg));

    switch (type)
    {
        case RSV_CHAN_TYPE_INTLK_CHAN:
            chan_id = buf_retrv_chan_id_cfg.cfg_int_lk_chan_id_int;
            break;

        case RSV_CHAN_TYPE_ILOOP_CHAN:
            chan_id = buf_retrv_chan_id_cfg.cfg_i_loop_chan_id_int;
            break;

        case RSV_CHAN_TYPE_CPU_CHAN:
            chan_id = buf_retrv_chan_id_cfg.cfg_cpu_chan_id_int;
            break;

        case RSV_CHAN_TYPE_DMA_CHAN:
            chan_id = buf_retrv_chan_id_cfg.cfg_dma_chan_id_int;
            break;

        case RSV_CHAN_TYPE_OAM_CHAN:
            chan_id = buf_retrv_chan_id_cfg.cfg_oam_chan_id_int;
            break;
        case RSV_CHAN_TYPE_ELOOP_CHAN:
            chan_id = buf_retrv_chan_id_cfg.cfg_e_loop_chan_id_int;
            break;
        default:
            break;
    }

    return chan_id;
}

void
sim_cmodel_debug_show_discard(ctc_cmodel_debug_module_t module, uint8 discard_type)
{
    if (module == CTC_CMODEL_DEBUG_IPE)
    {
        switch(discard_type)
        {
             case  IPE_DISCARD_USER_ID_BINDING_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE UserId binding discard!");
                    break;
             case  IPE_DISCARD_HDR_ADJ_BYTE_RMV_ERR_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE HdrAdj byte remove error discard!");
                    break;
             case  IPE_DISCARD_PSR_LEN_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE Parser length error discard!");
                    break;
            case  IPE_DISCARD_MAC_ISOLATED_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE mac isolated discard!");
                    break;
            case  IPE_DISCARD_EXCEP_2_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE exception 2 discard!");
                    break;
             case  IPE_DISCARD_USER_ID_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE UserId discard!");
                    break;
             case  IPE_DISCARD_PORT_OR_DS_VLAN_RCV_DIS:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE Port or vlan receive disable discard!");
                    break;
             case  IPE_DISCARD_ITAG_CHK_FAIL:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE itag chech fail discard!");
                    break;
             case  IPE_DISCARD_PTL_VLAN_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE protocol vlan discard!");
                    break;
             case  IPE_DISCARD_VLAN_TAG_CTL_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE vlan tag control discard!");
                    break;
             case  IPE_DISCARD_NOT_ALLOW_MCAST_MAC_SA_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE mcast mac not allowed sa discard!");
                    break;
             case  IPE_DISCARD_STP_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE STP discard!");
                    break;
             case  IPE_DISCARD_RESERVED0:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE rsv discard!");
                    break;
             case  IPE_DISCARD_PBB_OAM_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE PBB OAM discard!");
                    break;
             case  IPE_DISCARD_ARP_DHCP_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE arp dhcp discard!");
                    break;
             case  IPE_DISCARD_DS_PHYPORT_SRC_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE Source Port discard!");
                    break;
             case  IPE_DISCARD_VLAN_STATUS_FILTER_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE vlan filter discard!");
                    break;
             case  IPE_DISCARD_ACLQOS_DISCARD_PKT:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE acl qos discard!");
                    break;
             case  IPE_DISCARD_ROUTING_MCAST_IP_ADDR_CHK_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE routing mcast IP address check discard!");
                    break;
             case  IPE_DISCARD_BRG_BPDU_ETC_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE Unkonown U/M discard!");
                    break;
             case  IPE_DISCARD_STORM_CTL_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE storm control discard!");
                    break;
             case  IPE_DISCARD_LEARNING_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE learning discard!");
                    break;
             case  IPE_DISCARD_POLICING_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE policing discard!");
                    break;
            case  IPE_DISCARD_NO_FWD_PTR_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE no fwd ptr discard!");
                    break;
             case  IPE_DISCARD_FWD_PTR_ALL_F_OR_VALID_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE fwd ptr discard!");
                    break;
             case  IPE_DISCARD_FATAL_EXCEPTION_DSCD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE Fatal exception discard!");
                    break;
             case  IPE_DISCARD_APS_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE APS discard!");
                    break;
             case  IPE_DISCARD_FWD_DEST_ID_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE fwd DestId discard!");
                    break;
            case  IPE_DISCARD_RESERVED1:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE rsv discard!");
                    break;
             case  IPE_DISCARD_HDR_AJUST_SMALL_PKT_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE HdrAdj small packet discard!");
                    break;
             case  IPE_DISCARD_HDR_ADJUST_PKT_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE HdrAdj packet error discard!");
                    break;
             case  IPE_DISCARD_TRILL_ESADI_PKT_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE trill ESADI packet discard!");
                    break;
             case  IPE_DISCARD_LOOPBACK_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE loopback discard!");
                    break;
             case  IPE_DISCARD_EFM_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE EFM discard!");
                    break;
             case  IPE_DISCARD_CAPWAP_FROM_AC_ERR_OR_UNEXPECTABLE:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE CAPWAP from AC error discard!");
                    break;
             case  IPE_DISCARD_STACKING_NETWORK_HEADER_CHK_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE stacking network header check error discard!");
                    break;
             case  IPE_DISCARD_TRILL_FILTER_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE trill filter error discard!");
                    break;
             case  IPE_DISCARD_CAPWAP_CONTROL_EXCEPTION:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE CAPWAP control exception discard!");
                    break;
             case  IPE_DISCARD_L3_EXCEPTION:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE l2 exception discard!");
                    break;
             case  IPE_DISCARD_L2_EXCEPTION:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE l3 exception discard!");
                    break;
             case  IPE_DISCARD_TRILL_MCAST_ADDR_CHK_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE trill mcast address check error discard!");
                    break;
             case  IPE_DISCARD_TRILL_VERSION_CHK_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE trill version check discard!");
                    break;
             case  IPE_DISCARD_PTP_VERSION_CHK_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE ptp version check discard!");
                    break;
             case  IPE_DISCARD_PTPT_P2P_TRANS_CLOCK_DELAY_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE P2P Transparent Clock Delay discard!");
                    break;
             case  IPE_DISCARD_OAM_NOT_FOUND_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE OAM not found discard!");
                    break;
             case  IPE_DISCARD_OAM_STP_VLAN_FILTER_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: iscard_type= %d, %s\n", discard_type, "IPE OAM STP vlan filter discard!");
                    break;
             case  IPE_DISCARD_BFD_SINGLE_HOP_OAM_TTL_CHK_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE OAM BFD single hop discard!");
                    break;
             case  IPE_DISCARD_CAPWAP_DTLS_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE CAPWAP DTLS discard!");
                    break;
             case  IPE_DISCARD_NO_MEP_MIP_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE no MEP MIP discard!");
                    break;
             case  IPE_DISCARD_OAM_DIS:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE OAM discard!");
                    break;
             case  IPE_DISCARD_PBB_DECAP_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE PBB Decap discard!");
                    break;
             case  IPE_DISCARD_MPLS_TMPLS_OAM_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE mpls tmpls oam discard!");
                    break;
             case  IPE_DISCARD_MPLSTP_MCC_SCC_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE mpls tp mcc scc discard!");
                    break;
             case  IPE_DISCARD_ICMP_ERR_MSG_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE ICMP error message discard!");
                    break;
             case  IPE_DISCARD_PTP_ACL_EXCEPTION:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE PTP acl exception discard!");
                    break;
             case  IPE_DISCARD_ETHER_SERVICE_OAM_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE Ether service OAM discard!");
                    break;
             case  IPE_DISCARD_LINK_OAM_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE link OAM discard!");
                    break;
             case  IPE_DISCARD_TUNNEL_DECAP_OUTER_MARTIAN_ADDR_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE Tunnel Decap Outer Martian Address discard!");
                    break;
             case  IPE_DISCARD_CAPWAP_BSSID_LKP_OR_LOGIC_PORT_CHK_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE CAPWAP BSSID loopback check discard!");
                    break;
             case  IPE_DISCARD_USER_ID_FWD_PTR_ALL_F_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE tunnel dsfwdptr is 0xFFFF discard!");
                    break;
             case  IPE_DISCARD_CAPWAP_FRAGMEN_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE CAPWAP Fragment discard!");
                    break;
             case  IPE_DISCARD_TRILL_RPF_CHK_FAIL:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE trill RPF check discard!");
                    break;
             case  IPE_DISCARD_MUX_PORT_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE Mux Port error discard!");
                    break;
             case  IPE_DISCARD_RESERVED2:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "IPE rsv discard!");
                    break;
             default:
                 break;
        }
    }
    else
    {
        switch(discard_type)
        {
            case EPE_DISCARD_EPE_HDR_ADJ_DEST_ID_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE HdrAdj DestId discard!");
                    break;
            case EPE_DISCARD_EPE_HDR_ADJ_PKT_ERR_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE HdrAdj Packet Error discard!");
                    break;
            case EPE_DISCARD_EPE_HDR_ADJ_BYTE_REMOVE_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE HdrAdj Byte Remove discard!");
                    break;
            case EPE_DISCARD_DEST_PHY_PORT_DEST_ID_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE DsDestPort destDiscard is set discard!");
                    break;
            case EPE_DISCARD_PORT_ISOLATE_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Port Isolate discard!");
                    break;
            case EPE_DISCARD_DS_VLAN_TRANS_DIS:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE DsVlantransmitEn Disable discard!");
                    break;
            case EPE_DISCARD_BRG_TO_SAME_PORT_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Bridge To SamePort discard!");
                    break;
            case EPE_DISCARD_VPLS_HORIZON_SPLIT_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE VPLS horizon split discard!");
                    break;
            case EPE_DISCARD_EGRESS_VLAN_FILTER_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Vlan Filter discard!");
                    break;
            case EPE_DISCARD_EGRESS_STP_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE STP discard!");
                    break;
            case EPE_DISCARD_EGRESS_PARSER_LEN_ERR_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Parser length error discard!");
                    break;
            case EPE_DISCARD_EGRESS_PBB_CHK_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE PBB Check Fail discard!");
                    break;
            case EPE_DISCARD_UCAST_MCAST_FLOOD_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Port Bcast Flooding discard!");
                    break;
            case EPE_DISCARD_802_3_OAM_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE 802.3 OAM pactet discard!");
                    break;
            case EPE_DISCARD_EGRESS_TTL_FAIL:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE TTL Check Fail discard!");
                    break;
            case EPE_DISCARD_REMOTE_MIRROR_ESCAPE_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Mirror Escape discard!");
                    break;
            case EPE_DISCARD_TUNNEL_MTU_CHK_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Tunnel MTU Check discard!");
                    break;
            case EPE_DISCARD_INTERFACE_MTU_CHK_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Interface MTU Check discard!");
                    break;
            case EPE_DISCARD_LOGIC_PORT_CHK_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Logic Port Check discard!");
                    break;
            case EPE_DISCARD_EGRESS_ACL_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE ACL discard!");
                    break;
            case EPE_DISCARD_EGRESS_QOS_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Qos discard!");
                    break;
            case EPE_DISCARD_EGRESS_POLICING_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Policing discard!");
                    break;
            case EPE_DISCARD_CRC_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE CRC error discard!");
                    break;
            case EPE_DISCARD_ROUTE_PAYLOAD_OPERATION_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Route PayloadOP but is not IP packet discard!");
                    break;
            case EPE_DISCARD_BRG_PAYLOAD_OPERATION_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE bridge is not enable discard!");
                    break;
            case EPE_DISCARD_PT_LAYER4_OFFSET_LAGER_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE StripOffset exceed ErrorLayer4Offset discard!");
                    break;
            case EPE_DISCARD_BFD_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE BFD discard!");
                    break;
            case EPE_DISCARD_PORT_REFLECTIVE_CHK_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Port Reflective Check discard!");
                    break;
            case EPE_DISCARD_IP_MPLS_TTL_CHK_ERR_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE IP MPLS TTL Check Error discard!");
                    break;
            case EPE_DISCARD_OAM_EGDE_PORT_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE OAM EGDE Port discard!");
                    break;
            case EPE_DISCARD_NAT_PT_ICMP_ERR:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE EPE NAT-PT ICMP ERROR discard!");
                    break;
            case EPE_DISCARD_RESERVED0:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Rsv0 discard!");
                    break;
            case EPE_DISCARD_LOCAL_OAM_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Local OAM discard!");
                    break;
            case EPE_DISCARD_OAM_FILTERING_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE OAM Filtering discard!");
                    break;
            case EPE_DISCARD_OAM_HASH_CONFILICT_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE OAM Hash Confilict discard!");
                    break;
            case EPE_DISCARD_IPDA_EQUALS_TO_IPSA_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Ipda Equals To Ipsa discard!");
                    break;
            case EPE_DISCARD_RESERVED1:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Rsv1 discard!");
                    break;
            case EPE_DISCARD_TRILL_PAYLOAD_OPERATION_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Trill Payload Operation discard!");
                    break;
            case EPE_DISCARD_PBB_CHK_FAIL_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE PBB Check Fail discard!");
                    break;
            case EPE_DISCARD_DS_NEXT_HOP_DATA_VIOLATE:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE NextHop Data Violate discard!");
                    break;
            case EPE_DISCARD_DEST_VLAN_PTR_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Vlan Ptr discard!");
                    break;
            case EPE_DISCARD_DS_L3_EDIT_DATA_VIOLATE_1:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE L3Edit Data Violate1 discard!");
                    break;
            case EPE_DISCARD_DS_L3_EDIT_DATA_VIOLATE_2:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE L3Edit Data Violate2 discard!");
                    break;
            case EPE_DISCARD_DS_L3_EDIT_NAT_DATA_VIOLATE:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE L3Edit Nat Data Violate discard!");
                    break;
            case EPE_DISCARD_DS_L2_EDIT_DATA_VIOLATE_1:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE L2Edit Data Violate1 discard!");
                    break;
            case EPE_DISCARD_DS_L2_EDIT_DATA_VIOLATE_2:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE L2Edit Data Violate2 discard!");
                    break;
            case EPE_DISCARD_PACKET_HEADER_C2C_TTL_ZERO:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE Packet Header CTC TTL Zero discard!");
                    break;
            case EPE_DISCARD_PT_UDP_CHECKSUM_IS_ZERO:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE PT UDP CheckSum is Zero discard!");
                    break;
            case EPE_DISCARD_OAM_TO_LOCAL_DISCARD:
                    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "[Discard Info]: discard_type= %d, %s\n", discard_type, "EPE OAM to Local discard!");
                    break;
            default:
                break;
            }
    }

    return;
}

/******************************************************************************
 * Name   : sim_mallocate_ipe_memory
 * Purpose: mallocate all memory for IPE.
 * Input  : npkt -- input packet informations pointer.
 * Output : none.
 * Return : SUCCESS
 *          Other   = ErrCode
 * Note   : N/A
*******************************************************************************/
static int32
_sim_mallocate_ipe_memory(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info;
    int32 cnt;

    /* mallocate packet information memory */
    in_pkt->pkt_info = (void *)sal_malloc(sizeof(ipe_packet_info_t));
    if ( NULL == in_pkt->pkt_info)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(in_pkt->pkt_info, 0, sizeof(ipe_packet_info_t));

    /* mallocate parsing result memory */
    pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;

    pkt_info->packet_length = in_pkt->packet_length;

    pkt_info->parser_rslt = (void *)sal_malloc(sizeof(parsing_result_t));
    if (NULL == pkt_info->parser_rslt)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->parser_rslt, 0, sizeof(parsing_result_t));

    pkt_info->parser_rslt1 = (void *)sal_malloc(sizeof(parsing_result_t));
    if (NULL == pkt_info->parser_rslt1)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->parser_rslt1, 0, sizeof(parsing_result_t));

    /* mallocate mpls data memory */
    for(cnt = 0; cnt < 4; cnt ++)
    {
        pkt_info->mpls_data[cnt] = (void *)sal_malloc(sizeof(ds_mpls_t));

        if (NULL == pkt_info->mpls_data[cnt])
        {
            return DRV_E_NO_MEMORY;
        }

        sal_memset(pkt_info->mpls_data[cnt], 0, sizeof(ds_mpls_t));
    }

    /* mallocate tcam ipda data memory */
    pkt_info->ipda_tcam_data = (void *)sal_malloc(sizeof(ds_ip_da_t));
    if (NULL == pkt_info->ipda_tcam_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->ipda_tcam_data, 0, sizeof(ds_ip_da_t));

     /* mallocate hash ipda data memory */
    pkt_info->ipda_fib_data = (void *)sal_malloc(sizeof(ds_ip_da_t));
    if (NULL == pkt_info->ipda_fib_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->ipda_fib_data, 0, sizeof(ds_ip_da_t));

    /* mallocate tcam ipsa data memory */
    pkt_info->ipsa_tcam_data = (void *)sal_malloc(sizeof(ds_ip_da_t));
    if (NULL == pkt_info->ipsa_tcam_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->ipsa_tcam_data, 0, sizeof(ds_ip_da_t));

    /* mallocate hash ipsa data memory */
    pkt_info->ipsa_fib_data = (void *)sal_malloc(sizeof(ds_ip_da_t));
    if (NULL == pkt_info->ipsa_fib_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->ipsa_fib_data, 0, sizeof(ds_ip_da_t));

    /* mallocate tcam trill Da data memory */
    pkt_info->trill_da_data_tcam = (void *)sal_malloc(sizeof(ds_trill_da_t));
    if (NULL == pkt_info->trill_da_data_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->trill_da_data_tcam, 0, sizeof(ds_trill_da_t));

    /* mallocate hash trill Da data memory */
    pkt_info->trill_da_data_fib = (void *)sal_malloc(sizeof(ds_trill_da_t));
    if (NULL == pkt_info->trill_da_data_fib)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->trill_da_data_fib, 0, sizeof(ds_trill_da_t));

    /* mallocate hash trill vlan da data memory */
    pkt_info->trill_vlan_da_data_fib = (void *)sal_malloc(sizeof(ds_trill_da_t));
    if (NULL == pkt_info->trill_vlan_da_data_fib)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->trill_vlan_da_data_fib, 0, sizeof(ds_trill_da_t));

    /* mallocate tcam FCoE Da data memory */
    pkt_info->fcoe_da_data_tcam = (void *)sal_malloc(sizeof(ds_fcoe_da_t));
    if (NULL == pkt_info->fcoe_da_data_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->fcoe_da_data_tcam, 0, sizeof(ds_fcoe_da_t));

    /* mallocate tcam FCoE Sa data memory */
    pkt_info->fcoe_sa_data_tcam = (void *)sal_malloc(sizeof(ds_fcoe_sa_t));
    if (NULL == pkt_info->fcoe_sa_data_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->fcoe_sa_data_tcam, 0, sizeof(ds_fcoe_sa_t));

    /* mallocate hash FCoE Da data memory */
    pkt_info->fcoe_da_data_fib = (void *)sal_malloc(sizeof(ds_fcoe_da_t));
    if (NULL == pkt_info->fcoe_da_data_fib)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->fcoe_da_data_fib, 0, sizeof(ds_fcoe_da_t));

    /* mallocate hash FCoE Sa data memory */
    pkt_info->fcoe_sa_data_fib = (void *)sal_malloc(sizeof(ds_fcoe_sa_t));
    if (NULL == pkt_info->fcoe_sa_data_fib)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset (pkt_info->fcoe_sa_data_fib, 0, sizeof(ds_fcoe_sa_t));

    /* mallocate macda hash data memory */
    pkt_info->hash_mac_da_data = (void *)sal_malloc(sizeof(ds_mac_t));
    if (NULL == pkt_info->hash_mac_da_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->hash_mac_da_data, 0, sizeof(ds_mac_t));

    /* mallocate macda tcam data memory */
    pkt_info->tcam_mac_da_data = (void *)sal_malloc(sizeof(ds_mac_t));
    if (NULL == pkt_info->tcam_mac_da_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->tcam_mac_da_data, 0, sizeof(ds_mac_t));

    pkt_info->ip_tcam_mac_da_data = (void *)sal_malloc(sizeof(ds_mac_t));
    if (NULL == pkt_info->ip_tcam_mac_da_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->ip_tcam_mac_da_data, 0, sizeof(ds_mac_t));

    pkt_info->ip_hash_mac_da_data = (void *)sal_malloc(sizeof(ds_mac_t));
    if (NULL == pkt_info->ip_hash_mac_da_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->ip_hash_mac_da_data, 0, sizeof(ds_mac_t));

    /* mallocate mac sa hash data memory */
    pkt_info->hash_mac_sa_data = (void *)sal_malloc(sizeof(ds_mac_t));
    if (NULL == pkt_info->hash_mac_sa_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->hash_mac_sa_data, 0, sizeof(ds_mac_t));

    /* mallocate mac sa tcam data memory */
    pkt_info->tcam_mac_sa_data = (void *)sal_malloc(sizeof(ds_mac_t));
    if (NULL == pkt_info->tcam_mac_sa_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->tcam_mac_sa_data, 0, sizeof(ds_mac_t));

    /* mallocate outer mac sa hash data memory */
    pkt_info->hash_outer_mac_sa_data = (void *)sal_malloc(sizeof(ds_mac_t));
    if (NULL == pkt_info->hash_outer_mac_sa_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->hash_outer_mac_sa_data, 0, sizeof(ds_mac_t));

    /* mallocate outer mac sa tcam data memory */
    pkt_info->tcam_outer_mac_sa_data = (void *)sal_malloc(sizeof(ds_mac_t));
    if (NULL == pkt_info->tcam_outer_mac_sa_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->tcam_outer_mac_sa_data, 0, sizeof(ds_mac_t));

    /* mallocate ACL data0 memory */
    pkt_info->acl_data0 = (void *)sal_malloc(sizeof(ds_acl_t));
    if (NULL == pkt_info->acl_data0)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->acl_data0, 0, sizeof(ds_acl_t));

    /* mallocate ACL data1 memory */
    pkt_info->acl_data1 = (void *)sal_malloc(sizeof(ds_acl_t));
    if (NULL == pkt_info->acl_data1)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->acl_data1, 0, sizeof(ds_acl_t));

    /* mallocate ACL data2 memory */
    pkt_info->acl_data2 = (void *)sal_malloc(sizeof(ds_acl_t));
    if (NULL == pkt_info->acl_data2)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->acl_data2, 0, sizeof(ds_acl_t));

    /* mallocate ACL data3 memory */
    pkt_info->acl_data3 = (void *)sal_malloc(sizeof(ds_acl_t));
    if (NULL == pkt_info->acl_data3)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->acl_data3, 0, sizeof(ds_acl_t));

    /* mallocate ACL data3 memory */
    pkt_info->acl_hash_data = (void *)sal_malloc(sizeof(ds_acl_t));
    if (NULL == pkt_info->acl_hash_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->acl_hash_data, 0, sizeof(ds_acl_t));

    /* mallocate lm chan data memory */
    pkt_info->lm_chan_data0 = (void *)sal_malloc(sizeof(ds_eth_oam_chan_t));
    if (NULL == pkt_info->lm_chan_data0)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_chan_data0, 0, sizeof(ds_eth_oam_chan_t));

    pkt_info->lm_chan_data0_tcam = (void*)sal_malloc(sizeof(ds_eth_oam_tcam_chan_t));
    if(NULL == pkt_info->lm_chan_data0_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_chan_data0_tcam, 0, sizeof(ds_eth_oam_tcam_chan_t));

    pkt_info->lm_info0 = (void *)sal_malloc(sizeof(oam_info_t));
    if (NULL == pkt_info->lm_info0)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_info0, 0, sizeof(oam_info_t));

    pkt_info->lm_info0_tcam = (void *)sal_malloc(sizeof(oam_info_t));
    if (NULL == pkt_info->lm_info0_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_info0_tcam, 0, sizeof(oam_info_t));

    /* mallocate exception information memory */
    pkt_info->bexception = (greatbelt_exception_info_t *)sal_malloc(sizeof(greatbelt_exception_info_t));
    if ( NULL == pkt_info->bexception)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->bexception, 0 , sizeof(greatbelt_exception_info_t));

    /* mallocate header information memory */
    pkt_info->bheader = (ms_packet_header_t *)sal_malloc(sizeof(ms_packet_header_t));
    if (NULL == pkt_info->bheader)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->bheader, 0, sizeof(ms_packet_header_t));

    /* mallocate ingress header information memory */
    pkt_info->ingress_header = (packet_header_outer_t *)sal_malloc(sizeof(packet_header_outer_t));
    if (NULL == pkt_info->ingress_header)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->ingress_header, 0, sizeof(ms_packet_header_t));

    return DRV_E_NONE;
}

/******************************************************************************
 * Name   : sim_ipe_mallocate_memory
 * Purpose: mallocate all memory for IPE.
 * Input  : npkt -- input packet informations pointer.
 * Output : none.
 * Return : SUCCESS
 *          Other   = ErrCode
 * Note   : N/A
*******************************************************************************/
int32
sim_ipe_mallocate_memory(ipe_in_pkt_t *in_pkt)
{
    if(DRV_E_NONE != _sim_mallocate_ipe_memory(in_pkt))
    {
        sim_ipe_free_memory(in_pkt);
        return DRV_E_NO_MEMORY;
    }

    return DRV_E_NONE;
}

/******************************************************************************
 * Name   : sim_ipe_free_memory
 * Purpose: free all memory for IPE.
 * Input  : npkt -- input packet informations pointer.
 * Output : none.
 * Return : SUCCESS
 *          Other   = ErrCode
 * Note   : N/A
*******************************************************************************/
int32
sim_ipe_free_memory(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    int32 index;

    if(NULL == pkt_info)
    {
        return DRV_E_NONE;
    }

    if (NULL != pkt_info->parser_rslt)
    {
        sal_free(pkt_info->parser_rslt);
        pkt_info->parser_rslt = NULL;
    }

    if (NULL != pkt_info->parser_rslt1)
    {
        sal_free(pkt_info->parser_rslt1);
        pkt_info->parser_rslt1 = NULL;
    }

    if (NULL != pkt_info->hash_mac_da_data)
    {
        sal_free(pkt_info->hash_mac_da_data);
        pkt_info->hash_mac_da_data = NULL;
    }

    if (NULL != pkt_info->tcam_mac_da_data)
    {
        sal_free(pkt_info->tcam_mac_da_data);
        pkt_info->tcam_mac_da_data = NULL;
    }

    if (NULL != pkt_info->ip_hash_mac_da_data)
    {
        sal_free(pkt_info->ip_hash_mac_da_data);
        pkt_info->ip_hash_mac_da_data = NULL;
    }

    if (NULL != pkt_info->ip_tcam_mac_da_data)
    {
        sal_free(pkt_info->ip_tcam_mac_da_data);
        pkt_info->ip_tcam_mac_da_data = NULL;
    }

    if (NULL != pkt_info->hash_mac_sa_data)
    {
        sal_free(pkt_info->hash_mac_sa_data);
        pkt_info->hash_mac_sa_data = NULL;
    }

    if (NULL != pkt_info->tcam_mac_sa_data)
    {
        sal_free(pkt_info->tcam_mac_sa_data);
        pkt_info->tcam_mac_sa_data = NULL;
    }

    if (NULL != pkt_info->hash_outer_mac_sa_data)
    {
        sal_free(pkt_info->hash_outer_mac_sa_data);
        pkt_info->hash_outer_mac_sa_data = NULL;
    }

    if (NULL != pkt_info->tcam_outer_mac_sa_data)
    {
        sal_free(pkt_info->tcam_outer_mac_sa_data);
        pkt_info->tcam_outer_mac_sa_data = NULL;
    }

    if (NULL != pkt_info->acl_data0)
    {
        sal_free(pkt_info->acl_data0);
        pkt_info->acl_data0 = NULL;
    }

    if (NULL != pkt_info->acl_data1)
    {
        sal_free(pkt_info->acl_data1);
        pkt_info->acl_data1 = NULL;
    }

    if (NULL != pkt_info->acl_data2)
    {
        sal_free(pkt_info->acl_data2);
        pkt_info->acl_data2 = NULL;
    }

    if (NULL != pkt_info->acl_data3)
    {
        sal_free(pkt_info->acl_data3);
        pkt_info->acl_data3 = NULL;
    }

    if (NULL != pkt_info->acl_hash_data)
    {
        sal_free(pkt_info->acl_hash_data);
        pkt_info->acl_hash_data = NULL;
    }

    if (NULL != pkt_info->fcoe_da_data_tcam)
    {
        sal_free(pkt_info->fcoe_da_data_tcam);
        pkt_info->fcoe_da_data_tcam = NULL;
    }

    if (NULL != pkt_info->fcoe_sa_data_tcam)
    {
        sal_free(pkt_info->fcoe_sa_data_tcam);
        pkt_info->fcoe_sa_data_tcam = NULL;
    }

    if (NULL != pkt_info->fcoe_da_data_fib)
    {
        sal_free(pkt_info->fcoe_da_data_fib);
        pkt_info->fcoe_da_data_fib = NULL;
    }

    if (NULL != pkt_info->fcoe_sa_data_fib)
    {
        sal_free(pkt_info->fcoe_sa_data_fib);
        pkt_info->fcoe_sa_data_fib = NULL;
    }

    if (NULL != pkt_info->trill_da_data_tcam)
    {
        sal_free(pkt_info->trill_da_data_tcam);
        pkt_info->trill_da_data_tcam = NULL;
    }

    if (NULL != pkt_info->trill_da_data_fib)
    {
        sal_free(pkt_info->trill_da_data_fib);
        pkt_info->trill_da_data_fib = NULL;
    }

    if (NULL != pkt_info->trill_vlan_da_data_fib)
    {
        sal_free(pkt_info->trill_vlan_da_data_fib);
        pkt_info->trill_vlan_da_data_fib = NULL;
    }

    if (NULL != pkt_info->ipda_tcam_data)
    {
        sal_free(pkt_info->ipda_tcam_data);
        pkt_info->ipda_tcam_data = NULL;
    }

    if (NULL != pkt_info->ipsa_tcam_data)
    {
        sal_free(pkt_info->ipsa_tcam_data);
        pkt_info->ipsa_tcam_data = NULL;
    }

    if (NULL != pkt_info->ipda_fib_data)
    {
        sal_free(pkt_info->ipda_fib_data);
        pkt_info->ipda_fib_data = NULL;
    }

    if (NULL != pkt_info->ipsa_fib_data)
    {
        sal_free(pkt_info->ipsa_fib_data);
        pkt_info->ipsa_fib_data = NULL;
    }

    if(NULL != pkt_info->lm_info0)
    {
        sal_free(pkt_info->lm_info0);
        pkt_info->lm_info0 = NULL;
    }

    if(NULL != pkt_info->lm_info0_tcam)
    {
        sal_free(pkt_info->lm_info0_tcam);
        pkt_info->lm_info0_tcam = NULL;
    }

    for (index = 0; index < 4; index++)
    {
        if (NULL != pkt_info->mpls_data[index])
        {
            sal_free(pkt_info->mpls_data[index]);
            pkt_info->mpls_data[index] = NULL;
        }
    }

    if (NULL != pkt_info->bexception)
    {
        sal_free(pkt_info->bexception);
        pkt_info->bexception = NULL;
    }

    if (NULL != pkt_info->bheader)
    {
        sal_free(pkt_info->bheader);
        pkt_info->bheader = NULL;
    }

    if (NULL != pkt_info->ingress_header)
    {
        sal_free(pkt_info->ingress_header);
        pkt_info->ingress_header= NULL;
    }

    if (NULL != pkt_info->lm_chan_data0)
    {
        sal_free(pkt_info->lm_chan_data0);
        pkt_info->lm_chan_data0 = NULL;
    }

    if(NULL != pkt_info->lm_chan_data0_tcam)
    {
        sal_free(pkt_info->lm_chan_data0_tcam);
        pkt_info->lm_chan_data0_tcam = NULL;
    }

    sal_free(pkt_info);
    pkt_info = NULL;

    return DRV_E_NONE;
}

int32
sim_ipe_create_output(ipe_in_pkt_t *in_pkt, list_head_t *out_pkt_head)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;

    out_pkt_t *out_pkt = NULL;

    INIT_LIST_HEAD(out_pkt_head);

    out_pkt = sal_malloc(sizeof(out_pkt_t));
    if (NULL == out_pkt)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! No memory to alloc out_pkt at sim_ipe_create_output\n");
        goto ERROR;
    }
    sal_memset(out_pkt, 0, sizeof(out_pkt_t));

    out_pkt->exception = sal_malloc(sizeof(greatbelt_exception_info_t));
    if (NULL == out_pkt->exception)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! No memory to alloc exception at sim_ipe_create_output\n");
        goto ERROR;
    }
    sal_memset(out_pkt->exception, 0, sizeof(greatbelt_exception_info_t));

    out_pkt->packet_length  = in_pkt->packet_length;
    out_pkt->chan_id        = in_pkt->chan_id;
    out_pkt->chip_id        = in_pkt->chip_id;
    out_pkt->pkt_id         = in_pkt->pkt_id;
    out_pkt->dest_queue     = SIM_FWD_Q;
    out_pkt->local_phy_port     =pkt_info->local_phy_port;
    sal_memcpy(&out_pkt->module_bus, &in_pkt->module_bus, sizeof(in_pkt->module_bus));
    sal_memcpy(out_pkt->module_bus.packet_header,pkt_info->bheader,GREAT_BELT_HEADER_LEN);

    out_pkt->pkt            = in_pkt->pkt;

    sal_memcpy(out_pkt->exception, pkt_info->bexception, sizeof(greatbelt_exception_info_t));

#if 0
    /* store IPE discard type */
    if (pkt_info->discard)
    {
        sim_store_discard_type(DISCARD_CHECK_IPE_MODULE, pkt_info->discard_type);
    }
#endif

    list_add_tail(&out_pkt->head, out_pkt_head);

    return DRV_E_NONE;

ERROR:
    if(out_pkt)
    {
        if(out_pkt->exception)
        {
            sal_free(out_pkt->exception);
            out_pkt->exception = NULL;
        }
        sal_free(out_pkt);
        out_pkt = NULL;
    }
    return DRV_E_NO_MEMORY;
}

/******************************************************************************
 * Name   : _sim_mallocate_epe_memory
 * Purpose: mallocate all memory for EPE.
 * Input  : epkt -- input packet informations pointer.
 * Output : none.
 * Return : SUCCESS
 *        Other   = ErrCode
 * Note   : N/A
*******************************************************************************/
static int32
_sim_mallocate_epe_memory(epe_in_pkt_t *epkt)
{
    #define L2EDIT_MAX_SIZE 32
    #define L3EDIT_MAX_SIZE 80
    #define DSNEXTHOPBITS_MAX_SIZE 144
    #define L3_NEWHDR_MAX_SIZE 256
    #define L2_NEWHDR_MAX_SIZE 28
    epe_packet_info_t *pkt_info;

    /* mallocate memory for packet informations */
    epkt->pkt_info = (uint32 *)sal_malloc(sizeof(epe_packet_info_t));
    if (NULL == epkt->pkt_info)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(epkt->pkt_info, 0, sizeof(epe_packet_info_t));
    pkt_info = (epe_packet_info_t *)epkt->pkt_info;

    /* mallocate memory parsing result */
    pkt_info->parser_result = (uint32 *)sal_malloc(sizeof(parsing_result_t));
    if (NULL == pkt_info->parser_result)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->parser_result, 0, sizeof(parsing_result_t));

    /* malloc memory for l2edit */
    pkt_info->l2_edit = (uint8 *)sal_malloc(L2EDIT_MAX_SIZE);
    if (NULL == pkt_info->l2_edit)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->l2_edit, 0, L2EDIT_MAX_SIZE);

    /* malloc memory for l3edit */
    pkt_info->l3_edit = (uint8 *)sal_malloc(L3EDIT_MAX_SIZE);

    /* malloc memory for DsNextHopBits */
    pkt_info->DsNextHopBits = (uint8 *)sal_malloc(DSNEXTHOPBITS_MAX_SIZE);
    if (NULL == pkt_info->DsNextHopBits)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->DsNextHopBits, 0, DSNEXTHOPBITS_MAX_SIZE);

    /* malloc new l3 header memory */
    pkt_info->l3_header = (uint8 *)sal_malloc(L3_NEWHDR_MAX_SIZE);
    if (NULL == pkt_info->l3_header)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->l3_header, 0, L3_NEWHDR_MAX_SIZE);

    /* malloc new l2 header memory */
    pkt_info->l2_header = (uint8 *)sal_malloc(L2_NEWHDR_MAX_SIZE);
    if (NULL == pkt_info->l2_header)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->l2_header, 0, L2_NEWHDR_MAX_SIZE);

    /* retrieve data */
    pkt_info->acl_data0 = (uint32 *)sal_malloc(sizeof(ds_acl_t));
    if (NULL == pkt_info->acl_data0)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->acl_data0, 0, sizeof(ds_acl_t));

    /* retrieve data */
    pkt_info->acl_data1 = (uint32 *)sal_malloc(sizeof(ds_acl_t));
    if (NULL == pkt_info->acl_data1)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->acl_data1, 0, sizeof(ds_acl_t));

    /* retrieve data */
    pkt_info->acl_data2 = (uint32 *)sal_malloc(sizeof(ds_acl_t));
    if (NULL == pkt_info->acl_data2)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->acl_data2, 0, sizeof(ds_acl_t));

    /* retrieve data */
    pkt_info->acl_data3 = (uint32 *)sal_malloc(sizeof(ds_acl_t));
    if (NULL == pkt_info->acl_data3)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->acl_data3, 0, sizeof(ds_acl_t));

    /* mallocate lm chan data memory */
    pkt_info->lm_chan0_data = (void *)sal_malloc(sizeof(ds_mpls_pbt_bfd_oam_chan_t));
    if (NULL == pkt_info->lm_chan0_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_chan0_data, 0, sizeof(ds_mpls_pbt_bfd_oam_chan_t));

    /* mallocate lm chan data memory */
    pkt_info->lm_chan1_data = (void *)sal_malloc(sizeof(ds_mpls_pbt_bfd_oam_chan_t));
    if (NULL == pkt_info->lm_chan1_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_chan1_data, 0, sizeof(ds_mpls_pbt_bfd_oam_chan_t));

    /* mallocate lm chan data memory */
    pkt_info->lm_chan2_data = (void *)sal_malloc(sizeof(ds_mpls_pbt_bfd_oam_chan_t));
    if (NULL == pkt_info->lm_chan2_data)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_chan2_data, 0, sizeof(ds_mpls_pbt_bfd_oam_chan_t));


    /* mallocate tcam lm chan data memory */
    pkt_info->lm_chan0_data_tcam = (void *)sal_malloc(sizeof(ds_eth_oam_tcam_chan_t));
    if (NULL == pkt_info->lm_chan0_data_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_chan0_data_tcam, 0, sizeof(ds_eth_oam_tcam_chan_t));

    /* mallocate tcam lm chan data memory */
    pkt_info->lm_chan1_data_tcam = (void *)sal_malloc(sizeof(ds_eth_oam_tcam_chan_t));
    if (NULL == pkt_info->lm_chan1_data_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_chan1_data_tcam, 0, sizeof(ds_eth_oam_tcam_chan_t));

    /* mallocate tcam lm chan data memory */
    pkt_info->lm_chan2_data_tcam = (void *)sal_malloc(sizeof(ds_eth_oam_tcam_chan_t));
    if (NULL == pkt_info->lm_chan2_data_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_chan2_data_tcam, 0, sizeof(ds_eth_oam_tcam_chan_t));

    /* mallocate oam_info data memory */
    pkt_info->lm_info0 = (void *)sal_malloc(sizeof(oam_info_t));
    if (NULL == pkt_info->lm_info0)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_info0, 0, sizeof(oam_info_t));

    pkt_info->lm_info1 = (void *)sal_malloc(sizeof(oam_info_t));
    if (NULL == pkt_info->lm_info1)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_info1, 0, sizeof(oam_info_t));

    pkt_info->lm_info2 = (void *)sal_malloc(sizeof(oam_info_t));
    if (NULL == pkt_info->lm_info2)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_info2, 0, sizeof(oam_info_t));

    /* mallocate tcam oam_info data memory */
    pkt_info->lm_info0_tcam = (void *)sal_malloc(sizeof(oam_info_t));
    if (NULL == pkt_info->lm_info0_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_info0_tcam, 0, sizeof(oam_info_t));

    pkt_info->lm_info1_tcam = (void *)sal_malloc(sizeof(oam_info_t));
    if (NULL == pkt_info->lm_info1_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_info1_tcam, 0, sizeof(oam_info_t));

    pkt_info->lm_info2_tcam = (void *)sal_malloc(sizeof(oam_info_t));
    if (NULL == pkt_info->lm_info2_tcam)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->lm_info2_tcam, 0, sizeof(oam_info_t));

    /* mallocate exception information memory */
    pkt_info->bexception = (greatbelt_exception_info_t *)sal_malloc(sizeof(greatbelt_exception_info_t));
    if (NULL == pkt_info->bexception)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->bexception, 0, sizeof(greatbelt_exception_info_t));

    /* mallocate header information memory */
    pkt_info->bheader = (ms_packet_header_t *)sal_malloc(sizeof(ms_packet_header_t));
    if (NULL == pkt_info->bheader)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->bheader, 0, sizeof(ms_packet_header_t));

    /* malloc old packetheader memory */
    pkt_info->old_packet_header = (ms_packet_header_t *)sal_malloc(sizeof(ms_packet_header_t));
    if (NULL == pkt_info->old_packet_header)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->old_packet_header, 0, sizeof(ms_packet_header_t));

    /* mallocate ingress header information memory */
    pkt_info->ingress_header = (ms_packet_header_t *)sal_malloc(sizeof(ms_packet_header_t));
    if (NULL == pkt_info->ingress_header)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->ingress_header, 0, sizeof(ms_packet_header_t));

    return DRV_E_NONE;
}

/******************************************************************************
 * Name   : sim_epe_mallocate_memory
 * Purpose: mallocate all memory for EPE.
 * Input  : npkt -- input packet informations pointer.
 * Output : none.
 * Return : SUCCESS
 *          Other   = ErrCode
 * Note   : N/A
*******************************************************************************/
int32
sim_epe_mallocate_memory(epe_in_pkt_t *epkt)
{
    if(DRV_E_NONE != _sim_mallocate_epe_memory(epkt))
    {
        sim_epe_free_memory(epkt);
        return DRV_E_NO_MEMORY;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      sim_epe_free_memory
 * Purpose:   free the memory malloc in epe process.
 * Parameters:
 * Input:     none.
 * Output:    none.
 * Return:    DRV_E_NONE = success.
 *            Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32
sim_epe_free_memory(epe_in_pkt_t* epkt)
{
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)epkt->pkt_info;

    if (NULL != epkt->pkt)
    {
        sal_free(epkt->pkt);
        epkt->pkt = NULL;
    }

    if(NULL == pkt_info)
    {
        return DRV_E_NONE;
    }

    if (NULL != pkt_info->acl_data0)
    {
        sal_free(pkt_info->acl_data0);
        pkt_info->acl_data0 = NULL;
    }

    if (NULL != pkt_info->acl_data1)
    {
        sal_free(pkt_info->acl_data1);
        pkt_info->acl_data1 = NULL;
    }

    if (NULL != pkt_info->acl_data2)
    {
        sal_free(pkt_info->acl_data2);
        pkt_info->acl_data2 = NULL;
    }

    if (NULL != pkt_info->acl_data3)
    {
        sal_free(pkt_info->acl_data3);
        pkt_info->acl_data3 = NULL;
    }

    if (NULL != pkt_info->lm_chan0_data)
    {
        sal_free(pkt_info->lm_chan0_data);
        pkt_info->lm_chan0_data = NULL;
    }

    if (NULL != pkt_info->lm_chan1_data)
    {
        sal_free(pkt_info->lm_chan1_data);
        pkt_info->lm_chan1_data = NULL;
    }

    if (NULL != pkt_info->lm_chan2_data)
    {
        sal_free(pkt_info->lm_chan2_data);
        pkt_info->lm_chan2_data = NULL;
    }

    if (NULL != pkt_info->lm_chan0_data_tcam)
    {
        sal_free(pkt_info->lm_chan0_data_tcam);
        pkt_info->lm_chan0_data_tcam = NULL;
    }

    if (NULL != pkt_info->lm_chan1_data_tcam)
    {
        sal_free(pkt_info->lm_chan1_data_tcam);
        pkt_info->lm_chan1_data_tcam = NULL;
    }

    if (NULL != pkt_info->lm_chan2_data_tcam)
    {
        sal_free(pkt_info->lm_chan2_data_tcam);
        pkt_info->lm_chan2_data_tcam = NULL;
    }

    if (NULL != pkt_info->lm_info0)
    {
        sal_free(pkt_info->lm_info0);
        pkt_info->lm_info0 = NULL;
    }

    if (NULL != pkt_info->lm_info1)
    {
        sal_free(pkt_info->lm_info1);
        pkt_info->lm_info1 = NULL;
    }

    if (NULL != pkt_info->lm_info2)
    {
        sal_free(pkt_info->lm_info2);
        pkt_info->lm_info2 = NULL;
    }

    if (NULL != pkt_info->lm_info0_tcam)
    {
        sal_free(pkt_info->lm_info0_tcam);
        pkt_info->lm_info0_tcam = NULL;
    }

    if (NULL != pkt_info->lm_info1_tcam)
    {
        sal_free(pkt_info->lm_info1_tcam);
        pkt_info->lm_info1_tcam = NULL;
    }

    if (NULL != pkt_info->lm_info2_tcam)
    {
        sal_free(pkt_info->lm_info2_tcam);
        pkt_info->lm_info2_tcam = NULL;
    }

    if (NULL != pkt_info->l3_header)
    {
        sal_free(pkt_info->l3_header);
        pkt_info->l3_header = NULL;
    }

    if (NULL != pkt_info->l2_header)
    {
        sal_free(pkt_info->l2_header);
        pkt_info->l2_header = NULL;
    }

    if (NULL != pkt_info->parser_result)
    {
        sal_free(pkt_info->parser_result);
        pkt_info->parser_result = NULL;
    }

    if (NULL != pkt_info->l2_edit)
    {
        sal_free(pkt_info->l2_edit);
        pkt_info->l2_edit= NULL;
    }

    if (NULL != pkt_info->l3_edit)
    {
        sal_free(pkt_info->l3_edit);
        pkt_info->l3_edit = NULL;
    }

    if (NULL != pkt_info->DsNextHopBits)
    {
        sal_free(pkt_info->DsNextHopBits);
        pkt_info->DsNextHopBits = NULL;
    }

    if (NULL != pkt_info->bexception)
    {
        sal_free(pkt_info->bexception);
        pkt_info->bexception= NULL;
    }

    if (NULL != pkt_info->bheader)
    {
        sal_free(pkt_info->bheader);
        pkt_info->bheader = NULL;
    }

    if (NULL != pkt_info->old_packet_header)
    {
        sal_free(pkt_info->old_packet_header);
        pkt_info->old_packet_header = NULL;
    }

    if (NULL != pkt_info->ingress_header)
    {
        sal_free(pkt_info->ingress_header);
        pkt_info->ingress_header = NULL;
    }

    sal_free(pkt_info);
    pkt_info = NULL;

    return DRV_E_NONE;
}


int32 sim_epe_create_output(epe_in_pkt_t *in_pkt, queue_in_pkt_t *out_pkt)
{
    epe_packet_info_t *pkt_info = (epe_packet_info_t *)in_pkt->pkt_info;

    sal_memset(out_pkt, 0, sizeof(queue_in_pkt_t));

    /* mallocate packet information memory */
    //DRV_IF_ERROR_RETURN(_sim_mac_stats_transmit(in_pkt));

    out_pkt->pkt = in_pkt->pkt;
    in_pkt->pkt = NULL;

    /* if with bheader, packetLen is epe input packetlen, others is adjusted packetLen */
#if 0
    if (pkt_info->packet_header_en)
    {
        /* multi-chip */
        out_pkt->packet_length = in_pkt->packet_length + pkt_info->l2_new_header_len;
    }
    else
    {

        out_pkt->packet_length = pkt_info->packet_length;
    }
#else
    out_pkt->packet_length = in_pkt->packet_length;
#endif
    /* copy packet */
    out_pkt->chip_id = in_pkt->chip_id;
    out_pkt->pkt_id  = in_pkt->pkt_id;
    out_pkt->chan_id = in_pkt->chan_id;
    sal_memcpy(&out_pkt->module_bus, &in_pkt->module_bus, sizeof(in_pkt->module_bus));
    sal_memcpy(&out_pkt->module_bus.packet_header, pkt_info->bheader, GREAT_BELT_HEADER_LEN);

#if 0
    /* store EPE discard type */
    if (pkt_info->discard)
    {
        sim_store_discard_type(DISCARD_CHECK_EPE_MODULE, pkt_info->discard_type);
    }
#endif

    return DRV_E_NONE;
}


// the next 3 function is added by guhuade for oam pkt malloc and free
int32 sim_oam_mallocate_memory(oam_in_pkt_t* oam_pkt)
{
    uint8* pkt = sal_malloc(MTU);
    if (NULL == pkt)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt, 0, MTU);
    sal_memmove(pkt, oam_pkt->pkt, oam_pkt->packet_length);
    sal_free(oam_pkt->pkt);
    oam_pkt->pkt = pkt;

    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*) sal_malloc(sizeof(oam_pkt_info_t));
    if (NULL == pkt_info)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info, 0, sizeof(oam_pkt_info_t));

    oam_pkt->pkt_info = (uint32*)pkt_info;

    ms_packet_header_t* bheader = sal_malloc(sizeof(ms_packet_header_t));
    if (NULL == bheader)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(bheader, 0, sizeof(ms_packet_header_t));
    pkt_info->bheader = bheader;

    uint32* parser_rslt = sal_malloc(sizeof(oam_parser_result_t));
    if (NULL == parser_rslt)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(parser_rslt, 0, sizeof(oam_parser_result_t));
    pkt_info->parser_result = parser_rslt;

    return DRV_E_NONE;
}

int32 sim_oam_free_memory(oam_in_pkt_t* oam_pkt)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)oam_pkt->pkt_info;

    if (NULL != oam_pkt->pkt)
    {
        sal_free(oam_pkt->pkt);
        oam_pkt->pkt = NULL;
    }

    if (NULL == pkt_info)
    {
        return DRV_E_NONE;
    }

    if (NULL != pkt_info->parser_result)
    {
        sal_free(pkt_info->parser_result);
        pkt_info->parser_result = NULL;
    }

    if (NULL != pkt_info->bheader)
    {
        sal_free(pkt_info->bheader);
        pkt_info->bheader = NULL;
    }

    sal_free(pkt_info);
    pkt_info= NULL;

    return DRV_E_NONE;
}


int32 sim_oam_create_output(oam_in_pkt_t* oam_pkt, list_head_t* out_pkt)
{
    out_pkt_t* out_pkt_p = sal_malloc(sizeof(out_pkt_t));

    if (NULL == out_pkt_p)
    {
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! No memory to alloc out_pkt at sim_oam_create_output\n");
        return DRV_E_NO_MEMORY;
    }

    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)oam_pkt->pkt_info;

    sal_memset(out_pkt_p, 0, sizeof(out_pkt_t));
    out_pkt_p->exception = sal_malloc(sizeof(greatbelt_exception_info_t));

    if (NULL == out_pkt_p->exception)
    {
        sal_free(out_pkt_p);
        out_pkt_p = NULL;
        CMODEL_DEBUG_OUT_INFO("CModelProcess ERROR! No memory to alloc exception at sim_oam_create_output\n");
        return DRV_E_NO_MEMORY;
    }

    sal_memset(out_pkt_p->exception, 0, sizeof(greatbelt_exception_info_t));

    out_pkt_p->pkt = oam_pkt->pkt;
    oam_pkt->pkt = NULL;

    out_pkt_p->packet_length = oam_pkt->packet_length;
    out_pkt_p->chip_id = oam_pkt->chip_id;
    out_pkt_p->pkt_id  = oam_pkt->pkt_id;
    out_pkt_p->chan_id = oam_pkt->chan_id;
    sal_memcpy(&out_pkt_p->module_bus, &oam_pkt->module_bus, sizeof(oam_pkt->module_bus));

    uint8* bheader = (uint8*)pkt_info->bheader;

    DRV_IF_ERROR_RETURN(swap32((uint32 *)bheader, GREAT_BELT_HEADER_LEN / 4,
                            HOST_TO_NETWORK));
    bheader[15] &= 0xF0;
    uint8 header_crc = calculate_crc4((uint8 *)bheader, GREAT_BELT_HEADER_LEN, 0);
    bheader[15] |= (header_crc&0x0F);

#if (SDK_WORK_PLATFORM == 1)
    DRV_IF_ERROR_RETURN(swap32((uint32 *)bheader, (GREAT_BELT_HEADER_LEN) / 4, NETWORK_TO_HOST));

    if (!pkt_info->hard_discard)
    {
        if (cosim_db.store_bheader)
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_bheader(((void *)bheader), SIM_MODULE_OAM));
        }
    }
    DRV_IF_ERROR_RETURN(swap32((uint32 *)bheader, (GREAT_BELT_HEADER_LEN) / 4, HOST_TO_NETWORK));
#endif
    uint32 crc;

    /* update crc */
    DRV_IF_ERROR_RETURN(ctcutil_crc32(0xFFFFFFFF,
                                        out_pkt_p->pkt,
                                        (oam_pkt->packet_length - 4),
                                        &crc));
    DRV_IF_ERROR_RETURN(swap32(&crc, 1, HOST_TO_NETWORK));
    out_pkt_p->pkt[oam_pkt->packet_length - 4] = (crc >> 24) & 0xFF;
    out_pkt_p->pkt[oam_pkt->packet_length - 3] = (crc >> 16) & 0xFF;
    out_pkt_p->pkt[oam_pkt->packet_length - 2] = (crc >> 8) & 0xFF;
    out_pkt_p->pkt[oam_pkt->packet_length - 1] = crc & 0xFF;

    if (pkt_info->relay_to_cpu_valid || pkt_info->cpu_exception_valid)
    {
        sal_memcpy(out_pkt_p->module_bus.packet_header, bheader, GREAT_BELT_HEADER_LEN);
        /*out_pkt_p->dest_queue = SIM_NETTX_Q;*/
        out_pkt_p->dest_queue = SIM_FWD_Q; /* all pkt to cpu shall go through BSR */
        list_add_tail(&(out_pkt_p->head), out_pkt);
    }
    else if (pkt_info->relay_to_bsr_valid)
    {
        sal_memcpy(out_pkt_p->module_bus.packet_header, bheader, GREAT_BELT_HEADER_LEN);
        out_pkt_p->dest_queue = SIM_FWD_Q;
        list_add_tail(&(out_pkt_p->head), out_pkt);
    }
    else /* hard dicard */
    {
        if (out_pkt_p->exception)
        {
            sal_free(out_pkt_p->exception);
            out_pkt_p->exception = NULL;
        }
        if (out_pkt_p->pkt)
        {
            sal_free(out_pkt_p->pkt);
            out_pkt_p->pkt = NULL;
        }
        sal_free(out_pkt_p);
        out_pkt_p = NULL;
    }

    /* add code for compare oam in pkt for co-sim */
    if (pkt_info->relay_to_cpu_valid || pkt_info->cpu_exception_valid || pkt_info->relay_to_bsr_valid)
    {
#if COSIM_PENDING
        /* zhouw note */
        if (sim_interface_initialize)
        {
            sim_pkt_cmp_t* oam_outpkt = sal_malloc(sizeof(sim_pkt_cmp_t));
            if (NULL == oam_outpkt)
            {
                CMODEL_DEBUG_OUT_INFO("no memory\n");
                return DRV_E_NO_MEMORY;
            }
            sal_memset(oam_outpkt, 0, sizeof(sim_pkt_cmp_t));
            sal_memcpy(oam_outpkt->pkt, out_pkt_p->pkt, MTU);
            oam_outpkt->chip_id = out_pkt_p->chip_id;
            oam_outpkt->chan_id = out_pkt_p->chan_id;
            oam_outpkt->packet_length = out_pkt_p->packet_length;

            list_add_tail(&(oam_outpkt->head),&oam_output_pkt_list);
        }
#endif
    }

    return DRV_E_NONE;
}

static int32
_sim_mallocate_qmgt_memory(queue_in_pkt_t *qpkt)
{
    queue_packet_info_t *pkt_info;

    /* mallocate memory for packet informations */
    qpkt->pkt_info = (queue_packet_info_t *)sal_malloc(sizeof(queue_packet_info_t));
    if (NULL == qpkt->pkt_info)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(qpkt->pkt_info, 0, sizeof(queue_packet_info_t));
    pkt_info = (queue_packet_info_t *)qpkt->pkt_info;

    pkt_info->ms_met_fifo = (fwd_ms_met_fifo_t *)sal_malloc(sizeof(fwd_ms_met_fifo_t));
    if (NULL == pkt_info->ms_met_fifo)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->ms_met_fifo, 0, sizeof(fwd_ms_met_fifo_t));

    /* mallocate exception information memory */
    pkt_info->bexception = (greatbelt_exception_info_t *)sal_malloc(sizeof(greatbelt_exception_info_t));
    if (NULL == pkt_info->bexception)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt_info->bexception, 0, sizeof(greatbelt_exception_info_t));

    return DRV_E_NONE;
}

int32
sim_qmgt_mallocate_memory(queue_in_pkt_t *qpkt)
{
    if (DRV_E_NONE != _sim_mallocate_qmgt_memory(qpkt))
    {
        sim_qmgt_free_memory(qpkt);
        return DRV_E_NO_MEMORY;
    }

    queue_packet_info_t *pkt_info = (queue_packet_info_t *)qpkt->pkt_info;

    /* init the list head */
    INIT_LIST_HEAD(&pkt_info->ms_enqueue_list);
    INIT_LIST_HEAD(&pkt_info->ms_dequeue_list);

    return DRV_E_NONE;
}


int32
sim_qmgt_free_memory(queue_in_pkt_t *qpkt)
{
    queue_packet_info_t *pkt_info = (queue_packet_info_t *)qpkt->pkt_info;

    if (NULL != qpkt->pkt)
    {
        sal_free(qpkt->pkt);
        qpkt->pkt = NULL;
    }

    if (NULL != qpkt->exception)
    {
        sal_free(qpkt->exception);
        qpkt->exception = NULL;
    }

    if (NULL == pkt_info)
    {
        return DRV_E_NONE;
    }

    if (NULL != pkt_info->bexception)
    {
        sal_free(pkt_info->bexception);
        pkt_info->bexception = NULL;
    }

    if (NULL != pkt_info->ms_met_fifo)
    {
        sal_free(pkt_info->ms_met_fifo);
        pkt_info->ms_met_fifo = NULL;
    }

    if( NULL != pkt_info)
   {
        list_del_all_and_free(&pkt_info->ms_enqueue_list);
        list_del_all_and_free(&pkt_info->ms_dequeue_list);
   }

    sal_free(pkt_info);
    pkt_info = NULL;

    return DRV_E_NONE;
}

/******************************************************************************
 * Name   : sim_store_outpkt_filename
 * Purpose: to get the pkt filename from cli command
 * Input  : file_name
 * Output : N/A
 * Return : SUCCESS
 *          Other = ErrCode
 * Note   : N/A
 *****************************************************************************/
int32
sim_store_outpkt_filename(char *file_name)
{
     if (NULL == file_name)
     {
         CMODEL_DEBUG_OUT_INFO("invalid pke filename");
         return  DRV_E_INVALID_PARAMETER;
     }
     unlink(file_name);

     sal_memset(pkt_file_name, 0, MAX_PKT_FILE_NAME_SIZE);
     sal_strcpy(pkt_file_name, file_name);

     return 0;
 }

/******************************************************************************
 * Name   : sim_store_outpkt_filename
 * Purpose: to get the oam output pkt filename from cli command
 * Input  : file_name
 * Output : N/A
 * Return : SUCCESS
 *          Other = ErrCode
 * Note   : N/A
 *****************************************************************************/
int32
sim_store_oam_outpkt_filename(char *file_name)
{
     if (NULL == file_name)
     {
         CMODEL_DEBUG_OUT_INFO("invalid pke filename");
         return  DRV_E_INVALID_PARAMETER;
     }
     unlink(file_name);

     sal_memset(oam_pkt_file_name, 0, MAX_PKT_FILE_NAME_SIZE);
     sal_strcpy(oam_pkt_file_name, file_name);

     return 0;
 }

/******************************************************************************
 * Name   : sim_output_packet
 * Purpose: to output the pkt into the file pointed by fp
 * Input  : packet, packet_length.
 * Output : N/A
 * Return : SUCCESS
 *          Other   = ErrCode
 * Note   : N/A
 *****************************************************************************/
int32
sim_output_packet(uint8 *packet, uint32 packet_length, uint8 chip_id, uint32 channel)
{
    int32 temp = 0;
    FILE *fp = NULL;

    if (NULL == packet)
    {
        CMODEL_DEBUG_OUT_INFO("invalid paramet!");
        return  DRV_E_INVALID_PARAMETER;
    }

    fp = fopen(pkt_file_name, "a+");
    if(NULL == fp)
    {
        return DRV_E_NONE;
    }

    sal_fprintf(fp, "PKT: packet_length=%d chip_id=%d output_channel=%d\n", packet_length, chip_id, channel);
    for (temp = 0; temp < packet_length; temp ++)
    {
        sal_fprintf(fp, "%02x", packet[temp]);
        if ((temp + 1) % 16 == 0)
        {
            sal_fprintf(fp, "\n");
        }
    }
    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}

/******************************************************************************
 * Name   : sim_oam_output_packet
 * Purpose: to output the oam output pkt into the file pointed by fp
 * Input  : packet, packet_length.
 * Output : N/A
 * Return : SUCCESS
 *          Other   = ErrCode
 * Note   : N/A
 *****************************************************************************/
int32
sim_oam_output_packet(uint8 *packet, uint32 packet_length, uint8 chip_id, uint32 chan)
{
    int32 temp = 0;
    FILE *fp = NULL;

    if (NULL == packet)
    {
        CMODEL_DEBUG_OUT_INFO("invalid paramet!");
        return  DRV_E_INVALID_PARAMETER;
    }

    fp = fopen(oam_pkt_file_name, "a+");
    if(NULL == fp)
    {
        return DRV_E_NONE;
    }
    sal_fprintf(fp, "PKT: packet_length=%d chip_id=%d output_channel=%d\n", packet_length, chip_id, chan);

    for (temp = 0; temp < packet_length; temp ++)
    {
        sal_fprintf(fp, "%02x", packet[temp]);
        if ((temp + 1) % 16 == 0)
        {
            sal_fprintf(fp, "\n");
        }
    }
    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}

static int32
_sim_get_outpkt_linklist_from_outpkt_file(list_head_t *link_list, FILE* fp, uint32 *pkt_total_no)
{
#define OUTPKT_FILE_PKT_LINE_MAX_LENGTH   16
    FILE* outpkt_fp = fp;
    char line[LINE_LEN_MAX] = {0};
    char *ch = NULL;
    char char_ptr[3] = {0, 0, '\0'};
    int value = 0;
    outpkt_t *outpkt = NULL;
    uint32 data32 = 0;
    uint8 *pkt = NULL;
    uint32 packet_length =0;
    list_head_t *pos = NULL;

    *pkt_total_no = 0;

     /*parse output pkt file */
    while(!feof(outpkt_fp))
    {
        sal_memset(line, 0, sizeof(line));
        fgets(line, LINE_LEN_MAX, outpkt_fp);

        if (0 == sal_strncmp(line, "PKT", sal_strlen("PKT")))
        {
            if (0 != (*pkt_total_no))
            {
                list_add_tail(&outpkt->head, link_list);
            }

            (*pkt_total_no)++;

            /* creat one new link list node */
            outpkt = sal_malloc(sizeof(outpkt_t));
            if (NULL == outpkt)
            {
                CMODEL_DEBUG_OUT_INFO("no memory\n");
                outpkt->pkt = NULL;
                goto ERROR;
            }
            sal_memset(outpkt, 0, sizeof(outpkt_t));

            outpkt->pkt = sal_malloc(MTU);
            if (NULL == outpkt->pkt)
            {
                CMODEL_DEBUG_OUT_INFO("no memory\n");
                goto ERROR;
            }
            sal_memset(outpkt->pkt, 0, MTU);
            pkt = outpkt->pkt ;

            /* get packet_length */
            ch = sal_strstr(line, "packet_length=");
            if(ch == NULL)
            {
                CMODEL_DEBUG_OUT_INFO("read packet_length error!\n");
                goto ERROR;
            }
            sal_sscanf(&ch[14], "%d", &value);
            outpkt->packet_length = value;

            /* get chip_id */
            value = 0;
            ch = sal_strstr(line, "chip_id=");
            if(ch == NULL)
            {
                CMODEL_DEBUG_OUT_INFO("read chip_id error!\n");
                goto ERROR;
            }
            sal_sscanf(&ch[8], "%d", &value);
            outpkt->chip_id= value;

            /* get chan_id */
            value = 0;
            ch = sal_strstr(line, "output_channel=");
            if(ch == NULL)
            {
                CMODEL_DEBUG_OUT_INFO("read output_channel error!\n");
                goto ERROR;
            }
            sal_sscanf(&ch[15], "%d", &value);
            outpkt->chan_id = value;
        }
        else if (EMPTY_LINE(line[0]))
        {
            continue;
        }
        else                        /* get pkt content */
        {
            if(pkt == NULL)
            {
                CMODEL_DEBUG_OUT_INFO("pkt file format error, must start with string:PKT!\n");
                goto ERROR;
            }
            char *string_ptr = line;
            packet_length = 0;

            while (packet_length < OUTPKT_FILE_PKT_LINE_MAX_LENGTH)
            {
                sal_memcpy(char_ptr, string_ptr, 2);
                data32 = 0;
                if (sal_sscanf(char_ptr, "%x", &data32) == 1)
                {
                    *pkt = (uint8)data32;
                    pkt+=1;
                    string_ptr+=2;
                    packet_length+=1;
                }
                else
                {
                    break;
                }
            }
        }
    }

    if (outpkt == NULL)
    {
        return DRV_E_NONE;
    }

    /* insert the last node */
    list_add_tail(&outpkt->head, link_list);

    return DRV_E_NONE;

ERROR:
    /* delete all link list */
    list_for_each(pos, link_list)
    {
        out_pkt_t *node_tmp = list_entry(pos, out_pkt_t, head);
        if (NULL != node_tmp->pkt)
        {
            sal_free(node_tmp->pkt);
            node_tmp->pkt = NULL;
        }

        if (NULL != node_tmp)
        {
            sal_free(node_tmp);
            node_tmp = NULL;
        }
    }

    return DRV_E_NO_MEMORY;

}

static bool
_sim_compare_outpkt_node(outpkt_t *actual_node, outpkt_t *expect_node)
{
    uint32 pkt_index = 0;

    if ((actual_node->packet_length != expect_node->packet_length)
        || (actual_node->chip_id != expect_node->chip_id)
        || (actual_node->chan_id != expect_node->chan_id))
    {
        return FALSE;
    }
    else
    {
        while (pkt_index < actual_node->packet_length)
        {
/* whole packet compare, jump headerHash and headerCRC compare, only on UML, emu must open ???? attention */
#if 0
            if (pkt_index == GREAT_BELT_CPUMAC_HDR_LEN+5)       /* mask headerHash[2:0] */
            {
                if ((actual_node->pkt[pkt_index]>>3) != (expect_node->pkt[pkt_index]>>3))
                {
                    return FALSE;
                }
            }
            else if (pkt_index == GREAT_BELT_CPUMAC_HDR_LEN+GREATBELT_HDR_CRC_OFFSET) /* mask Hdrcrc[3:0] */
            {
                if ((actual_node->pkt[pkt_index]>>4) != (expect_node->pkt[pkt_index]>>4))
                {
                    return FALSE;
                }
            }
            else if (pkt_index == GREAT_BELT_CPUMAC_HDR_LEN+27) /* mask Hdrcrc[7:4] */
            {
                if ((actual_node->pkt[pkt_index]>>5) != (expect_node->pkt[pkt_index]>>5))
                {
                    return FALSE;
                }
            }
            else if (pkt_index >= actual_node->packet_length-4) /* mask packetCRC */
            {
            }
            else
            {
                if (actual_node->pkt[pkt_index] != expect_node->pkt[pkt_index])
                {
                    return FALSE;
                }
            }
#else
            if (actual_node->pkt[pkt_index] != expect_node->pkt[pkt_index])
            {
                return FALSE;
            }

#endif
            pkt_index++;
        }
    }
    return TRUE;
}

#if (SDK_WORK_PLATFORM == 1)

#if 0
/************* Temp code to help check cpu case bridge header and cpu header ************/
static bool
_sim_cmp_field(uint32 c_field, uint32 v_field, uint8 *name, bool *first_flag)
{
   char buf[128];
   if (c_field != v_field)
   {
      if (*first_flag == TRUE)
      {
         ASIC_DEBUG_BUS_CMP(buf,"$$$$$$$$$$$$$$$$$$$$$$$$$ BrgHeader MisMatch DebugInfo: $$$$$$$$$$$$$$$$$$$$$$$$$ START\n");
         *first_flag = FALSE;
      }

      ASIC_DEBUG_BUS_CMP(buf,"%s mismatch <Actual = 0x%x, Expect = 0x%x>\n", name, c_field, v_field);

      return FALSE;
   }

   return TRUE;
}

static bool
_sim_cmp_cpu_header(outpkt_t *actual_node, outpkt_t *expect_node)
{
    bool ret = TRUE;
    uint8 *pkt = NULL;

    if (sal_memcmp(actual_node->pkt, expect_node->pkt, GREAT_BELT_CPUMAC_HDR_LEN) != 0)
    {
        pkt = actual_node->pkt;
        sal_printf("$$$$$$$$$$$$$$$$$$$$$$$$$ CPUHeader MisMatch DebugInfo: $$$$$$$$$$$$$$$$$$$$$$$$$ START\n");
        sal_printf("Expect CPUHeader = \n");
        sal_printf("MacDa   = 0x%02x%02x%02x%02x%02x%02x\n", pkt[0], pkt[1], pkt[2], pkt[3], pkt[4], pkt[5]);
        sal_printf("MacSa   = 0x%02x%02x%02x%02x%02x%02x\n", pkt[6], pkt[7], pkt[8], pkt[9], pkt[10], pkt[11]);
        sal_printf("VLANTAG = 0x%02x%02x%02x%02x\n", pkt[12], pkt[13], pkt[14], pkt[15]);
        sal_printf("EthType = 0x%02x%02x\n", pkt[16], pkt[17]);
        sal_printf("RSV     = 0x%02x%02x\n", pkt[18], pkt[19]);
        sal_printf("\n");

        pkt = expect_node->pkt;
        sal_printf("Actual CPUHeader = \n");
        sal_printf("MacDa   = 0x%02x%02x%02x%02x%02x%02x\n", pkt[0], pkt[1], pkt[2], pkt[3], pkt[4], pkt[5]);
        sal_printf("MacSa   = 0x%02x%02x%02x%02x%02x%02x\n", pkt[6], pkt[7], pkt[8], pkt[9], pkt[10], pkt[11]);
        sal_printf("VLANTAG = 0x%02x%02x%02x%02x\n", pkt[12], pkt[13], pkt[14], pkt[15]);
        sal_printf("EthType = 0x%02x%02x\n", pkt[16], pkt[17]);
        sal_printf("RSV     = 0x%02x%02x\n", pkt[18], pkt[19]);
        sal_printf("$$$$$$$$$$$$$$$$$$$$$$$$$ CPUHeader MisMatch DebugInfo: $$$$$$$$$$$$$$$$$$$$$$$$$ END\n");
        sal_printf("\n");
    }

    return ret;
}

static int32
_sim_cmp_bridge_header(outpkt_t *actual_node, outpkt_t *expect_node)
{

    bool ret = TRUE, first_flag = TRUE;
    ms_packet_header_t actual_brg_header;
    ms_packet_header_t expect_brg_header;

    sal_memcpy(&actual_brg_header, actual_node->pkt, sizeof(GREAT_BELT_HEADER_LEN));
    DRV_IF_ERROR_RETURN(swap32((uint32*)(&actual_brg_header), GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));

    sal_memcpy(&expect_brg_header, expect_node->pkt, sizeof(GREAT_BELT_HEADER_LEN));
    DRV_IF_ERROR_RETURN(swap32((uint32*)(&expect_brg_header), GREAT_BELT_HEADER_LEN/4, NETWORK_TO_HOST));

    ret &= _sim_cmp_field(actual_brg_header.dest_map, expect_brg_header.dest_map, "dest_map", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.packet_offset, expect_brg_header.packet_offset, "packet_offset", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.source_port15_14, expect_brg_header.source_port15_14, "source_port15_14", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.source_port, expect_brg_header.source_port, "source_port", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.src_ctag_offset_type, expect_brg_header.src_ctag_offset_type, "src_ctag_offset_type", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.logic_port_type, expect_brg_header.logic_port_type, "logic_port_type", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.header_hash2_0, expect_brg_header.header_hash2_0, "header_hash2_0", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.src_queue_select, expect_brg_header.src_queue_select, "src_queue_select", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.source_cos, expect_brg_header.source_cos, "source_cos", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.packet_type, expect_brg_header.packet_type, "packet_type", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.priority, expect_brg_header.priority, "priority", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.next_hop_ptr, expect_brg_header.next_hop_ptr, "next_hop_ptr", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.color, expect_brg_header.color, "color", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.src_vlan_id, expect_brg_header.src_vlan_id, "src_vlan_id", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.header_crc, expect_brg_header.header_crc, "header_crc", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.loopback_discard, expect_brg_header.loopback_discard, "loopback_discard", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.source_port_extender, expect_brg_header.source_port_extender, "source_port_extender", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.bypass_ingress_edit, expect_brg_header.bypass_ingress_edit, "bypass_ingress_edit", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.from_fabric, expect_brg_header.from_fabric, "from_fabric", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.ttl, expect_brg_header.ttl, "ttl", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.dm_ts36_29, expect_brg_header.dm_ts36_29, "dm_ts36_29", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.rxtx_fcl22_17, expect_brg_header.rxtx_fcl22_17, "rxtx_fcl22_17", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.critical_packet, expect_brg_header.critical_packet, "critical_packet", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.length_adjust_type, expect_brg_header.length_adjust_type, "length_adjust_type", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.src_cvlan_id, expect_brg_header.src_cvlan_id, "src_cvlan_id", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.src_cvlan_id_valid, expect_brg_header.src_cvlan_id_valid, "src_cvlan_id_valid", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.src_svlan_id_valid, expect_brg_header.src_svlan_id_valid, "src_svlan_id_valid", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.stag_action, expect_brg_header.stag_action, "stag_action", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.svlan_tpid_index, expect_brg_header.svlan_tpid_index, "svlan_tpid_index", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.from_cpu_or_oam, expect_brg_header.from_cpu_or_oam, "from_cpu_or_oam", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.non_crc, expect_brg_header.non_crc, "non_crc", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.next_hop_ext, expect_brg_header.next_hop_ext, "next_hop_ext", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.source_cfi, expect_brg_header.source_cfi, "source_cfi", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.svlan_tag_operation_valid, expect_brg_header.svlan_tag_operation_valid, "svlan_tag_operation_valid", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.pbb_src_port_type, expect_brg_header.pbb_src_port_type, "pbb_src_port_type", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.source_port_isolate_id, expect_brg_header.source_port_isolate_id, "source_port_isolate_id", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.fid, expect_brg_header.fid, "fid", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.src_vlan_ptr, expect_brg_header.src_vlan_ptr, "src_vlan_ptr", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.header_hash7_3, expect_brg_header.header_hash7_3, "header_hash7_3", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.operation_type, expect_brg_header.operation_type, "operation_type", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.rxtx_fcl0, expect_brg_header.rxtx_fcl0, "rxtx_fcl0", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.oam_tunnel_en, expect_brg_header.oam_tunnel_en, "oam_tunnel_en", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.mux_length_type, expect_brg_header.mux_length_type, "mux_length_type", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.rxtx_fcl2_1, expect_brg_header.rxtx_fcl2_1, "rxtx_fcl2_1", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.cut_through, expect_brg_header.cut_through, "cut_through", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.rxtx_fcl3, expect_brg_header.rxtx_fcl3, "rxtx_fcl3", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.logic_src_port, expect_brg_header.logic_src_port, "logic_src_port", &first_flag);
    ret &= _sim_cmp_field(actual_brg_header.ip_sa, expect_brg_header.ip_sa, "ip_sa", &first_flag);

    sal_printf("$$$$$$$$$$$$$$$$$$$$$$$$$ BrgHeader MisMatch DebugInfo: $$$$$$$$$$$$$$$$$$$$$$$$$ END\n");
    sal_printf("\n");

    return ret;

}
#endif
#endif

/*****************************************************************************************/

static int32
_sim_cmp_result_outpkt_linklist(list_head_t *actual_outpkt_linklist, list_head_t *expect_outpkt_linklist,
                                         bool *succ, uint8 is_full_pktlen)
{
    list_head_t *link_list1 = NULL, *link_list2 = NULL, *pos1 = NULL, *pos2 = NULL;
    outpkt_t *actual_node = NULL, *expect_node = NULL;
    bool match = TRUE;

    link_list1 = actual_outpkt_linklist;
    link_list2 = expect_outpkt_linklist;
    *succ = TRUE;

    list_for_each(pos1, link_list1)
    {
        /* get one node in actual link list */
        actual_node = list_entry(pos1, outpkt_t, head);

        /* search the same node in expect outpkt link list */
        list_for_each (pos2, link_list2)
        {
            expect_node = list_entry(pos2, outpkt_t, head);

#if (SDK_WORK_PLATFORM == 1)
#if 0
           /************* temp code to help check cpu case bridge header and cpu header ************/
            if ((actual_node->chan_id == CPU_CHANID)
                && (expect_node->chan_id == CPU_CHANID))
            {
                if (FALSE == _sim_cmp_cpu_header(actual_node, expect_node))
                {
                    *succ = FALSE;

                    return DRV_E_NONE;
                }

                if (FALSE == _sim_cmp_bridge_header(actual_node, expect_node))
                {
                    *succ = FALSE;

                    return DRV_E_NONE;
                }
            }
            /*****************************************************************************************/
#endif
#endif
            match = _sim_compare_outpkt_node(actual_node, expect_node);

            /* if find the match node */
            if (match)
            {
                /* free the node in actual link list */
                list_del(&actual_node->head);
                if (NULL != actual_node)
                {
                     sal_free(actual_node->pkt);
                     actual_node->pkt = NULL;
                     sal_free(actual_node);
                     actual_node = NULL;
                }
                /* ajust search actual link list ptr */
                pos1 = link_list1;

                /* free the node in expect link list */
                list_del(&expect_node->head);
                if (NULL != expect_node)
                {
                     sal_free(expect_node->pkt);
                     expect_node->pkt = NULL;
                     sal_free(expect_node);
                     expect_node = NULL;
                }
                /* ajust search expect link list ptr */
                pos2 = link_list2;

                /* has match, do not need search expect linklist , jump to the last packet match processing */
                break;
            }
        }

        /* if no find the same node in the expect link list */
        if (match == FALSE)
        {
            *succ = FALSE;

            return DRV_E_NONE;
        }
    }

    if (is_full_pktlen)
    {
        /* finish serch those nodes in actual linklist,  check if the expect link list is empty */
        if (!(list_empty(link_list1)) || !(list_empty(link_list2)) )
        {
            CMODEL_DEBUG_OUT_INFO("\nOutpkt/expectPkt link list still has pkt!\n");
            *succ = FALSE;
        }
    }

    return DRV_E_NONE;
}

static int32
sim_whole_packet_compare_get_packet_len_cfg(uint8* is_full_pktlen)
{
    #define REGRESSION_PACKET_LEN_FILE_PATH "/../../regression/packet_len_cfg/pkt_len.tmp"
    char pktlen_profile_path[256] = {0};
    uint32 size_tmp = 0;
    char *buf_tmp = NULL;
    FILE* fp = NULL;
    char string[128] = {0};

    size_tmp = pathconf(".", _PC_PATH_MAX);
    if ((buf_tmp = (char *)sal_malloc((size_t)size_tmp)) != NULL)
    {
        if (NULL == getcwd(buf_tmp, (size_t)size_tmp))
        {
            CMODEL_DEBUG_OUT_INFO("$$$ Fail to get Current directory path when getting pkt length config file\n");
        }
    }
    sal_memset(pktlen_profile_path, 0, sizeof(pktlen_profile_path));
    sal_strcpy(pktlen_profile_path, buf_tmp);
    sal_strcat(pktlen_profile_path, REGRESSION_PACKET_LEN_FILE_PATH);

    CMODEL_DEBUG_OUT_INFO("Packet Length File Path: %s\n", pktlen_profile_path);

    fp = fopen(pktlen_profile_path, "r");
    if((NULL == fp) || feof(fp))
    {
        if (fp != NULL)
        {
            fclose(fp);
            fp = NULL;
        }
    }
    else
    {
        /* parse profile */
        while(!feof(fp))
        {
            sal_memset(string, 0, sizeof(string));
            fgets(string, 128, fp);

            /* comment line */
            if ('#' == string[0])
            {
              continue;
            }

            if (EMPTY_LINE(string[0]))
            {
              continue;
            }

            /*parse key info*/
            if(0 != sal_strstr(string, "full"))
            {
                *is_full_pktlen = TRUE;
                CMODEL_DEBUG_OUT_INFO("$$$$ Use full packet length from packet length configuration file! \n");
            }
            else if (0 != sal_strstr(string, "64"))
            {
                *is_full_pktlen = FALSE;
                CMODEL_DEBUG_OUT_INFO("$$$$ Use 64B packet length from packet length configuration file! \n");
            }
            else if (0 != sal_strstr(string, "65"))
            {
                *is_full_pktlen = FALSE;
                CMODEL_DEBUG_OUT_INFO("$$$$ Use 65B packet length from packet length configuration file! \n");
            }
            else if (0 != sal_strstr(string, "97"))
            {
                *is_full_pktlen = FALSE;
                CMODEL_DEBUG_OUT_INFO("$$$$ Use 97B packet length from packet length configuration file! \n");
            }
            else if (0 != sal_strstr(string, "225"))
            {
                *is_full_pktlen = FALSE;
                CMODEL_DEBUG_OUT_INFO("$$$$ Use 225B packet length from packet length configuration file! \n");
            }
            else if (0 != sal_strstr(string, "1518"))
            {
                *is_full_pktlen = FALSE;
                CMODEL_DEBUG_OUT_INFO("$$$$ Use 1518B packet length from packet length configuration file! \n");
            }
            else
            {
                CMODEL_DEBUG_OUT_INFO("$$$$ INVALID packet length from packet length configuration file! \n");
                CMODEL_DEBUG_OUT_INFO("$$$$ Use full packet length! \n");
                *is_full_pktlen = TRUE;
            }
            if (fp != NULL)
            {
                fclose(fp);
                fp = NULL;
            }
            return DRV_E_NONE;
        }
    }

    CMODEL_DEBUG_OUT_INFO("$$$$ Packet Length Configuration formate is not right! Use full packet length! \n");
    *is_full_pktlen = TRUE;

    if (fp != NULL)
    {
        fclose(fp);
        fp = NULL;
    }

    return DRV_E_NONE;
}

static uint16
_uint16_chksum (uint16 *start, uint16 length, uint32 init)
{
    uint32 sum = init;
    uint16 len = length >> 1;

    while (len-- > 0)
        sum += ntohs(*start++);


    if (length & 1)
        sum += (ntohs(*start) & 0xFF00);

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);

    len = sum & 0xFFFF;
    return(~len);
}
static void
_sim_check_outpkt_total_length(list_head_t *outpkt_list, bool *succ, chk_total_length_flag_t *ignor_total_length)
{
#define CRC_LENGTH 4
    outpkt_t *outpkt_ptr = NULL;
    list_head_t *pos = NULL;
    uint32 i = 0,hdr_start_pos = 0;
    bool is_ip = FALSE;
    uint32 layer3_protocol = 0;
    uint8 packet[MTU] = {0};
    uint32 ip_len = 0;
    uint32 pkt_no = 0, chan_id = 0;
    uint32 whole_pkt_len = 0;
    uint32 header_len = 0,expect_total_len = 0,real_total_len = 0;

    *succ = TRUE;

    if (ignor_total_length->ignore_ipv4_total_length
        && ignor_total_length->ignore_ipv6_total_length
        && ignor_total_length->ignore_udp_total_length)
    {
        return;
    }

    CMODEL_DEBUG_OUT_INFO("\n++++++++ OUTPKT TotalLength check Start! ++++++++\n");
    CMODEL_DEBUG_OUT_INFO("\n");

    list_for_each(pos, outpkt_list)
    {
        pkt_no++;
        outpkt_ptr = list_entry(pos, outpkt_t, head);
        sal_memset(packet, 0, MTU);
        sal_memcpy(packet, outpkt_ptr->pkt, outpkt_ptr->packet_length);
        whole_pkt_len = outpkt_ptr->packet_length;

        if (outpkt_ptr->chan_id == CPU_CHANID)
        {
            i = GREAT_BELT_CPUMAC_HDR_LEN + GREAT_BELT_HEADER_LEN;
        }
        else if ((outpkt_ptr->chan_id == OAM_CHANID) /* need to consider cross chip with bheader(l2header), add by zhouw ??*/
             || (outpkt_ptr->chan_id == INTERLAKEN_CHANID))
        {
            i = GREAT_BELT_HEADER_LEN;
        }
        else
        {
            i = 0;
        }

        chan_id = outpkt_ptr->chan_id;
        for (; i < (outpkt_ptr->packet_length - CRC_LENGTH); i++)
        {
            if (((packet[i] == 0x88) && (packet[i+1] == 0x47))
                || ((packet[i] == 0x88) && (packet[i+1] == 0x48))) /* MPLS packet do not check! TBD ??? */
            {
                CMODEL_DEBUG_OUT_INFO("++++++++ OUTPKT CheckSum check Done! ++++++++\n");
                CMODEL_DEBUG_OUT_INFO("\n");
                return;
            }

            if (((packet[i] == 0x08) && (packet[i+1] == 0) && ((packet[i+2] & 0xF0) == 0x40))
                || ((layer3_protocol == 4) && is_ip)) /* v4inv4 or v4inv6 */
            {
                /* find IPv4 Header,total length = layload length + headerlength */
                is_ip = TRUE;

                if ((packet[i] == 0x08) && (packet[i+1] == 0) && ((packet[i+2] & 0xF0) == 0x40))
                {
                    hdr_start_pos = i+2;
                }
                else
                {
                    hdr_start_pos = i;
                }

                /* get info in ipv4 */
                header_len= ((packet[hdr_start_pos] & 0xF) << 2);

                /* total length = layload length + headerlength */
                real_total_len = MAKE_UINT16(packet[hdr_start_pos+2], packet[hdr_start_pos+3]);
                expect_total_len = whole_pkt_len - hdr_start_pos - 4;  /* exclude crc length  */

                if (!ignor_total_length->ignore_ipv4_total_length)
                {
                    if (real_total_len != expect_total_len)
                    {
                        *succ = FALSE;
                        CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt IPV4 TotalLength check FAIL!\n", chan_id, pkt_no);
                        CMODEL_DEBUG_OUT_INFO("Real: 0x%04x; Expect: 0x%04x!\n", real_total_len, expect_total_len);
                        CMODEL_DEBUG_OUT_INFO("\n");
                    }
                    else
                    {
                        CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt IPV4 TotalLength check OK!\n", chan_id, pkt_no);
                        CMODEL_DEBUG_OUT_INFO("\n");
                    }
                }
                ip_len = 32/8;
                layer3_protocol = packet[hdr_start_pos+9];

                i = hdr_start_pos;
                i += (header_len - 1);
            }
            else if (((packet[i] == 0x86) && (packet[i+1] == 0xDD))
                || ((layer3_protocol == 41) && is_ip)) /* v6inv4 or v6inv6 */
            {
                /* find IPv6 Header,total length = payload length */
                is_ip = TRUE;

                if ((packet[i] == 0x86) && (packet[i+1] == 0xDD))
                {
                    hdr_start_pos = i+2;
                }
                else
                {
                    hdr_start_pos = i;
                }

                header_len = 40;

                /* total length = payload length */
                real_total_len = MAKE_UINT16(packet[hdr_start_pos+4], packet[hdr_start_pos+5]);
                expect_total_len = whole_pkt_len - hdr_start_pos - 40 - 4;  /* exclude crc length  */

                if (!ignor_total_length->ignore_ipv6_total_length)
                {
                    if (real_total_len != expect_total_len)
                    {
                        *succ = FALSE;
                        CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt IPV6 TotalLength check FAIL!\n", chan_id, pkt_no);
                        CMODEL_DEBUG_OUT_INFO("Real: 0x%04x; Expect: 0x%04x!\n", real_total_len, expect_total_len);
                        CMODEL_DEBUG_OUT_INFO("\n");
                    }
                    else
                    {
                        CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt IPV6 TotalLength check OK!\n", chan_id, pkt_no);
                        CMODEL_DEBUG_OUT_INFO("\n");
                    }
                }

                ip_len = 128/8;
                layer3_protocol = packet[hdr_start_pos+6];

                i = hdr_start_pos;
                i += (header_len - 1);
            }
            else if (is_ip && (layer3_protocol == 6))  /* is TCP */
            {
                if (!ignor_total_length->ignore_udp_total_length)
                {

                }

                is_ip = FALSE;
                layer3_protocol = 0;
            }
            else if (is_ip && (layer3_protocol == 17)) /* is UDP */
            {
                if (!ignor_total_length->ignore_udp_total_length)
                {
                    hdr_start_pos = i;

                    header_len = 8;

                    /* total length = layload length + headerlength */
                    real_total_len = MAKE_UINT16(packet[hdr_start_pos+4], packet[hdr_start_pos+5]);
                    expect_total_len = whole_pkt_len - hdr_start_pos - 4;  /* exclude crc length  */

                    if (!ignor_total_length->ignore_udp_total_length)
                    {
                        if (real_total_len != expect_total_len)
                        {
                            *succ = FALSE;
                            CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt UDP TotalLength check FAIL!\n", chan_id, pkt_no);
                            CMODEL_DEBUG_OUT_INFO("Real: 0x%04x; Expect: 0x%04x!\n", real_total_len, expect_total_len);
                            CMODEL_DEBUG_OUT_INFO("\n");
                        }
                        else
                        {
                            CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt UDP TotalLength check OK!\n", chan_id, pkt_no);
                            CMODEL_DEBUG_OUT_INFO("\n");
                        }
                    }
                }

                is_ip = FALSE;
                layer3_protocol = 0;
            }
        }
    }

    CMODEL_DEBUG_OUT_INFO("++++++++ OUTPKT TotalLength check Done! ++++++++\n");
    CMODEL_DEBUG_OUT_INFO("\n");

    return;
}


static void
_sim_check_outpkt_checksum(list_head_t *outpkt_list, bool *succ, chk_checksum_flag_t *ignor_check_sum)
{
    outpkt_t *outpkt_ptr = NULL;
    list_head_t *pos = NULL;
    uint16 rl_chk_sum = 0, expect_chk_sum = 0;
    uint32 i = 0, hdr_len = 0, hdr_start_pos = 0, ihl = 0;
    bool is_ip = FALSE;
    uint32 layer3_protocol = 0;
    uint8 packet[MTU] = {0};
    uint32 ip_len = 0;
    uint32 ipsa_pos = 0, ipda_pos = 0;
    uint32 pkt_no = 0, chan_id = 0;

    *succ = TRUE;

    if (ignor_check_sum->ignore_ip_checksum
        && ignor_check_sum->ignore_tcp_checksum
        && ignor_check_sum->ignore_udp_checksum)
    {
        return;
    }

    CMODEL_DEBUG_OUT_INFO("\n++++++++ OUTPKT CheckSum check Start! ++++++++\n");
    CMODEL_DEBUG_OUT_INFO("\n");

    list_for_each(pos, outpkt_list)
    {
        pkt_no++;
        outpkt_ptr = list_entry(pos, outpkt_t, head);
        sal_memset(packet, 0, MTU);
        sal_memcpy(packet, outpkt_ptr->pkt, outpkt_ptr->packet_length);

        if (outpkt_ptr->chan_id == CPU_CHANID)
        {
            i = GREAT_BELT_CPUMAC_HDR_LEN + GREAT_BELT_HEADER_LEN;
        }
        else if ((outpkt_ptr->chan_id == OAM_CHANID) /* need to consider cross chip with bheader(l2header), add by zhouw ??*/
             || (outpkt_ptr->chan_id == INTERLAKEN_CHANID))
        {
            i = GREAT_BELT_HEADER_LEN;
        }
        else
        {
            i = 0;
        }

        chan_id = outpkt_ptr->chan_id;
        for (; i < outpkt_ptr->packet_length; i++)
        {
            if (((packet[i] == 0x88) && (packet[i+1] == 0x47))
                || ((packet[i] == 0x88) && (packet[i+1] == 0x48))) /* MPLS packet do not check! TBD ??? */
            {
                CMODEL_DEBUG_OUT_INFO("++++++++ OUTPKT CheckSum check Done! ++++++++\n");
                CMODEL_DEBUG_OUT_INFO("\n");
                return;
            }

            if (((packet[i] == 0x08) && (packet[i+1] == 0) && ((packet[i+2] & 0xF0) == 0x40))
                || ((layer3_protocol == 4) && is_ip)) /* v4inv4 or v4inv6 */
            {
                /* find IPv4 Header */
                is_ip = TRUE;

                if ((packet[i] == 0x08) && (packet[i+1] == 0) && ((packet[i+2] & 0xF0) == 0x40))
                {
                    hdr_start_pos = i+2;
                }
                else
                {
                    hdr_start_pos = i;
                }

                /* get info in ip */
                hdr_len = MAKE_UINT16(packet[hdr_start_pos+2], packet[hdr_start_pos+3]);
                ihl = packet[hdr_start_pos]&0xF;
                ipda_pos = hdr_start_pos+16;
                ipsa_pos = hdr_start_pos+12;

                rl_chk_sum = MAKE_UINT16(packet[hdr_start_pos+10], packet[hdr_start_pos+11]);
                sal_memset(packet+hdr_start_pos+10, 0, 2);
                expect_chk_sum = _uint16_chksum((uint16 *)(packet+hdr_start_pos), ihl*4, 0);
                if (!ignor_check_sum->ignore_ip_checksum)
                {
                    if (rl_chk_sum != expect_chk_sum)
                    {
                        *succ = FALSE;
                        CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt IPV4 CheckSum check FAIL!\n", chan_id, pkt_no);
                        CMODEL_DEBUG_OUT_INFO("Real: 0x%04x; Expect: 0x%04x!\n", rl_chk_sum, expect_chk_sum);
                        CMODEL_DEBUG_OUT_INFO("\n");
                        //return;
                    }
                    else
                    {
                        CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt IPV4 CheckSum check OK!\n", chan_id, pkt_no);
                        CMODEL_DEBUG_OUT_INFO("\n");
                    }
                }
                ip_len = 32/8;
                layer3_protocol = packet[hdr_start_pos+9];

                i = hdr_start_pos;
                i += (ihl*4 - 1);
               // i += ihl*4;
            }
            else if ((packet[i] == 0x86) && (packet[i+1] == 0xDD))
            {
                /* find IPv6 Header (no checksum) */
                is_ip = TRUE;
                hdr_len = 40;
                hdr_start_pos = i+2;

                ipda_pos = hdr_start_pos+24;
                ipsa_pos = hdr_start_pos+8;

                ip_len = 128/8;
                layer3_protocol = packet[hdr_start_pos+6];

                i = hdr_start_pos;
                i += (hdr_len - 1);
            }
            else if (is_ip && (layer3_protocol == 6))  /* is TCP */
            {
                if (!ignor_check_sum->ignore_tcp_checksum)
                {
                    uint32 j;
                    uint32 pseudo_header_checksum = 0;

                    rl_chk_sum = MAKE_UINT16(packet[i+16], packet[i+17]);
                    sal_memset(packet+i+16, 0, 2); /* clear old checksum */

                    for (j = 0; j < ip_len; j+=2)
                    {
                        pseudo_header_checksum += ntohs(*(uint16*)(packet + ipsa_pos + j));
                    }

                    for (j = 0; j < ip_len; j+=2)
                    {
                        pseudo_header_checksum += ntohs(*(uint16*)(packet + ipda_pos + j));
                    }

                    pseudo_header_checksum += 6;
                    pseudo_header_checksum += outpkt_ptr->packet_length-i-4;
                    expect_chk_sum
                        = _uint16_chksum((uint16 *)(packet+i), outpkt_ptr->packet_length-i-4, pseudo_header_checksum);

                    if (rl_chk_sum != expect_chk_sum)
                    {
                        *succ = FALSE;
                        CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt TCP CheckSum check FAIL!\n", chan_id, pkt_no);
                        CMODEL_DEBUG_OUT_INFO("Real: 0x%04x; Expect: 0x%04x!\n", rl_chk_sum, expect_chk_sum);
                        CMODEL_DEBUG_OUT_INFO("\n");
                        //return;
                    }
                    else
                    {
                        CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt TCP CheckSum check OK!\n", chan_id, pkt_no);
                        CMODEL_DEBUG_OUT_INFO("\n");
                    }
                }

                is_ip = FALSE;
                layer3_protocol = 0;

                ipsa_pos = 0;
                ipda_pos = 0;
            }
            else if (is_ip && (layer3_protocol == 17)) /* is UDP */
            {
                if (!ignor_check_sum->ignore_udp_checksum)
                {
                    uint32 j;
                    uint32 pseudo_header_checksum = 0;

                    rl_chk_sum = MAKE_UINT16(packet[i+6], packet[i+7]);
                    sal_memset(packet+i+6, 0, 2); /* clear old checksum */

                    for (j = 0; j < ip_len; j+=2)
                    {
                        pseudo_header_checksum += ntohs(*(uint16*)(packet + ipsa_pos + j));
                    }

                    for (j = 0; j < ip_len; j+=2)
                    {
                        pseudo_header_checksum += ntohs(*(uint16*)(packet + ipda_pos + j));
                    }

                    pseudo_header_checksum += 17;
                    pseudo_header_checksum += outpkt_ptr->packet_length - i - 4;
                    expect_chk_sum
                        = _uint16_chksum((uint16 *)(packet+i), outpkt_ptr->packet_length-i-4, pseudo_header_checksum);
                       // = memcpy_chksum((packet+i), &data16, 2);

                    if (rl_chk_sum &&(rl_chk_sum != expect_chk_sum))
                    {
                        *succ = FALSE;
                        CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt UDP CheckSum check FAIL!\n", chan_id, pkt_no);
                        CMODEL_DEBUG_OUT_INFO("Real: 0x%04x; Expect: 0x%04x!\n", rl_chk_sum, expect_chk_sum);
                        CMODEL_DEBUG_OUT_INFO("\n");
                        //return;
                    }
                    else
                    {
                        CMODEL_DEBUG_OUT_INFO("ChanID%d_NO%d_outpkt UDP CheckSum check OK!\n", chan_id, pkt_no);
                        CMODEL_DEBUG_OUT_INFO("\n");
                    }
                }

                is_ip = FALSE;
                layer3_protocol = 0;

                ipsa_pos = 0;
                ipda_pos = 0;
            }
        }
    }

    CMODEL_DEBUG_OUT_INFO("++++++++ OUTPKT CheckSum check Done! ++++++++\n");
    CMODEL_DEBUG_OUT_INFO("\n");

    return;
}

/*****************************************************************************
 * Name   : sim_compare_file
 * Purpose: compare content of two files
 * Input  : file1, file2: the names of the two files
 * Output : N/A
 * Return : SUCCESS
 *          Other = ErrCode
 * Note   : N/A
 *****************************************************************************/
int32
sim_whole_compare_file(char *file1, char *file2, chk_checksum_flag_t *ignor_check_sum,chk_total_length_flag_t *ignor_total_length)
{
    #define MAX_LINE_LEN_IN_FILE 512

    FILE* fp_file1 = NULL;
    FILE* fp_file2 = NULL;
    int32 ret = DRV_E_NONE;
    list_head_t actual_outpkt_linklist;
    list_head_t expect_outpkt_linklist;
    list_head_t *pos = NULL;
    uint32 actual_total_outpkt_num = 0, expect_total_outpkt_num = 0, expect_total_outpkt_num_tmp = 0;
    bool cmp_succ = TRUE;
    outpkt_t *outpkt_ptr = NULL;

    uint8 is_full_pktlen = TRUE;

    DRV_IF_ERROR_RETURN(sim_whole_packet_compare_get_packet_len_cfg(&is_full_pktlen));

    /* open cmp file */
    fp_file1 = fopen(file1, "r");
    fp_file2 = fopen(file2, "r");
    INIT_LIST_HEAD(&actual_outpkt_linklist);
    INIT_LIST_HEAD(&expect_outpkt_linklist);

    if ((NULL == fp_file1) && (NULL == fp_file2))               /* actual and expect both no outpkt */
    {
        CMODEL_DEBUG_OUT_INFO("\nActual and Expect both no output packet!\n");
        sal_printf("PASSED %s\n", file1);
    }
    else if ((NULL == fp_file1) && (NULL != fp_file2))       /* actual no outpkt, expect  has outpkt */
    {
        CMODEL_DEBUG_OUT_INFO("\nActual no output packet, Expect has output packet!\n");
        sal_printf("FAILED %s\n", file1);
    }
    else if ((NULL != fp_file1) && (NULL == fp_file2))      /* actual has outpkt, expect no outpkt */
    {
        CMODEL_DEBUG_OUT_INFO("\nActual has output packet, Expect no output packet!\n");
        sal_printf("FAILED %s\n", file1);
    }
    else
    {
        ret = _sim_get_outpkt_linklist_from_outpkt_file(&actual_outpkt_linklist, fp_file1, &actual_total_outpkt_num);
        if (ret < 0)
        {
            sal_printf("FAILED : Get info from file %s error!\n", file1);
            goto RELEASE_FILE;
        }

        ret = _sim_get_outpkt_linklist_from_outpkt_file(&expect_outpkt_linklist, fp_file2, &expect_total_outpkt_num);
        if (ret < 0)
        {
            sal_printf("FAILED : Get info from file %s error!\n", file2);
            goto RELEASE_FILE;
        }

        /* check real outpkt checksum if is v4 v6 tcp udp packet (need to consider tunnel) */
        _sim_check_outpkt_checksum(&actual_outpkt_linklist, &cmp_succ, ignor_check_sum);
        if (cmp_succ == FALSE)
        {
            sal_printf("FAILED : Check outpkt checksum and crc error!\n");
            goto RELEASE_FILE;
        }

        /* check real outpkt totallength if is v4 v6 tcp udp packet (need to consider tunnel) */
        _sim_check_outpkt_total_length(&actual_outpkt_linklist, &cmp_succ, ignor_total_length);
        if (cmp_succ == FALSE)
        {
            sal_printf("FAILED : Check outpkt totallength error!\n");
            goto RELEASE_FILE;
        }

        cmp_succ = FALSE;
        expect_total_outpkt_num_tmp = expect_total_outpkt_num;
        ret = _sim_cmp_result_outpkt_linklist(&actual_outpkt_linklist, &expect_outpkt_linklist,
                                              &cmp_succ, is_full_pktlen);
        if (ret < 0)
        {
            goto RELEASE_FILE;
        }


        if (cmp_succ == FALSE)
        {
            sal_printf("FAILED %s\n", file1);
        }
        else
        {
            sal_printf("PASSED %s\n", file1);
        }
    }

RELEASE_FILE:
    /* release all link list and node memory */
    if (!(list_empty(&actual_outpkt_linklist)))
    {
        list_for_each(pos, &actual_outpkt_linklist)
        {
            outpkt_ptr = list_entry(pos, outpkt_t, head);
            if (NULL != outpkt_ptr)
            {
                list_del(&outpkt_ptr->head);
                sal_free(outpkt_ptr->pkt);
                outpkt_ptr->pkt = NULL;
                sal_free(outpkt_ptr);
                outpkt_ptr = NULL;
            }
            pos = &actual_outpkt_linklist;
        }
    }

    if (!(list_empty(&expect_outpkt_linklist)))
    {
        list_for_each(pos, &expect_outpkt_linklist)
        {
            outpkt_ptr = list_entry(pos, outpkt_t, head);
            if (NULL != outpkt_ptr)
            {
                list_del(&outpkt_ptr->head);
                sal_free(outpkt_ptr->pkt);
                outpkt_ptr->pkt = NULL;
                sal_free(outpkt_ptr);
                outpkt_ptr = NULL;
            }
            pos = &expect_outpkt_linklist;
        }
    }

    if (NULL != fp_file1)
    {
        fclose(fp_file1);
        fp_file1 = NULL;
    }

    if (NULL != fp_file2)
    {
        fclose(fp_file2);
        fp_file2 = NULL;
    }

    return ret;
}

/**
 @brief cmodel cli use to creat check discard result file
*/
int32
sim_discard_check_file(char *file_name)
{
    unlink(file_discard_check_result);
    sal_memset(file_discard_check_result, 0, sizeof(file_discard_check_result));

    if (file_name)
    {
        sal_memcpy(file_discard_check_result, file_name, sal_strlen(file_name));
    }
    else
    {
        sal_strcpy(file_discard_check_result, "");
    }

    return DRV_E_NONE;
}

/**
 @brief cmodel cli use to creat all check discard is null result file
*/
int32
sim_creat_check_no_any_discard_result_file(char *file_name)
{
    unlink(file_no_discard_check_result);
    sal_memset(file_no_discard_check_result, 0, sizeof(file_no_discard_check_result));

    if (file_name)
    {
        sal_memcpy(file_no_discard_check_result, file_name, sal_strlen(file_name));
    }
    else
    {
        sal_strcpy(file_no_discard_check_result, "");
    }

    return DRV_E_NONE;
}

/**
 @brief cmodel cli use to creat learning_tbl_isnull result file
*/
int32
sim_check_table_is_null_result_file(char *file_name)
{
    unlink(file_tbl_isnull_check_result);
    sal_memset(file_tbl_isnull_check_result, 0, sizeof(file_tbl_isnull_check_result));

    if (file_name)
    {
        sal_memcpy(file_tbl_isnull_check_result, file_name, sal_strlen(file_name));
    }
    else
    {
        sal_strcpy(file_tbl_isnull_check_result, "");
    }

    return DRV_E_NONE;
}

/**
 @brief cmodel cli use to check some fixed discard type
*/
int32 sim_check_discard_type(uint32 chipid, uint32 moduleid,
                            uint32 discard_type, bool is_pkt_cnt, uint32 cnt)
{
    int32 ret = DRV_E_NONE;

    ipe_fwd_discard_type_stats_t ipe_fwd_discard_type_stats;
    epe_hdr_edit_discard_type_stats_t epe_hdr_edit_discard_type_stats;
    tbls_id_t table_id = MaxTblId_t;

    uint32 cmd = 0;
    uint8 result_ok = FALSE;

    if (moduleid == DISCARD_CHECK_IPE_MODULE)
    {
        table_id = IpeFwdDiscardTypeStats_t;
        cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);
        sal_memset(&ipe_fwd_discard_type_stats, 0, sizeof(ipe_fwd_discard_type_stats));
        DRV_IF_ERROR_RETURN(CM_IOCTL(chipid, discard_type, cmd, &ipe_fwd_discard_type_stats));
    }
    else if (moduleid == DISCARD_CHECK_EPE_MODULE)
    {
        table_id = EpeHdrEditDiscardTypeStats_t;
        cmd = DRV_IOR(table_id, DRV_ENTRY_FLAG);
        sal_memset(&epe_hdr_edit_discard_type_stats, 0, sizeof(epe_hdr_edit_discard_type_stats));
        DRV_IF_ERROR_RETURN(CM_IOCTL(chipid, discard_type, cmd, &epe_hdr_edit_discard_type_stats));
    }


    if (is_pkt_cnt)  /* check the discardType packets count */
    {

        if (moduleid == DISCARD_CHECK_IPE_MODULE)
        {
            if (ipe_fwd_discard_type_stats.discard_pkt_cnt == cnt)
            {
                result_ok = TRUE;
                CMODEL_DEBUG_OUT_INFO("+++++ IPE discardType %d check pass (PktCnt check)!\n", discard_type);
                sal_printf("PASSED! IPE Check DiscardType %d Passed (PktCnt check)!\n", discard_type);
            }
            else
            {
                result_ok = FALSE;
                CMODEL_DEBUG_OUT_INFO("++++++ IPE discardType %d check FAILED (PktCnt check)!\n", discard_type);
                CMODEL_DEBUG_OUT_INFO("+++++ RealPktCount = %d, ExpectPktCount = %d!\n",
                                  ipe_fwd_discard_type_stats.discard_pkt_cnt, cnt);
                sal_printf("FAILED! IPE Check DiscardType %d Failed (PktCnt check)!\n", discard_type);
            }
        }
        else
        {
            if (epe_hdr_edit_discard_type_stats.discard_pkt_cnt == cnt)
            {
                result_ok = TRUE;
                CMODEL_DEBUG_OUT_INFO("+++++ EPE discardType %d check pass (PktCnt check)!\n", discard_type);
                sal_printf("PASSED! EPE Check DiscardType %d Passed (PktCnt check)!\n", discard_type);
            }
            else
            {
                result_ok = FALSE;
                CMODEL_DEBUG_OUT_INFO("++++++ EPE discardType %d check FAILED (PktCnt check)!\n", discard_type);
                CMODEL_DEBUG_OUT_INFO("+++++ RealPktCount = %d, ExpectPktCount = %d!\n",
                                      epe_hdr_edit_discard_type_stats.discard_pkt_cnt, cnt);
                sal_printf("FAILED! EPE Check DiscardType %d Failed (PktCnt check)!\n", discard_type);
            }
        }
    }
    else           /* check the discardType Bytes count */
    {
#if COSIM_PENDING
        /* zhouw note: because of no bytes count!!! check it?? */
        if (moduleid == DISCARD_CHECK_IPE_MODULE)
        {
            if (ipe_fwd_discard_type_stats.discard_bytes_cnt == cnt)
            {
                CMODEL_DEBUG_OUT_INFO("+++++ IPE discardType %d check pass (ByteCnt check)!\n", discard_type);
                sal_printf("PASSED! IPE Check DiscardType %d Passed (ByteCnt check)!\n", discard_type);
            }
            else
            {
                CMODEL_DEBUG_OUT_INFO("++++++ IPE discardType %d check FAILED (ByteCnt check)!\n", discard_type);
                CMODEL_DEBUG_OUT_INFO("+++++ RealByteCount = %d, ExpectByteCount = %d!\n",
                                  ipe_fwd_discard_type_stats.discard_bytes_cnt, cnt);
                sal_printf("FAILED! IPE Check DiscardType %d Failed (ByteCnt check)!\n", discard_type);
            }
        }
        else
        {
            if (epe_hdr_edit_discard_type_stats.discard_byte_cnt == cnt)
            {
                CMODEL_DEBUG_OUT_INFO("+++++ EPE discardType %d check pass (ByteCnt check)!\n", discard_type);
                sal_printf("PASSED! EPE Check DiscardType %d Passed (ByteCnt check)!\n", discard_type);
            }
            else
            {
                CMODEL_DEBUG_OUT_INFO("++++++ EPE discardType %d check FAILED (ByteCnt check)!\n", discard_type);
                CMODEL_DEBUG_OUT_INFO("+++++ RealByteCount = %d, ExpectByteCount = %d!\n",
                                      epe_hdr_edit_discard_type_stats.discard_byte_cnt, cnt);
                sal_printf("FAILED! EPE Check DiscardType %d Failed (ByteCnt check)!\n", discard_type);
            }
        }
#endif
    }

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);

    if (moduleid == DISCARD_CHECK_IPE_MODULE)
    {
        sal_memset(&ipe_fwd_discard_type_stats, 0, sizeof(ipe_fwd_discard_type_stats));
        DRV_IF_ERROR_RETURN(CM_IOCTL(chipid, discard_type, cmd, &ipe_fwd_discard_type_stats));
    }
    else
    {
        sal_memset(&epe_hdr_edit_discard_type_stats, 0, sizeof(epe_hdr_edit_discard_type_stats));
        DRV_IF_ERROR_RETURN(CM_IOCTL(chipid, discard_type, cmd, &epe_hdr_edit_discard_type_stats));
    }

    if (result_ok == TRUE)
    {
        sal_printf("PASSED! Check discard type Passed!\n");
    }
    else
    {
        sal_printf("FAILED! Check discard type Failed!\n");
    }

#if (SDK_WORK_PLATFORM == 1)
    uint8 chipid_base = 0;
    DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chipid_base));
    drv_model_sram_tbl_clear_wbit((chipid - chipid_base), table_id, discard_type);
#endif


    return ret;
}

int32
sim_check_all_discard_type_is_null(uint32 chipid)
{
    int32 ret = DRV_E_NONE;

    ipe_fwd_discard_type_stats_t ipe_fwd_discard_type_stats;
    epe_hdr_edit_discard_type_stats_t epe_hdr_edit_discard_type_stats;

    uint32 cmd_ipe = 0, cmd_epe = 0;
    uint32 i = 0, j = 0;
    uint32 ipe_discard_type_num = 0, epe_discard_type_num = 0;
    tbls_id_t ipe_table_id = MaxTblId_t;
    tbls_id_t epe_table_id = MaxTblId_t;
    bool is_failed = FALSE;

    ipe_table_id = IpeFwdDiscardTypeStats_t;
    epe_table_id = EpeHdrEditDiscardTypeStats_t;

    /* init */
    ipe_discard_type_num = IPE_DISCARD_TYPE_MAX_NUM;
    epe_discard_type_num = EPE_DISCARD_TYPE_MAX_NUM;

    while ((i < ipe_discard_type_num) || (j < epe_discard_type_num))
    {
        if (i < ipe_discard_type_num)
        {
            cmd_ipe = DRV_IOR(ipe_table_id, DRV_ENTRY_FLAG);
            sal_memset(&ipe_fwd_discard_type_stats, 0, sizeof(ipe_fwd_discard_type_stats));
            DRV_IF_ERROR_RETURN(CM_IOCTL(chipid, i, cmd_ipe, &ipe_fwd_discard_type_stats));

            if (ipe_fwd_discard_type_stats.discard_pkt_cnt != 0)
            {
                CMODEL_DEBUG_OUT_INFO("++++++ IPE discardType %d check FAILED, is not NULL!\n", i);
                CMODEL_DEBUG_OUT_INFO("++++++ IPE discardType %d discard_pkt_cnt = %d!\n",
                                      i, ipe_fwd_discard_type_stats.discard_pkt_cnt);
                if (!is_failed)
                {
                    is_failed = TRUE;
                }
                sal_printf("FAILED! IPE Check DiscardType %d Failed!\n", i);
            }

            /* clean */
            cmd_ipe = DRV_IOW(ipe_table_id, DRV_ENTRY_FLAG);
            sal_memset(&ipe_fwd_discard_type_stats, 0, sizeof(ipe_fwd_discard_type_stats));
            DRV_IF_ERROR_RETURN(CM_IOCTL(chipid, i, cmd_ipe, &ipe_fwd_discard_type_stats));

#if (SDK_WORK_PLATFORM == 1)
            uint8 chipid_base = 0;
            DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chipid_base));
            drv_model_sram_tbl_clear_wbit((chipid - chipid_base), ipe_table_id, i);
#endif
            i++;
        }

        if (j < epe_discard_type_num)
        {
            cmd_epe = DRV_IOR(epe_table_id, DRV_ENTRY_FLAG);
            sal_memset(&epe_hdr_edit_discard_type_stats, 0, sizeof(epe_hdr_edit_discard_type_stats_t));
            DRV_IF_ERROR_RETURN(CM_IOCTL(chipid, j, cmd_epe, &epe_hdr_edit_discard_type_stats));

            if (epe_hdr_edit_discard_type_stats.discard_pkt_cnt != 0)
            {
                CMODEL_DEBUG_OUT_INFO("++++++ EPE discardType %d check FAILED, is not NULL!\n", j);
                CMODEL_DEBUG_OUT_INFO("++++++ EPE discardType %d discard_pkt_cnt = %d!\n",
                                      j, epe_hdr_edit_discard_type_stats.discard_pkt_cnt);
                if (!is_failed)
                {
                    is_failed = TRUE;
                }
                sal_printf("FAILED! EPE Check DiscardType %d Failed!\n", j);
            }

            /* clean */
            cmd_epe = DRV_IOW(epe_table_id, DRV_ENTRY_FLAG);
            sal_memset(&epe_hdr_edit_discard_type_stats, 0, sizeof(epe_hdr_edit_discard_type_stats_t));
            DRV_IF_ERROR_RETURN(CM_IOCTL(chipid, j, cmd_epe, &epe_hdr_edit_discard_type_stats));

#if (SDK_WORK_PLATFORM == 1)
            uint8 chipid_base = 0;
            DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chipid_base));
            drv_model_sram_tbl_clear_wbit((chipid - chipid_base), epe_table_id, j);
#endif
            j++;
        }
    }
    if (!is_failed)
    {
        CMODEL_DEBUG_OUT_INFO("++++++ Check no DiscardType Passed!\n");
        sal_printf("PASSED! Check no DiscardType Passed!\n");
    }

    return ret;
}

/*****************************************************************************
 * Name   : sim_compare_rslt_file
 * Purpose: set the file to save the result of compare
 * Input  :  file_name: the names of the result file
 * Output : N/A
 * Return : SUCCESS
 *          Other = ErrCode
 * Note   : N/A
 *****************************************************************************/
int32
sim_compare_rslt_file(char *file_name)
{
    unlink(file_compare_result);
    sal_memset(file_compare_result, 0, sizeof(file_compare_result));

    if (file_name)
    {
        sal_memcpy(file_compare_result, file_name, sal_strlen(file_name));
    }
    else
    {
        sal_strcpy(file_compare_result, "");
    }

    return DRV_E_NONE;
}

int32
sim_chk_tbl_rslt_file(char *file_name)
{
    unlink(file_tbl_chk_result);
    sal_memset(file_tbl_chk_result, 0, sizeof(file_tbl_chk_result));

    if (file_name)
    {
        sal_memcpy(file_tbl_chk_result, file_name, sal_strlen(file_name));
    }
    else
    {
        sal_strcpy(file_tbl_chk_result, "");
    }

    return DRV_E_NONE;
}
int32 sim_store_chk_tbl_result(bool *succ)
{
    int32 ret;

    if (succ == NULL)
    {
        CMODEL_DEBUG_OUT_INFO("\nERROR! NULL Pointer!\n");
        ret = DRV_E_INVALID_PARAMETER;
        return ret;
    }

    if (*succ != TRUE)
    {
        sal_printf("FAILED! Check tblcheck Failed!\n");
    }

    if (*succ == TRUE)
    {
        sal_printf("PASSED! Check tblcheck Passed!\n");
    }
    else
    {
        sal_printf("FAILED! Check tblcheck Failed!\n");
    }

    return DRV_E_NONE;
}

int32 sim_flush_table(uint32 chip_id, tbls_id_t tbl_id)
{
    uint32 cmd = 0, tbl_index = 0;
    uint32 clear_data[MAX_ENTRY_WORD] = {0};

    sal_memset(clear_data, 0, sizeof(uint32)*MAX_ENTRY_WORD);

    if (tbl_id == IpeLearningCacheValid_t)  /* addition table */
    {
        cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, clear_data));

#if (SDK_WORK_PLATFORM == 0)
            cmd = DRV_IOW(IpeLearningCacheValid_t, IpeLearningCacheValid_LearningEntryValid_f);
            clear_data[0] = 0xFFFF;
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &clear_data)); /* write 1 clear on the corresponding bit */
            clear_data[0] = 0;
#endif
        /* wbit do not clear, because the table is set in default cfg */
    }
    else
    {
        cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
        for (tbl_index = 0; tbl_index < TABLE_MAX_INDEX(tbl_id); tbl_index++)
        {
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, tbl_index, cmd, clear_data));

#if (SDK_WORK_PLATFORM == 1)
            uint8 chipid_base = 0;
            DRV_IF_ERROR_RETURN(drv_get_chipid_base(&chipid_base));
            /* clear wbit */
            drv_model_sram_tbl_clear_wbit((chip_id - chipid_base), tbl_id, tbl_index);
#endif
        }
    }

    return DRV_E_NONE;
}

int32 sim_check_table_is_null(uint32 chip_id, tbls_id_t tbl_id)
{

    uint32 cmd = 0, tbl_index = 0;

    uint32 read_data[MAX_ENTRY_WORD] = {0};
    ipe_learning_cache_t *learning_cache = NULL;

    ipe_learning_cache_valid_t *learning_cache_valid = NULL;
    int32 ret = DRV_E_NONE;
    bool is_pass = TRUE;

    cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);

    /* Temp code, need to consider all table ?? add by zhouw */
    if ((tbl_id == IpeLearningCache_t) || (tbl_id == IpeLearningCacheValid_t))
    {
        for (tbl_index = 0; tbl_index < TABLE_MAX_INDEX(tbl_id); tbl_index++)
        {
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, tbl_index, cmd, read_data));
            if (tbl_id == IpeLearningCache_t)
            {
                learning_cache = (ipe_learning_cache_t *)read_data;
                if (!(learning_cache->source_port || learning_cache->vsi_id
                    || learning_cache->new_cvlan_id || learning_cache->old_cvlan_id
                    || learning_cache->old_cvlan_id || learning_cache->old_svlan_id
                    || learning_cache->mac_sa_hi || learning_cache->mac_sa_low
                    || learning_cache->is_ether_oam || learning_cache->is_global_src_port
                    || learning_cache->ether_oam_level))
                {
                    continue;
                }
                else
                {
                    is_pass = FALSE;
                    CMODEL_DEBUG_OUT_INFO("++++++ Failed! Check table %s index = 0x%x is not Null!!\n", TABLE_NAME(tbl_id), tbl_index);
                    CMODEL_DEBUG_OUT_INFO("Dump IpeLearningCache index %d connent:\n", tbl_index);
                    CMODEL_DEBUG_OUT_INFO("IpeLearningCache.sourcePort = %d\n", learning_cache->source_port);
                    CMODEL_DEBUG_OUT_INFO("IpeLearningCache.vsiId = %d\n", learning_cache->vsi_id);
                    CMODEL_DEBUG_OUT_INFO("IpeLearningCache.macSa = 0x%04x%08x\n",
                                           learning_cache->mac_sa_hi, learning_cache->mac_sa_low);
                    CMODEL_DEBUG_OUT_INFO("IpeLearningCache.newCVlanId = %d\n", learning_cache->new_cvlan_id);
                    CMODEL_DEBUG_OUT_INFO("IpeLearningCache.newSVlanId = %d\n", learning_cache->new_svlan_id);
                    CMODEL_DEBUG_OUT_INFO("IpeLearningCache.oldCVlanId = %d\n", learning_cache->old_cvlan_id);
                    CMODEL_DEBUG_OUT_INFO("IpeLearningCache.oldSVlanId = %d\n", learning_cache->old_svlan_id);
                    CMODEL_DEBUG_OUT_INFO("IpeLearningCache.isGlobalSrcPort = %d\n", learning_cache->is_global_src_port);
                    CMODEL_DEBUG_OUT_INFO("IpeLearningCache.isEtherOam = %d\n", learning_cache->is_ether_oam);
                    CMODEL_DEBUG_OUT_INFO("IpeLearningCache.etherOamMdLevel = %d\n", learning_cache->ether_oam_level);
                    break;
                }
            }
            else if (tbl_id == IpeLearningCacheValid_t)
            {
                learning_cache_valid = (ipe_learning_cache_valid_t *)read_data;
                if (!learning_cache_valid->learning_entry_valid)
                {
                    continue;
                }
                else
                {
                    is_pass = FALSE;
                    break;
                }
            }
        }
    }

    if (is_pass)
    {
        CMODEL_DEBUG_OUT_INFO("++++++ Passed! Check table %s is Null!!\n", TABLE_NAME(tbl_id));
        sal_printf("PASSED! Check table %s is Null!!\n", TABLE_NAME(tbl_id));
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("++++++ Failed! Check table %s index = 0x%x is not Null!!\n", TABLE_NAME(tbl_id), tbl_index);

        if (tbl_id == IpeLearningCacheValid_t)
        {
            CMODEL_DEBUG_OUT_INFO("++++++ IpeLearningCacheValid.learningEntryValid = %d\n", learning_cache_valid->learning_entry_valid);
        }

        sal_printf("FAILED! Check table %s index = 0x%x is not Null!!\n", TABLE_NAME(tbl_id), tbl_index);
    }

    return ret;
}

void cm_gen_greatbelt_packet_header(ms_packet_header_t* p_gb_header,
                                              greatbelt_packet_header_t* p_cm_gb_header,
                                              uint8 to_cm_using_hdr)
{
    if (to_cm_using_hdr)
    {
        p_cm_gb_header->dest_id = p_gb_header->dest_map&0xFFFF;
        p_cm_gb_header->dest_chip_id = (p_gb_header->dest_map>>16)&0x1F;
        p_cm_gb_header->mcast = (p_gb_header->dest_map>>21) & 0x1;
        p_cm_gb_header->packet_offset = p_gb_header->packet_offset;
        p_cm_gb_header->source_port15_14 = p_gb_header->source_port15_14;

        p_cm_gb_header->source_port = p_gb_header->source_port;
        p_cm_gb_header->src_ctag_offset_type_u.src_ctag_offset_type = p_gb_header->src_ctag_offset_type;
        p_cm_gb_header->logic_port_type = p_gb_header->logic_port_type;
        p_cm_gb_header->header_hash2_0 = p_gb_header->header_hash2_0;
        p_cm_gb_header->src_queue_select = p_gb_header->src_queue_select;
        p_cm_gb_header->source_cos = p_gb_header->source_cos;
        p_cm_gb_header->packet_type = p_gb_header->packet_type;
        p_cm_gb_header->priority = p_gb_header->priority;

        p_cm_gb_header->next_hop_ptr = p_gb_header->next_hop_ptr;
        p_cm_gb_header->bridge_operation = p_gb_header->bridge_operation;
        p_cm_gb_header->color = p_gb_header->color;
        p_cm_gb_header->src_vlan_id_u.src_vlan_id = p_gb_header->src_vlan_id;

        p_cm_gb_header->rxtx_fcl_22_17_u.rxtx_fcl_22_17 = p_gb_header->rxtx_fcl22_17;
        p_cm_gb_header->critical_packet = p_gb_header->critical_packet;
        p_cm_gb_header->length_adjust_type = p_gb_header->length_adjust_type;

        p_cm_gb_header->header_crc = p_gb_header->header_crc;
        p_cm_gb_header->loopback_discard_u.loopback_discard = p_gb_header->loopback_discard;
        p_cm_gb_header->source_port_extender = p_gb_header->source_port_extender;
        p_cm_gb_header->bypass_ingress_edit = p_gb_header->bypass_ingress_edit;
        p_cm_gb_header->from_fabric = p_gb_header->from_fabric;
        p_cm_gb_header->ttl_u.ttl = p_gb_header->ttl;
        p_cm_gb_header->flow_u.rev_0 = p_gb_header->flow;

        p_cm_gb_header->src_cvlan_id_u.src_cvlan_id = p_gb_header->src_cvlan_id;
        p_cm_gb_header->src_cvlan_id_valid_u.src_cvlanid_valid = p_gb_header->src_cvlan_id_valid;
        p_cm_gb_header->src_svlan_id_valid = p_gb_header->src_svlan_id_valid;
        p_cm_gb_header->stag_action = p_gb_header->stag_action;
        p_cm_gb_header->svlan_tpid_index_u.svlan_tpid_index = p_gb_header->svlan_tpid_index;
        p_cm_gb_header->from_cpu_or_oam = p_gb_header->from_cpu_or_oam;
        p_cm_gb_header->non_crc = p_gb_header->non_crc;
        p_cm_gb_header->next_hop_ext = p_gb_header->next_hop_ext;
        p_cm_gb_header->source_cfi = p_gb_header->source_cfi;
        p_cm_gb_header->svlan_tag_operation_valid = p_gb_header->svlan_tag_operation_valid;
        p_cm_gb_header->pbb_src_port_type_u.pbb_src_port_type = p_gb_header->pbb_src_port_type;
        p_cm_gb_header->source_port_isolate_id_u.source_port_isolate_id = p_gb_header->source_port_isolate_id;

        p_cm_gb_header->fid_u.rx_fcb_31_16 = p_gb_header->fid;
        p_cm_gb_header->src_vlan_ptr_t.rev_1 = p_gb_header->src_vlan_ptr;

        p_cm_gb_header->header_hash7_3 = p_gb_header->header_hash7_3;
        p_cm_gb_header->operation_type = p_gb_header->operation_type;
        p_cm_gb_header->rxtx_fcl0_u.rxtx_fcl_0 = p_gb_header->rxtx_fcl0;
        p_cm_gb_header->oam_tunnel_en = p_gb_header->oam_tunnel_en;
        p_cm_gb_header->mux_length_type = p_gb_header->mux_length_type;
        p_cm_gb_header->rxtx_fcl2_1_u.rxtx_fcl_2_1 = p_gb_header->rxtx_fcl2_1;
        p_cm_gb_header->cut_through = p_gb_header->cut_through;
        p_cm_gb_header->rxtx_fcl3_u.rxtx_fcl_3 = p_gb_header->rxtx_fcl3;
        p_cm_gb_header->logic_src_port_u.l4_source_port = p_gb_header->logic_src_port;

        p_cm_gb_header->ip_sa_u.ip_sa = p_gb_header->ip_sa;

    }
    else
    {
        p_gb_header->source_port15_14 = p_cm_gb_header->source_port15_14;
        p_gb_header->packet_offset = p_cm_gb_header->packet_offset;
        p_gb_header->dest_map = p_cm_gb_header->mcast<<21 | p_cm_gb_header->dest_chip_id << 16 | p_cm_gb_header->dest_id;

        p_gb_header->source_port = p_cm_gb_header->source_port;
        p_gb_header->src_ctag_offset_type = p_cm_gb_header->src_ctag_offset_type_u.src_ctag_offset_type;
        p_gb_header->logic_port_type = p_cm_gb_header->logic_port_type;
        p_gb_header->header_hash2_0 = p_cm_gb_header->header_hash2_0;
        p_gb_header->src_queue_select = p_cm_gb_header->src_queue_select;
        p_gb_header->source_cos = p_cm_gb_header->source_cos;
        p_gb_header->packet_type = p_cm_gb_header->packet_type;
        p_gb_header->priority = p_cm_gb_header->priority;

        p_gb_header->next_hop_ptr = p_cm_gb_header->next_hop_ptr;
        p_gb_header->bridge_operation = p_cm_gb_header->bridge_operation;
        p_gb_header->color = p_cm_gb_header->color;
        p_gb_header->src_vlan_id = p_cm_gb_header->src_vlan_id_u.src_vlan_id;

        p_gb_header->header_crc = p_cm_gb_header->header_crc;
        p_gb_header->loopback_discard = p_cm_gb_header->loopback_discard_u.loopback_discard;
        p_gb_header->source_port_extender = p_cm_gb_header->source_port_extender;
        p_gb_header->bypass_ingress_edit = p_cm_gb_header->bypass_ingress_edit;

        p_gb_header->from_fabric = p_cm_gb_header->from_fabric;
        p_gb_header->ttl = p_cm_gb_header->ttl_u.ttl;
        p_gb_header->flow = p_cm_gb_header->flow_u.rev_0;

        p_gb_header->rxtx_fcl22_17 = p_cm_gb_header->rxtx_fcl_22_17_u.rxtx_fcl_22_17;
        p_gb_header->critical_packet = p_cm_gb_header->critical_packet;
        p_gb_header->length_adjust_type = p_cm_gb_header->length_adjust_type;

        p_gb_header->src_cvlan_id = p_cm_gb_header->src_cvlan_id_u.src_cvlan_id;
        p_gb_header->src_cvlan_id_valid = p_cm_gb_header->src_cvlan_id_valid_u.src_cvlanid_valid;
        p_gb_header->src_svlan_id_valid = p_cm_gb_header->src_svlan_id_valid;
        p_gb_header->stag_action = p_cm_gb_header->stag_action;
        p_gb_header->svlan_tpid_index = p_cm_gb_header->svlan_tpid_index_u.svlan_tpid_index;
        p_gb_header->from_cpu_or_oam = p_cm_gb_header->from_cpu_or_oam;
        p_gb_header->non_crc = p_cm_gb_header->non_crc;
        p_gb_header->next_hop_ext = p_cm_gb_header->next_hop_ext;
        p_gb_header->source_cfi = p_cm_gb_header->source_cfi;
        p_gb_header->svlan_tag_operation_valid = p_cm_gb_header->svlan_tag_operation_valid;
        p_gb_header->pbb_src_port_type = p_cm_gb_header->pbb_src_port_type_u.pbb_src_port_type;
        p_gb_header->source_port_isolate_id = p_cm_gb_header->source_port_isolate_id_u.source_port_isolate_id;

        p_gb_header->fid = p_cm_gb_header->fid_u.rx_fcb_31_16;
        p_gb_header->src_vlan_ptr = p_cm_gb_header->src_vlan_ptr_t.rev_1;

        p_gb_header->header_hash7_3 = p_cm_gb_header->header_hash7_3;
        p_gb_header->operation_type = p_cm_gb_header->operation_type;
        p_gb_header->rxtx_fcl0 = p_cm_gb_header->rxtx_fcl0_u.rxtx_fcl_0;
        p_gb_header->oam_tunnel_en = p_cm_gb_header->oam_tunnel_en;
        p_gb_header->mux_length_type = p_cm_gb_header->mux_length_type;
        p_gb_header->rxtx_fcl2_1 = p_cm_gb_header->rxtx_fcl2_1_u.rxtx_fcl_2_1;
        p_gb_header->cut_through = p_cm_gb_header->cut_through;
        p_gb_header->rxtx_fcl3 = p_cm_gb_header->rxtx_fcl3_u.rxtx_fcl_3;
        p_gb_header->logic_src_port = p_cm_gb_header->logic_src_port_u.l4_source_port;

        p_gb_header->ip_sa = p_cm_gb_header->ip_sa_u.ip_sa;
    }
}

void cm_gen_greatbelt_packet_header_outer(packet_header_outer_t* p_gb_header_outer,
                                                    cm_greatbelt_packet_header_outer_t* p_cm_gb_header_outer,
                                                    uint8 to_cm_using_hdr)
{
    if (to_cm_using_hdr)
    {
        p_cm_gb_header_outer->dest_id = p_gb_header_outer->dest_map&0xFFFF;
        p_cm_gb_header_outer->dest_chip_id = (p_gb_header_outer->dest_map>>16)&0x1F;
        p_cm_gb_header_outer->mcast = (p_gb_header_outer->dest_map>>21) & 0x1;
        p_cm_gb_header_outer->svlan_tpid_index = p_gb_header_outer->svlan_tpid_index;
        p_cm_gb_header_outer->mirrored_packet = p_gb_header_outer->mirrored_packet;
        p_cm_gb_header_outer->header_version = p_gb_header_outer->header_version;
        p_cm_gb_header_outer->header_type = p_gb_header_outer->header_type;

        p_cm_gb_header_outer->source_port = p_gb_header_outer->source_port;
        p_cm_gb_header_outer->src_vlan_ptr = p_gb_header_outer->src_vlan_ptr;
        p_cm_gb_header_outer->outer_vlan_is_c_vlan = p_gb_header_outer->outer_vlan_is_c_vlan;
        p_cm_gb_header_outer->bypass_all = p_gb_header_outer->bypass_all;
        p_cm_gb_header_outer->from_cpu_lm_down_disable= p_gb_header_outer->from_cpu_lm_down_disable;

        p_cm_gb_header_outer->port_mac_sa_en = p_gb_header_outer->port_mac_sa_en;
        p_cm_gb_header_outer->source_port_isolate_id = p_gb_header_outer->source_port_isolate_id;
        p_cm_gb_header_outer->bridge_operation = p_gb_header_outer->bridge_operation;
        p_cm_gb_header_outer->ttl = p_gb_header_outer->ttl;
        p_cm_gb_header_outer->source_port_extender = p_gb_header_outer->source_port_extender;
        p_cm_gb_header_outer->oam_tunnel_en_u.oam_tunnel_en = p_gb_header_outer->oam_tunnel_en;
        p_cm_gb_header_outer->color = p_gb_header_outer->color;
        p_cm_gb_header_outer->is_leaf = p_gb_header_outer->is_leaf;
        p_cm_gb_header_outer->critical_packet = p_gb_header_outer->critical_packet;
        p_cm_gb_header_outer->mac_known = p_gb_header_outer->mac_known;
        p_cm_gb_header_outer->packet_type = p_gb_header_outer->packet_type;
        p_cm_gb_header_outer->priority = p_gb_header_outer->priority;

        p_cm_gb_header_outer->operation_type = p_gb_header_outer->operation_type;
        p_cm_gb_header_outer->logic_port_type = p_gb_header_outer->logic_port_type;
        p_cm_gb_header_outer->header_hash = p_gb_header_outer->header_hash;
        p_cm_gb_header_outer->logic_src_port = p_gb_header_outer->logic_src_port;

        p_cm_gb_header_outer->from_cpu_lm_up_disable= p_gb_header_outer->from_cpu_lm_up_disable;
        p_cm_gb_header_outer->next_hop_ptr = p_gb_header_outer->next_hop_ptr;
        p_cm_gb_header_outer->next_hop_ext = p_gb_header_outer->next_hop_ext;

        p_cm_gb_header_outer->timestamp107_96_u.timestamp_107_96 = p_gb_header_outer->timestamp107_96;
        p_cm_gb_header_outer->timestamp95_64_u.timestamp_95_64 = p_gb_header_outer->timestamp95_64;
        p_cm_gb_header_outer->timestamp63_32_u.rev_1 = p_gb_header_outer->timestamp63_32;
        p_cm_gb_header_outer->timestamp31_0_u.timestamp_31_0 = p_gb_header_outer->timestamp31_0;

    }
    else
    {

        p_gb_header_outer->dest_map = (p_cm_gb_header_outer->mcast << 21)
                                      |(p_cm_gb_header_outer->dest_chip_id << 16)
                                      |(p_cm_gb_header_outer->dest_id);

        p_gb_header_outer->svlan_tpid_index = p_cm_gb_header_outer->svlan_tpid_index;
        p_gb_header_outer->mirrored_packet = p_cm_gb_header_outer->mirrored_packet;
        p_gb_header_outer->header_version = p_cm_gb_header_outer->header_version;
        p_gb_header_outer->header_type = p_cm_gb_header_outer->header_type;

        p_gb_header_outer->source_port = p_cm_gb_header_outer->source_port;
        p_gb_header_outer->src_vlan_ptr = p_cm_gb_header_outer->src_vlan_ptr;
        p_gb_header_outer->outer_vlan_is_c_vlan = p_cm_gb_header_outer->outer_vlan_is_c_vlan;
        p_gb_header_outer->bypass_all = p_cm_gb_header_outer->bypass_all;
        p_gb_header_outer->from_cpu_lm_down_disable = p_cm_gb_header_outer->from_cpu_lm_down_disable;

        p_gb_header_outer->port_mac_sa_en = p_cm_gb_header_outer->port_mac_sa_en;
        p_gb_header_outer->source_port_isolate_id = p_cm_gb_header_outer->source_port_isolate_id;
        p_gb_header_outer->bridge_operation = p_cm_gb_header_outer->bridge_operation;
        p_gb_header_outer->ttl = p_cm_gb_header_outer->ttl;
        p_gb_header_outer->source_port_extender = p_cm_gb_header_outer->source_port_extender;
        p_gb_header_outer->oam_tunnel_en = p_cm_gb_header_outer->oam_tunnel_en_u.oam_tunnel_en;
        p_gb_header_outer->color = p_cm_gb_header_outer->color;
        p_gb_header_outer->is_leaf = p_cm_gb_header_outer->is_leaf;
        p_gb_header_outer->critical_packet = p_cm_gb_header_outer->critical_packet;
        p_gb_header_outer->mac_known = p_cm_gb_header_outer->mac_known;
        p_gb_header_outer->packet_type = p_cm_gb_header_outer->packet_type;
        p_gb_header_outer->priority = p_cm_gb_header_outer->priority;

        p_gb_header_outer->operation_type = p_cm_gb_header_outer->operation_type;
        p_gb_header_outer->logic_port_type = p_cm_gb_header_outer->logic_port_type;
        p_gb_header_outer->header_hash = p_cm_gb_header_outer->header_hash;
        p_gb_header_outer->logic_src_port = p_cm_gb_header_outer->logic_src_port;

        p_gb_header_outer->from_cpu_lm_up_disable = p_cm_gb_header_outer->from_cpu_lm_up_disable;
        p_gb_header_outer->next_hop_ptr = p_cm_gb_header_outer->next_hop_ptr;
        p_gb_header_outer->next_hop_ext = p_cm_gb_header_outer->next_hop_ext;

        p_gb_header_outer->timestamp107_96 = p_cm_gb_header_outer->timestamp107_96_u.timestamp_107_96;
        p_gb_header_outer->timestamp95_64 = p_cm_gb_header_outer->timestamp95_64_u.timestamp_95_64;
        p_gb_header_outer->timestamp63_32 = p_cm_gb_header_outer->timestamp63_32_u.rev_1;
        p_gb_header_outer->timestamp31_0 = p_cm_gb_header_outer->timestamp31_0_u.timestamp_31_0;
    }
}

void cm_set_ptp_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32 high_64_32,uint32 low_31_0)
{
    p_cm_gb_header->src_ctag_offset_type_u.ptp_timestamp_61 = IS_BIT_SET(high_64_32,(61-32));
    p_cm_gb_header->rxtx_fcl_22_17_u.ptp_timestamp_60_55 = ((high_64_32 >> (55-32)) & 0x3F);
    p_cm_gb_header->src_cvlan_id_valid_u.ptp_timestamp_54 = IS_BIT_SET(high_64_32,(54-32));
    p_cm_gb_header->src_cvlan_id_u.ptp_timestamp_53_42 = ((high_64_32 >> (42-32)) & 0xFFF);
    p_cm_gb_header->fid_u.ptp_timestamp_41_26 = (((high_64_32 & 0x3FF) << (32 - 26)) | ((low_31_0 >> 26) & 0x3F));
    p_cm_gb_header->rxtx_fcl3_u.ptp_timestamp_25_25 = IS_BIT_SET(low_31_0,25);
    p_cm_gb_header->rxtx_fcl2_1_u.ptp_timestamp_24_23 = ((low_31_0 >> 23) & 0x3);
    p_cm_gb_header->rxtx_fcl0_u.ptp_timestamp_22_22 = IS_BIT_SET(low_31_0,22);
    p_cm_gb_header->ip_sa_u.share4.ptp_timestamp_21_0 = (low_31_0 & 0x3FFFFF);
}
void cm_get_ptp_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32* high_64_32,uint32* low_31_0)
{
    *low_31_0 = ((p_cm_gb_header->fid_u.ptp_timestamp_41_26 & 0x3F) << 26)
                 |(p_cm_gb_header->rxtx_fcl3_u.ptp_timestamp_25_25 << 25)
                 |(p_cm_gb_header->rxtx_fcl2_1_u.ptp_timestamp_24_23 << 23)
                 |(p_cm_gb_header->rxtx_fcl0_u.ptp_timestamp_22_22 << 22)
                 |p_cm_gb_header->ip_sa_u.share4.ptp_timestamp_21_0;

     *high_64_32 = (p_cm_gb_header->src_ctag_offset_type_u.ptp_timestamp_61 << 29)
                 |(p_cm_gb_header->rxtx_fcl_22_17_u.ptp_timestamp_60_55 << 23)
                 |(p_cm_gb_header->src_cvlan_id_valid_u.ptp_timestamp_54 << 22)
                 |(p_cm_gb_header->src_cvlan_id_u.ptp_timestamp_53_42 << 10)
                 |(p_cm_gb_header->fid_u.ptp_timestamp_41_26 >> 6);
}
void cm_set_dm_rx_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32 high_64_32,uint32 low_31_0)
{
    p_cm_gb_header->src_ctag_offset_type_u.dm_timestamp_61 = IS_BIT_SET(high_64_32,(61-32));
    p_cm_gb_header->rxtx_fcl_22_17_u.dm_timestamp_60_55 = ((high_64_32 >> (55-32)) & 0x3F);
    p_cm_gb_header->ttl_u.dm_timestamp_54_47 = ((high_64_32 >> (47-32)) & 0xFF);
    p_cm_gb_header->src_cvlan_id_valid_u.dm_timestamp_46 = IS_BIT_SET(high_64_32,(46-32));
    p_cm_gb_header->src_cvlan_id_u.dm_timestamp_45_34 = ((high_64_32 >> (34-32)) & 0xFFF);
    p_cm_gb_header->fid_u.dm_timestamp_33_18 = (((high_64_32 & 0x3) << (32-18)) | ((low_31_0 >> 18) & 0x3FFF));
    p_cm_gb_header->logic_src_port_u.dm_timestamp_17_2 = ((low_31_0 >> 2) & 0xFFFF);
    p_cm_gb_header->rxtx_fcl3_u.dm_timestamp_1_1 = IS_BIT_SET(low_31_0,1);
    p_cm_gb_header->rxtx_fcl0_u.dm_timestamp_0_0 = IS_BIT_SET(low_31_0,0);
}
void cm_get_dm_rx_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32* high_64_32,uint32* low_31_0)
{
   *high_64_32 = (p_cm_gb_header->src_ctag_offset_type_u.dm_timestamp_61 << 29)
                |(p_cm_gb_header->rxtx_fcl_22_17_u.dm_timestamp_60_55 << 23)
                |(p_cm_gb_header->ttl_u.dm_timestamp_54_47 << 15)
                |(p_cm_gb_header->src_cvlan_id_valid_u.dm_timestamp_46 << 14)
                |(p_cm_gb_header->src_cvlan_id_u.dm_timestamp_45_34 << 2)
                |((p_cm_gb_header->fid_u.dm_timestamp_33_18 >> 14)& 0x3);
   *low_31_0 = ((p_cm_gb_header->fid_u.dm_timestamp_33_18 & 0x3FFFF)<<18)
              |(p_cm_gb_header->logic_src_port_u.dm_timestamp_17_2 << 2)
              |(p_cm_gb_header->rxtx_fcl3_u.dm_timestamp_1_1 << 1)
              | p_cm_gb_header->rxtx_fcl0_u.dm_timestamp_0_0;
}

void cm_set_dm_tx_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32 high_61_32,uint32 low_31_0)
{
    /* PacketHeader.{ttl[3:0], srcCvlanId[11:0], fid[13:0], ipSa[31:0] = TimeStamp[61:0]} */
    p_cm_gb_header->ttl_u.ttl &= 0xF0;
    p_cm_gb_header->ttl_u.ttl |= (high_61_32>>(58-32));  /* [61:58] */
    p_cm_gb_header->src_cvlan_id_u.src_cvlan_id = (high_61_32>>(46-32))&0xFFF; /* [57:46] */
    p_cm_gb_header->fid_u.rx_fcb_31_16 &= 0xC000;
    p_cm_gb_header->fid_u.rx_fcb_31_16 |= (high_61_32&0x3FFF); /* [45:32] */
    p_cm_gb_header->ip_sa_u.ip_sa = low_31_0;  /* [31:0] */
}

void cm_get_dm_tx_timestamp_in_header(greatbelt_packet_header_t* p_cm_gb_header,uint32* high_61_32,uint32* low_31_0)
{
   *high_61_32 = ((p_cm_gb_header->ttl_u.ttl&0xF) << (58-32))
                |(p_cm_gb_header->src_cvlan_id_u.src_cvlan_id << (46-32))
                |(p_cm_gb_header->fid_u.rx_fcb_31_16&0x3FFF);
   *low_31_0 = p_cm_gb_header->ip_sa_u.ip_sa;
}

void
cm_set_cmodel_debug_callback(void * cb)
{
    cmodel_debug_cb = cb;
}

