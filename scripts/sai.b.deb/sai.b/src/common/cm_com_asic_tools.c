/****************************************************************************
 * sim_asic_tools.c: store tools in each module and some emualtion board tools.
 *
 * Copyright: (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:      V1.0.
 * Author:       ZhouW.
 * Date:         2010-09-20.
 * Reason:       Greatbelt First Create.
****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "ctcutil_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/
sim_asic_store_file_name_t store_file_name;

/*****************************************************************************
 * Name:   sim_asic_rx_pkt_cnt
 * Purpose: count netRx inpkt number
 * Input:   file_name -- the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_rx_pkt_cnt(char *file_name)
{
    if (!file_name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    unlink(file_name);
    sal_memset(store_file_name.rx_pkt_cnt_name, 0, sizeof(store_file_name.rx_pkt_cnt_name));
    sal_strncpy(store_file_name.rx_pkt_cnt_name, file_name, SIM_ASIC_MAX_PATH_LEN);

    return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_tx_pkt_cnt
 * Purpose: count netTx inpkt number
 * Input:   file_name -- the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_tx_pkt_cnt(char *file_name)
{
    if (!file_name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    unlink(file_name);
    sal_memset(store_file_name.tx_pkt_cnt_name, 0, sizeof(store_file_name.tx_pkt_cnt_name));
    sal_strncpy(store_file_name.tx_pkt_cnt_name, file_name, SIM_ASIC_MAX_PATH_LEN);

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:   sim_asic_epe_bhdr_inpkt
 * Purpose: store epe inpkt's bridge header.
 * Input:   file_name -- the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_epe_bhdr_inpkt(char *file_name)
{
    if (!file_name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    unlink(file_name);
    sal_memset(store_file_name.epe_bhdr_input_name, 0, sizeof(store_file_name.epe_bhdr_input_name));
    sal_strncpy(store_file_name.epe_bhdr_input_name, file_name, SIM_ASIC_MAX_PATH_LEN);

    return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_ipe_bhdr_inpkt
 * Purpose: store ipe inpkt's bridge header.
 * Input:   file_name -- the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_ipe_bhdr_inpkt(char *file_name)
{
    if (!file_name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    unlink(file_name);
    sal_memset(store_file_name.ipe_bhdr_input_name, 0, sizeof(store_file_name.ipe_bhdr_input_name));
    sal_strncpy(store_file_name.ipe_bhdr_input_name, file_name, SIM_ASIC_MAX_PATH_LEN);

    return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_ipe_inpkt
 * Purpose: set IPE inpkt's file name
 * Input:   file_name -- the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_ipe_inpkt(char *file_name)
{
    if (!file_name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    unlink(file_name);
    sal_memset(store_file_name.ipe_inpkt_name, 0, sizeof(store_file_name.ipe_inpkt_name));
    sal_strncpy(store_file_name.ipe_inpkt_name, file_name, SIM_ASIC_MAX_PATH_LEN);

    return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_oam_inpkt
 * Purpose: set OAM inpkt's file name
 * Input:   file_name -- the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_oam_inpkt(char *file_name)
{
    if (!file_name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    unlink(file_name);
    sal_memset(store_file_name.oam_inpkt_name, 0, sizeof(store_file_name.oam_inpkt_name));
    sal_strncpy(store_file_name.oam_inpkt_name, file_name, SIM_ASIC_MAX_PATH_LEN);

    return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_qmgt_inpkt
 * Purpose: set qmgr inpkt file name
 * Input:   file_name: the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
 *****************************************************************************/
int32 sim_asic_qmgt_inpkt(char *file_name)
{
    if (!file_name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    unlink(file_name);
    sal_memset(store_file_name.qmgt_inpkt_name, 0, sizeof(store_file_name.qmgt_inpkt_name));
    sal_strncpy(store_file_name.qmgt_inpkt_name, file_name, SIM_ASIC_MAX_PATH_LEN);

    return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_epe_inpkt
 * Purpose: set epe inpkt file name
 * Input:   file_name: the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
 *****************************************************************************/
int32 sim_asic_epe_inpkt(char *file_name)
{
    if (!file_name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    unlink(file_name);
    sal_memset(store_file_name.epe_inpkt_name, 0, sizeof(store_file_name.epe_inpkt_name));
    sal_strncpy(store_file_name.epe_inpkt_name, file_name, SIM_ASIC_MAX_PATH_LEN);

    return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_cpu_netrx_inpkt
 * Purpose: set cpu netrx inpkt file name
 * Input:   file_name: the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_cpu_netrx_inpkt(char *file_name)
{
    if (!file_name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    unlink(file_name);
    sal_memset(store_file_name.cpu_netrx_inpkt_name, 0, sizeof(store_file_name.cpu_netrx_inpkt_name));
    sal_strncpy(store_file_name.cpu_netrx_inpkt_name, file_name, SIM_ASIC_MAX_PATH_LEN);

    return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_macrx_inpkt
 * Purpose: set macRX inpkt file name
 * Input:   file_name: the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32
sim_asic_macrx_inpkt(char *file_name)
{
     if (NULL == file_name)
     {
         CMODEL_DEBUG_OUT_INFO("Invalid macrx input packet filename!\n");
         return  DRV_E_INVALID_PARAMETER;
     }
     unlink(file_name);

     sal_memset(store_file_name.macrx_input_name, 0, sizeof(store_file_name.macrx_input_name));
     sal_strncpy(store_file_name.macrx_input_name, file_name, SIM_ASIC_MAX_PATH_LEN);

     return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_mactx_outpkt
 * Purpose: set macTX inpkt file name
 * Input:   file_name: the output file name
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_mactx_outpkt(char *file_name)
{
     if (NULL == file_name)
     {
         CMODEL_DEBUG_OUT_INFO("Invalid mactx output packet filename!\n");
         return  DRV_E_INVALID_PARAMETER;
     }
     unlink(file_name);

     sal_memset(store_file_name.mactx_output_name, 0, sizeof(store_file_name.mactx_output_name));
     sal_strncpy(store_file_name.mactx_output_name, file_name, SIM_ASIC_MAX_PATH_LEN);

     return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_gen_rx_pkt_cnt
 * Purpose:
 * Input:
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_gen_rx_pkt_cnt(int32 *p_arr)
{
    FILE *fp_rx = NULL;
    uint32 i = 0;

    if (p_arr == NULL)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    fp_rx = fopen(store_file_name.rx_pkt_cnt_name, "w+");
    if (fp_rx == NULL)
    {
        return DRV_E_NONE;
    }
    for(i = 0; i < MAX_MACNUM; i++)
    {
        sal_fprintf(fp_rx, "mac %d receive pkt num is :%d\n", i, *(p_arr + i));
    }

    fclose(fp_rx);
    fp_rx = NULL;

    return DRV_E_NONE;
}


/*****************************************************************************
 * Name:   sim_asic_gen_tx_pkt_cnt
 * Purpose:
 * Input:
 * Output:  N/A
 * Return:  SUCCESS
 *         Other = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_gen_tx_pkt_cnt(int32 *p_arr)
{
    FILE *fp_tx = NULL;
    uint32 i = 0;
    if (p_arr == NULL )
    {
        return DRV_E_INVALID_PARAMETER;
    }

    fp_tx = fopen(store_file_name.tx_pkt_cnt_name, "w+");
    if (fp_tx == NULL)
    {
        return DRV_E_NONE;
    }
    for(i = 0; i < MAX_MACNUM; i++)
    {
        sal_fprintf(fp_tx, "mac %d transmit pkt num is :%d\n", i, *(p_arr + i));
    }

    fclose(fp_tx);
    fp_tx = NULL;

    return DRV_E_NONE;
}


/******************************************************************************
 * Name:   sim_asic_gen_ipe_inpkt
 * Purpose: generate asic ipe inpkt
 * Input:   packet, packet_length.
 * Output:  N/A
 * Return:  SUCCESS
 *         Other   = ErrCode
 * Note:    N/A
 *****************************************************************************/
int32 sim_asic_gen_ipe_inpkt(ipe_in_pkt_t *ipkt)
{
    int32 i = 0,total_length = 0;
    FILE *fp = NULL;
    uint8 temp_pkt[MTU] = {0};

    if (ipkt == NULL || ipkt->packet_length == 0 || ipkt->pkt == NULL)
    {
        return DRV_E_INVALID_PARAMETER;
    }
    fp = fopen(store_file_name.ipe_inpkt_name, "a+");

    /* cosim Ipe inpkt divide according to asic's requirement */
    /* if (ipkt->chan_id != I_LOOPBACK_CHANID)
    {
        fp = fopen(store_file_name.ipe_inpkt_name, "a+");
    }
    else
    {
        fp = fopen("asic_ipe_iloop_inpkt.txt", "a+");
    }*/
    if (fp == NULL)
    {
        return DRV_E_NONE;
    }

    if (ipkt->chan_id == I_LOOPBACK_CHANID)
    {
        sal_memcpy(temp_pkt, ipkt->module_bus.packet_header, GREAT_BELT_HEADER_LEN);
        sal_memcpy(temp_pkt + GREAT_BELT_HEADER_LEN, ipkt->pkt, ipkt->packet_length);
        total_length = ipkt->packet_length + GREAT_BELT_HEADER_LEN;
    }
    else
    {
        sal_memcpy(temp_pkt, ipkt->pkt, ipkt->packet_length);
        total_length = ipkt->packet_length;
    }

    sal_fprintf(fp, "pkt %d %d %d\n", ipkt->packet_length, ipkt->chan_id, ipkt->chip_id);
    sal_fprintf(fp, "%02x\n", ipkt->channelinfo_ptpen);

    for (i = 0; i < total_length; i++)
    {
        sal_fprintf(fp, "%02x", temp_pkt[i]);
        if ((i + 1) % 16 == 0)
        {
            sal_fprintf(fp, "\n");
        }
    }
    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}


/******************************************************************************
 * Name:   gen_asic_qmgt_inpkt
 * Purpose: generate asic qmgt inpkt
 * Input:   packet, packet_length.
 * Output:  N/A
 * Return:  SUCCESS
 *         Other   = ErrCode
 * Note:    N/A
*****************************************************************************/
int32 sim_asic_gen_qmgt_inpkt(queue_in_pkt_t *qpkt)
{
    int32 i = 0;
    FILE *fp = NULL;
    uint8 temp_pkt[MTU] = {0};

    if (NULL == qpkt || 0 == qpkt->packet_length || NULL == qpkt->pkt)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    fp = fopen(store_file_name.qmgt_inpkt_name, "a+");
    if (fp == NULL)
    {
        return DRV_E_NONE;
    }

    sal_memcpy(temp_pkt, qpkt->exception, GREAT_BELT_EXCEPTION_LEN);
    sal_memcpy(temp_pkt + GREAT_BELT_EXCEPTION_LEN, qpkt->module_bus.packet_header, GREAT_BELT_HEADER_LEN);
    sal_memcpy(temp_pkt + GREAT_BELT_EXCEPTION_LEN + GREAT_BELT_HEADER_LEN, qpkt->pkt, qpkt->packet_length);
    DRV_IF_ERROR_RETURN(swap32((uint32*)temp_pkt, GREAT_BELT_EXCEPTION_LEN/4, HOST_TO_NETWORK));

    sal_fprintf(fp, "pkt %d %d %d\n",
            qpkt->packet_length, qpkt->chan_id, qpkt->chip_id);
    sal_fprintf(fp, "%02x\n", qpkt->local_phy_port);

    for (i = 0; i < (GREAT_BELT_EXCEPTION_LEN + GREAT_BELT_HEADER_LEN + qpkt->packet_length); i++)
    {
        sal_fprintf(fp, "%02x", temp_pkt[i]);
        if ((i + 1) % 16 == 0)
        {
            sal_fprintf(fp, "\n");
        }
    }
    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}

int32
sim_asic_gen_cpu_netrx_inpkt(out_pkt_t* cpupkt)
{
    int32 i;
    FILE *fp;
    /*uint32 channel;*/

    if (NULL == cpupkt || 0 == cpupkt->packet_length || NULL == cpupkt->pkt)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    fp = fopen(store_file_name.cpu_netrx_inpkt_name, "a+");
    if (fp == NULL)
    {
        return DRV_E_NONE;
    }

    sal_fprintf(fp, "pkt %d %d %d %d\n",
            cpupkt->packet_length , cpupkt->chan_id, cpupkt->chip_id, cpupkt->local_phy_port);
    for (i = 0; i < cpupkt->packet_length; i++)
    {
        sal_fprintf(fp, "%02x", cpupkt->pkt[i]);
        if ((i + 1) % 16 == 0)
        {
            sal_fprintf(fp, "\n");
        }
    }
    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}

int32
sim_asic_gen_ipe_bhdr_inpkt(ipe_in_pkt_t *ipkt)
{
    FILE *fp;
/* TBD
    greatbelt_packet_header_t *bheader = (greatbelt_packet_header_t *)ipkt->pkt;
*/
    if (ipkt == NULL || ipkt->packet_length == 0 || ipkt->pkt == NULL)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    fp = fopen(store_file_name.ipe_bhdr_input_name, "a+");
    if (fp == NULL)
    {
        return DRV_E_NONE;
    }

    sal_fprintf(fp, "---------------pkt %d %d %d---------------\n", ipkt->packet_length, ipkt->chan_id, ipkt->chip_id);

/*TBD
    sal_fprintf(fp,"header_type = %x\n",bheader->header_type);
    sal_fprintf(fp,"dest_id_discard = %x\n",bheader->dest_id_discard);
    sal_fprintf(fp,"packet_offset = %x\n", bheader->packet_offset);
    sal_fprintf(fp,"mcast = %x\n",bheader->mcast);
    sal_fprintf(fp,"dest_chip_id = %x\n",bheader->dest_chip_id);
    sal_fprintf(fp,"dest_id = %x\n",bheader->dest_id);
    sal_fprintf(fp,"priority = %x\n",bheader->priority);
    sal_fprintf(fp,"packet_type = %x\n",bheader->packet_type);
    sal_fprintf(fp,"source_cos = %x\n",bheader->source_cos);
    sal_fprintf(fp,"src_queue_select = %x\n",bheader->src_queue_select);
    sal_fprintf(fp,"header_hash = %x\n",(bheader->hd_hash_7_to_3 << 3) | (bheader->header_hash_2_0));
    sal_fprintf(fp,"vpls_port_type = %x\n",bheader->vpls_port_type);
    sal_fprintf(fp,"untagged_packet = %x\n",bheader->untagged_packet);
    sal_fprintf(fp,"source_port = %x\n",bheader->source_port);
    sal_fprintf(fp,"src_vlan_id = %x\n",bheader->src_vlan_id);
    sal_fprintf(fp,"color = %x\n", bheader->color);
    sal_fprintf(fp,"next_hop_ptr = %x\n", (bheader->next_hop_ptr_19_18 << 18) | (bheader->next_hop_ptr_17_0));
    sal_fprintf(fp,"length_adjust_type  = %x\n", bheader->length_adjust_type);
    sal_fprintf(fp,"critical_packet = %x\n", bheader->critical_packet);
    sal_fprintf(fp,"packet_ttl = %x\n", bheader->ttl_or_oam_defect);
    sal_fprintf(fp,"source_port_isolate_id = %x\n", bheader->source_port_isolate_id);
    sal_fprintf(fp,"pbb_src_port_type  = %x\n", bheader->pbb_srcport_type_or_l4srcport_vld);
    sal_fprintf(fp,"source_cfi = %x\n", bheader->source_cfi);
    sal_fprintf(fp,"next_hop_ext = %x\n", bheader->next_hop_ext);
    sal_fprintf(fp,"svlan_tpid_index = %x\n", bheader->svlan_tpid_index);
    sal_fprintf(fp,"deny_replace_cos = %x\n", bheader->deny_replace_cos);
    sal_fprintf(fp,"deny_replace_dscp = %x\n", bheader->deny_replace_dscp);
    sal_fprintf(fp,"src_svlan_id_valid = %x\n", bheader->src_svlan_id_valid);
    sal_fprintf(fp,"src_cvlan_id_valid = %x\n", bheader->src_cvlan_id_valid);
    sal_fprintf(fp,"src_cvlan_id = %x\n", bheader->src_cvlan_id);
    sal_fprintf(fp,"outer_vlan_is_cvlan = %x\n", (bheader->src_vlanptr_or_timestamp_79_64 >> 14) & 0x1);
    sal_fprintf(fp,"src_vlan_ptr = %x\n", (bheader->src_vlanptr_or_timestamp_79_64) & 0x3fff);
    sal_fprintf(fp,"vrf_id = %x\n", bheader->vrfid_timestamp_63_48);
    sal_fprintf(fp,"l4_source_port = %x\n", bheader->l4srcport_or_vplssrcport_oamtype);
    sal_fprintf(fp,"src_tagged = %x\n", bheader->src_tagged);
    sal_fprintf(fp,"use_outer_vrf_id = %x\n", bheader->use_outer_vrfid);
    sal_fprintf(fp,"pfm = %x\n", bheader->pfm);
    sal_fprintf(fp,"oam_tunnel_en = %x\n", bheader->oam_tunnel_en);
    sal_fprintf(fp,"mirror = %x\n", bheader->mirror);
    sal_fprintf(fp,"operation_type = %x\n", bheader->operation_type);
    sal_fprintf(fp,"l3 = %x\n", (bheader->flowid_servecid_or_oamportid >> 31) & 0x1);
    sal_fprintf(fp,"src_dscp = %x\n", (bheader->flowid_servecid_or_oamportid >> 25) & 0x3f);
    sal_fprintf(fp,"flow_id = %x\n", (bheader->flowid_servecid_or_oamportid >> 16) & 0xfff);
    sal_fprintf(fp,"service_id = %x\n", (bheader->flowid_servecid_or_oamportid) & 0xffff);
*/

    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}


int32
sim_asic_gen_epe_bhdr_inpkt(ms_packet_header_t *bheader)
{
    FILE *fp;

    if (bheader == NULL)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    fp = fopen(store_file_name.epe_bhdr_input_name, "a+");
    if (fp == NULL)
    {
        return DRV_E_NONE;
    }

    sal_fprintf(fp, "----------------------------------------------------------\n");

/*TBD
    sal_fprintf(fp,"header_type = %x\n",bheader->header_type);
    sal_fprintf(fp,"dest_id_discard = %x\n",bheader->dest_id_discard);
    sal_fprintf(fp,"packet_offset = %x\n", bheader->packet_offset);
    sal_fprintf(fp,"mcast = %x\n",bheader->mcast);
    sal_fprintf(fp,"dest_chip_id = %x\n",bheader->dest_chip_id);
    sal_fprintf(fp,"dest_id = %x\n",bheader->dest_id);
    sal_fprintf(fp,"priority = %x\n",bheader->priority);
    sal_fprintf(fp,"packet_type = %x\n",bheader->packet_type);
    sal_fprintf(fp,"source_cos = %x\n",bheader->source_cos);
    sal_fprintf(fp,"src_queue_select = %x\n",bheader->src_queue_select);
    sal_fprintf(fp,"header_hash = %x\n",(bheader->hd_hash_7_to_3 << 3) | (bheader->header_hash_2_0));
    sal_fprintf(fp,"vpls_port_type = %x\n",bheader->vpls_port_type);
    sal_fprintf(fp,"untagged_packet = %x\n",bheader->untagged_packet);
    sal_fprintf(fp,"source_port = %x\n",bheader->source_port);
    sal_fprintf(fp,"src_vlan_id = %x\n",bheader->src_vlan_id);
    sal_fprintf(fp,"color = %x\n", bheader->color);
    sal_fprintf(fp,"next_hop_ptr = %x\n", (bheader->next_hop_ptr_19_18 << 18) | (bheader->next_hop_ptr_17_0));
    sal_fprintf(fp,"length_adjust_type  = %x\n", bheader->length_adjust_type);
    sal_fprintf(fp,"critical_packet = %x\n", bheader->critical_packet);
    sal_fprintf(fp,"packet_ttl = %x\n", bheader->ttl_or_oam_defect);
    sal_fprintf(fp,"source_port_isolate_id = %x\n", bheader->source_port_isolate_id);
    sal_fprintf(fp,"pbb_src_port_type  = %x\n", bheader->pbb_srcport_type_or_l4srcport_vld);
    sal_fprintf(fp,"source_cfi = %x\n", bheader->source_cfi);
    sal_fprintf(fp,"next_hop_ext = %x\n", bheader->next_hop_ext);
    sal_fprintf(fp,"svlan_tpid_index = %x\n", bheader->svlan_tpid_index);
    sal_fprintf(fp,"deny_replace_cos = %x\n", bheader->deny_replace_cos);
    sal_fprintf(fp,"deny_replace_dscp = %x\n", bheader->deny_replace_dscp);
    sal_fprintf(fp,"src_svlan_id_valid = %x\n", bheader->src_svlan_id_valid);
    sal_fprintf(fp,"src_cvlan_id_valid = %x\n", bheader->src_cvlan_id_valid);
    sal_fprintf(fp,"src_cvlan_id = %x\n", bheader->src_cvlan_id);
    sal_fprintf(fp,"outer_vlan_is_cvlan = %x\n", (bheader->src_vlanptr_or_timestamp_79_64 >> 14) & 0x1);
    sal_fprintf(fp,"src_vlan_ptr = %x\n", (bheader->src_vlanptr_or_timestamp_79_64) & 0x3fff);
    sal_fprintf(fp,"vrf_id = %x\n", bheader->vrfid_timestamp_63_48);
    sal_fprintf(fp,"l4_source_port = %x\n", bheader->l4srcport_or_vplssrcport_oamtype);
    sal_fprintf(fp,"src_tagged = %x\n", bheader->src_tagged);
    sal_fprintf(fp,"use_outer_vrf_id = %x\n", bheader->use_outer_vrfid);
    sal_fprintf(fp,"pfm = %x\n", bheader->pfm);
    sal_fprintf(fp,"oam_tunnel_en = %x\n", bheader->oam_tunnel_en);
    sal_fprintf(fp,"mirror = %x\n", bheader->mirror);
    sal_fprintf(fp,"operation_type = %x\n", bheader->operation_type);
    sal_fprintf(fp,"l3 = %x\n", (bheader->flowid_servecid_or_oamportid >> 31) & 0x1);
    sal_fprintf(fp,"src_dscp = %x\n", (bheader->flowid_servecid_or_oamportid >> 25) & 0x3f);
    sal_fprintf(fp,"flow_id = %x\n", (bheader->flowid_servecid_or_oamportid >> 16) & 0xfff);
    sal_fprintf(fp,"service_id = %x\n", (bheader->flowid_servecid_or_oamportid) & 0xffff);
*/

    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}


/******************************************************************************
 * Name   : gen_asic_epe_inpkt
 * Purpose: generate asic epe inpkt
 * Input  : packet, packet_length.
 * Output : N/A
 * Return : SUCCESS
 *          Other   = ErrCode
 * Note   : N/A
 *****************************************************************************/
int32
sim_asic_gen_epe_inpkt(epe_in_pkt_t* epkt)
{
    int32 i;
    FILE *fp;
    uint8 temp_pkt[MTU] = {0};

    if (epkt == NULL || epkt->pkt == NULL)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    fp = fopen(store_file_name.epe_inpkt_name, "a+");
    if (fp == NULL)
    {
        return DRV_E_NONE;
    }

    sal_memcpy(temp_pkt, epkt->module_bus.packet_header, GREAT_BELT_HEADER_LEN);
    sal_memcpy(temp_pkt + GREAT_BELT_HEADER_LEN, epkt->pkt, epkt->packet_length);

    sal_fprintf(fp, "pkt %d %d %d\n", epkt->packet_length , epkt->chan_id, epkt->chip_id);

    for (i = 0; i < (GREAT_BELT_HEADER_LEN + epkt->packet_length); i++)
    {
        sal_fprintf(fp, "%02x", temp_pkt[i]);
        if ((i + 1) % 16 == 0)
        {
            sal_fprintf(fp, "\n");
        }
    }
    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}

int32
sim_asic_gen_oam_inpkt(oam_in_pkt_t* in_pkt)
{
    int32 i;
    FILE *fp;
    uint8 temp_pkt[MTU] = {0};

    if (in_pkt == NULL || in_pkt->pkt == NULL)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    fp = fopen(store_file_name.oam_inpkt_name, "a+");
    if (fp == NULL)
    {
        return DRV_E_NONE;
    }

    sal_memcpy(temp_pkt, in_pkt->module_bus.packet_header, GREAT_BELT_HEADER_LEN);
    sal_memcpy(temp_pkt + GREAT_BELT_HEADER_LEN, in_pkt->pkt, in_pkt->packet_length);

    sal_fprintf(fp, "pkt %d %d %d\n", in_pkt->packet_length , in_pkt->chan_id, in_pkt->chip_id);

    for (i = 0; i < (GREAT_BELT_HEADER_LEN + in_pkt->packet_length); i++)
    {
        sal_fprintf(fp, "%02x", temp_pkt[i]);
        if ((i + 1) % 16 == 0)
        {
            sal_fprintf(fp, "\n");
        }
    }
    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}

int32
sim_asic_gen_macrx_inpkt(uint32 chipid_offset, uint8 *pkt, uint32 packet_length, uint32 mac_num)
{
    int32 i;
    FILE *fp = NULL;
    uint8 chipid = chipid_offset + drv_init_chip_info.drv_init_chipid_base;

    if (pkt == NULL)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    fp = fopen(store_file_name.macrx_input_name, "a+");
    if (fp == NULL)
    {
        return DRV_E_NONE;
    }

    sal_fprintf(fp, "pkt %d %d %d\n", packet_length , mac_num, chipid);
    for (i = 0; i < packet_length; i++)
    {
        sal_fprintf(fp, "%02x", pkt[i]);
        if ((i + 1) % 16 == 0)
        {
            sal_fprintf(fp, "\n");
        }
    }
    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}

int32
sim_asic_gen_mactx_outpkt(uint32 chipid, uint8 *pkt, uint32 packet_length, uint32 chanid)
{
    int32 i;
    FILE *fp = NULL;

    if ((chanid != 48) && (chanid != 49) && (chanid != 50) && (chanid != 51))
    {
        return DRV_E_NONE;
    }

    if (pkt == NULL)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    fp = fopen(store_file_name.mactx_output_name, "a+");

    if (fp == NULL)
    {
        return DRV_E_NONE;
    }

    sal_fprintf(fp, "pkt %d %d %d\n", packet_length , chanid, chipid);
    for (i = 0; i < packet_length - 4; i++)
    {
        sal_fprintf(fp, "%02x", pkt[i]);
        if ((i + 1) % 16 == 0)
        {
            sal_fprintf(fp, "\n");
        }
    }
    sal_fprintf(fp, "\n");

    fclose(fp);
    fp = NULL;

    return DRV_E_NONE;
}


#if !defined(SDK_IN_KERNEL)
uint32 sim_asic_emu_bit_map[1024];

static void
_sim_asic_emu_check_integrity_calc_proc(uint8 chip_id,
                                            char *str,
                                            uint32 *val)
{
    char  *temp_head, *temp_tail;
    uint8   opcode ='+';
    uint32   data;

    sal_memset(val, 0, 12);

    temp_head = sal_strstr(str, "{");
    temp_tail = str;
    while (NULL != temp_head)
    {
        uint32 addr, start, end;

        temp_tail   = sal_strstr(temp_head, "}");
        if(NULL == temp_tail)
        {
            CMODEL_DEBUG_OUT_INFO("%s miss  }!\n", str);
            return;
        }

        if (3 != sal_sscanf(temp_head + 1, "%x %d %d", &addr, &start, &end))
        {
            CMODEL_DEBUG_OUT_INFO("%s parameter error!\n", str);
            return;
        }

        if(DRV_E_NONE != drv_io_api.drv_sram_read_entry(chip_id, addr, &data, 4))
        {
            CMODEL_DEBUG_OUT_INFO("%s read memory error!\n", str);
            return;
        }

        data = (data >> start) & ((1 << (end - start + 1)) - 1);

        switch (opcode)
        {
            case '+':
                val[0]   = val[0] + data;
                break;

            case '-':
                val[0]   = val[0] - data;
                break;

            default:
                CMODEL_DEBUG_OUT_INFO("%s not support opcode!\n", str);
        }

        if(NULL != sal_strstr(temp_tail, "+"))
        {
            opcode = '+';
            temp_tail = sal_strstr(temp_tail, "+")  + 1;
        }
        else  if(NULL != sal_strstr(temp_tail, "-"))
        {
            opcode = '-';
            temp_tail = sal_strstr(temp_tail, "-")  + 1;
        }
        else  if(NULL != sal_strstr(temp_tail, "&"))
        {
            opcode = '&';
            temp_tail = sal_strstr(temp_tail, "&")  + 1;
        }
        else
        {
            return;
        }

        temp_head = sal_strstr(temp_tail, "{");
    }

    if (1 != sal_sscanf(temp_tail, "%x", &data))
    {
        CMODEL_DEBUG_OUT_INFO("%s no follow value!\n", str);
        return;
    }

    switch (opcode)
    {
        case '+':
            val[0]   = val[0] + data;
            break;

        case '-':
            val[0]   = val[0] - data;
            break;

        case '&':
            val[2]   = val[0];
            val[0]   = val[0] & data;
            val[1]   = 1;
            break;

        default:
            CMODEL_DEBUG_OUT_INFO("%s not support opcode!\n", str);
    }

}

static void
_sim_asic_emu_check_integrity_macro_line_handle(uint8 chip,
                                                    char *line,
                                                    uint32 *addr)
{
    char *value = NULL;
    uint32 data[3] = {0};

    value = sal_strstr(line, "=");
    if (NULL == value)
    {
        CMODEL_DEBUG_OUT_INFO("%s", line);
        return;
    }

    if (sal_strstr(line, "}") > sal_strstr(line, "="))
    {
        _sim_asic_emu_check_integrity_calc_proc(chip, (value + 1), data);
    }
    else
    {
        sal_sscanf (value + 1, "%x", data);
    }

    if (NULL != sal_strstr(line, "DS_Queue_LinkList_addr"))
    {
        addr[DS_QUE_LINK_LIST_BASE] = data[0];
    }
    else if (NULL != sal_strstr(line, "QL_FreeList_Head_Ptr_Addr"))
    {
        addr[FL_QUE_LINK_HEAD] = data[0];
    }
    else if (NULL != sal_strstr(line, "QL_FreeList_Tail_Ptr_Addr"))
    {
        addr[FL_QUE_LINK_TAIL] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Base_Addr"))
    {
         addr[FL_BUF_STORE_BASE] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Head_Ptr0_Addr"))
    {
        addr[FL_BUF_STORE_HEAD0] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Tail_Ptr0_Addr"))
    {
        addr[FL_BUF_STORE_TAIL0] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Head_Ptr1_Addr"))
    {
        addr[FL_BUF_STORE_HEAD1] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Tail_Ptr1_Addr"))
    {
        addr[FL_BUF_STORE_TAIL1] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Head_Ptr2_Addr"))
    {
        addr[FL_BUF_STORE_HEAD2] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Tail_Ptr2_Addr"))
    {
        addr[FL_BUF_STORE_TAIL2] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Head_Ptr3_Addr"))
    {
        addr[FL_BUF_STORE_HEAD3] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Tail_Ptr3_Addr"))
    {
         addr[FL_BUF_STORE_TAIL3] = data[0];
   }
    else if (NULL != sal_strstr(line, "NR_FreeList_Base_Addr"))
    {
         addr[FL_NET_RX_BASE] = data[0];
   }
    else if (NULL != sal_strstr(line, "NR_FreeList_Head_Ptr_Addr"))
    {
        addr[FL_NET_RX_HEAD] = data[0];
    }
    else if (NULL != sal_strstr(line, "NR_FreeList_Tail_Ptr_Addr"))
    {
        addr[FL_NET_RX_TAIL] = data[0];
    }
    else if (NULL != sal_strstr(line, "NR_FreeList_Counter"))
    {
         addr[FL_NET_RX_COUNTER] = data[0];
   }
    else if (NULL != sal_strstr(line, "QL_FreeList_Counter"))
    {
         addr[FL_QUE_LINK_COUNTER] = data[0];
   }
    else if (NULL != sal_strstr(line, "BS_FreeList_Counter0"))
    {
        addr[FL_BUF_STORE_COUNTER0] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Counter1"))
    {
        addr[FL_BUF_STORE_COUNTER1] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Counter2"))
    {
        addr[FL_BUF_STORE_COUNTER2] = data[0];
    }
    else if (NULL != sal_strstr(line, "BS_FreeList_Counter3"))
    {
        addr[FL_BUF_STORE_COUNTER3] = data[0];
    }
	else if (NULL != sal_strstr(line, "BufStoreLinkListTableCtrl"))
    {
        addr[FL_BUF_STORE_TABLE_CTRL_ADDR] = data[0];
    }
    else if (NULL != sal_strstr(line, "FabricVoq_freeCell_addr"))
    {
        addr[FAB_VOQ_FREE_CELL_BASE] = data[0];
    }
    else if (NULL != sal_strstr(line, "FabricVoq_freeCell_Head_Ptr_Addr"))
    {
        addr[FAB_VOQ_FREE_CELL_HEAD] = data[0];
    }
    else if (NULL != sal_strstr(line, "FabricVoq_freeCell_Tail_Ptr_Addr"))
    {
        addr[FAB_VOQ_FREE_CELL_TAIL] = data[0];
    }
    else if (NULL != sal_strstr(line, "FabricVoq_freeCell_Counter"))
    {
        addr[FAB_VOQ_FREE_CELL_CNT] = data[0];
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("%s", line);
    }
}

static void
_sim_asic_emu_link_list_check(uint8 chip_id, link_list_t *list,
                        FILE *dest, uint8 *pass)
{
    uint32 counter, index, offset, data, saved_index = 0;

    if(( NULL != sal_strstr(list->desc, "DsQueueLinkList"))
        || ( NULL != sal_strstr(list->desc, "DsBufferLinkList0"))
        || ( NULL != sal_strstr(list->desc, "DsNetRxList")) )
    {
        sal_memset(sim_asic_emu_bit_map, 0, 1024* 4);
    }
    sal_fprintf(dest, "\n\n========================================================\n");
    sal_fprintf(dest, "%s FreeList Check, Total %d entries\n", list->desc, list->index_num);
    sal_fprintf(dest, "========================================================\n");

    counter   = 0;
    index      =  list->head;

    for(;;)
    {
        sim_asic_emu_bit_map[index / 32] = sim_asic_emu_bit_map[index / 32] | (1 << (index % 32));
        counter ++;
        offset = list->base + index * list->entry_size;

        if ((index == list->tail) || (counter == list->index_num))
        {
            break;
        }

        /* read first offset for triger */
        if(DRV_E_NONE != drv_io_api.drv_sram_read_entry(chip_id, offset, &data, 4))
        {
            CMODEL_DEBUG_OUT_INFO("%s read index(0x%x) error!, entry size = %d, offset = 0x%x!\n", list->desc, index, list->entry_size, offset);
        }

        /* read real offset for nextpointer */
        offset = list->base + index * list->entry_size + list->np_offset * 4;
        if(DRV_E_NONE != drv_io_api.drv_sram_read_entry(chip_id, offset, &data, 4))
        {
            CMODEL_DEBUG_OUT_INFO("%s read index(0x%x) error!, entry size = %d, offset = 0x%x!\n", list->desc, index, list->entry_size, offset);
        }
        index = (data >> list->np_star_bit) & ((1 << (list->np_end_bit - list->np_star_bit + 1)) - 1);
        saved_index = index;
    }

    if (saved_index != list->tail)
    {
        sal_fprintf(dest, "@actual tail = 0x%x, expetc tail = 0x%x\n", saved_index, list->tail);
        *pass = FALSE;
    }
    else if (counter != list->index_num)
    {
        sal_fprintf(dest, "@actual counter = 0x%x, expetc counter = 0x%x\n", counter, list->index_num);
        *pass = FALSE;
    }

    if(list->index_end == 0)
    {
        return;
    }

    sal_fprintf(dest, "%s missed index list \n", list->desc);
    for(index = list->index_start; index <= list->index_end; index ++)
    {
        if(!IS_BIT_SET(sim_asic_emu_bit_map[index / 32], (index % 32)))
        {
            sal_fprintf(dest, "index (0x%x) missed!\n", index);
        }
    }
}

static void
_sim_asic_emu_check_integrity_link_list_check(uint8 chip_id,
                                                    uint32 *addr,
                                                    FILE *dest,
                                                    uint8 *pass)
{
    link_list_t link_list;

    /* DsQueueLinkList FreeList Check */
    link_list.base = addr[DS_QUE_LINK_LIST_BASE];
    link_list.head = addr[FL_QUE_LINK_HEAD];
    link_list.tail   =  addr[FL_QUE_LINK_TAIL];
    link_list.entry_size = 8;
    link_list.np_offset  = 0;
    link_list.np_star_bit = 0;
    link_list.np_end_bit = 14;
    link_list.index_start = 0;
    link_list.index_end = addr[FL_QUE_LINK_COUNTER] - 1;
    link_list.index_num= addr[FL_QUE_LINK_COUNTER];
    link_list.desc = "DsQueueLinkList";
    _sim_asic_emu_link_list_check(chip_id, &link_list, dest, pass);

    /* DsBufferStoreLinkList FreeList0 Check */
    link_list.base = addr[FL_BUF_STORE_BASE];
    link_list.head = addr[FL_BUF_STORE_HEAD0];
    link_list.tail   = addr[FL_BUF_STORE_TAIL0];
    link_list.entry_size = 4;
    link_list.np_offset  = 0;
    link_list.np_star_bit = 0;
    link_list.np_end_bit = 14;
    link_list.index_start = 0;
    link_list.index_end = addr[FL_BUF_STORE_COUNTER0] -1;
    link_list.index_num= addr[FL_BUF_STORE_COUNTER0];
    link_list.desc = "DsBufferLinkList0";
    _sim_asic_emu_link_list_check(chip_id, &link_list, dest, pass);

    /* DsNetRxLinkList FreeList Check */
    link_list.base = addr[FL_NET_RX_BASE];
    link_list.head = addr[FL_NET_RX_HEAD];
    link_list.tail   = addr[FL_NET_RX_TAIL];
    link_list.entry_size = 4;
    link_list.np_offset  = 0;
    link_list.np_star_bit = 0;
    link_list.np_end_bit = 7;
    link_list.index_start = 0;
    link_list.index_end =  addr[FL_NET_RX_COUNTER] - 1;
    link_list.index_num = addr[FL_NET_RX_COUNTER];
    link_list.desc = "DsNetRxList";
    _sim_asic_emu_link_list_check(chip_id, &link_list, dest, pass);

}

#endif

int32
sim_asic_emu_check_integrity_gen_compare(uint8 chip_id,
                                            char *src_file,
                                            char *dest_file)
{
#if !defined(SDK_IN_KERNEL)
    FILE *src =NULL, *dest = NULL;
    char  line[512];
    uint32 data[3];

    src = fopen(src_file, "r");
    if (NULL == src)
    {
        CMODEL_DEBUG_OUT_INFO("open temp file failed!\n");
        return (-1);
    }

    dest = fopen(dest_file, "w+");
    if (NULL == dest)
    {
        fclose(src);
        CMODEL_DEBUG_OUT_INFO("open destination file failed!\n");
        return (-1);
    }

    sal_memset(line, 0, 512);
    while (NULL != fgets(line, 512, src))
    {
        char *sub_string, exps[20];

        if ('#' == line[0])
        {
            sal_fprintf(dest, "%s", line);
        }
        else
        {
            sub_string = sal_strstr(line, "=");
            if(NULL == sub_string)
            {
                sal_fprintf(dest, "%s", line);
            }
            else if((NULL == sal_strstr(sub_string, "{")) || (NULL != sal_strstr(sub_string, "N{")))
            {
                sal_fprintf(dest, "%s", line);
            }
            else
            {
                sub_string[1] = '\0';

                _sim_asic_emu_check_integrity_calc_proc(chip_id, sub_string + 2, data);
                sal_sprintf(exps, "  %x\n", data[0]);
                sal_strcat(line, exps);
                sal_fprintf(dest, "%s", line);
            }
        }

        sal_memset(line, 0, 512);
    }

    fclose(src);
    src = NULL;
    fclose(dest);
    dest = NULL;

    /* convert tcl script to plain text */
    sal_sprintf(line, "sed -i -e 's/N{/{/g' %s ", dest_file);
    system(line);
#endif
    return DRV_E_NONE;
}

int32
sim_asic_emu_check_integrity_gen_result(uint8 chip_id, char *src_file,  char *dest_file)
{
#if !defined(SDK_IN_KERNEL)
    FILE *src =NULL, *dest = NULL;
    char   line[512] = {0};
    char   exps[40] = {0};
    char*  rslt = NULL;
    uint8  pass = TRUE;
    uint32 addr[MAX_ADDR_NUM] = {0};
    uint32 expect[3] = {0};
    uint32 actual[3] = {0};

    src = fopen(src_file, "r");
    if (NULL == src)
    {
        CMODEL_DEBUG_OUT_INFO("open source file failed!\n");
        return (-1);
    }

    dest = fopen(dest_file, "w+");
    if (NULL == dest)
    {
        CMODEL_DEBUG_OUT_INFO("open destination file failed!\n");
        fclose(src);
        src = NULL;
        return (-1);
    }

    sal_memset(line, 0, 512);
    while (NULL != fgets(line, 512, src))
    {
        /* comment line */
        if ('#' == line[0])
        {
            sal_fprintf(dest, "%s", line);
        }
        /* plain line */
        else if (NULL == sal_strstr(line, "="))
        {
            sal_fprintf(dest, "%s", line);
        }
        /* macro line */
        else if ((NULL == sal_strstr(line, "{")) || (sal_strstr(line, "{") > sal_strstr(line, "=")))
        {
            sal_fprintf(dest, "%s", line);
            _sim_asic_emu_check_integrity_macro_line_handle(chip_id, line, addr);
        }
        /* raw line */
        else
        {
            rslt = sal_strstr(line, "=");
            rslt[1] = '\0';
            _sim_asic_emu_check_integrity_calc_proc(chip_id, line, actual);
            _sim_asic_emu_check_integrity_calc_proc(chip_id, rslt + 2, expect);
            if(actual[0] == expect[0])
            {
                sal_sprintf(exps, " %x", actual[0]);
                sal_strcat(line, exps);
                sal_fprintf(dest, "%s", line);
            }
            else
            {
                sal_sprintf(exps, " %x @expect %x!", actual[0], expect[0]);
                sal_strcat(line, exps);
                pass = FALSE;
                sal_fprintf(dest, "%s", line);
            }

            if (actual[1])
            {
                sal_fprintf(dest, " -- Before mask actual = %x\n", actual[2]);
            }

            if (expect[1])
            {
                sal_fprintf(dest, " -- Before mask expect = %x\n", expect[2]);
            }

            if (!actual[1] && ! expect[1])
            {
                sal_fprintf(dest, "\n");
            }
        }

        sal_memset(line, 0, 512);
    }
    _sim_asic_emu_check_integrity_link_list_check(chip_id, addr, dest, &pass);

    fclose(src);
    src = NULL;
    fclose(dest);
    dest = NULL;

    if (pass)
    {
        CMODEL_DEBUG_OUT_INFO("\nemulation integrity check %d %s %s passed!", chip_id, src_file, dest_file);
    }
    else
    {
        CMODEL_DEBUG_OUT_INFO("\nemulation integrity check %d %s %s failed!", chip_id, src_file, dest_file);
    }
#endif
    return DRV_E_NONE;
}

