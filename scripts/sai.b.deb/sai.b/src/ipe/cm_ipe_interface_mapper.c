/****************************************************************************
 * cm_ipe_interface_mapper.c: Provides IPE interface mapper handle function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       zhouw .
 * Date:         2008-01-13.
 * Reason:       First Create.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Mengzhw .
 * Date:         2010-11-23.
 * Reason:       SYNC GreatBelt 1.0.
 *
 * Revision:     V4.28.
 * Author:       Mengzhw .
 * Date:         2011-09-30.
 * Reason:       SYNC GreatBelt 4.28.
 *
 * Revision:     V5.1.0
 * Author:       Wangcy.
 * Date:         2011-12-12.
 * Reason:       sync spec v5.1.0.
 *
 * Revision:     V5.6.0
 * Author:       Wangcy.
 * Date:         2012-01-07.
 * Reason:       sync spec v5.6.0.
 *
 * Revision:     V5.7.0
 * Author:       Wangcy.
 * Date:         2012-01-17.
 * Reason:       sync spec v5.7.0.
 *
 * Reversion:    V5.11.0
 * Author:       ZhouW
 * Date:         2012-03-01.
 * Reason:       sync spec v5.11.0.
 *
 * Reversion:    V5.13.0
 * Author:       Wangcy
 * Date:         2012-03-12.
 * Reason:       sync spec v5.13.0.
 *
 * Reversion:    V5.15.0.1
 * Author:       Wangcy
 * Date:         2012-03-23.
 * Reason:       sync spec v5.15.0.1
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "ctcutil_lib.h"
#include "cm_lib.h"
#include "drv_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
struct interface_map_info_s
{
    uint32 vlan_tag_ctl            :4;
    uint32 ingress_filtering_en    :1;
    uint32 protocol_vlan_en        :1;
    uint32 protocol_vlan_id_valid  :1;
    uint32 protocol_replace_tag_en :1;
    uint32 pip_macsa_low           :8;
    uint32 protocol_vlan_id        :12;
    uint32 svlan_exist             :1;
    uint32 cvlan_exist             :1;
    uint32 macda_router_mac_type   :2;
    uint32 protocol_cos            :3;
    uint32 protocol_cfi            :1;
    uint32 protocol_cos_valid      :1;
    uint32 vlan_status_ptr         :9;
    uint32 added_default_svlan_tag :1;
    uint32 added_default_cvlan_tag :1;
    uint32 ingress_filtering_disable   :1;
    uint32 port_vsi_high_priority  :1;
    uint32 port_receive_disable    :1;
    uint32 vlan_receive_disable    :1;
};
typedef struct interface_map_info_s interface_map_info_t;

/****************************************************************************
 * Name:       _cm_ipe_interface_mapper_get_port_info
 * Purpose:    Get port information.
 * Parameters:
 * Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                      header, and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                      header, and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_interface_mapper_get_port_info(ipe_in_pkt_t *in_pkt, interface_map_info_t *map_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;
    uint32 cmd = 0;
    ds_src_port_t ds_src_port;

    /* RETRIEVE_DS_SRC_PORT */
    sal_memset(&ds_src_port, 0, sizeof(ds_src_port));
    cmd = DRV_IOR(DsSrcPort_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, pkt_info->local_phy_port, cmd, &ds_src_port));

    map_info->ingress_filtering_en = ds_src_port.ingress_filtering_en;
    map_info->ingress_filtering_disable = ds_src_port.ingress_filtering_disable;
    map_info->vlan_tag_ctl = ds_src_port.vlan_tag_ctl;
    map_info->protocol_vlan_en = ds_src_port.protocol_vlan_en;
    map_info->port_vsi_high_priority = ds_src_port.port_vsi_high_priority;

    /* consider ttl pipe mode or uniform mode??? */
    if (ds_src_port.use_outer_ttl)
    {
        pkt_info->packet_ttl = pkt_info->outer_ttl;
    }
    else
    {
        pkt_info->packet_ttl = parser_result->l3_s.ttl;
    }

    /* save informations to packet info data structure */
    pkt_info->mac_security_discard = ds_src_port.mac_security_discard;
    pkt_info->l2_acl_en0 = ds_src_port.l2_acl_en0;
    pkt_info->l2_acl_en1 = ds_src_port.l2_acl_en1;
    pkt_info->l2_acl_en2 = ds_src_port.l2_acl_en2;
    pkt_info->l2_acl_en3 = ds_src_port.l2_acl_en3;
    pkt_info->bridge_en = ds_src_port.bridge_en;
    pkt_info->interface_id = ds_src_port.interface_id;
    pkt_info->port_policer_valid = ds_src_port.port_policer_valid;
    pkt_info->qos_policy = ds_src_port.qos_policy;
    pkt_info->l2_acl_label = ds_src_port.l2_acl_label;
    pkt_info->rpf_type = ds_src_port.rpf_type;
    pkt_info->routed_port = ds_src_port.routed_port;
    pkt_info->ipg_index = ds_src_port.ipg_index;
    pkt_info->qos_domain = ds_src_port.qos_domain;
    pkt_info->port_security_en = ds_src_port.port_security_en;
    pkt_info->port_security_exception_en = ds_src_port.port_security_exception_en;
    pkt_info->dhcp_exception_type = ds_src_port.dhcp_exception_type;
    pkt_info->port_check_en = ds_src_port.port_check_en;
    pkt_info->force_acl_qos_ipv4_to_mac_key = ds_src_port.force_acl_qos_ipv4to_mac_key;
    pkt_info->force_acl_qos_ipv6_to_mac_key = ds_src_port.force_acl_qos_ipv6to_mac_key;
    pkt_info->trill_en = ds_src_port.trill_en;
    pkt_info->arp_exception_type = ds_src_port.arp_exception_type;
    pkt_info->fcoe_en = ds_src_port.fcoe_en;
    pkt_info->fcoe_rpf_en = ds_src_port.fcoe_rpf_en;
    pkt_info->speed = ds_src_port.speed;
    pkt_info->acl_port_num = ds_src_port.acl_port_num;
    pkt_info->l2_ipv6_acl_en0 = ds_src_port.l2_ipv6_acl_en0;
    pkt_info->l2_ipv6_acl_en1 = ds_src_port.l2_ipv6_acl_en1;
    pkt_info->port_storm_ctl_ptr = ds_src_port.port_storm_ctl_ptr;
    pkt_info->port_storm_ctl_en = ds_src_port.port_storm_ctl_en;
    pkt_info->mpls_section_lm_en = ds_src_port.mpls_section_lm_en;
    pkt_info->ether_lm_valid = ds_src_port.ether_lm_valid;
    pkt_info->force_ipv6_key = ds_src_port.force_ipv6_key;
    pkt_info->mac_key_use_label =ds_src_port.mac_key_use_label;
    pkt_info->ipv4_key_use_label = ds_src_port.ipv4_key_use_label;
    pkt_info->ipv6_key_use_label = ds_src_port.ipv6_key_use_label;
    pkt_info->mpls_key_use_label =ds_src_port.mpls_key_use_label;
    pkt_info->link_lm_type = ds_src_port.link_lm_type;
    pkt_info->link_lm_cos = ds_src_port.link_lm_cos;
    pkt_info->link_lm_cos_type = ds_src_port.link_lm_cos_type;
    pkt_info->fast_learning_en = ds_src_port.fast_learning_en;
    pkt_info->link_lm_index_base = ds_src_port.link_lm_index_base;
    pkt_info->ether_oam_edge_port = ds_src_port.ether_oam_edge_port;

    pkt_info->service_acl_qos_en = pkt_info->service_acl_qos_en || ds_src_port.service_acl_qos_en;

    pkt_info->route_disable |= ds_src_port.route_disable;
    pkt_info->learning_disable |= ds_src_port.learning_disable;
    pkt_info->oam_tunnel_en = pkt_info->oam_tunnel_en || (ds_src_port.oam_tunnel_en && (!pkt_info->from_cpu_or_oam));

    if (!pkt_info->is_loop)
    {
        pkt_info->src_port_isolate_id = ds_src_port.src_port_isolate_id;
    }

    map_info->port_receive_disable = ds_src_port.receive_disable;
    map_info->pip_macsa_low = ds_src_port.pip_mac_sa;

    pkt_info->is_leaf = pkt_info->is_leaf || ds_src_port.is_leaf;

    if (!ds_src_port.port_cross_connect && (0 != pkt_info->vrfid_or_ds_fwd_ptr))
    {
        pkt_info->vsi_id = pkt_info->vrfid_or_ds_fwd_ptr & 0x3FFF;
    }

    /* port cross connect */
    if (ds_src_port.port_cross_connect)
    {
        pkt_info->ds_fwd_ptr_valid = TRUE;
        pkt_info->ds_fwd_ptr = pkt_info->vrfid_or_ds_fwd_ptr;
        pkt_info->payload_packet_type = pkt_info->packet_type;
    }

    if (!pkt_info->logic_src_port_valid)
    {
        pkt_info->logic_src_port = pkt_info->default_logic_src_port;
        pkt_info->logic_port_type |= ds_src_port.logic_port_type;
    }

    if ((ds_src_port.discard_trill && (L3_TYPE_TRILL == parser_result->layer3_type))
        ||(ds_src_port.discard_non_trill && (L3_TYPE_TRILL != parser_result->layer3_type)))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_TRILL_FILTER_ERR;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DsSrcPort discardTrill, and portID = %d !\n", pkt_info->local_phy_port);
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (ds_src_port.aps_select_valid)
    {
        if (!pkt_info->aps_select_valid0)
        {
            pkt_info->aps_select_valid0 = TRUE;
            pkt_info->aps_select_protecting_path0 = ds_src_port.aps_select_protecting_path;
            pkt_info->aps_select_group_id0 = ds_src_port.aps_group_id;
        }
        else if (!pkt_info->aps_select_valid1)
        {
            pkt_info->aps_select_valid1 = TRUE;
            pkt_info->aps_select_protecting_path1 = ds_src_port.aps_select_protecting_path;
            pkt_info->aps_select_group_id1 = ds_src_port.aps_group_id;
        }
        else
        {
            pkt_info->aps_select_valid2 = TRUE;
            pkt_info->aps_select_protecting_path2 = ds_src_port.aps_select_protecting_path;
            pkt_info->aps_select_group_id2 = ds_src_port.aps_group_id;
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_interface_mapper_pbb_process
 * Purpose:    ipe pbb process function.
 * Parameters:
 * Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                      header, and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                      header, and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_interface_mapper_pbb_process(ipe_in_pkt_t *in_pkt , interface_map_info_t *map_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;

    uint32 cmd = 0;
    uint8 loop_bmacda = 0;
    uint8 itag_check_discard = FALSE;
    uint8 invalid_bmacda = FALSE;
    uint8 itag_nca_check_discard = FALSE, itag_res2_check_discard = FALSE;
    uint8 pip_port_bmac_chk_discard = FALSE;
    uint8 pbb_type_ispip = FALSE, pbb_type_iscbp = FALSE;
    uint8 macda_pipmacsa_match = FALSE, macda_pbbgrpadd_match = FALSE, macda_is_bcast_addr = FALSE;
    uint32 rslt_macda_47to32 = 0, rslt_macda_31to0 = 0;
    uint32 rslt_macsa_47to32 = 0, rslt_macsa_31to0 = 0;
    uint32 pip_macsa_47to32 = 0, pip_macsa_31to0 = 0;
    uint32 pbb_group_address_47to32 = 0, pbb_group_address_31to0 = 0;
    ipe_intf_mapper_ctl_t intf_map_ctl;
    uint32 pbb_isid = 0, pbb_res2 = 0, pbb_nca = 0;

    sal_memset(&intf_map_ctl, 0, sizeof(ipe_intf_mapper_ctl_t));
    cmd = DRV_IOR(IpeIntfMapperCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &intf_map_ctl));

    pip_macsa_31to0 = (intf_map_ctl.pip_mac_sa_low << 8) | map_info->pip_macsa_low;
    pip_macsa_47to32 = intf_map_ctl.pip_mac_sa_high;

    /* {pcp[2:0], dei[0], nca[0], res1[0], res2[1:0], isid[23:0]} */
    pbb_isid = (parser_result->l3_s.ip_da.cmac.itag_tci.itag_tci & 0xFFFFFF);
    pbb_res2 = ((parser_result->l3_s.ip_da.cmac.itag_tci.itag_tci >>24) & 0x3);
    pbb_nca = IS_BIT_SET(parser_result->l3_s.ip_da.cmac.itag_tci.itag_tci, 27);

    pbb_group_address_47to32 = (intf_map_ctl.pbb_oui_value >> 8) & 0xFFFF;
    pbb_group_address_31to0 = ((intf_map_ctl.pbb_oui_value&0xFF)<<24) | pbb_isid;

    pbb_type_ispip = (PBB_PORT_TYPE_PIP == pkt_info->pbb_src_port_type)
        || ((PBB_PORT_TYPE_PNP == pkt_info->pbb_src_port_type) && intf_map_ctl.pnp_check_en);

    pbb_type_iscbp = (PBB_PORT_TYPE_CBP == pkt_info->pbb_src_port_type);

    itag_check_discard = intf_map_ctl.i_tag_valid_check
                         && ((L3_TYPE_CMAC != parser_result->layer3_type)
                         && (L4_TYPE_PBB_ITAG_OAM != parser_result->layer4_type))
                         && (pbb_type_ispip || pbb_type_iscbp);

    itag_res2_check_discard = (pbb_type_iscbp || pbb_type_ispip)
                              && (L3_TYPE_CMAC == parser_result->layer3_type)
                              && (0x0 != pbb_res2)
                              && intf_map_ctl.pbb_tci_res2_check_en;

    itag_nca_check_discard = pbb_type_ispip
                             && (L3_TYPE_CMAC == parser_result->layer3_type)
                             && ((pbb_nca != intf_map_ctl.nca_value)
                             && intf_map_ctl.pbb_tci_nca_check_en);

    rslt_macda_47to32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);
    rslt_macda_31to0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                   parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);

    macda_pipmacsa_match = (pip_macsa_31to0 == rslt_macda_31to0) && (pip_macsa_47to32 == rslt_macda_47to32);
    macda_pbbgrpadd_match = (pbb_group_address_31to0 == rslt_macda_31to0)
                            && (pbb_group_address_47to32 == rslt_macda_47to32);
    macda_is_bcast_addr = ((0xFFFFFFFF == rslt_macda_31to0) && (0xFFFF == rslt_macda_47to32));
    invalid_bmacda = (!macda_pipmacsa_match) && (!macda_pbbgrpadd_match)
                     && (L4_TYPE_PBB_ITAG_OAM != parser_result->layer4_type)
                     && (!macda_is_bcast_addr);

    rslt_macsa_47to32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
    rslt_macsa_31to0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                   parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
    loop_bmacda = (pip_macsa_31to0 == rslt_macsa_31to0) && (pip_macsa_47to32 == rslt_macsa_47to32);

    pip_port_bmac_chk_discard = pbb_type_ispip
                                && ((invalid_bmacda && intf_map_ctl.pip_invalid_mac_da_check)
                                    || (loop_bmacda && intf_map_ctl.pip_loop_mac_check));

    if (pbb_type_ispip
        && (L3_TYPE_CMAC == parser_result->layer3_type)
        && (pbb_nca != intf_map_ctl.nca_value)
        && (L4_TYPE_PBB_ITAG_OAM != parser_result->layer4_type)
        && intf_map_ctl.pbb_tci_nca_check_en
        && intf_map_ctl.pbb_tci_nca_exception_en
        && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PBB_TCI_NCA;
    }

    if (itag_check_discard || pip_port_bmac_chk_discard || itag_nca_check_discard || itag_res2_check_discard)
    {
        if ((intf_map_ctl.pbb_check_discard_type && (PBB_PORT_TYPE_PNP == pkt_info->pbb_src_port_type))
            || (PBB_PORT_TYPE_CBP == pkt_info->pbb_src_port_type) || (PBB_PORT_TYPE_PIP == pkt_info->pbb_src_port_type))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_ITAG_CHK_FAIL;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! PBB ITag check fail!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else
        {
            pkt_info->pbb_check_discard = TRUE;
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_intreface_mapper_protocol_vlan_handle
 * Purpose:    Protocol vlan classification process.
 * Parameters:
 * Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                      header, and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                      header, and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_intreface_mapper_protocol_vlan_handle(ipe_in_pkt_t *in_pkt, interface_map_info_t *map_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;
    ds_protocol_vlan_t ds_protocol_vlan;

    uint32 cmd = 0;
    uint8 index = 0;
    uint8 protocol_vlan_id_valid = FALSE;
    uint8 cpu_exception_en = FALSE;
    uint8 discard = FALSE;
    uint8 protocol_replace_tag_en = FALSE;
    uint16 protocol_vlan_id = 0;
    uint8 protocol_cos = 0;
    uint8 protocol_cfi = 0;
    uint8 protocol_cos_valid = FALSE;

    sal_memset(&ds_protocol_vlan, 0, sizeof(ds_protocol_vlan));
    cmd = DRV_IOR(DsProtocolVlan_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ds_protocol_vlan));

    if (map_info->protocol_vlan_en)
    {

        if (parser_result->l2_s.layer2_header_protocol == ds_protocol_vlan.protocol_ether_type0)
        {
            index = 0;
        }
        else if (parser_result->l2_s.layer2_header_protocol == ds_protocol_vlan.protocol_ether_type1)
        {
            index = 1;
        }
        else if (parser_result->l2_s.layer2_header_protocol == ds_protocol_vlan.protocol_ether_type2)
        {
            index = 2;
        }
        else if (parser_result->l2_s.layer2_header_protocol == ds_protocol_vlan.protocol_ether_type3)
        {
            index = 3;
        }
        else if (parser_result->l2_s.layer2_header_protocol == ds_protocol_vlan.protocol_ether_type4)
        {
            index = 4;
        }
        else if (parser_result->l2_s.layer2_header_protocol == ds_protocol_vlan.protocol_ether_type5)
        {
            index = 5;
        }
        else if (parser_result->l2_s.layer2_header_protocol == ds_protocol_vlan.protocol_ether_type6)
        {
            index = 6;
        }
        else if (parser_result->l2_s.layer2_header_protocol == ds_protocol_vlan.protocol_ether_type7)
        {
            index = 7;
        }
        else
        {
            map_info->protocol_vlan_en = FALSE;
        }
    }

    if (map_info->protocol_vlan_en)
    {
        sal_memset(&ds_protocol_vlan, 0, sizeof(ds_protocol_vlan));
        cmd = DRV_IOR(DsProtocolVlan_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ds_protocol_vlan));

        switch (index & 0x7)
        {
            case 0:
                protocol_vlan_id_valid = ds_protocol_vlan.protocol_vlan_id_valid0;
                cpu_exception_en = ds_protocol_vlan.cpu_exception_en0;
                discard = ds_protocol_vlan.discard0;
                protocol_replace_tag_en = ds_protocol_vlan.protocol_replace_tag_en0;
                protocol_vlan_id = ds_protocol_vlan.protocol_vlan_id0;
                protocol_cos = ds_protocol_vlan.protocol_cos0;
                protocol_cfi = ds_protocol_vlan.protocol_cfi0;
                protocol_cos_valid = ds_protocol_vlan.protocol_cos_valid0;
                break;
            case 1:
                protocol_vlan_id_valid = ds_protocol_vlan.protocol_vlan_id_valid1;
                cpu_exception_en = ds_protocol_vlan.cpu_exception_en1;
                discard = ds_protocol_vlan.discard1;
                protocol_replace_tag_en = ds_protocol_vlan.protocol_replace_tag_en1;
                protocol_vlan_id = ds_protocol_vlan.protocol_vlan_id1;
                protocol_cos = ds_protocol_vlan.protocol_cos1;
                protocol_cfi = ds_protocol_vlan.protocol_cfi1;
                protocol_cos_valid = ds_protocol_vlan.protocol_cos_valid1;
                break;
            case 2:
                protocol_vlan_id_valid = ds_protocol_vlan.protocol_vlan_id_valid2;
                cpu_exception_en = ds_protocol_vlan.cpu_exception_en2;
                discard = ds_protocol_vlan.discard2;
                protocol_replace_tag_en = ds_protocol_vlan.protocol_replace_tag_en2;
                protocol_vlan_id = ds_protocol_vlan.protocol_vlan_id2;
                protocol_cos = ds_protocol_vlan.protocol_cos2;
                protocol_cfi = ds_protocol_vlan.protocol_cfi2;
                protocol_cos_valid = ds_protocol_vlan.protocol_cos_valid2;
                break;
            case 3:
                protocol_vlan_id_valid = ds_protocol_vlan.protocol_vlan_id_valid3;
                cpu_exception_en = ds_protocol_vlan.cpu_exception_en3;
                discard = ds_protocol_vlan.discard3;
                protocol_replace_tag_en = ds_protocol_vlan.protocol_replace_tag_en3;
                protocol_vlan_id = ds_protocol_vlan.protocol_vlan_id3;
                protocol_cos = ds_protocol_vlan.protocol_cos3;
                protocol_cfi = ds_protocol_vlan.protocol_cfi3;
                protocol_cos_valid = ds_protocol_vlan.protocol_cos_valid3;
                break;
            case 4:
                protocol_vlan_id_valid = ds_protocol_vlan.protocol_vlan_id_valid4;
                cpu_exception_en = ds_protocol_vlan.cpu_exception_en4;
                discard = ds_protocol_vlan.discard4;
                protocol_replace_tag_en = ds_protocol_vlan.protocol_replace_tag_en4;
                protocol_vlan_id = ds_protocol_vlan.protocol_vlan_id4;
                protocol_cos = ds_protocol_vlan.protocol_cos4;
                protocol_cfi = ds_protocol_vlan.protocol_cfi4;
                protocol_cos_valid = ds_protocol_vlan.protocol_cos_valid4;
                break;
            case 5:
                protocol_vlan_id_valid = ds_protocol_vlan.protocol_vlan_id_valid5;
                cpu_exception_en = ds_protocol_vlan.cpu_exception_en5;
                discard = ds_protocol_vlan.discard5;
                protocol_replace_tag_en = ds_protocol_vlan.protocol_replace_tag_en5;
                protocol_vlan_id = ds_protocol_vlan.protocol_vlan_id5;
                protocol_cos = ds_protocol_vlan.protocol_cos5;
                protocol_cfi = ds_protocol_vlan.protocol_cfi5;
                protocol_cos_valid = ds_protocol_vlan.protocol_cos_valid5;
                break;
            case 6:
                protocol_vlan_id_valid = ds_protocol_vlan.protocol_vlan_id_valid6;
                cpu_exception_en = ds_protocol_vlan.cpu_exception_en6;
                discard = ds_protocol_vlan.discard6;
                protocol_replace_tag_en = ds_protocol_vlan.protocol_replace_tag_en6;
                protocol_vlan_id = ds_protocol_vlan.protocol_vlan_id6;
                protocol_cos = ds_protocol_vlan.protocol_cos6;
                protocol_cfi = ds_protocol_vlan.protocol_cfi6;
                protocol_cos_valid = ds_protocol_vlan.protocol_cos_valid6;
                break;
            case 7:
                protocol_vlan_id_valid = ds_protocol_vlan.protocol_vlan_id_valid7;
                cpu_exception_en = ds_protocol_vlan.cpu_exception_en7;
                discard = ds_protocol_vlan.discard7;
                protocol_replace_tag_en = ds_protocol_vlan.protocol_replace_tag_en7;
                protocol_vlan_id = ds_protocol_vlan.protocol_vlan_id7;
                protocol_cos = ds_protocol_vlan.protocol_cos7;
                protocol_cfi = ds_protocol_vlan.protocol_cfi7;
                protocol_cos_valid = ds_protocol_vlan.protocol_cos_valid7;
                break;
            default:
                break;
        }

        map_info->protocol_vlan_id_valid = protocol_vlan_id_valid;
        if (cpu_exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_PROTOCOL_VLAN;
        }

        if (discard)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_PTL_VLAN_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Protocol vlan discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        map_info->protocol_replace_tag_en = protocol_replace_tag_en;
        map_info->protocol_vlan_id = protocol_vlan_id;
        map_info->protocol_cos = protocol_cos;
        map_info->protocol_cfi = protocol_cfi;
        map_info->protocol_cos_valid = protocol_cos_valid;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_interface_mapper_vlan_tag_control
 * Purpose:    IPE vlan tagged control handle.
 * Parameters:
 * Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_interface_mapper_vlan_tag_control(ipe_in_pkt_t *in_pkt, interface_map_info_t *map_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t  *parser_result = (parsing_result_t *) pkt_info->parser_rslt;
    uint8 vlan_tag_ctl_discard = FALSE;
    uint32 cmd = 0;
    ipe_intf_mapper_ctl_t ipe_intf_mapper_ctl;

    /* VLAN_TAG_CTL */
    map_info->svlan_exist = parser_result->l2_s.svlan_id_valid && (parser_result->l2_s.svlan_id != 0);
    map_info->cvlan_exist = parser_result->l2_s.cvlan_id_valid && (parser_result->l2_s.cvlan_id != 0);

    sal_memset(&ipe_intf_mapper_ctl, 0, sizeof(ipe_intf_mapper_ctl_t));
    cmd = DRV_IOR(IpeIntfMapperCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_intf_mapper_ctl));

    switch(map_info->vlan_tag_ctl)
    {
        case 1: /* drop all untagged inlcude priority tagged */
            vlan_tag_ctl_discard = !(map_info->svlan_exist || map_info->cvlan_exist);
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop all untagged packet!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 2: /* drop alltagged not inlcude priority tagged */
            vlan_tag_ctl_discard = (map_info->svlan_exist || map_info->cvlan_exist);
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop all tagged packet!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 3: /* drop all */
            vlan_tag_ctl_discard = TRUE;
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop all packet!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 4: /* drop pkt without 2 vlan tagged */
            vlan_tag_ctl_discard = !(map_info->svlan_exist && map_info->cvlan_exist);
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop packet without double vlan tagged!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 5: /* drop all 2 vlan tagged */
            vlan_tag_ctl_discard = (map_info->svlan_exist && map_info->cvlan_exist);
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop packet with double vlan tagged!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 6: /* drop all svlan tagged */
            vlan_tag_ctl_discard = map_info->svlan_exist;
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop all packet with stag!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 7: /* drop all none svlan tagged */
            vlan_tag_ctl_discard = !map_info->svlan_exist;
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop all packet without stag!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 8: /* drop only svlan tagged */
            vlan_tag_ctl_discard = (map_info->svlan_exist && (!map_info->cvlan_exist));
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop all packet only with stag!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 9: /* permit only svlan tagged */
            vlan_tag_ctl_discard = !(map_info->svlan_exist && !(map_info->cvlan_exist));
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to permit all packet only with stag!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 10: /* drop all cvlan tagged */
            vlan_tag_ctl_discard = map_info->cvlan_exist;
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop all packet with ctag!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 11: /* drop all none cvlan tagged */
            vlan_tag_ctl_discard = !map_info->cvlan_exist;
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop all packet without ctag!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 12: /* drop only cvlan tagged */
            vlan_tag_ctl_discard = map_info->cvlan_exist && !map_info->svlan_exist;
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to drop all packet only with ctag!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        case 13: /* permit only cvlan tagged */
            vlan_tag_ctl_discard = !(map_info->cvlan_exist && !map_info->svlan_exist);
            if (vlan_tag_ctl_discard)
            {
                CMODEL_DEBUG_OUT_INFO("++++ Discard! AFT control to permit all packet only with ctag!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
            break;

        default:
            vlan_tag_ctl_discard = FALSE;
            /* admit all */
            break;
    }

    if (vlan_tag_ctl_discard && !pkt_info->from_cpu_or_oam)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_VLAN_TAG_CTL_DISCARD;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! vlan tag control discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    return DRV_E_NONE;
}
/****************************************************************************
 * Name:       _cm_ipe_interface_mapper_security_check
 * Purpose:    IPE security check handle.
 * Parameters:
 * Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_interface_mapper_security_check(ipe_in_pkt_t *in_pkt, interface_map_info_t *map_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t  *parser_result = (parsing_result_t *) pkt_info->parser_rslt;
    uint32 cmd = 0;
    uint8 mac_da_equal_sa = FALSE;
    uint8 ipv4_da_equal_sa = FALSE, ipv6_da_equal_sa = FALSE;
    ipe_intf_mapper_ctl_t ipe_intf_mapper_ctl;

    sal_memset(&ipe_intf_mapper_ctl, 0, sizeof(ipe_intf_mapper_ctl_t));
    cmd = DRV_IOR(IpeIntfMapperCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_intf_mapper_ctl));

    /* SECURITY_CHECK */
    /* discard multicast MAC SA */
    if (IS_BIT_SET(parser_result->l2_s.mac_sa5, 0) && !ipe_intf_mapper_ctl.allow_mcast_mac_sa
            && ((L2_TYPE_ETHV2 == parser_result->layer2_type) || (L2_TYPE_ETHSAP == parser_result->layer2_type)
                || (L2_TYPE_ETHSNAP == parser_result->layer2_type)))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_NOT_ALLOW_MCAST_MAC_SA_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! All packet with Mcast MacSa will be dropped!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* discard equal mac or equal ip */
    mac_da_equal_sa = ((parser_result->layer2_type == L2_TYPE_ETHV2)
                        || (parser_result->layer2_type == L2_TYPE_ETHSAP)
                        || (parser_result->layer2_type == L2_TYPE_ETHSNAP))
                        && (parser_result->l2_s.mac_da0 == parser_result->l2_s.mac_sa0)
                        && (parser_result->l2_s.mac_da1 == parser_result->l2_s.mac_sa1)
                        && (parser_result->l2_s.mac_da2 == parser_result->l2_s.mac_sa2)
                        && (parser_result->l2_s.mac_da3 == parser_result->l2_s.mac_sa3)
                        && (parser_result->l2_s.mac_da4 == parser_result->l2_s.mac_sa4)
                        && (parser_result->l2_s.mac_da5 == parser_result->l2_s.mac_sa5);

    ipv4_da_equal_sa = (parser_result->layer3_type == L3_TYPE_IPV4)
                      && (parser_result->l3_s.ip_da.ipv4.ipda == parser_result->l3_s.ip_sa.ipv4.ipsa);

    ipv6_da_equal_sa = (parser_result->layer3_type == L3_TYPE_IPV6)
                      && (parser_result->l3_s.ip_da.ipv6.ipda_127_96 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96)
                      && (parser_result->l3_s.ip_da.ipv6.ipda_95_64 == parser_result->l3_s.ip_sa.ipv6.ipsa_95_64)
                      && (parser_result->l3_s.ip_da.ipv6.ipda_63_32 == parser_result->l3_s.ip_sa.ipv6.ipsa_63_32)
                      && (parser_result->l3_s.ip_da.ipv6.ipda_31_0 == parser_result->l3_s.ip_sa.ipv6.ipsa_31_0);

    if ((mac_da_equal_sa && ipe_intf_mapper_ctl.discard_same_mac_addr)
       || (ipv4_da_equal_sa && ipe_intf_mapper_ctl.discard_same_ip_addr)
       || (ipv6_da_equal_sa && ipe_intf_mapper_ctl.discard_same_ip_addr))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_NOT_ALLOW_MCAST_MAC_SA_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! the Same Mac and same IP address is not allowed!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* tcp/udp security check */
    if ((L4_TYPE_TCP == parser_result->layer4_type) || (L4_TYPE_UDP == parser_result->layer4_type))
    {
        if ((IS_BIT_SET(parser_result->l4_error_bits,0) && IS_BIT_SET(ipe_intf_mapper_ctl.layer4_security_check_en,0)) ||
            (IS_BIT_SET(parser_result->l4_error_bits,1) && IS_BIT_SET(ipe_intf_mapper_ctl.layer4_security_check_en,1)) ||
            (IS_BIT_SET(parser_result->l4_error_bits,2) && IS_BIT_SET(ipe_intf_mapper_ctl.layer4_security_check_en,2)) ||
            (IS_BIT_SET(parser_result->l4_error_bits,3) && IS_BIT_SET(ipe_intf_mapper_ctl.layer4_security_check_en,3)) ||
            (IS_BIT_SET(parser_result->l4_error_bits,4) && IS_BIT_SET(ipe_intf_mapper_ctl.layer4_security_check_en,4)) )
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_NOT_ALLOW_MCAST_MAC_SA_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! tcp/udp security check discard,same mac:%d,same ipv4:%d,same ipv6:%d\n",mac_da_equal_sa,ipv4_da_equal_sa,ipv6_da_equal_sa);
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    /* icmp security check */
    if ((L4_TYPE_ICMP == parser_result->layer4_type) && (0 != parser_result->l3_s.frag_info)
        && IS_BIT_SET(ipe_intf_mapper_ctl.layer4_security_check_en,5))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_NOT_ALLOW_MCAST_MAC_SA_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! icmp security check discard\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* gre version check */
    if ((L4_TYPE_GRE == parser_result->layer4_type)
        && ((0x7 & parser_result->l4_s.l4_src_port.gre_flags) != ipe_intf_mapper_ctl.gre_version)
        && ipe_intf_mapper_ctl.gre_version_check_en)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_NOT_ALLOW_MCAST_MAC_SA_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! gre version check failed\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_interface_mapper_mac_addr_handle
 * Purpose:    ipe mac address handle.
 * Parameters:
 * Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_interface_mapper_mac_addr_handle(ipe_in_pkt_t *in_pkt, interface_map_info_t *map_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;

    ipe_intf_mapper_ctl_t ipe_intf_mapper_ctl;
    ipe_router_mac_ctl_t ipe_router_mac_ctl;
    ipe_port_mac_ctl_t ipe_port_mac_ctl;

    uint8 mac_match_type0 = FALSE, mac_match_type1 = FALSE, mac_match_type2 = FALSE;
    uint32 mac_39_8 = 0;
    uint8 mac_47_40 = 0;
    uint16 system_mac_high = 0;
    uint32 system_mac_low = 0;
    uint8 system_mac_match = FALSE, port_mac_match = FALSE;
    uint16 psr_mac_da_high = 0;
    uint32 psr_mac_da_low = 0;
    uint32 cmd = 0;
    uint8 port_mac_type_high = 0;
    uint32 port_mac_type_low = 0;
    uint8 macda_match_type_bitmap = 0;

    /*MAC_ADDRESS*/
    mac_39_8 = MAKE_UINT32(parser_result->l2_s.mac_da4, parser_result->l2_s.mac_da3,
                           parser_result->l2_s.mac_da2, parser_result->l2_s.mac_da1);
    mac_47_40 = parser_result->l2_s.mac_da5;


    sal_memset(&ipe_router_mac_ctl, 0, sizeof(ipe_router_mac_ctl_t));
    cmd = DRV_IOR(IpeRouterMacCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_router_mac_ctl));

    /* check macDa[47:6] == router_mac_ctl.router_mac_type[47:6] */
    if ((mac_47_40 == ipe_router_mac_ctl.router_mac_type0_47_40)
        && (mac_39_8 == ipe_router_mac_ctl.router_mac_type0_39_8))
    {
        mac_match_type0 = TRUE;
    }

    if ((mac_47_40 == ipe_router_mac_ctl.router_mac_type1_47_40)
        && (mac_39_8 == ipe_router_mac_ctl.router_mac_type1_39_8))
    {
        mac_match_type1 = TRUE;
    }

    if ((mac_47_40 == ipe_router_mac_ctl.router_mac_type2_47_40)
        && (mac_39_8 == ipe_router_mac_ctl.router_mac_type2_39_8))
    {
        mac_match_type2 = TRUE;
    }

    /* case mac_match_type{2, 1, 0} */
    macda_match_type_bitmap = (mac_match_type2<<2) | (mac_match_type1<<1) | mac_match_type0;
    switch (macda_match_type_bitmap)
    {
        case 1:
            map_info->macda_router_mac_type = 0;
            break;
        case 2:
        case 3:
            map_info->macda_router_mac_type = 1;
            break;
        case 4:
        case 5:
        case 6:
        case 7:
            map_info->macda_router_mac_type = 2;
            break;
        default:
            map_info->macda_router_mac_type = 3;
            break;
    }

    sal_memset(&ipe_port_mac_ctl, 0, sizeof(ipe_port_mac_ctl_t));
    cmd = DRV_IOR(IpePortMacCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_port_mac_ctl));
    switch (pkt_info->port_mac_type)
    {
        case 0:
            port_mac_type_high = ipe_port_mac_ctl.port_mac_type0_47_40;
            port_mac_type_low = ipe_port_mac_ctl.port_mac_type0_39_8;
            break;
        case 1:
            port_mac_type_high = ipe_port_mac_ctl.port_mac_type1_47_40;
            port_mac_type_low = ipe_port_mac_ctl.port_mac_type1_39_8;
            break;
        default:
            break;
    }

    sal_memset(&ipe_intf_mapper_ctl, 0, sizeof(ipe_intf_mapper_ctl_t));
    cmd = DRV_IOR(IpeIntfMapperCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_intf_mapper_ctl));
    system_mac_low = ipe_intf_mapper_ctl.system_mac_low;
    system_mac_high = ipe_intf_mapper_ctl.system_mac_high;

    psr_mac_da_low = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                 parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
    psr_mac_da_high = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);

    /* Only unicast MAC,PBB/TRILL, etc multicast MAC DA not here. */
    /* to another port's macDa[47:0] of the same device??? */
    port_mac_match = (mac_47_40 == port_mac_type_high)
                      && (mac_39_8 == port_mac_type_low)
                      && (parser_result->l2_s.mac_da0 == pkt_info->port_mac_label);

    system_mac_match = (system_mac_high == psr_mac_da_high)
                        && (system_mac_low == psr_mac_da_low)
                        && ipe_intf_mapper_ctl.system_mac_en;

    if (port_mac_match || system_mac_match || ipe_port_mac_ctl.port_mac_check_disable)
    {
        pkt_info->is_port_mac = TRUE; /* only ucast MAC */
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_interface_mapper_assign_vid
 * Purpose:    VlanId assignment.
 * Parameters:
 * Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                      header, and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                      header, and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_interface_mapper_assign_vid(ipe_in_pkt_t *in_pkt, interface_map_info_t *map_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;
    uint32 cmd = 0;
    uint8 user_scos = 0;
    uint8 user_scfi = 0;
    uint8 user_ccos = 0;
    uint8 user_ccfi = 0;
    uint16 user_svlan_id = 0;
    uint16 user_cvlan_id = 0;

    ipe_intf_mapper_ctl_t intf_map_ctl;
    ds_src_port_t ds_src_port;

    /* VLAN_TAG */
    sal_memset(&ds_src_port, 0, sizeof(ds_src_port));
    cmd = DRV_IOR(DsSrcPort_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, pkt_info->local_phy_port, cmd, &ds_src_port));

    sal_memset(&intf_map_ctl, 0, sizeof(intf_map_ctl));
    cmd = DRV_IOR(IpeIntfMapperCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &intf_map_ctl));

    if ((PBB_PORT_TYPE_PBB_NONE != pkt_info->pbb_src_port_type)
        && !IS_BIT_SET(pkt_info->pbb_src_port_type, 2)
        && (L3_TYPE_CMAC == parser_result->layer3_type))
    {
        if (parser_result->l2_s.svlan_id_valid && ds_src_port.use_btag_cos)
        {
            pkt_info->source_cos = parser_result->l2_s.stag_cos;
            pkt_info->source_cfi = parser_result->l2_s.stag_cfi;
        }
        else
        {
            pkt_info->source_cos = (parser_result->l3_s.ip_da.cmac.itag_tci.itag_tci >> 29) & 0x7;
            pkt_info->source_cfi = IS_BIT_SET(parser_result->l3_s.ip_da.cmac.itag_tci.itag_tci, 28);
        }
    }
    else
    {
        if ((USERID_SCOS_ACTION_NONE == pkt_info->scos_action) && parser_result->l2_s.svlan_id_valid)
        {
            user_scos = parser_result->l2_s.stag_cos;
        }
        else if ((USERID_SCOS_ACTION_NONE == pkt_info->scos_action) && !parser_result->l2_s.svlan_id_valid)
        {
            user_scos = pkt_info->default_pcp;
        }
        else if ((USERID_SCOS_ACTION_SWAP == pkt_info->scos_action) && parser_result->l2_s.cvlan_id_valid)
        {
            user_scos = parser_result->l2_s.ctag_cos;
        }
        else if ((USERID_SCOS_ACTION_SWAP == pkt_info->scos_action) && !parser_result->l2_s.cvlan_id_valid)
        {
            user_scos = pkt_info->default_pcp;
        }
        else if (USERID_SCOS_ACTION_USER == pkt_info->scos_action)
        {
            user_scos = pkt_info->user_scos;
        }
        else
        {
            user_scos = pkt_info->default_pcp;
        }

        if ((USERID_SCFI_ACTION_NONE == pkt_info->scfi_action) && parser_result->l2_s.svlan_id_valid)
        {
            user_scfi = parser_result->l2_s.stag_cfi;
        }
        else if ((USERID_SCFI_ACTION_NONE == pkt_info->scfi_action) && !parser_result->l2_s.svlan_id_valid)
        {
            user_scfi = pkt_info->default_dei;
        }
        else if ((USERID_SCFI_ACTION_SWAP == pkt_info->scfi_action) && parser_result->l2_s.cvlan_id_valid)
        {
            user_scfi = parser_result->l2_s.ctag_cfi;
        }
        else if ((USERID_SCFI_ACTION_SWAP == pkt_info->scfi_action) && !parser_result->l2_s.cvlan_id_valid)
        {
            user_scfi = pkt_info->default_dei;
        }
        else if (USERID_SCFI_ACTION_USER == pkt_info->scfi_action)
        {
            user_scfi = pkt_info->user_scfi;
        }
        else
        {
            user_scfi = pkt_info->default_dei;
        }

        if ((USERID_CCOS_ACTION_NONE == pkt_info->ccos_action) && parser_result->l2_s.cvlan_id_valid)
        {
            user_ccos = parser_result->l2_s.ctag_cos;
        }
        else if ((USERID_CCOS_ACTION_NONE == pkt_info->ccos_action) && !parser_result->l2_s.cvlan_id_valid)
        {
            user_ccos = pkt_info->default_pcp;
        }
        else if ((USERID_CCOS_ACTION_SWAP == pkt_info->ccos_action) && parser_result->l2_s.svlan_id_valid)
        {
            user_ccos = parser_result->l2_s.stag_cos;
        }
        else if ((USERID_CCOS_ACTION_SWAP == pkt_info->ccos_action) && !parser_result->l2_s.svlan_id_valid)
        {
            user_ccos = pkt_info->default_pcp;
        }
        else if (USERID_CCOS_ACTION_USER == pkt_info->ccos_action)
        {
            user_ccos = pkt_info->user_ccos;
        }
        else
        {
            user_ccos = pkt_info->default_pcp;
        }

        if ((USERID_CCFI_ACTION_NONE == pkt_info->ccfi_action) && parser_result->l2_s.cvlan_id_valid)
        {
            user_ccfi = parser_result->l2_s.ctag_cfi;
        }
        else if ((USERID_CCFI_ACTION_NONE == pkt_info->ccfi_action) && !parser_result->l2_s.cvlan_id_valid)
        {
            user_ccfi = pkt_info->default_dei;
        }
        else if ((USERID_CCFI_ACTION_SWAP == pkt_info->ccfi_action) && parser_result->l2_s.svlan_id_valid)
        {
            user_ccfi = parser_result->l2_s.stag_cfi;
        }
        else if ((USERID_CCFI_ACTION_SWAP == pkt_info->ccfi_action) && !parser_result->l2_s.svlan_id_valid)
        {
            user_ccfi = pkt_info->default_dei;
        }
        else if (USERID_CCFI_ACTION_USER == pkt_info->ccfi_action)
        {
            user_ccfi = pkt_info->user_ccfi;
        }
        else
        {
            user_ccfi = pkt_info->default_dei;
        }

        if (parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->source_cos = parser_result->l2_s.stag_cos;
            pkt_info->source_cfi = parser_result->l2_s.stag_cfi;
        }
        else
        {
            pkt_info->source_cos = pkt_info->default_pcp;
            pkt_info->source_cfi = pkt_info->default_dei;
        }

        if (parser_result->l2_s.cvlan_id_valid)
        {
            pkt_info->ctag_cos = parser_result->l2_s.ctag_cos;
            pkt_info->ctag_cfi = parser_result->l2_s.ctag_cfi;
        }
        else
        {
            pkt_info->ctag_cos = pkt_info->default_pcp;
            pkt_info->ctag_cfi = pkt_info->default_dei;
        }

        if (pkt_info->svlan_tag_operation_valid || pkt_info->cvlan_tag_operation_valid)
        {
            pkt_info->source_cos = user_scos;
            pkt_info->source_cfi = user_scfi;
            pkt_info->ctag_cos = user_ccos;
            pkt_info->ctag_cfi = user_ccfi;
            pkt_info->classify_stag_cos = user_scos;
            pkt_info->classify_stag_cfi = user_scfi;
            pkt_info->classify_ctag_cos = user_ccos;
            pkt_info->classify_ctag_cfi = user_ccfi;
        }
        else if (map_info->protocol_vlan_en && map_info->protocol_cos_valid)
        {
            pkt_info->source_cos = map_info->protocol_cos;
            pkt_info->source_cfi = map_info->protocol_cfi;
            if (!pkt_info->src_outer_vlan_is_svlan)
            {
                pkt_info->ctag_cos = map_info->protocol_cos;
                pkt_info->ctag_cfi = map_info->protocol_cfi;
            }
        }
        else if (parser_result->l2_s.svlan_id_valid)
        {
            pkt_info->source_cos = parser_result->l2_s.stag_cos;
            pkt_info->source_cfi = parser_result->l2_s.stag_cfi;
        }
        else if (parser_result->l2_s.cvlan_id_valid && !pkt_info->src_outer_vlan_is_svlan)
        {
            pkt_info->source_cos = parser_result->l2_s.ctag_cos;
            pkt_info->source_cfi = parser_result->l2_s.ctag_cfi;
            pkt_info->ctag_cos = parser_result->l2_s.ctag_cos;
            pkt_info->ctag_cfi = parser_result->l2_s.ctag_cfi;
        }
    }

    /* ASSIGN_VLAN_ID */
    if ((PBB_PORT_TYPE_PIP == pkt_info->pbb_src_port_type) && (L3_TYPE_CMAC == parser_result->layer3_type))
    {
        pkt_info->svlan_id_valid = parser_result->l3_s.ip_da.cmac.cmac_svlan_valid;
        pkt_info->svlan_id = parser_result->l3_s.ip_da.cmac.cmac_svlan_id;
        parser_result->l2_s.svlan_id_valid = parser_result->l3_s.ip_da.cmac.cmac_svlan_valid;
        parser_result->l2_s.svlan_id = parser_result->l3_s.ip_da.cmac.cmac_svlan_id;
        parser_result->l2_s.stag_cos = parser_result->l3_s.ip_da.cmac.cmac_stag_cos;
        parser_result->l2_s.stag_cfi = parser_result->l3_s.ip_da.cmac.cmac_stag_cfi;

        pkt_info->cvlan_id_valid = parser_result->l3_s.ip_sa.cmac.cmac_cvlan_valid;
        pkt_info->cvlan_id = parser_result->l3_s.ip_sa.cmac.cmac_cvlan_id;
        parser_result->l2_s.cvlan_id_valid = parser_result->l3_s.ip_sa.cmac.cmac_cvlan_valid;
        parser_result->l2_s.cvlan_id = parser_result->l3_s.ip_sa.cmac.cmac_cvlan_id;
        parser_result->l2_s.ctag_cos = parser_result->l3_s.ip_sa.cmac.cmac_ctag_cos;
        parser_result->l2_s.ctag_cfi = parser_result->l3_s.ip_sa.cmac.cmac_ctag_cfi;
    }
    else
    {
        if ((USERID_SVLAN_ID_ACTION_NONE == pkt_info->svlan_id_action)&& parser_result->l2_s.svlan_id_valid)
        {
            user_svlan_id = parser_result->l2_s.svlan_id;
        }
        else if ((USERID_SVLAN_ID_ACTION_NONE == pkt_info->svlan_id_action)&& !parser_result->l2_s.svlan_id_valid)
        {
            user_svlan_id = pkt_info->default_vlan_id;
        }
        else if ((USERID_SVLAN_ID_ACTION_SWAP == pkt_info->svlan_id_action)&& parser_result->l2_s.cvlan_id_valid)
        {
            user_svlan_id = parser_result->l2_s.cvlan_id;
        }
        else if ((USERID_SVLAN_ID_ACTION_SWAP == pkt_info->svlan_id_action)&& !parser_result->l2_s.cvlan_id_valid)
        {
            user_svlan_id = pkt_info->default_vlan_id;
        }
        else if (USERID_SVLAN_ID_ACTION_USER == pkt_info->svlan_id_action)
        {
            user_svlan_id = pkt_info->user_svlan_id;
        }
        else
        {
            user_svlan_id = pkt_info->default_vlan_id;
        }

        if ((USERID_CVLAN_ID_ACTION_NONE == pkt_info->cvlan_id_action)&& parser_result->l2_s.cvlan_id_valid)
        {
            user_cvlan_id = parser_result->l2_s.cvlan_id;
        }
        else if ((USERID_CVLAN_ID_ACTION_NONE == pkt_info->cvlan_id_action)&& !parser_result->l2_s.cvlan_id_valid)
        {
            user_cvlan_id = pkt_info->default_vlan_id;
        }
        else if ((USERID_CVLAN_ID_ACTION_SWAP == pkt_info->cvlan_id_action)&& parser_result->l2_s.svlan_id_valid)
        {
            user_cvlan_id = parser_result->l2_s.svlan_id;
        }
        else if ((USERID_CVLAN_ID_ACTION_SWAP == pkt_info->cvlan_id_action)&& !parser_result->l2_s.svlan_id_valid)
        {
            user_cvlan_id = pkt_info->default_vlan_id;
        }
        else if (USERID_CVLAN_ID_ACTION_USER == pkt_info->cvlan_id_action)
        {
            user_cvlan_id = pkt_info->user_cvlan_id;
        }
        else
        {
            user_cvlan_id = pkt_info->default_vlan_id;
        }

        /* Svlan space operation */
        if (pkt_info->src_outer_vlan_is_svlan)
        {
            pkt_info->svlan_id_valid = TRUE;

            /* untag or priority tag */
            if (!map_info->svlan_exist)
            {
                if (pkt_info->svlan_tag_operation_valid)
                {
                    pkt_info->svlan_id = user_svlan_id;
                }
                else if (map_info->protocol_vlan_en && map_info->protocol_vlan_id_valid)
                {
                    pkt_info->svlan_id = map_info->protocol_vlan_id;
                    pkt_info->svlan_tag_operation_valid = TRUE;
                    pkt_info->stag_action = USERID_STAG_ACTION_MODIFY;
                    pkt_info->stag_modify_mode = MODIFY_MODE_UPGRADE_ADD;
                }
                else
                {
                    pkt_info->svlan_id = pkt_info->default_vlan_id;

                    if (!ds_src_port.add_default_vlan_disable)
                    {
                        pkt_info->svlan_tag_operation_valid = TRUE;
                        pkt_info->stag_action = USERID_STAG_ACTION_MODIFY;
                        pkt_info->stag_modify_mode = MODIFY_MODE_UPGRADE_ADD;
                        map_info->added_default_svlan_tag = TRUE;
                    }
                }
            }
            else if (!ds_src_port.ingress_tag_high_priority)    /*tagged packet*/
            {
                if (pkt_info->svlan_tag_operation_valid)
                {
                    pkt_info->svlan_id = user_svlan_id;
                }
                else if (map_info->protocol_vlan_en
                    && map_info->protocol_vlan_id_valid
                    && map_info->protocol_replace_tag_en)
                {
                    pkt_info->svlan_id = map_info->protocol_vlan_id;
                    pkt_info->svlan_tag_operation_valid = TRUE;
                    pkt_info->stag_action = USERID_STAG_ACTION_MODIFY;
                }
                else if (ds_src_port.default_replace_tag_en)
                {
                    pkt_info->svlan_id = pkt_info->default_vlan_id;
                    pkt_info->svlan_tag_operation_valid = TRUE;
                    pkt_info->stag_action = USERID_STAG_ACTION_MODIFY;
                }
                else
                {
                    pkt_info->svlan_id = parser_result->l2_s.svlan_id;
                }
            }
            else
            {
                pkt_info->svlan_id = parser_result->l2_s.svlan_id;
            }

            if (pkt_info->cvlan_tag_operation_valid)
            {
                pkt_info->cvlan_id_valid = TRUE;
                pkt_info->cvlan_id = user_cvlan_id;
            }
            else
            {
                pkt_info->cvlan_id_valid = parser_result->l2_s.cvlan_id_valid;
                pkt_info->cvlan_id = parser_result->l2_s.cvlan_id;
            }
        }
        else /* cvlan space operation */
        {
            pkt_info->cvlan_id_valid = TRUE;

            /* untag or priority tag */
            if (!map_info->cvlan_exist)
            {
                if (pkt_info->cvlan_tag_operation_valid)
                {
                    pkt_info->cvlan_id = user_cvlan_id;
                }
                else if (map_info->protocol_vlan_en && map_info->protocol_vlan_id_valid)
                {
                    pkt_info->cvlan_id = map_info->protocol_vlan_id;
                    pkt_info->cvlan_tag_operation_valid = TRUE;
                    pkt_info->ctag_action = USERID_CTAG_ACTION_MODIFY;
                    pkt_info->ctag_modify_mode = MODIFY_MODE_UPGRADE_ADD;
                }
                else
                {
                    pkt_info->cvlan_id = pkt_info->default_vlan_id;

                    if (!ds_src_port.add_default_vlan_disable)
                    {
                        pkt_info->cvlan_tag_operation_valid = TRUE;
                        pkt_info->ctag_action = USERID_CTAG_ACTION_MODIFY;
                        pkt_info->ctag_modify_mode = MODIFY_MODE_UPGRADE_ADD;
                        map_info->added_default_cvlan_tag = TRUE;
                    }
                }
            }
            else if (!ds_src_port.ingress_tag_high_priority)  /*tagged packet*/
            {
                if (pkt_info->cvlan_tag_operation_valid)
                {
                    pkt_info->cvlan_id = user_cvlan_id;
                }
                else if (map_info->protocol_vlan_en
                        && map_info->protocol_vlan_id_valid
                        && map_info->protocol_replace_tag_en)
                {
                    pkt_info->cvlan_id = map_info->protocol_vlan_id;
                    pkt_info->cvlan_tag_operation_valid =TRUE;
                    pkt_info->ctag_action = USERID_CTAG_ACTION_MODIFY;
                }
                else if (ds_src_port.default_replace_tag_en)
                {
                    pkt_info->cvlan_id = pkt_info->default_vlan_id;
                    pkt_info->cvlan_tag_operation_valid = TRUE;
                    pkt_info->ctag_action = USERID_CTAG_ACTION_MODIFY;
                }
                else
                {
                    pkt_info->cvlan_id = parser_result->l2_s.cvlan_id;
                }
            }
            else
            {
                pkt_info->cvlan_id = parser_result->l2_s.cvlan_id;
            }

            if (pkt_info->svlan_tag_operation_valid)
            {
                pkt_info->svlan_id_valid = TRUE;
                pkt_info->svlan_id = user_svlan_id;
            }
            else
            {
                pkt_info->svlan_id_valid = parser_result->l2_s.svlan_id_valid;
                pkt_info->svlan_id = parser_result->l2_s.svlan_id;
            }
        }

        /* packet without ctag upgrade action to add */
        if ((USERID_CTAG_ACTION_MODIFY == pkt_info->ctag_action)
            && (!parser_result->l2_s.cvlan_id_valid)
            && (MODIFY_MODE_UPGRADE_ADD == pkt_info->ctag_modify_mode))
        {
            pkt_info->ctag_action = USERID_CTAG_ACTION_ADD;
        }

        /* packet without stag upgrade action to add */
        if ((USERID_STAG_ACTION_MODIFY == pkt_info->stag_action)
            && (!parser_result->l2_s.svlan_id_valid)
            && (MODIFY_MODE_UPGRADE_ADD == pkt_info->stag_modify_mode))
        {
            pkt_info->stag_action = USERID_STAG_ACTION_ADD;
        }

        /* add ctag after stag */
        pkt_info->src_ctag_offset_type = parser_result->l2_s.svlan_id_valid;
        if ((USERID_CTAG_ACTION_ADD == pkt_info->ctag_action)
            && parser_result->l2_s.svlan_id_valid
            && (CTAG_OFFSET_TYPE_AFTER_MAC == pkt_info->ctag_add_mode))
        {
            /* add ctag after mac */
            pkt_info->src_ctag_offset_type = 0;
        }
    }

    if (((USERID_STAG_ACTION_MODIFY == pkt_info->stag_action)
           || (USERID_STAG_ACTION_DELETE == pkt_info->stag_action))
           && (!parser_result->l2_s.svlan_id_valid))
    {
        pkt_info->stag_action = USERID_STAG_ACTION_NONE;
    }

    if (((USERID_CTAG_ACTION_MODIFY == pkt_info->ctag_action)
           || (USERID_CTAG_ACTION_DELETE == pkt_info->ctag_action))
           && (!parser_result->l2_s.cvlan_id_valid))
    {
        pkt_info->ctag_action = USERID_CTAG_ACTION_NONE;
    }

    /* VLAN pointer */
    if (pkt_info->user_vlan_ptr_valid)
    {
        pkt_info->vlan_ptr = pkt_info->user_vlan_ptr;
    }
    else if (pkt_info->routed_port)
    {
        pkt_info->vlan_ptr = 4096 + pkt_info->interface_id;
    }
    else
    {
        if (pkt_info->svlan_id_valid)
        {
            pkt_info->vlan_ptr = pkt_info->svlan_id;
        }
        else
        {
            pkt_info->vlan_ptr = pkt_info->cvlan_id;
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_ipe_interface_mapper_get_vlan_info
 * Purpose:    get source vlan informations.
 * Parameters:
 * Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
static int32
_cm_ipe_interface_mapper_get_vlan_info(ipe_in_pkt_t *in_pkt, interface_map_info_t *map_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;

    ds_vlan_t ds_vlan;
    ds_src_port_t ds_src_port;
    ds_vlan_profile_t ds_vlan_profile;
    ds_src_interface_t  ds_src_interface;
    ipe_intf_mapper_ctl_t ipe_intf_mapper_ctl;
    ipe_ds_vlan_ctl_t ipe_ds_vlan_ctl;
    ds_router_mac_t ds_router_mac;

    uint32 cmd = 0;
    uint8 is_dhcp_pkt = FALSE, is_dhcp_ipv6_pkt = FALSE;
    uint8 is_arp = FALSE;
    uint8 route_all_packets = FALSE;
    uint8 router_mac_type = 0;
    uint8 router_mac_label = 0;
    uint8 stp_id = 0;
    uint16 stp_state_idx = 0;
    uint32 stp_field_offset = 0, stp_field_value = 0, stp_field_id = 0;
    uint32 src_mac_check_fail = 0, dest_mac_check_fail = 0;
    uint8 macda_match_target_mac = 0, macsa_match_send_mac = FALSE;
    uint32 sender_ip_check_fail = 0, target_ip_check_fail = 0;
    uint32 ip_check_fail = 0;
    uint8 vlan_id_valid = 0;
    uint8 ingress_filtering_en = 0;
    uint8 fip_exception_type = 0;
    uint8 is_ptp_packet = FALSE;
    uint8 is_fip = FALSE;
    uint32 macsa_47_to32 = 0, macsa_31_to0 = 0, macda_47_to32 = 0, macda_31_to0 = 0;

    sal_memset(&ds_vlan, 0, sizeof(ds_vlan));
    sal_memset(&ds_src_port, 0, sizeof(ds_src_port));
    sal_memset(&ds_vlan_profile, 0, sizeof(ds_vlan_profile));
    sal_memset(&ds_src_interface, 0, sizeof(ds_src_interface));
    sal_memset(&ds_router_mac, 0, sizeof(ds_router_mac));

    sal_memset(&ipe_intf_mapper_ctl, 0, sizeof(ipe_intf_mapper_ctl));
    cmd = DRV_IOR(IpeIntfMapperCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_intf_mapper_ctl));

    sal_memset(&ipe_ds_vlan_ctl, 0, sizeof(ipe_ds_vlan_ctl));
    cmd = DRV_IOR(IpeDsVlanCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_ds_vlan_ctl));

    cmd = DRV_IOR(DsSrcPort_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, pkt_info->local_phy_port, cmd, &ds_src_port));

    /*DS_VLAN*/
    pkt_info->bcast_mac_address = ((0xFF == parser_result->l2_s.mac_da5)
                                    && (0xFF == parser_result->l2_s.mac_da4)
                                    && (0xFF == parser_result->l2_s.mac_da3)
                                    && (0xFF == parser_result->l2_s.mac_da2)
                                    && (0xFF == parser_result->l2_s.mac_da1)
                                    && (0xFF == parser_result->l2_s.mac_da0));

    pkt_info->mcast_mac_address = (IS_BIT_SET(parser_result->l2_s.mac_da5, 0)
                                   && (!pkt_info->bcast_mac_address));

    if (!IS_BIT_SET(pkt_info->vlan_ptr, 12)) /* vlanPtr < 4096 */
    {
        cmd = DRV_IOR(DsVlan_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, pkt_info->vlan_ptr, cmd, &ds_vlan));

        ingress_filtering_en = (map_info->ingress_filtering_en || ds_vlan.ingress_filtering_en)
                               && (!map_info->ingress_filtering_disable)&& (!pkt_info->from_cpu_or_oam);

        if (!pkt_info->routed_port && ingress_filtering_en && (pkt_info->local_phy_port < MAX_NETWORK_PORT_WO_MUX))
        {
            if (IS_BIT_SET(pkt_info->local_phy_port, 5))
            {
                vlan_id_valid = IS_BIT_SET(ds_vlan.vlan_id_valid59_32, pkt_info->local_phy_port & 0x1F);
            }
            else
            {
                vlan_id_valid = IS_BIT_SET(ds_vlan.vlan_id_valid31_0, pkt_info->local_phy_port & 0x1F);
            }
        }

        pkt_info->igmp_snoop_en = ds_vlan.igmpsnoop_en;
        pkt_info->mac_security_vlan_discard = ds_vlan.mac_security_vlan_discard;
        pkt_info->interface_id = ds_vlan.interface_id;
        pkt_info->ucast_discard = ds_vlan.ucast_discard;
        pkt_info->mcast_discard = ds_vlan.mcast_discard;

        pkt_info->arp_exception_type = ds_vlan.arp_exception_type;
        pkt_info->dhcp_exception_type = ds_vlan.dhcp_exception_type;


        if (!map_info->port_vsi_high_priority)
        {
            pkt_info->vsi_id = ds_vlan.vsi_id;
        }

        fip_exception_type = 0;

        if (0 != ds_vlan.profile_id)
        {
            cmd = DRV_IOR(DsVlanProfile_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, ds_vlan.profile_id, cmd, &ds_vlan_profile));
            pkt_info->vlan_storm_ctl_ptr = ds_vlan_profile.vlan_storm_ctl_ptr;
            pkt_info->vlan_storm_ctl_en = ds_vlan_profile.vlan_storm_ctl_en;

            pkt_info->l3_span_en = ds_vlan_profile.ingress_vlan_span_en;
            pkt_info->l3_span_id = ds_vlan_profile.ingress_vlan_span_id;

            pkt_info->l3_acl_routed_only = ds_vlan_profile.ingress_vlan_acl_routed_only;
            pkt_info->l3_acl_en0 = ds_vlan_profile.ingress_vlan_acl_en0;
            pkt_info->l3_acl_en1 = ds_vlan_profile.ingress_vlan_acl_en1;
            pkt_info->l3_acl_en2 = ds_vlan_profile.ingress_vlan_acl_en2;
            pkt_info->l3_acl_en3 = ds_vlan_profile.ingress_vlan_acl_en3;
            pkt_info->l3_ipv6_acl_en0 = ds_vlan_profile.ingress_vlan_i_pv6_acl_en0;
            pkt_info->l3_ipv6_acl_en1 = ds_vlan_profile.ingress_vlan_i_pv6_acl_en1;
            pkt_info->force_ipv4_lookup = ds_vlan_profile.force_ipv4_lookup;
            pkt_info->force_ipv6_lookup = ds_vlan_profile.force_ipv6_lookup;

            pkt_info->l3_acl_label = ds_vlan_profile.ingress_vlan_acl_label;

            fip_exception_type = ds_vlan_profile.fip_exception_type;

        }

        pkt_info->src_queue_select |= ds_vlan.src_queue_select;

        stp_id = ds_vlan.stp_id;

        pkt_info->learning_disable |= ds_vlan.learning_disable;
        pkt_info->bridge_en &= (!ds_vlan.bridge_disable);

        map_info->vlan_receive_disable = ds_vlan.receive_disable;
    }
    else if (4 == (pkt_info->vlan_ptr >> 10))   /* 4096 <= vlanPtr < 4096+1024 */
    {
        pkt_info->interface_id = pkt_info->vlan_ptr - 0x1000;
        map_info->vlan_receive_disable = FALSE;
    }
    else
    {
        pkt_info->interface_id = 0;
        map_info->vlan_receive_disable = FALSE;
    }

    if (pkt_info->user_vsi_id_valid)
    {
        pkt_info->vsi_id = pkt_info->user_vsi_id;
    }

    /* VLAN stats,support 4k vlan stats */
    if (ipe_ds_vlan_ctl.stats_en && (!pkt_info->flow_stats2_valid) && (!IS_BIT_SET(pkt_info->vlan_ptr, 12)))
    {
        if (0 == ipe_ds_vlan_ctl.stats_mode) /* all packet */
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = (ipe_ds_vlan_ctl.vlan_stats_ucast_ptr_bit<<12) | (pkt_info->vlan_ptr&0xFFF);
        }
        else if ((1 == ipe_ds_vlan_ctl.stats_mode) && (!pkt_info->mcast_mac_address) && (!pkt_info->bcast_mac_address))
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = (ipe_ds_vlan_ctl.vlan_stats_ucast_ptr_bit<<12) | (pkt_info->vlan_ptr&0xFFF);
        }
        else if ((2 == ipe_ds_vlan_ctl.stats_mode) && pkt_info->mcast_mac_address)
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = (ipe_ds_vlan_ctl.vlan_stats_mcast_ptr_bit<<12) | (pkt_info->vlan_ptr&0xFFF);
        }
        else if ((3 == ipe_ds_vlan_ctl.stats_mode) && pkt_info->bcast_mac_address)
        {
            pkt_info->flow_stats2_valid = TRUE;
            pkt_info->flow_stats2_ptr = (ipe_ds_vlan_ctl.vlan_stats_bcast_ptr_bit<<12) | (pkt_info->vlan_ptr&0xFFF);
        }
        else
        {
            /* do nothing */
        }
    }

    is_ptp_packet = (parser_result->layer3_type == L3_TYPE_PTP)
                 || (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_UDP_PTP);

    if (ipe_intf_mapper_ctl.use_port_ptp && ds_src_port.ptp_en && is_ptp_packet)
    {
        pkt_info->ptp_en = TRUE;
    }
    else if (ds_vlan_profile.ptp_en && is_ptp_packet)
    {
        pkt_info->ptp_en = TRUE;
    }

    /* DS_SRC_INTERFACE */
    /* Interface property */
    if (0 != pkt_info->interface_id)
    {
        cmd = DRV_IOR(DsSrcInterface_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, pkt_info->interface_id , cmd, &ds_src_interface));

        pkt_info->l3_if_type = ds_src_interface.l3_if_type;
        pkt_info->v4_ucast_sa_type = ds_src_interface.v4_ucast_sa_type;
        pkt_info->v4_ucast_en = ds_src_interface.v4_ucast_en;
        pkt_info->v4_mcast_en = ds_src_interface.v4_mcast_en;
        pkt_info->v6_ucast_en = ds_src_interface.v6_ucast_en;
        pkt_info->v6_mcast_en = ds_src_interface.v6_mcast_en;
        pkt_info->mpls_en = ds_src_interface.mpls_en;
        pkt_info->v6_ucast_sa_type = ds_src_interface.v6_ucast_sa_type;
        pkt_info->pbr_label = ds_src_interface.pbr_label;
        pkt_info->route_lookup_mode = ds_src_interface.route_lookup_mode;
        pkt_info->rpf_permit_default = ds_src_interface.rpf_permit_default;

        if (!ipe_intf_mapper_ctl.port_rpf_high_priority)
        {
            pkt_info->rpf_type = ds_src_interface.rpf_type;
        }

        pkt_info->mpls_section_lm_en |= ds_src_interface.mpls_section_lm_en;

        if (0x3FFF == ds_src_interface.vrf_id)
        {
            pkt_info->vrf_id = pkt_info->vsi_id;
        }
        else
        {
            pkt_info->vrf_id = ds_src_interface.vrf_id;
        }

        route_all_packets = ds_src_interface.route_all_packets;
        router_mac_type = ds_src_interface.router_mac_type;
        router_mac_label = ds_src_interface.router_mac_label;

        pkt_info->route_disable = pkt_info->route_disable || ds_src_interface.route_disable;

        if (pkt_info->mpls_label_space_valid)
        {
            pkt_info->mpls_label_space = pkt_info->fid & 0xFF;
        }
        else
        {
            pkt_info->mpls_label_space = ds_src_interface.mpls_label_space;
        }
    }

    if (pkt_info->user_vrf_id_valid)
    {
        pkt_info->vrf_id = pkt_info->user_vrf_id;
    }

    /* OAM */
    if (OAM_NONE == pkt_info->rx_oam_type)
    {
        if ((map_info->svlan_exist && map_info->cvlan_exist) && ipe_intf_mapper_ctl.oam_tunnel_check_type)
        {
            pkt_info->oam_tunnel_en = TRUE;
        }

        if ((L3_TYPE_CMAC == parser_result->layer3_type)
            && (PBB_PORT_TYPE_PIP == pkt_info->pbb_src_port_type)
            && (L4_TYPE_PBB_ITAG_OAM == parser_result->layer4_type))
        {
            if (ipe_intf_mapper_ctl.pbb_oam_en)
            {
                pkt_info->rx_oam_type = OAM_PBB_BSI;
            }

            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_PBB_OAM_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! PBB OAM discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if ((L3_TYPE_CMAC == parser_result->layer3_type)
                 && (PBB_PORT_TYPE_CBP == pkt_info->pbb_src_port_type)
                 && (L4_TYPE_PBB_ITAG_OAM == parser_result->layer4_type)
                 && ipe_intf_mapper_ctl.pbb_bsi_oam_on_igs_cbp_en)
        {
            pkt_info->rx_oam_type = OAM_PBB_BSI;
        }
        else if ((L3_TYPE_ETHEROAM == parser_result->layer3_type)
                 && ds_src_port.ether_oam_valid
                 && !pkt_info->oam_tunnel_en
                 && (0 != parser_result->l3_s.ip_da.eth_oam.eth_oam_level))
        {
            if ((0 == parser_result->l2_s.svlan_id)
                && (0 == parser_result->l2_s.cvlan_id)
                && (!ipe_intf_mapper_ctl.untagged_service_oam_en))
            {/* service OAM without VLAN as exception */
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
                pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_ETHERNET_OAM_ERR;

                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = IPE_DISCARD_ETHER_SERVICE_OAM_DISCARD;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! Ethernet Service OAM discard!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
            else
            {/* Ethernet service OAM */
                pkt_info->rx_oam_type = OAM_ETHER;
            }
        }

        if (ds_src_port.link_oam_en && (L3_TYPE_ETHEROAM == parser_result->layer3_type)
            && (0 == parser_result->l3_s.ip_da.eth_oam.eth_oam_level))
        {
            if (map_info->svlan_exist || map_info->cvlan_exist)
            {
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
                pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_ETHERNET_OAM_ERR;

                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = IPE_DISCARD_LINK_OAM_DISCARD;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! Ethernet OAM discard!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
            else
            {
                pkt_info->link_or_section_OAM = TRUE;

                if (map_info->added_default_svlan_tag)    /* link OAM don't add default vlan tag */
                {
                    pkt_info->svlan_tag_operation_valid = FALSE;
                    pkt_info->stag_action = USERID_STAG_ACTION_NONE;
                }

                if (map_info->added_default_cvlan_tag)  /* link OAM don't add default vlan tag */
                {
                    pkt_info->cvlan_tag_operation_valid = FALSE;
                    pkt_info->ctag_action = USERID_STAG_ACTION_NONE;
                }
            }
        }
        else if ((L3_TYPE_ETHEROAM == parser_result->layer3_type)
                 && (0 == parser_result->l3_s.ip_da.eth_oam.eth_oam_level)
                 && ipe_intf_mapper_ctl.link_oam_discard_en)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_LINK_OAM_DISCARD;
                pkt_info->discard = TRUE;

                CMODEL_DEBUG_OUT_INFO("++++ Discard! ether link OAM discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    if (map_info->port_receive_disable && !pkt_info->link_or_section_OAM)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_PORT_OR_DS_VLAN_RCV_DIS;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! port receivedisable = 1,port=%d\n",pkt_info->local_phy_port);
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (map_info->vlan_receive_disable && !pkt_info->link_or_section_OAM)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_PORT_OR_DS_VLAN_RCV_DIS;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! vlan receivedisable = 1,vlan=%d\n",pkt_info->vlan_ptr);
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* ARP_DHCP_EXCEPTION */
    is_dhcp_pkt = ((L3_TYPE_IPV4 == parser_result->layer3_type)
                   && parser_result->l4_s.is_udp
                   && ((67 == parser_result->l4_s.l4_dst_port.l4_dest_port)
                       ||(68 == parser_result->l4_s.l4_dst_port.l4_dest_port)));

    is_dhcp_ipv6_pkt = ((L3_TYPE_IPV6 == parser_result->layer3_type)
                        && parser_result->l4_s.is_udp
                        && ((546 == parser_result->l4_s.l4_dst_port.l4_dest_port)
                            || (547 == parser_result->l4_s.l4_dst_port.l4_dest_port)));

    is_arp = (L3_TYPE_ARP == parser_result->layer3_type);
    is_fip = (0x8914 == parser_result->l2_s.layer2_header_protocol);

    if (is_dhcp_pkt || is_dhcp_ipv6_pkt)
    {
        if (!IS_BIT_SET(pkt_info->dhcp_exception_type, 0) && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = ipe_intf_mapper_ctl.dhcp_exception_sub_index;
        }

        if (!pkt_info->discard && IS_BIT_SET(pkt_info->dhcp_exception_type, 1))
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_ARP_DHCP_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DHCP packet discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    macsa_47_to32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
    macsa_31_to0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                             parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
    macsa_match_send_mac = (macsa_47_to32 == parser_result->l3_s.ip_sa.arp.sender_mac_47_32)
                            &&(macsa_31_to0 == parser_result->l3_s.ip_sa.arp.sender_mac_31_0);

    macda_47_to32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
    macda_31_to0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                               parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
    macda_match_target_mac = (macda_47_to32 == parser_result->l3_s.ip_da.arp.target_mac_47_32)
                            &&(macda_31_to0 == parser_result->l3_s.ip_da.arp.target_mac_31_0);

    if (is_arp && ((parser_result->layer2_type == L2_TYPE_ETHV2)
                    ||(parser_result->layer2_type == L2_TYPE_ETHSAP)
                    ||(parser_result->layer2_type == L2_TYPE_ETHSNAP)))  /* ARP validation check */
    {
        src_mac_check_fail = ipe_intf_mapper_ctl.arp_src_mac_check_en && (!macsa_match_send_mac);

        dest_mac_check_fail = ipe_intf_mapper_ctl.arp_dest_mac_check_en
                            && (parser_result->l3_s.ip_da.arp.arp_op_code == 2)
                            && (!macda_match_target_mac);

        sender_ip_check_fail = ((parser_result->l3_s.ip_sa.arp.sender_ip == 0)
                             || (parser_result->l3_s.ip_sa.arp.sender_ip == 0xFFFFFFFF)
                             || ((parser_result->l3_s.ip_sa.arp.sender_ip >> 28) == 0xE));

        target_ip_check_fail = (parser_result->l3_s.ip_da.arp.arp_op_code == 2)
                             && ((parser_result->l3_s.ip_da.arp.target_ip == 0)
                             || (parser_result->l3_s.ip_da.arp.target_ip == 0xFFFFFFFF)
                             || (parser_result->l3_s.ip_da.arp.target_ip >> 28) == 0xE);

        ip_check_fail = (ipe_intf_mapper_ctl.arp_ip_check_en && (sender_ip_check_fail || target_ip_check_fail));

        if (src_mac_check_fail || dest_mac_check_fail || ip_check_fail)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_ARP_DHCP_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! ARP legal check fail discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }

            if (ipe_intf_mapper_ctl.arp_check_exception_en && !pkt_info->exception_en)
            {
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
                pkt_info->exception_sub_index = ipe_intf_mapper_ctl.arp_exception_sub_index;
            }
        }
    }

    if (is_arp && (!pkt_info->discard))  /* ARP exception */
    {
        if (!IS_BIT_SET(pkt_info->arp_exception_type, 0) && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = ipe_intf_mapper_ctl.arp_exception_sub_index;
        }

        if (!pkt_info->discard && (IS_BIT_SET(pkt_info->arp_exception_type, 1)))
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_ARP_DHCP_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! ARP DHCP discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (is_fip && !pkt_info->discard)   /* fip exception */
    {
        if (IS_BIT_SET(fip_exception_type, 0) && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = 2;
            pkt_info->exception_sub_index = ipe_intf_mapper_ctl.fip_exception_sub_index;
        }

        if (!pkt_info->discard && IS_BIT_SET(fip_exception_type, 1))
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_ARP_DHCP_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! ARP DHCP discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* DS_VLAN_STATUS */
    if (!pkt_info->routed_port && ingress_filtering_en && (!IS_BIT_SET(pkt_info->vlan_ptr, 12))
        && !pkt_info->from_cpu_or_oam && (pkt_info->local_phy_port < MAX_NETWORK_PORT_WO_MUX))
    {
        if (!vlan_id_valid && !pkt_info->from_cpu_or_oam)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_VLAN_STATUS_FILTER_DISCARD;

                if ((pkt_info->rx_oam_type != OAM_ETHER) && (!pkt_info->link_or_section_OAM))
                {
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard!vlanstatus check failed,port:%d,vlan:%d\n",pkt_info->local_phy_port,pkt_info->vlan_ptr);
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
                else
                {
                    pkt_info->ether_oam_discard = TRUE;
                }
            }
        }
    }

    /* STP_STATE */
    /* Support 4 combination depend on the value of IpeDsVlanCtl.dsStpStateShift[1:0]
       2'b00: 512 * 16 (port * STP instance)
       2'b01: 256 * 32
       2'b10: 128 * 64
       2'b11: 64 * 128
    */
    if (!ds_src_port.stp_disable && !pkt_info->from_cpu_or_oam)
    {
        stp_state_idx = (pkt_info->local_phy_port << (ipe_ds_vlan_ctl.ds_stp_state_shift))
                               + ((stp_id >> 4) & 0x7);
        stp_field_offset = (stp_id & 0xF);
        stp_field_id = DsStpState_StpState0_f + stp_field_offset;

        /*use the lower bits for index into DsStpState Table*/
        cmd = DRV_IOR(DsStpState_t, stp_field_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, stp_state_idx, cmd, &stp_field_value));

        pkt_info->stp_state = stp_field_value & 0x3;
    }
    else
    {   /* forwarding */
        pkt_info->stp_state = STP_FORWARDING;
    }

    /* DECIDING_ROUTER_MAC */
    if (route_all_packets)
    {
        pkt_info->is_router_mac = TRUE;
    }
    else if (0x3 == map_info->macda_router_mac_type)
    {
        pkt_info->is_router_mac = FALSE;
    }
    else if (0x3 == router_mac_type)/*need to lookup route mac table*/
    {
        sal_memset(&ds_router_mac, 0, sizeof(ds_router_mac));
        cmd = DRV_IOR(DsRouterMac_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, router_mac_label, cmd, &ds_router_mac));

        if (((map_info->macda_router_mac_type == ds_router_mac.router_mac0_type)
              && (parser_result->l2_s.mac_da0 == ds_router_mac.router_mac0_byte))
            || ((map_info->macda_router_mac_type == ds_router_mac.router_mac1_type)
                 && (parser_result->l2_s.mac_da0 == ds_router_mac.router_mac1_byte))
            || ((map_info->macda_router_mac_type == ds_router_mac.router_mac2_type)
                 && (parser_result->l2_s.mac_da0 == ds_router_mac.router_mac2_byte))
            || ((map_info->macda_router_mac_type == ds_router_mac.router_mac3_type)
                 && (parser_result->l2_s.mac_da0 == ds_router_mac.router_mac3_byte)))
        {
            pkt_info->is_router_mac = TRUE;
        }
    }
    else if ((map_info->macda_router_mac_type == router_mac_type)
             && (parser_result->l2_s.mac_da0 == router_mac_label))
    {
        pkt_info->is_router_mac = TRUE;
    }

    if (is_arp && (pkt_info->arp_exception_type == 0))
    {
        if (pkt_info->bcast_mac_address)
        {
            if (pkt_info->routed_port && ipe_intf_mapper_ctl.arp_broadcast_routed_port_discard)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = IPE_DISCARD_ARP_DHCP_DISCARD;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! Route port and ARP broadcast packet is discard!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }

            if (pkt_info->routed_port && ds_src_port.bcast_arp_exception_disable &&
                    pkt_info->exception_en && (3 == pkt_info->exception_index))
            {
                pkt_info->exception_en = FALSE;
            }
        }
        else if (!pkt_info->is_router_mac
                && ipe_intf_mapper_ctl.arp_unicast_exception_disable
                && pkt_info->exception_en
                && (pkt_info->exception_index == EXCEPTION_TYPE_LAYER3))
        {
            pkt_info->exception_en = FALSE; /* ARP to other, Mac lookup performed */
        }
        else if (pkt_info->is_router_mac && ipe_intf_mapper_ctl.arp_unicast_discard) /* ARP to me, No Mac lookup performed */
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type =IPE_DISCARD_ARP_DHCP_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! ARP unicast packet is discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    if ((is_dhcp_pkt || is_dhcp_ipv6_pkt) && (pkt_info->dhcp_exception_type == 0))
    {
        if (pkt_info->mcast_mac_address || pkt_info->bcast_mac_address)
        {
            if (pkt_info->routed_port && ipe_intf_mapper_ctl.dhcp_broadcast_routed_port_discard)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard_type = IPE_DISCARD_ARP_DHCP_DISCARD;
                    pkt_info->discard = TRUE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! Route port and DHCP broadcast packet is discard!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
        }
        else if (!pkt_info->is_router_mac
                && ipe_intf_mapper_ctl.dhcp_unicast_exception_disable
                && pkt_info->exception_en
                && (pkt_info->exception_index == EXCEPTION_TYPE_LAYER3))
        {
            pkt_info->exception_en = FALSE;
        }
        else if (pkt_info->is_router_mac && ipe_intf_mapper_ctl.dhcp_unicast_discard)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_ARP_DHCP_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! DHCP unicast packet is discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_ipe_interface_mapper
 * Purpose:    handle IPE interface mapper.
 * Parameters:
 *  Input:     in_pkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *	       Other = Error, please refer DRV_E_XXX.
 * Note:       none.
 ****************************************************************************/
int32
cm_ipe_interface_mapper(ipe_in_pkt_t *in_pkt)
{
    uint32 cmd = 0;
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    interface_map_info_t map_info;
    ipe_intf_mapper_ctl_t ipe_intf_mapper_ctl;
    ipe_port_mac_ctl_t ipe_port_mac_ctl;
    ds_src_port_t ds_src_port;
    uint8 bypass_all = FALSE;

    sal_memset(&map_info, 0, sizeof(map_info));

    sal_memset(&ipe_intf_mapper_ctl, 0, sizeof(ipe_intf_mapper_ctl));
    cmd = DRV_IOR(IpeIntfMapperCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_intf_mapper_ctl));

    sal_memset(&ipe_port_mac_ctl, 0, sizeof(ipe_port_mac_ctl));
    cmd = DRV_IOR(IpePortMacCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_port_mac_ctl));

    sal_memset(&ds_src_port, 0, sizeof(ds_src_port));
    cmd = DRV_IOR(DsSrcPort_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, pkt_info->local_phy_port, cmd, &ds_src_port));  /* only 256 entry */

    /* RETRIEVE_DS_SRC_PORT */
    bypass_all = pkt_info->bypass_all;

    if (bypass_all)
    {
        pkt_info->learning_disable = ipe_intf_mapper_ctl.bypass_all_disable_learning;
    }

    pkt_info->link_oam_mep_index = ds_src_port.link_oam_mep_index;

    if (!pkt_info->bypass_all)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Interface Mapper Process");

        /* get source port infomations */
        DRV_IF_ERROR_RETURN(_cm_ipe_interface_mapper_get_port_info(in_pkt, &map_info));

        /* pbb process */
        DRV_IF_ERROR_RETURN(_cm_ipe_interface_mapper_pbb_process(in_pkt, &map_info));

        /* protocol vlan handle */
        DRV_IF_ERROR_RETURN(_cm_ipe_intreface_mapper_protocol_vlan_handle(in_pkt, &map_info));

        /* vlan tag control */
        DRV_IF_ERROR_RETURN(_cm_ipe_interface_mapper_vlan_tag_control(in_pkt, &map_info));

        /* security check */
        DRV_IF_ERROR_RETURN(_cm_ipe_interface_mapper_security_check(in_pkt, &map_info));

        /* mac address */
        DRV_IF_ERROR_RETURN(_cm_ipe_interface_mapper_mac_addr_handle(in_pkt, &map_info));

        /* assign vlan id */
        DRV_IF_ERROR_RETURN(_cm_ipe_interface_mapper_assign_vid(in_pkt, &map_info));

        /* get vlan infomations */
        DRV_IF_ERROR_RETURN(_cm_ipe_interface_mapper_get_vlan_info(in_pkt, &map_info));
    }

    return DRV_E_NONE;
}

