/****************************************************************************
 * ipe_lkp.c    Provides IPE lookup handle function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 *
 * Revision:   V5.15.2.
 * Author:     ZhouW.
 * Date:       2012-04-01.
 * Reason:     Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "cm_lib.h"
#include "drv_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
#define CM_TCAM_AGING_MAX_PTR  (8192 + 256)
#define CM_AGING_CAM_NUM        16
#define CM_AGING_INDEX_MAX      4
#define CM_AGING_STR            "[CM Aging]"

#define CM_AGING_SOURCE_TCAM    0
#define CM_AGING_SOURCE_USERID  1
#define CM_AGING_SOURCE_FIB     2

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/
static uint32 g_cm_aging_ptr[CM_AGING_INDEX_MAX];   /* for debug */

#if (HOST_IS_LE == 1)
static uint32 g_cm_aging_quotiety = 23;             /* on UML */
#else
static uint32 g_cm_aging_quotiety = 10;             /* on Board */
#endif

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
/* only support FIFO depth 1 */
static int32
_cm_ipe_aging_add_sw_aging_fifo(uint8 chip_id, uint32 aging_ptr)
{
    ds_aging_ptr_fifo_depth_t aging_fifo_depth;
    ds_aging_ptr_t ipe_aging_ptr;
    uint32 wait_count = 0;
    uint32 cmd = 0;

    cmd = DRV_IOR(DsAgingPtrFifoDepth_t, DRV_ENTRY_FLAG);
    while (1)
    {
        wait_count++;
        if (wait_count > 100)
        {
            /* overwrite old entry */
            break;
        }

        sim_ioctl(chip_id, 0, cmd, &aging_fifo_depth);
        if (0 == aging_fifo_depth.ds_aging_ptr_fifo_depth)
        {
            break;
        }

        /* wait for old FIFO content is readed by SDK */
        sal_task_sleep(50);
    }

    ipe_aging_ptr.aging_ptr_found = aging_ptr;
    cmd = DRV_IOW(DsAgingPtr_t, DRV_ENTRY_FLAG);
    sim_ioctl(chip_id, 0, cmd, &ipe_aging_ptr);

    aging_fifo_depth.ds_aging_ptr_fifo_depth = 1;
    cmd = DRV_IOW(DsAgingPtrFifoDepth_t, DRV_ENTRY_FLAG);
    sim_ioctl(chip_id, 0, cmd, &aging_fifo_depth);

    DRV_IF_ERROR_RETURN(cm_com_interrupt_set(chip_id, TRUE, CM_INTR_GB_FUNC_IPE_AGING_FIFO, CM_INTR_ALL));

    return 0;
}

static int32
_cm_ipe_aging_engine_mac_aging(uint8 chip_id, uint32 cm_aging_index, uint32 aging_ptr, uint32 fdb_key_index,
        fib_engine_lookup_result_ctl_t* p_lkp_ctl, ipe_aging_ctl_t* p_aging_ctl)
{
    sal_systime_t tv;
    dynamic_ds_fdb_lookup_index_cam_t dynamic_ds_fdb_lookup_index_cam;
    ds_mac_hash_key_t mac_hash_key;
    ds_mac_t ds_mac;
    uint32 cmd = 0;
    uint32 aging_valid = 0;
    uint32 aging_index = 0;
    uint32 fast_learning_en = 0;
    uint32 aging32bit_index = 0;
    uint32 aging_status = 0;
    uint32 aging_status_bit = 0;
    uint32 ad_index = 0;
    uint32 need_cpu_age = 0;
    uint32 need_hw_age = 0;

    aging32bit_index = (((aging_ptr - CM_TCAM_AGING_MAX_PTR) >> 5) + (CM_TCAM_AGING_MAX_PTR >> 3));

    if (fdb_key_index < CM_AGING_CAM_NUM)
    {
        sal_memset(&dynamic_ds_fdb_lookup_index_cam, 0, sizeof(dynamic_ds_fdb_lookup_index_cam));
        cmd = DRV_IOR(DynamicDsFdbLookupIndexCam_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, fdb_key_index/2, cmd, &dynamic_ds_fdb_lookup_index_cam));

        if (fdb_key_index % 2)
        {
           sal_memcpy(&mac_hash_key, (uint8*)&dynamic_ds_fdb_lookup_index_cam + sizeof(ds_3word_hash_key_t),
                sizeof(ds_3word_hash_key_t));
        }
        else
        {
           sal_memcpy(&mac_hash_key, (uint8*)&dynamic_ds_fdb_lookup_index_cam,
                sizeof(ds_3word_hash_key_t));
        }
    }
    else
    {
        /* only simulate 80 BITs */
        cmd = DRV_IOR(DsMacHashKey_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, fdb_key_index - CM_AGING_CAM_NUM, cmd, &mac_hash_key));
    }

    if (!mac_hash_key.valid)
    {
        aging_valid = 0;
    }
    else
    {
        if (mac_hash_key.is_mac_hash)
        {
            if (p_lkp_ctl->ad_bits_type)
            {
                ad_index = ((mac_hash_key.vsi_id >> 13) << 15)
                        |  (mac_hash_key.ds_ad_index14_3 << 3)
                        |  (mac_hash_key.ds_ad_index2_2 << 2)
                        |  (mac_hash_key.ds_ad_index1_0);
            }
            else
            {
                ad_index = (mac_hash_key.ds_ad_index14_3 << 3)
                        |  (mac_hash_key.ds_ad_index2_2 << 2)
                        |  (mac_hash_key.ds_ad_index1_0);
            }
        }
        else
        {
            /* dsAdIndex[15:0] ??? */
            ad_index = (mac_hash_key.ds_ad_index14_3 << 3)
                    |  (mac_hash_key.ds_ad_index2_2 << 2)
                    |  (mac_hash_key.ds_ad_index1_0);
        }

        cmd = DRV_IOR(DsMac_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, ad_index, cmd, &ds_mac));
        aging_valid = ds_mac.aging_valid;
        aging_index = ds_mac.aging_index;
        fast_learning_en = ((ds_mac.fast_learning_en || p_lkp_ctl->force_hw_aging) && mac_hash_key.is_mac_hash);
        aging_status = 0;
        cmd = DRV_IOR(DsAging_t, DsAging_AgingStatus_f);
        DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, aging32bit_index, cmd, &aging_status));
        aging_status_bit = (1 << (aging_ptr % 32));
        aging_status_bit = aging_status_bit & aging_status;
    }

    need_cpu_age = (aging_valid)
                && ((aging_index == cm_aging_index) || !p_aging_ctl->aging_index_valid)
                && (!fast_learning_en || !p_aging_ctl->hw_aging_en)
                && (!aging_status_bit);
    need_hw_age = (aging_valid)
                && ((aging_index == cm_aging_index) || !p_aging_ctl->aging_index_valid)
                && (fast_learning_en && p_aging_ctl->hw_aging_en)
                && (!aging_status_bit);

    if (need_hw_age)
    {
        /* HW Aging : not implement */
    }
    else if (need_cpu_age)
    {
        _cm_ipe_aging_add_sw_aging_fifo(chip_id, aging_ptr);
        sal_gettime(&tv);
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_AGING,
            CM_AGING_STR" add SW FIFO chip %d aging_ptr %d at time %d sec\n",
            chip_id, aging_ptr, tv.tv_sec);
    }
    else
    {
        if (aging_ptr < CM_TCAM_AGING_MAX_PTR)
        {
            /* TCAM Aging : not implement */
        }
        else
        {
            if (mac_hash_key.valid)
            {
                sal_gettime(&tv);
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_AGING,
                    CM_AGING_STR" clear chip %d aging_ptr %d index %d status 0x%08x clr 0x%08x at time %d sec\n",
                    chip_id, aging_ptr, aging32bit_index, aging_status, aging_status_bit, tv.tv_sec);
            }
            cmd = DRV_IOR(DsAging_t, DsAging_AgingStatus_f);
            DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, aging32bit_index, cmd, &aging_status));
            aging_status &= (~aging_status_bit);
            aging32bit_index = (((aging_ptr - CM_TCAM_AGING_MAX_PTR) >> 5) + (CM_TCAM_AGING_MAX_PTR >> 3));
            cmd = DRV_IOW(DsAging_t, DsAging_AgingStatus_f);
            DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, aging32bit_index, cmd, &aging_status));
        }
    }

    return DRV_E_NONE;
}

static int32
_cm_ipe_aging_engine_chip_process(uint8 chip_id)
{
    sal_systime_t tv;
    ipe_aging_ctl_t aging_ctl;
    fib_engine_lookup_result_ctl_t lkp_ctl;

    uint32 min_ptr = 0;
    uint32 max_ptr = 0;
    uint32 userid_max_ptr = 0;
    uint32 ip_max_ptr = 0;
    uint32 mac_max_ptr = 0;
    uint32 aging_ptr = 0;
    uint32 fdb_key_index = 0;
    uint32 cmd = 0;
    uint32 scan_en[CM_AGING_INDEX_MAX];
    uint32 interval[CM_AGING_INDEX_MAX];
    uint32 cm_aging_index = 0;
    uint32 curr_sleep_count = 0;
    uint32 max_sleep_count = 0;

    sal_memset(&aging_ctl, 0, sizeof(aging_ctl));
    sal_memset(&lkp_ctl, 0, sizeof(lkp_ctl));
    sal_memset(scan_en, 0, sizeof(scan_en));

    cmd = DRV_IOR(IpeAgingCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, 0, cmd, &aging_ctl));
    scan_en[0] = aging_ctl.scan_en0;
    scan_en[1] = aging_ctl.scan_en1;
    scan_en[2] = aging_ctl.scan_en2;
    scan_en[3] = aging_ctl.scan_en3;
    interval[0] = aging_ctl.aging_interval0;
    interval[1] = aging_ctl.aging_interval1;
    interval[2] = aging_ctl.aging_interval2;
    interval[3] = aging_ctl.aging_interval3;

    min_ptr = aging_ctl.min_ptr;
    max_ptr = aging_ctl.max_ptr;
    userid_max_ptr = aging_ctl.aging_user_id_max_ptr;
    ip_max_ptr = aging_ctl.aging_ip_max_ptr;
    mac_max_ptr = aging_ctl.aging_mac_max_ptr;

    cmd = DRV_IOR(FibEngineLookupResultCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, 0, cmd, &lkp_ctl));

    for (cm_aging_index = 0; cm_aging_index < CM_AGING_INDEX_MAX; cm_aging_index++)
    {
        if (!scan_en[cm_aging_index])
        {
            continue;
        }

        curr_sleep_count = 0;
        sal_gettime(&tv);
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_AGING,
            CM_AGING_STR" scan chip %d, type %d at time %d sec\n",
            chip_id, cm_aging_index, tv.tv_sec);

        /* calc aging count for one sleep 10ms */
        /* aging seconds = interval / 2000
         * sleep_time = (seconds * 1000) / 10 = (interval / 20)
         * max_sleep_count = (max_ptr - min_ptr) / sleep_time = 20 * (max_ptr - min_ptr) / interval
         * 23/10 is quotiety according to testing
         */
        max_sleep_count = (20 * (aging_ctl.max_ptr - aging_ctl.min_ptr + 1)) / interval[cm_aging_index];
        max_sleep_count = (max_sleep_count * g_cm_aging_quotiety) / 10;

        for (aging_ptr = min_ptr; aging_ptr < max_ptr; aging_ptr++)
        {
            g_cm_aging_ptr[cm_aging_index] = aging_ptr;
            curr_sleep_count++;
            if (curr_sleep_count >= max_sleep_count)
            {
                curr_sleep_count = 0;
                sal_task_sleep(10);

                /* update scan en, interval will not updated */
                cmd = DRV_IOR(IpeAgingCtl_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, 0, cmd, &aging_ctl));
                scan_en[0] = aging_ctl.scan_en0;
                scan_en[1] = aging_ctl.scan_en1;
                scan_en[2] = aging_ctl.scan_en2;
                scan_en[3] = aging_ctl.scan_en3;
                if (!scan_en[cm_aging_index])
                {
                    break;
                }
            }

            if (aging_ptr < CM_TCAM_AGING_MAX_PTR)
            {
                /* [0, 8192 + 256 - 1] */
                /* TCAM Aging */
                continue;
            }
            else if (aging_ptr < userid_max_ptr)
            {
                /* UserID Aging */
                continue;
            }
            else if (aging_ptr < ip_max_ptr)
            {
                /* IP Aging */
                continue;
            }
            else if (aging_ptr < mac_max_ptr)
            {
                fdb_key_index = aging_ptr - ip_max_ptr;
                _cm_ipe_aging_engine_mac_aging(chip_id, 0, aging_ptr, fdb_key_index, &lkp_ctl, &aging_ctl);
            }
            else
            {
                continue;
            }
        }

        /* clear scan enable */
        if (aging_ctl.stop_on_max_ptr)
        {
            scan_en[cm_aging_index] = FALSE;
            cmd = DRV_IOW(IpeAgingCtl_t, IpeAgingCtl_ScanEn0_f + cm_aging_index);
            DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, 0, cmd, &scan_en[cm_aging_index]));
        }
    }

    return DRV_E_NONE;
}

int32
cm_update_aging_cache(uint8 chip_id, uint32 type, uint32 aging_ptr, uint32 valid)
{
    ipe_aging_ctl_t aging_ctl;
    uint32 aging32bit_index = 0;
    uint32 aging_status_bit = 0;
    uint32 aging_status = 0;
    uint32 cmd = 0;
    uint32 aging_bit_ptr = 0;


    cmd = DRV_IOR(IpeAgingCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, 0, cmd, &aging_ctl));

    switch (type)
    {
    case CM_AGING_SOURCE_TCAM:
        /* not implement */
        return DRV_E_INVAILD_TYPE;
        break;

    case CM_AGING_SOURCE_USERID:
        aging_bit_ptr = (aging_ptr - 256) + CM_TCAM_AGING_MAX_PTR;
        break;

    case CM_AGING_SOURCE_FIB:
        if (aging_ptr < 256)
        {
            aging_bit_ptr = aging_ptr + 8192;
        }
        else
        {
            aging_bit_ptr = (aging_ptr - 256) + aging_ctl.aging_user_id_max_ptr;
        }
        break;

    default:
        return DRV_E_INVAILD_TYPE;
    }

    aging32bit_index = (((aging_bit_ptr - CM_TCAM_AGING_MAX_PTR) >> 5) + (CM_TCAM_AGING_MAX_PTR >> 3));

    if (aging_bit_ptr < CM_TCAM_AGING_MAX_PTR)
    {
        /* not implement */
    }
    else
    {
        cmd = DRV_IOR(DsAging_t, DsAging_AgingStatus_f);
        DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, aging32bit_index, cmd, &aging_status));
        aging_status_bit = (1 << (aging_bit_ptr % 32));

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_AGING,
            CM_AGING_STR" update chip %d aging_ptr %d index %d status 0x%08x set 0x%08x\n",
            chip_id, aging_bit_ptr, aging32bit_index, aging_status, aging_status_bit);

        if (valid)
        {
            aging_status |= aging_status_bit;
        }
        else
        {
            aging_status &= (~aging_status_bit);
        }
        cmd = DRV_IOW(DsAging_t, DsAging_AgingStatus_f);
        DRV_IF_ERROR_RETURN(sim_ioctl(chip_id, aging32bit_index, cmd, &aging_status));
    }

    return DRV_E_NONE;
}

void
cm_sim_aging_engine()
{
    uint8 chip_id = 0;
    uint8 chip_num = 0;

    drv_get_chipnum(&chip_num);

    for (;;)
    {
        for (chip_id = 0; chip_id < chip_num; chip_id++)
        {
            _cm_ipe_aging_engine_chip_process(chip_id);
        }

        sal_task_sleep(100);
    }

    return;
}

