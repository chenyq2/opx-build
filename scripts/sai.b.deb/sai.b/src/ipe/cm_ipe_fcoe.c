/****************************************************************************
 * cm_ipe_fcoe.c: Performs IPE FCoE switch operation.
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Version:        V1.0.
 * Author:         JiangJF
 * Date:           2010-10-12.
 * Reason:         First Create.
 *
 * Modify History:
 * Reversion:      V1.01
 * Author:         XuZx
 * Date:           2010-11-15.
 * Reason:         Revise for first formal spec.
 *
 * Reversion:      V1.02
 * Author:         XuZx
 * Date:           2010-11-23.
 * Reason:         Revise for second formal spec.
 *
 * Reversion:      V2.0
 * Author:         Jiangsz
 * Date:           2011-04-08.
 * Reason:         sync spec V2.0.
 *
 * Reversion:      V4.2
 * Author:         Jiangsz
 * Date:           2011-07-04.
 * Reason:         sync spec V4.2.
 *
 * Reversion:      V4.29.0
 * Author:         wangcy
 * Date:           2011-10-08.
 * Reason:         sync spec V4.29.0.
 *
 * Reversion:      V5.1.0
 * Author:         Wangcy
 * Date:           2012-1-7.
 * Reason:         sync spec v5.1.0.
 *
 * Reversion:      V5.7.0
 * Author:         Wangcy
 * Date:           2012-1-17.
 * Reason:         sync spec v5.7.0.
 *
 * Reversion:      V5.11.0
 * Author:         ZhouW
 * Date:           2012-03-01.
 * Reason:         sync spec v5.11.0.
 *
 * Reversion:      V5.13.0
 * Author:         Wangcy
 * Date:           2012-03-12.
 * Reason:         sync spec v5.13.0.
 *
 * Revision:       V5.15.2.
 * Author:         ZhouW.
 * Date:           2012-04-01.
 * Reason:         Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "ctcutil_rand.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/

/****************************************************************************
 * Name:       cm_ipe_fcoe_handle
 * Purpose:    IPE fcoe handle process.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE -- success.
 *             Other -- ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 cm_ipe_fcoe_handle(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *) pkt_info->parser_rslt;
    uint8 fcoe_packet = 0;
    ds_fcoe_da_t* ds_fcoe_da_tcam = NULL;
    ds_fcoe_sa_t* ds_fcoe_sa_tcam = NULL;
    ds_fcoe_da_t* ds_fcoe_da_fib = NULL;
    ds_fcoe_sa_t* ds_fcoe_sa_fib = NULL;
    ds_fcoe_da_t* ds_fcoe_da = NULL;
    ds_fcoe_sa_t* ds_fcoe_sa = NULL;
    uint8 rpf_check_ok = FALSE;
    uint8 fcoe_sa_tcam_result_valid = FALSE;
    uint8 fcoe_da_tcam_result_valid = FALSE;
    uint8 fcoe_sa_fib_result_valid = FALSE;
    uint8 fcoe_da_fib_result_valid = FALSE;
    uint8 mac_sa_check_ok= FALSE;
    uint8 fcoe_da_default_entry_valid = FALSE;
    uint8 fcoe_sa_default_entry_valid = FALSE;
    uint8 fcoe_da_result_valid = FALSE;
    uint8 fcoe_sa_result_valid = FALSE;
    uint8 dlb_en = FALSE;
    uint8 ecmp_hash = 0;
    uint32 cmd = 0;
    uint32 ds_ecmp_ptr = 0;
    uint8 current_ts = 0;
    uint8 dest_channel[16] = {0};
    uint32 channel_class[16] = {0};
    uint8 equal_cost_path_sel = 0;
    uint8 ecmp_mem_num = 0;
    uint8 index = 0;
    uint8 max_channel_class = 0;
    uint8 max_channel_class_index_array[16] = {0};
    uint8 max_channel_class_count = 0;
    uint32 random = 0;
    uint32 ds_fwd_ptr = 0;

    ipe_fcoe_ctl_t ipe_fcoe_ctl;
    ipe_ecmp_ctl_t ipe_ecmp_ctl;
    ds_ecmp_state_t ds_ecmp_state;
    ds_ecmp_group_t ds_ecmp_group;
    ipe_ecmp_channel_state_t ipe_ecmp_channel_state;

    sal_memset(&ipe_fcoe_ctl, 0, sizeof(ipe_fcoe_ctl));
    cmd = DRV_IOR(IpeFcoeCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_fcoe_ctl));

    sal_memset(&ipe_ecmp_ctl, 0, sizeof(ipe_ecmp_ctl));
    cmd = DRV_IOR(IpeEcmpCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_ecmp_ctl));

    if (pkt_info->is_fcoe)
    {
        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1)) /* TCAM lookup enabled */
        {
            fcoe_da_tcam_result_valid = pkt_info->fcoe_da_tcam_result_valid;
            ds_fcoe_da_tcam = (ds_fcoe_da_t* )pkt_info->fcoe_da_data_tcam;
        }

        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0)) /* FIB lookup enabled */
        {
            fcoe_da_fib_result_valid = pkt_info->fcoe_da_fib_result_valid;
            fcoe_da_default_entry_valid = pkt_info->fcoe_da_fib_default_entry_valid;
            ds_fcoe_da_fib = (ds_fcoe_da_t* )pkt_info->fcoe_da_data_fib;
        }

        /* First hash */
        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0)
            && fcoe_da_fib_result_valid && !fcoe_da_default_entry_valid)
        {
            fcoe_da_result_valid = fcoe_da_fib_result_valid;
            ds_fcoe_da = ds_fcoe_da_fib;
        }
        /* Second TCAM */
        else if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1) && fcoe_da_tcam_result_valid)
        {
            fcoe_da_result_valid = fcoe_da_tcam_result_valid;
            ds_fcoe_da = ds_fcoe_da_tcam;
        }
        /* Third Default */
        else if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0) && fcoe_da_fib_result_valid)
        {
            fcoe_da_result_valid = fcoe_da_fib_result_valid;
            ds_fcoe_da = ds_fcoe_da_fib;
        }
    }

    if (pkt_info->is_fcoe_rpf)
    {
        if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 1)) /* TCAM lookup enabled */
        {
            fcoe_sa_tcam_result_valid = pkt_info->fcoe_sa_tcam_result_valid;
            ds_fcoe_sa_tcam = (ds_fcoe_sa_t* )pkt_info->fcoe_sa_data_tcam;
        }

        if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0)) /* FIB lookup enabled */
        {
            fcoe_sa_fib_result_valid = pkt_info->fcoe_sa_fib_result_valid;
            fcoe_sa_default_entry_valid = pkt_info->fcoe_sa_fib_default_entry_valid;
            ds_fcoe_sa_fib = (ds_fcoe_sa_t* )pkt_info->fcoe_sa_data_fib;
        }

        /* First hash */
        if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0)
            && fcoe_sa_fib_result_valid && !fcoe_sa_default_entry_valid)
        {
            fcoe_sa_result_valid = fcoe_sa_fib_result_valid;
            ds_fcoe_sa = ds_fcoe_sa_fib;
        }
        /* Second TCAM */
        else if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 1) && fcoe_sa_tcam_result_valid)
        {
            fcoe_sa_result_valid = fcoe_sa_tcam_result_valid;
            ds_fcoe_sa = ds_fcoe_sa_tcam;
        }
        /* Third Default */
        else if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0) && fcoe_sa_fib_result_valid)
        {
            fcoe_sa_result_valid = fcoe_sa_fib_result_valid;
            ds_fcoe_sa = ds_fcoe_sa_fib;
        }
    }

    fcoe_packet = (!pkt_info->discard) && pkt_info->is_fcoe && fcoe_da_result_valid &&
                    (!pkt_info->deny_route || ipe_fcoe_ctl.fcoe_bypass_deny_route);

    if (fcoe_packet)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Fcoe Process");

        /* FORWARDING */
        if (fcoe_sa_result_valid)
        {

            rpf_check_ok=  !fcoe_sa_result_valid || !ds_fcoe_sa->rpf_check_en
                       || (ds_fcoe_sa->global_src_port == pkt_info->global_src_port);

            mac_sa_check_ok = !fcoe_sa_result_valid || !ds_fcoe_sa->mac_sa_check_en
                    ||((parser_result->l2_s.mac_sa0 == (ds_fcoe_sa->mac_sa16_0 & 0xFF))
                    && (parser_result->l2_s.mac_sa1 == ((ds_fcoe_sa->mac_sa16_0 >> 8) & 0xFF))
                    && (parser_result->l2_s.mac_sa2 == ((((ds_fcoe_sa->mac_sa16_0 >> 16) & 0x1)
                        | (ds_fcoe_sa->mac_sa20_17 << 1)
                        | ((ds_fcoe_sa->mac_sa28_21 & 0x7) << 5)) & 0xFF))
                    && (parser_result->l2_s.mac_sa3 == ((((ds_fcoe_sa->mac_sa28_21 >> 3) & 0x1F)
                        | ((ds_fcoe_sa->mac_sa44_29 & 0x7) << 5)) & 0xFF))
                    && (parser_result->l2_s.mac_sa4 == ((ds_fcoe_sa->mac_sa44_29 >> 3) & 0xFF))
                    && (parser_result->l2_s.mac_sa5 == (((ds_fcoe_sa->mac_sa44_29 >> 11) & 0x1F)
                        | (ds_fcoe_sa->mac_sa46_45 << 5) | (ds_fcoe_sa->mac_sa47_47 << 7))));

            if (!rpf_check_ok || !mac_sa_check_ok || ds_fcoe_sa->src_discard)
            {
                pkt_info->fatal_exception_valid = TRUE;
                pkt_info->fatal_exception = FATAL_EXP_FCOE_VIRTUAL_LINK_CHECK_FAIL;
            }
        }

        dlb_en = ds_fcoe_da->dlb_en;
        ecmp_hash = ipe_fcoe_ctl.fcoe_ecmp_hash_mode ? (parser_result->l2_s.mac_ecmp_hash) : (parser_result->l3_s.ip_ecmp_hash);

        pkt_info->ds_fwd_ptr_valid = TRUE;

        if(ds_fcoe_da->priority_path_en)
        {
            pkt_info->ds_fwd_ptr = ds_fcoe_da->ds_fwd_ptr + pkt_info->priority_path_select;
        }
        else if(dlb_en)
        {
            switch(ipe_ecmp_ctl.ecmp_flow_num)
            {
                case 0:
                    ds_ecmp_ptr = ((ds_fcoe_da->equal_cost_path_num & 0x3) << 8) | (ecmp_hash & 0xFF);
                    break;
                case 1:
                    ds_ecmp_ptr = ((ds_fcoe_da->equal_cost_path_num & 0x7) << 7) | (ecmp_hash & 0x7F);
                    break;
                case 2:
                    ds_ecmp_ptr = ((ds_fcoe_da->equal_cost_path_num & 0xF) << 6) | (ecmp_hash & 0x3F);
                    break;
                case 3:
                    ds_ecmp_ptr = ((ds_fcoe_da->equal_cost_path_num & 0xF) << 5) | (ecmp_hash & 0x1F);
                    break;
                default:
                    break;
            }

            sal_memset(&ds_ecmp_state, 0, sizeof(ds_ecmp_state));
            cmd = DRV_IOR(DsEcmpState_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, ds_ecmp_ptr, cmd, &ds_ecmp_state));

            /* ECMP bundle to same ports */
            sal_memset(&ds_ecmp_group, 0, sizeof(ds_ecmp_group));
            cmd = DRV_IOR(DsEcmpGroup_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, ds_fcoe_da->equal_cost_path_num, cmd, &ds_ecmp_group));

            /* flow active */
            if (ds_ecmp_state.active && ((current_ts - ds_ecmp_state.old_ts) < ipe_ecmp_ctl.ts_threshold))
            {
                pkt_info->ds_fwd_ptr = ds_ecmp_state.ds_fwd_ptr;
                ds_ecmp_state.old_ts = current_ts;
            }
            /* flow inactive */
            else
            {
                sal_memset(&ipe_ecmp_channel_state, 0, sizeof(ipe_ecmp_channel_state));
                cmd = DRV_IOR(IpeEcmpChannelState_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_ecmp_channel_state));

                dest_channel[0] = ds_ecmp_group.dest_channel0; dest_channel[1] = ds_ecmp_group.dest_channel1;
                dest_channel[2] = ds_ecmp_group.dest_channel2; dest_channel[3] = ds_ecmp_group.dest_channel3;
                dest_channel[4] = ds_ecmp_group.dest_channel4; dest_channel[5] = ds_ecmp_group.dest_channel5;
                dest_channel[6] = ds_ecmp_group.dest_channel6; dest_channel[7] = ds_ecmp_group.dest_channel7;

                for (index = 0; index < 8; index++)
                {
                    cmd = DRV_IOR(IpeEcmpChannelState_t, (IpeEcmpChannelState_ChannelClass0_f + (dest_channel[index] & 0x3F)));
                    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &(channel_class[index])));
                }

                ecmp_mem_num = ds_ecmp_group.ecmp_mem_num;

                max_channel_class = channel_class[0];/* store current max_channel_class */
                max_channel_class_index_array[0] = 0;/* store index of all max_channel_class item */
                max_channel_class_count = 1;/* max_channel_class item count */

                for (index = 1; index < ecmp_mem_num; index++)
                {
                    if(channel_class[index] == max_channel_class)
                    {
                        max_channel_class_index_array[max_channel_class_count] = index;
                        max_channel_class_count ++;
                    }
                    else if(channel_class[index] > max_channel_class)
                    {
                        max_channel_class_index_array[0] = index;
                        max_channel_class_count = 1;
                    }
                }

                if (1 == max_channel_class_count)
                {
                    index = max_channel_class_index_array[0];
                }
                else
                {
                    ctcutil_rand(0, 0x7FFF, &random); /* software random may be diffrent from ASIC */
                    index = max_channel_class_index_array[random % max_channel_class_count];
                }

                switch(index)
                {
                    case 0:
                        ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr0;
                        break;
                    case 1:
                        ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr1;
                        break;
                    case 2:
                        ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr2;
                        break;
                    case 3:
                        ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr3;
                        break;
                    case 4:
                        ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr4;
                        break;
                    case 5:
                        ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr5;
                        break;
                    case 6:
                        ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr6;
                        break;
                    case 7:
                        ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr7;
                        break;
                    default:
                        break;
                }

                ds_ecmp_state.ds_fwd_ptr = ds_fwd_ptr;
                pkt_info->ds_fwd_ptr = ds_fwd_ptr;
                ds_ecmp_state.old_ts = current_ts;
                ds_ecmp_state.active = TRUE;
            }

            /* write  ecmpstate back */
            cmd = DRV_IOW(DsEcmpState_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, ds_ecmp_ptr, cmd, &ds_ecmp_state));
        }
        else
        {
            switch (ds_fcoe_da->equal_cost_path_num)
            {
                case 0:
                    equal_cost_path_sel = 0;
                    break;
                case 1:
                    equal_cost_path_sel = IS_BIT_SET(ecmp_hash, 0);
                    break;
                case 2:
                    equal_cost_path_sel = ecmp_hash % 3;
                    break;
                case 3:
                    equal_cost_path_sel = ecmp_hash & 0x3;
                    break;
                case 4:
                    equal_cost_path_sel = ecmp_hash % 5;
                    break;
                case 5:
                    equal_cost_path_sel = ecmp_hash % 6;
                    break;
                case 6:
                    equal_cost_path_sel = ecmp_hash % 7;
                    break;
                case 7:
                    equal_cost_path_sel = ecmp_hash & 0x7;
                    break;
                default:
                    equal_cost_path_sel = ecmp_hash & 0xF;
                    break;
            }

            pkt_info->ds_fwd_ptr = ds_fcoe_da->ds_fwd_ptr + equal_cost_path_sel;
        }

        pkt_info->payload_packet_type = PKT_TYPE_ETHERNETV2; /* send Ethernet */
        pkt_info->payload_offset = parser_result->layer2_offset;
    }

    return DRV_E_NONE;
}

