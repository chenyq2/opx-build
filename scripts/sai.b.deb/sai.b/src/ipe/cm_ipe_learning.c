/****************************************************************************
 * cm_ipe_learning.c    Provides IPE mac learning handle function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Version:      V1.0
 * Author:       JiangJf
 * Date:         2010-10-13.
 * Reason:       First Create.
 *
 * Modify History:
 * Reversion:    V1.01
 * Author:       XuZx
 * Date:         2010-11-15.
 * Reason:       Revise for first formal spec.
 *
 * Reversion:    V1.02
 * Author:       XuZx
 * Date:         2010-11-23.
 * Reason:       Revise for second formal spec.
 *
 * Reversion:    V2.0
 * Author:       Jiangsz
 * Date:         2011-4-11.
 * Reason:       sync specV2.0
 *
 * Reversion:    V4.2
 * Author:       Jiangsz
 * Date:         2011-7-06.
 * Reason:       sync specV4.2
 *
 * Reversion:    V4.28
 * Author:       JiaK
 * Date:         2011-10-08.
 * Reason:       sync specV4.28
 *
 * Revision:     V5.1.0
 * Author:       Wangcy.
 * Date:         2012-1-7.
 * Reason:       sync spec v5.1.0.
 *
 * Revision:     V5.7.0
 * Author:       Wangcy.
 * Date:         2012-1-17.
 * Reason:       sync spec v5.7.0.
 *
 * Reversion:    V5.11.0
 * Author:       ZhouW
 * Date:         2012-03-01.
 * Reason:       sync spec v5.11.0.
 *
 * Reversion:    V5.13.0
 * Author:       Wangcy
 * Date:         2012-03-12.
 * Reason:       sync spec v5.13.0.
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/
#define CM_IPE_FDB_CAM_NUM  16

int32
cm_ipe_learning_update_fib_learning_fifo(uint8 chip_id, uint32 valid, uint32 key_index, ds_mac_hash_key_t* p_mac_key)
{
    fib_learn_fifo_info_t learn_fifo;
    fib_learn_fifo_result_t learn_fifo_result;
    uint32 cmd = 0;

    sal_memset(&learn_fifo, 0, sizeof(learn_fifo));
    sal_memset(&learn_fifo_result, 0, sizeof(learn_fifo_result));

    cmd = DRV_IOR(FibLearnFifoInfo_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &learn_fifo));

    if (0 != learn_fifo.learn_fifo_depth)
    {

    }
    else
    {
        learn_fifo_result.valid = valid;
        learn_fifo_result.key_index = key_index;
        learn_fifo_result.is_mac_hash = p_mac_key->is_mac_hash;
        learn_fifo_result.vsi_id = p_mac_key->vsi_id;
        learn_fifo_result.mapped_mac31_0 = p_mac_key->mapped_mac31_0;
        learn_fifo_result.mapped_mac47_32 = p_mac_key->mapped_mac47_32;
        learn_fifo_result.ds_ad_index1_0 = p_mac_key->ds_ad_index1_0;
        learn_fifo_result.ds_ad_index2_2 = p_mac_key->ds_ad_index2_2;
        learn_fifo_result.ds_ad_index14_3 = p_mac_key->ds_ad_index14_3;
        cmd = DRV_IOW(FibLearnFifoResult_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &learn_fifo_result));

        learn_fifo.learn_fifo_depth = 1;
        cmd = DRV_IOW(FibLearnFifoInfo_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &learn_fifo));
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_ipe_learning_learn_mac_sa
 * Purpose:    IPE learning handle.
 * Parameters:
 * Input:      in_packet  -- pointer to buffer which save input packet and packet
 *                           header ,and processing informations
 *             learning_source_port -- need learning or not
 *             vsi_id               -- vsi id
 *             is_ether_oam         -- ether oam learing or not
 *             ether_oam_md_level   -- ether oam md level
 *             is_outer_learning    -- learn mac sa in tunnel payload or not
 * Output:     write mac sa learning entry to cache
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_ipe_learning_learn_mac_sa(ipe_in_pkt_t *ipkt, ipe_learn_proc_input_info_t *p_learn_info)
{
    #define INVALID_LEARNING_CACHE_INDEX 0xFF

    ipe_packet_info_t *pkt_info = (ipe_packet_info_t*)ipkt->pkt_info;
    ipe_learning_cache_t ipe_learning_cache;
    ipe_learning_cache_valid_t ipe_learning_cache_valid;

    uint8 chip_id = ipkt->chip_id;
    uint8 in_cache = FALSE;
    uint8 learning_cache_miss = FALSE, learning_cache_full = FALSE, learning_cache_int = FALSE;
    uint16 write_learning_cache_index = INVALID_LEARNING_CACHE_INDEX;
    uint16 learning_cache_count = 0;
    int32 learning_cache_index = 0;
    uint32 cmd = 0;

    learning_cache_miss = TRUE;

    sal_memset(&ipe_learning_cache_valid, 0, sizeof(ipe_learning_cache_valid));
    cmd = DRV_IOR(IpeLearningCacheValid_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_learning_cache_valid));

    if (!p_learn_info->fast_learning_en)   /*normal learning*/
    {
        /* search learning cache to find match entry, if not match , will learning, else not learning */
        for (learning_cache_index = IPE_LEARNING_CACHE_MAX_INDEX-1; learning_cache_index >= 0; learning_cache_index--)
        {
            if (IS_BIT_SET(ipe_learning_cache_valid.learning_entry_valid, learning_cache_index))
            {
                sal_memset(&ipe_learning_cache, 0, sizeof(ipe_learning_cache));
                cmd = DRV_IOR(IpeLearningCache_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, learning_cache_index, cmd, &ipe_learning_cache));

                if (p_learn_info->is_outer_learning)
                {
                    in_cache = (p_learn_info->vsi_id == ipe_learning_cache.vsi_id)
                               && (p_learn_info->learning_source_port == ipe_learning_cache.source_port)
                               && (p_learn_info->is_global_src_port == ipe_learning_cache.is_global_src_port)
                               && (p_learn_info->mac_sa_31_0 == ipe_learning_cache.mac_sa_low)
                               && (p_learn_info->mac_sa_47_32 == ipe_learning_cache.mac_sa_hi);
                }
                else
                {
                    in_cache = (p_learn_info->vsi_id == ipe_learning_cache.vsi_id)
                               && (p_learn_info->learning_source_port == ipe_learning_cache.source_port)
                               && (p_learn_info->is_global_src_port == ipe_learning_cache.is_global_src_port)
                               && (p_learn_info->is_ether_oam == ipe_learning_cache.is_ether_oam)
                               && (p_learn_info->ether_oam_level == ipe_learning_cache.ether_oam_level)
                               && (p_learn_info->mac_sa_31_0 == ipe_learning_cache.mac_sa_low)
                               && (p_learn_info->mac_sa_47_32 == ipe_learning_cache.mac_sa_hi);
                }

                if (in_cache)
                {
                    learning_cache_miss = FALSE;
                    CMODEL_DEBUG_OUT_INFO("++++ Do learning! learning entry has been in learning cache!!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                    break;
                }
            }
            else
            {
                /* find a first empty entry for learning */
                if (INVALID_LEARNING_CACHE_INDEX == write_learning_cache_index)
                {
                    write_learning_cache_index = learning_cache_index;
                }
            }
        }

        /* cache full */
        learning_cache_full = (0xFFFF == ipe_learning_cache_valid.learning_entry_valid)
                              || ipe_learning_cache_valid.always_cpu_learning;

        for (learning_cache_index = 0; learning_cache_index < IPE_LEARNING_CACHE_MAX_INDEX; learning_cache_index++)
        {
            if (IS_BIT_SET(ipe_learning_cache_valid.learning_entry_valid, learning_cache_index))
            {
                learning_cache_count++;
            }
        }

        if (learning_cache_count > ipe_learning_cache_valid.learning_cache_int_threshold)
        {
            learning_cache_int = TRUE;
        }

        if (learning_cache_miss)
        {
            if (learning_cache_full)
            {
                /* Send packet to CPU in case of learning cache full */
                if (ipe_learning_cache_valid.exception_en)
                {
                    pkt_info->exception_en = TRUE;
                    pkt_info->exception_index = EXCEPTION_TYPE_LEARNING_CACHE_FULL;
                }
            }
            else if (p_learn_info->is_outer_learning)
            {
                /* need to differentiate outer learning ??? */
                sal_memset(&ipe_learning_cache, 0, sizeof(ipe_learning_cache));

                ipe_learning_cache.mac_sa_low = p_learn_info->mac_sa_31_0;
                ipe_learning_cache.mac_sa_hi = p_learn_info->mac_sa_47_32;
                ipe_learning_cache.source_port = p_learn_info->learning_source_port;
                ipe_learning_cache.vsi_id = p_learn_info->vsi_id;
                ipe_learning_cache.is_global_src_port = p_learn_info->is_global_src_port;
                ipe_learning_cache.old_cvlan_id = p_learn_info->old_cvlan_id;
                ipe_learning_cache.new_cvlan_id = p_learn_info->new_cvlan_id;
                ipe_learning_cache.old_svlan_id = p_learn_info->old_svlan_id;
                ipe_learning_cache.new_svlan_id = p_learn_info->new_svlan_id;

                cmd = DRV_IOW(IpeLearningCache_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, write_learning_cache_index, cmd, &ipe_learning_cache));

                SET_BIT(ipe_learning_cache_valid.learning_entry_valid, write_learning_cache_index);
                cmd = DRV_IOW(IpeLearningCacheValid_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_learning_cache_valid));
                /* trigger SW learning interrupt */
                DRV_IF_ERROR_RETURN(cm_com_interrupt_set(chip_id, TRUE, CM_INTR_GB_FUNC_IPE_LEARN_CACHE, CM_INTR_ALL));
            }
            else
            {
                /* add entry to IPELearning Cache */
                sal_memset(&ipe_learning_cache, 0, sizeof(ipe_learning_cache));

                ipe_learning_cache.mac_sa_low = p_learn_info->mac_sa_31_0;
                ipe_learning_cache.mac_sa_hi = p_learn_info->mac_sa_47_32;
                ipe_learning_cache.source_port = p_learn_info->learning_source_port;
                ipe_learning_cache.vsi_id = p_learn_info->vsi_id;
                ipe_learning_cache.is_ether_oam = p_learn_info->is_ether_oam;
                ipe_learning_cache.ether_oam_level = p_learn_info->ether_oam_level;
                ipe_learning_cache.is_global_src_port = p_learn_info->is_global_src_port;
                ipe_learning_cache.old_cvlan_id = p_learn_info->old_cvlan_id;
                ipe_learning_cache.old_svlan_id = p_learn_info->old_svlan_id;
                ipe_learning_cache.new_cvlan_id = p_learn_info->new_cvlan_id;
                ipe_learning_cache.new_svlan_id = p_learn_info->new_svlan_id;

                cmd = DRV_IOW(IpeLearningCache_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, write_learning_cache_index, cmd, &ipe_learning_cache));

                SET_BIT(ipe_learning_cache_valid.learning_entry_valid, write_learning_cache_index);
                cmd = DRV_IOW(IpeLearningCacheValid_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_learning_cache_valid));
                /* trigger SW learning interrupt */
                DRV_IF_ERROR_RETURN(cm_com_interrupt_set(chip_id, TRUE, CM_INTR_GB_FUNC_IPE_LEARN_CACHE, CM_INTR_ALL));
            }
        }
    }
    else
    {
        /* hardware learning*/
        fib_engine_lookup_result_ctl_t lkp_rslt_ctl;
        fib_engine_lookup_result_ctl1_t lkp_rslt_ctl1;
        ds_mac_hash_key_t mac_hash_key;
        ds_mac_hash_key_t fib_key;
        ds_mac_t ds_mac;
        lookup_info_t lkp_info;
        lookup_result_t lkp_rslt;
        fib_learn_fifo_info_t learn_fifo;
        hash_io_by_idx_para_t hash_io_para;
        uint32 ds_ad_index = 0;
        uint32 fib_learning_fifo_not_full = FALSE;

        sal_memset(&lkp_rslt_ctl, 0, sizeof(lkp_rslt_ctl));
        sal_memset(&lkp_rslt_ctl1, 0, sizeof(lkp_rslt_ctl1));
        sal_memset(&mac_hash_key, 0, sizeof(mac_hash_key));
        sal_memset(&fib_key, 0, sizeof(fib_key));
        sal_memset(&ds_mac, 0, sizeof(ds_mac));
        sal_memset(&lkp_info, 0, sizeof(lkp_info));
        sal_memset(&lkp_rslt, 0, sizeof(lkp_rslt));
        sal_memset(&learn_fifo, 0, sizeof(learn_fifo));
        sal_memset(&hash_io_para, 0, sizeof(hash_io_para));

        mac_hash_key.is_mac_hash = 1;
        mac_hash_key.mapped_mac31_0 = p_learn_info->mac_sa_31_0;
        mac_hash_key.mapped_mac47_32 = p_learn_info->mac_sa_47_32;
        mac_hash_key.valid = 1;

        cmd = DRV_IOR(FibEngineLookupResultCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &lkp_rslt_ctl));
        cmd = DRV_IOR(FibEngineLookupResultCtl1_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &lkp_rslt_ctl1));

        if (p_learn_info->is_global_src_port)
        {
            if ((p_learn_info->learning_source_port >> 9) == 0x1F)
            {
                /* linkagg */
                ds_ad_index = (p_learn_info->learning_source_port & 0x1FF) + lkp_rslt_ctl1.ds_mac_base2;
            }
            else
            {
                ds_ad_index = (p_learn_info->learning_source_port & 0x1FF) + lkp_rslt_ctl1.ds_mac_base1;
            }
        }
        else
        {
            ds_ad_index = (p_learn_info->learning_source_port) + lkp_rslt_ctl1.ds_mac_base0;
        }

        if (lkp_rslt_ctl.ad_bits_type)
        {
            mac_hash_key.vsi_id = ((ds_ad_index & 0x8000) >> 2) | (p_learn_info->vsi_id & 0x1FFF);
        }
        else
        {
            mac_hash_key.vsi_id = p_learn_info->vsi_id;
        }
        mac_hash_key.ds_ad_index1_0 = ((ds_ad_index >> 0) & 0x3);
        mac_hash_key.ds_ad_index2_2 = ((ds_ad_index >> 2) & 0x1);
        mac_hash_key.ds_ad_index14_3 = ((ds_ad_index >> 3) & 0xFFF);


        /* do hask lookup */
        fib_key.mapped_mac31_0 = mac_hash_key.mapped_mac31_0;
        fib_key.mapped_mac47_32 = mac_hash_key.mapped_mac47_32;
        fib_key.vsi_id = mac_hash_key.vsi_id;
        fib_key.valid = 1;
        fib_key.is_mac_hash = 1;

        lkp_info.chip_id = chip_id;
        lkp_info.hash_module = HASH_MODULE_FIB;
        lkp_info.hash_type = FIB_HASH_TYPE_MAC;
        lkp_info.p_ds_key = &fib_key;

        DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_lookup);
        DRV_IF_ERROR_RETURN(drv_io_api.drv_hash_lookup(&lkp_info, &lkp_rslt));

        cmd = DRV_IOR(FibLearnFifoInfo_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &learn_fifo));

        fib_learning_fifo_not_full = (0 == learn_fifo.learn_fifo_depth) ? TRUE : FALSE;
        if ((lkp_rslt.valid || lkp_rslt.free)
            && (fib_learning_fifo_not_full || lkp_rslt_ctl.fast_learning_ignore_fifo_full))
        {
            hash_io_para.chip_id = chip_id;
            hash_io_para.table_id = DsMacHashKey_t;
            hash_io_para.table_index = lkp_rslt.key_index - CM_IPE_FDB_CAM_NUM;
            hash_io_para.key = (uint32*)&mac_hash_key;
            DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_key_add_by_index);
            DRV_IF_ERROR_RETURN(drv_io_api.drv_hash_key_add_by_index(&hash_io_para));
            cm_update_aging_cache(chip_id, 2,
                lkp_rslt.key_index + lkp_rslt_ctl.fdb_aging_base + 256, 1);
        }

        if ((lkp_rslt.valid || lkp_rslt.free) && (fib_learning_fifo_not_full))
        {
            cm_ipe_learning_update_fib_learning_fifo(chip_id, TRUE, lkp_rslt.key_index, &mac_hash_key);
        }
    }

    return DRV_E_NONE;
}

int32
cm_ipe_learning_delete_dsmac_hash_key(uint8 chip_id, uint32 mac_key_index)
{
    fib_learn_fifo_info_t learn_fifo;
    ds_mac_hash_key_t mac_hash_key;
    hash_io_by_idx_para_t hash_io_para;
    uint32 fib_learning_fifo_not_full = FALSE;
    uint32 cmd = 0;

    sal_memset(&learn_fifo, 0, sizeof(learn_fifo));
    sal_memset(&mac_hash_key, 0, sizeof(mac_hash_key));
    sal_memset(&hash_io_para, 0, sizeof(hash_io_para));

    cmd = DRV_IOR(FibLearnFifoInfo_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &learn_fifo));

    fib_learning_fifo_not_full = (0 == learn_fifo.learn_fifo_depth) ? TRUE : FALSE;
    if (fib_learning_fifo_not_full)
    {
        hash_io_para.chip_id = chip_id;
        hash_io_para.table_id = DsMacHashKey_t;
        hash_io_para.table_index = mac_key_index - CM_IPE_FDB_CAM_NUM;
        hash_io_para.key = (uint32*)&mac_hash_key;
        DRV_PTR_VALID_CHECK(drv_io_api.drv_hash_key_del_by_index);
        DRV_IF_ERROR_RETURN(drv_io_api.drv_hash_key_del_by_index(&hash_io_para));

        cm_ipe_learning_update_fib_learning_fifo(chip_id, FALSE, mac_key_index, &mac_hash_key);
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       ipe_learning_handle
 * Purpose:    IPE learning handle.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_ipe_learning_handle(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t*)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    ipe_learning_cache_valid_t ipe_learning_cache_valid;
    ipe_learn_proc_input_info_t learning_info;
    ipe_learning_ctl_t ipe_learning_ctl;
    ds_mac_t *p_mac_sa = NULL;
    ds_mac_t *tcam_mac_sa = NULL;
    ds_mac_t *hash_mac_sa = NULL;

    uint8 chip_id = in_pkt->chip_id;
    uint8 src_port_mismatch = FALSE;
    uint8 mac_security_discard = FALSE;
    uint8 vsi_security_discard = FALSE;
    uint8 system_security_discard = FALSE;
    uint8 src_mismatch_discard = FALSE;
    uint8 port_security_discard = FALSE;
    uint8 vlan_security_discard = FALSE;
    uint8 learning_en = FALSE;
    uint8 need_to_learn = FALSE;
    uint32 cmd = 0;
    uint8 is_ether_oam = FALSE;
    uint8 ether_oam_level = 0;
    uint16 learning_src_port = 0;
    uint8 mac_sa_result_valid = FALSE;
    uint8 mac_sa_hash_conflict = FALSE;
    uint8 is_global_src_port = FALSE;
    uint8 hash_mac_sa_result_valid = FALSE;
    uint8 tcam_mac_sa_result_valid = FALSE;
    uint8 default_entry_valid = FALSE;
    uint32 mac_sa_lower32 = 0;
    uint16 mac_sa_upper16 = 0;

    sal_memset(&ipe_learning_cache_valid, 0, sizeof(ipe_learning_cache_valid));
    sal_memset(&ipe_learning_ctl, 0, sizeof(ipe_learning_ctl));

    /* POP_DS */
    if (pkt_info->mac_sa_lookup_en)
    {
        if (pkt_info->mac_hash_lookup_en)
        {
            hash_mac_sa_result_valid = pkt_info->mac_sa_hash_result_valid;
            default_entry_valid = pkt_info->mac_sa_default_entry_valid;
            mac_sa_hash_conflict = pkt_info->mac_sa_hash_conflict;
            hash_mac_sa = (ds_mac_t *)pkt_info->hash_mac_sa_data;
        }

        if (pkt_info->mac_tcam_lookup_en)
        {
            tcam_mac_sa_result_valid = pkt_info->mac_sa_tcam_result_valid;
            tcam_mac_sa = (ds_mac_t *)pkt_info->tcam_mac_sa_data;
        }
    }

    /* First hash */
    if (hash_mac_sa_result_valid && !default_entry_valid)
    {
        mac_sa_result_valid = hash_mac_sa_result_valid;
        p_mac_sa = hash_mac_sa;
    }
    /* Second TCAM */
    else if (tcam_mac_sa_result_valid)
    {
        mac_sa_result_valid = tcam_mac_sa_result_valid;
        p_mac_sa = tcam_mac_sa;
        mac_sa_hash_conflict = FALSE;
    }
    /* Third Default */
    else if (hash_mac_sa_result_valid)
    {
        mac_sa_result_valid = hash_mac_sa_result_valid;
        p_mac_sa = hash_mac_sa;
    }

    if (!mac_sa_result_valid)
    {
        return DRV_E_NONE;
    }

    cmd = DRV_IOR(IpeLearningCacheValid_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_learning_cache_valid));

    cmd = DRV_IOR(IpeLearningCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_learning_ctl));

    /* DS_MAC_SA */
    if (!p_mac_sa->next_hop_ptr_valid && p_mac_sa->bridge_aps_select_en && pkt_info->bridge_aps_select_en)
    {
        if (!pkt_info->aps_select_valid0)
        {
            pkt_info->aps_select_valid0 = p_mac_sa->bridge_aps_select_en;   /* used as aps_select_valid */
            pkt_info->aps_select_protecting_path0 = p_mac_sa->aps_select_protecting_path;
            pkt_info->aps_select_group_id0 = (p_mac_sa->esp_id10_9 << 9)    /* used as apsSelectGroupId[10:9] */
                                            | p_mac_sa->esp_id8_0;          /* used as apsSelectGroupId[8:0] */
        }
        else if (!pkt_info->aps_select_valid1)
        {
            pkt_info->aps_select_valid1 = p_mac_sa->bridge_aps_select_en;   /* used as aps_select_valid */
            pkt_info->aps_select_protecting_path1 = p_mac_sa->aps_select_protecting_path;
            pkt_info->aps_select_group_id1 = (p_mac_sa->esp_id10_9 << 9)    /* used as apsSelectGroupId[10:9] */
                                            | p_mac_sa->esp_id8_0;          /* used as apsSelectGroupId[8:0] */
        }
        else
        {
            pkt_info->aps_select_valid2 = p_mac_sa->bridge_aps_select_en;   /* used as aps_select_valid */
            pkt_info->aps_select_protecting_path2 = p_mac_sa->aps_select_protecting_path;
            pkt_info->aps_select_group_id2 = (p_mac_sa->esp_id10_9 << 9)    /* used as apsSelectGroupId[10:9] */
                                            | p_mac_sa->esp_id8_0;          /* used as apsSelectGroupId[8:0] */
        }

    }

    learning_src_port = (!p_mac_sa->learn_source) ? pkt_info->global_src_port : pkt_info->logic_src_port;
    is_global_src_port = (!p_mac_sa->learn_source) ? TRUE : FALSE;

    src_port_mismatch = (!p_mac_sa->learn_source) ? (pkt_info->global_src_port != p_mac_sa->global_src_port):
                                                    (pkt_info->logic_src_port != p_mac_sa->global_src_port);/*share*/

    need_to_learn = ((p_mac_sa->learn_en && !ipe_learning_ctl.mac_table_full)
                    || (src_port_mismatch && p_mac_sa->src_mismatch_learn_en))
                    && (!mac_sa_hash_conflict || !ipe_learning_cache_valid.mac_hash_conflict_learning_disable)
                    && (p_mac_sa->next_hop_ptr_valid || (!p_mac_sa->conversation_check_en
                       || (p_mac_sa->conversation_check_en && pkt_info->is_conversation)));

    /* Security discard */
    src_mismatch_discard = src_port_mismatch && p_mac_sa->src_mismatch_discard && pkt_info->port_security_en;

    port_security_discard = need_to_learn && pkt_info->mac_security_discard;

    vlan_security_discard = need_to_learn && pkt_info->mac_security_vlan_discard;

    vsi_security_discard = need_to_learn && pkt_info->mac_security_vsi_discard;

    system_security_discard = need_to_learn && ipe_learning_ctl.system_mac_security_discard;

    /* Security exception */
    if (!p_mac_sa->next_hop_ptr_valid
            && p_mac_sa->mac_sa_exception_en
            && p_mac_sa->src_discard
            && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_MAC_SA;
    }
    else if (src_mismatch_discard && pkt_info->port_security_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_SRC_MISMATCH;
    }
    else if (port_security_discard && pkt_info->port_security_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PORT_SECURITY;
    }
    else if (vlan_security_discard && ipe_learning_ctl.vlan_security_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_VLAN_SECURITY;
    }
    else if (vsi_security_discard && ipe_learning_ctl.vsi_security_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_VSI_SECURITY;
    }
    else if (system_security_discard && ipe_learning_ctl.system_security_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_SYS_SECURITY;
    }

    mac_security_discard = p_mac_sa->src_discard || src_mismatch_discard || port_security_discard
                           || vlan_security_discard || vsi_security_discard || system_security_discard;

    if (mac_security_discard && (!pkt_info->discard))
    {
        pkt_info->discard_type = IPE_DISCARD_LEARNING_DISCARD;
        pkt_info->discard = TRUE;

        if (p_mac_sa->src_discard)
        {
            CMODEL_DEBUG_OUT_INFO("++++ Discard! DsMacSa srcDiscard is set!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }

        if (src_mismatch_discard)
        {
            CMODEL_DEBUG_OUT_INFO("++++ Discard! Source port mismatch discard!\n");
            CMODEL_DEBUG_OUT_INFO("++++ DsMacSa.learnSource = %d\n", p_mac_sa->learn_source);
            CMODEL_DEBUG_OUT_INFO("++++ PacketInfo.globalSrcPort = %d; DsMacSa.globalSrcPort = %d!\n",
                                   pkt_info->global_src_port, p_mac_sa->global_src_port);
            CMODEL_DEBUG_OUT_INFO("++++ PacketInfo.logicSrcPort = %d; DsMacSa.logicSrcPort = %d!\n",
                                   pkt_info->logic_src_port, p_mac_sa->global_src_port);
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }

        if (port_security_discard)
        {
            CMODEL_DEBUG_OUT_INFO("++++ Discard! Port security discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }

        if (vlan_security_discard)
        {
            CMODEL_DEBUG_OUT_INFO("++++ Discard! Vlan security discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }

        if (vsi_security_discard)
        {
            CMODEL_DEBUG_OUT_INFO("++++ Discard! VSI security discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }

        if (system_security_discard)
        {
            CMODEL_DEBUG_OUT_INFO("++++ Discard! system security discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    mac_sa_lower32 = MAKE_UINT32(parser_result->l2_s.mac_sa3,
                                 parser_result->l2_s.mac_sa2,
                                 parser_result->l2_s.mac_sa1,
                                 parser_result->l2_s.mac_sa0);
    mac_sa_upper16 = MAKE_UINT16(parser_result->l2_s.mac_sa5,
                                 parser_result->l2_s.mac_sa4);

    /* LARNING_EN */
    learning_en = need_to_learn && (!mac_security_discard) && (!pkt_info->deny_learning);

    if (!learning_en)
    {
        return DRV_E_NONE;
    }

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Learning Process");

    /* LEARNING */
    is_ether_oam = (L3_TYPE_ETHEROAM == parser_result->layer3_type);
    ether_oam_level = is_ether_oam ? parser_result->l3_s.ip_da.eth_oam.eth_oam_level : 0;

    sal_memset(&learning_info, 0, sizeof(learning_info));
    learning_info.is_outer_learning = FALSE;
    learning_info.learning_source_port = learning_src_port;
    learning_info.is_global_src_port = is_global_src_port;
    learning_info.vsi_id = pkt_info->fid;
    learning_info.mac_sa_31_0 = mac_sa_lower32;
    learning_info.mac_sa_47_32 = mac_sa_upper16;
    learning_info.is_ether_oam = is_ether_oam;
    learning_info.ether_oam_level = ether_oam_level;
    learning_info.old_svlan_id = parser_result->l2_s.svlan_id;
    learning_info.old_cvlan_id = parser_result->l2_s.cvlan_id;
    learning_info.new_svlan_id = pkt_info->svlan_id;
    learning_info.new_cvlan_id = pkt_info->cvlan_id;

    if (pkt_info->fast_learning_en && p_mac_sa->fast_learning_en && !is_ether_oam && !mac_sa_hash_conflict)
    {
        learning_info.fast_learning_en = TRUE;
        DRV_IF_ERROR_RETURN(cm_ipe_learning_learn_mac_sa(in_pkt, &learning_info));
    }
    else
    {
        learning_info.fast_learning_en = FALSE;
        DRV_IF_ERROR_RETURN(cm_ipe_learning_learn_mac_sa(in_pkt, &learning_info));
    }

#if (SDK_WORK_PLATFORM == 1)
    if (!learning_info.is_outer_learning)
    {
        if (cosim_db.store_ipe_bus[SIM_IPE_ILREQ])
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_ILREQ]((void *)(&learning_info)));
        }
    }
    else
    {
        if (cosim_db.store_ipe_bus[SIM_IPE_OLREQ])
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_OLREQ]((void *)(&learning_info)));
        }
    }
#endif

    return DRV_E_NONE;
}

