/****************************************************************************
 * cm_ipe_oam.c:  Performs IPE OAM processing
 * Copyright:      (c)2011 Centec Networks Inc.  All rights reserved.
 *
 * Version:       V1.0.
 * Author:        JiangJf
 * Date:          2010-10-15
 * Reason:        First Create
 *
 * Modify History: ----------------------------------
 * Reversion:    V1.01
 * Author:       XuZx
 * Date:         2010-11-15.
 * Reason:       Revise for first formal spec.
 *
 * Reversion:    V1.02
 * Author:       XuZx
 * Date:         2010-11-23.
 * Reason:       Revise for second formal spec.
 *
 * Reversion:    V4.2.1
 * Author:       JiangJf
 * Date:         2011-06-30.
 * Reason:       sync spec V4.2.1.
 *
 * Reversion:    V4.3.0
 * Author:       MengZw
 * Date:         2011-07-14.
 * Reason:       sync spec V4.3.0.
 *
 * Reversion:    V5.6.0
 * Author:       Wangcy
 * Date:         2012-01-07.
 * Reason:       sync spec V5.6.0.
 *
 * Reversion:    V5.7.0
 * Author:       Wangcy
 * Date:         2012-01-17.
 * Reason:       sync spec V5.7.0.
 *
 * Reversion:    V5.11.0
 * Author:       ZhouW
 * Date:         2012-03-01.
 * Reason:       sync spec v5.11.0.
 *
 * Revision:     V5.15.0.
 * Author:       ZhouW.
 * Date:         2012-03-23.
 * Reason:       Sync to SpecV5.15.0.
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/


/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/


/****************************************************************************
 *
 * Functions
 *
****************************************************************************/

/****************************************************************************
 * Name:        cm_ipe_oam_get_mep_info
 * Purpose:     get OAM MEP information
 * Parameters:
 * Input:       p_ds_eth_oam_chan  -- oam channal info
 * Output:      mep_up_info      -- up mep info
 *              mep_down_info    -- down mep info
 * Return:      DRV_E_NONE = success.
 *              Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:        none.
****************************************************************************/



int32
cm_com_oam_get_mep_info(cm_oam_chan_info_t *chan_info, cm_oam_chan_rslt_t *chan_rslt)
{
    ds_eth_oam_chan_t* p_ds_eth_oam_chan = chan_info->p_ds_eth_oam_chan;
    oam_info_t *p_oam_chan_info = chan_info->p_oam_chan_info;
    uint8 next_lm = chan_info->next_lm;

    mep_level_info_t *mep_up_info = chan_rslt->mep_up_info;
    mep_level_info_t *mep_down_info = chan_rslt->mep_down_info;
    cm_oam_lm_info_t *lm_info = chan_rslt->lm_info;


    uint8 level = 0;
    uint8 next_mep = 0;
    uint8 mep_down_bitmap = 0;
    uint8 mep_up_bitmap = 0;
    uint8 lm_bitmap = 0;
    uint8 lm_cos_type = 0;


    for (level = 1; level < MAX_MEP_LEVEL; level++) /*level 1~7 */
    {
        mep_down_bitmap = ((p_ds_eth_oam_chan->mep_down_bitmap_high << 4) | p_ds_eth_oam_chan->mep_down_bitmap_low) << 1;
        if (IS_BIT_SET(mep_down_bitmap, level))
        {
            if ((chan_info->parser_oam_level < level) && 0 == chan_rslt->down_min_valid_lvl)
            {
                chan_rslt->down_min_valid_lvl =  level;  /* Minimum level great than parserOamLevel */
            }

            if (level > chan_rslt->down_max_valid_lvl)
            {
                chan_rslt->down_max_valid_lvl = level;
            }

            mep_down_info[level].valid = TRUE;
            switch (next_mep & 0x3) /* only 0-3 is valid */
            {
                case 0:
                    mep_down_info[level].mep_index = p_ds_eth_oam_chan->mep_index0;
                    break;
                case 1:
                    mep_down_info[level].mep_index = p_ds_eth_oam_chan->mep_index1;
                    break;
                case 2:
                    mep_down_info[level].mep_index = p_ds_eth_oam_chan->mep_index2;
                    break;
                case 3:
                    mep_down_info[level].mep_index = ((p_ds_eth_oam_chan->mep_index3_12_3 << 3)
                                                        | p_ds_eth_oam_chan->mep_index3_2_0);
                    break;
                default:
                    mep_down_info[level].mep_index = p_ds_eth_oam_chan->mep_index0;
                    break;
            }
            lm_bitmap = (p_oam_chan_info->lm_bitmap << 1);
            if (IS_BIT_SET(lm_bitmap, level) && (next_lm < 3))
            {
                lm_cos_type = (p_ds_eth_oam_chan->lm_cos_type1_1 << 1) + p_ds_eth_oam_chan->lm_cos_type0_0;

                lm_info->lm_index_base[next_lm] = p_oam_chan_info->lm_index_base + ((LM_COS_TYPE_PER_COS != lm_cos_type) ? (next_mep&0x3) :((next_mep&0x3) << 3));

                lm_info->valid[next_lm] = TRUE;
                lm_info->is_up[next_lm] = FALSE;
                lm_info->lm_level[next_lm] = level;

                lm_info->lm_cos_type[next_lm] = lm_cos_type;

                lm_info->lm_cos[next_lm] = p_ds_eth_oam_chan->lm_cos;
                lm_info->lm_type[next_lm] = (p_ds_eth_oam_chan->lm_type1_1 << 1) | p_ds_eth_oam_chan->lm_type0_0;
                next_lm++;
            }
            next_mep++;
        }

        mep_up_bitmap = ((p_ds_eth_oam_chan->mep_up_bitmap_high << 4) | p_ds_eth_oam_chan->mep_up_bitmap_low) << 1;
        if (IS_BIT_SET(mep_up_bitmap, level))
        {
            if ((chan_info->parser_oam_level < level) && 0 == chan_rslt->up_min_valid_lvl)
            {
                chan_rslt->up_min_valid_lvl = level;  /* Minimum level great than parserOamLevel */
            }
            if (level > chan_rslt->up_max_valid_lvl)
            {
               chan_rslt->up_max_valid_lvl = level;
            }

            mep_up_info[level].valid = TRUE;
            switch (next_mep & 0x3) /* only 0-3 is valid */
            {
                case 0:
                    mep_up_info[level].mep_index = p_ds_eth_oam_chan->mep_index0;
                    break;
                case 1:
                    mep_up_info[level].mep_index = p_ds_eth_oam_chan->mep_index1;
                    break;
                case 2:
                    mep_up_info[level].mep_index = p_ds_eth_oam_chan->mep_index2;
                    break;
                case 3:
                    mep_up_info[level].mep_index = ((p_ds_eth_oam_chan->mep_index3_12_3 << 3)
                                                        | p_ds_eth_oam_chan->mep_index3_2_0);
                    break;
                default:
                    mep_up_info[level].mep_index = p_ds_eth_oam_chan->mep_index0;
                    break;
            }
            lm_bitmap = (p_oam_chan_info->lm_bitmap << 1);
            if (IS_BIT_SET(lm_bitmap, level) && (next_lm < 3))
            {
                lm_cos_type = (p_ds_eth_oam_chan->lm_cos_type1_1 << 1) + p_ds_eth_oam_chan->lm_cos_type0_0;

                lm_info->lm_index_base[next_lm] = p_oam_chan_info->lm_index_base + ((LM_COS_TYPE_PER_COS != lm_cos_type) ? (next_mep&0x3) :((next_mep&0x3) << 3));

                lm_info->valid[next_lm] = TRUE;
                lm_info->is_up[next_lm] = TRUE;
                lm_info->lm_level[next_lm] = level;

                lm_info->lm_cos_type[next_lm] = lm_cos_type;

                lm_info->lm_cos[next_lm] = p_ds_eth_oam_chan->lm_cos;
                lm_info->lm_type[next_lm] = (p_ds_eth_oam_chan->lm_type1_1 << 1) | p_ds_eth_oam_chan->lm_type0_0;
                next_lm++;
            }
            next_mep++;
        }
    }
    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       cm_ipe_oam_handle
 * Purpose:    IPE fcoe handle process.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 cm_ipe_oam_handle(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t*)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    uint8 chip_id = in_pkt->chip_id;
    uint32 cmd = 0;

    mep_level_info_t mep_up_info[MAX_MEP_LEVEL];
    mep_level_info_t mep_down_info[MAX_MEP_LEVEL];

    cm_oam_chan_info_t chan_info;
    cm_oam_chan_rslt_t chan_rslt;

    uint8 compared_lm_cos[MAX_LM_INFO_NUM] = {0};

    uint8  mep_en = FALSE;

    uint8  lm_stats_en0 = FALSE;
    uint8  lm_stats_en1 = FALSE;
    uint8  lm_stats_en2 = FALSE;

    uint8  oam_result_valid = FALSE;

    uint16  lm_index0 = 0;
    uint16  lm_index1 = 0;
    uint16  lm_index2 = 0;
    uint16  lm_stats_ptr0 = 0;
    uint16  lm_stats_ptr1 = 0;
    uint16  lm_stats_ptr2 = 0;

    uint8   lm_num  = 0;
    uint8 mpls_section_lm_valid = FALSE;
    uint8 mpls_lm_type[MAX_LM_INFO_NUM] = {0};
    uint8 low_level_discard_en = FALSE;
    uint8 ether_lm_enable = FALSE;
    uint8 mpls_lm_enable = FALSE;
    uint8 lm_ptr_num = 0;

    ds_oam_lm_stats0_t ds_oam_lm_stats;

    void *ds_oam_chan = NULL;
    ds_mpls_pbt_bfd_oam_chan_t* p_ds_mpls_pbt_bfd_oam_chan = NULL;
    ds_eth_oam_chan_t* p_ds_eth_oam_chan = NULL;

    ipe_oam_ctl_t ipe_oam_ctl;

    oam_info_t* oam_chan_info = NULL;
    uint8 oam_hash_conflict    = FALSE;

    uint8 is_mpls_1dm_packet    = FALSE;
    uint8 is_mpls_2dm_packet    = FALSE;
    uint8 is_ether_dm_packet    = FALSE;
    uint8 oam_level = 0;

    cm_oam_lm_info_t lm_info;

    /*mpls lm*/
    uint8 is_mpls_oam = FALSE;
    uint8 is_mpls_ach_lm = FALSE;
    uint8 is_mpls_ach_lm_or_dm =  FALSE;
    uint8 is_mpls_ach_dm = FALSE;
    uint8 is_mpls_y1731_oam = FALSE;
    uint8 is_mpls_y1731_aps_or_ccm = FALSE;
    uint8 is_mpls_y1731_aps =  FALSE;
    uint8 is_mpls_y1731_ccm =  FALSE;
    uint8 is_mpls_y1731_lmm_or_lmr = FALSE;
    uint8 is_mpls_y1731_lmm = FALSE;
    uint8 is_mpls_y1731_lmr = FALSE;
    uint8 is_mpls_y1731_lbm = FALSE;
    uint8 is_mpls_y1731_ltm = FALSE;
    uint8 mpls_lm_valid = FALSE;

    uint8 is_single_lm0 = FALSE;
    uint8 is_single_lm1 = FALSE;
    uint8 is_single_lm2 = FALSE;
    uint8 is_dual_lm0   = FALSE;
    uint8 is_dual_lm1   = FALSE;
    uint8 is_dual_lm2   = FALSE;
    uint8 lm_mpls_data_packet = FALSE;

    uint8 lm_mpls_oam_packet0 = FALSE;
    uint8 lm_mpls_oam_packet1 = FALSE;
    uint8 lm_mpls_oam_packet2 = FALSE;

    uint8 lm_cos_match0 = FALSE;
    uint8 lm_cos_match1 = FALSE;
    uint8 lm_cos_match2 = FALSE;

    uint8 is_mpls_lm_packet0   = FALSE;
    uint8 is_mpls_lm_packet1   = FALSE;
    uint8 is_mpls_lm_packet2   = FALSE;

    /*eth lm*/
    uint8 is_ether_oam = FALSE;
    uint8 is_ether_oam_aps = FALSE;
    uint8 is_ether_oam_ccm = FALSE;
    uint8 is_ether_oam_aps_or_ccm = FALSE;
    uint8 is_ether_oam_lmm_or_lmr = FALSE;
    uint8 is_ether_oam_lmm = FALSE;
    uint8 is_ether_oam_lmr = FALSE;
    uint8 ether_lm_valid = FALSE;

    uint8 is_ether_oam_equal_level0 = FALSE;
    uint8 is_ether_oam_equal_level1 = FALSE;
    uint8 is_ether_oam_equal_level2 = FALSE;

    uint8  lm_ether_oam_packet0 = FALSE;
    uint8  lm_ether_oam_packet1 = FALSE;
    uint8  lm_ether_oam_packet2 = FALSE;

    uint8  is_ether_lm_packet0    = FALSE;
    uint8  is_ether_lm_packet1    = FALSE;
    uint8  is_ether_lm_packet2    = FALSE;

    uint8 rx_oam_type = 0, gal_exist = FALSE, entropy_label_exist = FALSE, link_or_section_oam = FALSE;
    uint8 oam_dest_chip_id = 0, dm_en = FALSE, mip_en = FALSE, lm_received_packet = FALSE;
    uint32 mep_index = 0, rx_fcb = 0, rxtx_fcl = 0;
    cm_uint64_t timestamp;

    uint8 discard_type = 0;
    bool discard_down_lm_en = FALSE, discard_up_lm_en = FALSE, discard_mpls_lm_en = FALSE, low_level_up_lm_disable = FALSE;

    sal_memset(mep_up_info, 0, sizeof(mep_level_info_t) * MAX_MEP_LEVEL);
    sal_memset(mep_down_info, 0, sizeof(mep_level_info_t) * MAX_MEP_LEVEL);

    sal_memset(&chan_info, 0, sizeof(cm_oam_chan_info_t));
    sal_memset(&chan_rslt, 0, sizeof(cm_oam_chan_rslt_t));

    sal_memset(&ds_oam_lm_stats, 0, sizeof(ds_oam_lm_stats0_t));

    sal_memset(&ipe_oam_ctl, 0, sizeof(ipe_oam_ctl));
    sal_memset(&lm_info, 0, sizeof(cm_oam_lm_info_t));

    sal_memset(&timestamp, 0, sizeof(timestamp));

    cmd = DRV_IOR(IpeOamCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_oam_ctl));

    pkt_info->is_ipv4 = (L3_TYPE_IPV4 == parser_result->layer3_type);
    pkt_info->acl_dscp_valid = pkt_info->acl_dscp_valid
                               && ((L3_TYPE_IPV4 == parser_result->layer3_type)
                                  ||(L3_TYPE_IPV6 == parser_result->layer3_type)
                                  ||(L3_TYPE_IP == parser_result->layer3_type));
    oam_chan_info = NULL;
    lm_num = 0;

    /*POP_DS*/
    if (pkt_info->lm_lookup_en0 || pkt_info->oam_lookup_en)
    {
        oam_result_valid = pkt_info->lm_result_valid0;
        ds_oam_chan = pkt_info->lm_chan_data0;
        oam_chan_info = pkt_info->lm_info0;
        oam_hash_conflict = pkt_info->hash_conflict0;
    }

    rx_oam_type = pkt_info->rx_oam_type;
    gal_exist = pkt_info->gal_exist;
    entropy_label_exist = pkt_info->entropy_label_exist;
    link_or_section_oam = pkt_info->link_or_section_OAM;
    timestamp.high_63_32 = pkt_info->share_fields_u.ptp.time_stamp_61_32;
    timestamp.low_31_0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;

    /*OAM MEP*/
    is_mpls_1dm_packet = (L4_TYPE_ACH_OAM == parser_result->layer4_type)
                         &&  ((L4_USER_TYPE_ACHOAM_ACH_DM == parser_result->l4_s.layer4_user_type) ||
                            (L4_USER_TYPE_ACHOAM_ACH_DLMDM == parser_result->l4_s.layer4_user_type) ||
                         ((L4_USER_TYPE_ACHOAM_ACH_Y1731 == parser_result->l4_s.layer4_user_type)
                            && (OAM_OP_1DM == parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code)));
    is_mpls_2dm_packet = (L4_TYPE_ACH_OAM == parser_result->layer4_type) && (L4_USER_TYPE_ACHOAM_ACH_Y1731 == parser_result->l4_s.layer4_user_type)
                            && ((OAM_OP_DMR == parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code)
                            ||(OAM_OP_DMM == parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code));
    is_ether_dm_packet =  (OAM_OP_1DM == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code) ||
                        (OAM_OP_DMM == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code) ||
                        (OAM_OP_DMR == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code);

    /*OAM LM*/
    compared_lm_cos[0] = pkt_info->packet_cos0;
    compared_lm_cos[1] = pkt_info->packet_cos0;
    compared_lm_cos[2] = pkt_info->packet_cos0;


    if ((LM_TYPE_NONE != pkt_info->link_lm_type) ||
        (((LM_ETHER == pkt_info->lm_lookup_type)|| (OAM_ETHER == rx_oam_type))&& oam_result_valid))
    {/*Ether LM*/
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Ether Oam Process");
        if (LM_TYPE_NONE != pkt_info->link_lm_type)
        {/*link lm*/

            lm_info.lm_index_base[0] = pkt_info->link_lm_index_base;
            lm_info.valid[0]        = TRUE;
            lm_info.is_up[0]        = FALSE;
            lm_info.lm_level[0]     = 0;
            lm_info.lm_type[0]      = pkt_info->link_lm_type;
            lm_info.lm_cos_type[0]  = pkt_info->link_lm_cos_type;
            lm_info.lm_cos[0]       = pkt_info->link_lm_cos;
            lm_num = 1;
        }

        if (((LM_ETHER == pkt_info->lm_lookup_type)|| (OAM_ETHER == rx_oam_type)) && oam_result_valid)
        {/*service lm*/
            chan_info.next_lm = lm_num;
            chan_info.p_ds_eth_oam_chan = ds_oam_chan;
            chan_info.p_oam_chan_info = oam_chan_info;
            chan_info.parser_oam_level = parser_result->l3_s.ip_da.eth_oam.eth_oam_level;
            chan_rslt.lm_info = &lm_info;
            chan_rslt.mep_down_info = mep_down_info;
            chan_rslt.mep_up_info = mep_up_info;

            cm_com_oam_get_mep_info(&chan_info, &chan_rslt);
        }

        if (LM_TYPE_NONE != pkt_info->link_lm_type)
        {
            pkt_info->lm_lookup_type = LM_ETHER;
        }
    }
    else
    {/*MPLS LM*/

        if ((LM_MPLS == pkt_info->lm_lookup_type) && oam_result_valid)
        {/*mpls section lm*/
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Mpls Oam Process");
            p_ds_mpls_pbt_bfd_oam_chan = ds_oam_chan;
            lm_info.valid[0] = TRUE;
            lm_info.is_up[0] = FALSE;
            lm_info.lm_index_base[0] = p_ds_mpls_pbt_bfd_oam_chan->lm_index_base;
            lm_info.lm_type[0] =p_ds_mpls_pbt_bfd_oam_chan->lm_type;
            lm_info.lm_cos_type[0] = p_ds_mpls_pbt_bfd_oam_chan->lm_cos_type;
            lm_info.lm_cos[0]  = p_ds_mpls_pbt_bfd_oam_chan->lm_cos;
            compared_lm_cos[0] = pkt_info->packet_cos0;
            mpls_lm_type[0] = p_ds_mpls_pbt_bfd_oam_chan->mpls_lm_type;
            lm_num =  1;
            mpls_section_lm_valid = TRUE;

            if (link_or_section_oam)
            {
                pkt_info->oam_lookup_num = 0;
            }
            else
            {
                pkt_info->oam_lookup_num = (3 == pkt_info->oam_lookup_num) ? pkt_info->oam_lookup_num : (pkt_info->oam_lookup_num + 1);
            }
        }

        if (LM_MPLS == pkt_info->lm_lookup_type)
        {
            if (LM_TYPE_NONE != pkt_info->lm_type0)
            {
                lm_info.valid[lm_num] = TRUE;
                lm_info.is_up[lm_num] = FALSE;
                lm_info.lm_index_base[lm_num] = pkt_info->mpls_lm_base0;
                lm_info.lm_type[lm_num] = pkt_info->lm_type0;
                lm_info.lm_cos_type[lm_num] = pkt_info->mpls_lm_cos_type0;
                lm_info.lm_cos[lm_num] = pkt_info->mpls_lm_cos0;

                compared_lm_cos[lm_num] = pkt_info->packet_cos0;

                if (mpls_section_lm_valid)
                {
                    switch (lm_num)
                    {
                    case 0:
                        CMODEL_DEBUG_OUT_INFO("+++++,Error:lm_num invalid,lm_num = %d,\n",lm_num);
                        break;
                    case 1:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type0;
                        break;
                    case 2:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type1;
                        break;
                    default:
                        CMODEL_DEBUG_OUT_INFO("+++++,Error:lm_num invalid,lm_num = %d,\n",lm_num);
                        break;
                    }
                }
                else
                {
                    switch (lm_num)
                    {
                    case 0:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type0;
                        break;
                    case 1:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type1;
                        break;
                    case 2:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type2;
                        break;
                    default:
                        CMODEL_DEBUG_OUT_INFO("+++++,Error:lm_num invalid,lm_num = %d,\n",lm_num);
                        break;
                    }
                }


                lm_num += 1;

            }

            if (LM_TYPE_NONE != pkt_info->lm_type1)
            {
                lm_info.valid[lm_num] = TRUE;
                lm_info.is_up[lm_num] = FALSE;
                lm_info.lm_index_base[lm_num] = pkt_info->mpls_lm_base1;
                lm_info.lm_type[lm_num] = pkt_info->lm_type1;
                lm_info.lm_cos_type[lm_num] = pkt_info->mpls_lm_cos_type1;
                lm_info.lm_cos[lm_num] = pkt_info->mpls_lm_cos1;

                compared_lm_cos[lm_num] = pkt_info->packet_cos1;

                if (mpls_section_lm_valid)
                {
                    switch (lm_num)
                    {
                    case 0:
                        CMODEL_DEBUG_OUT_INFO("+++++,Error:lm_num invalid,lm_num = %d,\n",lm_num);
                        break;
                    case 1:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type0;
                        break;
                    case 2:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type1;
                        break;
                    default:
                        CMODEL_DEBUG_OUT_INFO("+++++,Error:lm_num invalid,lm_num = %d,\n",lm_num);
                        break;
                    }
                }
                else
                {
                    switch (lm_num)
                    {
                    case 0:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type0;
                        break;
                    case 1:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type1;
                        break;
                    case 2:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type2;
                        break;
                    default:
                        CMODEL_DEBUG_OUT_INFO("+++++,Error:lm_num invalid,lm_num = %d,\n",lm_num);
                        break;
                    }
                }

                lm_num += 1;

            }

            if ((LM_TYPE_NONE != pkt_info->lm_type2) && (lm_num < 3))
            {
                lm_info.valid[lm_num] = TRUE;
                lm_info.is_up[lm_num] = FALSE;
                lm_info.lm_index_base[lm_num] = pkt_info->mpls_lm_base2;
                lm_info.lm_type[lm_num] = pkt_info->lm_type2;
                lm_info.lm_cos_type[lm_num] = pkt_info->mpls_lm_cos_type2;
                lm_info.lm_cos[lm_num] = pkt_info->mpls_lm_cos2;

                compared_lm_cos[lm_num] = pkt_info->packet_cos2;

                if (mpls_section_lm_valid)
                {
                    switch (lm_num)
                    {
                    case 0:
                        CMODEL_DEBUG_OUT_INFO("+++++,Error:lm_num invalid,lm_num = %d,\n",lm_num);
                        break;
                    case 1:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type0;
                        break;
                    case 2:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type1;
                        break;
                    default:
                        CMODEL_DEBUG_OUT_INFO("+++++,Error:lm_num invalid,lm_num = %d,\n",lm_num);
                        break;
                    }
                }
                else
                {
                    switch (lm_num)
                    {
                    case 0:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type0;
                        break;
                    case 1:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type1;
                        break;
                    case 2:
                        mpls_lm_type[lm_num] = pkt_info->mpls_lm_type2;
                        break;
                    default:
                        CMODEL_DEBUG_OUT_INFO("+++++,Error:lm_num invalid,lm_num = %d,\n",lm_num);
                        break;
                    }
                }


            }
        }

    }

    /*OAM MEP*/
    if (link_or_section_oam && (L3_TYPE_ETHEROAM == parser_result->layer3_type) && !pkt_info->from_cpu_or_oam)
    {/*ethernet link OAM*/
        mep_index = pkt_info->link_oam_mep_index;
        oam_dest_chip_id = ipe_oam_ctl.link_oam_dest_chip_id;
        rx_oam_type = OAM_ETHER;
        mep_en = TRUE;
        dm_en = is_ether_dm_packet;
    }
    else if (link_or_section_oam && oam_result_valid && !pkt_info->from_cpu_or_oam && !pkt_info->discard)
    {/*mpls section oam*/
        p_ds_mpls_pbt_bfd_oam_chan = ds_oam_chan;
        oam_dest_chip_id = p_ds_mpls_pbt_bfd_oam_chan->oam_dest_chip_id;
        mep_index = p_ds_mpls_pbt_bfd_oam_chan->mep_index;
        mep_en = TRUE;
        dm_en = is_mpls_1dm_packet || is_mpls_2dm_packet;
    }
    else if ((OAM_ETHER == rx_oam_type) && oam_result_valid && !pkt_info->from_cpu_or_oam && !pkt_info->discard)
    {/*ethernet service oam*/
        p_ds_eth_oam_chan = ds_oam_chan;
        oam_dest_chip_id = p_ds_eth_oam_chan->oam_dest_chip_id;

        oam_level = parser_result->l3_s.ip_da.eth_oam.eth_oam_level;
        if (mep_down_info[oam_level].valid)
        {
            mep_index = mep_down_info[oam_level].mep_index;
            mep_en = TRUE;
            dm_en = is_ether_dm_packet;
        }
        else if (oam_level < chan_rslt.down_min_valid_lvl)
        {
            mep_index = mep_down_info[chan_rslt.down_min_valid_lvl].mep_index;
            mep_en = TRUE;
            low_level_up_lm_disable = TRUE;
        }
        else if (oam_level <= chan_rslt.up_max_valid_lvl) /* High level cross Connect */
        {
            mep_index = mep_up_info[chan_rslt.up_max_valid_lvl].mep_index;
            mep_en = TRUE;
            low_level_discard_en = TRUE;
        }
    }
    else if ((OAM_ACH == rx_oam_type) && pkt_info->mpls_mep_check && !link_or_section_oam
            && !pkt_info->from_cpu_or_oam && !pkt_info->discard)
    {/*mpls label oam*/
        oam_dest_chip_id  = pkt_info->mpls_oam_dest_chipid;
        mep_index         = pkt_info->mpls_mep_index;
        mep_en = TRUE;
        dm_en             = is_mpls_1dm_packet || is_mpls_2dm_packet;
    }
    else if (oam_result_valid && (rx_oam_type != OAM_NONE) && !pkt_info->from_cpu_or_oam && !pkt_info->discard)
    {/*mpls bfd and other oam*/
        p_ds_mpls_pbt_bfd_oam_chan  = ds_oam_chan;
        oam_dest_chip_id  = p_ds_mpls_pbt_bfd_oam_chan->oam_dest_chip_id;
        mep_index         = p_ds_mpls_pbt_bfd_oam_chan->mep_index;
        mep_en = TRUE;
        dm_en             = is_mpls_1dm_packet || is_mpls_2dm_packet;
    }

    /*LM Process*/
    /*LM decision(per traffic class in-profile, 100% losses within loss-of-continuty)*/
    is_mpls_oam     = (L4_TYPE_ACH_OAM == parser_result->layer4_type);
    is_mpls_ach_lm  = (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_DLM)
                        || (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_DLMDM);
    is_mpls_ach_lm_or_dm =  (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_DLM)
                        || (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_DM)
                        || (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_DLMDM)
                        || (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_ILM)
                        || (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_ILMDM);
    is_mpls_ach_dm = (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_DM)
                        || (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_DLMDM)
                        || (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_ILMDM);
    is_mpls_y1731_oam = (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_Y1731);
    is_mpls_y1731_aps_or_ccm = (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_APS)
                                || (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_CCM);
    is_mpls_y1731_aps =  (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_APS);
    is_mpls_y1731_ccm =  (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_CCM);
    is_mpls_y1731_lmm_or_lmr = (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_LMM)
                                || (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_LMR);
    is_mpls_y1731_lmm =   (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_LMM);
    is_mpls_y1731_lmr =   (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_LMR);

    is_mpls_y1731_lbm = (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_LBM);
    is_mpls_y1731_ltm = (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_LTM);

    mpls_lm_valid = (LM_MPLS == pkt_info->lm_lookup_type);

    is_single_lm0 = (LM_TYPE_SINGLE == lm_info.lm_type[0]);
    is_single_lm1 = (LM_TYPE_SINGLE == lm_info.lm_type[1]);
    is_single_lm2 = (LM_TYPE_SINGLE == lm_info.lm_type[2]);
    is_dual_lm0   = (LM_TYPE_DUAL == lm_info.lm_type[0]);
    is_dual_lm1   = (LM_TYPE_DUAL == lm_info.lm_type[1]);
    is_dual_lm2   = (LM_TYPE_DUAL == lm_info.lm_type[2]);

    lm_mpls_data_packet = (L4_TYPE_ACH_OAM != parser_result->layer4_type);
    lm_mpls_oam_packet0 = is_mpls_oam && is_mpls_y1731_oam && ipe_oam_ctl.lm_proactive_mpls_oam_packet
                            && ((is_single_lm0 && is_mpls_y1731_aps_or_ccm) || (is_dual_lm0 && is_mpls_y1731_aps));
    lm_mpls_oam_packet1 = is_mpls_oam && is_mpls_y1731_oam && ipe_oam_ctl.lm_proactive_mpls_oam_packet
                            && ((is_single_lm1 && is_mpls_y1731_aps_or_ccm) || (is_dual_lm1 && is_mpls_y1731_aps));
    lm_mpls_oam_packet2 = is_mpls_oam && is_mpls_y1731_oam && ipe_oam_ctl.lm_proactive_mpls_oam_packet
                            && ((is_single_lm2 && is_mpls_y1731_aps_or_ccm) || (is_dual_lm2 && is_mpls_y1731_aps));

    lm_cos_match0 = (compared_lm_cos[0] == lm_info.lm_cos[0]) || (LM_COS_TYPE_SPECIFIED_COS != lm_info.lm_cos_type[0]);
    lm_cos_match1 = (compared_lm_cos[1] == lm_info.lm_cos[1]) || (LM_COS_TYPE_SPECIFIED_COS != lm_info.lm_cos_type[1]);
    lm_cos_match2 = (compared_lm_cos[2] == lm_info.lm_cos[2]) || (LM_COS_TYPE_SPECIFIED_COS != lm_info.lm_cos_type[2]);

    is_mpls_lm_packet0 = mpls_lm_valid && lm_info.valid[0] &&
                        (lm_mpls_data_packet || lm_mpls_oam_packet0 || (0 != pkt_info->oam_lookup_num)) &&
                        lm_cos_match0;
    is_mpls_lm_packet1 = mpls_lm_valid && lm_info.valid[1] &&
                        (lm_mpls_data_packet || lm_mpls_oam_packet1 || (1 != pkt_info->oam_lookup_num)) &&
                        lm_cos_match1;
    is_mpls_lm_packet2 = mpls_lm_valid && lm_info.valid[2] &&
                        (lm_mpls_data_packet || lm_mpls_oam_packet2 || (2 != pkt_info->oam_lookup_num)) &&
                        lm_cos_match2;

    is_ether_oam = (L3_TYPE_ETHEROAM == parser_result->layer3_type);
    is_ether_oam_aps = (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_APS);
    is_ether_oam_ccm = (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_CCM);
    is_ether_oam_aps_or_ccm = ((parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_APS)||
                                (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_CCM));
    is_ether_oam_lmm_or_lmr = ((parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_LMM) ||
                                (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_LMR));
    is_ether_oam_lmm = (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_LMM);
    is_ether_oam_lmr = (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_LMR);
    ether_lm_valid = (LM_ETHER == pkt_info->lm_lookup_type);

    is_ether_oam_equal_level0 = (parser_result->l3_s.ip_da.eth_oam.eth_oam_level == lm_info.lm_level[0]);
    is_ether_oam_equal_level1 = (parser_result->l3_s.ip_da.eth_oam.eth_oam_level == lm_info.lm_level[1]);
    is_ether_oam_equal_level2 = (parser_result->l3_s.ip_da.eth_oam.eth_oam_level == lm_info.lm_level[2]);

    lm_ether_oam_packet0  = is_ether_oam && is_ether_oam_equal_level0 &&
                            ((is_single_lm0 && is_ether_oam_aps_or_ccm) || (is_dual_lm0 && is_ether_oam_aps))&&
                            ipe_oam_ctl.lm_proactive_ether_oam_packet;

    lm_ether_oam_packet1  = is_ether_oam && is_ether_oam_equal_level1 &&
                            ((is_single_lm1 && is_ether_oam_aps_or_ccm) || (is_dual_lm1 && is_ether_oam_aps))&&
                            ipe_oam_ctl.lm_proactive_ether_oam_packet;
    lm_ether_oam_packet2  = is_ether_oam && is_ether_oam_equal_level2 &&
                            ((is_single_lm2 && is_ether_oam_aps_or_ccm) || (is_dual_lm2 && is_ether_oam_aps))&&
                            ipe_oam_ctl.lm_proactive_ether_oam_packet;

    is_ether_lm_packet0   = ether_lm_valid && lm_info.valid[0] &&     /* ETHERNET LM Enabled */
                            (!is_ether_oam || lm_ether_oam_packet0 || /* data or specified OAM */
                            (parser_result->l3_s.ip_da.eth_oam.eth_oam_level > lm_info.lm_level[0])) && /* high level OAM packet */
                            lm_cos_match0;  /* Match CoS */
    is_ether_lm_packet1   = ether_lm_valid && lm_info.valid[1] &&
                            (!is_ether_oam || lm_ether_oam_packet1 ||
                            (parser_result->l3_s.ip_da.eth_oam.eth_oam_level > lm_info.lm_level[1])) &&
                            lm_cos_match1;
    is_ether_lm_packet2   = ether_lm_valid && lm_info.valid[2] &&
                            (!is_ether_oam || lm_ether_oam_packet2 ||
                            (parser_result->l3_s.ip_da.eth_oam.eth_oam_level > lm_info.lm_level[2])) &&
                            lm_cos_match2;

    lm_stats_en0 = (is_mpls_lm_packet0 || is_ether_lm_packet0) &&
                    ((COLOR_GREEN == pkt_info->new_color) || !ipe_oam_ctl.lm_green_packet);
    lm_stats_en1 = (is_mpls_lm_packet1 || is_ether_lm_packet1) &&
                    ((COLOR_GREEN == pkt_info->new_color) || !ipe_oam_ctl.lm_green_packet);
    lm_stats_en2 = (is_mpls_lm_packet2 || is_ether_lm_packet2) &&
                    ((COLOR_GREEN == pkt_info->new_color) || !ipe_oam_ctl.lm_green_packet);

    lm_index0 = lm_info.lm_index_base[0] + ((lm_info.lm_cos_type[0] != LM_COS_TYPE_PER_COS) ? 0 : compared_lm_cos[0]);
    lm_stats_ptr0 = lm_index0;
    lm_index1 = lm_info.lm_index_base[1] + ((lm_info.lm_cos_type[1] != LM_COS_TYPE_PER_COS) ? 0 : compared_lm_cos[1]);
    lm_stats_ptr1 = lm_index1;
    lm_index2 = lm_info.lm_index_base[2] + ((lm_info.lm_cos_type[2] != LM_COS_TYPE_PER_COS) ? 0 : compared_lm_cos[2]);
    lm_stats_ptr2 = lm_index2;

    discard_type = pkt_info->discard_type;
    if (!pkt_info->discard && pkt_info->storm_ctl_drop)
    {
        discard_type = IPE_DISCARD_STORM_CTL_DISCARD;
    }
    else if (!pkt_info->discard && pkt_info->mark_drop)
    {
        discard_type = IPE_DISCARD_POLICING_DISCARD;
    }

    if (pkt_info->exception2_lm_en)
    {
        discard_down_lm_en = ipe_oam_ctl.exception2_discard_down_lm_en;
        discard_up_lm_en = ipe_oam_ctl.exception2_discard_up_lm_en;
    }
    else
    {
        if (discard_type < 32)
        {
            discard_down_lm_en = IS_BIT_SET(ipe_oam_ctl.discard_down_lm_en31_0, discard_type);
            discard_up_lm_en = IS_BIT_SET(ipe_oam_ctl.discard_up_lm_en31_0, discard_type);
        }
        else
        {
            discard_down_lm_en = IS_BIT_SET(ipe_oam_ctl.discard_down_lm_en63_32, discard_type);
            discard_up_lm_en = IS_BIT_SET(ipe_oam_ctl.discard_up_lm_en63_32, discard_type);
        }
    }

    if (discard_type < 32)
    {
        discard_mpls_lm_en = IS_BIT_SET(ipe_oam_ctl.discard_mpls_lm_en31_0, discard_type);
    }
    else
    {
        discard_mpls_lm_en = IS_BIT_SET(ipe_oam_ctl.discard_mpls_lm_en63_32, discard_type);
    }


    if (lm_stats_en0)/*RAM1 for 0~127, RAM 1 for 128~255, RAM 2 for 256~383*/
    {
        LM_CMD_READ(chip_id, lm_stats_ptr0, cmd, ds_oam_lm_stats);

        if (LM_MPLS == pkt_info->lm_lookup_type)
        {
            if (!pkt_info->discard || discard_mpls_lm_en)
            {
                if (mpls_lm_type[0])
                {
                    ds_oam_lm_stats.rx_fcl_r++;/*rxp[31:0]*/
                    if (ds_oam_lm_stats.rx_fcl_r == 0) /*overflow*/
                    {
                        ds_oam_lm_stats.rx_fcb_r++;/*rxp[63:32]*/
                    }
                }
                else
                {
                    ds_oam_lm_stats.rx_fcl++;
                }
            }
        }
        else if (lm_info.is_up[0])
        {
            if(((!pkt_info->exception2_lm_en && (!pkt_info->discard || discard_up_lm_en))
                || (pkt_info->exception2_lm_en && pkt_info->exception2_lm_up_en && (!pkt_info->discard || discard_up_lm_en)))
                && (!mep_en && !low_level_up_lm_disable && !pkt_info->ether_oam_discard))
            {
                ds_oam_lm_stats.tx_fcl++;
            }
        }
        else if (((pkt_info->link_lm_type != LM_TYPE_NONE) && (!pkt_info->discard || ipe_oam_ctl.discard_link_lm_en)) /* link LM */
            || ((pkt_info->link_lm_type == LM_TYPE_NONE)                                                    /* down LM */
                && ((!pkt_info->exception2_lm_en && (!pkt_info->discard || discard_down_lm_en)) /* non exception2 */
                    || (pkt_info->exception2_lm_en && pkt_info->exception2_lm_down_en            /* exception2 */
                        && (!pkt_info->discard || discard_down_lm_en)))))
        {
            ds_oam_lm_stats.rx_fcl++;
        }

        LM_CMD_WRITE(chip_id, lm_stats_ptr0, cmd, ds_oam_lm_stats);
    }

    if (lm_stats_en1)
    {
        LM_CMD_READ(chip_id, lm_stats_ptr1, cmd, ds_oam_lm_stats);

        if (LM_MPLS == pkt_info->lm_lookup_type)
        {
            if (!pkt_info->discard || discard_mpls_lm_en)
            {
                if (mpls_lm_type[1])
                {
                    ds_oam_lm_stats.rx_fcl_r++;/*rxp[31:0]*/
                    if (ds_oam_lm_stats.rx_fcl_r == 0) /*overflow*/
                    {
                        ds_oam_lm_stats.rx_fcb_r++;/*rxp[63:32]*/
                    }
                }
                else
                {
                    ds_oam_lm_stats.rx_fcl++;
                }
            }
        }
        else if (lm_info.is_up[1])
        {
            if(((!pkt_info->exception2_lm_en && (!pkt_info->discard || discard_up_lm_en))
                || (pkt_info->exception2_lm_en && pkt_info->exception2_lm_up_en && (!pkt_info->discard || discard_up_lm_en)))
                && (!mep_en && !low_level_up_lm_disable && !pkt_info->ether_oam_discard))
            {
                ds_oam_lm_stats.tx_fcl++;
            }
        }
        else if ((!pkt_info->exception2_lm_en && (!pkt_info->discard || discard_down_lm_en))
            || (pkt_info->exception2_lm_en && pkt_info->exception2_lm_down_en && (!pkt_info->discard || discard_down_lm_en)))
        {
            ds_oam_lm_stats.rx_fcl++;
        }

        LM_CMD_WRITE(chip_id, lm_stats_ptr1, cmd, ds_oam_lm_stats);
    }

    if (lm_stats_en2)
    {
        LM_CMD_READ(chip_id, lm_stats_ptr2, cmd, ds_oam_lm_stats);

        if (LM_MPLS == pkt_info->lm_lookup_type)
        {
            if(!pkt_info->discard || discard_mpls_lm_en)
            {
                if (mpls_lm_type[2])
                {
                    ds_oam_lm_stats.rx_fcl_r++;/*rxp[31:0]*/
                    if (ds_oam_lm_stats.rx_fcl_r == 0) /*overflow*/
                    {
                        ds_oam_lm_stats.rx_fcb_r++;/*rxp[63:32]*/
                    }
                }
                else
                {
                    ds_oam_lm_stats.rx_fcl++;
                }
            }
        }
        else if (lm_info.is_up[2])
        {
            if(((!pkt_info->exception2_lm_en && (!pkt_info->discard || discard_up_lm_en))
                || (pkt_info->exception2_lm_en && pkt_info->exception2_lm_up_en && (!pkt_info->discard || discard_up_lm_en)))
            && (!mep_en && !low_level_up_lm_disable && !pkt_info->ether_oam_discard))
            {
                ds_oam_lm_stats.tx_fcl++;
            }
        }
        else if ((!pkt_info->exception2_lm_en && (!pkt_info->discard || discard_down_lm_en))
            || (pkt_info->exception2_lm_en && pkt_info->exception2_lm_down_en && (!pkt_info->discard || discard_down_lm_en)))
        {
            ds_oam_lm_stats.rx_fcl++;
        }

        LM_CMD_WRITE(chip_id, lm_stats_ptr2, cmd, ds_oam_lm_stats);
    }

    if (is_ether_oam)/*ETHERNET OAM*/
    {
        if (lm_info.valid[0] && ((is_dual_lm0 && is_ether_oam_ccm) || (is_single_lm0 && is_ether_oam_lmm_or_lmr)) &&
            is_ether_oam_equal_level0 && lm_cos_match0 )/*level & COS match 0*/
        {
            ether_lm_enable = TRUE;
            lm_ptr_num = 0;
        }
        else if (lm_info.valid[1] && ((is_dual_lm1 && is_ether_oam_ccm) || (is_single_lm1 && is_ether_oam_lmm_or_lmr)) &&
            is_ether_oam_equal_level1 && lm_cos_match1 )/*level & COS match 1*/
        {
            ether_lm_enable = TRUE;
            lm_ptr_num = 1;
        }
        else if (lm_info.valid[2] && ((is_dual_lm2 && is_ether_oam_ccm) || (is_single_lm2 && is_ether_oam_lmm_or_lmr)) &&
            is_ether_oam_equal_level2 && lm_cos_match2 )/*level & COS match 2*/
        {
            ether_lm_enable = TRUE;
            lm_ptr_num = 2;
        }
    }


    if (pkt_info->is_mpls_packet && is_mpls_oam)/*MPLS ACHOAM*/
    {
        if (lm_info.valid[0] && ((is_dual_lm0 && is_mpls_y1731_oam && is_mpls_y1731_ccm)
            ||(is_single_lm0 && ((is_mpls_y1731_oam && is_mpls_y1731_lmm_or_lmr) || is_mpls_ach_lm)))
            && (0 == pkt_info->oam_lookup_num) && lm_cos_match0)
        {
            mpls_lm_enable = TRUE;
            lm_ptr_num = 0;
            pkt_info->source_cos = compared_lm_cos[0]; /* For section LBM/LBR in OAM engine */
        }
        else if (lm_info.valid[1] && ((is_dual_lm1 && is_mpls_y1731_oam && is_mpls_y1731_ccm)
            ||(is_single_lm1 && ((is_mpls_y1731_oam && is_mpls_y1731_lmm_or_lmr) || is_mpls_ach_lm)))
            && (1 == pkt_info->oam_lookup_num) && lm_cos_match1)
        {
            mpls_lm_enable = TRUE;
            lm_ptr_num = 1;
            pkt_info->source_cos = compared_lm_cos[1];
        }
        else if (lm_info.valid[2] && ((is_dual_lm2 && is_mpls_y1731_oam && is_mpls_y1731_ccm)
            ||(is_single_lm2 && ((is_mpls_y1731_oam && is_mpls_y1731_lmm_or_lmr) || is_mpls_ach_lm)))
            && (2 == pkt_info->oam_lookup_num) && lm_cos_match2)
        {
            mpls_lm_enable = TRUE;
            lm_ptr_num = 2;
            pkt_info->source_cos = compared_lm_cos[2];
        }
    }

    if ((ether_lm_enable && is_ether_oam_ccm) || (mpls_lm_enable && is_mpls_y1731_oam && is_mpls_y1731_ccm))
    {
        pkt_info->lm_packet_type = IPE_LM_PACKET_TYPE_LM_CCM;/* LM CCM */
    }
    else if ((ether_lm_enable && is_ether_oam_lmm) || (mpls_lm_enable && is_mpls_y1731_oam && is_mpls_y1731_lmm))
    {
        pkt_info->lm_packet_type = IPE_LM_PACKET_TYPE_LMM;/* LMM */
    }
    else if ((ether_lm_enable && is_ether_oam_lmr) || (mpls_lm_enable && is_mpls_y1731_oam && is_mpls_y1731_lmr))
    {
        pkt_info->lm_packet_type = IPE_LM_PACKET_TYPE_LMR;/* LMR */
    }
    else if (mpls_lm_enable && is_mpls_ach_lm )
    {
        pkt_info->lm_packet_type = IPE_LM_PACKET_TYPE_LM_ACH;/* LM ACH */
    }
    else
    {
        pkt_info->lm_packet_type = IPE_LM_PACKET_TYPE_LM_NONE;/* NO LM */
    }


    if((IPE_LM_PACKET_TYPE_LM_NONE != pkt_info->lm_packet_type))
    {
        if (0 == lm_ptr_num)
        {
            LM_CMD_READ(chip_id, lm_stats_ptr0, cmd, ds_oam_lm_stats);
        }
        else if (1 == lm_ptr_num)
        {
            LM_CMD_READ(chip_id, lm_stats_ptr1, cmd, ds_oam_lm_stats);
        }
        else if (2 == lm_ptr_num)
        {
            LM_CMD_READ(chip_id, lm_stats_ptr2, cmd, ds_oam_lm_stats);
        }
    }

    if (pkt_info->from_cpu_or_oam && (IPE_LM_PACKET_TYPE_LM_CCM == pkt_info->lm_packet_type))
    {
        /*OAM send CCM with LM*/
        pkt_info->share_type = SHARE_TYPE_LMTX;                            /*EPE Edit LM packet*/
        /* PacketInfo.shareField[79:0] */
        pkt_info->share_fields_u.lmtx.lm_packet_type = pkt_info->lm_packet_type;
        pkt_info->share_fields_u.lmtx.rxtx_fcl = ds_oam_lm_stats.tx_fcl;     /*local counter TxFcl when TX*/
        pkt_info->share_fields_u.lmtx.rx_fcb = ds_oam_lm_stats.rx_fcl_r;   /*local counter rxFcl last RX*/
        pkt_info->share_fields_u.lmtx.tx_fcb = ds_oam_lm_stats.tx_fcf_r;   /*packet's TxFcf last RX*/
    }
    else if (pkt_info->from_cpu_or_oam && (IPE_LM_PACKET_TYPE_LMM == pkt_info->lm_packet_type))
    {
        /*OAM/CPU originate LMM, IPE/EPE read tx_fcl and write into TxFcf of LMM packet*/
        pkt_info->share_type = SHARE_TYPE_LMTX;
        /* PacketInfo.shareField[79:0] */
        pkt_info->share_fields_u.lmtx.lm_packet_type = pkt_info->lm_packet_type;
        pkt_info->share_fields_u.lmtx.rxtx_fcl = ds_oam_lm_stats.tx_fcl;
        /*add by yongchao sync with RTL*/
        pkt_info->share_fields_u.lmtx.tx_fcb =0;
        pkt_info->share_fields_u.lmtx.rx_fcb =0;
    }
    else if (pkt_info->from_cpu_or_oam && (IPE_LM_PACKET_TYPE_LMR == pkt_info->lm_packet_type))
    {
        /*OAM/CPU generate LMR, IPE/EPE read tx_fcl and write into TxFcb of LMR packet*/
        pkt_info->share_type = SHARE_TYPE_LMTX;
        /* PacketInfo.shareField[79:0] */
        pkt_info->share_fields_u.lmtx.lm_packet_type = pkt_info->lm_packet_type;
        pkt_info->share_fields_u.lmtx.rxtx_fcl = ds_oam_lm_stats.tx_fcl;
        /*add by yongchao sync with RTL*/
        pkt_info->share_fields_u.lmtx.tx_fcb =0;
        pkt_info->share_fields_u.lmtx.rx_fcb =0;
    }
    else if ((!pkt_info->from_cpu_or_oam) && (IPE_LM_PACKET_TYPE_LM_CCM == pkt_info->lm_packet_type))
    {
        /*receive LM CCM*/
        /* PacketInfo.shareField[79:0] */
        lm_received_packet = TRUE;

        ds_oam_lm_stats.tx_fcf_r = parser_result->l3_s.ip_sa.eth_oam.tx_fcf;
        ds_oam_lm_stats.rx_fcb_r = parser_result->l3_s.ip_sa.eth_oam.rx_fcb;
        ds_oam_lm_stats.tx_fcb_r = parser_result->l3_s.ip_sa.eth_oam.tx_fcb;
        ds_oam_lm_stats.rx_fcl_r = ds_oam_lm_stats.rx_fcl;

        if (0 == lm_ptr_num)
        {
            LM_CMD_WRITE(chip_id, lm_stats_ptr0, cmd, ds_oam_lm_stats);
        }
        else if (1 == lm_ptr_num)
        {
            LM_CMD_WRITE(chip_id, lm_stats_ptr1, cmd, ds_oam_lm_stats);
        }
        else if (2 == lm_ptr_num)
        {
            LM_CMD_WRITE(chip_id, lm_stats_ptr2, cmd, ds_oam_lm_stats);
        }
    }
    else if ((!pkt_info->from_cpu_or_oam) && (IPE_LM_PACKET_TYPE_LMM == pkt_info->lm_packet_type))
    {
        /*IPE read rxFcl and send to OAM/CPU to Generate LMR,OAM/CPU write RxFCI as RxFCf*/
        /* PacketInfo.shareField[79:0] */
        lm_received_packet = TRUE;
        rxtx_fcl = ds_oam_lm_stats.rx_fcl;
        rx_fcb = 0;
    }
    else if ((!pkt_info->from_cpu_or_oam) && (IPE_LM_PACKET_TYPE_LMR == pkt_info->lm_packet_type))
    {
        /*IPE read rxFcl and send to OAM/CPU for calculating*/
        /* PacketInfo.shareField[79:0] */
        lm_received_packet = TRUE;
        rxtx_fcl = ds_oam_lm_stats.rx_fcl;
        rx_fcb = 0;
    }
    else if ((!pkt_info->from_cpu_or_oam) && (IPE_LM_PACKET_TYPE_LM_ACH == pkt_info->lm_packet_type))
    {
        /* PacketInfo.shareField[79:0] */
        lm_received_packet = TRUE;

        if (IS_BIT_SET(parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_flag, 3)) /*64 bits counter*/
        {
            rx_fcb = ds_oam_lm_stats.rx_fcb_r;
            rxtx_fcl = ds_oam_lm_stats.rx_fcl_r;
        }
        else /*32 bit counter*/
        {
            rxtx_fcl = ds_oam_lm_stats.rx_fcl_r;  /*rxp[31:0]*/
            rx_fcb = 0;
        }
    }

    /*RX OAM TYPE*/
    /* ETHER MIP decision, MAC DA, etc check in OAM Engine */
    if (OAM_ETHER == rx_oam_type)
    {
        if (oam_result_valid && IS_BIT_SET((oam_chan_info->mip_bitmap << 1), parser_result->l3_s.ip_da.eth_oam.eth_oam_level)
                && (((OAM_OP_LBM == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code) && pkt_info->is_port_mac)
                || (OAM_OP_LTM == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code)))
        {
            mip_en = TRUE;
            oam_dest_chip_id = p_ds_eth_oam_chan->oam_dest_chip_id;
        }
    }
    else if (OAM_ACH == rx_oam_type)
    {
        if (!pkt_info->mpls_mep_check && ((is_mpls_y1731_oam && ((pkt_info->is_mpls_ttl_one
            && is_mpls_y1731_lbm) || is_mpls_y1731_ltm)) || (is_mpls_ach_lm_or_dm && pkt_info->is_mpls_ttl_one)))
        {
            mip_en = TRUE;
            dm_en = is_mpls_ach_dm;
            oam_dest_chip_id = pkt_info->mpls_oam_dest_chipid;
        }

    }

    /*oam hash lookup conflict*/
    if (!mep_en && !mip_en && oam_hash_conflict && (OAM_NONE != rx_oam_type)
        && !pkt_info->from_cpu_or_oam)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_OAM_NOT_FOUND_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! OAM IPE_DISCARD_OAM_NOT_FOUND!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }

        if (ipe_oam_ctl.oam_hash_conflict_exception_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_OAM_HASH_CONFLICT;
        }
    }
    else if (OAM_ETHER == rx_oam_type)
    {
        if ((!mep_en || low_level_discard_en) && !mip_en
            && pkt_info->ether_oam_edge_port && !pkt_info->from_cpu_or_oam) /* first check down mep cross connect */
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_OAM_NOT_FOUND_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! OAM IPE_DISCARD_OAM_NOT_FOUND!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if ((!mep_en || (low_level_discard_en && ipe_oam_ctl.low_level_oam_filtering_en)) && !mip_en
            && pkt_info->ether_oam_discard)  /* second check filtering */
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_OAM_STP_VLAN_FILTER_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! OAM Filtering check failed!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (!mep_en && !mip_en)  /* third check high level */
        {
            rx_oam_type = OAM_NONE;
        }
    }
    else if (OAM_NONE != rx_oam_type)
    {
        if ((OAM_IP_BFD == rx_oam_type) && oam_result_valid && p_ds_mpls_pbt_bfd_oam_chan->bfd_single_hop
             && !pkt_info->bfd_single_hop_ttl_match)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_BFD_SINGLE_HOP_OAM_TTL_CHK_ERR;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! IPE_DISCARD_BFD_SINGLE_HOP_OAM_TTL_CHK_ERR!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (!mip_en && (OAM_ACH == rx_oam_type) && !pkt_info->mpls_mep_check)
        {
            rx_oam_type = OAM_NONE;
            pkt_info->payload_offset = pkt_info->payload_offset - (pkt_info->mpls_extra_payload_offset << 2);
        }
        else if (!mep_en && !mip_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_NO_MEP_MIP_DIS;  /* no MEP/MIP discard,TRILL BFD/MPLS,etc */

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_NO_MEP_MIP_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! IPE_DISCARD_NO_MEP_MIP_DISCARD!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    if (pkt_info->share_type == SHARE_TYPE_DMTX)
    {/* s+ ns */
        uint32 msb = 0;
        uint32 lsb = 0;
        GET_PTP_ENGINE_TIMESTAMP(PTP_ENGINE_ACCESS_IPE_OAM, FALSE, &msb, &lsb);
        pkt_info->share_fields_u.dmtx.time_stamp_61_32 = (msb >> 2);
        pkt_info->share_fields_u.dmtx.time_stamp_31_0 = ((msb&0x3) << 30)| (lsb&0x3FFFFFFF);
    }

    /* discard reset mepEn/mipEn,etc */
    else if (OAM_TYPE_NONE != rx_oam_type)
    {
        pkt_info->share_type = SHARE_TYPE_OAM;
        pkt_info->share_fields_u.oam.oam_dest_chip_id = oam_dest_chip_id;
        pkt_info->share_fields_u.oam.mip_en = mip_en;
        pkt_info->share_fields_u.oam.mep_index = mep_index;
        pkt_info->share_fields_u.oam.rx_oam_type = rx_oam_type;
        pkt_info->share_fields_u.oam.link_or_section_oam = pkt_info->link_or_section_OAM;
        pkt_info->share_fields_u.oam.lm_received_packet = lm_received_packet;
        pkt_info->share_fields_u.oam.gal_exist = gal_exist;
        pkt_info->share_fields_u.oam.entropy_label_exist = entropy_label_exist;
        pkt_info->share_fields_u.oam.dm_en = dm_en;
        pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 = rxtx_fcl;
        pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32 = rx_fcb;

        if (dm_en)
        {
            pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32 = timestamp.high_63_32;
            pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 = timestamp.low_31_0;
        }
    }

    return DRV_E_NONE;
}

