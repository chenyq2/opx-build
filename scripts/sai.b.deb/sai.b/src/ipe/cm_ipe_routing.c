/****************************************************************************
 * cm_ipe_routing.c: Provides IPE routing handle function.
 * Copyright:       (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Version:        V1.0.
 * Author:         JiangJf
 * Date:           2010-10-08.
 * Reason:         First Create.
 *
 * Modify History:
 * Reversion:      V1.01
 * Author:         XuZx
 * Date:           2010-11-15.
 * Reason:         Revise for first formal spec.
 *
 * Reversion:      V1.02
 * Author:         XuZx
 * Date:           2010-11-23.
 * Reason:         Revise for second formal spec.
 *
 * Reversion:      V4.2
 * Author:         Jiangsz
 * Date:           2011-07-04.
 * Reason:         sync spec V4.2.1.
 *
 * Reversion:      V4.29.0
 * Author:         wangcy
 * Date:           2011-10-08.
 * Reason:         sync spec V4.29.0.
 *
 * Revision:       V5.1.0
 * Author:         Wangcy.
 * Date:           2011-12-12.
 * Reason:         sync spec v5.1.0.
 *
 * Revision:       V5.6.0
 * Author:         Wangcy.
 * Date:           2012-01-07.
 * Reason:         sync spec v5.6.0.
 *
 * Revision:       V5.7.0
 * Author:         Wangcy.
 * Date:           2012-01-17.
 * Reason:         sync spec v5.7.0.
 *
 * Reversion:      V5.11.0
 * Author:         ZhouW
 * Date:           2012-03-01.
 * Reason:         sync spec v5.11.0.
 *
 * Reversion:      V5.13.0
 * Author:         Wangcy
 * Date:           2012-03-12.
 * Reason:         sync spec v5.13.0.
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "ctcutil_rand.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
****************************************************************************/
#define L3_IF_TYPE_EXTERNAL    0
#define L3_IF_TYPE_INTERNAL    1

struct ipe_route_dest_info_e
{
    uint8 chip_id;
    uint8 use_ip_sa_fwd_ptr;
    ds_ip_da_t *ds_ip_da;
    ds_ip_sa_nat_t *ds_ip_sa_nat;
    uint8* routing_escape   ;
    uint8* routing_escape_case ;
    uint8 ip_sa_result_valid;
};
typedef struct ipe_route_dest_info_e ipe_route_dest_info_t;

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/

/****************************************************************************
 * Name:       _cm_ipe_routing_destination
 * Purpose:    ipe routing destination sub-routine
 * Parameters:
 * Input:      ipe_route_destination_info pointer
 *
 * Output:     routing_escape_case  -- routing escape case
 *             routing_escape       -- if escape routing
 *
 * Return:     DRV_E_NONE  -- success.
 *             Other       -- Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32 _cm_ipe_routing_destination(ipe_packet_info_t *pkt_info,
                                                ipe_route_dest_info_t* p_dest_info)
{
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    ds_ip_da_t* ds_ip_da = p_dest_info->ds_ip_da;
    ipe_route_ctl_t ipe_route_ctl;
    ipe_ecmp_ctl_t ipe_ecmp_ctl;
    ds_ecmp_state_t ds_ecmp_state;
    ds_ecmp_group_t ds_ecmp_group;
    ipe_ecmp_channel_state_t ipe_ecmp_channel_state;

    uint32 cmd = 0;
    uint16 ds_fwd_ptr = 0;
    uint16 ds_ecmp_ptr = 0;
    uint8 equal_cost_path_num = 0, equal_cost_path_sel = 0;
    uint8 priority_path_en = 0;
    uint8 gre_options = 0;
    uint8 unknown_protocol = 0;
    uint8 dlb_en = FALSE;
    uint8 current_ts = 0;
    uint8 dest_channel[16] = {0};
    uint32 channel_class[16] = {0};
    uint8 ecmp_mem_num = 0;
    uint8 index = 0;
    uint8 max_channel_class = 0;
    uint8 max_channel_class_index_array[16] = {0};
    uint8 max_channel_class_count = 0;
    uint32 random = 0;

    sal_memset(&ipe_route_ctl, 0, sizeof(ipe_route_ctl));
    cmd = DRV_IOR(IpeRouteCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_dest_info->chip_id, 0, cmd, &ipe_route_ctl));

    sal_memset(&ipe_ecmp_ctl, 0, sizeof(ipe_ecmp_ctl));
    cmd = DRV_IOR(IpeEcmpCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_dest_info->chip_id, 0, cmd, &ipe_ecmp_ctl));

    if (p_dest_info->use_ip_sa_fwd_ptr)
    {
        /* ipSA[31:0]/{8'd0, priorityPathEn, equalCosPathNum[2:0],4'b0,dsFwdPtr[15:0]} */
        ds_fwd_ptr = p_dest_info->ds_ip_sa_nat->ip_sa16_0 & 0xFFFF;
        priority_path_en = IS_BIT_SET(p_dest_info->ds_ip_sa_nat->ip_sa30_23,6);/* used as priorityPathEn*/
        equal_cost_path_num = (p_dest_info->ds_ip_sa_nat->ip_sa30_23 >> 3) & 0x7;/* used as equalcostpathnum*/
        dlb_en = FALSE;
    }
    else
    {
        ds_fwd_ptr = ds_ip_da->ds_fwd_ptr;
        priority_path_en = ds_ip_da->priority_path_en;
        equal_cost_path_num = ds_ip_da->equal_cost_path_num2_0 | (ds_ip_da->equal_cost_path_num3_3 << 3);
        dlb_en = ds_ip_da->dlb_en;

        if (pkt_info->layer3_exception && ds_ip_da->exception3_ctl_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = pkt_info->layer3_exception_sub_index;
        }
        else if (ds_ip_da->ip_da_exception_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = (ipe_route_ctl.exception_sub_index << 5) | ds_ip_da->exception_sub_index;
        }

        if (pkt_info->exception_en && (EXCEPTION_TYPE_LAYER3 == pkt_info->exception_index)
            && !ipe_route_ctl.exception3_discard_disable)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_L3_EXCEPTION;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! IpeRouteCtl.exception3Discard control to drop!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    /* only one of layer3 and layer2 ECMP is valid */
    pkt_info->self_address = ds_ip_da->self_address;
    pkt_info->ds_fwd_ptr_valid = TRUE;
    if (ds_ip_da->next_hop_ptr_valid)
    {
        pkt_info->ds_fwd_ptr_valid = FALSE;
        pkt_info->next_hop_ptr_valid = TRUE;
        pkt_info->ad_next_hop_ptr = ds_ip_da->ds_fwd_ptr;  /* used as ad_next_hop_ptr */
        pkt_info->ad_dest_map = ds_ip_da->tunnel_gre_options  /* used as ad_dest_map[2:0] */
                              | (ds_ip_da->aps_select_valid << 3) /* used as ad_dest_map[3] */
                              | (ds_ip_da->payload_offset_type << 4) /* used as ad_dest_map[4] */
                              | (ds_ip_da->aps_select_group_id << 5) /* used as ad_dest_map[5] */
                              | (ds_ip_da->equal_cost_path_num2_0 << 6) /* used as ad_dest_map[8:6] */
                              | (ds_ip_da->equal_cost_path_num3_3 << 9) /* used as ad_dest_map[9] */
                              | (ds_ip_da->isatap_check_en << 10) /* used as ad_dest_map[10] */
                              | (ds_ip_da->tunnel_packet_type << 11) /* used as ad_dest_map[13:11] */
                              | (ds_ip_da->color << 14) /* used as ad_dest_map[15:14] */
                              | (ds_ip_da->priority << 16); /* used as ad_dest_map[21:16] */
        pkt_info->ad_length_adjust_type = IS_BIT_SET(ds_ip_da->tunnel_payload_offset, 3);/* used as lengthadjusttype */
        pkt_info->ad_critical_packet = IS_BIT_SET(ds_ip_da->tunnel_payload_offset, 2);/* used as criticalpacket */
        pkt_info->ad_next_hop_ext = IS_BIT_SET(ds_ip_da->tunnel_payload_offset, 1);/* used as nexthopext */
        pkt_info->ad_send_local_phy_port = IS_BIT_SET(ds_ip_da->tunnel_payload_offset, 0);/* used as sendLocalPhyPort */
        pkt_info->ad_aps_type = ds_ip_da->payload_select;  /* used as adApsType */
        pkt_info->ad_speed = ds_ip_da->ad_speed0_0 | (ds_ip_da->pt_enable << 1);  /* used as adApsType */
    }
    else if(priority_path_en)
    {
        pkt_info->ds_fwd_ptr = ds_fwd_ptr + pkt_info->priority_path_select;
    }
    else if(dlb_en)
    {
        switch(ipe_ecmp_ctl.ecmp_flow_num)
        {
            case 0:
                ds_ecmp_ptr = ((equal_cost_path_num & 0x3) << 8) | (parser_result->l3_s.ip_ecmp_hash & 0xFF);
                break;
            case 1:
                ds_ecmp_ptr = ((equal_cost_path_num & 0x7) << 7) | (parser_result->l3_s.ip_ecmp_hash & 0x7F);
                break;
            case 2:
                ds_ecmp_ptr = ((equal_cost_path_num & 0xF) << 6) | (parser_result->l3_s.ip_ecmp_hash & 0x3F);
                break;
            case 3:
                ds_ecmp_ptr = ((equal_cost_path_num & 0xF) << 5) | (parser_result->l3_s.ip_ecmp_hash & 0x1F);
                break;
            default:
                break;
        }

        sal_memset(&ds_ecmp_state, 0, sizeof(ds_ecmp_state));
        cmd = DRV_IOR(DsEcmpState_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_dest_info->chip_id, ds_ecmp_ptr, cmd, &ds_ecmp_state));

        /* ECMP bundle to same ports */
        sal_memset(&ds_ecmp_group, 0, sizeof(ds_ecmp_group));
        cmd = DRV_IOR(DsEcmpGroup_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_dest_info->chip_id, equal_cost_path_num, cmd, &ds_ecmp_group));

        /* flow active */
        if (ds_ecmp_state.active && ((current_ts - ds_ecmp_state.old_ts) < ipe_ecmp_ctl.ts_threshold))
        {
            pkt_info->ds_fwd_ptr = ds_ecmp_state.ds_fwd_ptr;
            ds_ecmp_state.old_ts = current_ts;
        }
        /* flow inactive */
        else
        {
            sal_memset(&ipe_ecmp_channel_state, 0, sizeof(ipe_ecmp_channel_state));
            cmd = DRV_IOR(IpeEcmpChannelState_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_dest_info->chip_id, 0, cmd, &ipe_ecmp_channel_state));

            dest_channel[0] = ds_ecmp_group.dest_channel0; dest_channel[1] = ds_ecmp_group.dest_channel1;
            dest_channel[2] = ds_ecmp_group.dest_channel2; dest_channel[3] = ds_ecmp_group.dest_channel3;
            dest_channel[4] = ds_ecmp_group.dest_channel4; dest_channel[5] = ds_ecmp_group.dest_channel5;
            dest_channel[6] = ds_ecmp_group.dest_channel6; dest_channel[7] = ds_ecmp_group.dest_channel7;

            for (index = 0; index < 8; index++)
            {
                cmd = DRV_IOR(IpeEcmpChannelState_t, (IpeEcmpChannelState_ChannelClass0_f + (dest_channel[index] & 0x3F)));
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_dest_info->chip_id, 0, cmd, &(channel_class[index])));
            }

            ecmp_mem_num = ds_ecmp_group.ecmp_mem_num;

            max_channel_class = channel_class[0];   /* store current max_channel_class */
            max_channel_class_index_array[0] = 0;   /* store index of all max_channel_class item */
            max_channel_class_count = 1;            /* max_channel_class item count */

            for (index = 1; index < ecmp_mem_num; index++)
            {
                if (channel_class[index] == max_channel_class)
                {
                    max_channel_class_index_array[max_channel_class_count] = index;
                    max_channel_class_count ++;
                }
                else if (channel_class[index] > max_channel_class)
                {
                    max_channel_class_index_array[0] = index;
                    max_channel_class_count = 1;
                }
            }

            if (1 == max_channel_class_count)
            {
                index = max_channel_class_index_array[0];
            }
            else
            {
                ctcutil_rand(0, 0x7FFF, &random); /* software random may be diffrent from ASIC */
                index = max_channel_class_index_array[random % max_channel_class_count];
            }

            switch (index)
            {
                case 0:
                    ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr0;
                    break;
                case 1:
                    ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr1;
                    break;
                case 2:
                    ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr2;
                    break;
                case 3:
                    ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr3;
                    break;
                case 4:
                    ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr4;
                    break;
                case 5:
                    ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr5;
                    break;
                case 6:
                    ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr6;
                    break;
                case 7:
                    ds_fwd_ptr = ds_ecmp_group.ds_fwd_ptr7;
                    break;
                default:
                    break;
            }

            ds_ecmp_state.ds_fwd_ptr = ds_fwd_ptr;
            pkt_info->ds_fwd_ptr = ds_fwd_ptr;
            ds_ecmp_state.old_ts = current_ts;
            ds_ecmp_state.active = TRUE;
        }

        /* write  ecmpstate back */
        cmd = DRV_IOW(DsEcmpState_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_dest_info->chip_id, ds_ecmp_ptr, cmd, &ds_ecmp_state));
    }
    else
    {
        switch (equal_cost_path_num)
        {
            case 0:
                equal_cost_path_sel = 0;
                break;
            case 1:
                equal_cost_path_sel = IS_BIT_SET(parser_result->l3_s.ip_ecmp_hash, 0);
                break;
            case 2:
                equal_cost_path_sel = parser_result->l3_s.ip_ecmp_hash % 3;
                break;
            case 3:
                equal_cost_path_sel = parser_result->l3_s.ip_ecmp_hash & 0x3;
                break;
            case 4:
                equal_cost_path_sel = parser_result->l3_s.ip_ecmp_hash % 5;
                break;
            case 5:
                equal_cost_path_sel = parser_result->l3_s.ip_ecmp_hash % 6;
                break;
            case 6:
                equal_cost_path_sel = parser_result->l3_s.ip_ecmp_hash % 7;
                break;
            case 7:
                equal_cost_path_sel = parser_result->l3_s.ip_ecmp_hash & 0x7;
                break;
            default:
                equal_cost_path_sel = parser_result->l3_s.ip_ecmp_hash & 0xF;
                break;
        }

        pkt_info->ds_fwd_ptr = ds_fwd_ptr + equal_cost_path_sel;
        pkt_info->ecmp_hash = parser_result->l3_s.ip_ecmp_hash;
    }

    if (!p_dest_info->use_ip_sa_fwd_ptr)
    {
        /* ======== bug 4667 ECO begine ========= */
        //if (!ds_ip_da->next_hop_ptr_valid && ds_ip_da->aps_select_valid)
        if (0)
        /* ======== bug 4667 ECO end ========= */
        {
            if (!pkt_info->aps_select_valid0)
            {
                /* share with aps_select_protecting_path */
                pkt_info->aps_select_protecting_path0 = ds_ip_da->icmp_check_en;
                /* share with aps_select_group_id */
                pkt_info->aps_select_group_id0 = (ds_ip_da->aps_select_group_id << 10) 
                                                |ds_ip_da->rpf_if_id;
                /* ===== bug 4614 ECO begine ==== */
                pkt_info->aps_select_valid0 = TRUE;
                /* ===== bug 4614 ECO end ==== */
            }
            else if (!pkt_info->aps_select_valid1)
            {
                /* share with aps_select_protecting_path */
                pkt_info->aps_select_protecting_path1 = ds_ip_da->icmp_check_en;
                /* share with aps_select_group_id */
                pkt_info->aps_select_group_id1 = (ds_ip_da->aps_select_group_id << 10) 
                                                |ds_ip_da->rpf_if_id;
                /* ===== bug 4614 ECO begine ==== */
                pkt_info->aps_select_valid1 = TRUE;
                /* ===== bug 4614 ECO end ==== */
            }
            else
            {
                /* share with aps_select_protecting_path */
                pkt_info->aps_select_protecting_path2 = ds_ip_da->icmp_check_en;
                /* share with aps_select_group_id */
                pkt_info->aps_select_group_id2 = (ds_ip_da->aps_select_group_id << 10) 
                                                |ds_ip_da->rpf_if_id;
                /* ===== bug 4614 ECO begine ==== */
                pkt_info->aps_select_valid2 = TRUE;
                /* ===== bug 4614 ECO end ==== */
            }
        }

        if ((OAM_IP_BFD == pkt_info->rx_oam_type) && (!ds_ip_da->self_address))
        {
            pkt_info->rx_oam_type = OAM_NONE;
        }
        else if (OAM_IP_BFD == pkt_info->rx_oam_type)
        {
            pkt_info->payload_offset = parser_result->l3_s.layer4_offset + 8;
            pkt_info->exception_en = FALSE;  /* move to IPEFwd for different rxOamType ??? */
        }

        if (!ds_ip_da->next_hop_ptr_valid && ds_ip_da->pt_enable)
        {
            if (ipe_route_ctl.ivi_use_da_info && ds_ip_da->deny_pbr)  /* used as iviEnable */
            {
                pkt_info->pt_enable = TRUE;
                pkt_info->src_address_mode = FALSE;
            }
            else if (p_dest_info->ip_sa_result_valid && (pkt_info->is_ipv4_ucast_nat || pkt_info->is_ipv6_ucast_nat))
            {
                 pkt_info->pt_enable = TRUE;
                 pkt_info->ipv4_src_embeded_mode = p_dest_info->ds_ip_sa_nat->ipv4_embeded_mode;
                 pkt_info->new_ip_sa = (p_dest_info->ds_ip_sa_nat->ip_sa31 << 31)
                                                               | (p_dest_info->ds_ip_sa_nat->ip_sa30_23 << 23)
                                                               | (p_dest_info->ds_ip_sa_nat->ip_sa22_21 << 21)
                                                               | (p_dest_info->ds_ip_sa_nat->ip_sa20_17 << 17)
                                                               | p_dest_info->ds_ip_sa_nat->ip_sa16_0;
                 pkt_info->new_ip_sa_39_32 = p_dest_info->ds_ip_sa_nat->ip_sa39_32;
                 pkt_info->ip_sa_mode = p_dest_info->ds_ip_sa_nat->ip_sa_mode;
                 pkt_info->src_address_mode = p_dest_info->ds_ip_sa_nat->src_address_mode;

                 if (2 == p_dest_info->ds_ip_sa_nat->ip_sa_mode)
                 {
                    pkt_info->ip_sa_prefix_length = p_dest_info->ds_ip_sa_nat->ip_sa_prefix_length;
                 }
             }
             else if (!pkt_info->discard)
             {
                pkt_info->discard_type = IPE_DISCARD_ROUTING_MCAST_IP_ADDR_CHK_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! discard type is %d\n", pkt_info->discard_type);
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
             }
        }

        if (pkt_info->pt_enable && pkt_info->is_icmp && !pkt_info->exception_en && ipe_route_ctl.pt_icmp_escape)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = (ipe_route_ctl.exception_sub_index << 5) | ds_ip_da->exception_sub_index;

            if (!pkt_info->discard)
             {
                pkt_info->discard_type = IPE_DISCARD_ICMP_ERR_MSG_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! discard type is %d\n", pkt_info->discard_type);
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
             }
        }

        if (!ds_ip_da->next_hop_ptr_valid)
        {
            switch (ds_ip_da->payload_select)
            {
                case 0:
                    if ((!pkt_info->is_decap) && (!pkt_info->is_mpls_switched))
                    {
                        pkt_info->payload_packet_type = pkt_info->packet_type;         /* original packet */
                    }
                    break;
                case 1:
                    pkt_info->payload_packet_type = PKT_TYPE_IPV4;                     /* send IP ,packettype =1 */
                    pkt_info->payload_offset = parser_result->l2_s.layer3_offset;
                    break;
                case 2:
                    pkt_info->payload_packet_type = ds_ip_da->tunnel_packet_type;      /*send tunnel*/
                    pkt_info->payload_offset
                        = (ds_ip_da->payload_offset_type ?
                                parser_result->l2_s.layer3_offset : parser_result->l3_s.layer4_offset) +
                                (ds_ip_da->tunnel_payload_offset<<ipe_route_ctl.offset_byte_shift);
                    break;
                case 3:
                    gre_options = (parser_result->l4_s.l4_src_port.gre_flags >> 12) & 0xF;/* send GRE tunnel */
                    unknown_protocol = pkt_info->unknown_gre_protocol;
                    if ((((IS_BIT_SET(gre_options, 3) << 2) + (gre_options & 0x3))
                            != ds_ip_da->tunnel_gre_options)
                        || unknown_protocol
                        || (IS_BIT_SET(gre_options, 2) && ipe_route_ctl.gre_option2_check_en))
                    {
                        /* UNKOWN GRE -- should send to CPU */
                        *(p_dest_info->routing_escape_case) = 2;
                        *(p_dest_info->routing_escape) = TRUE;
                        pkt_info->ds_fwd_ptr_valid = FALSE;
                    }
                    else
                    {
                        pkt_info->payload_packet_type = pkt_info->gre_payload_packet_type;
                        pkt_info->payload_offset
                            = (ds_ip_da->payload_offset_type ?
                                    parser_result->l2_s.layer3_offset : parser_result->l3_s.layer4_offset)
                                       + (ds_ip_da->tunnel_payload_offset<<ipe_route_ctl.offset_byte_shift);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    if (pkt_info->exception_en && (EXCEPTION_TYPE_LAYER2 == pkt_info->exception_index)
        && ipe_route_ctl.exception2_discard)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_L2_EXCEPTION;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! IpeRouteCtl.exception2Discard control to drop!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_ipe_routing_handle
 * Purpose:    IPE routing handle process.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing informations
 * Return:     DRV_E_NONE -- success.
 *             Other -- ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 cm_ipe_routing_handle(ipe_in_pkt_t* in_pkt)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    ds_ip_da_t* ds_ip_da = NULL;
    ds_ip_da_t* ds_ip_da_tcam = NULL;
    ds_ip_da_t* ds_ip_da_fib = NULL;
    ds_ip_da_t* ds_ip_da_rpf = NULL;
    ds_ip_da_t* ds_ip_sa_tcam = NULL;
    ds_ip_da_t* ds_ip_sa_fib = NULL;
    ds_ip_da_t* pbr_ds_ip_da = NULL;
    ds_ip_sa_nat_t* ds_ip_sa_nat = NULL;
    ds_ip_sa_nat_t *ds_ip_sa_nat_tcam = NULL;
    ds_ip_sa_nat_t *ds_ip_sa_nat_fib = NULL;

    uint8 chip_id = in_pkt->chip_id;
    uint8 routed_packet = FALSE;
    uint8 is_ipv4 = FALSE;
    uint8 is_ipv6 = FALSE;
    uint8 is_ucast = FALSE;
    uint8 is_mcast = FALSE;
    uint8 ip_header_error = FALSE;
    uint8 igmp_snooped_packet = FALSE;
    uint8 ip_options = FALSE;
    uint8 routing_escape = FALSE;
    uint8 routing_escape_case = 0;
    uint8 is_atap_check_ok = FALSE;
    uint8 rpf_check_ok = FALSE;
    uint8 nat_eligible = FALSE;
    uint8 use_ip_sa_fwd_ptr = FALSE;
    uint8 is_sa_nat = FALSE;
    uint8 ip_da_result_valid = FALSE;
    uint8 ip_sa_result_valid = FALSE;
    uint8 ip_da_tcam_result_valid = FALSE;
    uint8 ip_da_fib_result_valid = FALSE;
    uint8 ip_sa_tcam_result_valid = FALSE;
    uint8 ip_sa_fib_result_valid = FALSE;
    uint8 rpf_loose_check_ok = FALSE;
    uint8 rpf_strict_check_ok = FALSE;
    uint8 ipda_default_entry_valid = FALSE;
    uint8 ipsa_default_entry_valid = FALSE;
    uint8 rpf_if_id_match = FALSE;
    uint8 rpf_if_id_check_disable = FALSE;
    uint8 rpf_if_id_match_one = FALSE;
    uint8 rpf_port_check_disable = FALSE;
    uint8 rpf_port_check_match_one = FALSE;
    uint16 layer3_interface_id = 0;
    uint16 rpf_check_id = 0;
    uint16 rpf_port_id0 = 0, rpf_port_id1 = 0, rpf_port_id2 = 0, rpf_port_id3 = 0;
    uint32 cmd = 0;
    uint8 tcam_da_result_priority = FALSE,fib_da_result_priority = FALSE,tcam_da_first = FALSE;
    uint8 tcam_sa_result_priority = FALSE,fib_sa_result_priority = FALSE,tcam_sa_first = FALSE;

    ipe_route_ctl_t ipe_route_ctl;
    ipe_route_dest_info_t ipe_route_dest_info;
    ds_rpf_t ds_rpf ;

    sal_memset(&ipe_route_dest_info, 0, sizeof(ipe_route_dest_info));
    sal_memset(&ds_rpf, 0, sizeof(ds_rpf));

    sal_memset(&ipe_route_ctl, 0, sizeof(ipe_route_ctl));
    cmd = DRV_IOR(IpeRouteCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_route_ctl));

    /* POP_DS */
    /* IP DA lookup result */
    if (pkt_info->is_ipv4_ucast || pkt_info->is_ipv4_mcast
        || pkt_info->is_ipv6_ucast || pkt_info->is_ipv6_mcast)
    {
        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1)) /* TCAM lookup enabled */
        {
            ds_ip_da_tcam = (ds_ip_da_t *)pkt_info->ipda_tcam_data;
            ip_da_tcam_result_valid = pkt_info->ipda_tcam_result_valid;
        }

        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0)) /* FIB lookup enabled */
        {
            ds_ip_da_fib = (ds_ip_da_t *)pkt_info->ipda_fib_data;
            ip_da_fib_result_valid = pkt_info->ipda_fib_result_valid;
            ipda_default_entry_valid = pkt_info->ipda_fib_default_entry_valid;
        }

        tcam_da_result_priority = ip_da_tcam_result_valid && ds_ip_da_tcam->result_priority;
        fib_da_result_priority = ip_da_fib_result_valid && ds_ip_da_fib->result_priority;
        tcam_da_first = tcam_da_result_priority && !fib_da_result_priority;

        /*First LPM*/
        if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0) && ip_da_fib_result_valid && !ipda_default_entry_valid && !tcam_da_first)
        {
            ip_da_result_valid = ip_da_fib_result_valid;
            ds_ip_da = ds_ip_da_fib;
        }
        /*Second TCAM*/
        else if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 1) && ip_da_tcam_result_valid)
        {
            ip_da_result_valid = ip_da_tcam_result_valid;
            ds_ip_da = ds_ip_da_tcam;
        }
        /*Third Default*/
        else if (IS_BIT_SET(pkt_info->layer3_da_lookup_mode, 0) && ip_da_fib_result_valid)
        {
            ip_da_result_valid = ip_da_fib_result_valid;
            ds_ip_da = ds_ip_da_fib;
        }
    }

    /* IP DA lookup result */
    if ( pkt_info->is_ipv4_ucast_rpf || pkt_info->is_ipv6_ucast_rpf
        || pkt_info->is_ipv4_ucast_nat || pkt_info->is_ipv6_ucast_nat)
    {
        if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 1)) /* TCAM lookup enabled */
        {
            ds_ip_sa_tcam = (ds_ip_da_t* )pkt_info->ipsa_tcam_data;
            ds_ip_sa_nat_tcam = (ds_ip_sa_nat_t* )pkt_info->ipsa_tcam_data;
            ip_sa_tcam_result_valid = pkt_info->ipsa_tcam_result_valid;
        }

        if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0)) /* FIB lookup enabled */
        {
            ds_ip_sa_fib = (ds_ip_da_t *)pkt_info->ipsa_fib_data;
            ds_ip_sa_nat_fib = (ds_ip_sa_nat_t* )pkt_info->ipsa_fib_data;
            ip_sa_fib_result_valid = pkt_info->ipsa_fib_result_valid;
            ipsa_default_entry_valid = pkt_info->ipsa_fib_default_entry_valid;
        }

        /* ======== bug 4821 ECO begine =========*/
        if (pkt_info->is_ipv4_ucast_rpf || pkt_info->is_ipv6_ucast_rpf)
        {
            tcam_sa_result_priority = ip_sa_tcam_result_valid && ds_ip_sa_tcam->result_priority;
            fib_sa_result_priority = ip_sa_fib_result_valid && ds_ip_sa_fib->result_priority;
        }
        else
        {
            tcam_sa_result_priority = ip_sa_tcam_result_valid && ds_ip_sa_nat_tcam->result_priority;
            fib_sa_result_priority = ip_sa_fib_result_valid && ds_ip_sa_nat_fib->result_priority;
        }
        /* =========bug 4821 ECO end ==========*/

        tcam_sa_first = tcam_sa_result_priority && !fib_sa_result_priority;

        /*First LPM*/
        if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0) && ip_sa_fib_result_valid && !ipsa_default_entry_valid && !tcam_sa_first)
        {
            ip_sa_result_valid = ip_sa_fib_result_valid;
            ds_ip_da_rpf = ds_ip_sa_fib;
        }
        /*Second TCAM*/
        else if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 1) && ip_sa_tcam_result_valid)
        {
            ip_sa_result_valid = ip_sa_tcam_result_valid;
            ds_ip_da_rpf = ds_ip_sa_tcam;    /* DsIpDaRpf alias to DsIpDa */
        }
        /*Third Default*/
        else if (IS_BIT_SET(pkt_info->layer3_sa_lookup_mode, 0) && ip_sa_fib_result_valid)
        {
            ip_sa_result_valid = ip_sa_fib_result_valid;
            ds_ip_da_rpf = ds_ip_sa_fib;
        }

        ds_ip_sa_nat = (ds_ip_sa_nat_t* )ds_ip_da_rpf;
    }
    else if (pkt_info->is_ipv4_pbr || pkt_info->is_ipv6_pbr)
    {
        ip_sa_result_valid = pkt_info->ipsa_tcam_result_valid;
        pbr_ds_ip_da = (ds_ip_da_t *)pkt_info->ipsa_tcam_data;
    }

    if (ip_sa_result_valid && (pkt_info->is_ipv4_pbr || pkt_info->is_ipv6_pbr)) /* PBR */
    {
        ip_sa_result_valid = FALSE;

        if (!pbr_ds_ip_da->deny_pbr)
        {
            ds_ip_da = pbr_ds_ip_da;
            ip_da_result_valid = TRUE;
        }
    }

    routed_packet = (!pkt_info->discard)
                    && (!pkt_info->deny_route)
                    && ip_da_result_valid
                    && (pkt_info->is_ipv4_ucast || pkt_info->is_ipv4_mcast
                       || pkt_info->is_ipv6_ucast || pkt_info->is_ipv6_mcast);

    is_ipv4 = pkt_info->is_ipv4_ucast || pkt_info->is_ipv4_mcast;
    is_ipv6 = pkt_info->is_ipv6_ucast || pkt_info->is_ipv6_mcast;
    is_ucast = pkt_info->is_ipv4_ucast || pkt_info->is_ipv6_ucast;
    is_mcast = pkt_info->is_ipv4_mcast || pkt_info->is_ipv6_mcast;
    is_sa_nat = pkt_info->is_ipv4_ucast_nat || pkt_info->is_ipv6_ucast_nat;
    layer3_interface_id = pkt_info->interface_id;
    rpf_check_id = ipe_route_ctl.rpf_check_against_port ? ((1 << 9) | (pkt_info->local_phy_port))
                                                        : layer3_interface_id;

    if (routed_packet)
    {
        if ((!pkt_info->is_decap) && (!pkt_info->is_mpls_switched) && (!pkt_info->src_dscp_valid))
        {
            pkt_info->src_dscp = (parser_result->l3_s.tos.ip_tos >> 2) & 0x3F;
        }
    }
    else
    {
        if (OAM_IP_BFD == pkt_info->rx_oam_type)
        {
            pkt_info->rx_oam_type = OAM_NONE;
        }
    }

    /* ROUTE_SUMMARY */
    if (!routed_packet)
    {
        goto ROUTE_SUMMARY;
    }

    /* ESCAPE_CHECKING */
    ip_header_error = parser_result->l3_s.ip_header_error;
    ip_options = (!ipe_route_ctl.ip_options_escape_disable) && parser_result->l3_s.ip_options;
    igmp_snooped_packet = is_mcast && pkt_info->igmp_packet;

    if (is_ipv4)
    {
        /* see figure "IP Routing Martian Address Check Funtion" for FuncIpv4MartianAddr */

        if (!ipe_route_ctl.mcast_address_match_check_disable && pkt_info->ipv4_mcast_address
            && pkt_info->ipv4_mcast_address_check_failure)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_ROUTING_MCAST_IP_ADDR_CHK_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! IPv4 Packet Mcast address match check fail!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }
    else /* must be IPv6 */
    {
        if (!ipe_route_ctl.mcast_address_match_check_disable && pkt_info->ipv6_mcast_address
            && pkt_info->ipv6_mcast_address_check_failure)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_ROUTING_MCAST_IP_ADDR_CHK_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! IPv6 Packet Mcast address match check fail!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    if (ip_header_error)
    {
        routing_escape_case = 0; /* ip header error -- should be discarded */
    }
    else if (ip_options)
    {
        routing_escape_case = 1; /* ip options -- should be send to CPU */
    }
    else if (pkt_info->ip_link_scope_address)
    {
        routing_escape_case = 7; /* ip address link scope --- should be send to CPU */
    }
    else
    {
        routing_escape_case = 0; /* ip martin address --- should be discarded */
    }

    /* escape routing for all those cases */
    routing_escape = ip_header_error || ip_options || pkt_info->ip_martian_address
                     || pkt_info->ip_link_scope_address || igmp_snooped_packet;

    /* CHECK_TTL */
    if (!routing_escape && ds_ip_da->ttl_check_en && (pkt_info->packet_ttl < ipe_route_ctl.ip_ttl_limit))
    {
        routing_escape_case = 4;        /* TTL check failure */
        routing_escape = TRUE;
    }

    /* CHECK_ICMP_ERR_MASSAGE */
    if (!pkt_info->exception_en && ds_ip_da->icmp_err_msg_check_en
        && ((is_ipv4 && pkt_info->is_ipv4_icmp_err_msg) || (is_ipv6 && pkt_info->is_ipv6_icmp_err_msg)))
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
        pkt_info->exception_sub_index = (ipe_route_ctl.exception_sub_index << 5) | ds_ip_da->exception_sub_index;

        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_ICMP_ERR_MSG_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! IP Packet ICMP Error Discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* SA_NAT_SWITCH */
    if (is_sa_nat && ip_sa_result_valid)
    {
        /* NAT */
        nat_eligible = (L3_IF_TYPE_EXTERNAL == ds_ip_da->l3_if_type)
                       && (L3_IF_TYPE_INTERNAL == pkt_info->l3_if_type);

        /* forward by IPSA for mobile IP reverse tunnel or NAT missing IPSA matching address */
        use_ip_sa_fwd_ptr = ds_ip_sa_nat->force_ip_sa_fwd
                            || (ds_ip_sa_nat->ip_sa_fwd_ptr_valid && nat_eligible);

        /* for Ipv6, forceIpSaFwd and ipSa FwdPtrValid can be set, However, NAT is not supported */
        if (nat_eligible)
        {
            pkt_info->new_ip_sa_valid = ds_ip_sa_nat->replace_ip_sa;
            pkt_info->new_ip_sa = (ds_ip_sa_nat->ip_sa31 << 31)
                                                          | (ds_ip_sa_nat->ip_sa30_23 << 23)
                                                          | (ds_ip_sa_nat->ip_sa22_21 << 21)
                                                          | (ds_ip_sa_nat->ip_sa20_17 << 17)
                                                          | ds_ip_sa_nat->ip_sa16_0;

            pkt_info->new_l4_source_port_valid = ds_ip_sa_nat->replace_l4_source_port;
            pkt_info->new_l4_source_port = ds_ip_sa_nat->l4_source_port;


            rpf_check_ok = (0x0 == ds_ip_sa_nat->rpf_if_id) || (ds_ip_sa_nat->rpf_if_id == rpf_check_id);

            if (!rpf_check_ok)
            {
                routing_escape = TRUE;
                routing_escape_case = 5;  /* Ucast RPF fail - should be discarded */
            }
        }
    }

    /* UNICAST_SWITCH */
    if (is_ucast)
    {
        /* UCAST_ICMP_REDIRECT */
        /* ======== bug 4667 ECO begine ========= */
       // if (!routing_escape && is_ucast && !ds_ip_da->aps_select_valid && ds_ip_da->icmp_check_en
       //     && (layer3_interface_id == ds_ip_da->rpf_if_id) && !pkt_info->exception_en)
        if (!routing_escape && is_ucast && ds_ip_da->icmp_check_en 
            && (layer3_interface_id == ds_ip_da->rpf_if_id) && !pkt_info->exception_en)
        /* ======== bug 4667 ECO end ========= */
        {
            /* no fatal exception, bit 0 means ICMP redirect */
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_ICMP_REDIRECT;
        }

        /* UCAST_RPF */
        if (!routing_escape && !is_sa_nat && ip_sa_result_valid)
        {
            if (0 != ds_ip_da_rpf->rpf_if_id)  /* Check RPF */
            {
                if (!ds_ip_da_rpf->rpf_check_mode)  /* use profile*/
                {
                    sal_memset(&ds_rpf, 0, sizeof(ds_rpf));
                    cmd = DRV_IOR(DsRpf_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, (ds_ip_da_rpf->rpf_if_id & 0x3F), cmd, &ds_rpf));

                    rpf_port_id0 = (ds_rpf.rpf_port_id0_13_12 << 12) | (ds_rpf.rpf_port_id0_11_8 << 8)
                       | (ds_rpf.rpf_port_id0_7_4 << 4) | ds_rpf.rpf_port_id0_3_0;
                    rpf_port_id1 = (ds_rpf.rpf_port_id1_13_12 << 12) | (ds_rpf.rpf_port_id1_11_8 << 8)
                                   | (ds_rpf.rpf_port_id1_7_4 << 4) | ds_rpf.rpf_port_id1_3_0;
                    rpf_port_id2 = (ds_rpf.rpf_port_id2_13_12 << 12) | (ds_rpf.rpf_port_id2_11_8 << 8)
                                   | (ds_rpf.rpf_port_id2_7_4 << 4) | ds_rpf.rpf_port_id2_3_0;
                    rpf_port_id3 = (ds_rpf.rpf_port_id3_13_12 << 12) | (ds_rpf.rpf_port_id3_11_8 << 8)
                                   | (ds_rpf.rpf_port_id3_7_4 << 4) | ds_rpf.rpf_port_id3_3_0;

                    rpf_if_id_check_disable = !ds_rpf.rpf_if_id_valid0 && !ds_rpf.rpf_if_id_valid1 && !ds_rpf.rpf_if_id_valid2 && !ds_rpf.rpf_if_id_valid3
                                                            && !ds_rpf.rpf_if_id_valid4 && !ds_rpf.rpf_if_id_valid5 && !ds_rpf.rpf_if_id_valid6 && !ds_rpf.rpf_if_id_valid7
                                                            && !ds_rpf.rpf_if_id_valid8 && !ds_rpf.rpf_if_id_valid9 && !ds_rpf.rpf_if_id_valid10 && !ds_rpf.rpf_if_id_valid11
                                                            && !ds_rpf.rpf_if_id_valid12 && !ds_rpf.rpf_if_id_valid13 && !ds_rpf.rpf_if_id_valid14 && !ds_rpf.rpf_if_id_valid15;
                    rpf_if_id_match_one =
                         (ds_rpf.rpf_if_id_valid0  && (ds_rpf.rpf_if_id0 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid1 && (ds_rpf.rpf_if_id1 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid2 && (ds_rpf.rpf_if_id2 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid3 && (ds_rpf.rpf_if_id3 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid4 && (ds_rpf.rpf_if_id4 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid5 && (ds_rpf.rpf_if_id5 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid6 && (ds_rpf.rpf_if_id6 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid7 && (ds_rpf.rpf_if_id7 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid8 && (ds_rpf.rpf_if_id8 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid9 && (ds_rpf.rpf_if_id9 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid10 && (ds_rpf.rpf_if_id10 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid11 && (ds_rpf.rpf_if_id11 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid12 && (ds_rpf.rpf_if_id12 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid13 && (ds_rpf.rpf_if_id13 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid14 && (ds_rpf.rpf_if_id14 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid15 && (ds_rpf.rpf_if_id15 == rpf_check_id));
                    rpf_port_check_disable = !ds_rpf.rpf_port_id_valid0 && !ds_rpf.rpf_port_id_valid1
                                                            && !ds_rpf.rpf_port_id_valid2 && !ds_rpf.rpf_port_id_valid3;
                    rpf_port_check_match_one =
                        (ds_rpf.rpf_port_id_valid0 && (rpf_port_id0 == pkt_info->global_src_port))
                                 || (ds_rpf.rpf_port_id_valid1 && (rpf_port_id1 == pkt_info->global_src_port))
                                 || (ds_rpf.rpf_port_id_valid2 && (rpf_port_id2 == pkt_info->global_src_port))
                                 || (ds_rpf.rpf_port_id_valid3 && (rpf_port_id3 == pkt_info->global_src_port));
                    rpf_if_id_match = (rpf_if_id_check_disable || rpf_if_id_match_one) && (rpf_port_check_disable || rpf_port_check_match_one);
                }

                rpf_loose_check_ok = (0 != ds_ip_da_rpf->rpf_if_id)
                                     && pkt_info->rpf_type
                                     && (!ds_ip_da_rpf->is_default_route || pkt_info->rpf_permit_default);

                rpf_strict_check_ok = (0 != ds_ip_da_rpf->rpf_if_id)
                                      && !pkt_info->rpf_type
                                      && ((ds_ip_da_rpf->rpf_check_mode && (ds_ip_da_rpf->rpf_if_id == rpf_check_id))
                                        || (!ds_ip_da_rpf->rpf_check_mode && rpf_if_id_match));

                rpf_check_ok = (ds_ip_da_rpf->icmp_check_en && (!ipe_route_ctl.icmp_check_rpf_en))
                               || (0x0 == ds_ip_da_rpf->rpf_if_id)
                               || rpf_loose_check_ok
                               || rpf_strict_check_ok;

            }
            else
            {
                rpf_check_ok = TRUE;
            }

            if (!rpf_check_ok)
            {
                routing_escape = TRUE;
                routing_escape_case = 5;  /* Ucast RPF fail --- should be discarded */
            }
        }

        /* DECAP_SWITCH */
        if (!pkt_info->is_decap)
        {
            /* ISATP_CHECK */
            if (!ds_ip_da->next_hop_ptr_valid && ds_ip_da->isatap_check_en
                        && parser_result->l4_s.isatap_ptp_ver.is_isatap_interface)
            {
                is_atap_check_ok = pkt_info->isatap_check_ok;
            }
            else
            {
                is_atap_check_ok = TRUE;
            }

            if (!is_atap_check_ok)
            {
                routing_escape = TRUE;
                routing_escape_case = 3;     /* ISATAP failure - should be sent to CPU */
            }
        }
    }
    else
    {
        /* MCAST_RPF */
        if (!routing_escape && !is_sa_nat)
        {
            rpf_check_ok = FALSE;

            if (0x0 != ds_ip_da->rpf_if_id)   /* check RPF */
            {
                if (!ds_ip_da->rpf_check_mode)  /* use profile*/
                {
                    sal_memset(&ds_rpf, 0, sizeof(ds_rpf));
                    cmd = DRV_IOR(DsRpf_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, (ds_ip_da->rpf_if_id & 0x3F), cmd, &ds_rpf));

                    rpf_port_id0 = (ds_rpf.rpf_port_id0_13_12 << 12) | (ds_rpf.rpf_port_id0_11_8 << 8)
                       | (ds_rpf.rpf_port_id0_7_4 << 4) | ds_rpf.rpf_port_id0_3_0;
                    rpf_port_id1 = (ds_rpf.rpf_port_id1_13_12 << 12) | (ds_rpf.rpf_port_id1_11_8 << 8)
                                   | (ds_rpf.rpf_port_id1_7_4 << 4) | ds_rpf.rpf_port_id1_3_0;
                    rpf_port_id2 = (ds_rpf.rpf_port_id2_13_12 << 12) | (ds_rpf.rpf_port_id2_11_8 << 8)
                                   | (ds_rpf.rpf_port_id2_7_4 << 4) | ds_rpf.rpf_port_id2_3_0;
                    rpf_port_id3 = (ds_rpf.rpf_port_id3_13_12 << 12) | (ds_rpf.rpf_port_id3_11_8 << 8)
                                   | (ds_rpf.rpf_port_id3_7_4 << 4) | ds_rpf.rpf_port_id3_3_0;

                    rpf_if_id_check_disable = !ds_rpf.rpf_if_id_valid0 && !ds_rpf.rpf_if_id_valid1 && !ds_rpf.rpf_if_id_valid2 && !ds_rpf.rpf_if_id_valid3
                                                            && !ds_rpf.rpf_if_id_valid4 && !ds_rpf.rpf_if_id_valid5 && !ds_rpf.rpf_if_id_valid6 && !ds_rpf.rpf_if_id_valid7
                                                            && !ds_rpf.rpf_if_id_valid8 && !ds_rpf.rpf_if_id_valid9 && !ds_rpf.rpf_if_id_valid10 && !ds_rpf.rpf_if_id_valid11
                                                            && !ds_rpf.rpf_if_id_valid12 && !ds_rpf.rpf_if_id_valid13 && !ds_rpf.rpf_if_id_valid14 && !ds_rpf.rpf_if_id_valid15;
                    rpf_if_id_match_one =
                         (ds_rpf.rpf_if_id_valid0  && (ds_rpf.rpf_if_id0 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid1 && (ds_rpf.rpf_if_id1 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid2 && (ds_rpf.rpf_if_id2 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid3 && (ds_rpf.rpf_if_id3 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid4 && (ds_rpf.rpf_if_id4 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid5 && (ds_rpf.rpf_if_id5 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid6 && (ds_rpf.rpf_if_id6 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid7 && (ds_rpf.rpf_if_id7 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid8 && (ds_rpf.rpf_if_id8 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid9 && (ds_rpf.rpf_if_id9 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid10 && (ds_rpf.rpf_if_id10 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid11 && (ds_rpf.rpf_if_id11 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid12 && (ds_rpf.rpf_if_id12 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid13 && (ds_rpf.rpf_if_id13 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid14 && (ds_rpf.rpf_if_id14 == rpf_check_id))
                         || (ds_rpf.rpf_if_id_valid15 && (ds_rpf.rpf_if_id15 == rpf_check_id));
                    rpf_port_check_disable = !ds_rpf.rpf_port_id_valid0 && !ds_rpf.rpf_port_id_valid1
                                                            && !ds_rpf.rpf_port_id_valid2 && !ds_rpf.rpf_port_id_valid3;
                    rpf_port_check_match_one =
                        (ds_rpf.rpf_port_id_valid0 && (rpf_port_id0 == pkt_info->global_src_port))
                                 || (ds_rpf.rpf_port_id_valid1 && (rpf_port_id1 == pkt_info->global_src_port))
                                 || (ds_rpf.rpf_port_id_valid2 && (rpf_port_id2 == pkt_info->global_src_port))
                                 || (ds_rpf.rpf_port_id_valid3 && (rpf_port_id3 == pkt_info->global_src_port));
                    rpf_if_id_match = (rpf_if_id_check_disable || rpf_if_id_match_one) && (rpf_port_check_disable || rpf_port_check_match_one);
                }

                if (ipe_route_ctl.rpf_type_for_mcast)
                {
                    rpf_loose_check_ok = pkt_info->rpf_type
                                         && (!ds_ip_da->is_default_route || pkt_info->rpf_permit_default);

                    rpf_strict_check_ok = !pkt_info->rpf_type &&
                                          ((ds_ip_da->rpf_check_mode && (ds_ip_da->rpf_if_id == layer3_interface_id))/*single check*/
                                          || (!ds_ip_da->rpf_check_mode && rpf_if_id_match));/*multi check*/

                    rpf_check_ok = rpf_loose_check_ok || rpf_strict_check_ok;
                }
                else
                {
                    rpf_check_ok = (ds_ip_da->rpf_check_mode && (ds_ip_da->rpf_if_id == rpf_check_id))
                                   || (!ds_ip_da->rpf_check_mode && rpf_if_id_match);
                }


            }
            else
            {
                rpf_check_ok = TRUE;
            }

            if (!rpf_check_ok)
            {
                routing_escape = TRUE;
                routing_escape_case = 5;/*Mcast RPF fail - should be bridged*/

                if(ipe_route_ctl.mcast_rpf_fail_cpu_en && !pkt_info->exception_en)
                {
                    pkt_info->exception_en = TRUE;
                    pkt_info->exception_index = EXCEPTION_TYPE_ROUTE_MCAST_RPF_FAIL;
                }
            }
        }

    }

    /* CHECK_ESCAPE_SWITCH */
    if (!routing_escape)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Routing Process");

        /* DESTINATION */
        ipe_route_dest_info.chip_id = chip_id;
        ipe_route_dest_info.use_ip_sa_fwd_ptr = use_ip_sa_fwd_ptr;
        ipe_route_dest_info.ds_ip_da = ds_ip_da;
        ipe_route_dest_info.ds_ip_sa_nat = ds_ip_sa_nat;
        ipe_route_dest_info.routing_escape = &routing_escape;
        ipe_route_dest_info.routing_escape_case = &routing_escape_case;
        ipe_route_dest_info.ip_sa_result_valid = ip_sa_result_valid;
        DRV_IF_ERROR_RETURN(_cm_ipe_routing_destination(pkt_info, &ipe_route_dest_info));
    }

    /* CHECK_ESCAPE_SWITCH2 */
    if (routing_escape)
    {
        /* ROUTE_ESCAPE_PROCESS */
        if (igmp_snooped_packet)
        {
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = FATAL_EXP_IGMP_SNOOPED_PACKET;
        }
        /* Mcast Rpf fall back to bridge packet */
        else if ((is_mcast && (5 == routing_escape_case)) && !ipe_route_ctl.mcast_escape_to_cpu)
        {
            pkt_info->bridge_packet = TRUE;

            if ((OAM_IP_BFD == pkt_info->rx_oam_type) && ipe_route_ctl.mcast_fallback_bridge_disable_bfd)
            {
                pkt_info->rx_oam_type = OAM_NONE;
            }
        }
        else
        {
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = routing_escape_case;
        }
    }

ROUTE_SUMMARY:
    /* ROUTE_SUMMARY */
    if (pkt_info->tx_dm_en)
    {
        pkt_info->share_type = SHARE_TYPE_DMTX;
        pkt_info->share_fields_u.dmtx.dm_offset = pkt_info->time_stamp31_0 & 0xFF;
    }
    else if (pkt_info->new_ip_sa_valid || pkt_info->new_l4_source_port_valid || pkt_info->pt_enable)
    {
        pkt_info->share_type = SHARE_TYPE_NAT;
        pkt_info->share_fields_u.nat.new_ip_sa_39_32 = pkt_info->new_ip_sa_39_32;
        pkt_info->share_fields_u.nat.new_ip_sa_31_0 = pkt_info->new_ip_sa;
        pkt_info->share_fields_u.nat.new_l4_source_port = pkt_info->new_l4_source_port;
        pkt_info->share_fields_u.nat.new_ip_sa_valid = pkt_info->new_ip_sa_valid;
        pkt_info->share_fields_u.nat.new_l4_source_port_valid = pkt_info->new_l4_source_port_valid;
        pkt_info->share_fields_u.nat.pt_enable = pkt_info->pt_enable;
        pkt_info->share_fields_u.nat.ipv4_src_embeded_mode = pkt_info->ipv4_src_embeded_mode;
        pkt_info->share_fields_u.nat.ip_sa_mode = pkt_info->ip_sa_mode;
        pkt_info->share_fields_u.nat.src_address_mode = pkt_info->src_address_mode;
        pkt_info->share_fields_u.nat.ip_sa_prefix_length = pkt_info->ip_sa_prefix_length;
        pkt_info->share_fields_u.nat.new_ip_sa_valid = pkt_info->new_ip_sa_valid;
    }
    else
    {
        pkt_info->share_fields_u.ptp.ptp_extra_offset = pkt_info->ptp_extra_offset;
        pkt_info->share_fields_u.ptp.time_stamp_61_32 = pkt_info->time_stamp61_32;
        pkt_info->share_fields_u.ptp.time_stamp_31_0 = pkt_info->time_stamp31_0;
    }

    return DRV_E_NONE;
}

