/*****************************************************************************
 * cm_ipe_user_identify.c   Provides IPE user identify function.
 *
 * Copyright (C) 2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * revision:       V1.0.
 * Author:         XuZx.
 * Date:           2010-11-2.
 * Reason:         Create for GreatBelt
 *
 * revision:       V1.0.
 * Author:         MengZhW.
 * Date:           2010-11-23.
 * Reason:         SYNC for GreatBelt
 *
 * revision:       V2.0.
 * Author:         XuZx.
 * Date:           2011-4-20.
 * Reason:         SYNC for GreatBelt v2.0
 *
 * revision:       V4.2.1
 * Author:         XuZx.
 * Date:           2011-07-07.
 * Reason:         SYNC for GreatBelt v4.2.1
 *
 * revision:       V4.7.1
 * Author:         XuZx.
 * Date:           2011-07-29.
 * Reason:         SYNC for GreatBelt v4.7.1
 *
 * Revision:       V4.29.0
 * Reviser         XuZx.
 * Date:           2011-10-10.
 * Reason:         Sync for GreatBelt v4.29.0
 *
 * Revision:       V4.33.0
 * Reviser         XuZx.
 * Date:           2011-10-25.
 * Reason:         Sync for GreatBelt v4.33.0
 *
 * Reversion:      V5.1.0
 * Author:         Wangcy
 * Date:           2011-12-12.
 * Reason:         sync spec v5.1.0.
 *
 * Reversion:      V5.7.0
 * Author:         Wangcy
 * Date:           2012-1-17.
 * Reason:         sync spec v5.7.0.
 *
 * Reversion:      V5.11.0
 * Author:         ZhouW
 * Date:           2012-03-01.
 * Reason:         sync spec v5.11.0.
 *
 * Reversion:      V5.13.0
 * Author:         Wangcy
 * Date:           2012-03-12.
 * Reason:         sync spec v5.13.0.
 *
 * Reversion:      V5.15.0.1
 * Author:         Wangcy
 * Date:           2012-03-23.
 * Reason:         sync spec v5.15.0.1
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 *****************************************************************************/
/*****************************************************************************
 *
 * Header Files
 *
 *****************************************************************************/
#include "sal.h"
#include "ctcutil_lib.h"
#include "drv_lib.h"
#include "cm_lib.h"
#include "cm_com_tcam_engine.h"

/*****************************************************************************
 *
 * Defines and Macros
 *
 *****************************************************************************/
enum userid_lookup_num_e
{
    USERID_LOOKUP1,
    USERID_LOOKUP2,
    USERID_LOOKUP_NUM,
};
typedef enum userid_lookup_num_e userid_lookup_num_t;

enum userid_tcam_num_e
{
    USERID_TCAM1,
    USERID_TCAM2,
    USERID_TCAM_NUM
};
typedef enum userid_tcam_num_e userid_tcam_num_t;

struct ipe_bpdu_ptl_esp_cam_c_s
{
    uint32 rsv2                     :16;
    uint32 mac_da_value_up          :16;

    uint32 mac_da_value_low         :32;
};
typedef struct ipe_bpdu_ptl_esp_cam_c_s ipe_bpdu_ptl_esp_cam_c_t;

struct ipe_bpdu_ptl_esp_cam2_c_s
{
    uint32 rsv1                     :8;
    uint32 mac_da_mask              :24;

    uint32 rsv2                     :8;
    uint32 mac_da_value             :24;
};
typedef struct ipe_bpdu_ptl_esp_cam2_c_s ipe_bpdu_ptl_esp_cam2_c_t;

struct ipe_bpdu_ptl_esp_cam_rst_c_s
{
    uint32 rsv1                     :25;
    uint32 entry_valid              :1;
    uint32 exception_sub_index      :6;
};
typedef struct ipe_bpdu_ptl_esp_cam_rst_c_s ipe_bpdu_ptl_esp_cam_rst_c_t;

struct per_lookup_s
{
    uint32 userid_hash_key_type     :5;
    uint32 tcam_result_valid        :1;
    uint32 hash_result_valid        :1;
    uint32 hash_default_entry_valid :1;
    uint32 userid_result_valid      :1;
    uint32 userid_lookup_no_result  :1;
    uint32 hash_lookup_use_label    :1;
    uint32 userid_use_logic_port    :1;
    uint32 hash_use_da              :1;
    uint32 rsv                      :19;

    uint32 tcam_en                  :1;
    uint32 tcam_no_lookup           :1;
    uint32 userid_tcam_type         :3;
    uint32 userid_label             :6;
    uint32 hash_global_src_port     :14;

    lookup_result_t         hash_lookup_result;
    tcam_lkp_outputs_t      tcam_lookup_result;
    ds_user_id_t            hash_ds;
    ds_user_id_mac_tcam_t   tcam_ds_user_id;
    ds_user_id_t*           p_ds_user_id;
    ds_tunnel_id_t*         p_ds_tunnel_id;
};
typedef struct per_lookup_s per_lookup_t;

struct user_id_info_s
{
    uint32 trill_no_loop_ucast      :1;
    uint32 trill_no_loop_mcast      :1;
    uint32 trill_loop_mcast         :1;
    uint32 exception2               :1;
    uint32 exception_sub_index      :6;
    uint32 customer_id_valid        :1;
    uint32 stag_cos                 :3;
    uint32 stag_cfi                 :1;
    uint32 ctag_cos                 :3;
    uint32 ctag_cfi                 :1;
    uint32 svlan_id                 :12;

    uint32 is_trill_mcast           :1;
    uint32 cvlan_id                 :12;
    uint32 global_src_port          :14;
    uint32 capwap_logic_src_port    :14;
    uint32 user_id_roaming_state    :2;
    uint32 rsv_0                    :2;

    uint32 ac_logic_port            :14;
    uint32 wtp_ds_fwd_ptr           :16;
    uint32 dsusrid1_aps_select_valid     :1;

    uint32 customer_id;
    ds_phy_port_ext_t  ds_phy_port_ext;
    per_lookup_t       per_lookup[USERID_LOOKUP_NUM];
};
typedef struct user_id_info_s user_id_info_t;

struct user_id_result_info_s
{
    uint32 ds_user_id1_vlan_ptr_valid            :1;
    uint32 ds_user_id1_vlan_tag_action_valid     :1;
    uint32 ds_user_id1_service_policer_valid     :1;
    uint32 ds_user_id1_flow_policer_valid        :1;
    uint32 ds_user_id1_aps_select_group_id_valid :1;
    uint32 ds_user_id1_logic_src_port_valid      :1;
    uint32 ds_user_id1_fid_valid                 :1;
    uint32 ds_user_id1_priority_valid            :1;
    uint32 ds_user_id1_ds_fwd_ptr_valid          :1;
    uint32 ds_user_id1_outer_vlan_is_cvlan_valid :1;
    uint32 ds_user_id1_svlan_tpid_index_en       :1;
    uint32 ds_user_id1_mac_isolated_group_valid  :1;
};
typedef struct user_id_result_info_s user_id_result_info_t;
/*****************************************************************************
 * Name:       _cm_ipe_user_identify_construct_tcam_key
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      tcam_key_type    --   specify the tcam key type
 *             p_in_pkt         --   pointer to buffer which save input packet and packet
 *                                   header ,and processing informations
 *             p_userid_key_ptr --   pointer to store user id key
 *             p_user_id_info   --   pointer to buffer which save user id temp variable
 *                                   used in user id
 *             lookup_index     --   specify lookup index
 * Output:     p_userid_key_ptr --   pointer to store user id key
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_construct_tcam_key(tcam_key_type_t tcam_key_type,
                                                     ipe_in_pkt_t* p_in_pkt,
                                                     void* p_userid_key_ptr,
                                                     user_id_info_t* p_user_id_info,
                                                     uint8 lookup_index)
{

    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)p_in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    uint32 cmd = 0;
    ipe_user_id_ctl_t ipe_user_id_ctl;
    uint32 customer_id = 0;
    uint8 user_id_label[USERID_LOOKUP_NUM] = {0};

    user_id_label[USERID_LOOKUP1] = pkt_info->user_id_label1;
    user_id_label[USERID_LOOKUP2] = pkt_info->user_id_label2;

    ds_user_id_mac_key_t* p_userid_mac_key_ptr = NULL;
    ds_user_id_vlan_key_t* p_userid_vlan_key_ptr = NULL;
    ds_user_id_ipv4_key_t* p_userid_ipv4_key_ptr = NULL;
    ds_user_id_ipv6_key_t* p_userid_ipv6_key_ptr = NULL;
    ds_tunnel_id_ipv4_key_t* p_userid_tunnel_ipv4_key_ptr = NULL;
    ds_tunnel_id_ipv6_key_t* p_userid_tunnel_ipv6_key_ptr = NULL;
    ds_tunnel_id_pbb_key_t* p_tunnel_id_pbb_key_ptr = NULL;
    ds_tunnel_id_capwap_key_t* p_tunnel_id_capwap_key_ptr = NULL;
    ds_tunnel_id_trill_key_t* p_tunnel_id_trill_key_ptr = NULL;

    uint16 ingress_nick_name = parser_result->l3_s.ip_sa.trill.ingress_nick_name;
    uint16 egress_nick_name = parser_result->l3_s.ip_da.trill.egress_nick_name;

    sal_memset(&ipe_user_id_ctl, 0, sizeof(ipe_user_id_ctl));
    cmd = DRV_IOR(IpeUserIdCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_in_pkt->chip_id, 0, cmd, &ipe_user_id_ctl));

    switch (tcam_key_type)
    {
        case TCAM_TYPE_MAC_USERID:
            p_userid_mac_key_ptr = (ds_user_id_mac_key_t*)p_userid_key_ptr;

            p_userid_mac_key_ptr->is_acl_qos_key0 = FALSE;
            p_userid_mac_key_ptr->is_acl_qos_key1 = FALSE;

            p_userid_mac_key_ptr->table_id0 = (ipe_user_id_ctl.lookup_ctl0 >> 2) & 0x7;
            p_userid_mac_key_ptr->table_id1 = (ipe_user_id_ctl.lookup_ctl0 >> 2) & 0x7;

            p_userid_mac_key_ptr->sub_table_id0 = ipe_user_id_ctl.lookup_ctl0 & 0x3;
            p_userid_mac_key_ptr->sub_table_id1 = ipe_user_id_ctl.lookup_ctl0 & 0x3;

            p_userid_mac_key_ptr->layer2_type = parser_result->layer2_type;
            p_userid_mac_key_ptr->layer3_type = parser_result->layer3_type;

            if ((pkt_info->capwap_tunnel_valid
                && pkt_info->capwap_tunnel_type)
                && (ROAMING_HA == pkt_info->roaming_state)
                && !IS_BIT_SET(parser_result->l2_s.mac_da5, 0))
            {
                p_userid_mac_key_ptr->mac_sa47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);
                p_userid_mac_key_ptr->mac_sa31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                                               parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
                p_userid_mac_key_ptr->mac_da47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
                p_userid_mac_key_ptr->mac_da31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                                               parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
            }
            else
            {
                p_userid_mac_key_ptr->mac_sa47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
                p_userid_mac_key_ptr->mac_sa31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                                               parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
                p_userid_mac_key_ptr->mac_da47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);
                p_userid_mac_key_ptr->mac_da31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                                               parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
            }
            p_userid_mac_key_ptr->user_id_label = user_id_label[lookup_index];
            p_userid_mac_key_ptr->exception2 = p_user_id_info->exception2;
            p_userid_mac_key_ptr->exception_sub_index = p_user_id_info->exception_sub_index;

            p_userid_mac_key_ptr->vlan_id1 = ipe_user_id_ctl.user_id_mac_key_svlan_first ?
                                             p_user_id_info->svlan_id : p_user_id_info->cvlan_id;
            p_userid_mac_key_ptr->cos1 = ipe_user_id_ctl.user_id_mac_key_svlan_first ?
                                         p_user_id_info->stag_cos : p_user_id_info->ctag_cos;
            p_userid_mac_key_ptr->cfi1 = ipe_user_id_ctl.user_id_mac_key_svlan_first ?
                                         p_user_id_info->stag_cfi : p_user_id_info->ctag_cfi;
            p_userid_mac_key_ptr->vlan_id2_hi = (ipe_user_id_ctl.user_id_mac_key_svlan_first ?
                                                 p_user_id_info->cvlan_id : p_user_id_info->svlan_id) >> 8;
            p_userid_mac_key_ptr->vlan_id2_low = (ipe_user_id_ctl.user_id_mac_key_svlan_first ?
                                                  p_user_id_info->cvlan_id : p_user_id_info->svlan_id) & 0xFF;
            p_userid_mac_key_ptr->cos2 = ipe_user_id_ctl.user_id_mac_key_svlan_first ?
                                         p_user_id_info->ctag_cos : p_user_id_info->stag_cos;
            break;
        case TCAM_TYPE_IPV6_USERID:
            p_userid_ipv6_key_ptr = (ds_user_id_ipv6_key_t*)p_userid_key_ptr;

            p_userid_ipv6_key_ptr->is_acl_qos_key0 = FALSE;
            p_userid_ipv6_key_ptr->is_acl_qos_key1 = FALSE;
            p_userid_ipv6_key_ptr->is_acl_qos_key2 = FALSE;
            p_userid_ipv6_key_ptr->is_acl_qos_key3 = FALSE;
            p_userid_ipv6_key_ptr->is_acl_qos_key4 = FALSE;
            p_userid_ipv6_key_ptr->is_acl_qos_key5 = FALSE;
            p_userid_ipv6_key_ptr->is_acl_qos_key6 = FALSE;
            p_userid_ipv6_key_ptr->is_acl_qos_key7 = FALSE;

            p_userid_ipv6_key_ptr->table_id0 = (ipe_user_id_ctl.lookup_ctl1 >> 2) & 0x7;
            p_userid_ipv6_key_ptr->table_id1 = (ipe_user_id_ctl.lookup_ctl1 >> 2) & 0x7;
            p_userid_ipv6_key_ptr->table_id2 = (ipe_user_id_ctl.lookup_ctl1 >> 2) & 0x7;
            p_userid_ipv6_key_ptr->table_id3 = (ipe_user_id_ctl.lookup_ctl1 >> 2) & 0x7;
            p_userid_ipv6_key_ptr->table_id4 = (ipe_user_id_ctl.lookup_ctl1 >> 2) & 0x7;
            p_userid_ipv6_key_ptr->table_id5 = (ipe_user_id_ctl.lookup_ctl1 >> 2) & 0x7;
            p_userid_ipv6_key_ptr->table_id6 = (ipe_user_id_ctl.lookup_ctl1 >> 2) & 0x7;
            p_userid_ipv6_key_ptr->table_id7 = (ipe_user_id_ctl.lookup_ctl1 >> 2) & 0x7;

            p_userid_ipv6_key_ptr->sub_table_id0 = ipe_user_id_ctl.lookup_ctl1 & 0x3;
            p_userid_ipv6_key_ptr->sub_table_id1 = ipe_user_id_ctl.lookup_ctl1 & 0x3;
            p_userid_ipv6_key_ptr->sub_table_id2 = ipe_user_id_ctl.lookup_ctl1 & 0x3;
            p_userid_ipv6_key_ptr->sub_table_id3 = ipe_user_id_ctl.lookup_ctl1 & 0x3;
            p_userid_ipv6_key_ptr->sub_table_id4 = ipe_user_id_ctl.lookup_ctl1 & 0x3;
            p_userid_ipv6_key_ptr->sub_table_id5 = ipe_user_id_ctl.lookup_ctl1 & 0x3;
            p_userid_ipv6_key_ptr->sub_table_id6 = ipe_user_id_ctl.lookup_ctl1 & 0x3;
            p_userid_ipv6_key_ptr->sub_table_id7 = ipe_user_id_ctl.lookup_ctl1 & 0x3;

            p_userid_ipv6_key_ptr->ip_sa31_0 = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
            p_userid_ipv6_key_ptr->ip_sa63_32 = parser_result->l3_s.ip_sa.ipv6.ipsa_63_32;
            p_userid_ipv6_key_ptr->ip_sa71_64 = (parser_result->l3_s.ip_sa.ipv6.ipsa_95_64 & 0xFF);
            p_userid_ipv6_key_ptr->ip_sa103_72 = ((parser_result->l3_s.ip_sa.ipv6.ipsa_127_96&0xFF)<<24)
                                                    |(parser_result->l3_s.ip_sa.ipv6.ipsa_95_64>>8);
            p_userid_ipv6_key_ptr->ip_sa127_104 = (parser_result->l3_s.ip_sa.ipv6.ipsa_127_96>>8)&0xFFFFFF;

            p_userid_ipv6_key_ptr->ip_header_error = parser_result->l3_s.ip_header_error;
            p_userid_ipv6_key_ptr->ip_options = parser_result->l3_s.ip_options;
            p_userid_ipv6_key_ptr->mac_sa47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5,
                                                             parser_result->l2_s.mac_sa4);
            p_userid_ipv6_key_ptr->mac_sa31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                                            parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
            p_userid_ipv6_key_ptr->layer3_type = parser_result->layer3_type;
            p_userid_ipv6_key_ptr->l4_source_port = parser_result->l4_s.l4_src_port.l4_source_port;
            p_userid_ipv6_key_ptr->layer2_type = parser_result->layer2_type;
            p_userid_ipv6_key_ptr->svlan_id_valid = parser_result->l2_s.svlan_id_valid;
            p_userid_ipv6_key_ptr->cvlan_id_valid = parser_result->l2_s.cvlan_id_valid;
            p_userid_ipv6_key_ptr->ip_da31_0 = parser_result->l3_s.ip_da.ipv6.ipda_31_0;
            p_userid_ipv6_key_ptr->ip_da63_32 = parser_result->l3_s.ip_da.ipv6.ipda_63_32;
            p_userid_ipv6_key_ptr->ip_da71_64 = (parser_result->l3_s.ip_da.ipv6.ipda_95_64 & 0xFF);
            p_userid_ipv6_key_ptr->ip_da103_72 = ((parser_result->l3_s.ip_da.ipv6.ipda_127_96&0xFF)<<24)
                                                    |(parser_result->l3_s.ip_da.ipv6.ipda_95_64>>8);
            p_userid_ipv6_key_ptr->ip_da127_104 = (parser_result->l3_s.ip_da.ipv6.ipda_127_96>>8)&0xFFFFFF;
            p_userid_ipv6_key_ptr->l4_info_mapped = parser_result->l4_s.layer4_info_mapped;
            p_userid_ipv6_key_ptr->ether_type15_8 = parser_result->l2_s.layer2_header_protocol>>8;
            p_userid_ipv6_key_ptr->ether_type7_0 = parser_result->l2_s.layer2_header_protocol&0xFF;
            p_userid_ipv6_key_ptr->mac_da47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5,
                                                             parser_result->l2_s.mac_da4);
            p_userid_ipv6_key_ptr->mac_da31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                                            parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
            p_userid_ipv6_key_ptr->frag_info = parser_result->l3_s.frag_info;
            p_userid_ipv6_key_ptr->layer4_type = parser_result->layer4_type;
            p_userid_ipv6_key_ptr->l4_dest_port = parser_result->l4_s.l4_dst_port.l4_dest_port;
            p_userid_ipv6_key_ptr->dscp = (parser_result->l3_s.tos.ip_tos >> 2) & 0x3F;
            p_userid_ipv6_key_ptr->is_udp = parser_result->l4_s.is_udp;
            p_userid_ipv6_key_ptr->is_tcp = parser_result->l4_s.is_tcp;
            p_userid_ipv6_key_ptr->ipv6_flow_label = parser_result->l3_s.ipv6_flow_label;
            p_userid_ipv6_key_ptr->user_id_label = user_id_label[lookup_index];
            p_userid_ipv6_key_ptr->svlan_id = p_user_id_info->svlan_id;
            p_userid_ipv6_key_ptr->cvlan_id11_10 = (p_user_id_info->cvlan_id >> 10) & 0x3;
            p_userid_ipv6_key_ptr->cvlan_id9_0 = p_user_id_info->cvlan_id & 0x3FF;
            p_userid_ipv6_key_ptr->stag_cos = p_user_id_info->stag_cos;
            p_userid_ipv6_key_ptr->stag_cfi = p_user_id_info->stag_cfi;
            p_userid_ipv6_key_ptr->ctag_cos = p_user_id_info->ctag_cos;
            p_userid_ipv6_key_ptr->ctag_cfi = p_user_id_info->ctag_cfi;
            p_userid_ipv6_key_ptr->exception2 = p_user_id_info->exception2;
            p_userid_ipv6_key_ptr->exception_sub_index = p_user_id_info->exception_sub_index & 0x3F;
            break;

        case TCAM_TYPE_IPV4_USERID:
            p_userid_ipv4_key_ptr = (ds_user_id_ipv4_key_t*)p_userid_key_ptr;

            p_userid_ipv4_key_ptr->is_acl_qos_key0 = FALSE;
            p_userid_ipv4_key_ptr->is_acl_qos_key1 = FALSE;
            p_userid_ipv4_key_ptr->is_acl_qos_key2 = FALSE;
            p_userid_ipv4_key_ptr->is_acl_qos_key3 = FALSE;

            p_userid_ipv4_key_ptr->table_id0 = (ipe_user_id_ctl.lookup_ctl2 >> 2) & 0x7;
            p_userid_ipv4_key_ptr->table_id1 = (ipe_user_id_ctl.lookup_ctl2 >> 2) & 0x7;
            p_userid_ipv4_key_ptr->table_id2 = (ipe_user_id_ctl.lookup_ctl2 >> 2) & 0x7;
            p_userid_ipv4_key_ptr->table_id3 = (ipe_user_id_ctl.lookup_ctl2 >> 2) & 0x7;

            p_userid_ipv4_key_ptr->sub_table_id0 = ipe_user_id_ctl.lookup_ctl2 & 0x3;
            p_userid_ipv4_key_ptr->sub_table_id1 = ipe_user_id_ctl.lookup_ctl2 & 0x3;
            p_userid_ipv4_key_ptr->sub_table_id2 = ipe_user_id_ctl.lookup_ctl2 & 0x3;
            p_userid_ipv4_key_ptr->sub_table_id3 = ipe_user_id_ctl.lookup_ctl2 & 0x3;

            p_userid_ipv4_key_ptr->ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
            p_userid_ipv4_key_ptr->ip_da = parser_result->l3_s.ip_da.ipv4.ipda;
            p_userid_ipv4_key_ptr->layer4_type = parser_result->layer4_type;
            p_userid_ipv4_key_ptr->l4_source_port = parser_result->l4_s.l4_src_port.l4_source_port;
            p_userid_ipv4_key_ptr->l4_dest_port = parser_result->l4_s.l4_dst_port.l4_dest_port;
            p_userid_ipv4_key_ptr->l4_info_mapped = parser_result->l4_s.layer4_info_mapped;
            p_userid_ipv4_key_ptr->dscp = (parser_result->l3_s.tos.ip_tos >> 2) & 0x3F;
            p_userid_ipv4_key_ptr->ip_header_error = parser_result->l3_s.ip_header_error;
            p_userid_ipv4_key_ptr->ip_options = parser_result->l3_s.ip_options;
            p_userid_ipv4_key_ptr->frag_info = parser_result->l3_s.frag_info;
            p_userid_ipv4_key_ptr->is_udp = parser_result->l4_s.is_udp;
            p_userid_ipv4_key_ptr->is_tcp = parser_result->l4_s.is_tcp;
            p_userid_ipv4_key_ptr->mac_sa_hi = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
            p_userid_ipv4_key_ptr->mac_sa_low = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                                  parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
            p_userid_ipv4_key_ptr->svlan_id_valid = parser_result->l2_s.svlan_id_valid;
            p_userid_ipv4_key_ptr->cvlan_id_valid = parser_result->l2_s.cvlan_id_valid;
            p_userid_ipv4_key_ptr->layer2_type = parser_result->layer2_type;
            p_userid_ipv4_key_ptr->layer3_type = parser_result->layer3_type;
            p_userid_ipv4_key_ptr->ether_type_hi = parser_result->l2_s.layer2_header_protocol >> 8;
            p_userid_ipv4_key_ptr->ether_type_low = parser_result->l2_s.layer2_header_protocol & 0xFF;
            p_userid_ipv4_key_ptr->mac_da_hi = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);
            p_userid_ipv4_key_ptr->mac_da_low = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                                    parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
            p_userid_ipv4_key_ptr->user_id_label = user_id_label[lookup_index];
            p_userid_ipv4_key_ptr->svlan_id = p_user_id_info->svlan_id;
            p_userid_ipv4_key_ptr->cvlan_id = p_user_id_info->cvlan_id;
            p_userid_ipv4_key_ptr->stag_cos = p_user_id_info->stag_cos;
            p_userid_ipv4_key_ptr->stag_cfi = p_user_id_info->stag_cfi;
            p_userid_ipv4_key_ptr->ctag_cos = p_user_id_info->ctag_cos;
            p_userid_ipv4_key_ptr->ctag_cfi = p_user_id_info->ctag_cfi;
            p_userid_ipv4_key_ptr->exception2 = p_user_id_info->exception2;
            p_userid_ipv4_key_ptr->exception_sub_index = p_user_id_info->exception_sub_index;
            p_userid_ipv4_key_ptr->routed_packet = FALSE;

            break;

        case TCAM_TYPE_VLAN_USERID:
            p_userid_vlan_key_ptr = (ds_user_id_vlan_key_t*)p_userid_key_ptr;

            p_userid_vlan_key_ptr->is_acl_qos_key = FALSE;
            p_userid_vlan_key_ptr->table_id = (ipe_user_id_ctl.lookup_ctl3 >> 2) & 0x7;
            p_userid_vlan_key_ptr->sub_table_id = ipe_user_id_ctl.lookup_ctl3 & 0x3;

            p_userid_vlan_key_ptr->user_id_label = user_id_label[lookup_index];
            p_userid_vlan_key_ptr->svlan_id_valid = parser_result->l2_s.svlan_id_valid;
            p_userid_vlan_key_ptr->cvlan_id_valid = parser_result->l2_s.cvlan_id_valid;

            if (p_user_id_info->customer_id_valid)
            {
                customer_id = p_user_id_info->customer_id;
            }
            else
            {
                customer_id = ((p_user_id_info->cvlan_id << 15) | (p_user_id_info->exception2 << 14)
                              | (p_user_id_info->exception_sub_index << 8) | (p_user_id_info->ctag_cos << 5)
                              | (p_user_id_info->ctag_cfi << 4) | (p_user_id_info->stag_cos << 1)
                              | p_user_id_info->stag_cfi);
            }

            p_userid_vlan_key_ptr->svlan_id = p_user_id_info->svlan_id;
            p_userid_vlan_key_ptr->global_src_port = p_user_id_info->global_src_port;
            p_userid_vlan_key_ptr->customer_id = customer_id;
            break;

        case TCAM_TYPE_IPV6_TUNNELID:
            p_userid_tunnel_ipv6_key_ptr = (ds_tunnel_id_ipv6_key_t*)p_userid_key_ptr;

            p_userid_tunnel_ipv6_key_ptr->is_acl_qos_key0 = FALSE;
            p_userid_tunnel_ipv6_key_ptr->is_acl_qos_key1 = FALSE;
            p_userid_tunnel_ipv6_key_ptr->is_acl_qos_key2 = FALSE;
            p_userid_tunnel_ipv6_key_ptr->is_acl_qos_key3 = FALSE;
            p_userid_tunnel_ipv6_key_ptr->is_acl_qos_key4 = FALSE;
            p_userid_tunnel_ipv6_key_ptr->is_acl_qos_key5 = FALSE;
            p_userid_tunnel_ipv6_key_ptr->is_acl_qos_key6 = FALSE;
            p_userid_tunnel_ipv6_key_ptr->is_acl_qos_key7 = FALSE;

            p_userid_tunnel_ipv6_key_ptr->table_id0 = (ipe_user_id_ctl.lookup_ctl4 >> 3) & 0x7;
            p_userid_tunnel_ipv6_key_ptr->table_id1 = (ipe_user_id_ctl.lookup_ctl4 >> 3) & 0x7;
            p_userid_tunnel_ipv6_key_ptr->table_id2 = (ipe_user_id_ctl.lookup_ctl4 >> 3) & 0x7;
            p_userid_tunnel_ipv6_key_ptr->table_id3 = (ipe_user_id_ctl.lookup_ctl4 >> 3) & 0x7;
            p_userid_tunnel_ipv6_key_ptr->table_id4 = (ipe_user_id_ctl.lookup_ctl4 >> 3) & 0x7;
            p_userid_tunnel_ipv6_key_ptr->table_id5 = (ipe_user_id_ctl.lookup_ctl4 >> 3) & 0x7;
            p_userid_tunnel_ipv6_key_ptr->table_id6 = (ipe_user_id_ctl.lookup_ctl4 >> 3) & 0x7;
            p_userid_tunnel_ipv6_key_ptr->table_id7 = (ipe_user_id_ctl.lookup_ctl4 >> 3) & 0x7;


            p_userid_tunnel_ipv6_key_ptr->sub_table_id0 = ipe_user_id_ctl.lookup_ctl4 & 0x7;
            p_userid_tunnel_ipv6_key_ptr->sub_table_id1 = ipe_user_id_ctl.lookup_ctl4 & 0x7;
            p_userid_tunnel_ipv6_key_ptr->sub_table_id2 = ipe_user_id_ctl.lookup_ctl4 & 0x7;
            p_userid_tunnel_ipv6_key_ptr->sub_table_id3 = ipe_user_id_ctl.lookup_ctl4 & 0x7;
            p_userid_tunnel_ipv6_key_ptr->sub_table_id4 = ipe_user_id_ctl.lookup_ctl4 & 0x7;
            p_userid_tunnel_ipv6_key_ptr->sub_table_id5 = ipe_user_id_ctl.lookup_ctl4 & 0x7;
            p_userid_tunnel_ipv6_key_ptr->sub_table_id6 = ipe_user_id_ctl.lookup_ctl4 & 0x7;
            p_userid_tunnel_ipv6_key_ptr->sub_table_id7 = ipe_user_id_ctl.lookup_ctl4 & 0x7;

            p_userid_tunnel_ipv6_key_ptr->user_id_label = user_id_label[lookup_index];
            p_userid_tunnel_ipv6_key_ptr->vlan_ptr = pkt_info->user_vlan_ptr;

            p_userid_tunnel_ipv6_key_ptr->ip_sa31_0 = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
            p_userid_tunnel_ipv6_key_ptr->ip_sa63_32= parser_result->l3_s.ip_sa.ipv6.ipsa_63_32;
            p_userid_tunnel_ipv6_key_ptr->ip_sa95_64 = parser_result->l3_s.ip_sa.ipv6.ipsa_95_64;
            p_userid_tunnel_ipv6_key_ptr->ip_sa127_96 = parser_result->l3_s.ip_sa.ipv6.ipsa_127_96;

            p_userid_tunnel_ipv6_key_ptr->ip_da31_0 = parser_result->l3_s.ip_da.ipv6.ipda_31_0;
            p_userid_tunnel_ipv6_key_ptr->ip_da63_32 = parser_result->l3_s.ip_da.ipv6.ipda_63_32;
            p_userid_tunnel_ipv6_key_ptr->ip_da95_64 = parser_result->l3_s.ip_da.ipv6.ipda_95_64;
            p_userid_tunnel_ipv6_key_ptr->ip_da127_96 = parser_result->l3_s.ip_da.ipv6.ipda_127_96;

            p_userid_tunnel_ipv6_key_ptr->layer4_type = parser_result->layer4_type;
            p_userid_tunnel_ipv6_key_ptr->frag_info = parser_result->l3_s.frag_info;
            p_userid_tunnel_ipv6_key_ptr->ip_options = parser_result->l3_s.ip_options;
            p_userid_tunnel_ipv6_key_ptr->ip_header_error = parser_result->l3_s.ip_header_error;
            p_userid_tunnel_ipv6_key_ptr->ipv6_flow_label = parser_result->l3_s.ipv6_flow_label;
            p_userid_tunnel_ipv6_key_ptr->l4_info_mapped = parser_result->l4_s.layer4_info_mapped;
            p_userid_tunnel_ipv6_key_ptr->layer3_type = parser_result->layer3_type;
            p_userid_tunnel_ipv6_key_ptr->dscp = (parser_result->l3_s.tos.ip_tos >> 2) & 0x3F;
            p_userid_tunnel_ipv6_key_ptr->is_udp = parser_result->l4_s.is_udp;
            p_userid_tunnel_ipv6_key_ptr->is_tcp = parser_result->l4_s.is_tcp;
            p_userid_tunnel_ipv6_key_ptr->mac_sa47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
            p_userid_tunnel_ipv6_key_ptr->mac_sa31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                                                   parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
            p_userid_tunnel_ipv6_key_ptr->layer2_type = parser_result->layer2_type;
            p_userid_tunnel_ipv6_key_ptr->mac_da47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);
            p_userid_tunnel_ipv6_key_ptr->mac_da31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                                                   parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
            p_userid_tunnel_ipv6_key_ptr->ether_type = parser_result->l2_s.layer2_header_protocol;
            p_userid_tunnel_ipv6_key_ptr->svlan_id = p_user_id_info->svlan_id;
            p_userid_tunnel_ipv6_key_ptr->stag_cfi = p_user_id_info->stag_cfi;
            p_userid_tunnel_ipv6_key_ptr->stag_cos = p_user_id_info->stag_cos;
            p_userid_tunnel_ipv6_key_ptr->cvlan_id = p_user_id_info->cvlan_id;
            p_userid_tunnel_ipv6_key_ptr->ctag_cos = p_user_id_info->ctag_cos;
            p_userid_tunnel_ipv6_key_ptr->ctag_cfi = p_user_id_info->ctag_cfi;

            if (IS_BIT_SET(parser_result->l4_s.l4_src_port.gre_flags, 13) && (L4_TYPE_GRE == parser_result->layer4_type))
            {
                p_userid_tunnel_ipv6_key_ptr->l4_source_port = parser_result->l4_s.gre_bfd_ptp.gre_key & 0xFFFF;
                p_userid_tunnel_ipv6_key_ptr->l4_des_port  = (parser_result->l4_s.gre_bfd_ptp.gre_key >> 16)& 0xFFFF;
            }
            else if (L4_TYPE_UDP == parser_result->layer4_type)
            {
                p_userid_tunnel_ipv6_key_ptr->l4_source_port = parser_result->l4_s.l4_src_port.l4_source_port;
                p_userid_tunnel_ipv6_key_ptr->l4_des_port = parser_result->l4_s.l4_dst_port.l4_dest_port;
            }
            break;

        case TCAM_TYPE_IPV4_TUNNELID:
            p_userid_tunnel_ipv4_key_ptr = (ds_tunnel_id_ipv4_key_t*)p_userid_key_ptr;

            p_userid_tunnel_ipv4_key_ptr->is_acl_qos_key0 = FALSE;
            p_userid_tunnel_ipv4_key_ptr->is_acl_qos_key1 = FALSE;
            p_userid_tunnel_ipv4_key_ptr->table_id0 = (ipe_user_id_ctl.lookup_ctl5 >> 3) & 0x7;
            p_userid_tunnel_ipv4_key_ptr->table_id1 = (ipe_user_id_ctl.lookup_ctl5 >> 3) & 0x7;
            p_userid_tunnel_ipv4_key_ptr->sub_table_id0 = ipe_user_id_ctl.lookup_ctl5 & 0x7;
            p_userid_tunnel_ipv4_key_ptr->sub_table_id1 = ipe_user_id_ctl.lookup_ctl5 & 0x7;
            p_userid_tunnel_ipv4_key_ptr->ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
            p_userid_tunnel_ipv4_key_ptr->ip_da = parser_result->l3_s.ip_da.ipv4.ipda;
            p_userid_tunnel_ipv4_key_ptr->layer4_type = parser_result->layer4_type;

            p_userid_tunnel_ipv4_key_ptr->l4_source_port = parser_result->l4_s.l4_src_port.l4_source_port;
            p_userid_tunnel_ipv4_key_ptr->l4_dest_port = parser_result->l4_s.l4_dst_port.l4_dest_port;
            p_userid_tunnel_ipv4_key_ptr->gre_key = parser_result->l4_s.gre_bfd_ptp.gre_key;
            p_userid_tunnel_ipv4_key_ptr->frag_info = parser_result->l3_s.frag_info;
            break;

        case TCAM_TYPE_PBB_TUNNELID:
            p_tunnel_id_pbb_key_ptr = (ds_tunnel_id_pbb_key_t*)p_userid_key_ptr;

            p_tunnel_id_pbb_key_ptr->is_acl_qos_key = FALSE;
            p_tunnel_id_pbb_key_ptr->table_id = (ipe_user_id_ctl.lookup_ctl6 >> 3) & 0x7;
            p_tunnel_id_pbb_key_ptr->sub_table_id = ipe_user_id_ctl.lookup_ctl6 & 0x7;
            p_tunnel_id_pbb_key_ptr->user_id_lable = user_id_label[lookup_index] & 0x3F;
            p_tunnel_id_pbb_key_ptr->global_src_port = p_user_id_info->global_src_port;
            p_tunnel_id_pbb_key_ptr->isid = parser_result->l3_s.ip_da.cmac.itag_tci.itag_tci & 0xFFFFFF;
            break;

        case TCAM_TYPE_CAPWAP_TUNNELID:
            p_tunnel_id_capwap_key_ptr = (ds_tunnel_id_capwap_key_t*)p_userid_key_ptr;

            p_tunnel_id_capwap_key_ptr->is_acl_qos_key = FALSE;
            p_tunnel_id_capwap_key_ptr->table_id = (ipe_user_id_ctl.lookup_ctl7 >> 3) & 0x7;
            p_tunnel_id_capwap_key_ptr->sub_table_id = ipe_user_id_ctl.lookup_ctl7 & 0x7;
            p_tunnel_id_capwap_key_ptr->rid = parser_result->l4_s.rid_ptp_bfd.rid_t.rid;
            p_tunnel_id_capwap_key_ptr->radio_mac_high = parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.radio_mac_47_32;
            p_tunnel_id_capwap_key_ptr->radio_mac_low = parser_result->l4_s.gre_bfd_ptp.radio_mac_31_0;
            break;

        case TCAM_TYPE_TRILL_TUNNELID:
            p_tunnel_id_trill_key_ptr = (ds_tunnel_id_trill_key_t*)p_userid_key_ptr;

            p_tunnel_id_trill_key_ptr->is_acl_qos_key = FALSE;
            p_tunnel_id_trill_key_ptr->table_id = (ipe_user_id_ctl.lookup_ctl8 >> 3) & 0x7;
            p_tunnel_id_trill_key_ptr->sub_table_id = ipe_user_id_ctl.lookup_ctl8 & 0x7;

            if (lookup_index == USERID_LOOKUP1) {
                if (p_user_id_info->trill_no_loop_ucast)
                {
                    /* unicast RPF */
                    p_tunnel_id_trill_key_ptr->trill_key_type = 0x2;
                }
                else if (p_user_id_info->trill_no_loop_mcast)
                {
                    /* multicast RPF */
                    p_tunnel_id_trill_key_ptr->trill_key_type = 0x3;
                }
                else if (p_user_id_info->trill_loop_mcast)
                {
                    /* multicast decapsulation */
                    p_tunnel_id_trill_key_ptr->trill_key_type = 0x1;
                }
                else
                {
                    p_tunnel_id_trill_key_ptr->trill_key_type = 0x7;
                }
            }
            else if (lookup_index == USERID_LOOKUP2)
            {
                if (p_user_id_info->trill_no_loop_ucast)
                {
                    /* unicast decapsulation */
                    p_tunnel_id_trill_key_ptr->trill_key_type = 0;
                }
                else if (p_user_id_info->trill_no_loop_mcast)
                {
                    /* multicast adjacency check */
                    p_tunnel_id_trill_key_ptr->trill_key_type = 0x4;
                }
                else
                {
                    p_tunnel_id_trill_key_ptr->trill_key_type = 0x7;
                }

            }

            p_tunnel_id_trill_key_ptr->global_src_port = p_user_id_info->global_src_port;
            p_tunnel_id_trill_key_ptr->ingress_nickname = ingress_nick_name;
            p_tunnel_id_trill_key_ptr->egress_nickname = egress_nick_name;
            p_tunnel_id_trill_key_ptr->ip_options = parser_result->l3_s.ip_options;
            p_tunnel_id_trill_key_ptr->ttl = parser_result->l3_s.ttl;
            p_tunnel_id_trill_key_ptr->trill_multicast = parser_result->l3_s.ip_da.trill.trill_multicast;
            p_tunnel_id_trill_key_ptr->trill_version = parser_result->l3_s.ip_da.trill.trill_version;
            break;

        default:
            break;
    }

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:       _cm_ipe_user_identify_lookup_tcam
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      p_in_pkt  --         pointer to buffer which save input packet and packet
 *                                  header ,and processing informations
 *             p_user_id_info  --   pointer to buffer which save user id temp variable
 *                                  used in user id
 * Output:     p_in_pkt  -- pointer to buffer which save input packet and packet
 *                          header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_lookup_tcam(ipe_in_pkt_t* p_in_pkt,
                                            user_id_info_t* p_user_id_info,
                                            uint8 lookup_index)
{

    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)p_in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *)pkt_info->parser_rslt;

    uint32 cmd = 0;
    void* p_da_ad = NULL;
    uint8 chip_id = p_in_pkt->chip_id;
    tcam_lkp_outputs_t tcam_lookup_result;
    tcam_lkp_inputs_t tcam_lookup_info;
    ds_user_id_mac_key_t ds_user_id_mac_key;
    ds_user_id_vlan_key_t ds_user_id_vlan_key;
    ds_tunnel_id_ipv4_key_t ds_tunnel_id_ipv4_key;
    ds_tunnel_id_ipv6_key_t ds_tunnel_id_ipv6_key;
    ds_user_id_ipv6_key_t ds_user_id_ipv6_key;
    ds_user_id_ipv4_key_t ds_user_id_ipv4_key;
    ds_tunnel_id_pbb_key_t ds_tunnel_id_pbb_key;
    ds_tunnel_id_capwap_key_t ds_tunnel_id_capwap_key;
    ds_tunnel_id_trill_key_t ds_tunnel_id_trill_key;
    ipe_user_id_ctl_t ipe_user_id_ctl;
    uint32 userid_tcam_type = p_user_id_info->per_lookup[lookup_index].userid_tcam_type;

    sal_memset(&tcam_lookup_info, 0, sizeof(tcam_lookup_info));
    sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_info));
    sal_memset(&ds_user_id_mac_key, 0, sizeof(ds_user_id_mac_key_t));
    sal_memset(&ds_user_id_vlan_key, 0, sizeof(ds_user_id_vlan_key_t));
    sal_memset(&ds_tunnel_id_ipv4_key, 0, sizeof(ds_tunnel_id_ipv4_key_t));
    sal_memset(&ds_tunnel_id_ipv6_key, 0, sizeof(ds_tunnel_id_ipv6_key_t));
    sal_memset(&ds_user_id_ipv6_key, 0, sizeof(ds_user_id_ipv6_key_t));
    sal_memset(&ds_user_id_ipv4_key, 0, sizeof(ds_user_id_ipv4_key_t));
    sal_memset(&ds_tunnel_id_pbb_key, 0, sizeof(ds_tunnel_id_pbb_key_t));
    sal_memset(&ds_tunnel_id_capwap_key, 0, sizeof(ds_tunnel_id_capwap_key_t));
    sal_memset(&ds_tunnel_id_trill_key, 0, sizeof(ds_tunnel_id_trill_key_t));

    sal_memset(&ipe_user_id_ctl, 0, sizeof(ipe_user_id_ctl));
    cmd = DRV_IOR(IpeUserIdCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_user_id_ctl));

    p_da_ad = &p_user_id_info->per_lookup[lookup_index].tcam_ds_user_id;
    p_user_id_info->per_lookup[lookup_index].tcam_lookup_result.tcam_lkp_output[0].ds_ad = p_da_ad;

    switch (userid_tcam_type)
    {
        case USERID_PORT_TCAM_TYPE_MAC_SA:
            tcam_lookup_info.chip_id = p_in_pkt->chip_id;
            tcam_lookup_info.tcam_key_size = ((ipe_user_id_ctl.lookup_ctl0 >> 5) & 0x3);
            tcam_lookup_info.tcam_key_type = TCAM_TYPE_MAC_USERID;
            tcam_lookup_info.tcam_key = &ds_user_id_mac_key;
            break;

        case USERID_PORT_TCAM_TYPE_IP:
            if (L3_TYPE_IPV6 == parser_result->layer3_type)
            {
                if (p_user_id_info->ds_phy_port_ext.disable_user_id_ipv6)
                {
                    /* No User ID TCAM lookup performed */
                    p_user_id_info->per_lookup[lookup_index].tcam_no_lookup = TRUE;
                }
                else if (!p_user_id_info->ds_phy_port_ext.force_user_id_ipv6_to_mac_key)
                {
                    /* IPv6 UserId */
                    tcam_lookup_info.chip_id = p_in_pkt->chip_id;
                    tcam_lookup_info.tcam_key_size = ((ipe_user_id_ctl.lookup_ctl1 >> 5) & 0x3);
                    tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV6_USERID;
                    tcam_lookup_info.tcam_key = &ds_user_id_ipv6_key;
                 }
                else
                {
                    /* MAC UserId */
                    tcam_lookup_info.chip_id = p_in_pkt->chip_id;
                    tcam_lookup_info.tcam_key_size = ((ipe_user_id_ctl.lookup_ctl0 >> 5) & 0x3);
                    tcam_lookup_info.tcam_key_type = TCAM_TYPE_MAC_USERID;
                    tcam_lookup_info.tcam_key = &ds_user_id_mac_key;
                 }
            }
            else if ((L3_TYPE_IPV4 == parser_result->layer3_type)
                    || ((L3_TYPE_ARP == parser_result->layer3_type)
                    && ipe_user_id_ctl.arp_force_ipv4))
            {
                if (p_user_id_info->ds_phy_port_ext.disable_user_id_ipv4)
                {
                    /* No User ID TCAM lookup performed */
                    p_user_id_info->per_lookup[lookup_index].tcam_no_lookup = TRUE;
                }
                else if (!p_user_id_info->ds_phy_port_ext.force_user_id_ipv4_to_mac_key)
                {
                    /* IPv4 UserId */
                    tcam_lookup_info.chip_id = p_in_pkt->chip_id;
                    tcam_lookup_info.tcam_key_size = ((ipe_user_id_ctl.lookup_ctl2 >> 5) & 0x3);
                    tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV4_USERID;
                    tcam_lookup_info.tcam_key = &ds_user_id_ipv4_key;
                 }
                else
                {
                    /* MAC UserId */
                    tcam_lookup_info.chip_id = p_in_pkt->chip_id;
                    tcam_lookup_info.tcam_key_size = ((ipe_user_id_ctl.lookup_ctl0 >> 5) & 0x3);
                    tcam_lookup_info.tcam_key_type = TCAM_TYPE_MAC_USERID;
                    tcam_lookup_info.tcam_key = &ds_user_id_mac_key;
                 }
            }
            else if (ipe_user_id_ctl.force_mac_key)
            {
                /* MAC UserId */
                tcam_lookup_info.chip_id = p_in_pkt->chip_id;
                tcam_lookup_info.tcam_key_size = ((ipe_user_id_ctl.lookup_ctl0 >> 5) & 0x3);
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_MAC_USERID;
                tcam_lookup_info.tcam_key = &ds_user_id_mac_key;
             }
            else
            {
                /* No User ID TCAM lookup performed */
                p_user_id_info->per_lookup[lookup_index].tcam_no_lookup = TRUE;
            }
            break;

        case USERID_PORT_TCAM_TYPE_VLAN:
            /* VLAN key */
            tcam_lookup_info.chip_id = p_in_pkt->chip_id;
            tcam_lookup_info.tcam_key_size = ((ipe_user_id_ctl.lookup_ctl3 >> 5) & 0x3);
            tcam_lookup_info.tcam_key_type = TCAM_TYPE_VLAN_USERID;
            tcam_lookup_info.tcam_key = &ds_user_id_vlan_key;
            break;

        case USERID_PORT_TCAM_TYPE_IP_TUNNEL:
            if (L3_TYPE_IPV6 == parser_result->layer3_type)
            {
                /* Ipv6 tunnel */
                tcam_lookup_info.chip_id = p_in_pkt->chip_id;
                tcam_lookup_info.tcam_key_size = ((ipe_user_id_ctl.lookup_ctl4 >> 6) & 0x3);
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV6_TUNNELID;
                tcam_lookup_info.tcam_key = &ds_user_id_ipv6_key;
            }
            else if (L3_TYPE_IPV4 == parser_result->layer3_type)
            {
                /* Ipv4 tunnel, gre key, udp */
                tcam_lookup_info.chip_id = p_in_pkt->chip_id;
                tcam_lookup_info.tcam_key_size = ((ipe_user_id_ctl.lookup_ctl5 >> 6) & 0x3);
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_IPV4_TUNNELID;
                tcam_lookup_info.tcam_key = &ds_user_id_ipv4_key;
            }
            else
            {
                /* No User ID TCAM lookup performed */
                p_user_id_info->per_lookup[lookup_index].tcam_no_lookup = TRUE;
            }
            break;

        case USERID_PORT_TCAM_TYPE_PBB:
            /* PBB key */
            if (L3_TYPE_CMAC == parser_result->layer3_type)    /* only for PBB packet */
            {
                tcam_lookup_info.chip_id = p_in_pkt->chip_id;
                tcam_lookup_info.tcam_key_size = ((ipe_user_id_ctl.lookup_ctl6 >> 6) & 0x3);
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_PBB_TUNNELID;
                tcam_lookup_info.tcam_key = &ds_tunnel_id_pbb_key;
            }
            else
            {
                /* No User ID TCAM lookup performed */
                p_user_id_info->per_lookup[lookup_index].tcam_no_lookup = TRUE;
            }

            break;

        case USERID_PORT_TCAM_TYPE_CAPWAP:
            /* CAPWAP key */
            if (L4_USER_TYPE_UDP_CAPWAP == parser_result->l4_s.layer4_user_type)  /* only for CAPWAP packet */
            {
                tcam_lookup_info.chip_id = p_in_pkt->chip_id;
                tcam_lookup_info.tcam_key_size = 0;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_CAPWAP_TUNNELID;
                tcam_lookup_info.tcam_key = &ds_tunnel_id_capwap_key;
            }
            else
            {
                /* No User ID TCAM lookup performed */
                p_user_id_info->per_lookup[lookup_index].tcam_no_lookup = TRUE;
            }

            break;

        case USERID_PORT_TCAM_TYPE_TRILL:
            /* TRILL key */
            if (L3_TYPE_TRILL == parser_result->layer3_type)  /* only for TRILL packeta */
            {
                tcam_lookup_info.chip_id = p_in_pkt->chip_id;
                tcam_lookup_info.tcam_key_size = 0;
                tcam_lookup_info.tcam_key_type = TCAM_TYPE_TRILL_TUNNELID;
                tcam_lookup_info.tcam_key = &ds_tunnel_id_trill_key;
            }
            else
            {
                /* No User ID TCAM lookup performed */
                p_user_id_info->per_lookup[lookup_index].tcam_no_lookup = TRUE;
            }

            break;

         default:
            break;
    }

    if (!p_user_id_info->per_lookup[lookup_index].tcam_no_lookup)
    {
        DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_construct_tcam_key(tcam_lookup_info.tcam_key_type,
                            p_in_pkt, tcam_lookup_info.tcam_key, p_user_id_info, lookup_index));

        DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info,
                            &p_user_id_info->per_lookup[lookup_index].tcam_lookup_result));
    }

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:       _cm_ipe_user_identify_lookup_user_id_hash
 * Purpose:    handle IPE user identification perform user id hash lookup.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header, and processing informations
 *             lookup_index -- specify the user id hash lookup index
 *             p_user_id_info  --  pointer to buffer which save info to perform lookup
 * Output:     p_user_id_info  --  pointer to a struct used to store hash lookup result
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_lookup_hash(ipe_in_pkt_t* p_in_pkt,
                                            user_id_info_t* p_user_id_info,
                                            uint32 lookup_index)
{
    userid_key_t userid_key;
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    uint8 hash_use_da = p_user_id_info->per_lookup[lookup_index].hash_use_da;
    uint16 hash_global_src_port = p_user_id_info->per_lookup[lookup_index].hash_global_src_port;
    uint16 hash_lookup_use_label = p_user_id_info->per_lookup[lookup_index].hash_lookup_use_label;

    userid_key_type_t key_type = p_user_id_info->per_lookup[lookup_index].userid_hash_key_type;


    if (USERID_LOOKUP1 == lookup_index)
    {
        /* TrillMcAdj and TrillUc hash lkp only in UserID Lookup2 */
        if ((USERID_KEY_TYPE_TRILL_MC_ADJ == key_type)
            || (USERID_KEY_TYPE_TRILL_UC == key_type))
        {
            return DRV_E_NONE;
        }
    }
    else if (USERID_LOOKUP2 == lookup_index)
    {
        /* TrillMcRpf, TrillUcRpf and TrillMc hash lkp only in UserID Lookup1 */
        if ((USERID_KEY_TYPE_TRILL_UC_RPF == key_type)
            || (USERID_KEY_TYPE_TRILL_MC_RPF == key_type)
            || (USERID_KEY_TYPE_TRILL_MC == key_type))
        {
            return DRV_E_NONE;
        }
    }

    switch (key_type)
    {
        case USERID_KEY_TYPE_TWO_VLAN:  /* Port + svid + cvid */
            userid_key.xport.global.src = hash_global_src_port & 0x3FFF;
            userid_key.key.two_vlan.is_label = hash_lookup_use_label;
            userid_key.key.two_vlan.svlan_id = p_user_id_info->svlan_id;
            userid_key.key.two_vlan.cvlan_id = p_user_id_info->cvlan_id;
            break;

        case USERID_KEY_TYPE_SVLAN:    /* Port + svid */
            userid_key.xport.global.src = hash_global_src_port & 0x3FFF;
            userid_key.key.svlan.is_label = hash_lookup_use_label;
            userid_key.key.svlan.svlan_id = p_user_id_info->svlan_id;
            break;

        case USERID_KEY_TYPE_CVLAN:    /* Port + Cvid */
            userid_key.xport.global.src = hash_global_src_port & 0x3FFF;
            userid_key.key.cvlan.is_label = hash_lookup_use_label;
            userid_key.key.cvlan.cvlan_id = p_user_id_info->cvlan_id;
            break;

        case USERID_KEY_TYPE_SVLAN_COS:
            userid_key.xport.global.src = hash_global_src_port & 0x3FFF;
            userid_key.key.svlan_cos.is_label = hash_lookup_use_label;
            userid_key.key.svlan_cos.svlan_id = p_user_id_info->svlan_id;
            userid_key.key.svlan_cos.stag_cos = p_user_id_info->stag_cos;
            break;

        case USERID_KEY_TYPE_CVLAN_COS:     /* Port+cvid+ccos */
            userid_key.xport.global.src = hash_global_src_port & 0x3FFF;
            userid_key.key.cvlan_cos.is_label = hash_lookup_use_label;
            userid_key.key.cvlan_cos.cvlan_id = p_user_id_info->cvlan_id;
            userid_key.key.cvlan_cos.ctag_cos = p_user_id_info->ctag_cos;
            break;

        case USERID_KEY_TYPE_PORT_MAC_SA:
            userid_key.xport.global.src = hash_global_src_port & 0x3FFF;
            userid_key.key.port_mac_sa.is_label = hash_lookup_use_label;

            if ((pkt_info->capwap_tunnel_valid && pkt_info->capwap_tunnel_type
                && (ROAMING_HA == pkt_info->roaming_state) && !IS_BIT_SET(parser_result->l2_s.mac_da5, 0))
                || hash_use_da)
            {
                userid_key.key.port_mac_sa.is_mac_da = TRUE;
                userid_key.key.port_mac_sa.mac_sa_47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5,
                                                                       parser_result->l2_s.mac_da4);
                userid_key.key.port_mac_sa.mac_sa_31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3,
                                                                      parser_result->l2_s.mac_da2,
                                                                      parser_result->l2_s.mac_da1,
                                                                      parser_result->l2_s.mac_da0);
            }
            else
            {
                userid_key.key.port_mac_sa.is_mac_da = FALSE;
                userid_key.key.port_mac_sa.mac_sa_47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5,
                                                                       parser_result->l2_s.mac_sa4);
                userid_key.key.port_mac_sa.mac_sa_31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3,
                                                                      parser_result->l2_s.mac_sa2,
                                                                      parser_result->l2_s.mac_sa1,
                                                                      parser_result->l2_s.mac_sa0);
            }
            break;

        case USERID_KEY_TYPE_PORT_IPV4_SA:
            userid_key.xport.global.src = hash_global_src_port & 0x3FFF;
            userid_key.key.port_ipv4_sa.is_label = hash_lookup_use_label;
            userid_key.key.port_ipv4_sa.ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
            break;

        case USERID_KEY_TYPE_MAC_SA:   /* MAC SA */
            if ((pkt_info->capwap_tunnel_valid && pkt_info->capwap_tunnel_type
                && (ROAMING_HA == pkt_info->roaming_state) && !IS_BIT_SET(parser_result->l2_s.mac_da5, 0))
                || hash_use_da)
            {
                userid_key.key.mac_sa.is_mac_da = TRUE;
                userid_key.key.mac_sa.mac_sa_47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5,
                                                                  parser_result->l2_s.mac_da4);
                userid_key.key.mac_sa.mac_sa_31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3,
                                                                 parser_result->l2_s.mac_da2,
                                                                 parser_result->l2_s.mac_da1,
                                                                 parser_result->l2_s.mac_da0);
            }
            else
            {
                userid_key.key.mac_sa.is_mac_da = FALSE;
                userid_key.key.mac_sa.mac_sa_47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5,
                                                                  parser_result->l2_s.mac_sa4);
                userid_key.key.mac_sa.mac_sa_31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3,
                                                                 parser_result->l2_s.mac_sa2,
                                                                 parser_result->l2_s.mac_sa1,
                                                                 parser_result->l2_s.mac_sa0);
            }
            break;

        case USERID_KEY_TYPE_IPV4_SA:    /* Port + Ipv4SA */
            userid_key.key.ipv4_sa.ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
            break;

        case USERID_KEY_TYPE_PORT:    /* Port */
            userid_key.xport.global.src =  hash_global_src_port & 0x3FFF;
            userid_key.key.port.is_label = hash_lookup_use_label;
            break;

        case USERID_KEY_TYPE_L2:   /* L2 */
            userid_key.xport.global.src = hash_global_src_port & 0x3FFF;
            userid_key.key.L2.mac_da_47_32 = MAKE_UINT16(parser_result->l2_s.mac_da5,
                                                             parser_result->l2_s.mac_da4);
            userid_key.key.L2.mac_da_31_0 = MAKE_UINT32(parser_result->l2_s.mac_da3,
                                                            parser_result->l2_s.mac_da2,
                                                            parser_result->l2_s.mac_da1,
                                                            parser_result->l2_s.mac_da0);
            userid_key.key.L2.mac_sa_47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5,
                                                             parser_result->l2_s.mac_sa4);
            userid_key.key.L2.mac_sa_31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3,
                                                            parser_result->l2_s.mac_sa2,
                                                            parser_result->l2_s.mac_sa1,
                                                            parser_result->l2_s.mac_sa0);
            if (parser_result->l2_s.svlan_id_valid)
            {
                userid_key.key.L2.vlan_id = parser_result->l2_s.svlan_id;
                userid_key.key.L2.cos = parser_result->l2_s.stag_cos;
            }
            else
            {
                userid_key.key.L2.vlan_id = parser_result->l2_s.cvlan_id;
                userid_key.key.L2.cos = parser_result->l2_s.ctag_cos;
            }
            break;

        case USERID_KEY_TYPE_IPV6_SA:
            userid_key.key.ipv6_sa.ip_sa_127_96 = parser_result->l3_s.ip_sa.ipv6.ipsa_127_96;
            userid_key.key.ipv6_sa.ip_sa_95_64 = parser_result->l3_s.ip_sa.ipv6.ipsa_95_64;
            userid_key.key.ipv6_sa.ip_sa_63_32 = parser_result->l3_s.ip_sa.ipv6.ipsa_63_32;
            userid_key.key.ipv6_sa.ip_sa_31_0 = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
            break;

        case USERID_KEY_TYPE_IPV4_TUNNEL:
            userid_key.key.ipv4_tunnel.ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
            userid_key.key.ipv4_tunnel.ip_da = parser_result->l3_s.ip_da.ipv4.ipda;
            userid_key.key.ipv4_tunnel.layer4_type = parser_result->layer4_type;
            userid_key.xport.udp.src = 0;
            userid_key.xport.udp.dest = 0;
            break;

        case USERID_KEY_TYPE_IPV4_GRE_KEY:
            userid_key.key.ipv4_gre.ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
            userid_key.key.ipv4_gre.ip_da = parser_result->l3_s.ip_da.ipv4.ipda;
            userid_key.key.ipv4_gre.layer4_type = parser_result->layer4_type;
            userid_key.xport.udp.src = (parser_result->l4_s.gre_bfd_ptp.gre_key & 0xFFFF);
            userid_key.xport.udp.dest = (parser_result->l4_s.gre_bfd_ptp.gre_key >> 16);
            break;

        case USERID_KEY_TYPE_IPV4_UDP:
            userid_key.key.ipv4_udp.ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
            userid_key.key.ipv4_udp.ip_da = parser_result->l3_s.ip_da.ipv4.ipda;
            userid_key.key.ipv4_udp.layer4_type = parser_result->layer4_type;
            userid_key.xport.udp.src = parser_result->l4_s.l4_src_port.l4_source_port;
            userid_key.xport.udp.dest = parser_result->l4_s.l4_dst_port.l4_dest_port;
            break;

        case USERID_KEY_TYPE_PBB:
            userid_key.xport.global.src = (hash_global_src_port & 0x3FFF);
            userid_key.key.pbb.is_label = hash_lookup_use_label;
            userid_key.key.pbb.is_id = parser_result->l3_s.ip_da.cmac.itag_tci.share.isid;
            break;

        case USERID_KEY_TYPE_CAPWAP:
            userid_key.key.capwap.rid = parser_result->l4_s.rid_ptp_bfd.rid_t.rid;
            userid_key.key.capwap.radio_mac_47_32 = parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.radio_mac_47_32;
            userid_key.key.capwap.radio_mac_31_0 = parser_result->l4_s.gre_bfd_ptp.radio_mac_31_0;
            break;

        case USERID_KEY_TYPE_TRILL_UC_RPF:
            userid_key.key.trill_uc_rpf.ingress_nick_name = parser_result->l3_s.ip_sa.trill.ingress_nick_name;
            break;

        case USERID_KEY_TYPE_TRILL_MC_RPF:
            userid_key.key.trill_mc_rpf.ingress_nick_name = parser_result->l3_s.ip_sa.trill.ingress_nick_name;
            userid_key.key.trill_mc_rpf.egress_nick_name = parser_result->l3_s.ip_da.trill.egress_nick_name;
            break;

        case USERID_KEY_TYPE_TRILL_MC:
            userid_key.key.trill_mc.ingress_nick_name = parser_result->l3_s.ip_sa.trill.ingress_nick_name;
            userid_key.key.trill_mc.egress_nick_name = parser_result->l3_s.ip_da.trill.egress_nick_name;
            break;

        case USERID_KEY_TYPE_TRILL_MC_ADJ:
            userid_key.xport.global.src = (hash_global_src_port & 0x3FFF);
            userid_key.key.trill_mc_adj.is_label = hash_lookup_use_label;
            userid_key.key.trill_mc_adj.egress_nick_name = parser_result->l3_s.ip_da.trill.egress_nick_name;
            break;

        case USERID_KEY_TYPE_TRILL_UC:
            userid_key.key.trill_uc.ingress_nick_name = parser_result->l3_s.ip_sa.trill.ingress_nick_name;
            userid_key.key.trill_uc.egress_nick_name = parser_result->l3_s.ip_da.trill.egress_nick_name;
            break;

        case USERID_KEY_TYPE_IPV4_RPF:
            userid_key.key.ipv4_rpf.ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
            break;

        default:
            p_user_id_info->per_lookup[lookup_index].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
            CMODEL_DEBUG_OUT_INFO("@@@ Invalid UserID Hash Type!!\n");
            return DRV_E_NONE;
    }

    DRV_IF_ERROR_RETURN(cm_com_userid_hash_lookup_request(p_in_pkt->chip_id,pkt_info->local_phy_port,
                        &userid_key,key_type,USERID_DIRECTION_IPE_USERID,
                        &(p_user_id_info->per_lookup[lookup_index].hash_lookup_result)));

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:       _cm_ipe_user_identify_capwap_client_process
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      p_in_pkt -- pointer to buffer which save input packet and packet
 *                                  header ,and processing informations
 *             p_user_id_info -- pointer to buffer which save user id temp variable
 *                                  used in user id
 * Output:     p_in_pkt -- pointer to buffer which save input packet and packet
 *                          header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_capwap_client_process(ipe_in_pkt_t* p_in_pkt,
                                                         user_id_info_t*  p_user_id_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    parsing_result_t* parser_result = pkt_info->parser_rslt;
    ipe_user_id_ctl_t ipe_user_id_ctl;
    uint32 cmd = 0;

    if (pkt_info->capwap_tunnel_valid && pkt_info->capwap_tunnel_type)
    {
        /* from AC */
        if (ROAMING_HA == p_user_id_info->user_id_roaming_state)/* Receiving AC is HA, from FA, macSa must be roaming-out */
        {
            if (ROAMING_FA != pkt_info->roaming_state)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard = TRUE;
                    pkt_info->discard_type = IPE_DISCARD_CAPWAP_FROM_AC_ERR_OR_UNEXPECTABLE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! CAPWAP from AC error discard!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
            else if (pkt_info->logic_src_port != p_user_id_info->capwap_logic_src_port)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard = TRUE;
                    pkt_info->discard_type = IPE_DISCARD_CAPWAP_BSSID_LKP_OR_LOGIC_PORT_CHK_DISCARD;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! AC2AC tunnel from ROC logic port check fail discard!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
            else
            {
                pkt_info->roaming_state = ROAMING_HA;
            }
        }
        else if (ROAMING_FA == p_user_id_info->user_id_roaming_state)/* Receiving AC is FA, from HA, macDa must be roaming-in */
        {
            pkt_info->logic_src_port = p_user_id_info->ac_logic_port;

            if (ROAMING_HA != pkt_info->roaming_state)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard = TRUE;
                    pkt_info->discard_type = IPE_DISCARD_CAPWAP_FROM_AC_ERR_OR_UNEXPECTABLE;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! CAPWAP from AC error discard!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
            else if (pkt_info->logic_src_port != p_user_id_info->capwap_logic_src_port)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard = TRUE;
                    pkt_info->discard_type = IPE_DISCARD_CAPWAP_BSSID_LKP_OR_LOGIC_PORT_CHK_DISCARD;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! AC2AC tunnel to RIC logic port check fail discard!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
            else
            {
                pkt_info->roaming_state = ROAMING_FA;
                pkt_info->deny_bridge = TRUE;
                pkt_info->deny_learning = TRUE;
                pkt_info->route_disable = TRUE;
                pkt_info->ds_fwd_ptr = p_user_id_info->wtp_ds_fwd_ptr;/*forwarding to wtp*/
                pkt_info->ds_fwd_ptr_valid = TRUE;
            }
        }
        else if ((NONE_HA_FA_MODEL == p_user_id_info->user_id_roaming_state)
                || IS_BIT_SET(parser_result->l2_s.mac_da5, 0))
        {
            /* Non HA/FA Model*/
        }
        else
        {
            /* unexpectable discard, unauthenticated client, roamingState[1:0] 2'b00 */
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_CAPWAP_FROM_AC_ERR_OR_UNEXPECTABLE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! CAPWAP from ac is unauthenticated client discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }
    else if (pkt_info->capwap_tunnel_valid)
    {
        /* from WTP */
        if (ROAMING_HA == p_user_id_info->user_id_roaming_state)
        {
            pkt_info->roaming_state = ROAMING_HA;
        }
        else if (ROAMING_FA == p_user_id_info->user_id_roaming_state)
        {
            sal_memset(&ipe_user_id_ctl, 0, sizeof(ipe_user_id_ctl));
            cmd = DRV_IOR(IpeUserIdCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_in_pkt->chip_id, 0, cmd, &ipe_user_id_ctl));

            /* forwarding to HA by DsUserId */
            pkt_info->deny_bridge = !ipe_user_id_ctl.capwap_ac_ha_permit_bridge;
            pkt_info->deny_learning = !ipe_user_id_ctl.capwap_ac_ha_permit_learning;
            pkt_info->route_disable = !ipe_user_id_ctl.capwap_ac_ha_permit_route;
            pkt_info->roaming_state = ROAMING_FA;
        }
        else if (NONE_HA_FA_MODEL == p_user_id_info->user_id_roaming_state)
        {
            ;
        }
        else
        {
            /* unexpectable discard */
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_CAPWAP_FROM_AC_ERR_OR_UNEXPECTABLE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! CAPWAP from wtp is unauthenticated client discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (pkt_info->logic_src_port != p_user_id_info->capwap_logic_src_port)
        {
             if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_CAPWAP_BSSID_LKP_OR_LOGIC_PORT_CHK_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! WTP2AC tunnel logic port check fail discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }
    else
    {
        pkt_info->roaming_state = p_user_id_info->user_id_roaming_state;
    }

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:       _cm_ipe_user_identify_escape_bpdu_protocol
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      p_in_pkt  --         pointer to buffer which save input packet and packet
 *                                  header ,and processing informations
 *             p_user_id_info  --   pointer to buffer which save user id temp variable
 *                                  used in user id
 * Output:     p_in_pkt  -- pointer to buffer which save input packet and packet
 *                          header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_escape_bpdu_protocol(ipe_in_pkt_t* p_in_pkt, user_id_info_t* p_user_id_info)
{

    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    ipe_user_id_ctl_t ipe_user_id_ctl;

    uint8 bpdu_escape = 0;
    uint8 bpdu_protocol_escape_cam_hit = FALSE;
    uint8 bpdu_protocol_escape_cam_hit2 = FALSE;
    uint8 bpdu_protocol_escape_cam_hit3 = FALSE;
    uint8 bpdu_protocol_escape_cam_hit4 = FALSE;
    uint8 chip_id = p_in_pkt->chip_id;
    uint8 exception_sub_index = 0;
    uint8 exception_sub_index2 = 0;
    uint8 exception_sub_index3 = 0;
    uint8 exception_sub_index4 = 0;
    uint8 cam_index = 0;

    uint16 macda_upper16 = 0;
    uint16 ether_type = 0;

    uint32 mac_da = 0;
    uint32 macda_lower32 = 0;
    uint32 cmd = 0;

    ipe_bpdu_protocol_escape_cam_t bpdu_protocol_escape_cam;
    ipe_bpdu_protocol_escape_cam2_t bpdu_protocol_escape_cam2;
    ipe_bpdu_protocol_escape_cam3_t bpdu_protocol_escape_cam3;
    ipe_bpdu_protocol_escape_cam4_t bpdu_protocol_escape_cam4;
    ipe_bpdu_protocol_escape_cam_result_t bpdu_protocol_escape_cam_result;
    ipe_bpdu_protocol_escape_cam_result2_t bpdu_protocol_escape_cam_result2;
    ipe_bpdu_protocol_escape_cam_result3_t bpdu_protocol_escape_cam_result3;
    ipe_bpdu_protocol_escape_cam_result4_t bpdu_protocol_escape_cam_result4;
    ipe_bpdu_escape_ctl_t bpdu_escape_ctl;
    ipe_bpdu_ptl_esp_cam_c_t ptl_esc_cam_tmp;
    ipe_bpdu_ptl_esp_cam_rst_c_t ptl_escp_rst_tmp;
    ipe_bpdu_ptl_esp_cam2_c_t ptl_esc_cam2_tmp;
    ipe_bpdu_ptl_esp_cam_rst_c_t ptl_escp_rst2_tmp;


    sal_memset(&ipe_user_id_ctl, 0, sizeof(ipe_user_id_ctl));
    cmd = DRV_IOR(IpeUserIdCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_in_pkt->chip_id, 0, cmd, &ipe_user_id_ctl));

    sal_memset(&bpdu_protocol_escape_cam, 0, sizeof(bpdu_protocol_escape_cam));
    sal_memset(&bpdu_protocol_escape_cam_result, 0, sizeof(bpdu_protocol_escape_cam_result));
    sal_memset(&bpdu_protocol_escape_cam2, 0, sizeof(bpdu_protocol_escape_cam2));
    sal_memset(&bpdu_protocol_escape_cam_result2, 0, sizeof(bpdu_protocol_escape_cam_result2));
    sal_memset(&bpdu_protocol_escape_cam3, 0, sizeof(bpdu_protocol_escape_cam3));
    sal_memset(&bpdu_protocol_escape_cam_result3, 0, sizeof(bpdu_protocol_escape_cam_result3));
    sal_memset(&bpdu_protocol_escape_cam4, 0, sizeof(bpdu_protocol_escape_cam4));
    sal_memset(&bpdu_protocol_escape_cam_result4, 0, sizeof(bpdu_protocol_escape_cam_result4));
    sal_memset(&bpdu_escape_ctl, 0, sizeof(bpdu_escape_ctl));

    /* BPDU_PROTOCOL_ESCAPE */
    macda_lower32 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);

    macda_upper16 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);

    ether_type = parser_result->l2_s.layer2_header_protocol;

    /* bpdu cam */
    cmd = DRV_IOR(IpeBpduProtocolEscapeCam_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &bpdu_protocol_escape_cam));

    cmd = DRV_IOR(IpeBpduProtocolEscapeCamResult_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &bpdu_protocol_escape_cam_result));

    for (cam_index = 0; cam_index < 4; cam_index++)
    {
        sal_memset(&ptl_esc_cam_tmp, 0, sizeof(ptl_esc_cam_tmp));
        sal_memset(&ptl_escp_rst_tmp, 0, sizeof(ptl_escp_rst_tmp));

        switch (cam_index)
        {
            case 0:
                ptl_esc_cam_tmp.mac_da_value_low = bpdu_protocol_escape_cam.mac_da_value0_low;
                ptl_esc_cam_tmp.mac_da_value_up = bpdu_protocol_escape_cam.mac_da_value0_high;
                ptl_escp_rst_tmp.entry_valid = bpdu_protocol_escape_cam_result.cam1_entry_valid0;
                ptl_escp_rst_tmp.exception_sub_index = bpdu_protocol_escape_cam_result.cam1_exception_sub_index0;
                break;
            case 1:
                ptl_esc_cam_tmp.mac_da_value_low = bpdu_protocol_escape_cam.mac_da_value1_low;
                ptl_esc_cam_tmp.mac_da_value_up = bpdu_protocol_escape_cam.mac_da_value1_high;
                ptl_escp_rst_tmp.entry_valid = bpdu_protocol_escape_cam_result.cam1_entry_valid1;
                ptl_escp_rst_tmp.exception_sub_index = bpdu_protocol_escape_cam_result.cam1_exception_sub_index1;
                break;
            case 2:
                ptl_esc_cam_tmp.mac_da_value_low = bpdu_protocol_escape_cam.mac_da_value2_low;
                ptl_esc_cam_tmp.mac_da_value_up = bpdu_protocol_escape_cam.mac_da_value2_high;
                ptl_escp_rst_tmp.entry_valid = bpdu_protocol_escape_cam_result.cam1_entry_valid2;
                ptl_escp_rst_tmp.exception_sub_index = bpdu_protocol_escape_cam_result.cam1_exception_sub_index2;
                break;
            case 3:
                ptl_esc_cam_tmp.mac_da_value_low = bpdu_protocol_escape_cam.mac_da_value3_low;
                ptl_esc_cam_tmp.mac_da_value_up = bpdu_protocol_escape_cam.mac_da_value3_high;
                ptl_escp_rst_tmp.entry_valid = bpdu_protocol_escape_cam_result.cam1_entry_valid3;
                ptl_escp_rst_tmp.exception_sub_index = bpdu_protocol_escape_cam_result.cam1_exception_sub_index3;
                break;
            default:
                break;
        }

        if ((macda_lower32 == ptl_esc_cam_tmp.mac_da_value_low)
            && (macda_upper16 == ptl_esc_cam_tmp.mac_da_value_up))
        {
            if (ptl_escp_rst_tmp.entry_valid)
            {
                bpdu_protocol_escape_cam_hit = TRUE;
                exception_sub_index = ptl_escp_rst_tmp.exception_sub_index;
                break;
            }
        }
    }

    if ((parser_result->l2_s.mac_da5 == 0x01)
        && (parser_result->l2_s.mac_da4 == 0x80)
        && (parser_result->l2_s.mac_da3 == 0xc2))
    {
        /* BPDU Cam2 */
        cmd = DRV_IOR(IpeBpduProtocolEscapeCam2_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &bpdu_protocol_escape_cam2));

        cmd = DRV_IOR(IpeBpduProtocolEscapeCamResult2_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &bpdu_protocol_escape_cam_result2));

        /*lookup use macda[23:0]*/
        for (cam_index = 0; cam_index < 2; cam_index ++)
        {
            sal_memset(&ptl_esc_cam2_tmp, 0, sizeof(ptl_esc_cam2_tmp));
            sal_memset(&ptl_escp_rst2_tmp, 0, sizeof(ptl_escp_rst2_tmp));

            switch (cam_index)
            {
                case 0:
                    ptl_esc_cam2_tmp.mac_da_mask = bpdu_protocol_escape_cam2.mac_da_mask0;
                    ptl_esc_cam2_tmp.mac_da_value = bpdu_protocol_escape_cam2.mac_da_value0;
                    ptl_escp_rst2_tmp.entry_valid = bpdu_protocol_escape_cam_result2.cam2_entry_valid0;
                    ptl_escp_rst2_tmp.exception_sub_index = bpdu_protocol_escape_cam_result2.cam2_exception_sub_index0;
                    break;
                case 1:
                    ptl_esc_cam2_tmp.mac_da_mask = bpdu_protocol_escape_cam2.mac_da_mask1;
                    ptl_esc_cam2_tmp.mac_da_value = bpdu_protocol_escape_cam2.mac_da_value1;
                    ptl_escp_rst2_tmp.entry_valid = bpdu_protocol_escape_cam_result2.cam2_entry_valid1;
                    ptl_escp_rst2_tmp.exception_sub_index = bpdu_protocol_escape_cam_result2.cam2_exception_sub_index1;
                    break;
                default:
                    break;
            }

            if (((ptl_esc_cam2_tmp.mac_da_value & ptl_esc_cam2_tmp.mac_da_mask)& 0xFFFFFF)
                    == ((ptl_esc_cam2_tmp.mac_da_mask & macda_lower32) & 0xFFFFFF))
            {
                if (ptl_escp_rst2_tmp.entry_valid)
                {
                    bpdu_protocol_escape_cam_hit2 = TRUE;
                    exception_sub_index2 = ptl_escp_rst2_tmp.exception_sub_index;
                    break;
                }
            }
        }

        /* BPDU Cam4 */
        cmd = DRV_IOR(IpeBpduProtocolEscapeCam4_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &bpdu_protocol_escape_cam4));

        /* mac_da */
        for (cam_index = 0; cam_index < IPE_BPDU_PROTOCOL_ESCAPE_CAM_RESULT4_MAX_INDEX; cam_index++)
        {
            switch (cam_index)
            {
                case 0:
                    mac_da = bpdu_protocol_escape_cam4.mac_da0;
                    break;
                case 1:
                    mac_da = bpdu_protocol_escape_cam4.mac_da1;
                    break;
                case 2:
                    mac_da = bpdu_protocol_escape_cam4.mac_da2;
                    break;
                case 3:
                    mac_da = bpdu_protocol_escape_cam4.mac_da3;
                    break;
                case 4:
                    mac_da = bpdu_protocol_escape_cam4.mac_da4;
                    break;
                case 5:
                    mac_da = bpdu_protocol_escape_cam4.mac_da5;
                    break;
                case 6:
                    mac_da = bpdu_protocol_escape_cam4.mac_da6;
                    break;
                case 7:
                    mac_da = bpdu_protocol_escape_cam4.mac_da7;
                    break;
                default:
                    break;
            }

            if (mac_da == MAKE_UINT32(0, parser_result->l2_s.mac_da2,
                                     parser_result->l2_s.mac_da1,
                                     parser_result->l2_s.mac_da0))
            {
                sal_memset(&bpdu_protocol_escape_cam_result4, 0, sizeof(ipe_bpdu_protocol_escape_cam4_t));
                cmd = DRV_IOR(IpeBpduProtocolEscapeCamResult4_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, cam_index, cmd, &bpdu_protocol_escape_cam_result4));

                if (bpdu_protocol_escape_cam_result4.cam4_entry_valid)
                {
                    bpdu_protocol_escape_cam_hit4 = TRUE;
                    exception_sub_index4 = bpdu_protocol_escape_cam_result4.cam4_exception_sub_index;
                    break;
                }
            }
        }
    }

    /* BPDU Cam3 */
    for (cam_index = 0; cam_index < IPE_BPDU_PROTOCOL_ESCAPE_CAM3_MAX_INDEX; cam_index++)
    {
        sal_memset(&bpdu_protocol_escape_cam3, 0, sizeof(bpdu_protocol_escape_cam3));
        cmd = DRV_IOR(IpeBpduProtocolEscapeCam3_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, cam_index, cmd, &bpdu_protocol_escape_cam3));

        sal_memset(&bpdu_protocol_escape_cam_result3, 0, sizeof(bpdu_protocol_escape_cam_result3));
        cmd = DRV_IOR(IpeBpduProtocolEscapeCamResult3_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, cam_index, cmd, &bpdu_protocol_escape_cam_result3));

        /*lookup use l2 protocol*/
        if (bpdu_protocol_escape_cam3.cam3_ether_type == ether_type)
        {
            if (bpdu_protocol_escape_cam_result3.cam3_entry_valid)
            {
                bpdu_protocol_escape_cam_hit3 = TRUE;
                exception_sub_index3 = bpdu_protocol_escape_cam_result3.cam3_exception_sub_index;
                break;
            }
        }
    }

    cmd = DRV_IOR(IpeBpduEscapeCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &bpdu_escape_ctl));

    if (IS_BIT_SET(bpdu_escape_ctl.bpdu_escape_en, 0) && bpdu_protocol_escape_cam_hit3)
    {
        SET_BIT(bpdu_escape, 0);
    }

    if (IS_BIT_SET(bpdu_escape_ctl.bpdu_escape_en, 1) && bpdu_protocol_escape_cam_hit)
    {
        SET_BIT(bpdu_escape, 1);
    }

    if (IS_BIT_SET(bpdu_escape_ctl.bpdu_escape_en, 2) && bpdu_protocol_escape_cam_hit4)
    {
        SET_BIT(bpdu_escape, 2);
    }

    if (IS_BIT_SET(bpdu_escape_ctl.bpdu_escape_en, 3) && bpdu_protocol_escape_cam_hit2)
    {
        SET_BIT(bpdu_escape, 3);
    }

    if ((0x00 == parser_result->l2_s.mac_da0) && (0x00 == parser_result->l2_s.mac_da1)
        && (0x00 == parser_result->l2_s.mac_da2) && (0xC2 == parser_result->l2_s.mac_da3)
        && (0x80 == parser_result->l2_s.mac_da4) && (0x01 == parser_result->l2_s.mac_da5)
        && bpdu_escape_ctl.bpdu_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = bpdu_escape_ctl.bpdu_exception_sub_index;
    }
    else if ((0x8809 == ether_type) && bpdu_escape_ctl.slow_protocol_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = bpdu_escape_ctl.slow_protocol_exception_sub_index;
    }
    else if ((0x888E == ether_type) && bpdu_escape_ctl.eapol_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = bpdu_escape_ctl.eapol_exception_sub_index;
    }
    else if ((0x88CC == ether_type) && bpdu_escape_ctl.lldp_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = bpdu_escape_ctl.lldp_exception_sub_index;
    }
    else if ((0x22F4 == ether_type) && bpdu_escape_ctl.l2isis_exception_en && !pkt_info->exception_en)
    {
        /* for trill */
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
        pkt_info->exception_sub_index = bpdu_escape_ctl.l2isis_exception_sub_index;
    }
    else if (!pkt_info->exception_en)
    {
        if (IS_BIT_SET(bpdu_escape, 0))
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
            pkt_info->exception_sub_index = exception_sub_index3;
        }
        else if (IS_BIT_SET(bpdu_escape, 1))
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
            pkt_info->exception_sub_index = exception_sub_index;
        }
        else if (IS_BIT_SET(bpdu_escape, 2))
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
            pkt_info->exception_sub_index = exception_sub_index4;
        }
        else if (IS_BIT_SET(bpdu_escape, 3))
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
            pkt_info->exception_sub_index = exception_sub_index2;
        }
    }

    if (pkt_info->exception_en
        && (EXCEPTION_TYPE_LAYER2 == pkt_info->exception_index)
        && (!IS_BIT_SET(pkt_info->exception_sub_index, 5))
        && (!ipe_user_id_ctl.layer2_protocol_tunnel_lm_disable)
        && IS_BIT_SET(p_user_id_info->ds_phy_port_ext.exception2_discard , pkt_info->exception_sub_index & 0x1F)
        && IS_BIT_SET(p_user_id_info->ds_phy_port_ext.exception2_en, pkt_info->exception_sub_index & 0x1F))
    {
        pkt_info->exception2_lm_en = TRUE;
        pkt_info->exception2_lm_up_en = TRUE;
        pkt_info->exception2_lm_down_en = TRUE;
    }
    else if (pkt_info->exception_en && (EXCEPTION_TYPE_LAYER2 == pkt_info->exception_index) && ipe_user_id_ctl.layer2_protocol_tunnel_lm_disable
        && (!IS_BIT_SET(pkt_info->exception_sub_index, 5)) && (IS_BIT_SET(p_user_id_info->ds_phy_port_ext.exception2_discard,pkt_info->exception_sub_index & 0x1F)
            || IS_BIT_SET(p_user_id_info->ds_phy_port_ext.exception2_en,pkt_info->exception_sub_index & 0x1F)))
    {
        pkt_info->exception2_lm_en = TRUE;

        if (IS_BIT_SET(ipe_user_id_ctl.exception2_lm_up_en,pkt_info->exception_sub_index & 0x1F))
        {
            pkt_info->exception2_lm_up_en = TRUE;
        }

        if (IS_BIT_SET(ipe_user_id_ctl.exception2_lm_down_en,pkt_info->exception_sub_index & 0x1F))
        {
            pkt_info->exception2_lm_down_en = TRUE;
        }
    }

    if (pkt_info->exception_en && (EXCEPTION_TYPE_LAYER2 == pkt_info->exception_index)
        && (IS_BIT_SET(pkt_info->exception_sub_index, 5)
            || !ipe_user_id_ctl.layer2_protocol_tunnel_lm_disable
            || IS_BIT_SET(p_user_id_info->ds_phy_port_ext.exception2_discard, (pkt_info->exception_sub_index & 0x1F))))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_EXCEP_2_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! Exception2 discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (pkt_info->exception_en && (EXCEPTION_TYPE_LAYER2 == pkt_info->exception_index)
        && (!IS_BIT_SET(pkt_info->exception_sub_index, 5))
        && !IS_BIT_SET(p_user_id_info->ds_phy_port_ext.exception2_en, (pkt_info->exception_sub_index & 0x1F)))
    {
        pkt_info->exception_en = 0;
    }

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:       _cm_ipe_user_identify_lookup_prepare1
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      p_in_pkt  --         pointer to buffer which save input packet and packet
 *                                  header ,and processing informations
 *             p_user_id_info  --   pointer to buffer which save user id temp variable
 *                                  used in user id
 * Output:     p_in_pkt  -- pointer to buffer which save input packet and packet
 *                          header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_lookup_prepare1(ipe_in_pkt_t* p_in_pkt, user_id_info_t* p_user_id_info)
{

    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    ds_vlan_range_profile_t ds_vlan_range_profile;
    uint32 cmd = 0;
    uint8 chip_id = p_in_pkt->chip_id;
    uint16 vlan_range_check_id = 0;
    uint8 vlan_range_valid = FALSE;
    uint16 vlan_range_max = 0;
    /* USER_ID_LOOKUP_PREPARE1 */
    p_user_id_info->exception2 = pkt_info->exception_en && (EXCEPTION_TYPE_LAYER2 == pkt_info->exception_index);
    p_user_id_info->exception_sub_index = pkt_info->exception_sub_index;

    /* CIP -> PIP: globalSrcPort + SvlanId => Isid & vrfid;
       PIP -> CIP: bvlanId + Isid => vrfid;
       CBP -> PNP: Isid => bvlan */
    if ((L3_TYPE_CMAC == parser_result->layer3_type)
        && ((PBB_PORT_TYPE_CBP == pkt_info->pbb_src_port_type)
            || (PBB_PORT_TYPE_PIP == pkt_info->pbb_src_port_type)))
    {
        p_user_id_info->customer_id_valid = TRUE;
        p_user_id_info->customer_id = parser_result->l3_s.ip_da.cmac.itag_tci.itag_tci;
    }
    else
    {
        p_user_id_info->customer_id_valid = pkt_info->customer_id_valid;
        p_user_id_info->customer_id = pkt_info->customer_id;
    }

    if (pkt_info->use_default_vlan_lookup)
    {
        /* userId MAC/IP Key svlanId[11:0] & cvlanId[11:0] */
        if (pkt_info->src_outer_vlan_is_svlan && !parser_result->l2_s.svlan_id_valid)
        {
            /* s untag */
            p_user_id_info->svlan_id = pkt_info->default_vlan_id;
            p_user_id_info->stag_cos = pkt_info->default_pcp;
            p_user_id_info->stag_cfi = pkt_info->default_dei;
        }
        else if (pkt_info->src_outer_vlan_is_svlan && (!parser_result->l2_s.svlan_id)
                && parser_result->l2_s.svlan_id_valid)
        {
            /* s pri-tag */
            p_user_id_info->svlan_id = pkt_info->default_vlan_id;
        }
        else if ((!pkt_info->src_outer_vlan_is_svlan) && (!parser_result->l2_s.cvlan_id_valid))
        {
            /* c untag */
            p_user_id_info->cvlan_id = pkt_info->default_vlan_id;
            p_user_id_info->ctag_cos = pkt_info->default_pcp;
            p_user_id_info->ctag_cfi = pkt_info->default_dei;
        }
        else if ((!pkt_info->src_outer_vlan_is_svlan) && (!parser_result->l2_s.cvlan_id)
                && parser_result->l2_s.cvlan_id_valid)
        {
            /* c pri-tag */
            p_user_id_info->cvlan_id = pkt_info->default_vlan_id;
        }
    }

    if (pkt_info->vlan_range_profile_en)
    {
        if (parser_result->l2_s.svlan_id_valid && (p_user_id_info->svlan_id & 0xFFF)
            && pkt_info->vlan_range_type)
        {
            vlan_range_check_id = p_user_id_info->svlan_id & 0xFFF;
        }
        else if (parser_result->l2_s.cvlan_id_valid && (p_user_id_info->cvlan_id & 0xFFF)
                 && !pkt_info->vlan_range_type)
        {
            vlan_range_check_id = p_user_id_info->cvlan_id & 0xFFF;
        }
        else
        {
            vlan_range_check_id = pkt_info->use_default_vlan_lookup ? pkt_info->default_vlan_id : 0;
        }

        sal_memset(&ds_vlan_range_profile, 0, sizeof(ds_vlan_range_profile));
        cmd = DRV_IOR(DsVlanRangeProfile_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->vlan_range_profile, cmd,
                            &ds_vlan_range_profile));

        if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max0)
             && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min0)
             && (ds_vlan_range_profile.vlan_max0 != ds_vlan_range_profile.vlan_min0))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max0;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max1)
                 && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min1)
                 && (ds_vlan_range_profile.vlan_max1 != ds_vlan_range_profile.vlan_min1))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max1;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max2)
                 && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min2)
                 && (ds_vlan_range_profile.vlan_max2 != ds_vlan_range_profile.vlan_min2))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max2;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max3)
                && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min3)
                && (ds_vlan_range_profile.vlan_max3 != ds_vlan_range_profile.vlan_min3))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max3;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max4)
                && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min4)
                && (ds_vlan_range_profile.vlan_max4 != ds_vlan_range_profile.vlan_min4))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max4;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max5)
                 && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min5)
                 && (ds_vlan_range_profile.vlan_max5 != ds_vlan_range_profile.vlan_min5))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max5;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max6)
                 && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min6)
                 && (ds_vlan_range_profile.vlan_max6 != ds_vlan_range_profile.vlan_min6))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max6;
            vlan_range_valid = TRUE;
        }
        else if ((vlan_range_check_id <= ds_vlan_range_profile.vlan_max7)
                && (vlan_range_check_id >= ds_vlan_range_profile.vlan_min7)
                && (ds_vlan_range_profile.vlan_max7 != ds_vlan_range_profile.vlan_min7))
        {
            vlan_range_max = ds_vlan_range_profile.vlan_max7;
            vlan_range_valid = TRUE;
        }
        else
        {
            vlan_range_max = 0;
            vlan_range_valid = FALSE;
        }

        if (vlan_range_valid && pkt_info->vlan_range_type)
        {
            p_user_id_info->svlan_id = vlan_range_max;
        }
        else if (vlan_range_valid && !pkt_info->vlan_range_type)
        {
            p_user_id_info->cvlan_id = vlan_range_max;
        }
    }

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:       _cm_ipe_user_identify_lookup_prepare2
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      p_in_pkt        --   pointer to buffer which save input packet and packet
 *                                  header ,and processing informations
 *             p_user_id_info  --   pointer to buffer which save user id temp variable
 *                                  used in user id
 * Output:     p_in_pkt        --   pointer to buffer which save input packet and packet
 *                                  header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_lookup_prepare2(ipe_in_pkt_t* p_in_pkt, user_id_info_t* p_user_id_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    uint8 lookup = 0;
    uint8 capwap_hash_en[USERID_LOOKUP_NUM] = {0};
    uint8 pbb_hash_en[USERID_LOOKUP_NUM] = {0};
    uint8 ipv4_tunnel_hash_en[USERID_LOOKUP_NUM] = {0};
    uint8 ipv4_udp_tunnel_hash_en[USERID_LOOKUP_NUM] = {0};
    uint8 ipv4_gre_tunnel_hash_en[USERID_LOOKUP_NUM] = {0};
    uint8 port_hash_type[USERID_LOOKUP_NUM] = {0};
    uint8 is_ipv4 = FALSE;
    uint8 is_gre = FALSE;
    uint8 is_udp = FALSE;
    uint8 is_gre_key = FALSE;
    uint8 is_ip_in_ip = FALSE;
    uint8 is_v6_in_ip = FALSE;
    uint8 is_cap_wap = FALSE;
    uint8 is_trill = FALSE;
    uint8 is_cmac = FALSE;

    is_ipv4 = (L3_TYPE_IPV4 == parser_result->layer3_type);
    is_gre = (L4_TYPE_GRE == parser_result->layer4_type);
    is_udp = (L4_TYPE_UDP == parser_result->layer4_type);
    is_gre_key = (IS_BIT_SET(parser_result->l4_s.l4_src_port.gre_flags, 13));
    is_ip_in_ip = (L4_TYPE_IP_IN_IP == parser_result->layer4_type);
    is_v6_in_ip = (L4_TYPE_V6_IN_IP == parser_result->layer4_type);
    is_cmac = (L3_TYPE_CMAC == parser_result->layer3_type);
    is_cap_wap = (L4_USER_TYPE_UDP_CAPWAP == parser_result->l4_s.layer4_user_type);
    is_trill = (L3_TYPE_TRILL == parser_result->layer3_type);

    p_user_id_info->is_trill_mcast = parser_result->l3_s.ip_da.trill.trill_multicast;

    p_user_id_info->trill_no_loop_ucast = (!p_user_id_info->ds_phy_port_ext.trill_mcast_loopback)
                                           && (!p_user_id_info->is_trill_mcast)
                                           && is_trill;

    p_user_id_info->trill_no_loop_mcast = (!p_user_id_info->ds_phy_port_ext.trill_mcast_loopback)
                                           && p_user_id_info->is_trill_mcast
                                           && is_trill;

    p_user_id_info->trill_loop_mcast = p_user_id_info->ds_phy_port_ext.trill_mcast_loopback
                                       && p_user_id_info->is_trill_mcast
                                       && is_trill;

    /* Trill, uc hash is TRILLUCRPF and TRILLUC, mc hash is TRILLMCRPF and TRILLMCADJ,
       after loopback mc hash is TRILLMC.*/
    capwap_hash_en[USERID_LOOKUP1] = p_user_id_info->ds_phy_port_ext.capwap_hash_en1;
    capwap_hash_en[USERID_LOOKUP2] = p_user_id_info->ds_phy_port_ext.capwap_hash_en2;

    pbb_hash_en[USERID_LOOKUP1] = p_user_id_info->ds_phy_port_ext.pbb_hash_en1;
    pbb_hash_en[USERID_LOOKUP2] = p_user_id_info->ds_phy_port_ext.pbb_hash_en2;

    ipv4_tunnel_hash_en[USERID_LOOKUP1] = p_user_id_info->ds_phy_port_ext.ipv4_tunnel_hash_en1;
    ipv4_tunnel_hash_en[USERID_LOOKUP2] = p_user_id_info->ds_phy_port_ext.ipv4_tunnel_hash_en2;

    ipv4_udp_tunnel_hash_en[USERID_LOOKUP1] = p_user_id_info->ds_phy_port_ext.ipv4_udp_tunnel_hash_en1;
    ipv4_udp_tunnel_hash_en[USERID_LOOKUP2] = p_user_id_info->ds_phy_port_ext.ipv4_udp_tunnel_hash_en2;

    ipv4_gre_tunnel_hash_en[USERID_LOOKUP1] = p_user_id_info->ds_phy_port_ext.ipv4_gre_tunnel_hash_en1;
    ipv4_gre_tunnel_hash_en[USERID_LOOKUP2] = p_user_id_info->ds_phy_port_ext.ipv4_gre_tunnel_hash_en2;

    port_hash_type[USERID_LOOKUP1] = p_user_id_info->ds_phy_port_ext.user_id_hash1_type;
    port_hash_type[USERID_LOOKUP2] = p_user_id_info->ds_phy_port_ext.user_id_hash2_type;

    p_user_id_info->per_lookup[USERID_LOOKUP1].userid_use_logic_port = p_user_id_info->ds_phy_port_ext.user_id1_use_logic_port;
    p_user_id_info->per_lookup[USERID_LOOKUP2].userid_use_logic_port = p_user_id_info->ds_phy_port_ext.user_id2_use_logic_port;

    p_user_id_info->per_lookup[USERID_LOOKUP1].hash_lookup_use_label = p_user_id_info->ds_phy_port_ext.hash_lookup1_use_label;
    p_user_id_info->per_lookup[USERID_LOOKUP2].hash_lookup_use_label = p_user_id_info->ds_phy_port_ext.hash_lookup2_use_label;

    p_user_id_info->per_lookup[USERID_LOOKUP1].hash_use_da = p_user_id_info->ds_phy_port_ext.hash1_use_da;
    p_user_id_info->per_lookup[USERID_LOOKUP2].hash_use_da = p_user_id_info->ds_phy_port_ext.hash2_use_da;

    for (lookup = 0; lookup < USERID_LOOKUP_NUM; lookup++)
    {
        if ((port_hash_type[lookup] < DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_TUNNEL)
           && (DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_DISABLE != port_hash_type[lookup]))
        {
            /* Decide UserId hash type */
            p_user_id_info->per_lookup[lookup].userid_hash_key_type = port_hash_type[lookup];

            if ((DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_L2 == port_hash_type[lookup])
               && (L3_TYPE_ARP == parser_result->layer3_type))
            {
                p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
            }
        }
        else if (DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_TUNNEL == port_hash_type[lookup])
        {
            /* Decide TunnelId hash type */
            if (is_ipv4 && is_gre && is_gre_key && ipv4_gre_tunnel_hash_en[lookup])
            {
                /* IPv4 GRE tunnel, with key */
                p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_IPV4_GRE_KEY;
            }
            else if (is_udp && is_cap_wap && capwap_hash_en[lookup])
            {
                /* CAPWAP */
                p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_CAPWAP;
            }
            else if (is_ipv4 && (is_ip_in_ip || is_v6_in_ip || is_gre) && ipv4_tunnel_hash_en[lookup])
            {
                /* IPv4/IPv6 in IPv4, 6to4, ISATAP, GRE (w/o key) tunnel */
                p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_IPV4_TUNNEL;
            }
            else if (is_cmac && pbb_hash_en[lookup])
            {
                /* PBB*/
                p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_PBB;
            }
            else if (is_ipv4 && is_udp && ipv4_udp_tunnel_hash_en[lookup])
            {
                /* IPv4 UDP tunnel, with key */
                p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_IPV4_UDP;
            }
            else
            {
                p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
            }

            if (USERID_LOOKUP1 == lookup)
            {
                if (parser_result->l3_s.frag_info
                    && ((USERID_KEY_TYPE_IPV4_GRE_KEY == p_user_id_info->per_lookup[lookup].userid_hash_key_type)
                    || (USERID_KEY_TYPE_IPV4_UDP == p_user_id_info->per_lookup[lookup].userid_hash_key_type)
                    || (USERID_KEY_TYPE_IPV4_TUNNEL == p_user_id_info->per_lookup[lookup].userid_hash_key_type)
                    || (USERID_KEY_TYPE_CAPWAP == p_user_id_info->per_lookup[lookup].userid_hash_key_type)))
                {
                    p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
                }

                if ((0xE == (parser_result->l3_s.ip_da.ipv4.ipda >> 28))
                    && is_ipv4
                    && (!p_user_id_info->ds_phy_port_ext.mcast_vpn_loopback)
                    && ((USERID_KEY_TYPE_IPV4_TUNNEL == p_user_id_info->per_lookup[lookup].userid_hash_key_type)
                        || (USERID_KEY_TYPE_IPV4_GRE_KEY == p_user_id_info->per_lookup[lookup].userid_hash_key_type)))
                {
                    p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
                }
            }
            else if (USERID_LOOKUP2 == lookup)
            {
                if (p_user_id_info->ds_phy_port_ext.tunnel_rpf_check
                    && (USERID_KEY_TYPE_IPV4_GRE_KEY == p_user_id_info->per_lookup[lookup].userid_hash_key_type
                    || USERID_KEY_TYPE_IPV4_UDP == p_user_id_info->per_lookup[lookup].userid_hash_key_type
                    || USERID_KEY_TYPE_IPV4_TUNNEL == p_user_id_info->per_lookup[lookup].userid_hash_key_type))
                {
                    p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_IPV4_RPF;
                }

                if (parser_result->l3_s.frag_info
                    && ((USERID_KEY_TYPE_IPV4_GRE_KEY == p_user_id_info->per_lookup[lookup].userid_hash_key_type)
                    || (USERID_KEY_TYPE_IPV4_UDP == p_user_id_info->per_lookup[lookup].userid_hash_key_type)
                    || (USERID_KEY_TYPE_IPV4_TUNNEL == p_user_id_info->per_lookup[lookup].userid_hash_key_type)
                    || USERID_KEY_TYPE_CAPWAP == p_user_id_info->per_lookup[lookup].userid_hash_key_type))
                {
                    p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
                }
            }
        }
        else if (DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_TRILL == port_hash_type[lookup])
        {
            if (p_user_id_info->trill_no_loop_ucast)
            {
                if (USERID_LOOKUP1 == lookup)
                {
                    p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_TRILL_UC_RPF;
                }
                else if (USERID_LOOKUP2 == lookup)
                {
                    p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_TRILL_UC;
                }
            }
            else if (p_user_id_info->trill_no_loop_mcast)
            {
                if (USERID_LOOKUP1 == lookup)
                {
                    p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_TRILL_MC_RPF;
                }
                else if (USERID_LOOKUP2 == lookup)
                {
                    p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_TRILL_MC_ADJ;
                }
            }
            else if (p_user_id_info->trill_loop_mcast && (USERID_LOOKUP1 == lookup))
            {
                p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_TRILL_MC;
            }
            else
            {
                p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
            }
        }
        else
        {
            p_user_id_info->per_lookup[lookup].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
        }
    }

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:       _cm_ipe_user_identify_lookup_prepare3
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      p_in_pkt        --   pointer to buffer which save input packet and packet
 *                                  header ,and processing informations
 *             p_user_id_info  --   pointer to buffer which save user id temp variable
 *                                  used in user id
 * Output:     p_in_pkt        --   pointer to buffer which save input packet and packet
 *                                  header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_lookup_prepare3(ipe_in_pkt_t* p_in_pkt, user_id_info_t* p_user_id_info)
{
    /* USER_ID_LOOKUP_PREPARE3 */
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    ipe_user_id_ctl_t ipe_user_id_ctl;
    uint8 chip_id = p_in_pkt->chip_id;
    uint32 cmd = 0;
    uint8 index = 0;

    sal_memset(&ipe_user_id_ctl, 0, sizeof(ipe_user_id_ctl));
    cmd = DRV_IOR(IpeUserIdCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_user_id_ctl));

    for (index = 0; index < USERID_LOOKUP_NUM; index++)
    {
        if ((DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_IP_SA == p_user_id_info->per_lookup[index].userid_hash_key_type)
           || (DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_PORT_IP_SA == p_user_id_info->per_lookup[index].userid_hash_key_type))
        {
            if (L3_TYPE_IPV6 == parser_result->layer3_type)
            {
                if (p_user_id_info->ds_phy_port_ext.disable_user_id_ipv6)
                {
                    /* Disable */
                    p_user_id_info->per_lookup[index].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
                }
                else if (!p_user_id_info->ds_phy_port_ext.force_user_id_ipv6_to_mac_key)
                {
                    /* IPv6 */
                    p_user_id_info->per_lookup[index].userid_hash_key_type = USERID_KEY_TYPE_IPV6_SA;
                }
                else if (DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_IP_SA == p_user_id_info->per_lookup[index].userid_hash_key_type)
                {
                    /* MAC UserId */
                    p_user_id_info->per_lookup[index].userid_hash_key_type = USERID_KEY_TYPE_MAC_SA;
                }
                else
                {
                    /* Port MAC SA */
                    p_user_id_info->per_lookup[index].userid_hash_key_type = USERID_KEY_TYPE_PORT_MAC_SA;
                }
            }
            else if ((L3_TYPE_IPV4 == parser_result->layer3_type)
                    || ((L3_TYPE_ARP == parser_result->layer3_type)
                         && ipe_user_id_ctl.arp_force_ipv4))
            {
                if (p_user_id_info->ds_phy_port_ext.disable_user_id_ipv4)
                {
                    /* Disable */
                    p_user_id_info->per_lookup[index].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
                }
                else if (!p_user_id_info->ds_phy_port_ext.force_user_id_ipv4_to_mac_key)
                {
                    /* IPv4 UserId */
                    p_user_id_info->per_lookup[index].userid_hash_key_type = p_user_id_info->per_lookup[index].userid_hash_key_type;
                }
                else if (DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_IP_SA == p_user_id_info->per_lookup[index].userid_hash_key_type)
                {
                    /* MAC UserId*/
                    p_user_id_info->per_lookup[index].userid_hash_key_type = USERID_KEY_TYPE_MAC_SA;
                }
                else
                {
                    /* MAC SA */
                    p_user_id_info->per_lookup[index].userid_hash_key_type = USERID_KEY_TYPE_PORT_MAC_SA;
                }
            }
            else if (ipe_user_id_ctl.force_mac_key)
            {
                /* no-layer3, force MAC lookup */
                if (DS_PHY_PORT_EXT_USER_ID_HASH_TYPE_IP_SA == p_user_id_info->per_lookup[index].userid_hash_key_type)
                {
                    /* MAC SA */
                    p_user_id_info->per_lookup[index].userid_hash_key_type = USERID_KEY_TYPE_MAC_SA;
                }
                else
                {
                    /* Port MAC SA */
                    p_user_id_info->per_lookup[index].userid_hash_key_type = USERID_KEY_TYPE_PORT_MAC_SA;
                }
            }
            else
            {
                /* Disable */
                p_user_id_info->per_lookup[index].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
            }
        }

        if (p_user_id_info->per_lookup[index].userid_use_logic_port)
        {
            p_user_id_info->per_lookup[index].hash_global_src_port = pkt_info->logic_src_port;
        }
        else if (p_user_id_info->per_lookup[index].hash_lookup_use_label && (USERID_LOOKUP1 == index))
        {
            p_user_id_info->per_lookup[index].hash_global_src_port = pkt_info->user_id_label1;
        }
        else if (p_user_id_info->per_lookup[index].hash_lookup_use_label && (USERID_LOOKUP2 == index))
        {
            p_user_id_info->per_lookup[index].hash_global_src_port = pkt_info->user_id_label2;
        }
        else
        {
            p_user_id_info->per_lookup[index].hash_global_src_port = p_user_id_info->global_src_port;
        }
    }

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:       _cm_ipe_user_identify_user_id_result_handle1
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      p_in_pkt          --  pointer to buffer which save input packet and packet
 *                                   header ,and processing informations
 *             p_user_id_info    --  pointer to buffer which save user id temp variable
 *                                   used in user id
 *             user_id_result_info  --  pointer to buffer which save user id temp result
 *                                   used in user id
 * Output:     p_in_pkt          --  pointer to buffer which save input packet and packet
 *                                   header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_userid_result_handle1(ipe_in_pkt_t* p_in_pkt,
                                                          user_id_info_t* p_user_id_info,
                                                          user_id_result_info_t* p_user_id_result_info)
{

    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    ds_user_id_t* p_ds_user_id = (ds_user_id_t*)p_user_id_info->per_lookup[USERID_LOOKUP1].p_ds_user_id;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    uint16 mac_sa_high = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
    uint32 mac_sa_low = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                    parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
    uint32 ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
    uint16 binding_vlan_id = 0;
    uint8 mac_bind_mismatch = FALSE;
    uint8 port_bind_mismatch = FALSE;
    uint8 vlan_bind_mismatch = FALSE;
    uint8 ip_bind_mismatch = FALSE;
    uint8 ip_vlan_bind_mismatch = FALSE;
    uint8 binding_mismatch = FALSE;
    uint32 cmd = 0;
    ds_vlan_action_profile_t ds_vlan_action_profile;

    /*  USER_ID_RESULT_1 */
    if (p_ds_user_id->user_id_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index= EXCEPTION_TYPE_USER_ID;
    }

    pkt_info->bypass_all = p_ds_user_id->bypass_all;
    pkt_info->src_queue_select = p_ds_user_id->src_queue_select;
    pkt_info->deny_bridge = p_ds_user_id->deny_bridge;
    pkt_info->is_leaf = p_ds_user_id->is_leaf;

    if ((!pkt_info->from_cpu_or_oam) && p_ds_user_id->oam_tunnel_en)
    {
        pkt_info->oam_tunnel_en = TRUE;
    }

    if (0 != p_ds_user_id->user_vlan_ptr)
    {
        pkt_info->user_vlan_ptr_valid = TRUE;
        pkt_info->user_vlan_ptr = p_ds_user_id->user_vlan_ptr;
        p_user_id_result_info->ds_user_id1_vlan_ptr_valid = TRUE;
    }

    if (p_ds_user_id->mac_isolated_group_en)
    {
        pkt_info->mac_isolated_groupid = p_ds_user_id->binding_data_high & 0x3F;   /* used as macIsolatedGroupId[5:0] */
        p_user_id_result_info->ds_user_id1_mac_isolated_group_valid = TRUE;
    }

    /* VLAN Tag Action */
    if (p_ds_user_id->vlan_action_profile_valid)
    {
        sal_memset(&ds_vlan_action_profile, 0, sizeof(ds_vlan_action_profile_t));
        cmd = DRV_IOR(DsVlanActionProfile_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_in_pkt->chip_id,
                                      p_ds_user_id->vlan_action_profile_id,
                                      cmd, &ds_vlan_action_profile));


        pkt_info->svlan_tag_operation_valid = p_ds_user_id->svlan_tag_operation_valid;
        pkt_info->cvlan_tag_operation_valid = p_ds_user_id->cvlan_tag_operation_valid;
        pkt_info->user_svlan_id = p_ds_user_id->user_svlan_id;
        pkt_info->user_scos = p_ds_user_id->user_scos;
        pkt_info->user_scfi = p_ds_user_id->user_scfi;
        pkt_info->user_cvlan_id = p_ds_user_id->user_cvlan_id;
        pkt_info->user_ccos = p_ds_user_id->user_ccos;
        pkt_info->user_ccfi = p_ds_user_id->user_ccfi;

        pkt_info->stag_action = ds_vlan_action_profile.s_tag_action;
        pkt_info->ctag_action = ds_vlan_action_profile.c_tag_action;
        pkt_info->svlan_id_action = ds_vlan_action_profile.s_vlan_id_action;
        pkt_info->cvlan_id_action = ds_vlan_action_profile.c_vlan_id_action;
        pkt_info->scos_action = ds_vlan_action_profile.s_cos_action;
        pkt_info->ccos_action = ds_vlan_action_profile.c_cos_action;
        pkt_info->scfi_action = ds_vlan_action_profile.s_cfi_action;
        pkt_info->ccfi_action = ds_vlan_action_profile.c_cfi_action;
        pkt_info->ctag_add_mode =  ds_vlan_action_profile.ctag_add_mode;
        pkt_info->ctag_modify_mode = ds_vlan_action_profile.ctag_modify_mode;
        pkt_info->stag_modify_mode = ds_vlan_action_profile.stag_modify_mode;

        if (ds_vlan_action_profile.svlan_tpid_index_en)
        {
            p_user_id_result_info->ds_user_id1_svlan_tpid_index_en = TRUE;
            pkt_info->svlan_tpid_index = ds_vlan_action_profile.svlan_tpid_index;
        }

        if (ds_vlan_action_profile.outer_vlan_status != 0)
        {
             p_user_id_result_info->ds_user_id1_outer_vlan_is_cvlan_valid = TRUE;
             pkt_info->outer_vlan_is_cvlan = IS_BIT_SET(ds_vlan_action_profile.outer_vlan_status, 0);
        }

    }
    else
    {
        pkt_info->svlan_tag_operation_valid = FALSE;
        pkt_info->cvlan_tag_operation_valid = FALSE;
    }

    if (p_ds_user_id->ds_fwd_ptr_valid
        && (0 != p_ds_user_id->fid)
        && (0xFFFF != p_ds_user_id->fid)) /* fid share with dsFwdPtr */
    {
        /* payloadOffset should be 0 except packetHeaderValid */
        pkt_info->ds_fwd_ptr_valid = TRUE;
        pkt_info->ds_fwd_ptr = p_ds_user_id->fid;
        pkt_info->payload_packet_type = pkt_info->packet_type;
        p_user_id_result_info->ds_user_id1_ds_fwd_ptr_valid = TRUE;
    }
    else if (!p_ds_user_id->ds_fwd_ptr_valid && (0 != p_ds_user_id->fid))
    {
        if (p_ds_user_id->fid_type)
        {
            pkt_info->user_vsi_id_valid = TRUE;
            pkt_info->user_vsi_id = p_ds_user_id->fid & 0x3FFF;
        }
        else
        {
            pkt_info->user_vrf_id_valid = TRUE;
            pkt_info->user_vrf_id = p_ds_user_id->fid & 0x3FFF;
        }
        p_user_id_result_info->ds_user_id1_fid_valid = TRUE;
    }

    if (p_ds_user_id->ds_fwd_ptr_valid && (0xFFFF == p_ds_user_id->fid))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_USER_ID_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! packet discard in userId!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if ((0 != p_ds_user_id->stats_ptr) && (!pkt_info->flow_stats2_valid))
    {
        pkt_info->flow_stats2_valid = TRUE;
        pkt_info->flow_stats2_ptr = p_ds_user_id->stats_ptr;
    }

    pkt_info->user_priority_valid = (p_ds_user_id->user_color != 0);
    pkt_info->user_priority = p_ds_user_id->user_priority;
    pkt_info->user_color = p_ds_user_id->user_color;
    p_user_id_result_info->ds_user_id1_priority_valid = pkt_info->user_priority_valid;

    /* BINDING CHECK */
    if (p_ds_user_id->binding_mac_sa)
    {
        mac_bind_mismatch = (mac_sa_high != p_ds_user_id->binding_data_high)
                            || (mac_sa_low != p_ds_user_id->binding_data_low);
    }
    else if (!p_ds_user_id->binding_mac_sa)
    {
        binding_vlan_id = parser_result->l2_s.svlan_id_valid ?
                     parser_result->l2_s.svlan_id : parser_result->l2_s.cvlan_id;

        switch (p_ds_user_id->binding_data_low & 0x3) /* bindingData[1:0] */
        {
            case 0:
                port_bind_mismatch = (pkt_info->global_src_port != (p_ds_user_id->binding_data_high & 0x3FFF));
                break;
            case 1:
                vlan_bind_mismatch = ((binding_vlan_id & 0xFFF) != ((p_ds_user_id->binding_data_high >> 4) & 0xFFF));
                break;
            case 2:
                ip_bind_mismatch = (ip_sa != ((((p_ds_user_id->binding_data_high&0xF) << 28)
                                              | (p_ds_user_id->binding_data_low >> 4)))
                                              && (L3_TYPE_IPV4 == parser_result->layer3_type));
                break;
            case 3:
                ip_vlan_bind_mismatch = (((binding_vlan_id & 0xFFF) != ((p_ds_user_id->binding_data_high >> 4) & 0xFFF))
                                        || (ip_sa != (((p_ds_user_id->binding_data_high&0xF) << 28)
                                        | (p_ds_user_id->binding_data_low >> 4))))
                                        && (L3_TYPE_IPV4 == parser_result->layer3_type);
                break;
            default:
                break;
        }
    }

    binding_mismatch = ((mac_bind_mismatch || port_bind_mismatch || vlan_bind_mismatch
                       || ip_bind_mismatch || ip_vlan_bind_mismatch) && (!pkt_info->from_cpu_or_oam));

    if (p_ds_user_id->binding_en && binding_mismatch)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_USER_ID_BINDING_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! binding mismatch!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* BINDING_DATA_OVERLOAD */
    if (!p_ds_user_id->binding_en)
    {
       /*
        * {bindingData[47:32]}/
        * {apsSelectProtectingPath, igmpSnoopEn, servicePolicerValid, apsSelectValid, 1'b0,
        * apsSelectGroupId[10:0]/{5'd0, macIsolatedGroupId[5:0]}}
        * {bindingData[31:0]}
        * {vsiLearningDisable, macSecurityVsiDiscard, logicSrcPort[13:0], logicPortType,serviceAclQosEn,
        * servicePolicerMode, flowPolicerPtr[12:0]}
        */
        pkt_info->igmp_snoop_en = IS_BIT_SET(p_ds_user_id->binding_data_high, 14);
        pkt_info->mac_security_vsi_discard = IS_BIT_SET(p_ds_user_id->binding_data_low, 30);
        pkt_info->learning_disable = IS_BIT_SET(p_ds_user_id->binding_data_low, 31);

        if (IS_BIT_SET(p_ds_user_id->binding_data_high, 12)) /* used as apsSelectValid */
        {
            pkt_info->aps_select_valid0 = TRUE;
            pkt_info->aps_select_protecting_path0 = IS_BIT_SET(p_ds_user_id->binding_data_high, 15);/*used as apsSelectProtectingPath*/
            pkt_info->aps_select_group_id0 = p_ds_user_id->binding_data_high & 0x7FF;  /*used as aps_select_group_id0 */
            p_user_id_result_info->ds_user_id1_aps_select_group_id_valid = 1;
        }

        pkt_info->service_acl_qos_en = IS_BIT_SET(p_ds_user_id->binding_data_low, 14);

        /* servicePolicerValid */
        if (IS_BIT_SET(p_ds_user_id->binding_data_high, 13) && (0 != (p_ds_user_id->binding_data_low & 0x1FFF)))
        {
            pkt_info->service_policer_valid = IS_BIT_SET(p_ds_user_id->binding_data_high, 13);   /* servicePolicerValid */
            pkt_info->service_policer_mode = IS_BIT_SET(p_ds_user_id->binding_data_low, 13);     /* servicePolicerMode */
            pkt_info->service_policer_ptr = p_ds_user_id->binding_data_low & 0x1FFF;             /* servicePolicerPtr[12:0] */
            p_user_id_result_info->ds_user_id1_service_policer_valid = TRUE;
        }

        /* flowPolicerValid */
        if ((!IS_BIT_SET(p_ds_user_id->binding_data_high, 13)) && (0 != (p_ds_user_id->binding_data_low & 0x1FFF)))
        {
            pkt_info->flow_policer_valid = TRUE;
            pkt_info->flow_policer_ptr = p_ds_user_id->binding_data_low & 0x1FFF;                /* flowPolicerPtr[12:0] */
            p_user_id_result_info->ds_user_id1_flow_policer_valid = TRUE;
        }

        if (0 != ((p_ds_user_id->binding_data_low >> 16)& 0x3FFF))
        {
            pkt_info->logic_src_port_valid = TRUE;
            pkt_info->logic_src_port = (p_ds_user_id->binding_data_low >> 16) & 0x3FFF;
            pkt_info->logic_port_type |= IS_BIT_SET(p_ds_user_id->binding_data_low, 15);         /* logicPortType */
            p_user_id_result_info->ds_user_id1_logic_src_port_valid = TRUE;
        }

        p_user_id_info->user_id_roaming_state = p_ds_user_id->roaming_state;

        if (pkt_info->capwap_tunnel_valid &&
            ((USERID_KEY_TYPE_PORT_MAC_SA == p_user_id_info->per_lookup[USERID_LOOKUP1].userid_hash_key_type)
             ||(USERID_KEY_TYPE_MAC_SA == p_user_id_info->per_lookup[USERID_LOOKUP1].userid_hash_key_type)))
        {
            /* = DsUserId1.logicSrcPort[13:0] */
            p_user_id_info->ac_logic_port = (p_ds_user_id->binding_data_low>>16)&0x3FFF;

             /* = DsUserId1.dsFwdPtr[15:0] */
            p_user_id_info->wtp_ds_fwd_ptr = p_ds_user_id->fid;
        }

    }

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:       _cm_ipe_user_identify_user_id_result_handle2
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      p_in_pkt          --  pointer to buffer which save input packet and packet
 *                                   header ,and processing informations
 *             p_user_id_info    --  pointer to buffer which save user id temp variable
 *                                   used in user id
 *             p_user_id_result_info  --  pointer to buffer which save user id temp result
 *                                   used in user id
 * Output:     p_in_pkt          --  pointer to buffer which save input packet and packet
 *                                   header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_userid_result_handle2(ipe_in_pkt_t* p_in_pkt,
                                                          user_id_info_t* p_user_id_info,
                                                          user_id_result_info_t* p_user_id_result_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    ds_user_id_t* p_ds_user_id = (ds_user_id_t*)p_user_id_info->per_lookup[USERID_LOOKUP2].p_ds_user_id;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    uint16 mac_sa_high = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
    uint32 mac_sa_low = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                    parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);
    uint32 ip_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
    uint16 binding_vlan_id = 0;
    uint8 mac_bind_mismatch = FALSE;
    uint8 port_bind_mismatch = FALSE;
    uint8 vlan_bind_mismatch = FALSE;
    uint8 ip_bind_mismatch = FALSE;
    uint8 ip_vlan_bind_mismatch = FALSE;
    uint8 binding_mismatch = FALSE;
    uint32 cmd = 0;
    ds_vlan_action_profile_t ds_vlan_action_profile;

    if (p_ds_user_id->user_id_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_USER_ID;
    }

    if (p_ds_user_id->bypass_all)
    {
        pkt_info->bypass_all = TRUE;
    }

    if (p_ds_user_id->src_queue_select)
    {
        pkt_info->src_queue_select = TRUE;
    }

    if (p_ds_user_id->deny_bridge)
    {
        pkt_info->deny_bridge = TRUE;
    }

    if (p_ds_user_id->is_leaf)
    {
        pkt_info->is_leaf = TRUE;
    }

    if ((!pkt_info->from_cpu_or_oam) && p_ds_user_id->oam_tunnel_en)
    {
        pkt_info->oam_tunnel_en = TRUE;
    }

    if ((0 != p_ds_user_id->user_vlan_ptr)
        && (!p_user_id_result_info->ds_user_id1_vlan_ptr_valid))
    {
        pkt_info->user_vlan_ptr_valid = TRUE;
        pkt_info->user_vlan_ptr = p_ds_user_id->user_vlan_ptr;
    }

    if (p_ds_user_id->mac_isolated_group_en && !p_user_id_result_info->ds_user_id1_mac_isolated_group_valid)
    {
        pkt_info->mac_isolated_groupid = p_ds_user_id->binding_data_high & 0x3F;
    }

    /* VLAN Tag Action */
    if (p_ds_user_id->vlan_action_profile_valid)
    {
        sal_memset(&ds_vlan_action_profile, 0, sizeof(ds_vlan_action_profile_t));
        cmd = DRV_IOR(DsVlanActionProfile_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_in_pkt->chip_id,
                                      p_ds_user_id->vlan_action_profile_id,
                                      cmd, &ds_vlan_action_profile));

        if (!pkt_info->svlan_tag_operation_valid)
        {
            pkt_info->svlan_tag_operation_valid = p_ds_user_id->svlan_tag_operation_valid;
            pkt_info->user_svlan_id = p_ds_user_id->user_svlan_id;
            pkt_info->user_scos = p_ds_user_id->user_scos;
            pkt_info->user_scfi = p_ds_user_id->user_scfi;

            pkt_info->stag_action = ds_vlan_action_profile.s_tag_action;
            pkt_info->svlan_id_action = ds_vlan_action_profile.s_vlan_id_action;
            pkt_info->scos_action = ds_vlan_action_profile.s_cos_action;
            pkt_info->scfi_action = ds_vlan_action_profile.s_cfi_action;
            pkt_info->stag_modify_mode = ds_vlan_action_profile.stag_modify_mode;
        }

        if (!pkt_info->cvlan_tag_operation_valid)
        {
            pkt_info->cvlan_tag_operation_valid = p_ds_user_id->cvlan_tag_operation_valid;
            pkt_info->user_cvlan_id = p_ds_user_id->user_cvlan_id;
            pkt_info->user_ccos = p_ds_user_id->user_ccos;
            pkt_info->user_ccfi = p_ds_user_id->user_ccfi;

            pkt_info->ctag_action = ds_vlan_action_profile.c_tag_action;
            pkt_info->cvlan_id_action = ds_vlan_action_profile.c_vlan_id_action;
            pkt_info->ccos_action = ds_vlan_action_profile.c_cos_action;
            pkt_info->ccfi_action = ds_vlan_action_profile.c_cfi_action;
            pkt_info->ctag_add_mode =  ds_vlan_action_profile.ctag_add_mode;
            pkt_info->ctag_modify_mode = ds_vlan_action_profile.ctag_modify_mode;
        }

        if ((!p_user_id_result_info->ds_user_id1_svlan_tpid_index_en)
            && ds_vlan_action_profile.svlan_tpid_index_en)
        {
            pkt_info->svlan_tpid_index = ds_vlan_action_profile.svlan_tpid_index;
        }

        if (!p_user_id_result_info->ds_user_id1_outer_vlan_is_cvlan_valid
            && (ds_vlan_action_profile.outer_vlan_status != 0))
        {
            pkt_info->outer_vlan_is_cvlan = IS_BIT_SET(ds_vlan_action_profile.outer_vlan_status, 0);
        }
    }

    if (p_ds_user_id->ds_fwd_ptr_valid
       && (0 != p_ds_user_id->fid) /* fid share with dsFwdPtr */
       && (0xFFFF != p_ds_user_id->fid)
       && !p_user_id_result_info->ds_user_id1_ds_fwd_ptr_valid)
    {
        pkt_info->ds_fwd_ptr_valid = TRUE;
        pkt_info->ds_fwd_ptr = p_ds_user_id->fid;
        pkt_info->payload_packet_type = pkt_info->packet_type;
    }
    else if (!p_ds_user_id->ds_fwd_ptr_valid && (0 != p_ds_user_id->fid)
            && !p_user_id_result_info->ds_user_id1_fid_valid)
    {
        if (p_ds_user_id->fid_type)
        {
            pkt_info->user_vsi_id_valid = TRUE;
            pkt_info->user_vsi_id = p_ds_user_id->fid & 0x3FFF;
        }
        else
        {
            pkt_info->user_vrf_id_valid = TRUE;
            pkt_info->user_vrf_id = p_ds_user_id->fid & 0x3FFF;
        }
    }

    if (p_ds_user_id->ds_fwd_ptr_valid && (0xFFFF == p_ds_user_id->fid))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_USER_ID_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! packet discard in userId!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if ((0 != p_ds_user_id->stats_ptr) && (!pkt_info->flow_stats2_valid))
    {
        pkt_info->flow_stats2_valid = TRUE;
        pkt_info->flow_stats2_ptr = p_ds_user_id->stats_ptr;
    }

    if (!p_user_id_result_info->ds_user_id1_priority_valid)
    {
        pkt_info->user_priority_valid = (p_ds_user_id->user_color != 0);
        pkt_info->user_priority = p_ds_user_id->user_priority;
        pkt_info->user_color = p_ds_user_id->user_color;
    }

    /*BINDING CHECK*/
    if (p_ds_user_id->binding_mac_sa)
    {
        mac_bind_mismatch = (mac_sa_high != p_ds_user_id->binding_data_high)
                            || (mac_sa_low != p_ds_user_id->binding_data_low);
    }
    else if (!p_ds_user_id->binding_mac_sa)
    {
        binding_vlan_id = parser_result->l2_s.svlan_id_valid ?
                    parser_result->l2_s.svlan_id : parser_result->l2_s.cvlan_id;

        switch (p_ds_user_id->binding_data_low & 0x3)
        {
            case 0:
                port_bind_mismatch = (pkt_info->global_src_port != (p_ds_user_id->binding_data_high & 0x3FFF));
                break;
            case 1:
                vlan_bind_mismatch = ((binding_vlan_id & 0xFFF) != ((p_ds_user_id->binding_data_high >> 4) & 0xFFF));
                break;
            case 2:
                ip_bind_mismatch = ((ip_sa != (((p_ds_user_id->binding_data_high&0xF) << 28)
                                              | (p_ds_user_id->binding_data_low >> 4)))
                                        && (L3_TYPE_IPV4 == parser_result->layer3_type));
                break;
            case 3:
                ip_vlan_bind_mismatch = (((binding_vlan_id & 0xFFF) != ((p_ds_user_id->binding_data_high >> 4) & 0xFFF))
                                        || (ip_sa != (((p_ds_user_id->binding_data_high&0xF) << 28)
                                                     | (p_ds_user_id->binding_data_low >> 4))))
                                        && (L3_TYPE_IPV4 == parser_result->layer3_type);
                break;
            default:
                break;
        }
    }

    binding_mismatch = ((mac_bind_mismatch || port_bind_mismatch || vlan_bind_mismatch
                       || ip_bind_mismatch || ip_vlan_bind_mismatch) && (!pkt_info->from_cpu_or_oam));

    if (p_ds_user_id->binding_en && binding_mismatch)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard_type = IPE_DISCARD_USER_ID_BINDING_DISCARD;
            pkt_info->discard = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! binding mismatch!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /*BINGDING_DATA_OVERLODE*/
    if (!p_ds_user_id->binding_en)
    {
         /*{bindingData[47:32]}/
        {apsSelectProtectingPath, igmpSnoopEn, servicePolicerValid, apsSelectValid, 1'b0, apsSelectGroupId[10:0]} */
        if (IS_BIT_SET(p_ds_user_id->binding_data_high, 12) && !p_user_id_result_info->ds_user_id1_aps_select_group_id_valid)   /* apsSelectValid */
        {
            pkt_info->aps_select_valid0 = TRUE;
            pkt_info->aps_select_protecting_path0 = IS_BIT_SET(p_ds_user_id->binding_data_high, 15); /* used as apsSelectProtectingPath */
            pkt_info->aps_select_group_id0 = (p_ds_user_id->binding_data_high & 0x7FF); /* used as apsSelectGroupId */
        }

        /*{bindingData[31:0]}/
        {vsiLearningDisable, macSecurityVsiDiscard, logicSrcPort[13:0], logicPortType,
         serviceAclQosEn, servicePolicerMode, flowPolicerPtr[12:0]}*/
        if (IS_BIT_SET(p_ds_user_id->binding_data_low, 14))       /* serviceAclQosEn */
        {
            pkt_info->service_acl_qos_en = TRUE;
        }

        if (IS_BIT_SET(p_ds_user_id->binding_data_high, 14))   /* igmpSnoopEn */
        {
            pkt_info->igmp_snoop_en = TRUE;
        }

        if (IS_BIT_SET(p_ds_user_id->binding_data_low, 31))    /* vsiLearningDisable */
        {
            pkt_info->learning_disable = TRUE;
        }

        if (IS_BIT_SET(p_ds_user_id->binding_data_low, 30))    /* macSecurityVsiDiscard */
        {
            pkt_info->mac_security_vsi_discard = TRUE;
        }

        /*servicePolicerValid*/
        if (IS_BIT_SET(p_ds_user_id->binding_data_high, 13)
            && (0 != (p_ds_user_id->binding_data_low & 0x1FFF))   /* flowPolicerPtr[12:0] */
            && (!p_user_id_result_info->ds_user_id1_service_policer_valid))
        {
           /*
            *{bindingData[47:32]}/
            *{apsSelectProtectingPath, igmpSnoopEn, servicePolicerValid, apsSelectValid, 1'b0,
            *apsSelectGroupId[10:0]/{5'd0, macIsolatedGroupId[5:0]}}
            */
            pkt_info->service_policer_valid = IS_BIT_SET(p_ds_user_id->binding_data_high, 13);
            pkt_info->service_policer_mode = IS_BIT_SET(p_ds_user_id->binding_data_low, 13);
            pkt_info->service_policer_ptr = p_ds_user_id->binding_data_low & 0x1FFF;
        }

        if ((!IS_BIT_SET(p_ds_user_id->binding_data_high, 13))
            && (0 != (p_ds_user_id->binding_data_low & 0x1FFF))
            && (!p_user_id_result_info->ds_user_id1_flow_policer_valid))
        {
            pkt_info->flow_policer_valid = TRUE;
            pkt_info->flow_policer_ptr = p_ds_user_id->binding_data_low & 0x1FFF;
        }

        if (((p_ds_user_id->binding_data_low >> 16) & 0x3FFF)
            &&(!p_user_id_result_info->ds_user_id1_logic_src_port_valid))
        {
           /*
            *{bindingData[31:0]}/
            *{vsiLearningDisable, macSecurityVsiDiscard, logicSrcPort[13:0], logicPortType,
            *serviceAclQosEn, servicePolicerMode, flowPolicerPtr[12:0]}
            */
            pkt_info->logic_src_port_valid = TRUE;
            pkt_info->logic_src_port = (p_ds_user_id->binding_data_low >> 16) & 0x3FFF;
            pkt_info->logic_port_type = pkt_info->logic_port_type
                            || IS_BIT_SET(p_ds_user_id->binding_data_low, 15);
        }

        if (ROAMING_NONE != p_ds_user_id->roaming_state)
        {
            p_user_id_info->user_id_roaming_state = p_ds_user_id->roaming_state;
        }

        if (pkt_info->capwap_tunnel_valid
            && ((USERID_KEY_TYPE_PORT_MAC_SA == p_user_id_info->per_lookup[USERID_LOOKUP2].userid_hash_key_type)
                 ||(USERID_KEY_TYPE_MAC_SA == p_user_id_info->per_lookup[USERID_LOOKUP2].userid_hash_key_type)))
        {
            /* = DsUserId1.logicSrcPort[13:0] */
            p_user_id_info->ac_logic_port = (p_ds_user_id->binding_data_low>>16)&0x3FFF;

             /* = DsUserId1.dsFwdPtr[15:0] */
            p_user_id_info->wtp_ds_fwd_ptr = p_ds_user_id->fid;
         }
    }

    return  DRV_E_NONE;
}

/*****************************************************************************
 * Name:       _cm_ipe_user_identify_retrieve_lookup_result
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      p_in_pkt        --  pointer to buffer which save input packet and packet
 *                                 header ,and processing informations
 *             p_user_id_info  --  pointer to buffer which save user id temp variable
 *                                 used in user id
 * Output:     p_in_pkt        --  pointer to buffer which save input packet and packet
 *                                 header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
static int32
_cm_ipe_user_identify_retrieve_lookup_result(ipe_in_pkt_t* p_in_pkt, user_id_info_t* p_user_id_info)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    uint8 index = 0;
    lookup_result_t* p_hash_lookup_result = NULL;
    userid_lookup_extra_result_t* p_userid_lookup_extra_result = NULL;
    uint8 tunnel_lookup_result_valid[USERID_LOOKUP_NUM] = {FALSE};
    uint8 hash_type_is_tunnel_id[USERID_LOOKUP_NUM] = {FALSE};
    uint8 hash_type_is_user_id[USERID_LOOKUP_NUM] = {FALSE};
    uint8 tcam_type_is_user_id[USERID_LOOKUP_NUM] = {FALSE};
    uint8 tunnel_id_lookup_no_result = FALSE;

    for (index = 0; index < USERID_LOOKUP_NUM; index++)
    {
        p_hash_lookup_result = &p_user_id_info->per_lookup[index].hash_lookup_result;

        p_userid_lookup_extra_result = (userid_lookup_extra_result_t*)p_hash_lookup_result->extra;

        if (p_user_id_info->per_lookup[index].userid_hash_key_type >= USERID_KEY_TYPE_PBB)
        {
            hash_type_is_tunnel_id[index] = TRUE;
        }

        if ((p_user_id_info->per_lookup[index].userid_hash_key_type < USERID_KEY_TYPE_PBB)
           && (USERID_KEY_TYPE_DISABLE != p_user_id_info->per_lookup[index].userid_hash_key_type))
        {
            hash_type_is_user_id[index] = TRUE;
        }

        if (p_user_id_info->per_lookup[index].userid_tcam_type < USERID_PORT_TCAM_TYPE_IP_TUNNEL)
        {
            tcam_type_is_user_id[index] = TRUE;
        }

        /* handle UserId lookup result */
        /* if (hash is userId and result valid,not default entry) DsUserId use hash1Ds; */
        /* else if (tcam is userId and result valid) DsUserId use tcam1Ds */
        if (p_user_id_info->per_lookup[index].hash_result_valid && hash_type_is_user_id[index]
            && (!p_userid_lookup_extra_result->default_entry_valid))
        {
            p_user_id_info->per_lookup[index].p_ds_user_id
                        = (ds_user_id_t*)&p_user_id_info->per_lookup[index].hash_ds;

            p_user_id_info->per_lookup[index].userid_result_valid = TRUE;
        }
        else if (p_user_id_info->per_lookup[index].tcam_result_valid && tcam_type_is_user_id[index])
        {
            p_user_id_info->per_lookup[index].p_ds_user_id
                        = (ds_user_id_t*)&p_user_id_info->per_lookup[index].tcam_ds_user_id;

            p_user_id_info->per_lookup[index].userid_result_valid = TRUE;
        }

        /* handle Tunnel lookup result */
        if (p_user_id_info->per_lookup[index].hash_result_valid && hash_type_is_tunnel_id[index]
           && (!p_userid_lookup_extra_result->default_entry_valid))
        {
            /* DsTunnelId*/
            p_user_id_info->per_lookup[index].p_ds_tunnel_id
                        = (ds_tunnel_id_t*)&p_user_id_info->per_lookup[index].hash_ds;

            tunnel_lookup_result_valid[index] = TRUE;
        }
        else if (p_user_id_info->per_lookup[index].tcam_result_valid && !tcam_type_is_user_id[index])
        {
            p_user_id_info->per_lookup[index].p_ds_tunnel_id
                        = (ds_tunnel_id_t*)&p_user_id_info->per_lookup[index].tcam_ds_user_id;

            tunnel_lookup_result_valid[index] = TRUE;
        }

        /* Per port default entry for UserId lookup. */
        /* Define:"entry result",means lookups hit specific entry but no default entry */
        /* Define:"default result",means lookup doesn't hit specific entry result and default entry is used */
        if (!p_user_id_info->per_lookup[index].userid_result_valid
            && (hash_type_is_user_id[index]
                || (!hash_type_is_user_id[index]
                    && p_user_id_info->per_lookup[index].tcam_en
                    && (!p_user_id_info->per_lookup[index].tcam_no_lookup)
                    && tcam_type_is_user_id[index])))
        {
            /* lookup implemented (hash or TCAM), but no entry result */
            p_user_id_info->per_lookup[index].userid_lookup_no_result = TRUE;
        }
    }

    if (p_user_id_info->per_lookup[USERID_LOOKUP1].userid_lookup_no_result
       && p_user_id_info->per_lookup[USERID_LOOKUP2].userid_lookup_no_result
       && p_user_id_info->per_lookup[USERID_LOOKUP1].hash_result_valid
       && p_user_id_info->per_lookup[USERID_LOOKUP1].hash_default_entry_valid)
    {
        /* hash1 and hash2 both implemented userId lookup,but no entry result, use hash1 default entry */
        p_user_id_info->per_lookup[USERID_LOOKUP1].p_ds_user_id
                        = (ds_user_id_t*)&p_user_id_info->per_lookup[USERID_LOOKUP1].hash_ds;

        p_user_id_info->per_lookup[USERID_LOOKUP1].userid_result_valid = TRUE;
    }
    else if (p_user_id_info->per_lookup[USERID_LOOKUP2].userid_lookup_no_result
            && p_user_id_info->per_lookup[USERID_LOOKUP2].hash_result_valid
            && p_user_id_info->per_lookup[USERID_LOOKUP2].hash_default_entry_valid)
    {
        /* lookup2 hit default entry */
        if (p_user_id_info->per_lookup[USERID_LOOKUP1].userid_result_valid
            && p_user_id_info->ds_phy_port_ext.user_id_hash_depend)
        {
            /* lookup1 hit entry result,lookup2 hit default entry,and lookup1/lookup2 depend,only use lookup1 result */
            p_user_id_info->per_lookup[USERID_LOOKUP2].userid_result_valid = FALSE;
        }
        else
        {
            /* lookup1 hit entry result,lookup2 hit default result,and lookup1/lookup2 no depend,lookup2 use hash2 defualt result*/
            /* Or lookup1 doesn't implement lookup,lookup2 hit default entry,lookup2 use hash2 default result */
            p_user_id_info->per_lookup[USERID_LOOKUP2].p_ds_user_id
                            = (ds_user_id_t*)&p_user_id_info->per_lookup[USERID_LOOKUP2].hash_ds;

            p_user_id_info->per_lookup[USERID_LOOKUP2].userid_result_valid = TRUE;
        }

    }
    else if (p_user_id_info->per_lookup[USERID_LOOKUP1].userid_lookup_no_result
        && p_user_id_info->per_lookup[USERID_LOOKUP1].hash_result_valid
        && p_user_id_info->per_lookup[USERID_LOOKUP1].hash_default_entry_valid)
    {
        /* lookup1 hit default result */
        if (p_user_id_info->per_lookup[USERID_LOOKUP2].userid_result_valid
            && p_user_id_info->ds_phy_port_ext.user_id_hash_depend)
        {
            /* lookup1 hit default result,lookup2 hit entry result,and lookup1/lookup2 depend,lookup1 result no use. */
            p_user_id_info->per_lookup[USERID_LOOKUP1].userid_result_valid = FALSE;
        }
        else
        {
            /* lookup1 hit default result,lookup2 hit entry result,and lookup1/lookup2 no depend,lookup1 use hash1 default result */
            /* Or hash1 2 doesn't implement lookup,lookup1 use lookup1 default result */
            p_user_id_info->per_lookup[USERID_LOOKUP1].p_ds_user_id
                            = (ds_user_id_t*)&p_user_id_info->per_lookup[USERID_LOOKUP1].hash_ds;

            p_user_id_info->per_lookup[USERID_LOOKUP1].userid_result_valid = TRUE;
        }
    }

    pkt_info->tunnel_lookup_result1_valid = tunnel_lookup_result_valid[USERID_LOOKUP1];
    pkt_info->tunnel_lookup_result2_valid = tunnel_lookup_result_valid[USERID_LOOKUP2];

    for (index = 0; index < USERID_LOOKUP_NUM; index++)
    {
        /* Per lookup type default entry for TunnelId lookup. */
        if (!tunnel_lookup_result_valid[index] && (hash_type_is_tunnel_id[index]
           || (!hash_type_is_tunnel_id[index] && p_user_id_info->per_lookup[index].tcam_en
           && (!p_user_id_info->per_lookup[index].tcam_no_lookup) && !tcam_type_is_user_id[index])))
        {
            tunnel_id_lookup_no_result = TRUE;

            if (tunnel_id_lookup_no_result
                && p_user_id_info->per_lookup[index].hash_result_valid
                && p_user_id_info->per_lookup[index].hash_default_entry_valid)
            {
                p_user_id_info->per_lookup[index].p_ds_tunnel_id
                                = (ds_tunnel_id_t*)&p_user_id_info->per_lookup[index].hash_ds;

                if (USERID_LOOKUP1 == index)
                {
                    pkt_info->tunnel_lookup_result1_valid = TRUE;
                }
                else
                {
                    pkt_info->tunnel_lookup_result2_valid = TRUE;
                }
            }

        }
    }

    if (pkt_info->tunnel_lookup_result1_valid)
    {
        sal_memcpy(&(pkt_info->userid_tunnel_lkp1_ad),
                   p_user_id_info->per_lookup[USERID_LOOKUP1].p_ds_tunnel_id, sizeof(ds_tunnel_id_t));
    }

    if (pkt_info->tunnel_lookup_result2_valid)
    {
        sal_memcpy(&(pkt_info->userid_tunnel_lkp2_ad),
                   p_user_id_info->per_lookup[USERID_LOOKUP2].p_ds_tunnel_id, sizeof(ds_tunnel_id_t));
    }

    return DRV_E_NONE;
}

/*****************************************************************************
 * Name:       cm_ipe_user_identify_user_handle
 * Purpose:    handle IPE user identification.
 * Parameters:
 * Input:      p_in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Output:     p_in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other = Error, please reference DRV_E_XXX.
 * Note:       none.
 *****************************************************************************/
int32
cm_ipe_user_identify_user_handle(ipe_in_pkt_t* p_in_pkt)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t*)p_in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*)pkt_info->parser_rslt;

    ipe_user_id_ctl_t ipe_user_id_ctl;
    user_id_info_t user_id_info;
    ipe_user_id_sgmac_ctl_t ipe_user_id_sgmac_ctl;
    uint32 lookup_index = 0;
    uint32 chip_id = p_in_pkt->chip_id;
    uint32 random = 0; /* fake random, cmodel can not sim because of coSim */
    uint32 cmd = 0;
    uint8 user_id_en = FALSE;
    user_id_result_info_t user_id_result_info;
    uint8 result_valid = FALSE;
    uint8 interlaken_exception_disable = FALSE;
    userid_lookup_extra_result_t userid_lookup_extra_result[USERID_LOOKUP_NUM];

    sal_memset(&user_id_info, 0, sizeof(user_id_info));

    for (lookup_index = 0; lookup_index < USERID_LOOKUP_NUM; lookup_index++)
    {
        sal_memset(&userid_lookup_extra_result[lookup_index], 0, sizeof(userid_lookup_extra_result_t));

        user_id_info.per_lookup[lookup_index].userid_hash_key_type = USERID_KEY_TYPE_DISABLE;
        userid_lookup_extra_result[lookup_index].data = &user_id_info.per_lookup[lookup_index].hash_ds;
        user_id_info.per_lookup[lookup_index].hash_lookup_result.extra = &userid_lookup_extra_result[lookup_index];
    }

    sal_memset(&ipe_user_id_ctl, 0, sizeof(ipe_user_id_ctl));
    cmd = DRV_IOR(IpeUserIdCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_user_id_ctl));

    /* PACKET_DISCARD_AND_HASH */
    parser_result->layer2_offset = pkt_info->payload_offset;
    parser_result->l2_s.layer3_offset = pkt_info->payload_offset + parser_result->l2_s.layer3_offset;;
    /* payloadOffset:Parser start */
    parser_result->l3_s.layer4_offset = pkt_info->payload_offset + parser_result->l3_s.layer4_offset;;

    /* cmodel not need */
    /* estimated pacekt length,Only for Stop TM used,not foe Eop and Sop/Eop*/
    if (0 == pkt_info->packet_length)  /* not single buffer,estimated */
    {
        if ((L3_TYPE_IPV4 == parser_result->layer3_type))
        {
            pkt_info->packet_length = parser_result->l2_s.layer3_offset + parser_result->l3_s.ip_length;
        }
        else if ((L3_TYPE_IPV6 == parser_result->layer3_type))
        {
            pkt_info->packet_length = parser_result->l2_s.layer3_offset + parser_result->l3_s.ip_length + 40;
        }
        else if ((L3_TYPE_FCOE == parser_result->layer3_type))
        {
            pkt_info->packet_length = parser_result->l2_s.layer3_offset + ipe_user_id_ctl.fcoe_length;
        }
        else if ((L3_TYPE_TRILL == parser_result->layer3_type))
        {
            if (0 != parser_result->l3_s.ip_da.trill.trill_length)
            {
                pkt_info->packet_length = parser_result->l2_s.layer3_offset + parser_result->l3_s.ip_da.trill.trill_length;
            }
            else
            {
                pkt_info->packet_length = parser_result->l2_s.layer3_offset + ipe_user_id_ctl.trill_length;
            }
        }
        else
        {
            pkt_info->packet_length = parser_result->l2_s.layer3_offset + ipe_user_id_ctl.default_length;
        }

        pkt_info->packet_length = pkt_info->packet_length + (pkt_info->non_crc ? 0 : 4);

        if (pkt_info->packet_length <= 256)
        {
            pkt_info->packet_length = 260;
        }
    }

    pkt_info->exception_en = FALSE;
    pkt_info->exception_index = 0;
    pkt_info->exception_sub_index = 0;

    cmd = DRV_IOR(DsPhyPortExt_t, DRV_ENTRY_FLAG);
    sal_memset(&user_id_info.ds_phy_port_ext, 0, sizeof(ds_phy_port_ext_t));
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->local_phy_port, cmd, &user_id_info.ds_phy_port_ext));

    pkt_info->l2_span_en = user_id_info.ds_phy_port_ext.l2_span_en && (!pkt_info->from_cpu_or_oam);
    pkt_info->l2_span_id = user_id_info.ds_phy_port_ext.l2_span_id;

    user_id_info.per_lookup[USERID_LOOKUP1].tcam_en = user_id_info.ds_phy_port_ext.user_id_tcam1_en;
    user_id_info.per_lookup[USERID_LOOKUP2].tcam_en = user_id_info.ds_phy_port_ext.user_id_tcam2_en;

    pkt_info->random_log_en = user_id_info.ds_phy_port_ext.random_log_en && (!pkt_info->from_cpu_or_oam);

    ctcutil_rand(0, 0x7FFF, &random);
    if (user_id_info.ds_phy_port_ext.random_log_en
        && (!pkt_info->from_cpu_or_oam)
        && ((random & 0x7FFF) <= user_id_info.ds_phy_port_ext.random_threshold))
    {
        pkt_info->port_log_en = TRUE;
    }
    else
    {
        pkt_info->port_log_en = FALSE;
    }

    user_id_info.capwap_logic_src_port = pkt_info->logic_src_port;
    pkt_info->default_logic_src_port = user_id_info.ds_phy_port_ext.default_logic_src_port;

    if (user_id_info.ds_phy_port_ext.use_default_logic_src_port)
    {
        pkt_info->logic_src_port_valid = TRUE;
        pkt_info->logic_src_port = user_id_info.ds_phy_port_ext.default_logic_src_port;
    }

    if (user_id_info.ds_phy_port_ext.efm_loopback_en && !pkt_info->from_cpu_or_oam)
    {
        pkt_info->efm_loopback_en = TRUE;
        pkt_info->l2_span_en = FALSE;
        pkt_info->port_log_en = FALSE;
        pkt_info->ds_fwd_ptr_valid = TRUE;
        pkt_info->ds_fwd_ptr = user_id_info.ds_phy_port_ext.ds_fwd_ptr;

        if ((L3_TYPE_SLOWPROTO == parser_result->layer3_type)
            && (0x03 == parser_result->l3_s.ip_da.slow_ptl.slow_protocol_sub_type)
            && (0x01 == parser_result->l2_s.mac_da5) && (0x80 == parser_result->l2_s.mac_da4)
            && (0xC2 == parser_result->l2_s.mac_da3) && (0x00 == parser_result->l2_s.mac_da2)
            && (0x00 == parser_result->l2_s.mac_da1) && (0x02 == parser_result->l2_s.mac_da0))
        {
            if (!pkt_info->exception_en)
            {
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
                pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_EFM;
            }

            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_EFM_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! EFM protocol packet discard and do log!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }
    else if (parser_result->parser_length_error)
    {
        if (!IS_BIT_SET(ipe_user_id_ctl.parser_length_error_mode, 1))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_PSR_LEN_ERR;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! PSR length error!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if ((0 == ipe_user_id_ctl.parser_length_error_mode) && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PARSER_LEN_ERR;
        }
    }

    pkt_info->bypass_all = pkt_info->discard || pkt_info->bypass_all || pkt_info->efm_loopback_en;
    pkt_info->header_hash = parser_result->header_hash;

    pkt_info->src_outer_vlan_is_svlan = user_id_info.ds_phy_port_ext.src_outer_vlan_is_svlan;
    pkt_info->use_default_vlan_lookup = user_id_info.ds_phy_port_ext.use_default_vlan_lookup;
    pkt_info->user_id_label1 = user_id_info.ds_phy_port_ext.user_id_label1;
    pkt_info->user_id_label2 = user_id_info.ds_phy_port_ext.user_id_label2;
    pkt_info->pbb_mcast_loopback = user_id_info.ds_phy_port_ext.pbb_mcast_loopback;
    pkt_info->global_src_port = user_id_info.ds_phy_port_ext.global_src_port;
    pkt_info->vrfid_or_ds_fwd_ptr = user_id_info.ds_phy_port_ext.ds_fwd_ptr;

    if (pkt_info->use_default_vlan_tag_valid)
    {
        pkt_info->default_vlan_id = pkt_info->user_default_vlan_id;
        pkt_info->default_pcp = pkt_info->user_default_cos;
        pkt_info->default_dei = pkt_info->user_default_cfi;
    }
    else
    {
        pkt_info->default_vlan_id = user_id_info.ds_phy_port_ext.default_vlan_id;
        pkt_info->default_pcp = user_id_info.ds_phy_port_ext.default_pcp;
        pkt_info->default_dei = user_id_info.ds_phy_port_ext.default_dei;
    }

    user_id_info.user_id_roaming_state = ROAMING_NONE;

    if (parser_result->l2_s.svlan_id_valid)
    {
        pkt_info->classify_stag_cos = parser_result->l2_s.stag_cos;
        pkt_info->classify_stag_cfi = parser_result->l2_s.stag_cfi;
    }
    else
    {
        pkt_info->classify_stag_cos = pkt_info->default_pcp;
        pkt_info->classify_stag_cfi = pkt_info->default_dei;
    }

    if (parser_result->l2_s.cvlan_id_valid)
    {
        pkt_info->classify_ctag_cos = parser_result->l2_s.ctag_cos;
        pkt_info->classify_ctag_cfi = parser_result->l2_s.ctag_cfi;
    }
    else
    {
        pkt_info->classify_ctag_cos = pkt_info->default_pcp;
        pkt_info->classify_ctag_cfi = pkt_info->default_dei;
    }

    user_id_info.ac_logic_port = 0;
    user_id_info.wtp_ds_fwd_ptr = 0;

    if (IS_BIT_SET(p_in_pkt->chan_id,7) && !ipe_user_id_ctl.interlaken_exception_en)
    {
        interlaken_exception_disable = TRUE;
    }
    else
    {
        interlaken_exception_disable = FALSE;
    }

    /* BYPASS_SWITCH */
    if (pkt_info->bypass_all)
    {
        return DRV_E_NONE;
    }

    if (!(pkt_info->from_cpu_or_oam || interlaken_exception_disable))
    {
        /* BPDU_PROTOCOL_ESCAPE */
        DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_escape_bpdu_protocol(p_in_pkt, &user_id_info));
    }

    /* USER_ID_EN */
    user_id_en = (!pkt_info->discard) && (!pkt_info->bypass_all)
                 && ((!pkt_info->from_cpu_or_oam) || (!ipe_user_id_ctl.oam_tx_bypass_user_id));

    user_id_info.cvlan_id = parser_result->l2_s.cvlan_id; /* inner VLAN TAG */
    user_id_info.ctag_cos = parser_result->l2_s.ctag_cos;
    user_id_info.ctag_cfi = parser_result->l2_s.ctag_cfi;

    user_id_info.svlan_id = parser_result->l2_s.svlan_id; /* outer VLAN TAG */
    user_id_info.stag_cos = parser_result->l2_s.stag_cos;
    user_id_info.stag_cfi = parser_result->l2_s.stag_cfi;

    user_id_info.per_lookup[USERID_LOOKUP1].userid_tcam_type = user_id_info.ds_phy_port_ext.user_id_tcam1_type;
    user_id_info.per_lookup[USERID_LOOKUP2].userid_tcam_type = user_id_info.ds_phy_port_ext.user_id_tcam2_type;
    user_id_info.global_src_port = pkt_info->global_src_port;

    sal_memset(&ipe_user_id_sgmac_ctl, 0, sizeof(ipe_user_id_sgmac_ctl));
    cmd = DRV_IOR(IpeUserIdSgmacCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_user_id_sgmac_ctl));

    if (ipe_user_id_sgmac_ctl.sgmac_control_message_en && pkt_info->from_sgmac
        && (ipe_user_id_sgmac_ctl.sgmac_control_ether_type == parser_result->l2_s.layer2_header_protocol))
    {
        if (ipe_user_id_sgmac_ctl.sgmac_control_message_exception_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_SGMAC_CTL_MSG;
        }

        if (ipe_user_id_sgmac_ctl.sgmac_control_message_discard)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard_type = IPE_DISCARD_HDR_ADJ_BYTE_RMV_ERR_DISCARD;
                pkt_info->discard = TRUE;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! SGMac control message discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    if (user_id_en)
    {

        DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_lookup_prepare1(p_in_pkt, &user_id_info));

        DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_lookup_prepare2(p_in_pkt, &user_id_info));

        DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_lookup_prepare3(p_in_pkt, &user_id_info));

        for (lookup_index = 0; lookup_index < USERID_LOOKUP_NUM; lookup_index++)
        {
            /* PERFORM_USER_ID_HASH1-2_LOOKUP */
            if (USERID_KEY_TYPE_DISABLE != user_id_info.per_lookup[lookup_index].userid_hash_key_type)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "User Identification Process");
                DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_lookup_hash(p_in_pkt, &user_id_info, lookup_index));
            }

            if (user_id_info.per_lookup[lookup_index].tcam_en)
            {
                CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "User Identification Process");
                DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_lookup_tcam(p_in_pkt, &user_id_info, lookup_index));
            }
        }

        /* POP_USER_ID_LOOKUP_RESULT */
        for (lookup_index = 0; lookup_index < USERID_LOOKUP_NUM; lookup_index++)
        {
            if (USERID_KEY_TYPE_DISABLE != user_id_info.per_lookup[lookup_index].userid_hash_key_type)
            {
                result_valid = user_id_info.per_lookup[lookup_index].hash_lookup_result.valid;
                user_id_info.per_lookup[lookup_index].hash_result_valid = result_valid;

                user_id_info.per_lookup[lookup_index].hash_default_entry_valid
                                = userid_lookup_extra_result[lookup_index].default_entry_valid;
            }

            /* DsUserId use double wide associated data when TCAM lookup */
            if (user_id_info.per_lookup[lookup_index].tcam_en
                && (!user_id_info.per_lookup[lookup_index].tcam_no_lookup))
            {
                result_valid
                  = user_id_info.per_lookup[lookup_index].tcam_lookup_result.tcam_lkp_output[DRV_TCAM_LOOKUP1].tcam_lkp_result_valid;

                user_id_info.per_lookup[lookup_index].tcam_result_valid = result_valid;
            }
        }

        /* RETRIEVE_LOOKUP_RESULT */
        DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_retrieve_lookup_result(p_in_pkt, &user_id_info));

        sal_memset(&user_id_result_info, 0, sizeof(user_id_result_info));
        if (user_id_info.per_lookup[USERID_LOOKUP1].userid_result_valid)
        {
           DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_userid_result_handle1(p_in_pkt, &user_id_info,
                                                                            &user_id_result_info));
        }

        if (user_id_info.per_lookup[USERID_LOOKUP2].userid_result_valid)
        {
            DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_userid_result_handle2(p_in_pkt, &user_id_info,
                                                                             &user_id_result_info));
        }
    }

    DRV_IF_ERROR_RETURN(_cm_ipe_user_identify_capwap_client_process(p_in_pkt, &user_id_info));

    return DRV_E_NONE;
}

