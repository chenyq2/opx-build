/****************************************************************************
 * cm_ipe_tunnel_terminate.c : Provides IPE tunnel termination handle function.
 *
 * Copyright:(c)2010 Centec Networks Inc. All rights reserved.
 *
 * Revision:   V1.0.
 * Author:     Zhouw.
 * Date:       2010-10-25.
 * Reason:     First Create.
 *
 * Modify History:
 *
 * Revision:     V4.3.0
 * Author:       JiaK.
 * Date:         2011-07-13.
 * Reason:       Sync spec revision 4.3.0.
 *
 * Revision:     V4.3.0
 * Author:       JiangSz.
 * Date:         2011-07-18.
 * Reason:       Sync spec revision 4.5.1.
 *
 * Revision:     V4.29.0
 * Author:       TaoJ.
 * Date:         2011-10-8.
 * Reason:       Sync spec revision 4.29.0.
 *
 * Reversion:    V4.1.0
 * Author:       Wangcy
 * Date:         2011-12-12.
 * Reason:       sync spec v5.1.0.
 *
 * Reversion:    V5.6.0
 * Author:       Wangcy
 * Date:         2012-01-07.
 * Reason:       sync spec v5.6.0.
 *
 * Reversion:    V5.7.0
 * Author:       Wangcy
 * Date:         2012-01-17.
 * Reason:       sync spec v5.7.0.
 *
 * Reversion:    V5.11.0
 * Author:       ZhouW
 * Date:         2012-03-01.
 * Reason:       sync spec v5.11.0.
 *
 * Reversion:    V5.13.0
 * Author:       Wangcy
 * Date:         2012-03-12.
 * Reason:       sync spec v5.13.0.
 *
 * Reversion:    V5.15.0.1
 * Author:       Wangcy
 * Date:         2012-03-23.
 * Reason:       sync spec v5.13.0.1
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "ctcutil_lib.h"
#include "drv_lib.h"
#include "cm_lib.h"

/*****************************************************************************
 *
 * Defines and Macros
 *
 *****************************************************************************/

/* Pop dsuserid1 information structure */
struct tunnel_info_s
{
    uint8 ds_tunnelid1_is_tunnel :1;
    uint8 ds_tunnelid1_fwdptr_valid :1;
    uint8 ds_tunnelid1_aps_select_valid :1;

    uint8 ds_tunnelid1_servic_policer_valid :1;
    uint8 ds_tunnelid1_aps_select_group_valid :1;
    uint8 ds_tunnelid1_logic_src_port_valid :1;
    uint8 ds_tunnelid1_flow_policer_valid :1;

    uint8 ds_tunnelid1_fid_valid :1;
    uint8 ds_tunnelid1_label_space_valid :1;
    uint8 deny_tunnel_decap2 :1 ;
    uint8 capwap_bss_id_check :1;
    uint8 tunnel1_is_esadi :1;
    uint8 tunnel2_is_esadi :1;
};
typedef struct tunnel_info_s tunnel_info_t;

struct mpls_info_s
{
    uint32 parser_layer4_type;
    uint8 label_num;

    uint8 mpls_offset;
    uint8 mpls_lm_index;
    uint8 aps_num;
    uint8 _continue;
    uint8 entropy_label_en;
};
typedef struct mpls_info_s mpls_info_t;

enum oam_check_type_s
{
    OAM_CHECK_TYPE_NONE,
    OAM_CHECK_TYPE_MEP,
    OAM_CHECK_TYPE_MIP,
    OAM_CHECK_TYPE_OAM_DISCARD,
    OAM_CHECK_TYPE_TO_CPU,
    OAM_CHECK_TYPE_DATA_DISCARD,
};
typedef enum oam_check_type_s oam_check_type_t;

/****************************************************************************
 * Name:       _cm_ipe_lookup_manager_ipv4_martian_addr
 * Purpose:    check if the ip sa is martian address
 * Parameters:
 *  Input:     chip_id
 *             route ctl pointer
 *             ip_sa
 * Output:     ipv4_martian_address  bool
 *
 * Return:     DRV_E_NONE  -- success.
 *             Other       -- Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_ipe_tunnel_terminate_ipv4_martian_addr(uint8 chip_id, uint32 ip_sa, uint8 *ipv4_martian_address)
{
    uint8 ipv4_martian_check = 0;

    if (0xE == ((ip_sa >> 28) & 0xF))
    {
        SET_BIT(ipv4_martian_check, 0);
    }

    if (0xF == ((ip_sa >> 28) & 0xF))
    {
        SET_BIT(ipv4_martian_check, 1);
    }

    if (127 == ((ip_sa >> 24) & 0xFF))
    {
        SET_BIT(ipv4_martian_check, 2);
    }

    if (0 == ((ip_sa >> 24) & 0xFF))
    {
        SET_BIT(ipv4_martian_check, 3);
    }

    if (0 != ipv4_martian_check)
    {
        *ipv4_martian_address = TRUE;
    }
    else
    {
        *ipv4_martian_address = FALSE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_ipe_tunnel_terminate_mpls_label_process
* Purpose:    IPE tunnel termination mpls labels process.
* Parameters:
*  Input:     p_pktinfo -- pointer to buffer which save input packet
*                          and packet header ,and processing informations.
*             label_count -- current label number.
* Output:     none
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
static int32
_cm_ipe_tunnel_terminate_mpls_label_process(ipe_in_pkt_t *in_pkt,
                                        uint8 label_count, mpls_info_t *mpls_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    ipe_mpls_ctl_t ipe_mpls_ctl;
    ipe_mpls_ttl_thrd_t ipe_mpls_ttl_threshold;
    ds_mpls_ctl_t ds_mpls_ctl;
    ds_mpls_t ds_mpls;

    uint8 chip_id = in_pkt->chip_id;
    uint8 first_label = !label_count;
    uint8 exp = 0;
    uint8 ttl_threshold = 0, packet_ttl = 0, ttl_checked = 0;
    uint8 priority_offset = 0, color_offset = 0, exp_policer_offset = 0;;
    uint8 mpls_sbit = 0, mpls_escape_case = 0;
    uint8 label_base_if_12_to_6 = 0, label_base_global_12_to_6 = 0, label_base_12_to_6 = 0;
    uint8 label_space_size_type_if = 0, label_space_size_type_global = 0, lable_space_size_type = 0;
    uint8 dcn_forwarding_en = FALSE;
    uint8 interface_label_valid = FALSE;
    uint8 llsp = FALSE;
    uint8 oam_mep_en = FALSE, is_mpls_oam_exception = FALSE,oam_mip_en = FALSE;
    uint8 mpls_ttl_check_fail = FALSE, ttl_check_fail = FALSE, sbit_check_error = FALSE;
    uint8 is_dcn_channel_next1 = FALSE, is_dcn_channel_next2 = FALSE;
    uint8 mpls_label_next1_is_entropy = FALSE, mpls_label_next2_is_entropy = FALSE;
    uint8 is_mpls_mcast = FALSE, is_section_oam_label = FALSE;
    uint8 mpls_sbit_error = FALSE, mpls_escape = FALSE, mpls_label_outof_range = FALSE;
    uint8 oam_en = FALSE;
    uint16 dcn_pid = 0;
    uint32 min_interface_label = 0;
    uint32 label_space_size = 0;
    uint32 mpls_effective_label = 0;
    uint32 mpls_index = 0;
    uint32 ach = 0;
    uint32 priority_tmp = 0, color_tmp = 0;
    uint32 path_sel_priority_id = 0;
    uint32 field_id = 0, priority_path_select = 0;
    uint32 mpls_label_is_13 = 0, mpls_label_is_14 = 0;
    uint32 mpls_label_next1_is_13 = 0, mpls_label_next1_is_14 = 0;
    uint32 label = 0, label_next1 = 0, label_next2 = 0, label_next3 = 0;
    uint32 mpls_label = 0, mpls_label_next1 = 0, mpls_label_next2 = 0, mpls_label_next3 = 0;
    uint32 cmd = 0;
    uint32 mpls_label_hdr[8]= {parser_result->l3_s.ip_da.mpls.mpls_label0,
                               parser_result->l3_s.ip_da.mpls.mpls_label1,
                               parser_result->l3_s.ip_da.mpls.mpls_label2,
                               parser_result->l3_s.ip_da.mpls.mpls_label3,
                               parser_result->l3_s.ip_sa.mpls.mpls_label4,
                               parser_result->l3_s.ip_sa.mpls.mpls_label5,
                               parser_result->l3_s.ip_sa.mpls.mpls_label6,
                               parser_result->l3_s.ip_sa.mpls.mpls_label7};
    uint8 field_stats_en = FALSE;
    uint8 field_policer_en = FALSE;
    uint8 field_aps_en = FALSE;
    uint16 stats_ptr = 0,policer_ptr = 0,aps_ptr = 0;

    /* DS_MPLS_CTL */
    sal_memset(&ds_mpls_ctl, 0, sizeof(ds_mpls_ctl_t));
    cmd = DRV_IOR(DsMplsCtl_t, DRV_ENTRY_FLAG);
    /* no shared with PacketInfo.vrfid[13:0] */
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->mpls_label_space, cmd, &ds_mpls_ctl));

    sal_memset(&ipe_mpls_ctl, 0, sizeof(ipe_mpls_ctl_t));
    cmd = DRV_IOR(IpeMplsCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_mpls_ctl));

    sal_memset(&ipe_mpls_ttl_threshold, 0, sizeof(ipe_mpls_ttl_threshold));
    cmd = DRV_IOR(IpeMplsTtlThrd_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_mpls_ttl_threshold));

    is_mpls_mcast = (L3_TYPE_MPLSMCAST == parser_result->layer3_type);

    /* per-interface label space info */
    label_base_if_12_to_6 = is_mpls_mcast ? ds_mpls_ctl.label_base_mcast : ds_mpls_ctl.label_base;

    label_space_size_type_if = is_mpls_mcast ? ds_mpls_ctl.label_space_size_type_mcast
                                             : ds_mpls_ctl.label_space_size_type;

    interface_label_valid = is_mpls_mcast ? ds_mpls_ctl.interface_label_valid_mcast
                                          : ds_mpls_ctl.interface_label_valid;

    min_interface_label = is_mpls_mcast ? ipe_mpls_ctl.min_interface_label_mcast
                                        : ipe_mpls_ctl.min_interface_label;

    /* per-system label space info */
    label_base_global_12_to_6 = is_mpls_mcast ? ipe_mpls_ctl.label_base_global_mcast
                                              : ipe_mpls_ctl.label_base_global;

    label_space_size_type_global = is_mpls_mcast ? ipe_mpls_ctl.label_space_size_type_global_mcast
                                                 : ipe_mpls_ctl.label_space_size_type_global;


    /* DS_MPLS */
    label = (mpls_label_hdr[label_count] >> 12) & 0xFFFFF;

    if ((label >= min_interface_label) && interface_label_valid)   /* per inteface label */
    {
        mpls_effective_label = label - min_interface_label;
        label_base_12_to_6 = label_base_if_12_to_6;
        lable_space_size_type = label_space_size_type_if;
    }
    else                                                           /* global label, start from zero */
    {
        mpls_effective_label = label;
        label_base_12_to_6 = label_base_global_12_to_6;
        lable_space_size_type = label_space_size_type_global;
    }

    label_space_size = (64 << lable_space_size_type) - 1;
    mpls_label_outof_range = (mpls_effective_label > label_space_size);

    if (mpls_label_outof_range)
    {
        /* force to 0 is out of range to avoid reading errored RAM contents */
        mpls_effective_label = 0;
    }

    /* add offset to support multiple label space */
    mpls_index = (label_base_12_to_6 << 6) + mpls_effective_label;

    if (mpls_label_outof_range)
    {
        SET_BIT(pkt_info->mpls_lbl_out_rang, label_count);
    }
    else
    {
        CLEAR_BIT(pkt_info->mpls_lbl_out_rang, label_count);
    }

    /* (mplsIndex[19:0] + {IpeMplsCtl.dsMplsTableBase[17:6], 6'd0}) << 1 RTL use */
    sal_memset(&ds_mpls, 0, sizeof(ds_mpls));
    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR, "[Debug Table Index]:  %s[0x%x]\n", "DsMpls_t", mpls_index);
    cmd = DRV_IOR(DsMpls_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mpls_index, cmd, &ds_mpls));

    /* RETRIEVE_DS */
    pkt_info->svlan_tpid_index = ds_mpls.svlan_tpid_index;
    pkt_info->outer_vlan_is_cvlan = ds_mpls.outer_vlan_is_cvlan;
    pkt_info->vsi_learning_disable |= ds_mpls.vsi_learning_disable;
    pkt_info->mac_security_vsi_discard |= ds_mpls.mac_security_vsi_discard;
    pkt_info->acl_qos_use_outer_info |= ds_mpls.aclqos_use_outer_info;
    pkt_info->igmp_snoop_en |= ds_mpls.igmp_snoop_en;
    /* ======== bug 4987 metal fix ECO begin ========= */
    //pkt_info->inner_packet_lookup |= ds_mpls.inner_packet_lookup;
    pkt_info->inner_packet_lookup = (pkt_info->inner_packet_lookup && (ipe_mpls_ctl.mpls_ttl_decrement & 0x1)) || ds_mpls.inner_packet_lookup;
    /* ======== bug 4987 metal fix ECO end ========= */
    pkt_info->ttl_update |= ds_mpls.ttl_update;
    pkt_info->qos_domain = ds_mpls.overwrite_qos_domain ? ds_mpls.qos_domain : pkt_info->qos_domain;

    /* INIT */
    if ((first_label && ipe_mpls_ctl.use_first_label_exp) || ds_mpls.use_label_exp)
    {
        exp = (mpls_label_hdr[label_count] >> 9) & 0x7;
        pkt_info->src_dscp = (((mpls_label_hdr[label_count] >> 9) & 0x7) << 3);
    }

    if ((first_label && ipe_mpls_ctl.use_first_label_ttl) || ds_mpls.use_label_ttl)
    {
        packet_ttl = mpls_label_hdr[label_count] & 0xFF;
    }
    else
    {
        packet_ttl = pkt_info->packet_ttl;
    }

    /* ERROR_CHECK */
    mpls_label = mpls_label_hdr[label_count];
    mpls_label_next1 = mpls_label_hdr[label_count + 1];
    mpls_label_next2 = mpls_label_hdr[label_count + 2];
    mpls_label_next3 = mpls_label_hdr[label_count + 3];

    label_next1 = (mpls_label_next1 >> 12) & 0xFFFFF;
    label_next2 = (mpls_label_next2 >> 12) & 0xFFFFF;
    label_next3 = (mpls_label_next3 >> 12) & 0xFFFFF;

    mpls_label_is_14 = (label == ipe_mpls_ctl.oam_alert_label0);
    mpls_label_next1_is_14 = !IS_BIT_SET(mpls_label, 8) && (label_next1 == ipe_mpls_ctl.oam_alert_label0);

    mpls_label_is_13 = (label == ipe_mpls_ctl.oam_alert_label1);
    mpls_label_next1_is_13 = !IS_BIT_SET(mpls_label, 8) && (label_next1 == ipe_mpls_ctl.oam_alert_label1);

    is_section_oam_label = first_label && mpls_label_is_13;
    /*============ bug 4779 ECO begin=========*/
    //oam_mep_en = (OAM_CHECK_TYPE_MEP == ds_mpls.oam_check_type);
    oam_mep_en = (OAM_CHECK_TYPE_MEP == ds_mpls.oam_check_type)||(OAM_CHECK_TYPE_DATA_DISCARD == ds_mpls.oam_check_type);
    /*============ bug 4779 ECO end=========*/
    oam_mip_en = (OAM_CHECK_TYPE_MIP == ds_mpls.oam_check_type);

    /* MPLS/T-MPLS OAM processed by CPU */
    if (oam_mep_en && (mpls_label_is_14 || mpls_label_next1_is_14) && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_MPLS_TMPLS_OAM;

        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_MPLS_TMPLS_OAM_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! MPLS/T-MPLS OAM discard and exception to CPU!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* TTL */
    switch (ds_mpls.ttl_threshold_index)
    {
        case 0:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold0;
            break;
        case 1:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold1;
            break;
        case 2:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold2;
            break;
        case 3:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold3;
            break;
        case 4:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold4;
            break;
        case 5:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold5;
            break;
        case 6:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold6;
            break;
        case 7:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold7;
            break;
        case 8:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold8;
            break;
        case 9:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold9;
            break;
        case 10:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold10;
            break;
        case 11:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold11;
            break;
        case 12:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold12;
            break;
        case 13:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold13;
            break;
        case 14:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold14;
            break;
        case 15:
            ttl_threshold = ipe_mpls_ttl_threshold.ttl_threshold15;
            break;
        default:
            break;
    }

    if (ds_mpls.ttl_check_mode)
    {
        ttl_checked = ipe_mpls_ctl.mpls_ttl_limit;
    }
    else
    {
        ttl_checked = ttl_threshold;
    }

    ttl_check_fail = packet_ttl < ttl_checked;

    /* current label ttl check */
    if ((!is_section_oam_label && ttl_check_fail)
        || (is_section_oam_label && (0 == (mpls_label & 0xFF)) && ipe_mpls_ctl.gal_ttl_check_en))
    {
        mpls_ttl_check_fail = TRUE;
    }

    /* next label 1 ttl check(OAM label ttl > 0, entropy label is 0) */
    if ((oam_mep_en && mpls_label_next1_is_13 && (0 == (mpls_label_next1 & 0xFF)) && ipe_mpls_ctl.gal_ttl_check_en)
        || (ds_mpls.entropy_label_en && !mpls_label_next1_is_13 && (0 != (mpls_label_next1 & 0xFF))
           && ipe_mpls_ctl.entropy_label_ttl_check_en))
    {
        mpls_ttl_check_fail = TRUE;
    }

    /* next label 2 ttl check(both OAM and entorpy label, entropy label ttl must be 0) */
    if (ds_mpls.entropy_label_en && mpls_label_next1_is_13
        && (0 != (mpls_label_next2 & 0xFF)) && ipe_mpls_ctl.entropy_label_ttl_check_en)
    {
        mpls_ttl_check_fail = TRUE;
    }

    /* sbit check */
    sbit_check_error = ds_mpls.s_bit_check_en && (IS_BIT_SET(mpls_label, 8) != ds_mpls.s_bit);

    /* current label sbit check */
    if (is_section_oam_label && !IS_BIT_SET(mpls_label, 8) && ipe_mpls_ctl.gal_sbit_check_en)  /* section OAM not support entropy label */
    {
        mpls_sbit_error = TRUE; /* not support per interface TTL, sBit, EXP check, only 1 DsMpls for label 13 */

        if (!pkt_info->exception_en && ipe_mpls_ctl.section_oam_sbit_error_exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_SECTION_OAM_EXP;
        }
    }
    else if (!is_section_oam_label && !mpls_label_next1_is_13 && !ds_mpls.entropy_label_en && sbit_check_error)
    {
        mpls_sbit_error = TRUE;
    }

    /* next label 1 sbit check(OAM label sbit, entropy label sbit) */
    if (((oam_mep_en || oam_mip_en) && mpls_label_next1_is_13 && !ds_mpls.entropy_label_en && !IS_BIT_SET(mpls_label_next1, 8) && ipe_mpls_ctl.gal_sbit_check_en)
        || (!mpls_label_next1_is_13 && ds_mpls.entropy_label_en && !IS_BIT_SET(mpls_label_next1, 8) && ipe_mpls_ctl.entropy_label_sbit_check_en))
    {
        mpls_sbit_error = TRUE;
    }

    /* next label 2 sbit check(both OAM and entropy label,entropy label sbit) */
    if (mpls_label_next1_is_13 && ds_mpls.entropy_label_en && !IS_BIT_SET(mpls_label_next1, 8)
        && !IS_BIT_SET(mpls_label_next2, 8) && ipe_mpls_ctl.entropy_label_sbit_check_en)
    {
        mpls_sbit_error = TRUE;
    }

    mpls_label_outof_range = IS_BIT_SET(pkt_info->mpls_lbl_out_rang, label_count);

    switch ((mpls_label_outof_range << 2) | (mpls_sbit_error << 1) | mpls_ttl_check_fail)
    {
        case 1:
            mpls_escape_case = 2;
            break;
        case 2:
        case 3:
            mpls_escape_case = 1;
            break;
        case 4:
        case 5:
        case 6:
        case 7:
            mpls_escape_case = 0;
            break;
        default:
            mpls_escape_case = 3;
            break;
    }

    mpls_escape = mpls_label_outof_range || mpls_sbit_error || mpls_ttl_check_fail;

    if (mpls_escape)
    {
        /* MPLS_ESCAPE */
        pkt_info->fatal_exception_valid = TRUE;
        pkt_info->fatal_exception = ((2 << 2) | (mpls_escape_case & 0x3));
        pkt_info->ds_fwd_ptr_valid = FALSE;
        mpls_info->_continue = FALSE;
    }
    else
    {
        /* MPLS_OAM */
        mpls_label_next1_is_entropy = ds_mpls.entropy_label_en && !IS_BIT_SET(mpls_label, 8);
        mpls_label_next2_is_entropy = ds_mpls.entropy_label_en && !IS_BIT_SET(mpls_label_next1, 8);

        is_dcn_channel_next1 = ((mpls_label_next1 & 0xFFFF) == ipe_mpls_ctl.ach_dcn_channel_type0)
                               || ((mpls_label_next1 & 0xFFFF) == ipe_mpls_ctl.ach_dcn_channel_type1)
                               || ((1 == (mpls_label_next1 & 0xFFFF)) && ipe_mpls_ctl.mcc_channel_type_en)
                               || ((2 == (mpls_label_next1 & 0xFFFF)) && ipe_mpls_ctl.scc_channel_type_en);
        is_dcn_channel_next2 = ((mpls_label_next2 & 0xFFFF) == ipe_mpls_ctl.ach_dcn_channel_type0)
                               || ((mpls_label_next2 & 0xFFFF) == ipe_mpls_ctl.ach_dcn_channel_type1)
                               || ((1 == (mpls_label_next2 & 0xFFFF)) && ipe_mpls_ctl.mcc_channel_type_en)
                               || ((2 == (mpls_label_next2 & 0xFFFF)) && ipe_mpls_ctl.scc_channel_type_en);

        if ((is_section_oam_label && is_dcn_channel_next1) /* section DCN always to CPU */
            || ((1 == ds_mpls.dcn_check_type) && mpls_label_next1_is_13 && is_dcn_channel_next2) /* with GAL */
            || ((1 == ds_mpls.dcn_check_type) && ds_mpls.cw_exist && is_dcn_channel_next1))
        {
            if (!pkt_info->exception_en)
            {
                pkt_info->exception_en = TRUE; /* TTL, sbit, EXP checked by CPU */
                pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
                pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_DCN;
            }

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_MPLSTP_MCC_SCC_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Section DCN discard and exception to CPU!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (((2 == ds_mpls.dcn_check_type) && mpls_label_next1_is_13 && is_dcn_channel_next2)
            || ((2 == ds_mpls.dcn_check_type) && ds_mpls.cw_exist && is_dcn_channel_next1)) /* DCN forwarding */
        {
            dcn_forwarding_en = TRUE;
            dcn_pid = ((mpls_label_next1_is_13 ? mpls_label_next3:mpls_label_next2) >> 16) & 0xFFFF;
        }
        else if (is_section_oam_label)                                  /* Section OAM */
        {
            pkt_info->rx_oam_type = OAM_ACH;
            oam_en = TRUE;
            pkt_info->link_or_section_OAM = TRUE;
            pkt_info->gal_exist = TRUE;

            ach = mpls_label_next1;  /* sectin OAM not support Entropy label */
        }
        else if (mpls_label_next1_is_13)     /* LSP with ACH GAL */
        {
            pkt_info->rx_oam_type = OAM_ACH;
            oam_en = TRUE;
            pkt_info->mpls_extra_payload_offset = 1 + mpls_label_next2_is_entropy;
            pkt_info->gal_exist = TRUE;
            pkt_info->entropy_label_exist = mpls_label_next2_is_entropy;

            if (mpls_label_next2_is_entropy)
            {
                ach = mpls_label_next3; /* Up to 3 LSP, only 6 label's to Pass */
            }
            else
            {
                ach = mpls_label_next2;
            }
        }
        else if ((ds_mpls.cw_exist && !mpls_label_next1_is_13) /* PW with ACH CW */
                 && ((mpls_label_next1_is_entropy && (1 == ((label_next2 >> 16) & 0xF)))
                 || (IS_BIT_SET(mpls_label, 8) && (1 == ((label_next1 >> 16) & 0xF)))))
        {
            pkt_info->rx_oam_type = OAM_ACH; /* VCCV type 2/3 to CPU MS-PW? */
            oam_en = TRUE;
            pkt_info->mpls_extra_payload_offset = mpls_label_next1_is_entropy;
            pkt_info->entropy_label_exist = mpls_label_next1_is_entropy;
            ach = IS_BIT_SET(mpls_label, 8) ? mpls_label_next1 : mpls_label_next2;
        }
        else if ((ds_mpls.cw_exist && !mpls_label_next1_is_13 && !pkt_info->exception_en) /* not data/OAM */
                 && ((mpls_label_next1_is_entropy && (0 != ((label_next2 >> 17) & 0x7)))
                 || (IS_BIT_SET(mpls_label, 8) && (0 != ((label_next1 >> 17) & 0x7)))))
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_ACH_ERR;
            pkt_info->rx_oam_type = OAM_NONE;

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_L3_EXCEPTION;

                CMODEL_DEBUG_OUT_INFO("++++ Discard! l3 exception discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        /* OAM termination */
        if ((OAM_CHECK_TYPE_TO_CPU == ds_mpls.oam_check_type) && (OAM_ACH == pkt_info->rx_oam_type))  /* to CPU */
        {
            if (!pkt_info->exception_en)
            {
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
                pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_RESERVED3;
            }

            pkt_info->rx_oam_type = OAM_NONE;

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_OAM_DIS;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! TunnelTerminate: OAM discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if ((OAM_CHECK_TYPE_OAM_DISCARD == ds_mpls.oam_check_type) && (OAM_ACH == pkt_info->rx_oam_type)) /*discard OAM*/
        {
            pkt_info->rx_oam_type = OAM_NONE;
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_OAM_DIS;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! TunnelTerminate: OAM discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (((OAM_CHECK_TYPE_NONE == ds_mpls.oam_check_type) && (OAM_ACH == pkt_info->rx_oam_type))
                 || ((OAM_CHECK_TYPE_MIP == ds_mpls.oam_check_type) && (OAM_ACH == pkt_info->rx_oam_type)
                 && (1 != (mpls_label & 0xFF))))
        {
            pkt_info->rx_oam_type = OAM_NONE;
        }
        /*============ bug 4779 ECO begin=========*/
        //pkt_info->mpls_mep_check = (OAM_CHECK_TYPE_MEP == ds_mpls.oam_check_type);
        pkt_info->mpls_mep_check = (OAM_CHECK_TYPE_MEP == ds_mpls.oam_check_type)||(OAM_CHECK_TYPE_DATA_DISCARD == ds_mpls.oam_check_type);
        /*============ bug 4779 ECO end=========*/
        pkt_info->is_mpls_ttl_one = (1 == (mpls_label & 0xFF));

        if ((OAM_CHECK_TYPE_DATA_DISCARD == ds_mpls.oam_check_type) && !oam_en)  /* lock,discard */
        {
            pkt_info->rx_oam_type = OAM_NONE;

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_OAM_DIS;

                CMODEL_DEBUG_OUT_INFO("++++ Discard! TunnelTerminate: OAM discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (OAM_ACH == pkt_info->rx_oam_type) /* ACH OAM */
        {
            mpls_info->parser_layer4_type = L4_TYPE_ACH_OAM;

            if ((1 != ((ach >> 28) & 0xF)) && !pkt_info->exception_en) /* G-ACH first nibble check */
            {
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
                pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_ACH_ERR;
                pkt_info->rx_oam_type = OAM_NONE;

                if (!pkt_info->discard)
                {
                    pkt_info->discard = TRUE;
                    pkt_info->discard_type = IPE_DISCARD_L3_EXCEPTION;

                    CMODEL_DEBUG_OUT_INFO("++++ Discard! l3 exception discard!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
            else if (!pkt_info->link_or_section_OAM)
            {
                pkt_info->mpls_mep_index = ds_mpls.mep_index & 0x1FFF;
                pkt_info->mpls_oam_dest_chipid = (ds_mpls.oam_dest_chipid4 << 4)
                                                 | (ds_mpls.oam_dest_chipid3_2 << 2)
                                                 | ds_mpls.oam_dest_chipid1_0;
            }
        }

        is_mpls_oam_exception = pkt_info->exception_en && (pkt_info->exception_index == EXCEPTION_TYPE_OTHER)
                                && ((pkt_info->exception_sub_index > 7) && (pkt_info->exception_sub_index <= 14));

        /* MPLS_LABEL_PROCESS */
        if (ds_mpls.ttl_decrease_mode && ds_mpls.ttl_decrease_en) /* ttlDecreaseMode */
        {
           pkt_info->packet_ttl = (packet_ttl > ttl_threshold) ? (packet_ttl - ttl_threshold) : 0;
        }
        else if (ds_mpls.ttl_decrease_en)
        {
           pkt_info->packet_ttl = (packet_ttl > ipe_mpls_ctl.mpls_ttl_decrement) ?
                                  (packet_ttl - ipe_mpls_ctl.mpls_ttl_decrement) : 0;
        }
        else
        {
            pkt_info->packet_ttl = packet_ttl;
        }

        /* when trust DSCP or IP-PREC */
        if (ds_mpls.overwrite_priority && ((QOS_POLICY_TRUST_DSCP == pkt_info->qos_policy)
            || (QOS_POLICY_TRUST_IP_PRECEDENCE == pkt_info->qos_policy)))
        {
            pkt_info->mpls_overwrite_priority = TRUE;

            if (ds_mpls.llsp_valid) /* llspValid */
            {
                llsp = TRUE;
                color_offset = (pkt_info->qos_domain << 3) | (exp & 0x7);
                priority_offset = (pkt_info->qos_domain << 3) | ds_mpls.llsp_priority;
            }
            else
            {
                color_offset = (pkt_info->qos_domain << 3) | (exp & 0x7);
                priority_offset = (pkt_info->qos_domain << 3) | (exp & 0x7);
            }

            field_id = IpeMplsExpMap_Color0_f + color_offset;
            cmd = DRV_IOR(IpeMplsExpMap_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &color_tmp));

            field_id = IpeMplsExpMap_Priority0_f + priority_offset;
            cmd = DRV_IOR(IpeMplsExpMap_t, field_id);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &priority_tmp));

            pkt_info->color = color_tmp & 0x3;
            pkt_info->priority = priority_tmp & 0x3F;
        }

        path_sel_priority_id = IpeIntfMapperClaPathMap_PriorityPathSelect0_f
                               + (pkt_info->priority % IPE_INTF_MAPPER_CLA_PATH_MAP_MAX_INDEX);
        cmd = DRV_IOR(IpeIntfMapperClaPathMap_t, path_sel_priority_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->priority/IPE_INTF_MAPPER_CLA_PATH_MAP_MAX_INDEX,
                                          cmd, &priority_path_select));
        switch (exp & 0x7)
        {
            case 0:
                exp_policer_offset = ipe_mpls_ctl.exp_policer_offset0;
                break;
            case 1:
                exp_policer_offset = ipe_mpls_ctl.exp_policer_offset1;
                break;
            case 2:
                exp_policer_offset = ipe_mpls_ctl.exp_policer_offset2;
                break;
            case 3:
                exp_policer_offset = ipe_mpls_ctl.exp_policer_offset3;
                break;
            case 4:
                exp_policer_offset = ipe_mpls_ctl.exp_policer_offset4;
                break;
            case 5:
                exp_policer_offset = ipe_mpls_ctl.exp_policer_offset5;
                break;
            case 6:
                exp_policer_offset = ipe_mpls_ctl.exp_policer_offset6;
                break;
            case 7:
                exp_policer_offset = ipe_mpls_ctl.exp_policer_offset7;
                break;
            default:
                break;
        }

        /* select stats,policer,aps */
        field_stats_en = FALSE;
        field_policer_en = FALSE;
        field_aps_en = FALSE;

        switch (ds_mpls.policer_ptr_share_mode)
        {
        case 0:
            /* DsMpls.statsPtr is stats pointer,DsMpls.mplsFlowPolicerPtr is policer pointer */
            field_stats_en = TRUE;
            field_policer_en = TRUE;
            stats_ptr = ds_mpls.stats_ptr;
            policer_ptr = ds_mpls.mpls_flow_policer_ptr;

            break;
        case 1:
            /* DsMpls.statsPtr is stats pointer,DsMpls.mplsFlowPolicerPtr is aps pointer */
            field_stats_en = TRUE;
            field_aps_en = TRUE;
            stats_ptr = ds_mpls.stats_ptr;
            aps_ptr = ds_mpls.mpls_flow_policer_ptr;

            break;
        case 2:
            /* DsMpls.statsPtr is aps group,DsMpls.mplsFlowPolicerPtr is policer pointer */
            field_aps_en = TRUE;
            field_policer_en = TRUE;
            aps_ptr = ds_mpls.stats_ptr&0x7FF;
            policer_ptr = ds_mpls.mpls_flow_policer_ptr;

            break;
        case 3:
            /* DsMpls.statsPtr is stats pointer and policer pointer,DsMpls.mplsFlowPolicerPtr is aps pointer */
            field_stats_en = TRUE;
            field_policer_en = TRUE;
            field_aps_en = TRUE;
            stats_ptr = ds_mpls.stats_ptr + ipe_mpls_ctl.stats_ptr_base;
            policer_ptr = (ds_mpls.stats_ptr&0x1FFF) + ipe_mpls_ctl.policer_ptr_base;
            aps_ptr = ds_mpls.mpls_flow_policer_ptr;

            break;
        default:
            break;
        }

        if (field_stats_en)
        {
            if (0 != stats_ptr)
            {
                if (!pkt_info->flow_stats1_valid && ds_mpls.stats_mode)
                {
                    pkt_info->flow_stats1_valid = TRUE;
                    pkt_info->flow_stats1_ptr = stats_ptr;
                }
                else if (!pkt_info->flow_stats2_valid && (!ds_mpls.stats_mode))
                {
                    pkt_info->flow_stats2_valid = TRUE;
                    pkt_info->flow_stats2_ptr = stats_ptr;
                }
            }
        }

        if (field_policer_en)
        {
            if (0 != policer_ptr)
            {
                if (ds_mpls.service_policer_valid && !pkt_info->service_policer_valid)
                {
                    /* service policer */
                    pkt_info->service_policer_valid = TRUE;
                    pkt_info->service_policer_ptr = policer_ptr;
                }
                else if (!pkt_info->flow_policer_valid)
                {
                    /* for tunnel label + VC label(service policer disabled,flow policer) */
                    pkt_info->flow_policer_valid = TRUE;
                    /* ===== bug 4627 ECO begine ==== */
                    //pkt_info->flow_policer_ptr = policer_ptr + (llsp ? exp_policer_offset : 0);
                    pkt_info->flow_policer_ptr = policer_ptr + (!llsp ? exp_policer_offset : 0);
                    /* ===== bug 4627 ECO end ==== */
                }
            }
        }

        if (field_aps_en && ds_mpls.aps_select_valid && (3 != mpls_info->aps_num))
        {
            switch (mpls_info->aps_num & 0x3)
            {
            case 0:
                pkt_info->aps_select_valid0 = ds_mpls.aps_select_valid;
                pkt_info->aps_select_protecting_path0 = ds_mpls.aps_select_protecting_path;
                pkt_info->aps_select_group_id0 = aps_ptr;
                break;
            case 1:
                pkt_info->aps_select_valid1 = ds_mpls.aps_select_valid;
                pkt_info->aps_select_protecting_path1 = ds_mpls.aps_select_protecting_path;
                pkt_info->aps_select_group_id1 = aps_ptr;
                break;
            case 2:
                pkt_info->aps_select_valid2 = ds_mpls.aps_select_valid;
                pkt_info->aps_select_protecting_path2 = ds_mpls.aps_select_protecting_path;
                pkt_info->aps_select_group_id2 = aps_ptr;
                break;
            default:
                break;
            }

            if (OAM_ACH == pkt_info->rx_oam_type)
            {
                /* ===== bug 4630 ECO begine ==== */
                //pkt_info->aps_level_for_oam = label_count;
                pkt_info->aps_level_for_oam = mpls_info->aps_num;
                /* ===== bug 4630 ECO end ==== */
            }

            mpls_info->aps_num += 1;
        }
        else if (!pkt_info->link_or_section_OAM)
        {
            pkt_info->aps_level_for_oam = 3;
        }

        if (ds_mpls.label_space_valid)
        {
            pkt_info->mpls_label_space = ds_mpls.ds_fwd_ptr & 0xFF;   /* mplsLabelSpace[7:0] */

            if (ds_mpls.upstream_label_space)
            {
                pkt_info->mpls_label_space_valid = TRUE;
            }
        }

        if ((LM_TYPE_NONE != ds_mpls.lm_type) && !is_mpls_oam_exception
            && (3 != mpls_info->mpls_lm_index))
        {
            /* Only ACH,both data and OAM to lmLookup,but only count data packet */
            if (mpls_info->mpls_lm_index == 0)
            {
                pkt_info->lm_type0 = ds_mpls.lm_type;
                pkt_info->mpls_lm_cos_type0 = ds_mpls.lm_cos_type;
                pkt_info->mpls_lm_cos0 = ds_mpls.lm_cos;
                pkt_info->mpls_lm_base0 = ds_mpls.lm_base;
                pkt_info->packet_cos0 = (mpls_label_hdr[label_count] >> 9) & 0x7;
                pkt_info->mpls_lm_type0 = ds_mpls.mpls_lm_type;
            }
            else if (mpls_info->mpls_lm_index == 1)
            {
                pkt_info->lm_type1 = ds_mpls.lm_type;
                pkt_info->mpls_lm_cos_type1 = ds_mpls.lm_cos_type;
                pkt_info->mpls_lm_cos1 = ds_mpls.lm_cos;
                pkt_info->mpls_lm_base1 = ds_mpls.lm_base;
                pkt_info->packet_cos1 = (mpls_label_hdr[label_count] >> 9) & 0x7;
                pkt_info->mpls_lm_type1 = ds_mpls.mpls_lm_type;
            }
            else if (mpls_info->mpls_lm_index == 2)
            {
                pkt_info->lm_type2 = ds_mpls.lm_type;
                pkt_info->mpls_lm_cos_type2 = ds_mpls.lm_cos_type;
                pkt_info->mpls_lm_cos2 = ds_mpls.lm_cos;
                pkt_info->mpls_lm_base2 = ds_mpls.lm_base;
                pkt_info->packet_cos2 = (mpls_label_hdr[label_count] >> 9) & 0x7;
                pkt_info->mpls_lm_type2 = ds_mpls.mpls_lm_type;
            }

            if (OAM_ACH == pkt_info->rx_oam_type)
            {
                pkt_info->oam_lookup_num = mpls_info->mpls_lm_index; /* OAM payload match which LM label */
            }

            mpls_info->mpls_lm_index += 1;
        }

        if (ds_mpls.cw_exist                            /* Only for data traffic */
            && ((IS_BIT_SET(mpls_label, 8) && (0 == ((label_next1 >> 16) & 0xF)))
                || (!IS_BIT_SET(mpls_label, 8) && (0 == ((label_next2 >> 16) & 0xF)))))
        {
            pkt_info->is_leaf = IS_BIT_SET(mpls_label, 8) ? IS_BIT_SET(label_next1, 15)
                                                          : IS_BIT_SET(label_next2, 15);
        }

        pkt_info->logic_port_type |= ds_mpls.logic_port_type;

        if (0 != ds_mpls.logic_src_port)
        {
            pkt_info->inner_logic_src_port_valid = TRUE;
            pkt_info->inner_logic_src_port = (1 << 14) | ds_mpls.logic_src_port;
        }

        if (ds_mpls.service_acl_qo_s_en)
        {
            pkt_info->service_acl_qos_en = TRUE;
        }

        /* DESTINATION */
        mpls_sbit = IS_BIT_SET(mpls_label, 8);

        if (dcn_forwarding_en)
        {
            if ((0x21 == dcn_pid) && ipe_mpls_ctl.dcn_pid_ipv4_en)
            {
                pkt_info->payload_packet_type = PKT_TYPE_IPV4;
            }
            else if ((0x57 == dcn_pid) && ipe_mpls_ctl.dcn_pid_ipv6_en)
            {
                pkt_info->payload_packet_type = PKT_TYPE_IPV6;
            }
            else if (dcn_pid == ipe_mpls_ctl.dcn_pid0)
            {
                pkt_info->payload_packet_type = ipe_mpls_ctl.dcn_pid_packet_type0;
            }
            else if (dcn_pid == ipe_mpls_ctl.dcn_pid1)
            {
                pkt_info->payload_packet_type = ipe_mpls_ctl.dcn_pid_packet_type1;
            }
            else
            {
                pkt_info->payload_packet_type = PKT_TYPE_RESERVED;
            }
        }
        else if (OAM_ACH == pkt_info->rx_oam_type)
        {
            pkt_info->force_parser = TRUE;
            pkt_info->payload_packet_type = PKT_TYPE_MPLS; /* OAMEngine process LBM not use it */
        }
        else if (is_mpls_oam_exception)
        {
            pkt_info->payload_packet_type = pkt_info->packet_type;   /* keep old packetType[2:0] */
        }
        else if (mpls_sbit || ds_mpls.entropy_label_en)
        {
            pkt_info->payload_packet_type = ds_mpls.packet_type;     /* use inner packetType[2:0] */
        }
        else
        {
            pkt_info->payload_packet_type = PKT_TYPE_MPLS;           /* MPLS */
        }

        if (0 != ds_mpls.ds_fwd_ptr)
        {
            if (ds_mpls.fid_valid)
            {
                pkt_info->fid_type = ds_mpls.fid_type;

                if (!ds_mpls.fid_type)
                {
                    pkt_info->vrf_id = ds_mpls.ds_fwd_ptr & 0x3FFF;
                }
                else
                {
                    pkt_info->inner_vsi_id_valid = TRUE;
                    pkt_info->inner_vsi_id = ds_mpls.ds_fwd_ptr & 0x3FFF;
                }
            }
            else
            {
                if (ds_mpls.next_hop_ptr_valid)
                {
                    pkt_info->ds_fwd_ptr_valid = FALSE;
                    pkt_info->next_hop_ptr_valid = TRUE;
                    pkt_info->ad_next_hop_ptr = ds_mpls.ds_fwd_ptr;                       /* nextHopPtr[15:0] */
                    pkt_info->ad_dest_map = ((ds_mpls.lm_base & 0x3F) << 16)              /* adDestMap[21:16] */
                                         | (ds_mpls.oam_dest_chipid3_2 << 14)          /* adDestMap[15:14] */
                                         | ds_mpls.mep_index;                          /* adDestMap[13:0] */
                    pkt_info->ad_length_adjust_type = IS_BIT_SET(ds_mpls.lm_base, 13);    /* lengthAdjustType */
                    pkt_info->ad_critical_packet = IS_BIT_SET(ds_mpls.lm_base, 12);       /* criticalPacket */
                    pkt_info->ad_next_hop_ext = IS_BIT_SET(ds_mpls.lm_base, 11);          /* nextHopExt */
                    pkt_info->ad_send_local_phy_port = IS_BIT_SET(ds_mpls.lm_base, 10);   /* sendLocalPhyPort */
                    pkt_info->ad_aps_type = (ds_mpls.lm_base >> 8) & 0x3;                 /* apsType[1:0] */
                    pkt_info->ad_speed = (ds_mpls.lm_base >> 6) & 0x3;                    /* speed[1:0] */
                }
                else if (ds_mpls.priority_path_en)
                {
                    pkt_info->ds_fwd_ptr_valid = TRUE;
                    pkt_info->ds_fwd_ptr = ds_mpls.ds_fwd_ptr + priority_path_select;
                }
                else
                {
                    pkt_info->ds_fwd_ptr_valid = TRUE;
                    pkt_info->ds_fwd_ptr = ds_mpls.ds_fwd_ptr
                           + parser_result->l3_s.ip_ecmp_hash % (ds_mpls.equal_cost_path_num + 1);
                    pkt_info->ecmp_hash = parser_result->l3_s.ip_ecmp_hash;
                }
            }
        }

        /* payloadOffset */
        if (dcn_forwarding_en)
        {
            mpls_info->mpls_offset = mpls_info->mpls_offset + 2 + ((2 + mpls_label_next1_is_13) << 2);

            if ((pkt_info->payload_packet_type == PKT_TYPE_IPV4) || (pkt_info->payload_packet_type == PKT_TYPE_IPV6))
            {
                if (ipe_mpls_ctl.dcn_vrf_id_en)
                {
                    pkt_info->vrf_id = ipe_mpls_ctl.vrf_id;
                }
            }
            else
            {
                if (ipe_mpls_ctl.dcn_vsi_id_en)
                {
                    pkt_info->inner_vsi_id_valid = TRUE;
                    pkt_info->inner_vsi_id = ipe_mpls_ctl.vsi_id;
                }
            }
        }
        else if (OAM_ACH == pkt_info->rx_oam_type)
        {
            mpls_info->mpls_offset = (label_count + 1 + pkt_info->mpls_extra_payload_offset) << 2;
        }
        else
        {
            mpls_info->mpls_offset += (ds_mpls.entropy_label_en << 2)
                          + (ds_mpls.offset_bytes << ipe_mpls_ctl.mpls_offset_bytes_shift);
        }

        if (first_label && ds_mpls.tunnel_ptp_en) /* Only outerest label's PTP, MPLS Mcast */
        {
            pkt_info->tunnel_ptp_en = TRUE;
        }

        if (((PKT_TYPE_IPV4 == pkt_info->payload_packet_type) || (PKT_TYPE_IPV6 == pkt_info->payload_packet_type))
            && (OAM_CHECK_TYPE_MEP == ds_mpls.oam_check_type))
        {
            pkt_info->force_parser = TRUE;
        }

        mpls_info->_continue = ds_mpls._continue && (!mpls_sbit) && (!is_mpls_oam_exception)
                               && (OAM_ACH != pkt_info->rx_oam_type) && (!dcn_forwarding_en);

        if (pkt_info->tunnel_ptp_en && !mpls_info->_continue)
        {
            if (mpls_sbit)
            {
                /* No next label */
                pkt_info->force_parser = TRUE;
                pkt_info->ptp_extra_offset = 0;

                if (4 == ((label_next1 >> 16) & 0xF))
                {
                    pkt_info->payload_packet_type = PKT_TYPE_IPV4;
                }
                else if (6 == ((label_next1 >> 16) & 0xF))
                {
                    pkt_info->payload_packet_type = PKT_TYPE_IPV6;
                }
                else/* control word prepended, payloadOffset not include control word in EPE so EPE parsing must skip it*/
                {
                    pkt_info->payload_packet_type = PKT_TYPE_ETHERNETV2;
                }
            }
            else if (IS_BIT_SET(mpls_label_next1, 8)) /* mplsLabelNext1.sBit=1 and mplsSbit=0 */
            {
                /* One next label */
                pkt_info->force_parser = TRUE;

                if (4 == ((label_next2 >> 16) & 0xF))
                {
                    pkt_info->ptp_extra_offset = 1;
                    pkt_info->payload_packet_type = PKT_TYPE_IPV4;
                }
                else if (6 == ((label_next2 >> 16) & 0xF))
                {
                    pkt_info->ptp_extra_offset = 1;
                    pkt_info->payload_packet_type = PKT_TYPE_IPV6;
                }
                else
                {
                    pkt_info->ptp_extra_offset = 2;
                    pkt_info->payload_packet_type = PKT_TYPE_ETHERNETV2;
                }


            }
            else if (!(mpls_sbit && IS_BIT_SET(mpls_label_next1, 8)))/* mplsLabelNext1.sBit=0 and mplsSbit=0 */
            {
                /* Two next labels */
                if (label_count != 3)
                {
                    pkt_info->force_parser = TRUE;

                    if (4 == ((label_next3 >> 16) & 0xF))
                    {
                        pkt_info->ptp_extra_offset = 2;
                        pkt_info->payload_packet_type = PKT_TYPE_IPV4;
                    }
                    else if (6 == ((label_next3 >> 16) & 0xF))
                    {
                        pkt_info->ptp_extra_offset = 2;
                        pkt_info->payload_packet_type = PKT_TYPE_IPV6;
                    }
                    else
                    {
                        pkt_info->ptp_extra_offset = 3;
                        pkt_info->payload_packet_type = PKT_TYPE_ETHERNETV2;
                    }
                }
                else
                {
                    if (!pkt_info->exception_en)
                    {
                        pkt_info->exception_en = TRUE;
                        pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
                        pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PTP;
                    }

                    if (!pkt_info->discard)
                    {
                        pkt_info->discard = TRUE;
                        pkt_info->discard_type = IPE_DISCARD_PTP_ACL_EXCEPTION;

                        CMODEL_DEBUG_OUT_INFO("++++ Discard! ptp acl exception discard!\n");
                        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                    }
                }
            }
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_ipe_tunnel_terminate_pbb_operation
* Purpose:    IPE tunnel termination pbb operation.
* Parameters:
*  Input:     in_pkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
* Output:     p_ipe_inpkt -- pointer to buffer which save input packet
*                            and packet header ,and processing informations.
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
static int32
_cm_ipe_tunnel_terminate_pbb_operation(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    ipe_tunnel_decap_ctl_t ipe_tunnel_decap_ctl;
    ds_tunnel_id_t ds_tunnel_id ;

    uint8 chip_id = in_pkt->chip_id;
    uint8 lookup_result_valid = FALSE;
    uint8 mcast = FALSE;
    uint32 cmd = 0;

    sal_memset(&ipe_tunnel_decap_ctl, 0, sizeof(ipe_tunnel_decap_ctl_t));
    cmd = DRV_IOR(IpeTunnelDecapCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_tunnel_decap_ctl));


    sal_memset(&ds_tunnel_id, 0, sizeof(ds_tunnel_id_t));

    if (pkt_info->tunnel_lookup_result1_valid)
    {
        lookup_result_valid = TRUE;
        sal_memcpy(&ds_tunnel_id, &pkt_info->userid_tunnel_lkp1_ad, sizeof(ds_tunnel_id_t));
    }
    else if (pkt_info->tunnel_lookup_result2_valid)
    {
        lookup_result_valid = TRUE;
        sal_memcpy(&ds_tunnel_id, &pkt_info->userid_tunnel_lkp2_ad, sizeof(ds_tunnel_id_t));
    }

    mcast = (pkt_info->bcast_mac_address || pkt_info->mcast_mac_address);

    if (lookup_result_valid)
    {
        pkt_info->tunnel_ptp_en = ds_tunnel_id.tunnel_ptp_en;
        pkt_info->logic_port_type |= ds_tunnel_id.logic_port_type;

        if ((0 != ds_tunnel_id.stats_ptr) && !pkt_info->flow_stats1_valid)
        {
            pkt_info->flow_stats1_valid = TRUE;
            pkt_info->flow_stats1_ptr = ds_tunnel_id.stats_ptr;
        }

        if (IS_BIT_SET(ds_tunnel_id.binding_data_high, 14)           /* servicePolicerValid */
            && (0 != (ds_tunnel_id.binding_data_low & 0x1FFF)))      /* flowPolicerPtr */
        {
            pkt_info->service_policer_valid = IS_BIT_SET(ds_tunnel_id.binding_data_high, 14);
            pkt_info->service_policer_mode = IS_BIT_SET(ds_tunnel_id.binding_data_high, 0);
            pkt_info->service_policer_ptr = ds_tunnel_id.binding_data_low & 0x1FFF;
        }

        if (!IS_BIT_SET(ds_tunnel_id.binding_data_high, 14) && (0 != (ds_tunnel_id.binding_data_low & 0x1FFF)))
        {
            pkt_info->flow_policer_valid = TRUE;
            pkt_info->flow_policer_ptr = ds_tunnel_id.binding_data_low & 0x1FFF;
        }

        if (0 != ((ds_tunnel_id.binding_data_low >> 15) & 0x3FFF))   /* logicSrcPort */
        {
            pkt_info->inner_logic_src_port_valid = TRUE;
            pkt_info->inner_logic_src_port = (ds_tunnel_id.binding_data_low >> 15) & 0x3FFF;
        }

        if (ds_tunnel_id.ds_fwd_ptr_valid && (0xFFFF == ds_tunnel_id.fid))
        {
            if(!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_PBB_DECAP_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! PBB Decaps dsFwdPtr = 0xFFFF!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    if (PBB_PORT_TYPE_PIP == pkt_info->pbb_src_port_type)
    {
        if ((mcast || pkt_info->is_port_mac) && lookup_result_valid && !pkt_info->discard)
        {
            if (0 != ds_tunnel_id.fid)
            {
                pkt_info->vsi_id = (ds_tunnel_id.fid & 0x3FFF);
            }

            pkt_info->pip_bypass_learning = ds_tunnel_id.pip_bypass_learning;
            pkt_info->is_decap = ds_tunnel_id.is_tunnel;
            pkt_info->inner_packet_lookup = ds_tunnel_id.inner_packet_lookup;
            pkt_info->vsi_learning_disable = ds_tunnel_id.vsi_learning_disable;
            pkt_info->mac_security_vsi_discard |= ds_tunnel_id.mac_security_vsi_discard;
            pkt_info->igmp_snoop_en |= ds_tunnel_id.igmp_snoop_en;
            pkt_info->payload_offset = parser_result->l2_s.layer3_offset
                               + (ds_tunnel_id.tunnel_payload_offset << ipe_tunnel_decap_ctl.offset_byte_shift);
        }
        else
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_PBB_DECAP_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! PBB decap discard in tunnel terminate module!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }
    else if (PBB_PORT_TYPE_CBP == pkt_info->pbb_src_port_type)
    {
        if (lookup_result_valid && !pkt_info->discard)
        {
            if (0 != ds_tunnel_id.fid)
            {
                pkt_info->vsi_id = (ds_tunnel_id.fid & 0x3FFF);
            }

            if (ds_tunnel_id.isid_valid)
            {
                pkt_info->isid_translate_en = TRUE;
                pkt_info->new_isid = (ds_tunnel_id.isid << 9)
                                     | (ds_tunnel_id.ttl_update << 8)
                                     | (ds_tunnel_id.capwap_tunnel_type << 7)
                                     | (ds_tunnel_id.acl_qos_use_outer_info << 6)
                                     | (ds_tunnel_id.outer_vlan_is_cvlan << 5)
                                     | (ds_tunnel_id.ttl_check_en << 4)
                                     | (ds_tunnel_id.isatap_check_en << 3)
                                     | ds_tunnel_id.tunnel_gre_options;
            }
        }
        /* bvlan can't be retrieved at IPE,bvlan editing using Humber mode(information get at nexthop,editing at epe bridge) */
    }
    else if (PBB_PORT_TYPE_PNP == pkt_info->pbb_src_port_type)
    {
        if (pkt_info->is_port_mac && lookup_result_valid && !pkt_info->discard)
        {
            /* macDa is port mac,lookup result valid */
            if (ds_tunnel_id.is_tunnel)   /* unicast, decap */
            {
                pkt_info->is_decap = ds_tunnel_id.is_tunnel;
                pkt_info->inner_packet_lookup = ds_tunnel_id.inner_packet_lookup;
                pkt_info->pbb_outer_learning_enable = ds_tunnel_id.pbb_outer_learning_enable;

                if (0 != ds_tunnel_id.fid)
                {
                    pkt_info->inner_vsi_id_valid = TRUE;
                    pkt_info->inner_vsi_id = (ds_tunnel_id.fid & 0x3FFF);
                }

                pkt_info->payload_offset = parser_result->l2_s.layer3_offset
                               + (ds_tunnel_id.tunnel_payload_offset << ipe_tunnel_decap_ctl.offset_byte_shift);
            }
            else                          /* unicast, not decap. following bridging process */
            {
                if (0 != ds_tunnel_id.fid)
                {
                    pkt_info->vsi_id = (ds_tunnel_id.fid & 0x3FFF);
                }
            }
        }
        else if (!pkt_info->is_port_mac && pkt_info->pbb_mcast_loopback && lookup_result_valid && !pkt_info->discard)
        {
            /* mcast, after loopback, local member exists, need decap */
            if (0 != ds_tunnel_id.fid)
            {
                pkt_info->vsi_id = (ds_tunnel_id.fid & 0x3FFF);
            }

            pkt_info->is_decap = ds_tunnel_id.pbb_mcast_decap;
            pkt_info->inner_packet_lookup = ds_tunnel_id.inner_packet_lookup;
            pkt_info->pbb_outer_learning_disable = ds_tunnel_id.pbb_outer_learning_disable;
            pkt_info->vsi_learning_disable = ds_tunnel_id.vsi_learning_disable;
            pkt_info->mac_security_vsi_discard |= ds_tunnel_id.mac_security_vsi_discard;
            pkt_info->igmp_snoop_en |= ds_tunnel_id.igmp_snoop_en;
            pkt_info->payload_offset = parser_result->l2_s.layer3_offset
                            + (ds_tunnel_id.tunnel_payload_offset << ipe_tunnel_decap_ctl.offset_byte_shift);
        }
        /* else do nothing, follow general bridging/learning process */
    }

    if (pkt_info->inner_packet_lookup)
    {
        pkt_info->pbb_src_port_type = PBB_PORT_TYPE_PBB_NONE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_ipe_tunnel_terminate_tunnel_decaps1_op
* Purpose:    IPE tunnel termination tunnel decapsulate1 operation.
* Parameters:
*  Input:     in_pkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
*             p_ds_userid1 -- poped dsUserId1 table content pointer.
* Output:     p_ipe_inpkt -- pointer to buffer which save input packet
*                            and packet header ,and processing informations.
*             p_ds_userid1_info -- dsUserId1's output information pointer.
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
static int32
_cm_ipe_tunnel_terminate_tunnel_decaps1_op(ipe_in_pkt_t *in_pkt, tunnel_info_t *p_tunnel_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    ipe_tunnel_decap_ctl_t ipe_tunnel_decap_ctl;
    ipe_tunnel_id_ctl_t ipe_tunnel_id_ctl;
    ds_tunnel_id_t ds_tunnel_id ;

    uint8 chip_id = in_pkt->chip_id;
    uint8 gre_option = 0;
    uint8 rpf_check_ok = FALSE;
    uint8 isatap_check_ok = FALSE;
    uint8 bind_mis_match = FALSE;
    uint8 mac_bind_mis_match = FALSE, port_bind_mis_match = FALSE;
    uint8 ip_bind_mis_match = FALSE, vlan_bind_mis_match = FALSE, ip_vlan_bind_mis_match = FALSE;
    uint16 bind_vlan_id = 0;
    uint16 logic_src_port = 0;
    uint16 binding_data_43_30 = 0;
    uint16 gre_protocol = 0;
    uint16 unknown_protocol = 0;
    uint16 mac47_32 = 0;
    uint32 mac31_0 = 0;
    uint32 binding_data_35_4 = 0;
    uint32 cmd = 0;

    sal_memset(&ds_tunnel_id, 0, sizeof(ds_tunnel_id_t));
    sal_memcpy(&ds_tunnel_id, &(pkt_info->userid_tunnel_lkp1_ad), sizeof(ds_tunnel_id_t));

    /* FATAL_EXCEPTION_1 */
    if (parser_result->l3_s.ip_header_error)
    {
        pkt_info->fatal_exception_valid = TRUE;
        pkt_info->fatal_exception = FATAL_EXP_UC_IP_HDR_ERR_OR_IP_MARTION_ADDR;
    }

    if (parser_result->l3_s.ip_options)
    {
        if ((L3_TYPE_TRILL == parser_result->layer3_type) && ds_tunnel_id.trill_option_escape_en)
        {
            pkt_info->fatal_exception_valid= TRUE;
            pkt_info->fatal_exception = FATAL_EXP_TRILL_OPTION;
        }
        else
        {
            pkt_info->fatal_exception_valid= TRUE;
            pkt_info->fatal_exception = FATAL_EXP_UC_IP_OPTIONS;
        }
    }

    /* ESCAPE_CHECK_1 */
    if (pkt_info->fatal_exception_valid)
    {
        return DRV_E_NONE;
    }

    /* TUNNEL_PROPERTY_1 */
    pkt_info->is_decap = ds_tunnel_id.is_tunnel;
    p_tunnel_info->ds_tunnelid1_is_tunnel = ds_tunnel_id.is_tunnel;
    pkt_info->src_dscp = (parser_result->l3_s.tos.ip_tos >> 2) & 0x3F;

    if (ds_tunnel_id.tunnel_id_exception_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_USER_ID;
    }

    p_tunnel_info->tunnel1_is_esadi = (L3_TYPE_TRILL == parser_result->layer3_type)
                                        && parser_result->l3_s.ip_da.trill.is_esadi;

    /* different control bits for innerPacketLookup and parser ???, MPLS, etc */
    pkt_info->outer_vlan_is_cvlan = ds_tunnel_id.outer_vlan_is_cvlan;
    pkt_info->acl_qos_use_outer_info = ds_tunnel_id.acl_qos_use_outer_info;
    pkt_info->svlan_tpid_index = ds_tunnel_id.svlan_tpid_index;
    pkt_info->ttl_update = ds_tunnel_id.ttl_update;
    pkt_info->inner_packet_lookup = ds_tunnel_id.inner_packet_lookup;
    pkt_info->tunnel_rpf_check_request = ds_tunnel_id.tunnel_rpf_check_request;
    pkt_info->tunnel_ptp_en = ds_tunnel_id.tunnel_ptp_en;

    if (ds_tunnel_id.src_queue_select)
    {
        pkt_info->src_queue_select = TRUE;
    }

    if (ds_tunnel_id.vsi_learning_disable)
    {
        pkt_info->vsi_learning_disable = TRUE;
    }

    if (ds_tunnel_id.mac_security_vsi_discard)
    {
        pkt_info->mac_security_vsi_discard = TRUE;
    }

    if (ds_tunnel_id.igmp_snoop_en)
    {
        pkt_info->igmp_snoop_en = TRUE;
    }

    if (ds_tunnel_id.service_acl_qos_en)
    {
        pkt_info->service_acl_qos_en = TRUE;
    }

    if (ds_tunnel_id.logic_port_type)
    {
        pkt_info->logic_port_type = TRUE;
    }

    if (ds_tunnel_id.route_disable)
    {
        pkt_info->route_disable = TRUE;
    }

    if (ds_tunnel_id.deny_learning)
    {
        pkt_info->deny_learning = TRUE;
    }

    if (ds_tunnel_id.deny_bridge)
    {
        pkt_info->deny_bridge = TRUE;
    }

    if (ds_tunnel_id.ds_fwd_ptr_valid && (0 != ds_tunnel_id.fid) && (0xFFFF != ds_tunnel_id.fid)) /* dsFwdPtr */
    {
        p_tunnel_info->ds_tunnelid1_fwdptr_valid = TRUE;
        pkt_info->ds_fwd_ptr_valid = TRUE;
        pkt_info->ds_fwd_ptr = ds_tunnel_id.fid;
    }
    else if (!ds_tunnel_id.ds_fwd_ptr_valid && (1 == ((ds_tunnel_id.fid >> 14) & 0x3))) /* fid */
    {
        p_tunnel_info->ds_tunnelid1_fid_valid = TRUE;
        pkt_info->fid_type = ds_tunnel_id.fid_type;

        if (ds_tunnel_id.fid_type)
        {
            pkt_info->inner_vsi_id_valid = TRUE;
            pkt_info->inner_vsi_id = ds_tunnel_id.fid & 0x3FFF;
        }
        else
        {
            pkt_info->vrf_id = ds_tunnel_id.fid & 0x3FFF;
        }
    }
    else if (!ds_tunnel_id.ds_fwd_ptr_valid && (2 == ((ds_tunnel_id.fid >> 14) & 0x3))) /* labelSpace */
    {
        p_tunnel_info->ds_tunnelid1_label_space_valid = TRUE;
        pkt_info->mpls_label_space = ds_tunnel_id.fid & 0xFF;

        if (IS_BIT_SET(ds_tunnel_id.fid, 8))
        {
            pkt_info->mpls_label_space_valid = TRUE;
        }
    }

    if (ds_tunnel_id.ds_fwd_ptr_valid && (0xFFFF == ds_tunnel_id.fid))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_USER_ID_FWD_PTR_ALL_F_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! tunnel dsfwdptr is 0xFFFF!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if ((0 != ds_tunnel_id.stats_ptr) && !pkt_info->flow_stats1_valid)
    {
        pkt_info->flow_stats1_valid = TRUE;
        pkt_info->flow_stats1_ptr = ds_tunnel_id.stats_ptr;
    }

    /* For TRILL multicast decap without loopback, bindingData is userd for RPF check,
       logicSrcPort have to use other bits */
    if (ds_tunnel_id.trill_decap_without_loop)
    {
        logic_src_port = (ds_tunnel_id.pip_bypass_learning << 13)
                         | (ds_tunnel_id.tunnel_gre_options << 10)
                         | (((ds_tunnel_id.binding_data_high >> 13) & 0x7) << 7)
                         | (ds_tunnel_id.pbb_mcast_decap<< 6)
                         | (ds_tunnel_id.pbb_outer_learning_disable << 5)
                         | (ds_tunnel_id.pbb_outer_learning_enable << 4)
                         | (ds_tunnel_id.user_default_cos << 1)
                         | ds_tunnel_id.user_default_cfi;

        if (0 != logic_src_port)
        {
            p_tunnel_info->ds_tunnelid1_logic_src_port_valid = TRUE;
            pkt_info->inner_logic_src_port_valid = TRUE;
            pkt_info->inner_logic_src_port = (1 << 14) | (0x3FFF & logic_src_port);
        }
    }

    if (ds_tunnel_id.trill_multi_rpf_check)
    {
        binding_data_43_30 = ((ds_tunnel_id.binding_data_high & 0xFFF) << 2)
                             | ((ds_tunnel_id.binding_data_low >> 30) & 0x3);

        rpf_check_ok = (IS_BIT_SET(ds_tunnel_id.binding_data_low, 14)
                            && (pkt_info->global_src_port == (ds_tunnel_id.binding_data_low & 0x3FFF)))
                        || (IS_BIT_SET(ds_tunnel_id.binding_data_low, 29)
                            && (pkt_info->global_src_port == ((ds_tunnel_id.binding_data_low >> 15) & 0x3FFF)))
                        || (IS_BIT_SET(ds_tunnel_id.binding_data_high, 12)
                            && (pkt_info->global_src_port == binding_data_43_30))
                        || (IS_BIT_SET(ds_tunnel_id.isid, 14)
                            && (pkt_info->global_src_port == (ds_tunnel_id.isid & 0x3FFF)));

        if (!rpf_check_ok)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_TRILL_RPF_CHK_FAIL;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! TRILL tunnel RPF check fail!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (!rpf_check_ok && ds_tunnel_id.isid_valid) /* more RPF to CPU */
        {
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = FATAL_EXP_UC_OR_MC_MORE_RPF;
        }
    }
    else if (!ds_tunnel_id.binding_en)
    {
        if (IS_BIT_SET(ds_tunnel_id.binding_data_high, 13))   /* apsSelectValid */
        {
            p_tunnel_info->ds_tunnelid1_aps_select_valid = TRUE;

            if (!pkt_info->aps_select_valid0)
            {
                pkt_info->aps_select_valid0 = TRUE;
                pkt_info->aps_select_protecting_path0 = IS_BIT_SET(ds_tunnel_id.binding_data_high, 15);   /* apsSelectProtectingPath */
                pkt_info->aps_select_group_id0 = ((ds_tunnel_id.binding_data_high >> 1) & 0x7FF);         /* apsSelectGroupId */
            }
            else if (!pkt_info->aps_select_valid1)
            {
                pkt_info->aps_select_valid1 = TRUE;
                pkt_info->aps_select_protecting_path1 = IS_BIT_SET(ds_tunnel_id.binding_data_high, 15);
                pkt_info->aps_select_group_id1 = ((ds_tunnel_id.binding_data_high >> 1) & 0x7FF);
            }
            else if (!pkt_info->aps_select_valid2)
            {
                pkt_info->aps_select_valid2 = TRUE;
                pkt_info->aps_select_protecting_path2 = IS_BIT_SET(ds_tunnel_id.binding_data_high, 15);
                pkt_info->aps_select_group_id2 = ((ds_tunnel_id.binding_data_high >> 1) & 0x7FF);
            }
        }

        if (IS_BIT_SET(ds_tunnel_id.binding_data_high, 14)                                   /* servicePolicerValid */
            && (0 != (ds_tunnel_id.binding_data_low & 0x1FFF)))                              /* servicePolicerPtr */
        {
            pkt_info->service_policer_valid = IS_BIT_SET(ds_tunnel_id.binding_data_high, 14); /* servicePolicerValid */
            pkt_info->service_policer_mode = IS_BIT_SET(ds_tunnel_id.binding_data_high, 0);   /* servicePolicerMode */
            pkt_info->service_policer_ptr = ds_tunnel_id.binding_data_low & 0x1FFF;           /* servicePolicerPtr */
            p_tunnel_info->ds_tunnelid1_servic_policer_valid = TRUE;
        }

        if ((!IS_BIT_SET(ds_tunnel_id.binding_data_high, 14))                     /* flowPolicerValid */
             && (0 != (ds_tunnel_id.binding_data_low & 0x1FFF)))                  /* flowPolicerPtr */
        {
            pkt_info->flow_policer_valid = TRUE;
            pkt_info->flow_policer_ptr = ds_tunnel_id.binding_data_low & 0x1FFF;
            p_tunnel_info->ds_tunnelid1_flow_policer_valid = TRUE;
        }

        if (0 != ((ds_tunnel_id.binding_data_low >> 15) & 0x3FFF))                /* logicSrcPort */
        {
            p_tunnel_info->ds_tunnelid1_logic_src_port_valid = TRUE;
            pkt_info->inner_logic_src_port_valid = TRUE;
            pkt_info->inner_logic_src_port = (1 << 14) | ((ds_tunnel_id.binding_data_low >> 15) & 0x3FFF);
        }
    }
    else
    {
        if (ds_tunnel_id.binding_mac_sa)
        {
            mac47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
            mac31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                  parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);

            mac_bind_mis_match = ((ds_tunnel_id.binding_data_high != mac47_32)
                                 || (ds_tunnel_id.binding_data_low != mac31_0));
        }
        else if (!ds_tunnel_id.binding_mac_sa)
        {
            if (parser_result->l2_s.svlan_id_valid)
            {
                bind_vlan_id = parser_result->l2_s.svlan_id;
            }
            else
            {
                bind_vlan_id = parser_result->l2_s.cvlan_id;
            }

            binding_data_35_4 = ((ds_tunnel_id.binding_data_high & 0xF) << 28)
                                | (ds_tunnel_id.binding_data_low >> 4);

            switch (ds_tunnel_id.binding_data_low & 0x3)
            {
                case 0:
                    port_bind_mis_match
                        = (pkt_info->global_src_port != (ds_tunnel_id.binding_data_high & 0x3FFF)); /* [45:32] */
                    break;
                case 1:
                    vlan_bind_mis_match
                        = (bind_vlan_id != ((ds_tunnel_id.binding_data_high >> 4) & 0xFFF));       /* [47:36] */
                    break;
                case 2:
                    ip_bind_mis_match = ((parser_result->l3_s.ip_sa.ipv4.ipsa != binding_data_35_4)
                                            && L3_TYPE_IPV4 == parser_result->layer3_type);
                    break;
                case 3:
                    ip_vlan_bind_mis_match = (((bind_vlan_id != ((ds_tunnel_id.binding_data_high >> 4) & 0xFFF))
                                                || (parser_result->l3_s.ip_sa.ipv4.ipsa != binding_data_35_4))
                                             && (L3_TYPE_IPV4 == parser_result->layer3_type));
                    break;
                default:
                    break;
            }
        }

        bind_mis_match = mac_bind_mis_match || port_bind_mis_match || vlan_bind_mis_match
                         || ip_bind_mis_match || ip_vlan_bind_mis_match;

        if (bind_mis_match)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_USER_ID_BINDING_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! UserId binding discard(Mac/port/Ip/vlan/IpVlan bind mismatch)!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    /* TUNNEL_DECAP_1 */
    sal_memset(&ipe_tunnel_decap_ctl, 0, sizeof(ipe_tunnel_decap_ctl));
    cmd = DRV_IOR(IpeTunnelDecapCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_tunnel_decap_ctl));

    if ((ds_tunnel_id.trill_ttl_check_en) && (pkt_info->packet_ttl < ipe_tunnel_decap_ctl.trill_ttl))
    {
        pkt_info->fatal_exception_valid = TRUE;
        pkt_info->fatal_exception = FATAL_EXP_TRILL_TTL_CHECK_FAIL;
    }

    if (ipe_tunnel_decap_ctl.trillversion_check_en
        && (ipe_tunnel_decap_ctl.trill_version != parser_result->l3_s.ip_da.trill.trill_version)
        && (L3_TYPE_TRILL == parser_result->layer3_type))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_TRILL_VERSION_CHK_ERR;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! TRILL version check_0 fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (ipe_tunnel_decap_ctl.trill_bfd_check_en && (L3_TYPE_TRILL == parser_result->layer3_type)
        && (parser_result->l3_s.ip_da.trill.is_trill_bfd_echo || parser_result->l3_s.ip_da.trill.is_trill_bfd)
        && (parser_result->l3_s.ip_da.trill.trill_multicast
        || (parser_result->l3_s.ip_da.trill.trill_multi_hop && (pkt_info->packet_ttl <= ipe_tunnel_decap_ctl.trill_bfd_hop_count))
        || (!parser_result->l3_s.ip_da.trill.trill_multi_hop && (pkt_info->packet_ttl != 0x3F))))
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_TRILL_VERSION_CHK_ERR;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! TRILL version check_0 fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (parser_result->l3_s.ip_da.trill.is_trill_channel && parser_result->l3_s.ip_da.trill.is_trill_bfd_echo
        && ds_tunnel_id.trill_bfd_echo_en && !pkt_info->exception_en
        && (L3_TYPE_TRILL == parser_result->layer3_type))  /* Echo processing ?? */
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
        pkt_info->exception_sub_index = ds_tunnel_id.exception_sub_index;

        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_TRILL_ESADI_PKT_DISCARD;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! TRILL esadi packet!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }
    else if (parser_result->l3_s.ip_da.trill.is_trill_channel && parser_result->l3_s.ip_da.trill.is_trill_bfd
        && ds_tunnel_id.trill_bfd_en
        && (L3_TYPE_TRILL == parser_result->layer3_type))  /* TRILL BFD */
    {
        pkt_info->rx_oam_type = OAM_TRILL_BFD;
        pkt_info->payload_offset = parser_result->l2_s.layer3_offset
                                   + parser_result->l3_s.ip_da.trill.trill_inner_vlan_valid ? 24 : 20;
    }
    else if (parser_result->l3_s.ip_da.trill.is_trill_channel
        && ds_tunnel_id.trill_channel_en && !pkt_info->exception_en
        && (L3_TYPE_TRILL == parser_result->layer3_type))  /* TRILL OAM,ping,link trace */
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
        pkt_info->exception_sub_index = ds_tunnel_id.exception_sub_index;

        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_TRILL_ESADI_PKT_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! TRILL version check_1 fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if ((L3_TYPE_TRILL == parser_result->layer3_type) && parser_result->l3_s.ip_da.trill.is_esadi
        && ds_tunnel_id.esadi_check_en && !pkt_info->exception_en)
    {
        pkt_info->exception_en = TRUE;
        pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
        pkt_info->exception_sub_index = ds_tunnel_id.exception_sub_index;

        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_TRILL_ESADI_PKT_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! TRILL ESADI packet discard!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    if (ds_tunnel_id.ttl_check_en && (pkt_info->packet_ttl < ipe_tunnel_decap_ctl.ip_ttl_limit))
    {
        pkt_info->fatal_exception_valid = TRUE;
        pkt_info->fatal_exception = FATAL_EXP_UC_IP_TTL_CHECK_FAIL; /* TTL check failure */
    }

    if (ds_tunnel_id.isatap_check_en && parser_result->l4_s.isatap_ptp_ver.is_isatap_interface
        && (L4_TYPE_V6_IN_IP == parser_result->layer4_type))
    {
        isatap_check_ok = (parser_result->l3_s.ip_sa.ipv4.ipsa
                          == ((parser_result->l4_s.l4_src_port.l4_source_port << 16)
                                | parser_result->l4_s.l4_dst_port.l4_dest_port));
    }
    else
    {
        isatap_check_ok = TRUE;
    }

    if (!isatap_check_ok)
    {
        pkt_info->fatal_exception_valid = TRUE;
        pkt_info->fatal_exception = FATAL_EXP_UC_ISATAP_SRC_ADD_CHECK_FAIL;
    }

    if ((L4_TYPE_GRE != parser_result->layer4_type) && ds_tunnel_id.is_tunnel)
    {
        pkt_info->payload_packet_type = ds_tunnel_id.tunnel_packet_type;

        if ((L4_TYPE_UDP == parser_result->layer4_type)
            && (L4_USER_TYPE_UDP_CAPWAP == parser_result->l4_s.layer4_user_type))
        {
            pkt_info->payload_offset = parser_result->l3_s.layer4_offset + 8
                       + (parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_header_length << 2)
                       + (ds_tunnel_id.tunnel_payload_offset << ipe_tunnel_decap_ctl.offset_byte_shift);
        }
        else if (L4_TYPE_UDP == parser_result->layer4_type)
        {
            pkt_info->payload_offset = parser_result->l3_s.layer4_offset + 8
                       + (ds_tunnel_id.tunnel_payload_offset << ipe_tunnel_decap_ctl.offset_byte_shift);
        }
        else
        {
            pkt_info->payload_offset = parser_result->l3_s.layer4_offset
                       + (ds_tunnel_id.tunnel_payload_offset << ipe_tunnel_decap_ctl.offset_byte_shift);
        }
    }
    else if ((L4_TYPE_GRE == parser_result->layer4_type) && ds_tunnel_id.is_tunnel)
    {
        gre_option = (parser_result->l4_s.l4_src_port.gre_flags >> 12) & 0xF;
        gre_protocol = parser_result->l4_s.l4_dst_port.gre_protocol_type;
        unknown_protocol = (gre_protocol != 0x0800) && (gre_protocol != 0x6558) && (gre_protocol != 0x86DD)
                           && (gre_protocol != ipe_tunnel_decap_ctl.gre_flex_protocol)
                           && (gre_protocol != 0x8847) && (gre_protocol != 0x8848);

        if ((((IS_BIT_SET(gre_option, 3) << 2) | (gre_option & 0x3)) != ds_tunnel_id.tunnel_gre_options)
            || unknown_protocol
            || (IS_BIT_SET(gre_option, 2) && ipe_tunnel_decap_ctl.gre_option2_check_en))
        {
            /* UNKNOWN GRE --send to CPU */
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = FATAL_EXP_UC_GRE_UNKNOWN_OPTION_OR_PTL;
        }
        else
        {
            switch (gre_protocol)
            {
                case 0x0800:
                    pkt_info->payload_packet_type = PKT_TYPE_IPV4;
                    break;
                case 0x86DD:
                    pkt_info->payload_packet_type = PKT_TYPE_IPV6;
                    break;
                case 0x6558:
                    pkt_info->payload_packet_type = PKT_TYPE_ETHERNETV2;
                    break;
                case 0x8847:
                    pkt_info->payload_packet_type = PKT_TYPE_MPLS;
                    break;
                case 0x8848:
                    pkt_info->payload_packet_type = PKT_TYPE_MCAST_MPLS;
                    break;
                default:
                    pkt_info->payload_packet_type = ipe_tunnel_decap_ctl.gre_flex_payload_packet_type;
                    break;
            }

            pkt_info->payload_offset = parser_result->l3_s.layer4_offset
                           + (ds_tunnel_id.tunnel_payload_offset << ipe_tunnel_decap_ctl.offset_byte_shift);
        }
    }

    sal_memset(&ipe_tunnel_id_ctl, 0, sizeof(ipe_tunnel_id_ctl_t));
    cmd = DRV_IOR(IpeTunnelIdCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_tunnel_id_ctl));

    if (ds_tunnel_id.is_tunnel && (L4_TYPE_UDP == parser_result->layer4_type)
        && (L4_USER_TYPE_UDP_CAPWAP == parser_result->l4_s.layer4_user_type))
    {
        pkt_info->capwap_tunnel_valid = TRUE;
        pkt_info->capwap_tunnel_type = ds_tunnel_id.capwap_tunnel_type;

        if (IS_BIT_SET(parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_flags, 6))   /* Fragment */
        {
            if (ipe_tunnel_id_ctl.capwap_fragment_exception_en && !pkt_info->exception_en)
            {
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
                pkt_info->exception_sub_index = ipe_tunnel_id_ctl.capwap_fragment_exception_sub_index;
            }
             if (ipe_tunnel_id_ctl.capwap_fragment_discard && !pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_CAPWAP_FRAGMEN_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! CAPWAP fragment discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (ds_tunnel_id.capwap_tunnel_type)   /* AC2AC */
        {
            p_tunnel_info->deny_tunnel_decap2 = TRUE;
            pkt_info->roaming_state = parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_flags & 0x3;
        }
        else
        {
            p_tunnel_info->capwap_bss_id_check = TRUE;
        }

        if (parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_dtls)
        {
            if (ipe_tunnel_id_ctl.capwap_dtls_exception_en && !pkt_info->exception_en)
            {
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
                pkt_info->exception_sub_index = ipe_tunnel_id_ctl.capwap_dtls_exception_sub_index;
            }

            if (ipe_tunnel_id_ctl.capwap_dtls_discard && !pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_CAPWAP_DTLS_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! CAPWAP DTLS discard in IPE Tunnel terminate module!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (IS_BIT_SET(parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_flags, 2))
        {
            if (ipe_tunnel_id_ctl.capwap_keep_alive_exception_en && !pkt_info->exception_en)
            {
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_LAYER2;
                pkt_info->exception_sub_index = ipe_tunnel_id_ctl.capwap_keep_alive_exception_sub_index;
            }

            if (ipe_tunnel_id_ctl.capwap_keep_alive_discard && !pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_CAPWAP_CONTROL_EXCEPTION;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! CAPWAP tunnel keep alive packet will be discarded!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    if (ds_tunnel_id.use_default_vlan_tag)
    {
        pkt_info->use_default_vlan_tag = TRUE;
        pkt_info->user_default_vlan_id = ds_tunnel_id.isid & 0xFFF;
        pkt_info->user_default_cos = ds_tunnel_id.user_default_cos;
        pkt_info->user_default_cfi = ds_tunnel_id.user_default_cfi;
    }

    if (pkt_info->fatal_exception_valid)
    {
        pkt_info->inner_packet_lookup = FALSE;
        pkt_info->ds_fwd_ptr_valid = FALSE;
    }

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_ipe_tunnel_terminate_tunnel_decaps2_op
* Purpose:    IPE tunnel termination tunnel decapsulate2 operation.
* Parameters:
* Input:      in_pkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
*             ds_userid -- poped dsUserId2 table content pointer.
*             tunnel_decap1_info -- dsUserId1 output information's pointer.
* Output:     p_ipe_inpkt -- pointer to buffer which save input packet
*                         and packet header ,and processing informations.
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
static int32
_cm_ipe_tunnel_terminate_tunnel_decaps2_op(ipe_in_pkt_t *in_pkt, tunnel_info_t *p_tunnel_info)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    ipe_tunnel_decap_ctl_t ipe_tunnel_decap_ctl;
    ds_tunnel_id_t ds_tunnel_id ;

    uint8 chip_id = in_pkt->chip_id;
    uint8 gre_option = 0;
    uint8 bind_mis_match = FALSE;
    uint8 isatap_check_ok = FALSE;
    uint8 mac_bind_mis_match = FALSE, port_bind_mis_match = FALSE;
    uint8 ip_bind_mis_match = FALSE, vlan_bind_mis_match = FALSE, ip_vlan_bind_mis_match = FALSE;
    uint8 tunnel_more_rpf_if = FALSE, tunnel_rpf_check_ok = FALSE, tunnel_rpf_check_en = FALSE;
    uint8 tunnel_rpf_if_id0 = FALSE, tunnel_rpf_if_id1 = FALSE, tunnel_rpf_if_id2 = FALSE, tunnel_rpf_if_id3 = FALSE;
    uint8 tunnel_rpf_if_id_valid0 = FALSE, tunnel_rpf_if_id_valid1 = FALSE, tunnel_rpf_if_id_valid2 = FALSE, tunnel_rpf_if_id_valid3 = FALSE;
    uint16 mac47_32 = 0;
    uint16 bind_vlan_id = 0;
    uint16 gre_protocol = 0;
    uint16 unknown_protocol = 0;
    uint32 mac31_0 = 0;
    uint32 binding_data_35_4 = 0;
    uint32 cmd = 0;

    /* FATAL_EXCEPTION_2 */
    sal_memset(&ds_tunnel_id, 0, sizeof(ds_tunnel_id_t));
    sal_memcpy(&ds_tunnel_id, &(pkt_info->userid_tunnel_lkp2_ad), sizeof(ds_tunnel_id_t));

    if (parser_result->l3_s.ip_header_error)
    {
        pkt_info->fatal_exception_valid = TRUE;
        pkt_info->fatal_exception = FATAL_EXP_UC_IP_HDR_ERR_OR_IP_MARTION_ADDR;
    }

    if (parser_result->l3_s.ip_options)
    {
        if ((L3_TYPE_TRILL == parser_result->layer3_type) && (ds_tunnel_id.trill_option_escape_en))
        {
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = FATAL_EXP_TRILL_OPTION;
        }
        else
        {
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = FATAL_EXP_UC_IP_OPTIONS;
        }
    }

    /* ESCAPE_CHECK_2*/
    if (pkt_info->fatal_exception_valid)
    {
        return DRV_E_NONE;
    }

    if (ds_tunnel_id.rpf_check_en)
    {
        /* tunnel RPF check */
        tunnel_rpf_check_en = ds_tunnel_id.logic_port_type;
        tunnel_rpf_if_id_valid0 = ds_tunnel_id.service_acl_qos_en;
        tunnel_rpf_if_id_valid1 = ds_tunnel_id.igmp_snoop_en;
        tunnel_rpf_if_id_valid2 = ds_tunnel_id.isid_valid;
        tunnel_rpf_if_id_valid3 = ds_tunnel_id.binding_en;
        tunnel_more_rpf_if = ds_tunnel_id.binding_mac_sa;
        tunnel_rpf_if_id0 = ds_tunnel_id.binding_data_low & 0x3FF;
        tunnel_rpf_if_id1 = (ds_tunnel_id.binding_data_low >> 10) & 0x3FF;
        tunnel_rpf_if_id2 = (ds_tunnel_id.binding_data_low >> 20) & 0x3FF;
        tunnel_rpf_if_id3 = ((ds_tunnel_id.binding_data_high & 0xFF) << 2) | (ds_tunnel_id.binding_data_low >> 30);

        if (pkt_info->tunnel_rpf_check_request)
        {
            tunnel_rpf_check_ok = !tunnel_rpf_check_en || (tunnel_rpf_check_en
                                  && ((tunnel_rpf_if_id_valid0 && (tunnel_rpf_if_id0 == pkt_info->interface_id))
                                  || (tunnel_rpf_if_id_valid1 && (tunnel_rpf_if_id1 == pkt_info->interface_id))
                                  || (tunnel_rpf_if_id_valid2 && (tunnel_rpf_if_id2 == pkt_info->interface_id))
                                  || (tunnel_rpf_if_id_valid3 && (tunnel_rpf_if_id3 == pkt_info->interface_id))));

            if (!tunnel_rpf_check_ok)
            {
                pkt_info->fatal_exception_valid = TRUE;

                if (tunnel_more_rpf_if)
                {
                    pkt_info->fatal_exception = FATAL_EXP_UC_OR_MC_MORE_RPF;
                }
                else
                {
                    pkt_info->fatal_exception = FATAL_EXP_UC_RPF_CHECK_FAIL;
                }
            }
        }
    }
    else
    {
        /* TUNNEL_PROPERTY_2 */
        if (ds_tunnel_id.src_queue_select)
        {
            pkt_info->src_queue_select = ds_tunnel_id.src_queue_select;
        }

        if (ds_tunnel_id.route_disable)
        {
            pkt_info->route_disable = TRUE;
        }

        if (ds_tunnel_id.deny_learning)
        {
            pkt_info->deny_learning = TRUE;
        }

        if (ds_tunnel_id.deny_bridge)
        {
            pkt_info->deny_bridge = TRUE;
        }

        if (ds_tunnel_id.service_acl_qos_en)
        {
            pkt_info->service_acl_qos_en = TRUE;
        }

        if (ds_tunnel_id.tunnel_ptp_en)
        {
            pkt_info->tunnel_ptp_en = TRUE;
        }

        if (ds_tunnel_id.tunnel_id_exception_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_USER_ID;
        }

        p_tunnel_info->tunnel2_is_esadi = (L3_TYPE_TRILL == parser_result->layer3_type)
                                        && parser_result->l3_s.ip_da.trill.is_esadi;

        pkt_info->src_dscp = (parser_result->l3_s.tos.ip_tos >> 2) & 0x3F;

        if (!p_tunnel_info->ds_tunnelid1_is_tunnel)
        {
            pkt_info->is_decap = ds_tunnel_id.is_tunnel;
            pkt_info->outer_vlan_is_cvlan = ds_tunnel_id.outer_vlan_is_cvlan;
            pkt_info->acl_qos_use_outer_info = ds_tunnel_id.acl_qos_use_outer_info;
            pkt_info->svlan_tpid_index = ds_tunnel_id.svlan_tpid_index;
            pkt_info->ttl_update = ds_tunnel_id.ttl_update;
            pkt_info->inner_packet_lookup = ds_tunnel_id.inner_packet_lookup;

            if (ds_tunnel_id.vsi_learning_disable)
            {
                pkt_info->vsi_learning_disable = TRUE;
            }

            if (ds_tunnel_id.mac_security_vsi_discard)
            {
                pkt_info->mac_security_vsi_discard = TRUE;
            }

            if (ds_tunnel_id.igmp_snoop_en)
            {
                pkt_info->igmp_snoop_en = TRUE;
            }

            if (ds_tunnel_id.logic_port_type)
            {
                pkt_info->logic_port_type = TRUE;
            }
        }

        if (ds_tunnel_id.ds_fwd_ptr_valid && (0 != ds_tunnel_id.fid) && (0xFFFF != ds_tunnel_id.fid)
            && !p_tunnel_info->ds_tunnelid1_fwdptr_valid)
        {
            pkt_info->ds_fwd_ptr_valid = TRUE;
            pkt_info->ds_fwd_ptr = ds_tunnel_id.fid;
        }
        else if (!ds_tunnel_id.ds_fwd_ptr_valid && (1 == ((ds_tunnel_id.fid >> 14) & 0x3))
                 && !p_tunnel_info->ds_tunnelid1_fid_valid)
        {
            pkt_info->fid_type = ds_tunnel_id.fid_type;

            if (ds_tunnel_id.fid_type)
            {
                pkt_info->inner_vsi_id_valid = TRUE;
                pkt_info->inner_vsi_id = ds_tunnel_id.fid & 0x3FFF;
            }
            else
            {
                pkt_info->vrf_id = ds_tunnel_id.fid & 0x3FFF;
            }
        }
        else if (!ds_tunnel_id.ds_fwd_ptr_valid && (2 == ((ds_tunnel_id.fid >> 14) & 0x3))
                 && !p_tunnel_info->ds_tunnelid1_label_space_valid)
        {
            pkt_info->mpls_label_space = ds_tunnel_id.fid & 0xFF;

            if (IS_BIT_SET(ds_tunnel_id.fid, 8))
            {
                pkt_info->mpls_label_space_valid = TRUE;
            }
        }

        if (ds_tunnel_id.ds_fwd_ptr_valid && (0xFFFF == ds_tunnel_id.fid))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_USER_ID_FWD_PTR_ALL_F_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Tunnel2 dsfwdptr is 0xFFFF!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if ((0 != ds_tunnel_id.stats_ptr) && (!pkt_info->flow_stats1_valid))
        {
            pkt_info->flow_stats1_valid = TRUE;
            pkt_info->flow_stats1_ptr = ds_tunnel_id.stats_ptr;
        }

        if (!ds_tunnel_id.binding_en)
        {
            if (IS_BIT_SET(ds_tunnel_id.binding_data_high, 13)  /* apsSelectValid */
                && !p_tunnel_info->ds_tunnelid1_aps_select_valid)
            {
                if (!pkt_info->aps_select_valid0)
                {
                    pkt_info->aps_select_valid0 = TRUE;
                    pkt_info->aps_select_protecting_path0 = IS_BIT_SET(ds_tunnel_id.binding_data_high, 15);   /* apsSelectProtectingPath */
                    pkt_info->aps_select_group_id0 = ((ds_tunnel_id.binding_data_high >> 1) & 0x7FF);         /* apsSelectGroupId */
                }
                else if (!pkt_info->aps_select_valid1)
                {
                pkt_info->aps_select_valid1 = TRUE;
                    pkt_info->aps_select_protecting_path1 = IS_BIT_SET(ds_tunnel_id.binding_data_high, 15);
                    pkt_info->aps_select_group_id1 = ((ds_tunnel_id.binding_data_high >> 1) & 0x7FF);
                }
                else if (!pkt_info->aps_select_valid2)
                {
                    pkt_info->aps_select_valid2 = TRUE;
                    pkt_info->aps_select_protecting_path2 = IS_BIT_SET(ds_tunnel_id.binding_data_high, 15);
                    pkt_info->aps_select_group_id2 = ((ds_tunnel_id.binding_data_high >> 1) & 0x7FF);
                }
            }

            if (IS_BIT_SET(ds_tunnel_id.binding_data_high, 14)
                && (0 != (ds_tunnel_id.binding_data_low & 0x1FFF))
                && !p_tunnel_info->ds_tunnelid1_servic_policer_valid)
            {
                pkt_info->service_policer_valid = IS_BIT_SET(ds_tunnel_id.binding_data_high, 14);   /* servicePolicerValid */
                pkt_info->service_policer_mode = IS_BIT_SET(ds_tunnel_id.binding_data_high, 0);     /* servicePolicerMode */
                pkt_info->service_policer_ptr = ds_tunnel_id.binding_data_low & 0x1FFF;             /* servicePolicerPtr */
            }

            if ((!IS_BIT_SET(ds_tunnel_id.binding_data_high, 14))
                     && (0 != (ds_tunnel_id.binding_data_low & 0x1FFF))
                     && !p_tunnel_info->ds_tunnelid1_flow_policer_valid)
            {
                pkt_info->flow_policer_valid = TRUE;
                pkt_info->flow_policer_ptr = ds_tunnel_id.binding_data_low  & 0x1FFF;               /* flowPolicerPtr */
            }

            if (0 != ((ds_tunnel_id.binding_data_low >> 15) & 0x3FFF)
                && !p_tunnel_info->ds_tunnelid1_logic_src_port_valid)
            {
                pkt_info->inner_logic_src_port_valid = TRUE;
                pkt_info->inner_logic_src_port = (1 << 14) | ((ds_tunnel_id.binding_data_low >> 15) & 0x3FFF);
            }
        }
        else
        {
            if (ds_tunnel_id.binding_mac_sa)
            {
                mac47_32 = MAKE_UINT16(parser_result->l2_s.mac_sa5, parser_result->l2_s.mac_sa4);
                mac31_0 = MAKE_UINT32(parser_result->l2_s.mac_sa3, parser_result->l2_s.mac_sa2,
                                      parser_result->l2_s.mac_sa1, parser_result->l2_s.mac_sa0);

                mac_bind_mis_match = ((ds_tunnel_id.binding_data_high != mac47_32)
                                     || (ds_tunnel_id.binding_data_low !=  mac31_0));
            }
            else if (!ds_tunnel_id.binding_mac_sa)
            {
                if (parser_result->l2_s.svlan_id_valid)
                {
                    bind_vlan_id = parser_result->l2_s.svlan_id;
                }
                else
                {
                    bind_vlan_id = parser_result->l2_s.cvlan_id;
                }

                binding_data_35_4 = ((ds_tunnel_id.binding_data_high & 0xF) << 28)
                                    | (ds_tunnel_id.binding_data_low >> 4);

                switch (ds_tunnel_id.binding_data_low & 0x3)
                {
                    case 0:
                        port_bind_mis_match = (pkt_info->global_src_port != (ds_tunnel_id.binding_data_high & 0x3FFF));
                        break;
                    case 1:
                        vlan_bind_mis_match = (bind_vlan_id != ((ds_tunnel_id.binding_data_high >> 4) & 0xFFF));
                        break;
                    case 2:
                        ip_bind_mis_match = ((parser_result->l3_s.ip_sa.ipv4.ipsa != binding_data_35_4)
                                              && (L3_TYPE_IPV4 == parser_result->layer3_type));
                        break;
                    case 3:
                        ip_vlan_bind_mis_match = (((bind_vlan_id != ((ds_tunnel_id.binding_data_high >> 4) & 0xFFF))
                                                    || (parser_result->l3_s.ip_sa.ipv4.ipsa != binding_data_35_4))
                                                 && (L3_TYPE_IPV4 == parser_result->layer3_type));
                        break;
                    default:
                        break;
                }
            }

            bind_mis_match = mac_bind_mis_match || port_bind_mis_match || vlan_bind_mis_match
                        || ip_bind_mis_match || ip_vlan_bind_mis_match;

            if (bind_mis_match)
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard = TRUE;
                    pkt_info->discard_type = IPE_DISCARD_USER_ID_BINDING_DISCARD;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! UserId binding discard(Mac/port/Ip/vlan/IpVlan bind mismatch)!\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
        }

        /* TUNNEL_DECAP_2 */
        sal_memset(&ipe_tunnel_decap_ctl, 0, sizeof(ipe_tunnel_decap_ctl));
        cmd = DRV_IOR(IpeTunnelDecapCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_tunnel_decap_ctl));

        if (ds_tunnel_id.trill_ttl_check_en && (pkt_info->packet_ttl < ipe_tunnel_decap_ctl.trill_ttl))
        {
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = FATAL_EXP_TRILL_TTL_CHECK_FAIL;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! Tunnel2 TRILL TTL check fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }

        if (ipe_tunnel_decap_ctl.trillversion_check_en
            && (ipe_tunnel_decap_ctl.trill_version != parser_result->l3_s.ip_da.trill.trill_version)
            && (L3_TYPE_TRILL == parser_result->layer3_type))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_TRILL_VERSION_CHK_ERR;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Tunnel2 TRILL Version check_0 fail!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (ipe_tunnel_decap_ctl.trill_bfd_check_en && (L3_TYPE_TRILL == parser_result->layer3_type)
            && (parser_result->l3_s.ip_da.trill.is_trill_bfd_echo || parser_result->l3_s.ip_da.trill.is_trill_bfd)
            && (parser_result->l3_s.ip_da.trill.trill_multicast
            || (parser_result->l3_s.ip_da.trill.trill_multi_hop && (pkt_info->packet_ttl <= ipe_tunnel_decap_ctl.trill_bfd_hop_count))
            || (!parser_result->l3_s.ip_da.trill.trill_multi_hop && (pkt_info->packet_ttl != 0x3F))))
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_TRILL_VERSION_CHK_ERR;

                CMODEL_DEBUG_OUT_INFO("++++ Discard! TRILL version check_0 fail!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (parser_result->l3_s.ip_da.trill.is_trill_channel && parser_result->l3_s.ip_da.trill.is_trill_bfd_echo
            && ds_tunnel_id.trill_bfd_echo_en && !pkt_info->exception_en
            && (L3_TYPE_TRILL == parser_result->layer3_type))  /* Echo processing ?? */
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = ds_tunnel_id.exception_sub_index;

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_TRILL_ESADI_PKT_DISCARD;

                CMODEL_DEBUG_OUT_INFO("++++ Discard! TRILL esadi packet!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (parser_result->l3_s.ip_da.trill.is_trill_channel && parser_result->l3_s.ip_da.trill.is_trill_bfd
                 && ds_tunnel_id.trill_bfd_en && (L3_TYPE_TRILL == parser_result->layer3_type))  /* TRILL BFD */
        {
            pkt_info->rx_oam_type = OAM_TRILL_BFD;
            pkt_info->payload_offset = parser_result->l2_s.layer3_offset
                                       + parser_result->l3_s.ip_da.trill.trill_inner_vlan_valid ? 24 : 20;
        }
        else if (parser_result->l3_s.ip_da.trill.is_trill_channel && ds_tunnel_id.trill_channel_en && !pkt_info->exception_en
                 && (L3_TYPE_TRILL == parser_result->layer3_type))
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = ds_tunnel_id.exception_sub_index;

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_TRILL_ESADI_PKT_DISCARD;

                CMODEL_DEBUG_OUT_INFO("++++ Discard! Tunnel2 TRILL Esadi packet discard!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if ((L3_TYPE_TRILL == parser_result->layer3_type) && parser_result->l3_s.ip_da.trill.is_esadi
            && ds_tunnel_id.esadi_check_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_LAYER3;
            pkt_info->exception_sub_index = ds_tunnel_id.exception_sub_index;

            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_TRILL_ESADI_PKT_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! Tunnel2 TRILL ESADI Packet check fail!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (ds_tunnel_id.ttl_check_en && (pkt_info->packet_ttl < ipe_tunnel_decap_ctl.ip_ttl_limit))
        {
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = FATAL_EXP_UC_IP_TTL_CHECK_FAIL; /* TTL check failure */
        }

        if (ds_tunnel_id.isatap_check_en && parser_result->l4_s.isatap_ptp_ver.is_isatap_interface
            && (L4_TYPE_V6_IN_IP == parser_result->layer4_type))
        {
            isatap_check_ok = (parser_result->l3_s.ip_sa.ipv4.ipsa
                               == ((parser_result->l4_s.l4_src_port.l4_source_port << 16)
                                   | parser_result->l4_s.l4_dst_port.l4_dest_port));
        }
        else
        {
            isatap_check_ok = TRUE;
        }

        if (!isatap_check_ok)
        {
            pkt_info->fatal_exception_valid = TRUE;
            pkt_info->fatal_exception = FATAL_EXP_UC_ISATAP_SRC_ADD_CHECK_FAIL;
        }

        if ((L4_TYPE_GRE != parser_result->layer4_type) && ds_tunnel_id.is_tunnel)
        {
            pkt_info->payload_packet_type = ds_tunnel_id.tunnel_packet_type;

            if ((L4_TYPE_UDP == parser_result->layer4_type)
                && (L4_USER_TYPE_UDP_CAPWAP == parser_result->l4_s.layer4_user_type))
            {
                pkt_info->payload_offset = parser_result->l3_s.layer4_offset + 8+
                               + (parser_result->l4_s.ptp_oam_ach.wtp2ac_radio_mac.capwap_header_length << 2)
                               + (ds_tunnel_id.tunnel_payload_offset << ipe_tunnel_decap_ctl.offset_byte_shift);
            }
            else
            {
                pkt_info->payload_offset = parser_result->l3_s.layer4_offset
                               + (ds_tunnel_id.tunnel_payload_offset << ipe_tunnel_decap_ctl.offset_byte_shift);
            }
        }
        else if ((L4_TYPE_GRE == parser_result->layer4_type) && ds_tunnel_id.is_tunnel)
        {
            gre_option = (parser_result->l4_s.l4_src_port.gre_flags >> 12) & 0xF;
            gre_protocol = parser_result->l4_s.l4_dst_port.gre_protocol_type;
            unknown_protocol = (gre_protocol != 0x0800) && (gre_protocol != 0x6558)
                               && (gre_protocol != 0x86DD)
                               && (gre_protocol != ipe_tunnel_decap_ctl.gre_flex_protocol)
                               && (gre_protocol != 0x8847) && (gre_protocol != 0x8848);

            if ((((IS_BIT_SET(gre_option, 3) << 2) | (gre_option & 0x3)) != ds_tunnel_id.tunnel_gre_options)
                 || unknown_protocol || (IS_BIT_SET(gre_option, 2) && ipe_tunnel_decap_ctl.gre_option2_check_en))
            {
                /* UNKNOWN GRE --should send to CPU */
                pkt_info->fatal_exception_valid = TRUE;
                pkt_info->fatal_exception = FATAL_EXP_UC_GRE_UNKNOWN_OPTION_OR_PTL;
            }
            else
            {
                switch (gre_protocol)
                {
                    case 0x0800:
                        pkt_info->payload_packet_type = PKT_TYPE_IPV4;
                        break;
                    case 0x86DD:
                        pkt_info->payload_packet_type = PKT_TYPE_IPV6;
                        break;
                    case 0x6558:
                        pkt_info->payload_packet_type = PKT_TYPE_ETHERNETV2;
                        break;
                    case 0x8847:
                        pkt_info->payload_packet_type = PKT_TYPE_MPLS;
                        break;
                    case 0x8848:
                        pkt_info->payload_packet_type = PKT_TYPE_MCAST_MPLS;
                        break;
                    default:
                        pkt_info->payload_packet_type = ipe_tunnel_decap_ctl.gre_flex_payload_packet_type;
                        break;
                }

                pkt_info->payload_offset = parser_result->l3_s.layer4_offset
                           + (ds_tunnel_id.tunnel_payload_offset << ipe_tunnel_decap_ctl.offset_byte_shift);
            }
        }

        if (ds_tunnel_id.use_default_vlan_tag)
        {
            pkt_info->use_default_vlan_tag = TRUE;
            pkt_info->user_default_vlan_id = ds_tunnel_id.isid & 0xFFF;
            pkt_info->user_default_cos = ds_tunnel_id.user_default_cos;
            pkt_info->user_default_cfi = ds_tunnel_id.user_default_cfi;
        }

        if (pkt_info->fatal_exception_valid)
        {
            pkt_info->inner_packet_lookup = FALSE;
            pkt_info->ds_fwd_ptr_valid = FALSE;
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_ipe_tunnel_terminate_mpls_handle
* Purpose:    IPE tunnel termination mpls operation.
* Parameters:
*  Input:     in_pkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
* Output:     in_pkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
static int32
_cm_ipe_tunnel_terminate_mpls_handle(ipe_in_pkt_t *in_pkt, uint32 *parser_layer4_type)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    mpls_info_t mpls_info;

    uint8 label_count = 0;
    uint8 is_mpls_packet = FALSE;

    sal_memset(&mpls_info, 0, sizeof(mpls_info_t));

    mpls_info.parser_layer4_type = *parser_layer4_type;

    /* MPLS_PACKET */
    if ((L3_TYPE_MPLS == parser_result->layer3_type) || (L3_TYPE_MPLSMCAST == parser_result->layer3_type))
    {
        is_mpls_packet = TRUE;
    }

    /* NO_MPLS_PACKET_SWITCH */
    if (!is_mpls_packet)
    {
        return DRV_E_NONE;
    }

    /* MPLS_EN */
    mpls_info._continue = (!pkt_info->discard) && pkt_info->is_mpls_switched;

    if (mpls_info._continue)
    {
        pkt_info->payload_packet_type = pkt_info->packet_type;
        pkt_info->src_dscp = ((parser_result->l3_s.ip_da.mpls.mpls_label0 >> 9) & 0x7) << 3;
    }

    mpls_info.mpls_offset = 0;
    mpls_info.mpls_lm_index = 0;
    mpls_info.aps_num = 0;
    pkt_info->oam_lookup_num = 3; /* not associated with any LM */

    while (mpls_info._continue)
    {
        DRV_IF_ERROR_RETURN(_cm_ipe_tunnel_terminate_mpls_label_process(in_pkt, label_count, &mpls_info));

        label_count++;

        if (label_count >= 4)
        {
            break;
        }
    }

    /* PAYLOAD_OFFSET */
    pkt_info->payload_offset = parser_result->l2_s.layer3_offset + mpls_info.mpls_offset;

    *parser_layer4_type = mpls_info.parser_layer4_type;

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_ipe_tunnel_terminate_parser
* Purpose:    IPE tunnel termination Secondary Parser
* Parameters:
*  Input:     in_pkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
* Output:     in_pkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
static int32
_cm_ipe_tunnel_terminate_parser(ipe_in_pkt_t *in_pkt, uint32 parser_layer4_type)
{
    ipe_packet_info_t* pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parser_info_t parser_info;

    uint16 parser_length = 0;

    pkt_info->second_parser = TRUE; /* refer to page 86 flow chart */

    parser_length = ((in_pkt->packet_length-pkt_info->payload_offset)> 256) ? 256
                    : (in_pkt->packet_length-pkt_info->payload_offset);

    /* SECONDARY_PARSER */
    sal_memset(&parser_info, 0, sizeof(parser_info_t));
    /* parserLength[8:0] is the length in packet buffer without PacketHeader and timestamp, up to 256 bytes
       for cut-through enabled in IPE
       pbbSrcPortType[2:0] set to 0
       modId[4:0] and portId[7:0] set to 0
       muxLengthType[1:0] set to 0 */
    parser_info.pkt = in_pkt->pkt;
    parser_info.parser_length = (parser_length & 0x1FF);
    parser_info.packet_type = pkt_info->payload_packet_type;
    parser_info.parser_layer4_type = parser_layer4_type;
    parser_info.svlan_tpid_index = pkt_info->svlan_tpid_index;
    parser_info.outer_vlan_is_cvlan = pkt_info->outer_vlan_is_cvlan;
    parser_info.chip_id = in_pkt->chip_id;  /* set 0 on spec, for spec, modid and port only use hash
                                   in parser component, but cmodel will use the chipid when reg and table I/O */
    parser_info.port_id = 0;
    parser_info.payload_offset = pkt_info->payload_offset + (pkt_info->ptp_extra_offset << 2);
    parser_info.mux_length_type = 0;
    parser_info.parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parser_info.non_crc = pkt_info->non_crc;

    sal_memset(parser_info.parser_result, 0, sizeof(parsing_result_t));
    DRV_IF_ERROR_RETURN(cm_com_parser_packet_parsing(&parser_info));

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       cm_ipe_tunnel_terminate_handle
* Purpose:    IPE tunnel termination handle.
* Parameters:
* Input:      in_pkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
* Output:     in_pkt -- pointer to buffer which save input packet
*                        and packet header ,and processing informations.
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
int32 cm_ipe_tunnel_terminate_handle(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t *)in_pkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t *)pkt_info->parser_rslt;
    parsing_result_t *parser_result1 = (parsing_result_t *)pkt_info->parser_rslt1;
    ipe_tunnel_decap_ctl_t ipe_tunnel_decap_ctl;
    ipe_tunnel_id_ctl_t ipe_tunnel_id_ctl;
    tunnel_info_t tunnel_info;

    uint8 chip_id = in_pkt->chip_id;
    uint8 is_sa_6to4 = 0;
    uint8 is_sa_mcast = 0;
    uint8 is_sa_v4mapped = 0;
    uint8 is_sa_v4compatible = 0;
    uint8 is_sa_loop_back = 0;
    uint8 ip_martian_address = 0, ipv4_rule_martian_address = 0;
    uint8 ipv4 = FALSE, ipv6 = FALSE, pbb = FALSE, trill = FALSE;
    uint8 gre = FALSE, udp = FALSE;
    uint8 ipinip = FALSE, v6inip = FALSE, ipinv6 = FALSE, v6inv6 = FALSE;
    uint8 ipv4_mcast_addr = FALSE, ipv6_mcast_addr = FALSE;
    uint8 is_ipv4_tunnel = FALSE, is_ipv6_tunnel = FALSE;
    uint8 is_mpls = FALSE, is_trill = FALSE;
    uint8 is_tunnel_decap = FALSE, tunnel_decap1 = FALSE, tunnel_decap2 = FALSE;
    uint8 route_stp_block = FALSE;
    uint8 ipv4_mcast_address_check_fail = FALSE;
    uint8 ipv6_mcast_address_check_fail = FALSE;
    uint8 deny_tunnel_decap2 = FALSE;
    uint8 capwap_bssid_check = FALSE;
    uint16 macda_47_to_32 = 0;
    uint32 parser_layer4_type = 0;
    uint32 macda_47_to_24 = 0;
    uint32 macda_31_to_0 = 0;
    uint32 v4_ip_sa = 0;
    uint32 cmd = 0;

    /* TUNNEL_DECAP_DECIDE */
    sal_memset(&ipe_tunnel_decap_ctl, 0, sizeof(ipe_tunnel_decap_ctl));
    cmd = DRV_IOR(IpeTunnelDecapCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_tunnel_decap_ctl));

    sal_memset(&tunnel_info, 0, sizeof(tunnel_info));

    /* copy all ParserResult information into ParserResult1. only for CModel */
    sal_memcpy(parser_result1, parser_result, sizeof(parsing_result_t));

    deny_tunnel_decap2 = FALSE;
    capwap_bssid_check = FALSE;
    ipv4 = (L3_TYPE_IPV4 == parser_result->layer3_type);
    ipv6 = (L3_TYPE_IPV6 == parser_result->layer3_type);
    pbb = (L3_TYPE_CMAC == parser_result->layer3_type);
    trill = (L3_TYPE_TRILL == parser_result->layer3_type);
    gre = (L4_TYPE_GRE == parser_result->layer4_type);
    udp = (L4_TYPE_UDP == parser_result->layer4_type);
    ipinip = (L4_TYPE_IP_IN_IP == parser_result->layer4_type);
    v6inip = (L4_TYPE_V6_IN_IP == parser_result->layer4_type);
    ipinv6 = (L4_TYPE_IP_IN_V6 == parser_result->layer4_type);
    v6inv6 = (L4_TYPE_V6_IN_V6 == parser_result->layer4_type);

    ipv4_mcast_addr = ipv4 && (0xE == (parser_result->l3_s.ip_da.ipv4.ipda >> 28));
    ipv6_mcast_addr = ipv6 && (0xFF == (parser_result->l3_s.ip_da.ipv6.ipda_127_96 >> 24));

    macda_31_to_0 = MAKE_UINT32(parser_result->l2_s.mac_da3, parser_result->l2_s.mac_da2,
                                parser_result->l2_s.mac_da1, parser_result->l2_s.mac_da0);
    macda_47_to_32 = MAKE_UINT16(parser_result->l2_s.mac_da5, parser_result->l2_s.mac_da4);

    macda_47_to_24 = (parser_result->l2_s.mac_da5 << 16) | (parser_result->l2_s.mac_da4 << 8)
                     | parser_result->l2_s.mac_da3;

    ipv4_mcast_address_check_fail = (!ipe_tunnel_decap_ctl.mcast_address_match_check_disable)
                                    && IS_BIT_SET(parser_result->l2_s.mac_da5, 0)
                                    && (((macda_31_to_0 & 0x7FFFFF) != (parser_result->l3_s.ip_da.ipv4.ipda & 0x7FFFFF))
                                    || IS_BIT_SET(parser_result->l2_s.mac_da2, 7) || (macda_47_to_24 != 0x01005E));

    ipv6_mcast_address_check_fail = (!ipe_tunnel_decap_ctl.mcast_address_match_check_disable)
                                    && IS_BIT_SET(parser_result->l2_s.mac_da5, 0)
                                    && ((macda_31_to_0 != parser_result->l3_s.ip_da.ipv4.ipda)
                                    || (parser_result->l2_s.mac_da5 != 0x33) || (parser_result->l2_s.mac_da4 != 0x33));

    is_ipv4_tunnel = (ipv4 && (gre || udp || ipinip || v6inip)) && (pkt_info->is_router_mac
                     || (ipv4_mcast_addr && (pkt_info->bcast_mac_address || (!ipv4_mcast_address_check_fail))));

    is_ipv6_tunnel = (ipv6 && (gre || udp || ipinv6 || v6inv6)) && (pkt_info->is_router_mac
                     || (ipv6_mcast_addr && (pkt_info->bcast_mac_address || (!ipv6_mcast_address_check_fail))));

    is_trill = trill && (pkt_info->is_port_mac || (pkt_info->mcast_mac_address && ipe_tunnel_decap_ctl.trill_mcast_mac)
                        || ((macda_47_to_32 == 0x0180) && (macda_31_to_0 == 0xC2000040)));


    is_tunnel_decap = is_trill || is_ipv4_tunnel || is_ipv6_tunnel;

    if (trill && pkt_info->trill_en && !pkt_info->bcast_mac_address && !pkt_info->mcast_mac_address
        && !pkt_info->is_port_mac && !ipe_tunnel_decap_ctl.transmit_non_port_mac_trill_packet)
    {
        if (!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_TRILL_FILTER_ERR;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! Trill filter operation fail!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    sal_memset(&ipe_tunnel_id_ctl, 0, sizeof(ipe_tunnel_id_ctl));
    cmd = DRV_IOR(IpeTunnelIdCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(in_pkt->chip_id, 0, cmd, &ipe_tunnel_id_ctl));

    route_stp_block = ((STP_BLOCKING == pkt_info->stp_state) || (STP_LEARNING == pkt_info->stp_state))
                      && ipe_tunnel_id_ctl.route_obey_stp;

    tunnel_decap1 = is_tunnel_decap && pkt_info->tunnel_lookup_result1_valid && !route_stp_block;
    tunnel_decap2 = is_tunnel_decap && pkt_info->tunnel_lookup_result2_valid && !route_stp_block;

    if ((tunnel_decap1 || tunnel_decap2) && ipe_tunnel_decap_ctl.tunnel_martian_address_check_en)
    {
        if (ipv4)
        {
            DRV_IF_ERROR_RETURN(_cm_ipe_tunnel_terminate_ipv4_martian_addr(chip_id,
                        parser_result->l3_s.ip_sa.ipv4.ipsa, &ip_martian_address));
        }
        else if (ipv6)
        {
            /* 6to4 IPv6 address has the form of 2002:V4ADDR::/48, Ipsa[127:112] == 0x2002 */
            is_sa_6to4 = (0x2002 == (parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 >> 16));
            if (is_sa_6to4)
            {
                v4_ip_sa = ((parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 & 0xFFFF) << 16)
                            | (parser_result->l3_s.ip_sa.ipv6.ipsa_95_64 >> 16);
            }
            else
            {
                v4_ip_sa = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
            }

            /* v4Mapped IPv6 address has the form of 0:0:0:0:0:FFFF:/w.x.y.z/ or ::FFFF:/w.x.y.z/,
               Ipsa[127:48] == 80'b0, Ipsa[47:32] == 0xFFFF */
            is_sa_v4mapped = (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96)
                             && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_95_64)
                             && (0xFFFF == parser_result->l3_s.ip_sa.ipv6.ipsa_63_32);

            /* v4Compatible IPv6 address has the form of 0:0:0:0:0:0:/w.x.y.z/ or ::/w.x.y.z/,
               Ipsa[127:32] == 0 */
            is_sa_v4compatible = (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96)
                                 && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_95_64)
                                 && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_63_32);

            DRV_IF_ERROR_RETURN(_cm_ipe_tunnel_terminate_ipv4_martian_addr(chip_id, v4_ip_sa, &ip_martian_address));

            ipv4_rule_martian_address = (is_sa_6to4 || is_sa_v4mapped || is_sa_v4compatible) && ip_martian_address;

            /* ipsa is multicast: IpSa[127:120] == 8'hFF */
            is_sa_mcast = (0xFF == (parser_result->l3_s.ip_sa.ipv6.ipsa_127_96 >> 24));
            /* ipsa is loopback: IpSa[127:0] == {127'h0, 1'b1} */
            is_sa_loop_back = (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_127_96)
                               && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_95_64)
                               && (0 == parser_result->l3_s.ip_sa.ipv6.ipsa_63_32)
                               && (1 == parser_result->l3_s.ip_sa.ipv6.ipsa_31_0);

            ip_martian_address = is_sa_mcast || is_sa_loop_back || ipv4_rule_martian_address;
        }

        if (ip_martian_address)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_TUNNEL_DECAP_OUTER_MARTIAN_ADDR_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! tunnel outer ip is marthian address!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
    }

    is_mpls = (L3_TYPE_MPLS == parser_result->layer3_type) || (L3_TYPE_MPLSMCAST == parser_result->layer3_type);

    pkt_info->is_mpls_switched = is_mpls && (pkt_info->is_router_mac
                                 || ((0x01005E == macda_47_to_24) && (8 == parser_result->l2_s.mac_da2 >> 4))
                                 || pkt_info->bcast_mac_address) && pkt_info->mpls_en && (!route_stp_block); /* && pin_mpls_switch_en(cmodel do not need) */

    parser_layer4_type = L4_TYPE_NONE;

    if (pkt_info->bypass_all || pkt_info->discard)
    {
        return DRV_E_NONE;
    }

    /* TUNNEL_PBB_MPLS */
    if (pbb && ((PBB_PORT_TYPE_PIP == pkt_info->pbb_src_port_type)
        || (PBB_PORT_TYPE_PNP == pkt_info->pbb_src_port_type)
        || (PBB_PORT_TYPE_CBP == pkt_info->pbb_src_port_type)))
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Tunnel Decap(PBB) Process");
        /* PBB_OPERATION */
        DRV_IF_ERROR_RETURN(_cm_ipe_tunnel_terminate_pbb_operation(in_pkt));
    }
    else if (tunnel_decap1 || tunnel_decap2)
    {
        if (tunnel_decap1)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Tunnel Decap Process");

            /* TUNNEL_DECAP_OPERATION(1) */
            DRV_IF_ERROR_RETURN(_cm_ipe_tunnel_terminate_tunnel_decaps1_op(in_pkt, &tunnel_info));
        }

        if (!tunnel_decap2 && tunnel_info.capwap_bss_id_check)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = IPE_DISCARD_CAPWAP_BSSID_LKP_OR_LOGIC_PORT_CHK_DISCARD;
                CMODEL_DEBUG_OUT_INFO("++++ Discard! capwap lookup bssid fail!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }

        if (tunnel_decap2 && !tunnel_info.deny_tunnel_decap2)
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Tunnel Decap Process");

            /* TUNNEL_DECAP_OPERATION(2) */
            DRV_IF_ERROR_RETURN(_cm_ipe_tunnel_terminate_tunnel_decaps2_op(in_pkt, &tunnel_info));
        }

        pkt_info->is_esadi = tunnel_info.tunnel1_is_esadi || tunnel_info.tunnel2_is_esadi;
    }
    else if (pkt_info->is_mpls_switched)
    {
        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Tunnel Decap(MPLS) Process");

        /* MPLS_OPERATION */
        DRV_IF_ERROR_RETURN(_cm_ipe_tunnel_terminate_mpls_handle(in_pkt, &parser_layer4_type));
    }

    if ((!pkt_info->discard && pkt_info->inner_packet_lookup) || pkt_info->force_parser)
    {
        /* REQUEST_PARSING */
        DRV_IF_ERROR_RETURN(_cm_ipe_tunnel_terminate_parser(in_pkt, parser_layer4_type));

#if (SDK_WORK_PLATFORM == 1)
        if (cosim_db.store_ipe_bus[SIM_IPE_PR2LM])
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_PR2LM]((void *)in_pkt));
        }
#endif
    }

    return DRV_E_NONE;
}

