/****************************************************************************
 * cm_ipe_classification.c    Provides IPE classification handle function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Version:        V1.0.
 * Author:         Jiang
 * Date:           2010-10-13.
 * Reason:         First Create.
 *
 * Modify History:
 * Reversion:    V1.01
 * Author:       XuZx
 * Date:         2010-11-17.
 * Reason:       Revise for first formal spec.
 *
 * Reversion:    V1.02
 * Author:       XuZx
 * Date:         2010-11-23.
 * Reason:       Revise for second formal spec.
 *
 * Reversion:    V2.0
 * Author:       Jiangsz
 * Date:         2011-04-11.
 * Reason:       sync spec V2.0.
 *
 * Reversion:    V4.2.1
 * Author:       Shenhg
 * Date:         2011-07-04.
 * Reason:       sync spec V4.2.1.
 *
 * Reversion:    V4.29.0
 * Author:       wangcy
 * Date:         2011-10-08.
 * Reason:       sync spec V4.29.0.
 *
 * Reversion:    V5.1.0
 * Author:       Wangcy
 * Date:         2011-12-12.
 * Reason:       sync spec v5.1.0.
 *
 * Reversion:    V5.6.0
 * Author:       Wangcy
 * Date:         2012-01-07.
 * Reason:       sync spec v5.6.0.
 *
 * Reversion:    V5.11.0
 * Author:       ZhouW
 * Date:         2012-03-01.
 * Reason:       sync spec v5.11.0.
 *
 * Reversion:    V5.13.0
 * Author:       Wangcy
 * Date:         2012-03-12.
 * Reason:       sync spec v5.13.0.
 *
 * Reversion:    V5.15.0.1
 * Author:       Wangcy
 * Date:         2012-03-23.
 * Reason:       sync spec v5.15.0.1
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "cm_lib.h"
#include "drv_lib.h"
#include "cm_com_policing.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/


/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/

/****************************************************************************
 * Name:       cm_add64
 * Purpose:    do uint64 add with uint32.
 * Parameters:
 * Input:      a  -- cm_uint64_t including high32 and low32
 * Output:     b  -- cm_uint64_t including high32 and low32
 * Return:     cm_uint64_t (a + b) including high32 and low32
 * Note:       none.
****************************************************************************/
cm_uint64_t cm_add64(cm_uint64_t a, cm_uint64_t b)
{
    cm_uint64_t result;
    uint32 n;

    /* with carry */
    result.low_31_0 = (a.low_31_0 & 0x7fffffff) + (b.low_31_0 & 0x7fffffff);
    /* do carry */
    n = ((result.low_31_0 & 0x80000000)>>31) + ((a.low_31_0 & 0x80000000)>>31) + ((b.low_31_0 & 0x80000000)>>31);

    result.low_31_0 = (result.low_31_0 & 0x7fffffff) | ((n & 0x1) << 31);
    result.high_63_32 = a.high_63_32 + b.high_63_32 + ((n & 0x2)>>1);

    return result;
}

/****************************************************************************
 * Name:       cm_sub64
 * Purpose:    do uint64 add with uint32.
 * Parameters:
 * Input:      a  -- cm_uint64_t including high32 and low32
 * Output:     b  -- cm_uint64_t including high32 and low32
 * Return:     cm_uint64_t (a - b) including high32 and low32
 * Note:       none.
****************************************************************************/
cm_uint64_t cm_sub64(cm_uint64_t a, cm_uint64_t b)
{
    cm_uint64_t tmp;

    tmp.low_31_0 = ~(b.low_31_0);
    tmp.high_63_32 = ~(b.high_63_32);

    if (tmp.low_31_0 != 0xffffffff)
    {
        tmp.low_31_0 += 1;
    }
    else
    {
        tmp.low_31_0 = 0;
        tmp.high_63_32 += 1;
    }

    return cm_add64(a, tmp);
}

/****************************************************************************
 * Name:       cm_ipe_classification_handle
 * Purpose:    IPE classification handle process.
 * Parameters:
 * Input:      in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Output:     in_pkt  -- pointer to buffer which save input packet and packet
 *                        header ,and processing informations
 * Return:     DRV_E_NONE = success.
 *             Other      = Error, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_ipe_classification_handle(ipe_in_pkt_t *in_pkt)
{
    ipe_packet_info_t *pkt_info = (ipe_packet_info_t*)in_pkt->pkt_info;
    parsing_result_t *parser_result = (parsing_result_t*)pkt_info->parser_rslt;
    uint8 chip_id = in_pkt->chip_id;
    uint8 phb_label = 0;
    uint8 phb_offset = 0;
    uint32 phb_offset_tmp = 0;
    uint8 phb_color = 0;
    uint8 flow_policer_valid = FALSE;
    uint8 port_policer_valid = FALSE;
    uint32 cmd = 0;
    uint32 phb_offset_table_index = 0;
    uint32 phb_label_index = 0;
    uint16 in_port_policer = 0;
    uint16 flow_policer = 0;
    uint16 port_policer = 0;
    uint16 policer_length = 0;
    uint8 mark_drop = FALSE;
    uint8 new_color = 0;
    uint8 policer_layer3_offset = 0;
    uint8 mux_len = 0;
    uint32 field_id = 0;
    uint8 ptp_version = 0;
    uint8 ptp_message_type = 0;
    uint8 ptp_event_message = FALSE;
    uint8 ptp_peer_message = FALSE;
    uint8 is_ptp_mcast = FALSE;
    uint32 ptp_extra_offset = 0;
    uint8 timestamp_correction_disable = FALSE;
    ipe_classification_ctl_t ipe_classification_ctl;
    policing_info_t policing_info;
    ds_src_channel_t ds_src_channel;
    ipe_ptp_ctl_t ipe_ptp_ctl;
    cm_uint64_t timestamp,tmp_64_a,tmp_64_b;

    sal_memset(&timestamp,0,sizeof(timestamp));

    sal_memset(&ds_src_channel, 0, sizeof(ds_src_channel));
    cmd = DRV_IOR(DsSrcChannel_t, DRV_ENTRY_FLAG);
     DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, in_pkt->chan_id & 0x3F, cmd, &ds_src_channel));

    sal_memset(&ipe_ptp_ctl, 0, sizeof(ipe_ptp_ctl));
    cmd = DRV_IOR(IpePtpCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_ptp_ctl));

    /* INIT */

    /* different forwarding domain and STP for PTP and Data packet when port-based service interface ??? */
    /* PTP multi domain based on UDP port, IP address,VLAN,Label,etc ??? */
    ptp_extra_offset = pkt_info->share_fields_u.ptp.ptp_extra_offset;
    /* pkt_info->qcn_port_id = ds_src_channel.qcn_port_id;*/

    if (pkt_info->time_stamp_valid)
    {
        sal_memset(&tmp_64_a,0,sizeof(tmp_64_a));
        tmp_64_a.high_63_32 = pkt_info->share_fields_u.ptp.time_stamp_61_32;
        tmp_64_a.low_31_0 = pkt_info->share_fields_u.ptp.time_stamp_31_0;

        sal_memset(&tmp_64_b,0,sizeof(tmp_64_b));
        tmp_64_b.high_63_32 = 0;
        tmp_64_b.low_31_0 = ds_src_channel.ingress_latency & 0xFFFF;

        timestamp = cm_sub64(tmp_64_a, tmp_64_b);

     //   pkt_info->time_stamp61_32 = timestamp.high_63_32 & 0x3FFFFFFF;
     //   pkt_info->time_stamp31_0 = timestamp.low_31_0;
    }

    if (pkt_info->time_stamp_valid && pkt_info->ptp_en)
    {
        if (L3_TYPE_PTP == parser_result->layer3_type)/* Ethernet encapsulated */
        {
            ptp_version = parser_result->l3_s.ip_da.ptp.ptp_version & 0x3;
            ptp_message_type = parser_result->l3_s.ip_da.ptp.ptp_message_type & 0xF;
        }
        else
        {
            ptp_version = parser_result->l4_s.rid_ptp_bfd.ptp_msg_type.udp_ptp_version0
                          | (parser_result->l4_s.isatap_ptp_ver.udp_ptp_version1 << 1);
            ptp_message_type = parser_result->l4_s.rid_ptp_bfd.ptp_msg_type.udp_ptp_message_type;
        }

        ptp_event_message = (PTP_MESSAGE_TYPE_SYNC == ptp_message_type) ||
                            (PTP_MESSAGE_TYPE_DELAY_REQ == ptp_message_type) ||
                            (PTP_MESSAGE_TYPE_PDELAY_REQ == ptp_message_type) ||
                            (PTP_MESSAGE_TYPE_PDELAY_RESP == ptp_message_type);

        ptp_peer_message = (PTP_MESSAGE_TYPE_PDELAY_REQ == ptp_message_type) ||
                            (PTP_MESSAGE_TYPE_PDELAY_RESP == ptp_message_type) ||
                            (PTP_MESSAGE_TYPE_PDELAY_RESP_FOLLOW_UP == ptp_message_type);

        is_ptp_mcast = IS_BIT_SET(parser_result->l2_s.mac_da5, 0) || ipe_ptp_ctl.ptp_force_mcast;

        if (3 == ipe_ptp_ctl.ptp_clock_type)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PTP;

            pkt_info->discard = TRUE;
            pkt_info->discard_type = IPE_DISCARD_PTPT_P2P_TRANS_CLOCK_DELAY_DISCARD;
        }
        /* BC/OC Unicast/Multicast */
        else if ((1 == ipe_ptp_ctl.ptp_clock_type) && pkt_info->self_address
                 && (!ipe_ptp_ctl.ptp_ucast_disable || is_ptp_mcast))
        {
            pkt_info->ptp_valid = TRUE;   /* PTP Enabled,timestamp within packetheader */

        }
        /* TC version 1/2 */
        else if ((2 == ipe_ptp_ctl.ptp_clock_type)
                 && (!ipe_ptp_ctl.ptp_ucast_disable || is_ptp_mcast))
        {
            timestamp_correction_disable = FALSE;

            if ((2 == ptp_version) || ((3 == ptp_version) && (2 == ipe_ptp_ctl.ptp_high_version_action_type)))
            {
                pkt_info->ptp_transparent_clock_en = ptp_event_message;
                pkt_info->ptp_valid = TRUE;

                /* P2P transparent clock discard delay */
                if (ipe_ptp_ctl.ptp_delay_discard && !ipe_ptp_ctl.is_e2e_clock && (PTP_MESSAGE_TYPE_DELAY_REQ == ptp_message_type
                    || PTP_MESSAGE_TYPE_DELAY_RESP == ptp_message_type))
                {
                    timestamp_correction_disable = TRUE;

                    if (!pkt_info->discard)
                    {
                        pkt_info->discard = TRUE;
                        pkt_info->discard_type = IPE_DISCARD_PTPT_P2P_TRANS_CLOCK_DELAY_DISCARD;
                        CMODEL_DEBUG_OUT_INFO("++++ Discard! P2P Transparent Clock Discard\n");
                        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                    }
                }
                else if (!pkt_info->exception_en && ipe_ptp_ctl.ptp_peer_en &&
                         ((!is_ptp_mcast && pkt_info->self_address) ||
                         (is_ptp_mcast && ptp_peer_message)))
                {
                    timestamp_correction_disable = TRUE;

                    if (!ipe_ptp_ctl.ptp_delay_exception_disable)
                    {
                        /* ===== bug 4637 ECO begine ==== */
                        //if (!ipe_ptp_ctl.ptp_delay_discard)
                        if (!ipe_ptp_ctl.ptp_delay_exception_disable)
                        /* ===== bug 4637 ECO end ==== */
                        {
                            pkt_info->exception_en = TRUE;
                            pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
                            pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PTP;
                        }

                        if (!pkt_info->discard)
                        {
                            pkt_info->discard = TRUE;
                            pkt_info->discard_type = IPE_DISCARD_PTPT_P2P_TRANS_CLOCK_DELAY_DISCARD;
                            CMODEL_DEBUG_OUT_INFO("++++ Discard! P2P Transparent Clock Discard\n");
                            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                        }
                    }
                }
                /* Multicast */
                else if (!pkt_info->exception_en && is_ptp_mcast &&
                         ((((PTP_MESSAGE_TYPE_SYNC == ptp_message_type) ||
                         (PTP_MESSAGE_TYPE_FOLLOW_UP == ptp_message_type)) && ipe_ptp_ctl.ptp_sync_snooping_en) ||
                         ((PTP_MESSAGE_TYPE_SIGNALING == ptp_message_type) && ipe_ptp_ctl.ptp_signing_snooping_en) ||
                         ((PTP_MESSAGE_TYPE_MANAGEMENT == ptp_message_type) && ipe_ptp_ctl.ptp_management_snooping_en)))
                {
                    pkt_info->exception_en = TRUE;
                    pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
                    pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PTP;
                }

                if (!timestamp_correction_disable && ptp_event_message)
                {
                    /* path delay correction */
                    if (!ipe_ptp_ctl.is_e2e_clock && !ptp_peer_message)
                    {
                        sal_memset(&tmp_64_a,0,sizeof(tmp_64_a));
                        tmp_64_a.high_63_32 = timestamp.high_63_32;
                        tmp_64_a.low_31_0 = timestamp.low_31_0;

                        sal_memset(&tmp_64_b,0,sizeof(tmp_64_b));
                        tmp_64_b.high_63_32 = ds_src_channel.path_delay35_32 & 0xF;
                        tmp_64_b.low_31_0 = ds_src_channel.path_delay31_0;

                        sal_memset(&timestamp,0,sizeof(timestamp));
                        timestamp = cm_sub64(tmp_64_a, tmp_64_b);

                        //pkt_info->time_stamp61_32 = timestamp.high_63_32 & 0x3FFFFFFF;
                        //pkt_info->time_stamp31_0 = timestamp.low_31_0;
                    }

                    /* Asymmetry correction for ingress port */
                    if (PTP_MESSAGE_TYPE_SYNC == ptp_message_type || PTP_MESSAGE_TYPE_PDELAY_RESP == ptp_message_type)
                    {
                        if (!ds_src_channel.asymmetry_delay_negtive)
                        {
                            sal_memset(&tmp_64_a,0,sizeof(tmp_64_a));
                            tmp_64_a.high_63_32 = timestamp.high_63_32;
                            tmp_64_a.low_31_0 = timestamp.low_31_0;

                            sal_memset(&tmp_64_b,0,sizeof(tmp_64_b));
                            tmp_64_b.high_63_32 = ds_src_channel.asymmetry_delay35_32;
                            tmp_64_b.low_31_0 = ds_src_channel.asymmetry_delay31_0;

                            sal_memset(&timestamp,0,sizeof(timestamp));
                            timestamp = cm_sub64(tmp_64_a, tmp_64_b);

                          //  pkt_info->time_stamp61_32 = timestamp.high_63_32 & 0x3FFFFFFF;
                          //  pkt_info->time_stamp31_0 = timestamp.low_31_0;
                        }
                        else
                        {
                            sal_memset(&tmp_64_a,0,sizeof(tmp_64_a));
                            tmp_64_a.high_63_32 = timestamp.high_63_32;
                            tmp_64_a.low_31_0 = timestamp.low_31_0;

                            sal_memset(&tmp_64_b,0,sizeof(tmp_64_b));
                            tmp_64_b.high_63_32 = ds_src_channel.asymmetry_delay35_32;
                            tmp_64_b.low_31_0 = ds_src_channel.asymmetry_delay31_0;

                            sal_memset(&timestamp,0,sizeof(timestamp));
                            timestamp = cm_add64(tmp_64_a, tmp_64_b);

                           // pkt_info->time_stamp61_32 = timestamp.high_63_32 & 0x3FFFFFFF;
                           // pkt_info->time_stamp31_0 = timestamp.low_31_0;
                        }

                    }
                }
            }
            else if ((0x0 == ptp_version) || ((0x3 == ptp_version) &&
                     (0x0 == ipe_ptp_ctl.ptp_high_version_action_type)))
            {
                if (!pkt_info->discard)
                {
                    pkt_info->discard = TRUE;
                    pkt_info->discard_type = IPE_DISCARD_PTP_VERSION_CHK_ERR;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! PTP Version Check Error\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
            else if (0x3 == ptp_version && !pkt_info->exception_en &&
                     (0x1 == ipe_ptp_ctl.ptp_high_version_action_type))
            {
                pkt_info->exception_en = TRUE;
                pkt_info->exception_index = EXCEPTION_TYPE_OTHER;
                pkt_info->exception_sub_index = EXCEPTION_SUB_TYPE_PTP;  /* To CPU*/

                if (!pkt_info->discard)
                {
                    pkt_info->discard = TRUE;
                    pkt_info->discard_type = IPE_DISCARD_PTP_VERSION_CHK_ERR;
                    CMODEL_DEBUG_OUT_INFO("++++ Discard! PTP Version Check Error\n");
                    CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
                }
            }
        }
    }

    if (pkt_info->ptp_valid
        || (pkt_info->exception_en && (EXCEPTION_TYPE_OTHER == pkt_info->exception_index)
        && pkt_info->time_stamp_valid
        && (EXCEPTION_SUB_TYPE_PTP == pkt_info->exception_sub_index)))
    {
        pkt_info->share_type = SHARE_TYPE_PTP;
        pkt_info->share_fields_u.ptp.ptp_extra_offset = ptp_extra_offset;
        pkt_info->share_fields_u.ptp.time_stamp_61_32 = timestamp.high_63_32 & 0x3FFFFFFF;
        pkt_info->share_fields_u.ptp.time_stamp_31_0 = timestamp.low_31_0;
    }
    else if (pkt_info->share_type == SHARE_TYPE_NONE)
    {
        pkt_info->share_fields_u.ptp.time_stamp_61_32 = timestamp.high_63_32 & 0x3FFFFFFF;
        pkt_info->share_fields_u.ptp.time_stamp_31_0 = timestamp.low_31_0;
    }
#if (SDK_WORK_PLATFORM == 1)
    if (cosim_db.store_ipe_bus[SIM_IPE_LR2FW])
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_ipe_bus[SIM_IPE_LR2FW]((void *)in_pkt));
    }
#endif

    new_color = pkt_info->color;
    mark_drop = FALSE;

    sal_memset(&policing_info, 0, sizeof(policing_info));
    policing_info.new_color = new_color;
    policing_info.mark_drop = mark_drop;

    sal_memset(&ipe_classification_ctl, 0, sizeof(ipe_classification_ctl));

    /* DISCARD_SWITCH */
    if (!pkt_info->discard)
    {
        /* INCOMING_PHB */
        phb_label = pkt_info->priority;
        phb_color = pkt_info->color;

        phb_offset_table_index = phb_label / 16;
        phb_label_index = phb_label % 16;
        field_id = IpeClassificationPhbOffset_PhbOffset0_f + phb_label_index;
        cmd = DRV_IOR(IpeClassificationPhbOffset_t, field_id);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, phb_offset_table_index, cmd, &phb_offset_tmp));
        phb_offset = phb_offset_tmp & 0x3;

        /* PLICER_PARAMETERS */
        /* Get policer offset, different PHB lablel may use the same policer */
        sal_memset(&ipe_classification_ctl, 0, sizeof(ipe_classification_ctl));
        cmd = DRV_IOR(IpeClassificationCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &ipe_classification_ctl));

        in_port_policer = ((pkt_info->local_phy_port << ipe_classification_ctl.port_policer_shift)) & 0x1FFF;

        if (ipe_classification_ctl.port_policer_phb_en)
        {
            port_policer = (in_port_policer + phb_offset + ipe_classification_ctl.port_policer_base) & 0x1FFF;
        }
        else
        {
            port_policer = (in_port_policer + ipe_classification_ctl.port_policer_base) & 0x1FFF;
        }

        port_policer_valid = pkt_info->port_policer_valid || pkt_info->agg_flow_policer_valid;

        if (pkt_info->agg_flow_policer_valid)
        {
            port_policer = pkt_info->agg_flow_policer_ptr;
            CMODEL_DEBUG_OUT_INFO("++++++++++++++ IPE Do agg flow policer ++++++++++++++\n");
            CMODEL_DEBUG_OUT_INFO("agg_flow_policer_ptr =%d\n", pkt_info->agg_flow_policer_ptr);
        }

        if (pkt_info->flow_policer_valid)  /*use flow policer from QOS lookup*/
        {
            flow_policer = pkt_info->flow_policer_ptr;
            flow_policer_valid = TRUE;
            CMODEL_DEBUG_OUT_INFO("++++++++++++++ IPE Do Flow policer ++++++++++++++\n");
            CMODEL_DEBUG_OUT_INFO("Flow_policer_ptr =%d\n", pkt_info->flow_policer_ptr);

        }
        else if (pkt_info->service_policer_valid)
        {
            flow_policer_valid = TRUE;

            if (pkt_info->service_policer_mode)/* not hierachial policer */
            {
                CMODEL_DEBUG_OUT_INFO("++++++++++++++ IPE Do Service policer0 ++++++++++++++\n");
                flow_policer = (pkt_info->service_policer_ptr + 1
                                + ((3 == phb_offset) ? 2 : phb_offset)) & 0x1FFF; /* merge 2 and 3 */
                CMODEL_DEBUG_OUT_INFO("flow_policer_ptr =%d\n", flow_policer);

                port_policer = pkt_info->service_policer_ptr;
                port_policer_valid = TRUE;
            }
            else
            {
                CMODEL_DEBUG_OUT_INFO("++++++++++++++ IPE Do Service policer1 ++++++++++++++\n");
                flow_policer = pkt_info->service_policer_ptr + phb_offset;
                CMODEL_DEBUG_OUT_INFO("flow_policer_ptr =%d\n", flow_policer);
            }
        }
        else
        {
            flow_policer = 0;
            flow_policer_valid = FALSE;
        }

        if (MUX_LENGTH_TYPE1 == pkt_info->mux_length_type)
        {
            mux_len = 4;
        }
        else if (MUX_LENGTH_TYPE2 == pkt_info->mux_length_type)
        {
            mux_len = 8;
        }
        else
        {
            mux_len = 0;
        }

        /* PacketInfo.packetLength[13:0] is Eop or Sop/Eop real packetLength */
        /* policerLength[13:0] is 0 for Sop,real length for Sop/Eop */
        policer_length = pkt_info->packet_length - pkt_info->packet_length_adjust - mux_len;    /* Eop */

        policer_layer3_offset = parser_result->l2_s.layer3_offset - pkt_info->packet_length_adjust - mux_len;

        /* POLICING_OPERATION */
        if ((flow_policer_valid || port_policer_valid) && ((in_pkt->chan_id >= 32) ? IS_BIT_SET(ipe_classification_ctl.channel_policing_en63_32,in_pkt->chan_id - 32)
                                                                                   : IS_BIT_SET(ipe_classification_ctl.channel_policing_en31_0,in_pkt->chan_id))) /* perform policing operation*/
        {
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "IPE Classification Process");
            if (ipe_classification_ctl.flow_policer_first)
            {
                policing_info.chip_id = chip_id;
                policing_info.packet_length = policer_length;
                policing_info.color = phb_color;
                policing_info.policer_valid0 = flow_policer_valid;
                policing_info.policer_ptr0 = flow_policer;
                policing_info.layer3_offset = policer_layer3_offset;
                policing_info.policer_valid1 = port_policer_valid;
                policing_info.policer_ptr1 = port_policer;
                policing_info.ipg = pkt_info->ipg;
                policing_info.mark_drop = mark_drop;
                policing_info.new_color = new_color;

                /* here send packet must < 256B, CoSim use */
                policing_info.sop = TRUE;
                policing_info.eop = TRUE;
                policing_info.sop_color = 0;

                /* flow policer first */
                DRV_IF_ERROR_RETURN(cm_com_policing_operation(&policing_info));
            }
            else
            {
                policing_info.chip_id = chip_id;
                policing_info.packet_length = policer_length;
                policing_info.color = phb_color;
                policing_info.policer_valid0 = port_policer_valid;
                policing_info.policer_ptr0 = port_policer;
                policing_info.layer3_offset = policer_layer3_offset;
                policing_info.policer_valid1 = flow_policer_valid;
                policing_info.policer_ptr1 = flow_policer;
                policing_info.ipg = pkt_info->ipg;
                policing_info.mark_drop = mark_drop;
                policing_info.new_color = new_color;

                /* here send packet must < 256B, CoSim use */
                policing_info.sop = TRUE;
                policing_info.eop = TRUE;
                policing_info.sop_color = 0;

                /* port policer first */
                DRV_IF_ERROR_RETURN(cm_com_policing_operation(&policing_info));
            }
        }
    }

    /* CLASSIFICATION_RESULT */
    pkt_info->mark_drop = policing_info.mark_drop;
    pkt_info->new_color = policing_info.new_color;

    /* ECN packet? */
    return DRV_E_NONE;
}

