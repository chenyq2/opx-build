
/****************************************************************************
 * oam_tx_pkt.c : tx a pkt to bsr
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-11-23.
 * Reason:       First Create.
 *
 * Revision:     V2.0.
 * Author:       mengzw.
 * Date:         2011-04-20.
 * Reason:       Sync for spec V2.0.
 *
 * Revision:     V4.28.
 * Author:       zhaomc.
 * Date:         2011-09-28.
 * Reason:       Sync for spec V4.28.
 ****************************************************************************/


#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

struct oam_tx_pkt_info_s
{
    uint32 mep_index        :14;
    uint32 rmep_index       :14;
    uint32 is_eth           :1;
    uint32 cos              :3;

    uint32 mac_sa_byte      :16;
    uint32 packet_length    :16;

    uint32 chip_id          :5;
    uint32 if_status        :3;
    uint32 is_bfd           :1;
    uint32 is_tx_csf        :1;
    uint32 is_tx_cv         :1;
    uint32 rsv_0            :21;

    void* p_ds_mep;
    void* p_ds_rmep;
    void* p_ds_ma;
    void* p_packet_header ;
    uint8* pkt;
    uint8 ma_id_byte[48];
};
typedef struct oam_tx_pkt_info_s oam_tx_pkt_info_t;

struct oam_mpls_info_s
{
    uint32 mpls_pkt_type    :2;
    uint32 frequency        :8;
    uint32 mep_id           :13;
    uint32 resv             :9;

    uint32 defect_location;
    uint8 mpls_header[8];
    uint8 ma_id[48];
};
typedef struct oam_mpls_info_s oam_mpls_info_t;

/****************************************************************************
 * Name:       _cm_oam_gen_packet_header
 * Purpose:    generate packet header
 * Parameters:
 * Input:      tx_pkt_info -- pointer to buffer which save information
 *                       used in module generate ccm.
 * Output:     tx_pkt_info -- pointer to buffer which save information
 *                       used in module generate ccm.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_gen_packet_header(oam_tx_pkt_info_t * tx_pkt_info)
{
    greatbelt_packet_header_t cm_packet_header;

    ms_packet_header_t *packet_header = tx_pkt_info->p_packet_header;
    uint8 chip_id = tx_pkt_info->chip_id;
    uint16 mep_index = tx_pkt_info->mep_index;
    uint16 rmep_index = tx_pkt_info->rmep_index;
    ds_ma_t* ds_ma = (ds_ma_t*)tx_pkt_info->p_ds_ma;
    ds_eth_mep_t* ds_mep = (ds_eth_mep_t*)tx_pkt_info->p_ds_mep;

    ds_bfd_rmep_t *ds_bfd_rmep  = (ds_bfd_rmep_t*)tx_pkt_info->p_ds_rmep;
    ds_eth_mep_t  *ds_eth_mep   = (ds_eth_mep_t*)tx_pkt_info->p_ds_mep;

    uint8 ma_id_length_shift = 0;
    ds_ma_name_t ds_ma_name[6];
    uint8 ma_id_byte[48] = {0};

    uint8 priority_index = 0;
    uint16 ma_name_index = 0;
    uint8 is_eth = FALSE;
    uint8 is_bfd = FALSE;
    uint8 mp_port_id = 0;
    uint8 byte_index = 0;

    oam_ether_tx_ctl_t oam_ether_tx_ctl;
    ds_port_property_t ds_port_property;
    ds_priority_map_t ds_priority_map;
    uint32 cmd = 0;

    uint8 cw_add = FALSE;
    uint8 header_hash = 0;
    uint32 next_hop_ptr = 0;
    uint8 oam_label_exist = FALSE;

    ds_aps_bridge_t ds_aps_bridge0;
    ds_aps_bridge_t ds_aps_bridge1;
    uint8 next_aps_bridge_en1 = FALSE;
    uint32 dest_map = 0;
    uint16 next_aps_group_id = 0;
    uint8 aps_protecting_en1 = FALSE;
    uint8 aps_bridge_en = 0;
    uint8 tx_mcast_en = FALSE;

    uint8 dest_chip = 0;
    uint16 dest_id = 0;

    uint32 tx_dest_id = 0;
    uint32 tx_dest_port = 0;
    uint8 crc = 0;

    /*DEFAULT*/
    ma_name_index = ds_ma->ma_name_index;
    is_eth = ((ETH_CCM_MEP == ds_mep->mep_type)||(PBT_CCM_MEP == ds_mep->mep_type)
                ||(ACH_Y1731_MEP == ds_mep->mep_type));
    is_bfd = ((BFD_MEP == ds_mep->mep_type)||(ACH_BFD_MEP == ds_mep->mep_type)||(TRILL_BFD_MEP == ds_mep->mep_type));

    if(ds_mep->is_bfd)
    {
        aps_bridge_en = ds_bfd_rmep->aps_bridge_en;
    }
    else
    {
        aps_bridge_en = ds_eth_mep->aps_bridge_en;
    }

    sal_memset(&oam_ether_tx_ctl, 0, sizeof(oam_ether_tx_ctl));
    cmd = DRV_IOR(OamEtherTxCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_ether_tx_ctl));

    if (is_eth)
    {
        if(ds_mep->is_up && oam_ether_tx_ctl.tx_ccm_by_epe)/*UP MEP tx ccm by BSR->EEP*/
        {
            mp_port_id = ds_mep->port_id;
        }
        else/*down MEP, UP MEP tx ccm by iloopback (BSR->IPE->BSR->EPE)*/
        {
            if (0x1F == ds_mep->dest_chip)
            {
                mp_port_id = 128 + (ds_mep->dest_id & 0x3F);
            }
            else
            {
                mp_port_id = ds_mep->dest_id & 0x7F;
            }
        }
        sal_memset(&ds_port_property, 0, sizeof(ds_port_property));
        cmd = DRV_IOR(DsPortProperty_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mp_port_id, cmd, &ds_port_property));
    }

    priority_index = ds_ma->priority_index;
    sal_memset(&ds_priority_map, 0, sizeof(ds_priority_map));
    cmd = DRV_IOR(DsPriorityMap_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, priority_index, cmd, &ds_priority_map));

    if(is_eth && ds_mep->is_up && oam_ether_tx_ctl.tx_ccm_by_epe)
    {/*mcast group id*/
        tx_dest_id = (ds_mep->dest_chip << 16) | ds_mep->dest_id;
        tx_dest_port = 0;
    }
    else
    {
        sal_memset(&ds_aps_bridge0, 0, sizeof(ds_aps_bridge_t));
        sal_memset(&ds_aps_bridge1, 0, sizeof(ds_aps_bridge_t));

        if(aps_bridge_en) /*only mpls networks scene*/
        {
            /*APS levl 1*/
            cmd = DRV_IOR(DsApsBridge_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, (ds_mep->dest_id&0xFFF), cmd, &ds_aps_bridge0));

            if(ds_aps_bridge0.protecting_en && !ds_aps_bridge0.protecting_next_aps_bridge_en)
            {
                next_aps_bridge_en1 = FALSE;
                dest_map = ds_aps_bridge0.protecting_dest_map;
            }
            else if(!ds_aps_bridge0.protecting_en && !ds_aps_bridge0.protecting_next_aps_bridge_en)
            {
                next_aps_bridge_en1 = FALSE;
                dest_map = ds_aps_bridge0.working_dest_map;
            }
            else if(ds_aps_bridge0.protecting_en && ds_aps_bridge0.protecting_next_aps_bridge_en)
            {
                next_aps_bridge_en1 = TRUE;
                next_aps_group_id = ds_aps_bridge0.protecting_dest_map & 0xFFF;
            }
            else
            {/*!ds_aps_bridge0.protecting_en && ds_aps_bridge0.protecting_next_aps_bridge_en*/
                next_aps_bridge_en1 = TRUE;
                next_aps_group_id = ds_aps_bridge0.working_dest_map & 0xFFF;
            }

            /*APS Level 2*/
            if(next_aps_bridge_en1)
            {
                cmd = DRV_IOR(DsApsBridge_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, next_aps_group_id, cmd, &ds_aps_bridge1));
                aps_protecting_en1 = ds_aps_bridge1.protecting_en;
                if(ds_aps_bridge1.protecting_en)
                {
                    dest_map = ds_aps_bridge1.protecting_dest_map;
                }
                else
                {
                    dest_map = ds_aps_bridge1.working_dest_map;
                }
            }

        }
        else
        {

            if(is_eth)
            {
                dest_chip = ds_mep->dest_chip;
                dest_id  = ds_mep->dest_id;
            }
            else if(is_bfd)
            {
                dest_chip = ((ds_bfd_mep_t*)ds_mep)->dest_chip;
                dest_id  = ((ds_bfd_mep_t*)ds_mep)->dest_id;
            }

            tx_mcast_en = ds_mep->is_bfd ? ds_bfd_rmep->tx_mcast_en : ds_eth_mep->tx_mcast_en;
            dest_map = (tx_mcast_en << 21) | (dest_chip << 16) | dest_id;
        }

        if((0x1F == ((dest_map >> 16) & 0x1F)) && oam_ether_tx_ctl.lkup_link_agg_mem)
        {
            crc = cm_oam_gen_header_hash(mep_index, rmep_index, 0xFF);

            tx_dest_port = cm_oam_com_get_link_agg_port(chip_id ,(dest_map & 0x3F), crc);
            tx_dest_id = (((tx_dest_port>>9)&0x1F) << 16)| (oam_ether_tx_ctl.linkagg_dest_id15_9 << 9) |(tx_dest_port&0x1FF);

        }
        else
        {
            tx_dest_id = dest_map & 0x1FFFFF;
            tx_dest_port = (((dest_map >> 16)&0x1F) << 9) | (dest_map & 0x1FF);
        }
    }

    ma_id_length_shift = ds_ma->ma_id_length_type;
    sal_memset(ds_ma_name, 0, sizeof(ds_ma_name_t)*6);
    cmd = DRV_IOR(DsMaName_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index, cmd, &ds_ma_name[0]));
    if (ma_id_length_shift != 0)
    {
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, (ma_name_index + 1), cmd, &ds_ma_name[1]));
        ma_id_length_shift = ma_id_length_shift - 1;
        if (ma_id_length_shift != 0)
        {
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, (ma_name_index + 2), cmd, &ds_ma_name[2]));
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, (ma_name_index + 3), cmd, &ds_ma_name[3]));
            ma_id_length_shift = ma_id_length_shift - 1;
            if (ma_id_length_shift != 0)
            {
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, (ma_name_index + 4), cmd, &ds_ma_name[4]));
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, (ma_name_index + 5), cmd, &ds_ma_name[5]));
            }
        }
    }

    for (byte_index = 0; byte_index < 6; byte_index++)
    {
        ma_id_byte[8 * byte_index + 0] = (ds_ma_name[byte_index].ma_id_umc0 >> 24) & 0xFF;
        ma_id_byte[8 * byte_index + 1] = (ds_ma_name[byte_index].ma_id_umc0 >> 16) & 0xFF;
        ma_id_byte[8 * byte_index + 2] = (ds_ma_name[byte_index].ma_id_umc0 >> 8) & 0xFF;
        ma_id_byte[8 * byte_index + 3] = ds_ma_name[byte_index].ma_id_umc0  & 0xFF;
        ma_id_byte[8 * byte_index + 4] = (ds_ma_name[byte_index].ma_id_umc1 >> 24) & 0xFF;
        ma_id_byte[8 * byte_index + 5] = (ds_ma_name[byte_index].ma_id_umc1 >> 16) & 0xFF;
        ma_id_byte[8 * byte_index + 6] = (ds_ma_name[byte_index].ma_id_umc1 >> 8) & 0xFF;
        ma_id_byte[8 * byte_index + 7] = ds_ma_name[byte_index].ma_id_umc1 & 0xFF;
    }

    /*GEN_PACKET_HEADER*/
    sal_memset(packet_header, 0, sizeof(ms_packet_header_t));
    sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));
    /*header.rxOam=0*/
    sal_memset(&oam_ether_tx_ctl, 0, sizeof(oam_ether_tx_ctl));
    cmd = DRV_IOR(OamEtherTxCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_ether_tx_ctl));

    oam_label_exist = ((ds_mep->mep_type == ACH_Y1731_MEP) || (ds_mep->mep_type == ACH_BFD_MEP)) &&
                        (!ds_ma->tx_untagged_oam || ds_ma->tx_with_if_status);

    /*cm_packet_header.tx_fcb30_29_u.rx_oam_label_exist |= oam_label_exist;*/
    //to be done ,should be removed by spec
    if(oam_label_exist)
    {
        cm_packet_header.packet_type = PKT_TYPE_MPLS;
    }
    else if(is_eth && (ds_mep->mep_type != ACH_Y1731_MEP))
    {
        cm_packet_header.packet_type = PKT_TYPE_ETHERNETV2;
    }
    else
    {
        cm_packet_header.packet_type = PKT_TYPE_RESERVED;
    }

    if(ds_mep->is_up && !oam_ether_tx_ctl.tx_ccm_by_epe)
    {
        cm_packet_header.dest_chip_id = (tx_dest_port >> 9) & 0x1F;
        cm_packet_header.dest_id      = oam_ether_tx_ctl.iloop_chan_id;
    }
    else
    {
        cm_packet_header.dest_chip_id = (tx_dest_id >> 16) & 0x1F;
        cm_packet_header.dest_id      = tx_dest_id & 0xFFFF;
    }

    cm_packet_header.priority = ds_priority_map.priority;
    cm_packet_header.source_cos = ds_priority_map.cos;
    cm_packet_header.color = ds_priority_map.color;

    /* ======== bug 4990 metal fix ECO begin ========= */
    //cm_packet_header.ttl_u.ttl = ((ds_mep->mep_type == ACH_Y1731_MEP) || (ds_mep->mep_type == ACH_BFD_MEP))?ds_ma->mpls_ttl:0;
    cm_packet_header.ttl_u.ttl = ds_ma->mpls_ttl;
    /* ======== bug 4990 metal fix ECO end ========= */
    cw_add = ((ACH_Y1731_MEP == ds_mep->mep_type)||(ACH_BFD_MEP == ds_mep->mep_type)) ? TRUE : FALSE;
    cm_packet_header.ip_sa_u.share2.mip_en_or_cw_added = cw_add; /*cwAdd*/
    cm_packet_header.critical_packet = TRUE;
    cm_packet_header.from_cpu_or_oam = TRUE;

    header_hash = cm_oam_gen_header_hash(mep_index, rmep_index, 0xff);
    cm_packet_header.header_hash2_0 = header_hash & 0x7;
    cm_packet_header.header_hash7_3 = (header_hash >> 3) & 0x1F;

    cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr = 0;
    cm_packet_header.source_port = (oam_ether_tx_ctl.oam_chip_id << 9) | (oam_ether_tx_ctl.oam_port_id&0x7F);

    cm_packet_header.rxtx_fcl0_u.oam_use_fid = 0;
    cm_packet_header.next_hop_ext = ds_ma->next_hop_ext;
    /*header:mpls_label_valid[3:0]*/
    cm_packet_header.ip_sa_u.share3.mpls_label_disable = ~(ds_ma->mpls_label_valid);

    cm_packet_header.source_port_isolate_id_u.share2.is_up = ds_mep->is_up;
    cm_packet_header.ip_sa_u.share2.oam_type = ds_ma->rx_oam_type; /*oamType[3:0]*/
    cm_packet_header.operation_type = OPERATION_TYPE_OAM;
    cm_packet_header.ip_sa_u.share3.link_oam = ds_ma->linkoam;

    if (ds_mep->is_up)
    {
        if(ds_ma->use_vrfid_lkup)/*use for vpls up mep*/
        {
            cm_packet_header.rxtx_fcl0_u.oam_use_fid = ds_ma->use_vrfid_lkup;
            cm_packet_header.fid_u.share1.fid = ds_ma->next_hop_ptr & 0x3fff;
            cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr = oam_ether_tx_ctl.user_vlan_ptr;
        }
        else
        {
            cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr = ds_ma->next_hop_ptr & 0x1FFF;
        }
        cm_packet_header.mcast = oam_ether_tx_ctl.tx_ccm_by_epe;
        next_hop_ptr = oam_ether_tx_ctl.tx_ccm_by_epe ? 0 : (tx_dest_port&0x1FF);
    }
    else
    {
        if ((ETH_CCM_MEP == ds_mep->mep_type)||(PBT_CCM_MEP == ds_mep->mep_type))
        {
            cm_packet_header.src_vlan_ptr_t.share1.src_vlan_ptr = ds_ma->next_hop_ptr & 0x1fff;
            next_hop_ptr = (oam_ether_tx_ctl.bridge_nexthop_ptr_high << 12) | oam_ether_tx_ctl.bridge_next_ptr_low;
        }
        else
        {
            next_hop_ptr = ds_ma->next_hop_ptr;
            cm_packet_header.mcast = IS_BIT_SET(dest_map, 21);
        }
    }
    cm_packet_header.next_hop_ptr = next_hop_ptr & 0x3FFFF;

    cm_gen_greatbelt_packet_header(packet_header, &cm_packet_header, FALSE);

    /*assign output parameters*/
    tx_pkt_info->is_eth = is_eth;
    tx_pkt_info->is_bfd = is_bfd;
    tx_pkt_info->mac_sa_byte = ds_port_property.mac_sa_byte;
    tx_pkt_info->if_status = ds_port_property.if_status;
    tx_pkt_info->cos = ds_priority_map.cos;
    sal_memcpy(tx_pkt_info->ma_id_byte, ma_id_byte, 48);

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_gen_eth_ccm_pdu
 * Purpose:    generate eth ccm pdu
 * Parameters:
 * Input:      tx_pkt_info -- pointer to buffer which save information
 *                       used in module generate ccm.
 * Output:     tx_pkt_info -- pointer to buffer which save information
 *                       used in module generate ccm.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_gen_eth_ccm_pdu(oam_tx_pkt_info_t * tx_pkt_info )
{
    ds_eth_mep_t* ds_eth_mep = (ds_eth_mep_t*) tx_pkt_info->p_ds_mep;
    ds_eth_rmep_t* ds_eth_rmep = (ds_eth_rmep_t*) tx_pkt_info->p_ds_rmep;
    ds_ma_t* ds_ma = (ds_ma_t*) tx_pkt_info->p_ds_ma;
    uint8 chip_id = tx_pkt_info->chip_id;
    uint8* pkt = tx_pkt_info->pkt;
    ms_packet_header_t* packet_header = (ms_packet_header_t *)tx_pkt_info->p_packet_header;
    cm_greatbelt_packet_header_t cm_packet_header;


    oam_ether_tx_ctl_t oam_ether_tx_ctl;
    oam_parser_ether_ctl_t oam_parser_ether_ctl;
    oam_ether_tx_mac_t oam_ether_tx_mac;
    oam_ether_send_id_t oam_ether_send_id;

    uint16 ccm_vid = 0;
    uint8 cos = 0;
    uint16 ccm_type = 0;
    uint8 ccm_md_level = 0;
    uint8 ccm_version = 0;
    uint8 ccm_opcode = 0;
    uint8 ccm_flag = 0;
    uint8 ccm_first_tlv_offset = 0;
    uint16 ccm_mep_id = 0;
    uint8 ccm_intf_status = 0;
    uint8 ccm_port_status = 0;
    uint32 ccm_seq_num = 0;
    uint8 tx_with_if_status = FALSE;
    uint8 tx_with_port_status = FALSE;
    uint8 tx_with_send_id = FALSE;
    uint16 tpid =0;
    uint8 tx_untagged_oam = FALSE;
    uint8 pkt_byte_offset = 0;
    uint8 ccm_da[6] = {0};
    uint8 ccm_sa[6] = {0};
    uint8 ma_id[48] = {0};
    uint8 send_id_length = 0;
    uint8 sendid[15] = {0};
    uint8 header_crc = 0;
    uint8 sbit = 0;
    uint32 packet_crc = 0;
    uint32 mpls_tp_entropy_label = 0;

    uint32 cmd = 0;
    uint8 csf_type = 0;
    uint8 csf_flag = 0;
    uint32 real_pkt_len = 0;

    sal_memset(&cm_packet_header, 0, sizeof(cm_greatbelt_packet_header_t));
    cm_gen_greatbelt_packet_header(packet_header, &cm_packet_header, TRUE);

    sal_memset(&oam_ether_tx_ctl, 0, sizeof(oam_ether_tx_ctl));
    cmd = DRV_IOR(OamEtherTxCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_ether_tx_ctl));

    sal_memset(&oam_ether_tx_mac, 0, sizeof(oam_ether_tx_mac_t));
    cmd = DRV_IOR(OamEtherTxMac_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_ether_tx_mac));


    sal_memset(&oam_parser_ether_ctl, 0, sizeof(oam_parser_ether_ctl));
    cmd = DRV_IOR(OamParserEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_parser_ether_ctl));

    if (PBT_CCM_MEP == ds_eth_mep->mep_type
         || (tx_pkt_info->is_tx_csf && IS_BIT_SET(ds_eth_rmep->ccm_seq_num0,15))
         || (ds_eth_mep->eth_oam_p2_p_mode && ds_eth_mep->p2p_use_uc_da)) /*DsEthRmep.ccmSeqNum0[15] -> isCsfUseUcDa*/
    {
        ccm_da[0] = (ds_eth_rmep->rmep_mac_sa_high >> 8)& 0xFF;
        ccm_da[1] = ds_eth_rmep->rmep_mac_sa_high & 0xff;
        ccm_da[2] = (ds_eth_rmep->rmep_mac_sa_low >> 24)& 0xFF;
        ccm_da[3] = (ds_eth_rmep->rmep_mac_sa_low >> 16)& 0xFF;
        ccm_da[4] = (ds_eth_rmep->rmep_mac_sa_low >> 8)& 0xFF;
        ccm_da[5] = ds_eth_rmep->rmep_mac_sa_low & 0xFF;
    }
    else
    {
        ccm_da[0] = (oam_ether_tx_ctl.cfm_mcast_addr_high >> 16) & 0xFF;
        ccm_da[1] = (oam_ether_tx_ctl.cfm_mcast_addr_high >> 8) & 0xFF;
        ccm_da[2] =  oam_ether_tx_ctl.cfm_mcast_addr_high  & 0xFF;
        ccm_da[3] = (oam_ether_tx_ctl.cfm_mcast_addr_low >> 13) & 0xFF;
        ccm_da[4] = (oam_ether_tx_ctl.cfm_mcast_addr_low >> 5) & 0xFF;
        ccm_da[5] = ((oam_ether_tx_ctl.cfm_mcast_addr_low  & 0x1F)<< 3)|(ds_ma->md_lvl);/*bug 637*/
    }

    if (ds_eth_mep->share_mac_en)/*bug 528, bug 644*/
    {
        ccm_sa[0] = (oam_ether_tx_ctl.tx_bridge_mac_high >> 8) & 0xFF;
        ccm_sa[1] = oam_ether_tx_ctl.tx_bridge_mac_high & 0xFF;
        ccm_sa[2] = (oam_ether_tx_ctl.tx_bridge_mac_low >> 24) & 0xFF;
        ccm_sa[3] = (oam_ether_tx_ctl.tx_bridge_mac_low >> 16) & 0xFF;
        ccm_sa[4] = (oam_ether_tx_ctl.tx_bridge_mac_low >> 8) & 0xFF;
        ccm_sa[5] = oam_ether_tx_ctl.tx_bridge_mac_low & 0xFF;
    }
    else
    {
        ccm_sa[0] = (oam_ether_tx_mac.tx_port_mac_high >> 24) & 0xFF;
        ccm_sa[1] = (oam_ether_tx_mac.tx_port_mac_high >> 16) & 0xFF;
        ccm_sa[2] = (oam_ether_tx_mac.tx_port_mac_high >> 8) & 0xFF;
        ccm_sa[3] = (oam_ether_tx_mac.tx_port_mac_high) & 0xFF;
        ccm_sa[4] = (tx_pkt_info->mac_sa_byte >> 8) & 0xFF;
        ccm_sa[5] = tx_pkt_info->mac_sa_byte & 0xFF; /*bug 480*/

    }

    ccm_vid = ds_eth_mep->mep_primary_vid;
    cos = tx_pkt_info->cos;
    ccm_type = oam_ether_tx_ctl.ccm_ether_type;
    ccm_md_level = ds_ma->md_lvl;
    ccm_version = oam_ether_tx_ctl.ccm_version;
    ccm_opcode = oam_ether_tx_ctl.ccm_opcode;
    ccm_flag = (ds_eth_mep->present_rdi << 7) | (ds_eth_mep->present_traffic << 6) | (ds_ma->ccm_interval);
    ccm_first_tlv_offset = oam_ether_tx_ctl.ccm_first_tlv_offset;
    ccm_mep_id = ds_eth_mep->mep_id;
    ccm_intf_status = tx_pkt_info->if_status;
    ccm_port_status = ds_eth_mep->port_status;

    if (ds_eth_mep->seq_num_en)
    {
        ccm_seq_num = (ds_eth_mep->ccm_seq_num2 << 26) | (ds_eth_mep->ccm_seq_num1 << 20) | ds_eth_mep->ccm_seq_num0;
    }
    else
    {
        ccm_seq_num = 0;
    }

    /*GEN_MAID*/
    sal_memcpy(ma_id, tx_pkt_info->ma_id_byte, 48);

    /*ASSEMBLE_CCM_WITH_PACKET_HEADER*/
    tx_with_if_status = ds_ma->tx_with_if_status &&
                    ((ETH_CCM_MEP == ds_eth_mep->mep_type) || (PBT_CCM_MEP == ds_eth_mep->mep_type));
    tx_with_port_status = ds_ma->tx_with_port_status &&
                    ((ETH_CCM_MEP == ds_eth_mep->mep_type) || (PBT_CCM_MEP == ds_eth_mep->mep_type));
    tx_with_send_id = ds_ma->tx_with_send_id &&
                    ((ETH_CCM_MEP == ds_eth_mep->mep_type) || (PBT_CCM_MEP == ds_eth_mep->mep_type));

    switch (ds_eth_mep->tpid_type)
    {
        case 0:
            tpid = oam_ether_tx_ctl.tpid0;
            break;

        case 1:
            tpid = oam_ether_tx_ctl.tpid1;
            break;

        case 2:
            tpid = oam_ether_tx_ctl.tpid2;
            break;

        case 3:
            tpid = oam_ether_tx_ctl.tpid3;
            break;

        default:
            break;
    }
    tx_untagged_oam = ds_ma->tx_untagged_oam;
    //pkt_byte_offset = GREAT_BELT_HEADER_LEN;/*reserve 32 bytes for bridge header*/

    if (ds_eth_mep->mep_type != ACH_Y1731_MEP)
    {
        if (!tx_untagged_oam)
        {
            sal_memmove(pkt + pkt_byte_offset, ccm_da, 6);
            sal_memmove(pkt + pkt_byte_offset + 6, ccm_sa, 6);
            pkt[12 + pkt_byte_offset] = (tpid >> 8) & 0xFF;
            pkt[13 + pkt_byte_offset] = tpid & 0xFF;
            pkt[14 + pkt_byte_offset] = ((cos << 5) & 0xE0)|((ccm_vid >> 8) & 0xF);
            pkt[15 + pkt_byte_offset] = ccm_vid & 0xFF;
            pkt[16 + pkt_byte_offset] = (ccm_type >> 8) & 0xFF;
            pkt[17 + pkt_byte_offset] = ccm_type & 0xFF;
            pkt_byte_offset += 18;
        }
        else
        {
            sal_memmove(pkt + pkt_byte_offset, ccm_da, 6);
            sal_memmove(pkt + pkt_byte_offset + 6, ccm_sa, 6);
            pkt[12 + pkt_byte_offset] = (ccm_type >> 8) & 0xFF;
            pkt[13 + pkt_byte_offset] = ccm_type & 0xFF;
            pkt_byte_offset += 14;
        }
    }
    else/*MPLS-TP based Y1731, Add Ach Header*/
    {
        if (!tx_untagged_oam)
        {
            sbit = !ds_ma->tx_with_if_status; /*share with entropy*/
            pkt[pkt_byte_offset] = (oam_parser_ether_ctl.mpls_tp_oam_alert_label >> 12) & 0xFF;
            pkt[pkt_byte_offset + 1] = (oam_parser_ether_ctl.mpls_tp_oam_alert_label >> 4) & 0xFF;
            pkt[pkt_byte_offset + 2] = ((oam_parser_ether_ctl.mpls_tp_oam_alert_label << 4) & 0xFF)|(cos<<1)|sbit;
            pkt[pkt_byte_offset + 3] =  1;
            pkt_byte_offset += 4;
            cm_packet_header.ip_sa_u.share2.gal_exist = TRUE;
        }

       /* ds_eth_rmep->rmep_mac_sa_low
          {rmepMacSa[31:0]} in Eth OAM
          {12'd0,mplsTpEntropyLabel[19:0]} for mpls tp
       */
        if(ds_ma->tx_with_if_status)
        {
            mpls_tp_entropy_label = ds_eth_rmep->rmep_mac_sa_low & 0xFFFFF;

            pkt[pkt_byte_offset] = (mpls_tp_entropy_label >> 12) & 0xFF;
            pkt[pkt_byte_offset + 1] = (mpls_tp_entropy_label >> 4) & 0xFF;
            pkt[pkt_byte_offset + 2] = ((mpls_tp_entropy_label << 4) & 0xFF)|1;
            pkt[pkt_byte_offset + 3] =  0;
            pkt_byte_offset += 4;
            cm_packet_header.ip_sa_u.share2.entropy_label_exist = TRUE;
        }

        pkt[pkt_byte_offset] = (oam_ether_tx_ctl.ach_header_l >> 8) & 0xFF;
        pkt[pkt_byte_offset + 1] = oam_ether_tx_ctl.ach_header_l & 0xFF;
        pkt[pkt_byte_offset + 2] = (oam_ether_tx_ctl.ach_y1731_chan_type >> 8) & 0xFF;
        pkt[pkt_byte_offset + 3] = oam_ether_tx_ctl.ach_y1731_chan_type & 0xFF;
        pkt_byte_offset += 4;
    }

    if (tx_pkt_info->is_tx_csf) /*TX CSF*/
    {
        csf_type = (ds_eth_rmep->ccm_seq_num0>>3)&0x7; /*CSF Type*/
        csf_flag = csf_type << 3 | ds_ma->ccm_interval;
        pkt[pkt_byte_offset] = (ccm_md_level << 5) | ccm_version;
        pkt[pkt_byte_offset + 1] = 52;
        pkt[pkt_byte_offset + 2] = csf_flag;
        pkt[pkt_byte_offset + 3] = 0;
        pkt[pkt_byte_offset + 4] = 0;
        pkt_byte_offset += 5;
        /*32 is pkt hdr length, 4 is crc, so normal ccm length is 108 + 16 + 1 - 32 + 4 = 97*/
        real_pkt_len = pkt_byte_offset +4;
    }
    else
    {
        pkt[pkt_byte_offset] = (ccm_md_level << 5) | ccm_version;
        pkt[pkt_byte_offset + 1] = ccm_opcode;
        pkt[pkt_byte_offset + 2] = ccm_flag;
        pkt[pkt_byte_offset + 3] = ccm_first_tlv_offset;
        pkt[pkt_byte_offset + 4] = (ccm_seq_num >> 24) & 0xFF;
        pkt[pkt_byte_offset + 5] = (ccm_seq_num >> 16) & 0xFF;
        pkt[pkt_byte_offset + 6] = (ccm_seq_num >> 8) & 0xFF;
        pkt[pkt_byte_offset + 7] = ccm_seq_num & 0xFF;
        pkt[pkt_byte_offset + 8] = (ccm_mep_id >> 8) & 0xFF;
        pkt[pkt_byte_offset + 9] = ccm_mep_id  & 0xFF;

        sal_memcpy(pkt + pkt_byte_offset + 10, ma_id, 48);/*bytes 10-57*/

        /*16 bytes reserved for itu pkt counter*/
        sal_memset(pkt + pkt_byte_offset + 58 , 0, 16);/*bytes 58-73*/

        if (tx_with_port_status)
        {
            pkt[pkt_byte_offset + 74] = 2;
            pkt[pkt_byte_offset + 75] = 0;
            pkt[pkt_byte_offset + 76] = 1;
            pkt[pkt_byte_offset + 77] = ccm_port_status;

            pkt_byte_offset += 4;
        }
        if (tx_with_if_status)
        {
            pkt[pkt_byte_offset + 74] = 4;
            pkt[pkt_byte_offset + 75] = 0;
            pkt[pkt_byte_offset + 76] = 1;
            pkt[pkt_byte_offset + 77] = ccm_intf_status;
            pkt_byte_offset += 4;
        }
        if (tx_with_send_id)
        {
            sal_memset(&oam_ether_send_id, 0, sizeof(oam_ether_send_id));
            cmd = DRV_IOR(OamEtherSendId_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_ether_send_id));
            send_id_length = oam_ether_send_id.send_id_length;

            pkt[pkt_byte_offset + 74] = 1;
            pkt[pkt_byte_offset + 75] = 0;
            pkt[pkt_byte_offset + 76] = send_id_length & 0xF;

            sendid[0] = (oam_ether_send_id.send_id_byte0to2 >> 16) & 0xFF;
            sendid[1] = (oam_ether_send_id.send_id_byte0to2 >>  8) & 0xFF;
            sendid[2] = oam_ether_send_id.send_id_byte0to2 & 0xFF;
            sendid[3] = (oam_ether_send_id.send_id_byte3to6 >> 24) & 0xFF;
            sendid[4] = (oam_ether_send_id.send_id_byte3to6 >> 16) & 0xFF;
            sendid[5] = (oam_ether_send_id.send_id_byte3to6 >>  8) & 0xFF;
            sendid[6] = oam_ether_send_id.send_id_byte3to6 & 0xFF;
            sendid[7] = (oam_ether_send_id.send_id_byte7to10 >> 24) & 0xFF;
            sendid[8] = (oam_ether_send_id.send_id_byte7to10 >> 16) & 0xFF;
            sendid[9] = (oam_ether_send_id.send_id_byte7to10 >>  8) & 0xFF;
            sendid[10] = oam_ether_send_id.send_id_byte7to10  & 0xFF;
            sendid[11] = (oam_ether_send_id.send_id_byte11to14 >> 24) & 0xFF;
            sendid[12] = (oam_ether_send_id.send_id_byte11to14 >> 16) & 0xFF;
            sendid[13] = (oam_ether_send_id.send_id_byte11to14 >>  8) & 0xFF;
            sendid[14] = oam_ether_send_id.send_id_byte11to14 & 0xFF;
            sal_memmove(pkt + pkt_byte_offset + 77, sendid, oam_ether_send_id.send_id_length);
            pkt_byte_offset += (send_id_length + 3);
        }

        pkt[pkt_byte_offset + 74] = 0;
        /*32 is pkt hdr length, 4 is crc, so normal ccm length is 108 + 16 + 1 - 32 + 4 = 97*/
        /*no pkt hdr in v5_6*/
        real_pkt_len = 78 + 1 + pkt_byte_offset;
    }

    /*no pkt hdr in v5_6*/
    tx_pkt_info->packet_length = real_pkt_len;

    cm_gen_greatbelt_packet_header(packet_header, &cm_packet_header, FALSE);

    DRV_IF_ERROR_RETURN(swap32((uint32 *)packet_header, (GREAT_BELT_HEADER_LEN) / 4, HOST_TO_NETWORK));
    header_crc = calculate_crc4((uint8 *)packet_header, GREAT_BELT_HEADER_LEN, 0);

    ((uint8*)packet_header)[GREATBELT_HDR_CRC_OFFSET] &= 0xF0;
    ((uint8*)packet_header)[GREATBELT_HDR_CRC_OFFSET] |= (header_crc & 0x0F);

    /*no pkt hdr in v5_6*/
    ctcutil_crc32(0xFFFFFFFF, pkt,(tx_pkt_info->packet_length - 4), &packet_crc);

    swap32(&packet_crc, 1, HOST_TO_NETWORK);

    pkt[tx_pkt_info->packet_length - 4] = (packet_crc >> 24) & 0xFF;
    pkt[tx_pkt_info->packet_length - 3] = (packet_crc >> 16) & 0xFF;
    pkt[tx_pkt_info->packet_length - 2] = (packet_crc >> 8) & 0xFF;
    pkt[tx_pkt_info->packet_length - 1] = packet_crc  & 0xFF;


    return DRV_E_NONE;

}

/****************************************************************************
 * Name:       _cm_oam_gen_bfd_pdu
 * Purpose:    generate bfd pdu
 * Parameters:
 * Input:      tx_pkt_info -- pointer to buffer which save information
 *                       used in module generate ccm.
 * Output:     tx_pkt_info -- pointer to buffer which save information
 *                       used in module generate ccm.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_gen_bfd_pdu(oam_tx_pkt_info_t* tx_pkt_info)
{
    uint8 chip_id = tx_pkt_info->chip_id;
    ds_ma_t* ds_ma = (ds_ma_t*)tx_pkt_info->p_ds_ma;
    ds_bfd_mep_t* ds_bfd_mep = (ds_bfd_mep_t*)tx_pkt_info->p_ds_mep;
    ds_bfd_rmep_t* ds_bfd_rmep = (ds_bfd_rmep_t*)tx_pkt_info->p_ds_rmep;
    ms_packet_header_t* packet_header = (ms_packet_header_t *)tx_pkt_info->p_packet_header;
    cm_greatbelt_packet_header_t cm_packet_header;

    uint8* pkt = tx_pkt_info->pkt;

    oam_ether_tx_ctl_t oam_ether_tx_ctl;
    oam_parser_ether_ctl_t oam_parser_ether_ctl;

    uint8 pkt_byte_offset = 0;
    uint8 tx_untagged_oam = FALSE;
    uint8 cos = 0;
    uint32 cmd = 0;
    uint8 header_crc = 0;
    uint32 packet_crc = 0;
    uint32 check_sum  = 0;
    uint32 desired_min_tx_interval = 0;
    uint32 required_min_rx_interval = 0;
    uint16 dest_port = 0;
    uint8 ach_chan_type = 0;
    uint8 sbit = 0;
    uint32 mpls_tp_entropy_label = 0;
    uint16 ipv4_total_len = 0;
    uint8 ma_id[48] = {0};

    uint8 tx_cc_mode = 0;
    uint8 detect_mult = 0;
    uint8 offset = 0;
    uint8 csf_type = 0;
    uint8 csf_flag = 0;
    uint8 ccm_interval = 0;
    uint32 real_pkt_len = 0;


    sal_memset(&cm_packet_header, 0, sizeof(cm_greatbelt_packet_header_t));
    cm_gen_greatbelt_packet_header(packet_header, &cm_packet_header, TRUE);

    sal_memset(&oam_ether_tx_ctl, 0, sizeof(oam_ether_tx_ctl_t));
    cmd = DRV_IOR(OamEtherTxCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_ether_tx_ctl));

    sal_memset(&oam_parser_ether_ctl, 0, sizeof(oam_parser_ether_ctl));
    cmd = DRV_IOR(OamParserEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_parser_ether_ctl));

    /*ASSEMBLE_BFD_WITH_PACKET_HEADER*/
    tx_untagged_oam = ds_ma->tx_untagged_oam;
    cos = tx_pkt_info->cos;

    if (ACH_BFD_MEP == ds_bfd_mep->mep_type)/*MPLS TP based BFD*/
    {
        switch(ds_bfd_rmep->ach_chan_type)
        {
            case 1:
                if (tx_pkt_info->is_tx_cv)
                {   /*MPLS-TP BFD CV*/
                    ach_chan_type = oam_parser_ether_ctl.ach_bfd_chan_type_cv;
                }
                else if (tx_pkt_info->is_tx_csf)
                {   /*MPLS-TP CSF*/
                    ach_chan_type = oam_parser_ether_ctl.ach_chan_type_csf;
                }
                else
                {   /*MPLS-TP BFD CC*/
                    ach_chan_type = oam_parser_ether_ctl.ach_bfd_chan_type_cc;
                }
                break;
            case 3:/*ACH BFD*/
                ach_chan_type = 0x7;
                break;
            default:
                ach_chan_type = oam_parser_ether_ctl.ach_bfd_default_chan_type;
                break;
        }

        if (!tx_untagged_oam)
        {   /*tx with gal label*/
            sbit = !ds_ma->tx_with_if_status;
            pkt[pkt_byte_offset + 0] = (oam_parser_ether_ctl.mpls_tp_oam_alert_label>> 12)& 0xFF;
            pkt[pkt_byte_offset + 1] = (oam_parser_ether_ctl.mpls_tp_oam_alert_label >> 4)& 0xFF;
            pkt[pkt_byte_offset + 2] = ((oam_parser_ether_ctl.mpls_tp_oam_alert_label << 4)|(cos <<1)|sbit)& 0xFF;
            pkt[pkt_byte_offset + 3] = 1;
            pkt_byte_offset += 4;
            cm_packet_header.ip_sa_u.share2.gal_exist = TRUE;
        }

        /* ds_bfd_rmep->ip_sa
          {IPSa} in mpls ip bfd
          {10'd0,maIdLengthType[1:0], maNameIndex[13:0], ccmInterval[2:0],cvWhile[2:0], dMisConWhile[3:0],dMisCon} in mpls tp
          {12'd0,mplsTpEntropyLabel[19:0]} in MPLS BFD
        */
        if(ds_ma->tx_with_if_status)
        {   /*tx with entropy label*/
            mpls_tp_entropy_label = ds_bfd_rmep->ip_sa & 0xFFFFF;

            pkt[pkt_byte_offset + 0] = (mpls_tp_entropy_label >> 12) & 0xFF;
            pkt[pkt_byte_offset + 1] = (mpls_tp_entropy_label >> 4) & 0xFF;
            pkt[pkt_byte_offset + 2] = ((mpls_tp_entropy_label << 4) & 0xFF)|1;
            pkt[pkt_byte_offset + 3] =  0;
            pkt_byte_offset += 4;
            cm_packet_header.ip_sa_u.share2.entropy_label_exist = TRUE;
        }

        pkt[pkt_byte_offset + 0] = (oam_ether_tx_ctl.ach_header_l >> 8)& 0xFF;
        pkt[pkt_byte_offset + 1] = oam_ether_tx_ctl.ach_header_l & 0xFF;
        pkt[pkt_byte_offset + 2] = (ach_chan_type >> 8)& 0xFF;
        pkt[pkt_byte_offset + 3] = ach_chan_type & 0xFF;
        pkt_byte_offset += 4;
    }
    else
    {
        if(TRILL_BFD_MEP == ds_bfd_mep->mep_type)
        {
            /* All-Egress-RBridgeMacDa */
            pkt[pkt_byte_offset + 0] = (oam_ether_tx_ctl.egr_rb_mac_da_hi >> 8)& 0xFF;
            pkt[pkt_byte_offset + 1] = oam_ether_tx_ctl.egr_rb_mac_da_hi & 0xFF;
            pkt[pkt_byte_offset + 2] = (oam_ether_tx_ctl.egr_rb_mac_da_low >> 24)& 0xFF;
            pkt[pkt_byte_offset + 3] = (oam_ether_tx_ctl.egr_rb_mac_da_low >> 16)& 0xFF;
            pkt[pkt_byte_offset + 4] = (oam_ether_tx_ctl.egr_rb_mac_da_low >> 8)& 0xFF;
            pkt[pkt_byte_offset + 5] = oam_ether_tx_ctl.egr_rb_mac_da_low & 0xFF;

            /* Inner MacSa(6 bytes) + inner Vlan tag(4 bytes) + RBridge Channel Header (6 bytes)*/
            sal_memcpy(ma_id, tx_pkt_info->ma_id_byte, 48);

            for (offset = 6; (offset-6) < ds_ma->ma_name_len; offset++)
            {
                pkt[pkt_byte_offset + offset] = ma_id[offset-6];
            }

            pkt_byte_offset += 22; /* DsMa.maNameLen must be euqal to 16 */
        }
        else
        {
            if(ds_ma->tx_with_if_status) /*with IPv4 header, only for ip bfd over mpls*/
            {
                ipv4_total_len = 20 + 8 + 24;
                pkt[pkt_byte_offset + 0] = 0x45;
                pkt[pkt_byte_offset + 1] = 0;

                pkt[pkt_byte_offset + 2] = (ipv4_total_len << 8)&0xFF;
                pkt[pkt_byte_offset + 3] = ipv4_total_len & 0xFF;

                pkt[pkt_byte_offset + 4] = 0;  /*identification*/
                pkt[pkt_byte_offset + 5] = 0;

                pkt[pkt_byte_offset + 6] = 0;  /*frag*/
                pkt[pkt_byte_offset + 7] = 0;

                /*ECO 4886 start*/
                //pkt[pkt_byte_offset + 8] = 1;  /*ttl*/
                if((TRILL_BFD_MEP != ds_bfd_mep->mep_type) && ((oam_ether_tx_ctl.bridge_next_ptr_low & 0x1) == 0))
                {
                    pkt[pkt_byte_offset + 8] = ds_ma->mpls_ttl;  /*ttl*/
                }
                else
                {
                    pkt[pkt_byte_offset + 8] = 1;  /*ttl*/
                }
                /*ECO 4886 end*/
                pkt[pkt_byte_offset + 9] = 17; /*udp protocol*/

                pkt[pkt_byte_offset + 10] = 0; /*checksum*/
                pkt[pkt_byte_offset + 11] = 0;

                pkt[pkt_byte_offset + 12] = (ds_bfd_rmep->ip_sa>>24)&0xFF; /*ipsa*/
                pkt[pkt_byte_offset + 13] = (ds_bfd_rmep->ip_sa>>16)&0xFF;
                pkt[pkt_byte_offset + 14] = (ds_bfd_rmep->ip_sa>>8)&0xFF;
                pkt[pkt_byte_offset + 15] = (ds_bfd_rmep->ip_sa)&0xFF;

                pkt[pkt_byte_offset + 16] = 0x7F; /*ipda*/
                pkt[pkt_byte_offset + 17] = 0;
                pkt[pkt_byte_offset + 18] = 0;
                pkt[pkt_byte_offset + 19] = 1;

                check_sum = ip_chksum((uint16*)(pkt+ pkt_byte_offset), 20, 0);
                pkt[pkt_byte_offset + 10] = (check_sum>>8)&0xFF; /*checksum*/
                pkt[pkt_byte_offset + 11] = check_sum&0xFF;

                pkt_byte_offset += 20;

            }

            if(ds_ma->tx_with_send_id) /* UPD header with BFD PDU */
            {
                dest_port = ds_bfd_rmep->is_multi_hop ? oam_ether_tx_ctl.bfd_multi_hop_udp_dst_port:
                                                        oam_ether_tx_ctl.bfd_udp_dst_port;

                pkt[pkt_byte_offset + 0] = (ds_bfd_mep->bfd_srcport>>8) & 0xff;
                pkt[pkt_byte_offset + 1] = ds_bfd_mep->bfd_srcport & 0xff;
                pkt[pkt_byte_offset + 2] = (dest_port>>8) &0xff;
                pkt[pkt_byte_offset + 3] = dest_port &0xff;
                pkt[pkt_byte_offset + 4] = 0;
                pkt[pkt_byte_offset + 5] = 32;
                pkt[pkt_byte_offset + 6] = 0;
                pkt[pkt_byte_offset + 7] = 0;

                pkt_byte_offset += 8;
            }
        }
    }

    if (!tx_pkt_info->is_tx_csf)
    {
        tx_cc_mode =ds_bfd_mep->cc_tx_mode;

        if (!tx_cc_mode)
        {   /*tx mpls-tp cc use normal bfd mode*/
            desired_min_tx_interval = ds_bfd_mep->desired_min_tx_interval*1000;
            required_min_rx_interval = ds_bfd_rmep->required_min_rx_interval*1000;
            detect_mult = ds_bfd_rmep->local_defect_mult;
        }
        else
        {  /*tx mpls-tp cv and cc use y1731 mode*/
            ccm_interval = tx_pkt_info->is_tx_cv ? (ds_bfd_rmep->ip_sa>>8)&0x7 : ds_ma->ccm_interval;
            switch(ccm_interval)
            {
                case 1:
                    /*ECO 4989 start*/
                    /*desired_min_tx_interval  = 3330; //3.33ms*/
                    /*required_min_rx_interval = 9990; //9.99ms*/
                    if((0 == oam_ether_tx_ctl.bridge_nexthop_ptr_high)
                      &&(0 == oam_ether_tx_ctl.bridge_next_ptr_low))
                    {
                         desired_min_tx_interval    = 3300;     // 3.3ms
                         required_min_rx_interval   = 3300;     //3.3ms
                    }
                    else
                    {
                         desired_min_tx_interval    = 3330;     // 3.33ms
                         required_min_rx_interval   = 3330;     //3.33ms
                    }
                    break;

                case 2:
                    desired_min_tx_interval  = 10000; /*10ms*/
                    required_min_rx_interval = 10000; /*10ms*/
                    break;

                case 3:
                    desired_min_tx_interval =  100000; /*100ms*/
                    required_min_rx_interval = 100000; /*100ms*/
                    break;

                case 4:
                    desired_min_tx_interval  = 1000000; /*1s*/
                    required_min_rx_interval = 1000000; /*1s*/
                    break;

                case 5:
                    desired_min_tx_interval  = 10000000; /*10s*/
                    required_min_rx_interval = 10000000; /*10s*/
                    break;

                case 6:
                    desired_min_tx_interval  = 60000000;  /*60s*/
                    required_min_rx_interval = 60000000; /*60s*/
                    break;

                case 7:
                    desired_min_tx_interval  = 600000000;  /*600s*/
                    required_min_rx_interval = 600000000; /*600s*/
                    break;

                default:
                    desired_min_tx_interval  = 1000000; /*1s*/
                    required_min_rx_interval = 1000000; /*1s*/
                    /*ECO 4989 end*/
            }

            detect_mult = 3;
        }

        pkt[pkt_byte_offset + 0] = ((1 << 5)|ds_bfd_mep->local_diag) & 0xFF;
        pkt[pkt_byte_offset + 1] = ((ds_bfd_mep->local_stat << 6)|(ds_bfd_mep->pbit << 5)|(ds_bfd_rmep->fbit << 4))& 0xFF;
        pkt[pkt_byte_offset + 2] = detect_mult; /*detectMult*/
        pkt[pkt_byte_offset + 3] = 24; /*BFD Len = 24*/

        pkt[pkt_byte_offset + 4] = (ds_bfd_mep->local_disc>> 24) & 0xFF;  /*My Discription*/
        pkt[pkt_byte_offset + 5] = (ds_bfd_mep->local_disc >> 16) & 0xFF;
        pkt[pkt_byte_offset + 6] = (ds_bfd_mep->local_disc >> 8) & 0xFF;
        pkt[pkt_byte_offset + 7] = ds_bfd_mep->local_disc & 0xFF;

        pkt[pkt_byte_offset + 8] = (ds_bfd_rmep->remote_disc >> 24) & 0xFF; /*Your Discription*/
        pkt[pkt_byte_offset + 9] = (ds_bfd_rmep->remote_disc >> 16) & 0xFF;
        pkt[pkt_byte_offset + 10] = (ds_bfd_rmep->remote_disc >> 8) & 0xFF;
        pkt[pkt_byte_offset + 11] = ds_bfd_rmep->remote_disc & 0xFF;


        pkt[pkt_byte_offset + 12] = (desired_min_tx_interval >> 24) & 0xFF; /*Desire Min Tx Interval*/
        pkt[pkt_byte_offset + 13] = (desired_min_tx_interval >> 16) & 0xFF;
        pkt[pkt_byte_offset + 14] = (desired_min_tx_interval >> 8) & 0xFF;
        pkt[pkt_byte_offset + 15] =  desired_min_tx_interval & 0xFF;

        pkt[pkt_byte_offset + 16] = (required_min_rx_interval >> 24) & 0xFF; /*Require Min Rx Interval*/
        pkt[pkt_byte_offset + 17] = (required_min_rx_interval>> 16) & 0xFF;
        pkt[pkt_byte_offset + 18] = (required_min_rx_interval >> 8) & 0xFF;
        pkt[pkt_byte_offset + 19] = required_min_rx_interval & 0xFF;

        pkt[pkt_byte_offset + 20] = 0; /*Echo tx Interval*/
        pkt[pkt_byte_offset + 21] = 0;
        pkt[pkt_byte_offset + 22] = 0;
        pkt[pkt_byte_offset + 23] = 0;

        pkt_byte_offset += 24;

        /*TX CV*/
        if (tx_pkt_info->is_tx_cv && (ACH_BFD_MEP == ds_bfd_mep->mep_type))
        {
            /*GEN_MAID*/
            sal_memcpy(ma_id, tx_pkt_info->ma_id_byte, 48);

            for (offset = 0; offset < ds_ma->ma_name_len; offset++)
            {
                pkt[pkt_byte_offset + offset] = ma_id[offset];
            }

            pkt_byte_offset +=  ds_ma->ma_name_len;
        }
    }
    else
    {   /*TX CSF*/
        csf_type = (ds_bfd_mep->bfd_srcport>>3)&0x7; /*CSF Type*/
        csf_flag = csf_type << 3 | ds_ma->ccm_interval;

        pkt[pkt_byte_offset + 0] = 0;
        pkt[pkt_byte_offset + 1] = 0;
        pkt[pkt_byte_offset + 2] = csf_flag;
        pkt[pkt_byte_offset + 3] = 0;
        pkt[pkt_byte_offset + 4] = 0;
        pkt_byte_offset += 5;
    }

    /*no pkt hdr in v5_6*/
    real_pkt_len = pkt_byte_offset + 4;
    tx_pkt_info->packet_length = real_pkt_len;

    cm_gen_greatbelt_packet_header(packet_header, &cm_packet_header, FALSE);

    DRV_IF_ERROR_RETURN(swap32((uint32 *)packet_header, (GREAT_BELT_HEADER_LEN) / 4, HOST_TO_NETWORK));

    header_crc = calculate_crc4((uint8 *)packet_header, GREAT_BELT_HEADER_LEN, 0);

    ((uint8*)packet_header)[GREATBELT_HDR_CRC_OFFSET] &= 0xF0;
    ((uint8*)packet_header)[GREATBELT_HDR_CRC_OFFSET] |= (header_crc & 0x0F);

    /*no pkt hdr in v5_6*/
    ctcutil_crc32(0xFFFFFFFF, pkt,(tx_pkt_info->packet_length - 4), &packet_crc);
    DRV_IF_ERROR_RETURN(swap32(&packet_crc, 1, HOST_TO_NETWORK));

    pkt[tx_pkt_info->packet_length - 4] = (packet_crc >> 24) & 0xFF;
    pkt[tx_pkt_info->packet_length - 3] = (packet_crc >> 16) & 0xFF;
    pkt[tx_pkt_info->packet_length - 2] = (packet_crc >> 8) & 0xFF;
    pkt[tx_pkt_info->packet_length - 1] =  packet_crc  & 0xFF;

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       cm_oam_generate_ccm
 * Purpose:    generate ccm and tx packet
 * Parameters:
 * Input:      gen_ccm_pkt_info -- pointer to buffer which save information
 *                       used to generate ccm.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_oam_generate_ccm(oam_generate_ccm_pkt_info_t * gen_ccm_pkt_info)
{
    out_pkt_t oam_out_pkt;
    ms_packet_header_t packet_header;
    oam_tx_pkt_info_t tx_pkt_info;

    uint8 chip_id = gen_ccm_pkt_info->chip_id;
    uint8* pkt = NULL;
    uint8* exception = NULL;
    int32 ret = 0;

    sal_memset(&oam_out_pkt, 0, sizeof(out_pkt_t));
    sal_memset(&tx_pkt_info, 0, sizeof(oam_tx_pkt_info_t));

    pkt = sal_malloc(MTU);
    if (NULL == pkt)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(pkt, 0, MTU);
    oam_out_pkt.pkt = pkt;

    exception = sal_malloc(GREAT_BELT_EXCEPTION_LEN);
    if (NULL == exception)
    {
        sal_free(pkt);
        pkt = NULL;
        return DRV_E_NO_MEMORY;
    }
    sal_memset(exception, 0, GREAT_BELT_EXCEPTION_LEN);
    oam_out_pkt.exception = exception;

    tx_pkt_info.p_ds_mep = gen_ccm_pkt_info->p_ds_mep;
    tx_pkt_info.p_ds_rmep = gen_ccm_pkt_info->p_ds_rmep;
    tx_pkt_info.p_ds_ma = gen_ccm_pkt_info->p_ds_ma;
    tx_pkt_info.mep_index = gen_ccm_pkt_info->mep_index;
    tx_pkt_info.rmep_index = gen_ccm_pkt_info->rmep_index;
    tx_pkt_info.chip_id = gen_ccm_pkt_info->chip_id;
    tx_pkt_info.is_tx_csf= gen_ccm_pkt_info->is_tx_csf;
    tx_pkt_info.is_tx_cv = gen_ccm_pkt_info->is_tx_cv;

    tx_pkt_info.p_packet_header = &packet_header;
    tx_pkt_info.pkt = oam_out_pkt.pkt;

    if ((ret = _cm_oam_gen_packet_header(&tx_pkt_info)) < 0)
    {
        CMODEL_DEBUG_OUT_INFO("oam tx gen pkt hdr error!\n");
        goto error;
    }

    if (tx_pkt_info.is_eth)
    {
        if ((ret = _cm_oam_gen_eth_ccm_pdu(&tx_pkt_info)) < 0)
        {
            CMODEL_DEBUG_OUT_INFO("oam tx gen eth ccm pdu  error!\n");
            goto error;
        }
    }
     else if (tx_pkt_info.is_bfd)
    {
        if((ret = _cm_oam_gen_bfd_pdu(&tx_pkt_info))< 0)
        {
            CMODEL_DEBUG_OUT_INFO("oam tx gen bfd pdu  error!\n");
            goto error;
        }
    }

    oam_out_pkt.pkt_id = 0;
    oam_out_pkt.chip_id = chip_id;
    oam_out_pkt.chan_id = OAM_CHANID;
    oam_out_pkt.dest_queue = SIM_FWD_Q;
    oam_out_pkt.packet_length = tx_pkt_info.packet_length;
    /*no pkt hdr in v5_6*/
    oam_out_pkt.module_bus.pkt_len = tx_pkt_info.packet_length;
    sal_memcpy(oam_out_pkt.module_bus.packet_header, tx_pkt_info.p_packet_header, GREAT_BELT_HEADER_LEN);

    /* capture oam_tx pkt to oam_out_pkt.txt */
    ret = sim_oam_output_packet(oam_out_pkt.pkt, oam_out_pkt.packet_length,
                                oam_out_pkt.chip_id, oam_out_pkt.chan_id);

#if (SDK_WORK_PLATFORM == 1)
    DRV_IF_ERROR_RETURN(swap32((uint32 *)tx_pkt_info.p_packet_header, (GREAT_BELT_HEADER_LEN) / 4, NETWORK_TO_HOST));

    if (cosim_db.store_bheader)
    {
        DRV_IF_ERROR_RETURN(cosim_db.store_bheader(((void *)tx_pkt_info.p_packet_header), SIM_MODULE_OAM));
    }

    if (cosim_db.store_outpkt)
    {
        ret = cosim_db.store_outpkt(oam_out_pkt.chip_id, oam_out_pkt.chan_id,
                            oam_out_pkt.packet_length, oam_out_pkt.pkt, SIM_MODULE_OAM, 0, 0);
    }
#endif

    /* Send to fwd */
    ret = ctckal_queue_send(sim_queue[SIM_FWD_Q], (void *)&oam_out_pkt, sizeof(out_pkt_t));
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO("oam engine send pkt to fwd error! ret = %d\n", ret);

        goto error;
    }
    return DRV_E_NONE;

error:
    if (oam_out_pkt.pkt != NULL)
    {
        sal_free(oam_out_pkt.pkt);
        oam_out_pkt.pkt = NULL;
    }
    if (oam_out_pkt.exception != NULL)
    {
        sal_free(oam_out_pkt.exception);
        oam_out_pkt.exception = NULL;
    }

    return ret;

}

