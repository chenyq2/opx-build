
/****************************************************************************
 * cm_oam_header_adjust.c : Provides OAM header adjust function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       jiangsz.
 * Date:         2010-11-08.
 * Reason:       First Create.
 *
 * Revision:     V2.0.
 * Author:       mengzw.
 * Date:         2011-04-08.
 * Reason:       Sync for spec V2.0.

  * Revision:     V4.28.
 * Author:       zhaomc.
 * Date:         2011-09-28.
 * Reason:       Sync for spec V4.28.
 ****************************************************************************/
/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/

uint32 hard_error = 0;

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/

/****************************************************************************
 * Name:       cm_oam_header_adjust_handle
 * Purpose:    handle OAM header adjust,get the information from packet header.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_oam_header_adjust_handle(oam_in_pkt_t* in_pkt)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t *)in_pkt->pkt_info;
    greatbelt_packet_header_t cm_packet_header;
    ms_packet_header_t pkt_hdr;

    oam_header_adjust_ctl_t oam_header_adjust_ctl;

    oam_parser_info_t parser_info;

    uint32 cmd              = 0;
    uint8 chip_id           = 0;
    uint8 svlan_tpid_index  = 0;
    uint8 pbb_src_port_type = 0;



    /* RETRIEVE_PACKET_HEADER_FIELDS */
    sal_memcpy(pkt_info->bheader, in_pkt->module_bus.packet_header, sizeof(pkt_hdr));
    DRV_IF_ERROR_RETURN(swap32((uint32*)(pkt_info->bheader), GREAT_BELT_HEADER_LEN / 4, NETWORK_TO_HOST));

    sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));
    cm_gen_greatbelt_packet_header(pkt_info->bheader, &cm_packet_header, TRUE);

    chip_id =  in_pkt->chip_id;

    sal_memset(&oam_header_adjust_ctl, 0, sizeof(oam_header_adjust_ctl));
    cmd = DRV_IOR(OamHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_header_adjust_ctl));

    pkt_info->packet_offset   = cm_packet_header.packet_offset;

    if (cm_packet_header.from_fabric)
    {
        sal_memmove(in_pkt->pkt, in_pkt->pkt + GREAT_BELT_HEADER_LEN, in_pkt->module_bus.pkt_len - GREAT_BELT_HEADER_LEN);
    }
    pkt_info->operation_type = cm_packet_header.operation_type;

    pkt_info->rx_oam_type   = cm_packet_header.ip_sa_u.share2.oam_type;                         /*oamType*/
    pkt_info->mip_en        = cm_packet_header.ip_sa_u.share2.mip_en_or_cw_added;               /*mipEn*/
    pkt_info->link_oam      = cm_packet_header.ip_sa_u.share2.link_oam;                         /*isLinkOam*/
                                 
    /*rx_fcb for ccm, rx_fcf for LMM, Value of the local counter RxFCl at the time of reception of the last CCM frame from the peer MEP*/
    if (cm_packet_header.from_fabric)
    {
        pkt_info->packet_length = in_pkt->module_bus.pkt_len - GREAT_BELT_HEADER_LEN; /* packet length[13:0] from BSR bus */
    }
    else
    {
        pkt_info->packet_length = in_pkt->module_bus.pkt_len; /* packet length[13:0] from BSR bus */
    }
    pkt_info->is_up         = cm_packet_header.source_port_isolate_id_u.share2.is_up
                                && ((OAM_ETHER == pkt_info->rx_oam_type)||(OAM_PBB_BV == pkt_info->rx_oam_type));

    pkt_info->lm_received_packet = cm_packet_header.pbb_src_port_type_u.share2.lm_received_packet;

    pkt_info->mep_index     = cm_packet_header.ip_sa_u.share2.mep_index; /*mepIndex[13:0]*/
    /* PacketInfo.globalSrcPort[13:0]
       = PacketInfo.isUp ? {svlanTpidIndex[1:0], PacketHeader.destId[10:8], 1'b0, PacketHeader.destId[7:0]}
                           : PacketHeader.sourcePort[13:0] */
    if (pkt_info->is_up)
    {
        pkt_info->global_src_port = (cm_packet_header.ip_sa_u.share3.gal_exist<<13)
            | (cm_packet_header.ip_sa_u.share3.entropy_label_exist<<12)
            | (((cm_packet_header.dest_id>>8)&0x7)<<9)    /* destId[10:8] */
            | (cm_packet_header.dest_id&0xFF);             /* destId[7:0] */
    }
    else
    {
        pkt_info->global_src_port = (cm_packet_header.source_port & 0x3FFF);
    }

    pkt_info->ingress_src_port  = cm_packet_header.source_port & 0x3FFF;  /*for reply LBM/LMM*/
    pkt_info->local_phy_port    = cm_packet_header.ip_sa_u.share2.local_phy_port;  /*localPhyPort[8:0], up/down mep*/

    svlan_tpid_index            = cm_packet_header.svlan_tpid_index_u.svlan_tpid_index;

    /* ===== bug 4621 ECO begine ==== */
    //pbb_src_port_type           = cm_packet_header.pbb_src_port_type_u.pbb_src_port_type;     /*bug 919*/
    pbb_src_port_type = 0;
    /* ===== bug 4621 ECO end ==== */

    pkt_info->relay_all_to_cpu  = oam_header_adjust_ctl.relay_all_to_cpu;

    pkt_info->by_pass_all       = pkt_info->relay_all_to_cpu
                                    || IS_BIT_SET(oam_header_adjust_ctl.oam_pdu_bypass_oam_engine, pkt_info->rx_oam_type)
                                    || (7 != pkt_info->operation_type) /* 7 == OP_TYPE_OAM*/
                                    || (OAM_PBB_BSI == pkt_info->rx_oam_type)
                                    || (OAM_NONE == pkt_info->rx_oam_type);

    pkt_info->by_pass_all  |= hard_error || in_pkt->module_bus.dest_id_discard;
    pkt_info->discard = hard_error || in_pkt->module_bus.dest_id_discard;

    if (OAM_ACH == pkt_info->rx_oam_type)
    {
        if(cm_packet_header.ip_sa_u.share2.gal_exist
                && cm_packet_header.ip_sa_u.share2.entropy_label_exist)
        {
            pkt_info->label_num = 2;
        }
        else if(cm_packet_header.ip_sa_u.share2.gal_exist
               || cm_packet_header.ip_sa_u.share2.entropy_label_exist)
        {
            pkt_info->label_num = 1;
        }
        else
        {
            pkt_info->label_num = 0;
        }
    }


    /* PACKET_ADJUST */
    in_pkt->packet_length = pkt_info->packet_length;

    sal_memset(&parser_info, 0, sizeof(parser_info));

    parser_info.packet_length = pkt_info->packet_length;
    parser_info.svlan_tpid_index = svlan_tpid_index;
    parser_info.pbb_src_port_type = pbb_src_port_type;
    parser_info.by_pass_all = pkt_info->by_pass_all;
    parser_info.rx_oam_type = pkt_info->rx_oam_type;
    parser_info.packet_offset = pkt_info->packet_offset;

    DRV_IF_ERROR_RETURN(cm_oam_packet_parser_handle(in_pkt,&parser_info));

    return DRV_E_NONE;
}


