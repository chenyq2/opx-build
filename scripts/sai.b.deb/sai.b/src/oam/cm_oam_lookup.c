/****************************************************************************
 * cm_oam_lookup.c : performe oam lookup process
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz
 * Date:         2010-11-10.
 * Reason:       First Create.
 *
 * Revision:     V2.0.
 * Author:       mengzw.
 * Date:         2011-04-08.
 * Reason:       Sync for spec V2.0.
 *
 * Revision:     V4.28.
 * Author:       zhaomc.
 * Date:         2011-09-28.
 * Reason:       Sync for spec V4.28.
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"


/****************************************************************************
 * Name:       _cm_oam_lookup_get_rmep_index
 * Purpose:    get rmepIndex from hash result or register result.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
uint32
cm_oam_lookup_get_rmep_index(oam_in_pkt_t* in_pkt)
{

    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    lookup_result_t userid_hash_lookup_result;
    oam_info_t oam_info;

    userid_key_t oam_hash_key;
    userid_key_type_t userid_key_type = USERID_KEY_TYPE_DISABLE;

    uint32 rmep_index = 0;

    /*HASH*/
    sal_memset(&oam_info, 0, sizeof(oam_info_t));
    sal_memset(&oam_hash_key, 0, sizeof(userid_key_t));

    sal_memset(&userid_hash_lookup_result, 0, sizeof(userid_hash_lookup_result));

    oam_hash_key.key.ether_rmep_oam.mep_index = pkt_info->mep_index;
    oam_hash_key.key.ether_rmep_oam.rmep_id   = parser_result->rmep_id;
    userid_key_type = USERID_KEY_TYPE_ETHER_RMEP;

    userid_hash_lookup_result.extra = &oam_info;

    DRV_IF_ERROR_RETURN(cm_com_userid_hash_lookup_request(in_pkt->chip_id, pkt_info->local_phy_port, &oam_hash_key,
                        userid_key_type, USERID_DIRECTION_OTHER, &userid_hash_lookup_result));

    if (userid_hash_lookup_result.valid)
    {
        rmep_index = userid_hash_lookup_result.ad_index;
    }

    return rmep_index;
}

/****************************************************************************
 * Name:       cm_oam_lookup_handle
 * Purpose:    handle OAM lookup.
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                     header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32 cm_oam_pdu_check(oam_in_pkt_t* in_pkt)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8  chip_id = in_pkt->chip_id;
    uint32 cmd = 0;
    uint8  is_big_ccm_interval = FALSE;
    uint8  is_big_bfd_interval = FALSE;

    oam_rx_proc_ether_ctl_t oam_rx_proc_ether_ctl;

    /*PDU_CHECK*/
    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl));
    cmd = DRV_IOR(OamRxProcEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_rx_proc_ether_ctl));

    pkt_info->is_slow_oam_type = (ETH_OTHER == parser_result->oam_type )
      || (MPLS_OAM == parser_result->oam_type) || (MPLS_OTHER == parser_result->oam_type)
      || (MCC == parser_result->oam_type) || (SCC == parser_result->oam_type)
      || ((MPLSTP_LBM == parser_result->oam_type) && parser_result->mpls_lbm_pdu_invalid);

    is_big_ccm_interval = (parser_result->ccm_interval > oam_rx_proc_ether_ctl.min_interval_to_cpu)
      &&(ETHER_CCM == parser_result->oam_type);
    is_big_bfd_interval = ((parser_result->ma_id.bfd.desired_min_tx_interval > oam_rx_proc_ether_ctl.max_bfd_interval )
      ||(parser_result->ma_id.bfd.required_min_rx_interval > oam_rx_proc_ether_ctl.max_bfd_interval))
      &&(parser_result->oam_type == BFD_OAM);

    parser_result->bfd_oam_pdu_invalid |= (is_big_bfd_interval && !oam_rx_proc_ether_ctl.big_bfd_interval_to_cpu);

    if (parser_result->oam_pdu_invalid || (OAM_TYPE_NONE == parser_result->oam_type ))
    {
        pkt_info->by_pass_all = TRUE;
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_0_OAM_PDU_INVALID);
    }
    else if(parser_result->bfd_oam_pdu_invalid)
    {
        pkt_info->by_pass_all = TRUE;
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_11_BFD_MPLS_DM_DLM_OAM_PDU_INVALID);
    }
    else if (is_big_ccm_interval || is_big_bfd_interval) /*Big ccm interval to cpu*/
    {
        pkt_info->by_pass_all = TRUE;
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_12_BIG_INTERVAL_OR_SW_MEP_TO_CPU);
    }
    else if (pkt_info->is_slow_oam_type) /*slow oam pdu to cpu*/
    {
        if (MPLSTP_LBM == parser_result->oam_type)
        {
            pkt_info->by_pass_all = TRUE;
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_26_LBM_MAC_DA_MEP_ID_CHECK_FAIL);
        }
        else if(MCC == parser_result->oam_type)
        {
            pkt_info->by_pass_all = TRUE;
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_22_MCC_PDU_TO_CPU);
        }
        else if(SCC == parser_result->oam_type)
        {
            pkt_info->by_pass_all = TRUE;
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_31_SCC_PDU_TO_CPU);
        }
        else
        {
            pkt_info->by_pass_all = TRUE;
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_9_SLOW_OAM_PDU_TO_CPU);
        }
    }

    if (0x1FFF == pkt_info->mep_index)
    {
        if (BFD_OAM == parser_result->oam_type)
        {
            if (0 == parser_result->ma_id.bfd.your_disc)
            {
                if((BFD_STATE_DOWN == parser_result->ma_id.bfd.stat)
                    ||(BFD_STATE_ADMIN_DOWN == parser_result->ma_id.bfd.stat))
                {
                    pkt_info->by_pass_all = TRUE;
                    SET_BIT(pkt_info->exception, OAM_EXCEPTION_28_LEARNING_BFD_TO_CPU); /*first bfd packet,send to CPU*/
                }
            }
            else
            {
                pkt_info->by_pass_all = TRUE;
                SET_BIT(pkt_info->exception, OAM_EXCEPTION_12_BIG_INTERVAL_OR_SW_MEP_TO_CPU); /*mep cfg in sw*/
            }
        }
        else
        {
            pkt_info->by_pass_all = TRUE;
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_12_BIG_INTERVAL_OR_SW_MEP_TO_CPU); /*mep cfg in sw*/
        }
    }
    return DRV_E_NONE;
}


