/****************************************************************************
 * cm_oam_error_cache.c : receive the defect information and push defect
 *                             message to error cache
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Revision:     V1.0.
 * Author:       jiangsz.
 * Date:         2010-11-17.
 * Reason:       First Create.
 *
 * Revision:     V2.0.
 * Author:       mengzw.
 * Date:         2011-04-08.
 * Reason:       Sync for spec V2.0.
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

#define DRV_MAX_ERROR_CACHE_INDEX 16

/****************************************************************************
 *
 * Global and Declarations
 *
****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
****************************************************************************/

/****************************************************************************
 * Name:       cm_oam_error_cache_handle
 * Purpose:    push defect message to error cache and generate normal interrupt
 *             while Cache reaches threshold.
 * Parameters:
 * Input:      oam_error_pkt_info -- pointer to buffer which save information
 *                       used in error cache.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_oam_error_cache_handle(oam_error_cache_pkt_info_t* oam_error_pkt_info)
{
    oam_pkt_info_t* pkt_info = NULL;
    oam_parser_result_t* parser_result = NULL;
    oam_error_defect_ctl_t oam_error_defect_ctl;
    ds_oam_defect_status_t ds_oam_defect_status;
    uint8 chip_id = oam_error_pkt_info->chip_id;

    uint32 cmd = 0;
    uint16 mp_idx = 0;
    uint16 mp_idx2 = 0;

    uint8 is_rmep_valid = FALSE;
    uint8 defect_type = 0;
    uint8 defect_sub_type = 0;
    uint16 mep_index =0;
    uint16 rmep_index = 0;

    uint8 defect_idx  = 0;
    uint8 defect_report_en  = 0;

    /*PREPARATION*/
    if(oam_error_pkt_info->update_info_valid)
    {
        is_rmep_valid   = oam_error_pkt_info->is_rmep_valid;
        defect_type     = oam_error_pkt_info->defect_type;
        defect_sub_type = oam_error_pkt_info->defect_sub_type;
        mep_index       = oam_error_pkt_info->mep_index;
        rmep_index      = oam_error_pkt_info->rmep_index;
    }

    if(oam_error_pkt_info->packet_info_valid)
    {
        pkt_info = (oam_pkt_info_t*)oam_error_pkt_info->pkt_info;
        parser_result = (oam_parser_result_t*)oam_error_pkt_info->parser_result;

        defect_type       = pkt_info->defect_type;
        defect_sub_type   = pkt_info->defect_sub_type;
        mep_index         = pkt_info->mep_index;
        rmep_index        = pkt_info->rmep_index;
        if(((defect_type == 5) && (defect_sub_type == 1)) || ((defect_type == 4) && (defect_sub_type == 0)))
        {
            is_rmep_valid = FALSE;
        }
        else
        {
            is_rmep_valid = TRUE;
        }
    }

    sal_memset(&oam_error_defect_ctl, 0, sizeof(oam_error_defect_ctl));
    cmd = DRV_IOR(OamErrorDefectCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_error_defect_ctl));

    defect_idx = (defect_type <<3) | defect_sub_type;

    if (defect_idx < 32)
    {
        defect_report_en = IS_BIT_SET(oam_error_defect_ctl.report_defect_en0, defect_idx);
    }
    else
    {
        defect_report_en = IS_BIT_SET(oam_error_defect_ctl.report_defect_en1, defect_idx - 32);
    }

    if(defect_report_en)
    {

        if(is_rmep_valid)
        {
            mp_idx = rmep_index;
        }
        else
        {
            mp_idx = mep_index;
        }
        mp_idx2 = mp_idx >>5;

        sal_memset(&ds_oam_defect_status, 0, sizeof(ds_oam_defect_status));
        cmd = DRV_IOR(DsOamDefectStatus_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mp_idx2, cmd, &ds_oam_defect_status));

        ds_oam_defect_status.defect_status |= 1<<(mp_idx &0x1f);
        cmd = DRV_IOW(DsOamDefectStatus_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mp_idx2, cmd, &ds_oam_defect_status));

#if (SDK_WORK_PLATFORM == 1)
        if (cosim_db.store_table)
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DsOamDefectStatus_t, mp_idx2,
                                        (uint32 *)&ds_oam_defect_status, TRUE));
        }
#endif
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       cm_oam_scan_defect_timer
 * Purpose:    oam receive process
 * Parameters:
 * Input:      scan_times -- how many scan loops for min -- max ptr
 * Output:     None
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_oam_scan_defect_timer(uint32 chip_id, uint32 scan_times)
{
    oam_error_defect_ctl_t oam_error_defect_ctl;
    ds_oam_defect_status_t ds_oam_defect_status;
    oam_defect_cache_t oam_defect_cache;
    uint32 scan_time = 0;
    uint32 scan_count = 0;
    uint16 scan_ptr = 0;
    uint32 cmd = 0;
    uint8 cache_entry_match = FALSE;
    uint8 error_defect_index = 0;
    uint8 error_cache_full = FALSE;
    uint8 cache_entry_cnt = 0;
    uint8 normal_defect_interrupt = FALSE;
    uint32 i = 0;

    sal_memset(&oam_error_defect_ctl, 0, sizeof(oam_error_defect_ctl));
    cmd = DRV_IOR(OamErrorDefectCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_error_defect_ctl));

    while((scan_time<scan_times) && oam_error_defect_ctl.scan_en)
    {
        cache_entry_cnt = 0;
        scan_ptr = oam_error_defect_ctl.min_ptr;
        scan_count = 0;

        do
        {/*SCAN_DEFECT_PROC*/
            if(scan_count == oam_error_defect_ctl.scan_defect_interval)
            {
                sal_memset(&ds_oam_defect_status, 0, sizeof(ds_oam_defect_status));
                cmd = DRV_IOR(DsOamDefectStatus_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, scan_ptr, cmd, &ds_oam_defect_status));
                /* DsOamDefectStatus.DefectStatus[31:0] clear 0 by software layer*/
                if(ds_oam_defect_status.defect_status != 0)
                {
                    /*find scanPtr in OamDefectCache*/
                    cache_entry_match = FALSE;
                    for(error_defect_index=0; error_defect_index<DRV_MAX_ERROR_CACHE_INDEX; error_defect_index++)
                    {
                        sal_memset(&oam_defect_cache, 0, sizeof(oam_defect_cache));
                        cmd = DRV_IOR(OamDefectCache_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, error_defect_index, cmd, &oam_defect_cache));

                        if((oam_defect_cache.scan_ptr == scan_ptr)
                            && (IS_BIT_SET(oam_error_defect_ctl.cache_entry_valid, error_defect_index)))
                        {
                            cache_entry_match = TRUE;
                            break;
                        }
                    }

                    error_cache_full = (oam_error_defect_ctl.cache_entry_valid == 0xffff);

                    if(!cache_entry_match && !error_cache_full)
                    {
                        /* 1. find the first valid entry index (OamErrorDefectCtl.cacheEntryValid[15:0])*/
                        for (error_defect_index = 0; error_defect_index < DRV_MAX_ERROR_CACHE_INDEX; error_defect_index++)
                        {
                            if(!(IS_BIT_SET(oam_error_defect_ctl.cache_entry_valid, error_defect_index)))
                            {
                                break;
                            }
                        }
                        /* 2. add a new entry to OamDefectCache*/
                        if(error_defect_index<DRV_MAX_ERROR_CACHE_INDEX)
                        {
                            sal_memset(&oam_defect_cache, 0, sizeof(oam_defect_cache));
                            oam_defect_cache.scan_ptr = scan_ptr;
                            cmd = DRV_IOW(OamDefectCache_t, DRV_ENTRY_FLAG);
                            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, error_defect_index, cmd, &oam_defect_cache));
#if (SDK_WORK_PLATFORM == 1)
                            if (cosim_db.store_table)
                            {
                                DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, OamDefectCache_t, error_defect_index,
                                                            (uint32 *)&oam_defect_cache, TRUE));
                            }
#endif

                        }

                        /* 3. set the corresponding bit to 1 (OamErrorDefectCtl.cacheEntryValid[15:0]) */
                        SET_BIT(oam_error_defect_ctl.cache_entry_valid, error_defect_index);
                        cmd = DRV_IOW(OamErrorDefectCtl_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_error_defect_ctl));
#if (SDK_WORK_PLATFORM == 1)
                        if (cosim_db.store_table)
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, OamErrorDefectCtl_t, 0,
                                                        (uint32 *)&oam_error_defect_ctl, TRUE));
                        }
#endif
                        /* 4. cacheEntryCnt = the number of valid bit in cacheEntryValid */
                        for(i = 0;i < DRV_MAX_ERROR_CACHE_INDEX;i++)
                        {
                            if(IS_BIT_SET(oam_error_defect_ctl.cache_entry_valid, i))
                            {
                                cache_entry_cnt++;
                            }
                        }

                        normal_defect_interrupt = (cache_entry_cnt >= oam_error_defect_ctl.defect_cache_threshold);
                        if(normal_defect_interrupt)
                        {
                            /* trigger OAM defect cache interrupt */
                            DRV_IF_ERROR_RETURN(cm_com_interrupt_set(chip_id, TRUE, CM_INTR_GB_FUNC_OAM_DEFECT_CACHE, CM_INTR_ALL));
                            CMODEL_DEBUG_OUT_INFO("\n++++ normal_defect_interrupt! File:%s Line:%d Function:%s\n",
                                __FILE__, __LINE__, __FUNCTION__);
                        }
                    }
                }

                if(scan_ptr == oam_error_defect_ctl.max_ptr)
                {
                    if(oam_error_defect_ctl.stop_on_max_ptr)
                    {
                        CMODEL_DEBUG_OUT_INFO("\n++++ scan_stop_on_max_ptr! File:%s Line:%d Function:%s\n",
                            __FILE__, __LINE__, __FUNCTION__);

                        oam_error_defect_ctl.scan_en = FALSE;
                        cmd = DRV_IOW(OamErrorDefectCtl_t, DRV_ENTRY_FLAG);
                        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_error_defect_ctl));
#if (SDK_WORK_PLATFORM == 1)
                        if (cosim_db.store_table)
                        {
                            DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, OamErrorDefectCtl_t, 0,
                                                        (uint32 *)&oam_error_defect_ctl, TRUE));
                        }
#endif
                    }
                    else
                    {
                        scan_ptr = oam_error_defect_ctl.min_ptr;
                        break; /*cmodel add for control loop*/
                    }
                }
                else
                {
                    scan_ptr++;
                }

                scan_count = 0;
            }
            else
            {
                scan_count++;
            }
        } while (oam_error_defect_ctl.scan_en /*&& scan_ptr != oam_error_defect_ctl.max_ptr*/);
        /* Cmodel added to control scan_ptr loop once from min_ptr to max_ptr, asic will come to infinit loop*/

        scan_time++;
    }

    return DRV_E_NONE;
}

