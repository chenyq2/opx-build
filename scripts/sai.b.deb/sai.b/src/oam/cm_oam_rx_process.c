/****************************************************************************
 * cm_oam_rx_process.c : receive oam packet and process
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       jiangsz.
 * Date:         2010-11-16.
 * Reason:       First Create.
 *
 * Revision:     V2.0.
 * Author:       mengzw.
 * Date:         2011-04-08.
 * Reason:       Sync for spec V2.0.
 *
 * Revision:     V4.28.
 * Author:       zhaomc.
 * Date:         2011-09-28.
 * Reason:       Sync for spec V4.28.
 ****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "drv_lib.h"
#include "cm_lib.h"

#define MAX(a, b) (((a)>(b))?(a):(b))

struct oam_receive_pkt_info_s
{
    void* p_new_ds_mpls_mep;
    void* p_new_ds_mpls_rmep;
    void* p_new_ds_bfd_mep;
    void* p_new_ds_bfd_rmep;
    void* p_new_ds_eth_mep;
    void* p_new_ds_eth_rmep;
    void* p_ds_mpls_mep;
    void* p_ds_mpls_rmep;
    void* p_ds_bfd_mep;
    void* p_ds_bfd_rmep;
    void* p_ds_eth_mep;
    void* p_ds_eth_rmep;
    void* p_ds_mep;
    void* p_ds_rmep;
    void* p_ds_ma;
};
typedef struct oam_receive_pkt_info_s oam_receive_pkt_info_t;


/****************************************************************************
 * Name:       _cm_oam_receive_process_error_cache
 * Purpose:    send the defect information to error cache
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_receive_process_defect_proc(oam_in_pkt_t* in_pkt)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8 packet_info_valid = FALSE;
    oam_error_cache_pkt_info_t oam_error_pkt_info;

    pkt_info->is_defect_free = (pkt_info->defect_type == 0) && (pkt_info->defect_sub_type == 0);

    if(pkt_info->is_defect_free)
    {
        packet_info_valid = FALSE;
    }
    else
    {
        packet_info_valid = TRUE;

        sal_memset(&oam_error_pkt_info, 0, sizeof(oam_error_pkt_info));
        oam_error_pkt_info.defect_type = pkt_info->defect_type;
        oam_error_pkt_info.defect_sub_type = pkt_info->defect_sub_type;
        oam_error_pkt_info.mep_index = pkt_info->mep_index;
        oam_error_pkt_info.rmep_index = pkt_info->rmep_index;
        oam_error_pkt_info.packet_info_valid = packet_info_valid;
        oam_error_pkt_info.update_info_valid = FALSE;

        oam_error_pkt_info.pkt_info = pkt_info;
        oam_error_pkt_info.parser_result = parser_result;
        oam_error_pkt_info.chip_id = in_pkt->chip_id;

        cm_oam_error_cache_handle(&oam_error_pkt_info);
    }
    return DRV_E_NONE;

}


/****************************************************************************
 * Name:       _cm_oam_receive_process_equal_ccm
 * Purpose:    equal ccm process
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 *             rx_pkt_info -- pointer to buffer which save information
 *                       used in receive process.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_receive_process_equal_ccm(oam_in_pkt_t* in_pkt,
                                             oam_receive_pkt_info_t* rx_pkt_info)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8 chip_id = in_pkt->chip_id;
    oam_rx_proc_ether_ctl_t oam_rx_proc_ether_ctl;

    ds_eth_mep_t* ds_mep = (ds_eth_mep_t*)rx_pkt_info->p_ds_mep;
    ds_eth_mep_t* ds_eth_mep = (ds_eth_mep_t*)rx_pkt_info->p_ds_eth_mep;
    ds_eth_rmep_t* ds_eth_rmep = (ds_eth_rmep_t*)rx_pkt_info->p_ds_eth_rmep;
    ds_eth_rmep_t* new_ds_eth_rmep = (ds_eth_rmep_t*)rx_pkt_info->p_new_ds_eth_rmep;
    ds_ma_t *ds_ma = (ds_ma_t *)rx_pkt_info->p_ds_ma;
    ds_ma_name_t ds_ma_name[6];

    uint16 ma_name_index = 0;
    uint32 cmd = 0;
    uint8  ma_id_length_shift = 0;
    uint8  ma_id_byte[48] = {0};
    uint8  ma_id[48] = {0}, parserresult_ma_id[48] = {0};
    uint8  ma_id_byte_match = FALSE;
    uint8  index = 0;
    uint8  ma_id_match = FALSE;

    uint8  mep_id_mismatch = FALSE;
    uint8  ccm_interval_mismatch = FALSE;
    uint8  present_traffic_mismatch = FALSE;
    uint8  mac_sa_mismatch = FALSE;
    uint8  rdi_mismatch = FALSE;
    uint8  seq_num_match = FALSE;

    uint8 rmep_port_status_change = FALSE;
    uint8 rmep_intf_status_change = FALSE;

    uint32 ccm_seq_num = 0;
    uint8 csf_interval_fail = 0;
    uint8 csf_type      = 0;

    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl));
    cmd = DRV_IOR(OamRxProcEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_rx_proc_ether_ctl));

    if (ETH_CSF == parser_result->oam_type)
    {/* EQUAL_CSF_PROCESS */
        /*parserResult.ccmSeqNum[2:0] --> csfInterval*/
        csf_interval_fail = (parser_result->ccm_seq_num.csf.csf_flags & 0x7) != ds_ma->ccm_interval;
        if(!ds_eth_rmep->first_pkt_rx)
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_0_OAM_PDU_INVALID);
            pkt_info->by_pass_all = TRUE;
        }
        else if(oam_rx_proc_ether_ctl.eth_csf_to_cpu|| !ds_eth_rmep->is_csf_en)
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_20_CSF_TO_CPU);
            pkt_info->by_pass_all = TRUE;
        }
        else if (!ds_eth_mep->eth_oam_p2_p_mode || csf_interval_fail)
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_0_OAM_PDU_INVALID);
            pkt_info->by_pass_all = TRUE;
        }
        else
        {
            csf_type = (parser_result->ccm_seq_num.csf.csf_flags >> 3) & 0x7;

            if (csf_type == oam_rx_proc_ether_ctl.eth_csf_fdi
                || csf_type== oam_rx_proc_ether_ctl.eth_csf_rdi
                || csf_type == oam_rx_proc_ether_ctl.eth_csf_los)
            {
                pkt_info->defect_type     = 3;    /* csf detect*/
                pkt_info->defect_sub_type = 1;
            }
            else if (csf_type == oam_rx_proc_ether_ctl.eth_csf_clear)
            {
                pkt_info->defect_type     = 3;    /* csf clear*/
                pkt_info->defect_sub_type = 2;
            }
        }
    }
    else
    {/* EQUAL_CCM_PROCESS_COMPARE_MAID */
        ma_name_index = ds_ma->ma_name_index;
        sal_memset(ds_ma_name, 0, sizeof(ds_ma_name_t)*6);
        cmd = DRV_IOR(DsMaName_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index, cmd, &ds_ma_name[0]));

        ma_id_length_shift = ds_ma->ma_id_length_type;

        if(ma_id_length_shift != 0)
        {
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index + 1, cmd, &ds_ma_name[1]));
            ma_id_length_shift --;

            if(ma_id_length_shift != 0)
            {
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index + 2, cmd, &ds_ma_name[2]));
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index + 3, cmd, &ds_ma_name[3]));
                ma_id_length_shift --;

                if(ma_id_length_shift != 0)
                {
                    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index + 4, cmd, &ds_ma_name[4]));
                    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index + 5, cmd, &ds_ma_name[5]));
                }
            }
        }

        for (index = 0; index < 6; index++)
        {
            ma_id_byte[8 * index + 7] = ds_ma_name[index].ma_id_umc1 & 0xFF;
            ma_id_byte[8 * index + 6] = (ds_ma_name[index].ma_id_umc1 >> 8) & 0xFF;
            ma_id_byte[8 * index + 5] = (ds_ma_name[index].ma_id_umc1 >> 16) & 0xFF;
            ma_id_byte[8 * index + 4] = (ds_ma_name[index].ma_id_umc1 >> 24) & 0xFF;
            ma_id_byte[8 * index + 3] = ds_ma_name[index].ma_id_umc0 & 0xFF;
            ma_id_byte[8 * index + 2] = (ds_ma_name[index].ma_id_umc0 >> 8) & 0xFF;
            ma_id_byte[8 * index + 1] = (ds_ma_name[index].ma_id_umc0 >> 16) & 0xFF;
            ma_id_byte[8 * index + 0] = (ds_ma_name[index].ma_id_umc0 >> 24) & 0xFF;
        }

        for (index = 0; index < 6; index++)
        {
            uint32 parser_result_maid_field0 = 0;
            uint32 parser_result_maid_field1 = 0;
            switch (index)
            {
                case 0:
                    parser_result_maid_field0 = parser_result->ma_id.eth.ma_id_383_to352;
                    parser_result_maid_field1 = parser_result->ma_id.eth.ma_id_351_to320;
                    break;
                case 1:
                    parser_result_maid_field0 = parser_result->ma_id.eth.ma_id_319_to288;
                    parser_result_maid_field1 = parser_result->ma_id.eth.ma_id_287_to256;
                    break;
                case 2:
                    parser_result_maid_field0 = parser_result->ma_id.eth.ma_id_255_to224;
                    parser_result_maid_field1 = parser_result->ma_id.eth.ma_id_223_to192;
                    break;
                case 3:
                    parser_result_maid_field0 = parser_result->ma_id.eth.ma_id_191_to160;
                    parser_result_maid_field1 = parser_result->ma_id.eth.ma_id_159_to128;
                    break;
                case 4:
                    parser_result_maid_field0 = parser_result->ma_id.eth.ma_id_127_to96;
                    parser_result_maid_field1 = parser_result->ma_id.eth.ma_id_95_to64;
                    break;
                case 5:
                    parser_result_maid_field0 = parser_result->ma_id.eth.ma_id_63_to32;
                    parser_result_maid_field1 = parser_result->ma_id.eth.ma_id_31_to0;
                    break;
               default:
                    break;
             }

            parserresult_ma_id[8 * index + 0] = (parser_result_maid_field0 >> 24) & 0xFF;
            parserresult_ma_id[8 * index + 1] = (parser_result_maid_field0 >> 16) & 0xFF;
            parserresult_ma_id[8 * index + 2] = (parser_result_maid_field0 >> 8) & 0xFF;
            parserresult_ma_id[8 * index + 3] =  parser_result_maid_field0 & 0xFF;

            parserresult_ma_id[8 * index + 4] = (parser_result_maid_field1 >> 24) & 0xFF;
            parserresult_ma_id[8 * index + 5] = (parser_result_maid_field1 >> 16) & 0xFF;
            parserresult_ma_id[8 * index + 6] = (parser_result_maid_field1 >> 8) & 0xFF;
            parserresult_ma_id[8 * index + 7] = parser_result_maid_field1 & 0xFF;
        }

        switch(ds_ma->ma_id_length_type)
        {
            case 0:
            {
                sal_memcpy(ma_id, ma_id_byte, 8);
                break;
            }
            case 1:
            {
                sal_memcpy(ma_id, ma_id_byte, 16);
                break;
            }
            case 2:
            {
                sal_memcpy(ma_id, ma_id_byte, 32);
                break;
            }
            case 3:
            {
                sal_memcpy(ma_id, ma_id_byte, 48);
                break;
            }
            default:
                break;
        }

        ma_id_byte_match = !sal_memcmp(ma_id, parserresult_ma_id, parser_result->ma_id_length);
        ma_id_match = ma_id_byte_match || ds_mep->ma_id_check_disable;

        if(ma_id_match && !pkt_info->rmep_not_found)
        {
            /*EQUAL_CCM_PROCESS*/
            ccm_seq_num     = (ds_eth_rmep->ccm_seq_num1 << 24)|ds_eth_rmep->ccm_seq_num0;
            mep_id_mismatch = (parser_result->rmep_id != (ds_eth_rmep->mep_index & 0x1FFF));
            ccm_interval_mismatch       = (ds_ma->ccm_interval != parser_result->ccm_interval);
            present_traffic_mismatch    = (ds_eth_mep->present_traffic != parser_result->present_traffic);
            mac_sa_mismatch =
                !((parser_result->mac_sa.eth.mac_sa_47_to32 == ds_eth_rmep->rmep_mac_sa_high)
                && (parser_result->mac_sa.eth.mac_sa_31_to0 == ds_eth_rmep->rmep_mac_sa_low));
            mac_sa_mismatch = mac_sa_mismatch && parser_result->is_l2_eth_oam;
            rdi_mismatch = (parser_result->rdi != ds_eth_rmep->rmep_last_rdi);
            seq_num_match = ((ccm_seq_num + 1) == parser_result->ccm_seq_num.eth.ccm_seq_num);
            pkt_info->seq_num_chk_pass = seq_num_match ||(!ds_eth_rmep->seq_num_en) || (!ds_eth_rmep->first_pkt_rx);

            if(ds_eth_mep->eth_oam_p2_p_mode && mep_id_mismatch)
            {
                pkt_info->defect_type = 4; /*error ccm received, Unexp mep in ITU*/
                pkt_info->defect_sub_type = 0;

                SET_BIT(pkt_info->exception, OAM_EXCEPTION_4_ERROR_CCM_DEFECT_RMEP_NOT_FOUND);
            }
            else if(ccm_interval_mismatch)
            {
                pkt_info->defect_type = 4; /* Unexp ccm interval  in ITU*/
                pkt_info->defect_sub_type = 1;
                SET_BIT(pkt_info->exception, OAM_EXCEPTION_17_ERROR_CCM_DEFECT_CCM_INTERVAL_MISMATCH);
                /*the first expect ccm is rx, so update process can gen D_loc*/
                pkt_info->first_pkt_rx = TRUE;
            }
            else
            {
                /*the first expect ccm is rx, so update process can gen D_loc*/
                pkt_info->first_pkt_rx = TRUE;
                if(ds_eth_mep->present_traffic_check_en && present_traffic_mismatch)
                {
                    pkt_info->defect_type = 0;
                    pkt_info->defect_sub_type = 7; /*mm Defect, present traffic field mismatch*/
                    SET_BIT(pkt_info->exception, OAM_EXCEPTION_23_PBT_MM_DEFECT_PDU_TO_CPU);
                }

                /*check sequence number or increase packet number*/
                if((!pkt_info ->seq_num_chk_pass)
                  && ((ds_eth_rmep->seq_num_fail_counter + 1) >= oam_rx_proc_ether_ctl.seqnum_fail_report_thrd))
                {
                    SET_BIT(pkt_info->exception, OAM_EXCEPTION_6_CCM_SEQ_NUM_ERROR);
                }

                if(rdi_mismatch)
                {
                    pkt_info->defect_type = 1;
                    pkt_info->defect_sub_type = parser_result->rdi ? 0:7;
                    SET_BIT(pkt_info->exception, OAM_EXCEPTION_1_SOME_RDI_DEFECT);
                }

                rmep_port_status_change = parser_result->port_status_valid
                    &&(parser_result->port_status_value!= ds_eth_rmep->rmep_last_port_status);
                rmep_intf_status_change = parser_result->if_status_valid
                    &&(parser_result->if_status_value!= ds_eth_rmep->rmep_last_intf_status);

                if((rmep_port_status_change || rmep_intf_status_change) && !ds_eth_rmep->mac_status_change)
                {
                    pkt_info->defect_type = 0;
                    pkt_info->defect_sub_type = 1; /*status change defect*/
                    SET_BIT(pkt_info->exception, OAM_EXCEPTION_2_SOME_MAC_STATUS_DEFECT);
                    new_ds_eth_rmep->mac_status_change = TRUE;
                }

                if(mac_sa_mismatch && oam_rx_proc_ether_ctl.alarm_src_mac_mismatch
                    && ((ETH_CCM_MEP == ds_eth_mep->mep_type)||(PBT_CCM_MEP == ds_eth_mep->mep_type))
                    && !ds_eth_rmep->rmepmacmismatch)
                {
                    pkt_info->defect_type = 0; /*src MAC mismatch defect*/
                    pkt_info->defect_sub_type = 7;
                    SET_BIT(pkt_info->exception, OAM_EXCEPTION_13_SOURCE_MAC_MISMATCH);
                    new_ds_eth_rmep->rmepmacmismatch = TRUE;
                }
            }
        }
        else
        {
            if(!ma_id_match)
            {
                /*MAID_MISMATCH*/
                pkt_info->defect_type = 5;
                pkt_info->defect_sub_type = 0;
                SET_BIT(pkt_info->exception, OAM_EXCEPTION_5_XCON_CCM_DEFECT);
            }
            else
            {
                pkt_info->defect_type = 4;
                pkt_info->defect_sub_type = 0;
                SET_BIT(pkt_info->exception, OAM_EXCEPTION_5_XCON_CCM_DEFECT);
            }
        }

    }
    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_receive_process_equal_bfd
 * Purpose:    equal BFD process
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 *             rx_pkt_info -- pointer to buffer which save information
 *                       used in receive process.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/

static int32
_cm_oam_receive_process_equal_bfd(oam_in_pkt_t* in_pkt,
                                                    oam_receive_pkt_info_t* rx_pkt_info)
{
    oam_pkt_info_t* pkt_info   = (oam_pkt_info_t*)in_pkt->pkt_info;
    ds_bfd_mep_t* ds_bfd_mep   = (ds_bfd_mep_t*)rx_pkt_info->p_ds_bfd_mep;
    ds_bfd_rmep_t* ds_bfd_rmep = (ds_bfd_rmep_t*)rx_pkt_info->p_ds_bfd_rmep;
    ds_ma_t *ds_ma = (ds_ma_t *)rx_pkt_info->p_ds_ma;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    oam_rx_proc_ether_ctl_t oam_rx_proc_ether_ctl;

    uint8 chip_id = in_pkt->chip_id;
    uint32 cmd = 0;
    uint16 ma_name_index = 0;
    uint8 ma_id_byte[48] = {0};
    uint8 ma_id[48] = {0};
    uint8 ach_mepid_field[48] = {0};
    ds_ma_name_t ds_ma_name[6];
    uint8 ma_id_length_shift = 0;
    uint8 ds_index = 0;

    uint8 mis_con_defect   = 0;
    uint8 ach_mepid_length = 0;
    uint8 ma_id_byte_match = 0;

    uint8 csf_interval_fail = 0;
    uint8 csf_type = 0;
//    uint8 ach_field_index = 0;

    uint8 ma_id_length_type = 0;

    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl_t));
    cmd = DRV_IOR(OamRxProcEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd,  &oam_rx_proc_ether_ctl));

    if (BFD_OAM == parser_result->oam_type)
    {
        if (BFD_STATE_ADMIN_DOWN == ds_bfd_mep->local_stat)
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_29_ERROR_BFD_TO_CPU);/*discard*/
            pkt_info->by_pass_all = TRUE;
        }
        else
        {
            if(parser_result->ma_id.bfd.pbit || parser_result->ma_id.bfd.fbit)
            {/*Reception of poll packets or final packets and send them to cpu*/
                SET_BIT(pkt_info->exception, OAM_EXCEPTION_30_BFD_TIMER_NEGOTIATION_TO_CPU);
                /*ECO bug 4988 Start*/
                /*pkt_info->by_pass_all = TRUE;*/
                pkt_info->by_pass_all = IS_BIT_SET(oam_rx_proc_ether_ctl.ether_defect_to_rdi1, 31);
                /*ECO bug 4988 End*/
            }
        }

        pkt_info->first_pkt_rx = TRUE;/* the first expect BFD packet*/
    }
    else if(!ds_bfd_rmep->first_pkt_rx)
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_0_OAM_PDU_INVALID);
        pkt_info->by_pass_all = TRUE;
    }
    else if(MPLSTP_CSF == parser_result->oam_type && (!ds_bfd_rmep->is_csf_en ||oam_rx_proc_ether_ctl.tp_csf_to_cpu))
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_20_CSF_TO_CPU);
        pkt_info->by_pass_all = TRUE;
    }
    else if(MPLSTP_CSF == parser_result->oam_type)
    {
        csf_type = (parser_result->ccm_seq_num.csf.csf_flags >> 3) & 0x7;
        csf_interval_fail = ((parser_result->ccm_seq_num.csf.csf_flags &0x7) != ds_ma->ccm_interval);
        if (csf_interval_fail)
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_0_OAM_PDU_INVALID);
            pkt_info->by_pass_all = TRUE;
        }
        else
        {
            if (csf_type == oam_rx_proc_ether_ctl.tp_csf_fdi
                || csf_type == oam_rx_proc_ether_ctl.tp_csf_rdi
                || csf_type == oam_rx_proc_ether_ctl.tp_csf_los)
            {
                pkt_info->defect_type     = 3;    /* csf detect*/
                pkt_info->defect_sub_type = 1;
            }
            else if (csf_type == oam_rx_proc_ether_ctl.tp_csf_clear)
            {
                pkt_info->defect_type     = 3;    /* csf clear*/
                pkt_info->defect_sub_type = 2;
            }
        }
    }
    else if(MPLSTP_CV == parser_result->oam_type &&(!ds_bfd_rmep->is_cv_en || oam_rx_proc_ether_ctl.tp_cv_to_cpu))
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_9_SLOW_OAM_PDU_TO_CPU);/*discard*/
        pkt_info->by_pass_all = TRUE;
    }
    else
    {
        mis_con_defect = 0;
        ma_name_index = (ds_bfd_rmep->ip_sa>>11)&0x3FFF;
        sal_memset(&ds_ma_name[0], 0, sizeof(ds_ma_name));
        cmd = DRV_IOR(DsMaName_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index, cmd, &ds_ma_name[0]));

        ma_id_length_type = (ds_bfd_rmep->ip_sa>>25)&0x3;

        ma_id_length_shift = ma_id_length_type;
        if(ma_id_length_shift != 0)
        {
            cmd = DRV_IOR(DsMaName_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index+1, cmd, &ds_ma_name[1]));
            ma_id_length_shift--;

            if(ma_id_length_shift != 0)
            {
                cmd = DRV_IOR(DsMaName_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index+2, cmd, &ds_ma_name[2]));
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index+3, cmd, &ds_ma_name[3]));
                ma_id_length_shift--;

                if(ma_id_length_shift != 0)
                {
                    cmd = DRV_IOR(DsMaName_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index+4, cmd, &ds_ma_name[4]));
                    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, ma_name_index+5, cmd, &ds_ma_name[5]));

                }

            }
        }

        for (ds_index = 0; ds_index < 6; ds_index++)/*ma_id_byte[0..15]*/
        {
            ma_id_byte[8 * ds_index + 0] = (ds_ma_name[ds_index].ma_id_umc0 >> 24) & 0xFF;
            ma_id_byte[8 * ds_index + 1] = (ds_ma_name[ds_index].ma_id_umc0 >> 16) & 0xFF;
            ma_id_byte[8 * ds_index + 2] = (ds_ma_name[ds_index].ma_id_umc0 >> 8) & 0xFF;
            ma_id_byte[8 * ds_index + 3] =  ds_ma_name[ds_index].ma_id_umc0 & 0xFF;

            ma_id_byte[8 * ds_index + 4] = (ds_ma_name[ds_index].ma_id_umc1 >> 24) & 0xFF;
            ma_id_byte[8 * ds_index + 5] = (ds_ma_name[ds_index].ma_id_umc1 >> 16) & 0xFF;
            ma_id_byte[8 * ds_index + 6] = (ds_ma_name[ds_index].ma_id_umc1 >> 8) & 0xFF;
            ma_id_byte[8 * ds_index + 7] =  ds_ma_name[ds_index].ma_id_umc1 & 0xFF;
        }

        switch(ma_id_length_type)
        {
            case 0:
            {
                sal_memcpy(ma_id, ma_id_byte, 8);
                break;
            }
            case 1:
            {
                sal_memcpy(ma_id, ma_id_byte, 16);
                break;
            }
            case 2:
            {
                sal_memcpy(ma_id, ma_id_byte, 32);
                break;
            }
            case 3:
            {
                sal_memcpy(ma_id, ma_id_byte, 36);
                break;
            }
            default:
                break;
        }

        for (ds_index = 0; ds_index < 6; ds_index++)/*ma_id_byte[0..15]*/
        {
            uint32 parser_result_ach_mepid_field0 = 0;
            uint32 parser_result_ach_mepid_field1 = 0;

            switch (ds_index)
            {
                case 4:
                    parser_result_ach_mepid_field0 = parser_result->ma_id.bfd.ach_mepid_field0_31_to0;
                    parser_result_ach_mepid_field1 = 0;
                    break;
                case 3:
                    parser_result_ach_mepid_field0 = parser_result->ma_id.bfd.ach_mepid_field0_95_to64;
                    parser_result_ach_mepid_field1 = parser_result->ma_id.bfd.ach_mepid_field0_63_to32;
                    break;
                case 2:
                    parser_result_ach_mepid_field0 = parser_result->ma_id.bfd.ach_mepid_field0_159_to128;
                    parser_result_ach_mepid_field1 = parser_result->ma_id.bfd.ach_mepid_field0_127_to96;
                    break;
                case 1:
                    parser_result_ach_mepid_field0 = parser_result->ma_id.bfd.ach_mepid_field0_223_to192;
                    parser_result_ach_mepid_field1 = parser_result->ma_id.bfd.ach_mepid_field0_191_to160;
                    break;
                case 0:
                    parser_result_ach_mepid_field0 = ((parser_result->ccm_seq_num.bfd.ach_mepid_field2_287_to272<<16)
                        | parser_result->mac_sa.bfd.ach_mepid_field1_271_to256);
                    parser_result_ach_mepid_field1 = parser_result->mac_sa.bfd.ach_mepid_field1_255_to224;
                    break;
                default:
                    break;
            }

            ach_mepid_field[8 * ds_index + 0] = (parser_result_ach_mepid_field0 >> 24) & 0xFF;
            ach_mepid_field[8 * ds_index + 1] = (parser_result_ach_mepid_field0 >> 16) & 0xFF;
            ach_mepid_field[8 * ds_index + 2] = (parser_result_ach_mepid_field0 >> 8) & 0xFF;
            ach_mepid_field[8 * ds_index + 3] =  parser_result_ach_mepid_field0 & 0xFF;

            ach_mepid_field[8 * ds_index + 4] = (parser_result_ach_mepid_field1 >> 24) & 0xFF;
            ach_mepid_field[8 * ds_index + 5] = (parser_result_ach_mepid_field1 >> 16) & 0xFF;
            ach_mepid_field[8 * ds_index + 6] = (parser_result_ach_mepid_field1 >> 8) & 0xFF;
            ach_mepid_field[8 * ds_index + 7] = parser_result_ach_mepid_field1 & 0xFF;
        }


        ach_mepid_length = 4 + parser_result->mac_sa.bfd.ach_mepid_field1_271_to256;
        //ach_mepid_length = 4 + (parser_result->mac_sa.bfd.ach_mepid_field1_271_to256 & 0x3F); /* [261:256], please check it??? */

        ma_id_byte_match = !sal_memcmp(ma_id, ach_mepid_field, ach_mepid_length);
        mis_con_defect = !ma_id_byte_match;

        if (ds_bfd_rmep->disc_chk_en && (parser_result->ma_id.bfd.my_disc != ds_bfd_rmep->remote_disc))
        {
           mis_con_defect = 1;
        }

        if (parser_result->ma_id.bfd.your_disc != ds_bfd_mep->local_disc)
        {
           mis_con_defect = 1;
        }

        if (mis_con_defect)
        {
            pkt_info->defect_type     = 5;    /* mis-connect detect*/
            pkt_info->defect_sub_type = 0;
        }

    }
    return DRV_E_NONE;

}

/****************************************************************************
 * Name:       _cm_oam_receive_process_equal_lm
 * Purpose:    equal LMM/LMMR process
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/

static int32
_cm_oam_receive_process_equal_lm(oam_in_pkt_t* in_pkt, oam_receive_pkt_info_t* rx_pkt_info)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8 chip_id = in_pkt->chip_id;
    oam_rx_proc_ether_ctl_t oam_rx_proc_ether_ctl;
    ds_port_property_t ds_port_property;
    ds_ma_t *ds_ma = (ds_ma_t*)rx_pkt_info->p_ds_ma;
    uint32 cmd = 0;
    uint16 mp_port_id = 0;
    uint8  parser_result_mac_da[6] = {0};
    uint8  mac_da_check_fail = FALSE;

    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl));
    cmd = DRV_IOR(OamRxProcEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_rx_proc_ether_ctl));

    /*EQUAL_SINGLELM_PROC*/
    /*if LMR, send to CPU directly by exception, CPU will do validation check*/
    if(ETHER_LMR == parser_result->oam_type)
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_27_LM_TO_CPU);
        pkt_info->by_pass_all = TRUE;
    }
    else if (oam_rx_proc_ether_ctl.lmm_proc_by_cpu)
    {
        if(ETHER_LMM == parser_result->oam_type)
        {
             SET_BIT(pkt_info->exception, OAM_EXCEPTION_27_LM_TO_CPU);
             pkt_info->by_pass_all = TRUE;
        }
        else if (MPLSTP_DLM == parser_result->oam_type)
        {
             SET_BIT(pkt_info->exception, OAM_EXCEPTION_14_MPLS_TP_DLM_TO_CPU);
             pkt_info->by_pass_all = TRUE;

        }
    }
    else if(parser_result->is_l2_eth_oam && (ETHER_LMM == parser_result->oam_type))
    {   /*if LMM, check the MAC address*/
        if(0x1F == (pkt_info->global_src_port >> 9) && !pkt_info->link_oam)
        {
            mp_port_id = 128 + (pkt_info->global_src_port & 0x3F);
        }
        else
        {
            mp_port_id = pkt_info->local_phy_port & 0x7f; /*only support local phyport from 0-127*/
        }

        sal_memset(&ds_port_property, 0, sizeof(ds_port_property));
        cmd = DRV_IOR(DsPortProperty_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mp_port_id, cmd, &ds_port_property));



        if(pkt_info->share_mac_en)
        {
            sal_memset(pkt_info->port_mac, 0, sizeof(pkt_info->port_mac));
        }
        else
        {
            pkt_info->port_mac[0] = (oam_rx_proc_ether_ctl.port_mac >> 24) & 0xFF;
            pkt_info->port_mac[1] = (oam_rx_proc_ether_ctl.port_mac >> 16) & 0xFF;
            pkt_info->port_mac[2] = (oam_rx_proc_ether_ctl.port_mac >> 8) & 0xFF;
            pkt_info->port_mac[3] = oam_rx_proc_ether_ctl.port_mac & 0xFF;
            pkt_info->port_mac[4] = (ds_port_property.mac_sa_byte >> 8) & 0xFF;
            pkt_info->port_mac[5] = ds_port_property.mac_sa_byte & 0xFF;
        }

        pkt_info->bridge_mac[0] = (oam_rx_proc_ether_ctl.bridge_mac_high >> 8) & 0xFF;
        pkt_info->bridge_mac[1] = oam_rx_proc_ether_ctl.bridge_mac_high & 0xFF;
        pkt_info->bridge_mac[2] = (oam_rx_proc_ether_ctl.bridge_mac_low >> 24) & 0xFF;
        pkt_info->bridge_mac[3] = (oam_rx_proc_ether_ctl.bridge_mac_low >> 16) & 0xFF;
        pkt_info->bridge_mac[4] = (oam_rx_proc_ether_ctl.bridge_mac_low >> 8) & 0xFF;
        pkt_info->bridge_mac[5] = oam_rx_proc_ether_ctl.bridge_mac_low & 0xFF;

        if(!IS_BIT_SET(parser_result->mac_da.eth.mac_da_47_to32, 8))/*ucast mac da, [40] */
        {
            parser_result_mac_da[0]= (parser_result->mac_da.eth.mac_da_47_to32>>8);
            parser_result_mac_da[1]= (parser_result->mac_da.eth.mac_da_47_to32&0xFF);
            parser_result_mac_da[2]= (parser_result->mac_da.eth.mac_da_31_to0>>24);
            parser_result_mac_da[3]= (parser_result->mac_da.eth.mac_da_31_to0>>16)&0xFF;
            parser_result_mac_da[4]= (parser_result->mac_da.eth.mac_da_31_to0>>8)&0xFF;
            parser_result_mac_da[5]= parser_result->mac_da.eth.mac_da_31_to0&0xFF;

            mac_da_check_fail = oam_rx_proc_ether_ctl.lmm_macda_check_en
                && (sal_memcmp(parser_result_mac_da,pkt_info->bridge_mac,6) != 0)
                && (sal_memcmp(parser_result_mac_da,pkt_info->port_mac,6) != 0);
        }
        else if(!pkt_info->mip_en)/*mcast mac da, MCAST LBM only can be processed on MEP*/
        {
            mac_da_check_fail = oam_rx_proc_ether_ctl.lmm_macda_check_en
                &&((parser_result->mac_da.eth.mac_da_31_to0 & 0xF)!= ds_ma->md_lvl);
        }

        if(mac_da_check_fail)
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_26_LBM_MAC_DA_MEP_ID_CHECK_FAIL );
            pkt_info->by_pass_all = TRUE;
        }
    }
    else if(parser_result->oam_type == MPLSTP_DLM)
    {
        /*MPLSTP LM query (one way and no respond message)*/
        if((!IS_BIT_SET(parser_result->ma_id.dlm.flags, 3)) && (parser_result->ma_id.dlm.control_code == 0x2))
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_14_MPLS_TP_DLM_TO_CPU);
            pkt_info->by_pass_all = TRUE;
        }
        /*MPLSTP LM query (out of band messag)*/
        if((!IS_BIT_SET(parser_result->ma_id.dlm.flags, 3)) && (parser_result->ma_id.dlm.control_code == 0x1) && oam_rx_proc_ether_ctl.mplstpdlm_outbandto_cpu)
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_14_MPLS_TP_DLM_TO_CPU);
            pkt_info->by_pass_all = TRUE;
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_receive_process_equal_lb
 * Purpose:    equal LBM/LBR process
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_receive_process_equal_lb(oam_in_pkt_t* in_pkt, oam_receive_pkt_info_t* rx_pkt_info)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8 chip_id = in_pkt->chip_id;
    oam_rx_proc_ether_ctl_t oam_rx_proc_ether_ctl;
    auto_gen_pkt_ctl_t auto_gen_pkt_ctl;
    ds_port_property_t ds_port_property;
    uint32 cmd = 0;
    uint16 mp_port_id = 0;
    uint8 parser_result_mac_da[6] = {0};
    uint8 mac_da_check_fail = FALSE;
    uint8 mep_id_check_fail = FALSE;
    ds_eth_mep_t *ds_eth_mep = (ds_eth_mep_t*)rx_pkt_info->p_ds_eth_mep;
    ds_ma_t *ds_ma = (ds_ma_t*)rx_pkt_info->p_ds_ma;
    uint16 rx_stats_ptr = 0;
    auto_gen_pkt_rx_pkt_stats_t rx_pkt_stats;
    uint32 seq_num = 0;
    uint32 last_seq_num = 0;
    /**uint8* l3_header = in_pkt->pkt + parser_result->packet_offset;*/
    uint8 auto_gen_pkt_rx_pkts_stats_intr = FALSE;
    uint8 auto_gen_pkt_rx_octet_stats_intr = FALSE;

    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl));
    cmd = DRV_IOR(OamRxProcEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_rx_proc_ether_ctl));

    /*EQUAL_LB_PROC*/
    /*if LBR, send to CPU directly by exception,CPU will do validation check*/
    if(ETHER_LBR == parser_result->oam_type)
    {
        if(ds_eth_mep->auto_gen_en)
        {
            /**sunwei sync*/
            /*rx_stats_ptr = (ds_eth_mep->auto_gen_pkt_ptr<<3) + 1;  auto_gen_pkt_ptr*9*/
            rx_stats_ptr = (ds_eth_mep->auto_gen_pkt_ptr)&0x03;/**ds_eth_mep->auto_gen_pkt_ptr[1:0]*/

            sal_memset(&rx_pkt_stats, 0, sizeof(rx_pkt_stats));/*Format: AutoGenPktRxPktStats*/
            cmd = DRV_IOR(AutoGenPktRxPktStats_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, rx_stats_ptr, cmd, &rx_pkt_stats));

            rx_pkt_stats.rx_pkts++;

            if(pkt_info->packet_length >(0xffffffff-rx_pkt_stats.rx_octets0))
            {
                rx_pkt_stats.rx_octets1++;/*carry*/
            }
            rx_pkt_stats.rx_octets0 += pkt_info->packet_length;
            /**sunwei sync */
            /**
            seq_num = MAKE_UINT32(l3_header[4], l3_header[5], l3_header[6], l3_header[7]);
            */
            seq_num = parser_result->ccm_seq_num.eth.ccm_seq_num;
            last_seq_num = rx_pkt_stats.last_seq_num;
            if(rx_pkt_stats.seq_num_chk_en&& ((last_seq_num+1) != seq_num))
            {
                rx_pkt_stats.seq_disorder_cnt++;

            }
            rx_pkt_stats.last_seq_num = seq_num;
            cmd = DRV_IOW(AutoGenPktRxPktStats_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, rx_stats_ptr, cmd, &rx_pkt_stats));

#if (SDK_WORK_PLATFORM == 1)
            if (cosim_db.store_table)
            {
                DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, AutoGenPktRxPktStats_t, rx_stats_ptr,
                                            (uint32 *)&rx_pkt_stats, TRUE));
            }
#endif

            sal_memset(&auto_gen_pkt_ctl, 0, sizeof(auto_gen_pkt_ctl));
            cmd = DRV_IOR(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));

            auto_gen_pkt_rx_pkts_stats_intr = (rx_pkt_stats.rx_pkts >>26) >= auto_gen_pkt_ctl.pkts_stats_threshold;
            auto_gen_pkt_rx_octet_stats_intr = rx_pkt_stats.rx_octets1 >= auto_gen_pkt_ctl.octets_stats_threshold;

            if(auto_gen_pkt_rx_pkts_stats_intr)
            {
                CMODEL_DEBUG_OUT_INFO("\n++++ auto_gen_pkt_rx_pkts_stats_intr! File:%s Line:%d Function:%s\n",
                    __FILE__, __LINE__, __FUNCTION__);
            }
            if(auto_gen_pkt_rx_octet_stats_intr)
            {
                CMODEL_DEBUG_OUT_INFO("\n++++ auto_gen_pkt_rx_octet_stats_intr! File:%s Line:%d Function:%s\n",
                    __FILE__, __LINE__, __FUNCTION__);
            }

            pkt_info->equal_lb = FALSE;
        }
        else
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_25_EQUAL_LBR_TO_CPU);
            pkt_info->by_pass_all = TRUE;
        }
    }
     else if(oam_rx_proc_ether_ctl.lbm_proc_by_cpu)
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_26_LBM_MAC_DA_MEP_ID_CHECK_FAIL);
        pkt_info->by_pass_all = TRUE;
    }
    else if(ETHER_LBM == parser_result->oam_type)/* 802.1ag/Y1731 LBM processing */
    {
        /*if LBM, check the MAC address*/
        if(0x1F == (pkt_info->global_src_port >> 9) && !pkt_info->link_oam)
        {
            mp_port_id = 128 + (pkt_info->global_src_port & 0x3F);/*linkagg id*/
        }
        else
        {
            mp_port_id = pkt_info->local_phy_port & 0x7f;/*only support local phyport from 0-127*/
        }

        sal_memset(&ds_port_property, 0, sizeof(ds_port_property));
        cmd = DRV_IOR(DsPortProperty_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, mp_port_id, cmd, &ds_port_property));
        if(pkt_info->share_mac_en)
        {
            sal_memset(pkt_info->port_mac, 0, sizeof(pkt_info->port_mac));
        }
        else
        {
            pkt_info->port_mac[0] = (oam_rx_proc_ether_ctl.port_mac >> 24) & 0xFF;
            pkt_info->port_mac[1] = (oam_rx_proc_ether_ctl.port_mac >> 16) & 0xFF;
            pkt_info->port_mac[2] = (oam_rx_proc_ether_ctl.port_mac >> 8) & 0xFF;
            pkt_info->port_mac[3] = oam_rx_proc_ether_ctl.port_mac & 0xFF;
            pkt_info->port_mac[4] = (ds_port_property.mac_sa_byte >> 8) & 0xFF;
            pkt_info->port_mac[5] = ds_port_property.mac_sa_byte & 0xFF;
        }


        pkt_info->bridge_mac[0] = (oam_rx_proc_ether_ctl.bridge_mac_high >> 8) & 0xFF;
        pkt_info->bridge_mac[1] = oam_rx_proc_ether_ctl.bridge_mac_high & 0xFF;
        pkt_info->bridge_mac[2] = (oam_rx_proc_ether_ctl.bridge_mac_low >> 24) & 0xFF;
        pkt_info->bridge_mac[3] = (oam_rx_proc_ether_ctl.bridge_mac_low >> 16) & 0xFF;
        pkt_info->bridge_mac[4] = (oam_rx_proc_ether_ctl.bridge_mac_low >> 8) & 0xFF;
        pkt_info->bridge_mac[5] = oam_rx_proc_ether_ctl.bridge_mac_low & 0xFF;

        if(!IS_BIT_SET(parser_result->mac_da.eth.mac_da_47_to32, 8))/*ucast mac da*/
        {
            parser_result_mac_da[0]= (parser_result->mac_da.eth.mac_da_47_to32>>8)&0xFF;
            parser_result_mac_da[1]= parser_result->mac_da.eth.mac_da_47_to32&0xFF;
            parser_result_mac_da[2]= (parser_result->mac_da.eth.mac_da_31_to0>>24)&0xFF;
            parser_result_mac_da[3]= (parser_result->mac_da.eth.mac_da_31_to0>>16)&0xFF;
            parser_result_mac_da[4]= (parser_result->mac_da.eth.mac_da_31_to0>>8)&0xFF;
            parser_result_mac_da[5]= parser_result->mac_da.eth.mac_da_31_to0&0xFF;

            mac_da_check_fail = oam_rx_proc_ether_ctl.lbm_macda_check_en
                               && (sal_memcmp(parser_result_mac_da,pkt_info->bridge_mac,6) != 0)
                               && (sal_memcmp(parser_result_mac_da,pkt_info->port_mac,6) != 0);
        }
        else if(!pkt_info->mip_en)/*mcast mac da, MCAST LBM only can be processed on MEP*/
        {
            mac_da_check_fail = oam_rx_proc_ether_ctl.lbm_macda_check_en
                                &&((parser_result->mac_da.eth.mac_da_31_to0 & 0xF)!= ds_ma->md_lvl);
        }
        else
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_0_OAM_PDU_INVALID );
            pkt_info->by_pass_all = TRUE;
        }

        if(mac_da_check_fail)
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_26_LBM_MAC_DA_MEP_ID_CHECK_FAIL );
            pkt_info->by_pass_all = TRUE;
        }
    }
    else if(MPLSTP_LBM == parser_result->oam_type)/*MPLS TP based Y1731 LBM processing, MPLSTP LBM*/
    {
        if(pkt_info->mip_en)
        {
            SET_BIT(pkt_info->exception, OAM_EXCEPTION_26_LBM_MAC_DA_MEP_ID_CHECK_FAIL );
            pkt_info->by_pass_all = TRUE;
        }
        else
        {
            mep_id_check_fail = (parser_result->rmep_id != ds_eth_mep->mep_id);
            if(mep_id_check_fail)
            {
                SET_BIT(pkt_info->exception, OAM_EXCEPTION_26_LBM_MAC_DA_MEP_ID_CHECK_FAIL );
                pkt_info->by_pass_all = TRUE;
            }
        }
    }
    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_oam_receive_process_equal_tst
 * Purpose:    equal eth tst process
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_receive_process_equal_tst(oam_in_pkt_t* in_pkt, oam_receive_pkt_info_t* rx_pkt_info)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8 chip_id = in_pkt->chip_id;
    auto_gen_pkt_ctl_t auto_gen_pkt_ctl;
    ds_eth_mep_t *ds_eth_mep = (ds_eth_mep_t*)rx_pkt_info->p_ds_eth_mep;
    uint16 rx_stats_ptr = 0;
    auto_gen_pkt_rx_pkt_stats_t rx_pkt_stats;
    /**uint8* l3_header = in_pkt->pkt + parser_result->packet_offset;*/
    uint32 cmd = 0;
    uint32 seq_num = 0;
    uint32 last_seq_num = 0;
    uint8 auto_gen_pkt_rx_pkts_stats_intr = FALSE;
    uint8 auto_gen_pkt_rx_octet_stats_intr = FALSE;

    if(ds_eth_mep->auto_gen_en)
    {
        /**sunwei sync*/
        /*rx_stats_ptr = (ds_eth_mep->auto_gen_pkt_ptr<<3) + 1;  auto_gen_pkt_ptr*9*/
        rx_stats_ptr = ds_eth_mep->auto_gen_pkt_ptr&0x03;/**ds_eth_mep->auto_gen_pkt_ptr[1:0]*/

        sal_memset(&rx_pkt_stats, 0, sizeof(rx_pkt_stats));
        cmd = DRV_IOR(AutoGenPktRxPktStats_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, rx_stats_ptr, cmd, &rx_pkt_stats));

        rx_pkt_stats.rx_pkts++;

        if(pkt_info->packet_length >(0xffffffff-rx_pkt_stats.rx_octets0))
        {
            rx_pkt_stats.rx_octets1++;/*swap*/
        }
        rx_pkt_stats.rx_octets0 += pkt_info->packet_length;

        /** suwnei sync*/
        /**
        seq_num = MAKE_UINT32(l3_header[4], l3_header[5], l3_header[6], l3_header[7]);
        */
        seq_num = parser_result->ccm_seq_num.eth.ccm_seq_num;
        last_seq_num = rx_pkt_stats.last_seq_num;
        if(rx_pkt_stats.seq_num_chk_en && ((last_seq_num+1) != seq_num))
        {
            rx_pkt_stats.seq_disorder_cnt++;

        }
        /**sunwei sync */
         rx_pkt_stats.last_seq_num = seq_num;
        /* update new DsOamLmmStats to memory */
        cmd = DRV_IOW(AutoGenPktRxPktStats_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, rx_stats_ptr, cmd, &rx_pkt_stats));

#if (SDK_WORK_PLATFORM == 1)
        if (cosim_db.store_table)
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, AutoGenPktRxPktStats_t, rx_stats_ptr,
                                        (uint32 *)&rx_pkt_stats, TRUE));
        }
#endif
        sal_memset(&auto_gen_pkt_ctl, 0, sizeof(auto_gen_pkt_ctl));
        cmd = DRV_IOR(AutoGenPktCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &auto_gen_pkt_ctl));

        auto_gen_pkt_rx_pkts_stats_intr = (rx_pkt_stats.rx_pkts >>26) >= auto_gen_pkt_ctl.pkts_stats_threshold;
        auto_gen_pkt_rx_octet_stats_intr = rx_pkt_stats.rx_octets1 >= auto_gen_pkt_ctl.octets_stats_threshold;

        if(auto_gen_pkt_rx_pkts_stats_intr)
        {
            CMODEL_DEBUG_OUT_INFO("\n++++ auto_gen_pkt_rx_pkts_stats_intr! File:%s Line:%d Function:%s\n",
                __FILE__, __LINE__, __FUNCTION__);
        }
        if(auto_gen_pkt_rx_octet_stats_intr)
        {
            CMODEL_DEBUG_OUT_INFO("\n++++ auto_gen_pkt_rx_octet_stats_intr! File:%s Line:%d Function:%s\n",
                __FILE__, __LINE__, __FUNCTION__);
        }
    }
    else
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_10_ETH_TST_TO_CPU);
        pkt_info->by_pass_all = TRUE;
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       _cm_oam_receive_process_update_mp
 * Purpose:    updtate ds_rmep and ds_mep
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 *             rx_pkt_info -- pointer to buffer which save information
 *                       used in receive process.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
static int32
_cm_oam_receive_process_update_mp(oam_in_pkt_t* in_pkt,oam_receive_pkt_info_t* rx_pkt_info)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8 chip_id = in_pkt->chip_id;

    ds_eth_mep_t*  new_ds_eth_mep    = (ds_eth_mep_t*)rx_pkt_info->p_new_ds_eth_mep;
    ds_eth_rmep_t* new_ds_eth_rmep   = (ds_eth_rmep_t*)rx_pkt_info->p_new_ds_eth_rmep;
    ds_bfd_mep_t*  new_ds_bfd_mep    = (ds_bfd_mep_t*)rx_pkt_info->p_new_ds_bfd_mep;
    ds_bfd_rmep_t* new_ds_bfd_rmep   = (ds_bfd_rmep_t*)rx_pkt_info->p_new_ds_bfd_rmep;

    ds_eth_rmep_t* ds_eth_rmep = (ds_eth_rmep_t*)rx_pkt_info->p_ds_eth_rmep;
    ds_eth_mep_t* ds_eth_mep = (ds_eth_mep_t*)rx_pkt_info->p_ds_eth_mep;
    ds_bfd_mep_t* ds_bfd_mep   = (ds_bfd_mep_t*)rx_pkt_info->p_ds_bfd_mep;
    ds_bfd_rmep_t* ds_bfd_rmep   = (ds_bfd_rmep_t*)rx_pkt_info->p_ds_bfd_rmep;

    ds_eth_mep_t*  ds_mep      = (ds_eth_mep_t*)rx_pkt_info->p_ds_mep;
    ds_eth_rmep_t* ds_rmep     = (ds_eth_rmep_t*)rx_pkt_info->p_ds_rmep;

    uint32 cmd = 0;
    uint8 is_rmep_update = FALSE;
    uint8 is_ether_rmep_process = FALSE;
    uint8 is_bfd_rmep_process = FALSE;
    uint8 is_bfd_mep_process = FALSE;
    uint8 is_eth_mep = FALSE;
    uint8 is_eth_rmep = FALSE;
    uint8 is_bfd_mep = FALSE;
    uint8 is_bfd_rmep = FALSE;
    uint8 is_defect_to_rdi = FALSE;
    uint8 is_defect_free = FALSE;
    uint8 is_eth_defect_to_rdi = FALSE;
    uint8 rdi_index = 0;

    oam_rx_proc_ether_ctl_t oam_rx_proc_ether_ctl;
    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl));
    cmd = DRV_IOR(OamRxProcEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_rx_proc_ether_ctl));

    is_eth_mep = !ds_mep->is_bfd;
    is_eth_rmep = !ds_rmep->is_bfd;
    is_bfd_mep = ds_mep->is_bfd;
    is_bfd_rmep = ds_rmep->is_bfd;

    /*UPDATE_DS_RMEP*/
    is_rmep_update = (4 == pkt_info->defect_type) && (1 == pkt_info->defect_sub_type);
    is_ether_rmep_process   = (((pkt_info->defect_type != 5) && (pkt_info->defect_type != 4)) || is_rmep_update) && (!is_bfd_rmep);
    is_bfd_rmep_process     =  is_bfd_rmep && (!pkt_info->by_pass_all);
    /*update RMEP*/
    if ((ETH_CSF == parser_result->oam_type) && is_ether_rmep_process)
    {
         /*
          ccmSeqNum0[23:0]/
         {8'd0,isCsfUseUcDa,dCsf,rxCsfWhile[3:0],rxCsfType[2:0],isTxCsfEn,csfType[2:0],csfWhile[2:0]}
         */

        /*detect CSF */
        if ((3 == pkt_info->defect_type) && (1 == pkt_info->defect_sub_type))
        {
            SET_BIT(new_ds_eth_rmep->ccm_seq_num0, 14); /*dCSF*/
            SET_BIT_RANGE(new_ds_eth_rmep->ccm_seq_num0,oam_rx_proc_ether_ctl.rx_csf_while_cfg, 10, 4); /*rxCsfWhile*/
            SET_BIT_RANGE(new_ds_eth_rmep->ccm_seq_num0,((parser_result->ccm_seq_num.csf.csf_flags>>3)&0x7), 7, 3); /*rxCsfType*/
            if (IS_BIT_SET(ds_eth_rmep->ccm_seq_num0,14))
            {
                 pkt_info->defect_type = 0;
                 pkt_info->defect_sub_type = 0;
            }
        }

        /*clear CSF */
        if ((3 == pkt_info->defect_type) && (2 == pkt_info->defect_sub_type))
        {
            CLEAR_BIT(new_ds_eth_rmep->ccm_seq_num0,14); /*clear CSF*/
            SET_BIT_RANGE(new_ds_eth_rmep->ccm_seq_num0,oam_rx_proc_ether_ctl.rx_csf_while_cfg, 10, 4); /*reset rxCsfWhile*/
            SET_BIT_RANGE(new_ds_eth_rmep->ccm_seq_num0,((parser_result->ccm_seq_num.csf.csf_flags>>3)&0x7), 7, 3); /*rxCsfType*/
            if (!IS_BIT_SET(ds_eth_rmep->ccm_seq_num0,14))
            {
                 pkt_info->defect_type = 0;
                 pkt_info->defect_sub_type = 0;
            }
        }
    }
    else if(is_ether_rmep_process)
    {
        if(ds_eth_rmep->seq_num_en)
        {
            new_ds_eth_rmep->ccm_seq_num0 = parser_result->ccm_seq_num.eth.ccm_seq_num & 0xFFFFFF;
            new_ds_eth_rmep->ccm_seq_num1 = (parser_result->ccm_seq_num.eth.ccm_seq_num >> 24)& 0xFF;
            if(!pkt_info->seq_num_chk_pass)
            {
                new_ds_eth_rmep->seq_num_fail_counter += 1;
            }
        }

        if(!ds_eth_rmep->mac_addr_update_disable)
        {
            new_ds_eth_rmep->rmep_mac_sa_high = parser_result->mac_sa.eth.mac_sa_47_to32;
            new_ds_eth_rmep->rmep_mac_sa_low = parser_result->mac_sa.eth.mac_sa_31_to0;
        }

        new_ds_eth_rmep->rmep_last_rdi = parser_result->rdi;

        if(!ds_eth_rmep->d_loc)
        {
            new_ds_eth_rmep->rmep_while = oam_rx_proc_ether_ctl.rmep_while_cfg; /*reset timer*/
        }

        new_ds_eth_rmep->rmep_last_intf_status = parser_result->if_status_valid ?
                                     (parser_result->if_status_value & 0x7) : ds_eth_rmep->rmep_last_intf_status;

        new_ds_eth_rmep->rmep_last_port_status = parser_result->port_status_valid ?
                                    (parser_result->port_status_value & 0x3) : ds_eth_rmep->rmep_last_port_status;

        if(is_rmep_update)
        {
            new_ds_eth_rmep->d_unexp_period = TRUE;
            new_ds_eth_rmep->d_unexp_period_timer = oam_rx_proc_ether_ctl.d_unexp_period_timer_cfg;
            if(ds_eth_rmep->d_unexp_period)
            {
                pkt_info->defect_type       = 0;
                pkt_info->defect_sub_type   = 0;
            }
        }

        new_ds_eth_rmep->first_pkt_rx |= pkt_info->first_pkt_rx;

        is_defect_free = (0 == pkt_info->defect_type) && (0 == pkt_info->defect_sub_type);
        if(0 == ds_eth_rmep->first_pkt_rx && pkt_info->first_pkt_rx && is_defect_free)
        {   /*first rx packet report to cpu*/
            pkt_info->defect_type       = 2;
            pkt_info->defect_sub_type   = 4;
        }

        if((ds_eth_rmep->exp_ccm_num & 0x3) < 3)
        {
            new_ds_eth_rmep->exp_ccm_num &= 0xFC;/*clear[1:0]*/
            new_ds_eth_rmep->exp_ccm_num |= (ds_eth_rmep->exp_ccm_num & 0x3)+ 1;
        }

    }

    if(is_bfd_rmep_process && (BFD_OAM == parser_result->oam_type) )
    {
        new_ds_bfd_rmep->remote_disc = parser_result->ma_id.bfd.my_disc;
        new_ds_bfd_rmep->remote_stat = parser_result->ma_id.bfd.stat;
        new_ds_bfd_rmep->remote_diag = parser_result->ma_id.bfd.diag;
        new_ds_bfd_rmep->defect_mult = parser_result->ma_id.bfd.detect_mult;
        new_ds_bfd_rmep->first_pkt_rx |= pkt_info->first_pkt_rx;
    }

    if(is_bfd_rmep_process && (MPLSTP_CV == parser_result->oam_type) )
    {
        /*
        ipSa[31:0]
        {21d'0,ccmInterval[2:0],cvWhile[2:0],dMisConWhile[3:0],dMisCon}
        */

        /*mis-connect detect */
        if ((5 == pkt_info->defect_type) && (0 == pkt_info->defect_sub_type))
        {
            SET_BIT(new_ds_bfd_rmep->ip_sa, 0); /*dMisCon*/
            SET_BIT_RANGE(new_ds_bfd_rmep->ip_sa, oam_rx_proc_ether_ctl.d_mis_con_while_cfg, 1, 4);
            new_ds_bfd_mep->local_diag = (ds_bfd_mep->local_diag != 0)?ds_bfd_mep->local_diag:9;

            if (IS_BIT_SET(ds_bfd_rmep->ip_sa, 0))
            {
                 pkt_info->defect_type     = 0;
                 pkt_info->defect_sub_type = 0;
            }
        }

    }

    /* UPDATE_DS_MEP */
    is_defect_free = (0 == pkt_info->defect_type) && (0 == pkt_info->defect_sub_type);

    rdi_index = (pkt_info->defect_type <<3) | pkt_info->defect_sub_type;

    if (rdi_index < 32)
    {
        is_eth_defect_to_rdi = IS_BIT_SET(oam_rx_proc_ether_ctl.ether_defect_to_rdi0, rdi_index);
    }
    else
    {
        is_eth_defect_to_rdi = IS_BIT_SET(oam_rx_proc_ether_ctl.ether_defect_to_rdi1, rdi_index - 32);
    }

    is_defect_to_rdi = !is_defect_free && is_eth_defect_to_rdi;

    if(!is_bfd_mep)
    {
        if(is_defect_to_rdi)
        {
            new_ds_eth_mep->present_rdi = TRUE; /*should be cleared by sw*/
        }

        if((4 == pkt_info->defect_type) && (0 == pkt_info->defect_sub_type))
        {   /*unexp mep*/
            new_ds_eth_mep->d_unexp_mep = TRUE;
            new_ds_eth_mep->d_unexp_mep_timer = oam_rx_proc_ether_ctl.d_unexp_mep_timer_cfg;
            if(ds_eth_mep->d_unexp_mep)
            {
                pkt_info->defect_type       = 0;
                pkt_info->defect_sub_type   = 0;
            }
        }
        else if((5 == pkt_info->defect_type) && (0 == pkt_info->defect_sub_type))
        {
            /*maid mismatch*/
            new_ds_eth_mep->d_mismerge = TRUE;
            new_ds_eth_mep->d_mismerge_timer = oam_rx_proc_ether_ctl.d_mismerge_timer_cfg;
            if(ds_eth_mep->d_mismerge)
            {
                pkt_info->defect_type       = 0;
                pkt_info->defect_sub_type   = 0;
            }
        }
        else if((5 == pkt_info->defect_type) && (1 == pkt_info->defect_sub_type))
        {
            /*low ccm*/
            new_ds_eth_mep->d_meg_lvl = TRUE;
            new_ds_eth_mep->d_meg_lvl_timer = oam_rx_proc_ether_ctl.d_meg_lvl_timer_cfg;
            if(ds_eth_mep->d_meg_lvl)
            {
                pkt_info->defect_type       = 0;
                pkt_info->defect_sub_type   = 0;
            }
        }
    }

    is_bfd_mep_process = !pkt_info->by_pass_all && is_bfd_mep;

    if ((MPLSTP_CSF == parser_result->oam_type) && is_bfd_mep_process)
    {
        /*detect CSF */
        if ((3 == pkt_info->defect_type) && (1 == pkt_info->defect_sub_type))
        {
            SET_BIT(new_ds_bfd_mep->bfd_srcport, 6);/*dCSF*/
            new_ds_bfd_mep->rx_csf_while = oam_rx_proc_ether_ctl.rx_csf_while_cfg; /*rxCsfWhile*/
            SET_BIT_RANGE( new_ds_bfd_mep->bfd_srcport, (parser_result->ccm_seq_num.csf.csf_flags>>3)&0x7, 7, 3); /*rxCsfType*/
            if (IS_BIT_SET(ds_bfd_mep->bfd_srcport,6))
            {
                 pkt_info->defect_type = 0;
                 pkt_info->defect_sub_type = 0;
            }
        }

        /*clear CSF */
        if ((3 == pkt_info->defect_type) && (2 == pkt_info->defect_sub_type))
        {
            CLEAR_BIT(new_ds_bfd_mep->bfd_srcport,6);/*clear CSF*/
            new_ds_bfd_mep->rx_csf_while = oam_rx_proc_ether_ctl.rx_csf_while_cfg; /*rxCsfWhile*/
            SET_BIT_RANGE( new_ds_bfd_mep->bfd_srcport, (parser_result->ccm_seq_num.csf.csf_flags>>3)&0x7, 7, 3); /*rxCsfType*/
            if (!IS_BIT_SET(ds_bfd_mep->bfd_srcport,6))
            {
                 pkt_info->defect_type = 0;
                 pkt_info->defect_sub_type = 0;
            }
        }

    }

    if (BFD_OAM == parser_result->oam_type && is_bfd_mep_process)
    {
        if(BFD_STATE_ADMIN_DOWN == parser_result->ma_id.bfd.stat)
        {/*received state is AdminDown*/
            if (BFD_STATE_DOWN != ds_bfd_mep->local_stat)
            {
                new_ds_bfd_mep->local_diag = 3;
                new_ds_bfd_mep->local_stat = BFD_STATE_DOWN;
                pkt_info->defect_type      = 2;
                pkt_info->defect_sub_type  = 3;
            }
        }
        else
        {/*received state isn't AdminDown*/
            if(BFD_STATE_DOWN == ds_bfd_mep->local_stat)/*bfd.SessionState is Down*/
            {
                if(BFD_STATE_DOWN == parser_result->ma_id.bfd.stat)
                {
                    new_ds_bfd_mep->local_stat = BFD_STATE_INIT;
                    pkt_info->defect_type = 2;
                    pkt_info->defect_sub_type = 1;
                }
                else if(BFD_STATE_INIT == parser_result->ma_id.bfd.stat)
                {
                    new_ds_bfd_mep->local_stat = BFD_STATE_UP;
                    pkt_info->defect_type = 2;
                    pkt_info->defect_sub_type = 2;
                }
                new_ds_bfd_mep->local_diag = (3 == new_ds_bfd_mep->local_diag)?0:
                                             new_ds_bfd_mep->local_diag;
            }
            else if(BFD_STATE_INIT == ds_bfd_mep->local_stat)/*bfd.SssionState is Init*/
            {
                if((BFD_STATE_INIT == parser_result->ma_id.bfd.stat)||(BFD_STATE_UP == parser_result->ma_id.bfd.stat))
                {
                    new_ds_bfd_mep->local_stat = BFD_STATE_UP;
                    pkt_info->defect_type = 2;
                    pkt_info->defect_sub_type = 2;
                }
            }
            else/*bfd.Stat is up*/
            {
                if(BFD_STATE_DOWN == parser_result->ma_id.bfd.stat)
                {
                    new_ds_bfd_mep->local_diag = 3;
                    new_ds_bfd_mep->local_stat = BFD_STATE_DOWN;
                    pkt_info->defect_type = 2;
                    pkt_info->defect_sub_type = 3;
                }
            }
            new_ds_bfd_rmep->defect_while = new_ds_bfd_rmep->actual_rx_interval * new_ds_bfd_rmep->defect_mult;
        }
    }

    /* For cosim, do not write table if bypass (only in bfd for rtl design), which means nothing
    is modified when bypass, need pay more attention if there's any exception */

    /*Write new Mep &Rmep to ram*/
    if(is_bfd_mep)
    {
        if(!pkt_info->by_pass_all)
        {
            cmd = DRV_IOW(DsBfdMep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id,
                                              pkt_info->mep_index,
                                              cmd,
                                              new_ds_bfd_mep));
#if (SDK_WORK_PLATFORM == 1)
            if (cosim_db.store_table)
            {
                DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DsBfdMep_t, pkt_info->mep_index,
                                            (uint32 *)new_ds_bfd_mep, TRUE));
            }
#endif
        }
    }
    else
    {
        cmd = DRV_IOW(DsEthMep_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id,
                                          pkt_info->mep_index,
                                          cmd,
                                          new_ds_eth_mep));
#if (SDK_WORK_PLATFORM == 1)
        if (cosim_db.store_table)
        {
            DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DsEthMep_t, pkt_info->mep_index,
                                        (uint32 *)new_ds_eth_mep, TRUE));
        }
#endif
    }

    if (is_ether_rmep_process || is_bfd_rmep_process)
    {
        if(is_bfd_rmep)
        {
            if(!pkt_info->by_pass_all)
            {
                cmd = DRV_IOW(DsBfdRmep_t, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id,
                                                  pkt_info->rmep_index,
                                                  cmd,
                                                  new_ds_bfd_rmep));
#if (SDK_WORK_PLATFORM == 1)
                if (cosim_db.store_table)
                {
                    DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DsBfdRmep_t, pkt_info->rmep_index,
                                                (uint32 *)new_ds_bfd_rmep, TRUE));
                }
#endif
            }
        }
        else
        {
            cmd = DRV_IOW(DsEthRmep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id,
                                              pkt_info->rmep_index,
                                              cmd,
                                              new_ds_eth_rmep));
#if (SDK_WORK_PLATFORM == 1)
            if (cosim_db.store_table)
            {
                DRV_IF_ERROR_RETURN(cosim_db.store_table(chip_id, DsEthRmep_t, pkt_info->rmep_index,
                                            (uint32 *)new_ds_eth_rmep, TRUE));
            }
#endif
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_receive_process_low_ccm
 * Purpose:    equal low CCM process
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 *             rx_pkt_info -- pointer to buffer which save information
 *                       used in receive process.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/

static int32 _cm_oam_receive_process_low_ccm(oam_in_pkt_t* in_pkt,
                                                                oam_receive_pkt_info_t* rx_pkt_info)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;

    SET_BIT(pkt_info->exception, OAM_EXCEPTION_5_XCON_CCM_DEFECT);
    pkt_info->defect_type = 5;
    pkt_info->defect_sub_type = 1;

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:       _cm_oam_recieve_process_rx_proc_oam
 * Purpose:    oam receive process
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/

static int32
_cm_oam_recieve_process_rx_proc_oam(oam_in_pkt_t* in_pkt)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8 chip_id = in_pkt->chip_id;
    oam_receive_pkt_info_t receive_pkt_info;

    ds_ma_t ds_ma;
    ds_eth_mep_t ds_mep;
    ds_eth_rmep_t ds_rmep;
    ds_bfd_mep_t ds_bfd_mep;
    ds_bfd_rmep_t ds_bfd_rmep;
    ds_eth_mep_t ds_eth_mep;
    ds_eth_rmep_t ds_eth_rmep;
    ds_bfd_mep_t new_ds_bfd_mep;
    ds_bfd_rmep_t new_ds_bfd_rmep;
    ds_eth_mep_t new_ds_eth_mep;
    ds_eth_rmep_t new_ds_eth_rmep;

    oam_rx_proc_ether_ctl_t oam_rx_proc_ether_ctl;
    oam_ether_tx_ctl_t oam_ether_tx_ctl;

    uint8 is_eth_mep = FALSE;
    uint8 is_eth_rmep = FALSE;
    uint8 is_bfd_mep = FALSE;
    uint8 is_bfd_rmep = FALSE;
    uint32 cmd = 0;
    uint8 is_dm_type = FALSE;
    uint8 is_lb_type = FALSE;
    uint8 is_lm_type = FALSE;
    uint8 is_md_lvl_match = FALSE;
    uint8 equal_ccm = FALSE;
    uint8 equal_bfd = FALSE;
    uint8 low_ccm = FALSE;
    uint8 need_rmep_lookup = FALSE;
    uint8 non_lbm_in_mip = FALSE;

    uint8 is_lt_type      = FALSE;
    uint8 is_tp_csf_type  = FALSE;
    uint8 is_eth_csf_type = FALSE;
    uint8 is_ccm_type     = FALSE;

    uint8 equal_lt     = FALSE;

    uint8 crc = 0;
    uint32 rmep_index = 0;

    sal_memset(&ds_ma, 0, sizeof(ds_ma_t));
    sal_memset(&ds_mep, 0, sizeof(ds_eth_mep_t));
    sal_memset(&ds_rmep, 0, sizeof(ds_eth_rmep_t));
    sal_memset(&ds_bfd_mep, 0, sizeof(ds_bfd_mep_t));
    sal_memset(&ds_bfd_rmep, 0, sizeof(ds_bfd_rmep_t));
    sal_memset(&ds_eth_mep, 0, sizeof(ds_eth_mep_t));
    sal_memset(&ds_eth_rmep, 0, sizeof(ds_eth_rmep_t));
    sal_memset(&new_ds_bfd_mep, 0, sizeof(ds_bfd_mep_t));
    sal_memset(&new_ds_bfd_rmep, 0, sizeof(ds_bfd_rmep_t));
    sal_memset(&new_ds_eth_mep, 0, sizeof(ds_eth_mep_t));
    sal_memset(&new_ds_eth_rmep, 0, sizeof(ds_eth_rmep_t));

    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl));
    cmd = DRV_IOR(OamRxProcEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_rx_proc_ether_ctl));
    /*RX*/
    if(!pkt_info->mip_en)
    {
        sal_memset(&ds_mep, 0, sizeof(ds_mep));
        cmd = DRV_IOR(DsEthMep_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->mep_index, cmd, &ds_mep));

        pkt_info->ma_index = ds_mep.ma_index;

        cmd = DRV_IOR(DsMa_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->ma_index, cmd, &ds_ma));

        pkt_info->oam_use_fid = ds_ma.use_vrfid_lkup;
        if((ETH_CCM_MEP == ds_mep.mep_type) ||(PBT_CCM_MEP == ds_mep.mep_type))
        {
            pkt_info->next_hop_ptr = (ds_ma.next_hop_ext<<16);
            pkt_info->src_vlan_ptr = ds_ma.next_hop_ptr & 0x1FFF;/*VlanPtr[12:0]/VRF ID[13:0]*/
        }
        else
        {
            pkt_info->next_hop_ptr = ((ds_ma.next_hop_ext<<16) | ds_ma.next_hop_ptr);
            pkt_info->src_vlan_ptr = 0x1fff;/*VlanPtr[12:0]*/
        }

        pkt_info->mpls_label_disable = ~(ds_ma.mpls_label_valid);

        is_eth_mep = !ds_mep.is_bfd;
        is_bfd_mep = ds_mep.is_bfd;

        cmd = DRV_IOR(DsEthMep_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->mep_index, cmd, &ds_eth_mep));

        cmd = DRV_IOR(DsBfdMep_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->mep_index, cmd, &ds_bfd_mep));

        is_dm_type = (ETHER_1DM == parser_result->oam_type)||(ETHER_DMM == parser_result->oam_type)
          ||(ETHER_DMR == parser_result->oam_type)||(MPLSTP_DM == parser_result->oam_type)
          ||(MPLSTP_DLMDM == parser_result->oam_type);

        is_lb_type = (ETHER_LBM == parser_result->oam_type)||(ETHER_LBR == parser_result->oam_type)
          ||(MPLSTP_LBM == parser_result->oam_type);
        is_lm_type = (ETHER_LMM == parser_result->oam_type)||(ETHER_LMR == parser_result->oam_type)
          ||(MPLSTP_DLM == parser_result->oam_type);

        is_lt_type = (ETHER_LTM == parser_result->oam_type)||(ETHER_LTR == parser_result->oam_type);
        is_tp_csf_type  = (MPLSTP_CSF == parser_result->oam_type);
        is_eth_csf_type = (ETH_CSF == parser_result->oam_type);
        is_ccm_type = (ETHER_CCM == parser_result->oam_type);

        is_md_lvl_match = (ds_ma.md_lvl == parser_result->md_lvl)&& (pkt_info->is_up == ds_mep.is_up) ;
        equal_ccm = is_md_lvl_match &&(is_ccm_type||is_eth_csf_type)&& ds_mep.active && is_eth_mep;

        equal_bfd = is_bfd_mep && ds_mep.active
                    && ((BFD_OAM == parser_result->oam_type || MPLSTP_CV == parser_result->oam_type) || is_tp_csf_type);
        equal_lt  = is_md_lvl_match && is_lt_type && is_eth_mep && ds_mep.active;

        pkt_info->equal_dm = is_md_lvl_match && is_dm_type && ds_mep.active && (ds_mep.enable_pm || ds_mep.is_bfd);
        pkt_info->equal_lm = is_md_lvl_match && is_lm_type && ds_mep.active && pkt_info->lm_received_packet;
        pkt_info->equal_lb = is_md_lvl_match && is_lb_type;
        pkt_info->equal_eth_tst = is_md_lvl_match && (ETHER_TST == parser_result->oam_type);

        pkt_info->share_mac_en = ds_eth_mep.share_mac_en;
        low_ccm = ((parser_result->md_lvl < ds_ma.md_lvl) ||
                    ((ds_ma.md_lvl == parser_result->md_lvl) && (pkt_info->is_up != ds_mep.is_up)))
                    && ds_mep.active && is_ccm_type && is_eth_mep;

        if (!oam_rx_proc_ether_ctl.rmep_lkup_disable)
        {
            rmep_index = cm_oam_lookup_get_rmep_index(in_pkt);
        }

        need_rmep_lookup = ds_mep.eth_oam_p2_p_mode || ((ETHER_CCM == parser_result->oam_type) && !low_ccm);

        if (need_rmep_lookup)
        {
            /*RETRIEVE_RMEP_INDEX*/
            cmd = DRV_IOR(DsEthMep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->mep_index, cmd, &ds_mep));

            if (ETH_CCM_MEP != ds_mep.mep_type || ds_mep.eth_oam_p2_p_mode)
            {
                pkt_info->rmep_index = pkt_info->mep_index + 1;
            }
            else
            {
                pkt_info->rmep_index = rmep_index;
                pkt_info->rmep_not_found = (pkt_info->rmep_index == 0);
            }

            cmd = DRV_IOR(DsEthRmep_t, DRV_ENTRY_FLAG);/*144 bit sram*/
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->rmep_index, cmd, &ds_rmep));

            is_eth_rmep = !ds_rmep.is_bfd;
            is_bfd_rmep = ds_rmep.is_bfd;

            cmd = DRV_IOR(DsEthRmep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->rmep_index, cmd, &ds_eth_rmep));

            cmd = DRV_IOR(DsBfdRmep_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, pkt_info->rmep_index, cmd, &ds_bfd_rmep));


        }

        pkt_info->is_mep_hit = TRUE;

        if(((ACH_Y1731_MEP == ds_mep.mep_type) || (ACH_BFD_MEP == ds_mep.mep_type))
            && ds_ma.tx_with_if_status)
        {
            pkt_info->mpls_tp_entropy_label = (ACH_Y1731_MEP == ds_mep.mep_type) ? \
                (ds_eth_rmep.rmep_mac_sa_low&0xFFFFF) : (ds_bfd_rmep.ip_sa & 0xFFFFF);

        }

        if(((ACH_Y1731_MEP == ds_mep.mep_type) || (ACH_BFD_MEP == ds_mep.mep_type))
            && (!oam_rx_proc_ether_ctl.portbased_section_oam) && pkt_info->link_oam)
        {
            pkt_info->link_oam = 0;
        }
    }
    else
    {
        pkt_info->equal_lb = (ETHER_LBM == parser_result->oam_type) || (MPLSTP_LBM == parser_result->oam_type);
        equal_lt   = (ETHER_LTM == parser_result->oam_type);
        is_dm_type =  (MPLSTP_DM == parser_result->oam_type)||(MPLSTP_DLMDM == parser_result->oam_type);
        is_lm_type =  (MPLSTP_DLM == parser_result->oam_type);
        pkt_info->equal_dm = is_dm_type && !IS_BIT_SET(parser_result->ma_id.dlm.flags,3);
        pkt_info->equal_lm = is_lm_type && pkt_info->lm_received_packet && !IS_BIT_SET(parser_result->ma_id.dlm.flags,3);
        non_lbm_in_mip = !equal_lt && (!pkt_info->equal_dm) && (!pkt_info->equal_lm) && (ETHER_LBM != parser_result->oam_type);
        pkt_info->is_mep_hit    = FALSE;
        pkt_info->share_mac_en  = FALSE;
        pkt_info->equal_eth_tst = FALSE;
    }

    sal_memset(&oam_ether_tx_ctl, 0, sizeof(oam_ether_tx_ctl_t));
    cmd = DRV_IOR(OamEtherTxCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &oam_ether_tx_ctl));
    if((0x1F == (pkt_info->ingress_src_port >> 9)) && (1 == oam_ether_tx_ctl.lkup_link_agg_mem))
    {
        crc = cm_oam_gen_header_hash(pkt_info->mep_index, pkt_info->rmep_index, 0xFF);
        pkt_info->ingress_src_port = cm_oam_com_get_link_agg_port(chip_id ,pkt_info->ingress_src_port, crc);
    }

    receive_pkt_info.p_ds_mep       = &ds_mep;
    receive_pkt_info.p_ds_rmep      = &ds_rmep;
    receive_pkt_info.p_ds_bfd_mep   = &ds_bfd_mep;
    receive_pkt_info.p_ds_bfd_rmep  = &ds_bfd_rmep;
    receive_pkt_info.p_ds_eth_mep   = &ds_eth_mep;
    receive_pkt_info.p_ds_eth_rmep  = &ds_eth_rmep;
    receive_pkt_info.p_ds_ma        = &ds_ma;

    /*initialize new_ds*/
    sal_memcpy(&new_ds_bfd_mep, &ds_bfd_mep, sizeof(new_ds_bfd_mep));
    sal_memcpy(&new_ds_bfd_rmep, &ds_bfd_rmep, sizeof(new_ds_bfd_rmep));
    sal_memcpy(&new_ds_eth_mep, &ds_eth_mep, sizeof(new_ds_eth_mep));
    sal_memcpy(&new_ds_eth_rmep, &ds_eth_rmep, sizeof(new_ds_eth_rmep));

    receive_pkt_info.p_new_ds_bfd_mep   = &new_ds_bfd_mep;
    receive_pkt_info.p_new_ds_bfd_rmep  = &new_ds_bfd_rmep;
    receive_pkt_info.p_new_ds_eth_mep   = &new_ds_eth_mep;
    receive_pkt_info.p_new_ds_eth_rmep  = &new_ds_eth_rmep;

    if(low_ccm)
    {
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_low_ccm(in_pkt,&receive_pkt_info));
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_update_mp(in_pkt,&receive_pkt_info));
    }
    /*
    else if(rmep_not_found)
    {
         pkt_info->defect_type       = 4;
         pkt_info->defect_sub_type   = 0;
         SET_BIT(pkt_info->exception, OAM_EXCEPTION_4_ERROR_CCM_DEFECT_RMEP_NOT_FOUND);
    }
    */
    else if(equal_ccm)
    {
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_equal_ccm(in_pkt,&receive_pkt_info));
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_update_mp(in_pkt,&receive_pkt_info));
    }
    else if(equal_bfd)
    {
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_equal_bfd(in_pkt,&receive_pkt_info));
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_update_mp(in_pkt,&receive_pkt_info));
    }
    else if(pkt_info->equal_dm)
    {
        /*do nothing, just send to cpu in hdr edit*/
        /*goto error cache*/
        if(oam_rx_proc_ether_ctl.dm_proc_by_cpu)
        {
            if((ETHER_1DM == parser_result->oam_type)
                || (ETHER_DMM == parser_result->oam_type)
                || (ETHER_DMR == parser_result->oam_type))
            {
                SET_BIT(pkt_info->exception, OAM_EXCEPTION_18_DM_TO_CPU);
                pkt_info->by_pass_all = TRUE;
            }
            else
            {
                SET_BIT(pkt_info->exception, OAM_EXCEPTION_15_MPLS_TP_DM_DLMDM_TO_CPU);
                pkt_info->by_pass_all = TRUE;
            }
        }
        else
        {
            if(MPLSTP_DLMDM == parser_result->oam_type)
            {
                SET_BIT(pkt_info->exception, OAM_EXCEPTION_15_MPLS_TP_DM_DLMDM_TO_CPU);
                pkt_info->by_pass_all = TRUE;
            }
        }
    }
    else if(pkt_info->equal_lm)
    {
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_equal_lm(in_pkt, &receive_pkt_info));
    }
    else if(pkt_info->equal_lb)
    {
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_equal_lb(in_pkt, &receive_pkt_info));
    }
    else if(pkt_info->equal_eth_tst)
    {
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_equal_tst(in_pkt, &receive_pkt_info));
    }
    else if(equal_lt)
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_24_SEND_EQUAL_LTM_LTR_TO_CPU);
        pkt_info->by_pass_all = TRUE;
    }
    else if(non_lbm_in_mip)
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_21_MIP_RECEIVE_NON_PROCESS_PDU);
        pkt_info->by_pass_all = TRUE;
    }
    else /*CONFIGURE_ERROR*/
    {
        /*high ccm is processed by lookup module now, so if goto here, config error!*/
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_7_DS_OR_CTRL_REG_CONFIG_ERROR);
    }

    DRV_IF_ERROR_RETURN(_cm_oam_receive_process_defect_proc(in_pkt));

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:       cm_oam_receive_process_handle
 * Purpose:    oam receive process
 * Parameters:
 * Input:      in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Output:     in_pkt -- pointer to buffer which save input packet and packet
 *                       header ,and processing information.
 * Return:     DRV_E_NONE = success.
 *             Other      = ErrorCode, please refer to DRV_E_XXX.
 * Note:       none.
****************************************************************************/
int32
cm_oam_receive_process_handle(oam_in_pkt_t* in_pkt)
{
    oam_pkt_info_t* pkt_info = (oam_pkt_info_t*)in_pkt->pkt_info;
    oam_parser_result_t* parser_result = (oam_parser_result_t*)pkt_info->parser_result;
    uint8  chip_id = in_pkt->chip_id;
    uint8  is_aps_oam_pdu = FALSE;
    uint32 cmd = 0;
    oam_rx_proc_ether_ctl_t oam_rx_proc_ether_ctl;

    if(OAM_PBB_BSI == pkt_info->rx_oam_type)
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_23_PBT_MM_DEFECT_PDU_TO_CPU);
    }

    pkt_info->rmep_index = 0;
    if(parser_result->high_version_oam)
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_3_HIGH_VERSION_ETH_OAM_TO_CPU);
        pkt_info->by_pass_all = TRUE;
    }

    pkt_info->by_pass_all |= hard_error;
    pkt_info->discard |= hard_error;

    if(pkt_info->by_pass_all)
    {
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_defect_proc(in_pkt));
        return DRV_E_NONE;
    }

    /* PDU_CHECK */
    DRV_IF_ERROR_RETURN(cm_oam_pdu_check(in_pkt));
    if(pkt_info->by_pass_all)
    {
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_defect_proc(in_pkt));
        return DRV_E_NONE;
    }

    /* TLV_OPTION */
    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl_t));
    cmd = DRV_IOR(OamRxProcEtherCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd,  &oam_rx_proc_ether_ctl));

    if(parser_result->tlv_options && oam_rx_proc_ether_ctl.ccm_with_unknown_tlv_tocpu)
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_8_ETH_CCM_TLV_OPTION);
    }

    is_aps_oam_pdu = (ETHER_APS == parser_result->oam_type)
      ||(ETHER_RAPS == parser_result->oam_type);

    if((pkt_info->rx_oam_type != OAM_NONE)&& is_aps_oam_pdu)
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_16_APS_PDU_TO_CPU);
        pkt_info->by_pass_all = TRUE;
    }

    if(pkt_info->is_slow_oam_type && (pkt_info->mep_index != 0))
    {
        SET_BIT(pkt_info->exception, OAM_EXCEPTION_9_SLOW_OAM_PDU_TO_CPU);
        pkt_info->by_pass_all = TRUE;
    }

    if(!pkt_info->by_pass_all)
    {
        DRV_IF_ERROR_RETURN(_cm_oam_recieve_process_rx_proc_oam(in_pkt));
    }
    else
    {
        DRV_IF_ERROR_RETURN(_cm_oam_receive_process_defect_proc(in_pkt));
    }

    return DRV_E_NONE;
}
