/****************************************************************************
* cm_qmgt_met_fifo.c: Provides MetFifo funciton.
*
* Copyright:(c)2011 Centec Networks Inc. All rights reserved.
*
* Revision:   V1.0.
* Author:     Zhouw.
* Date:       2010-10-21.
* Reason:     First Create.
*
* Modify History:
* Revision:   V2.0.
* Author:     Zhouw.
* Date:       2011-04-16.
* Reason:     Sync to SpecV2.0.
*
* Revision:   V4.28.2.
* Author:     ZhouW.
* Date:       2011-09-26.
* Reason:     Sync to SpecV4.28.2.
*
* Revision:   V4.29.3.
* Author:     Shenhg.
* Date:       2011-10-210.
* Reason:     Sync to SpecV4.29.3.
*
* Revision:   V5.6.0.
* Author:     Shenhg.
* Date:       2012-01-06.
* Reason:     Sync to SpecV5.6.0.
*
* Revision:   V5.13.0.
* Author:     ZhouW.
* Date:       2012-03-10.
* Reason:     Sync to SpecV5.13.0.
*
* Revision:   V5.15.0.
* Author:     ZhouW.
* Date:       2012-03-22.
* Reason:     Sync to SpecV5.15.0.
*
* Revision:     V5.15.2.
* Author:       ZhouW.
* Date:         2012-04-01.
* Reason:       Sync to SpecV5.15.2.
****************************************************************************/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "sal.h"
#include "ctckal.h"
#include "cm_lib.h"
#include "drv_lib.h"
#include "ctcutil_lib.h"

/****************************************************************************
*
* Defines and Macros
*
****************************************************************************/
/****************************************************************************
*
* Global and Declarations
*
****************************************************************************/
/* Mapping of Exception Vector to Exception Index */
/*-----------------------------------------------------------------------------------------------------------
   Egress           Exception Vector      Exception Index Mapping                   Exception Index Range
-------------------------------------------------------------------------------------------------------------*/
 /*   0             exceptionVector[7]     PortLog                                        31

      0             exceptionVector[6]     {8'h14, aclLogId3[1:0]}                        20 + (0-3)

      0             exceptionVector[5]     {8'h10, aclLogId2[1:0]}                        16 + (0-3)

      0             exceptionVector[4]     {8'h0C, aclLogId1[1:0]}                        12 + (0-3)

      0             exceptionVector[3]     {8'h08, aclLogId0[1:0]}                        8 + (0-3)

      0             exceptionVector[2]     {8'h04, l3SpanId[1:0]}                         4 + (0-3)

      0             exceptionVector[1]     {8'h00, l2SpanId[1:0]}                         0 + (0-3)

      0             exceptionVector[0]    exceptionNumber7:{4'hC0,exceptionSubIndex[5:0]} 192 + (0-63) exceptionSubIndex[5:0]

                                          exceptionNumber6:{4'h18,3'b110}                 30 + 0

                                          exceptionNumber5:{4'h18,3'b101}                 29 + 0

                                          exceptionNumber4:{4'h18,3'b100}                 28 + 0

                                          exceptionNumber3:{4'h80,exceptionSubIndex[5:0]} 128 + (0-63) exceptionSubIndex[5:0]

                                          exceptionNumber2:{4'h40,exceptionSubIndex[5:0]} 64 + (0-63)

                                          exceptionNumber1:{4'h18,3'b001}                 25 + 0

                                          exceptionNumber0:{4'h18,3'b000}                 24 + 0



      1             exceptionVector[7]     PortLog                                        27

      1             exceptionVector[6]     {8'h34, aclLogId3[1:0]}                        52 + (0-3)

      1             exceptionVector[5]     {8'h30, aclLogId2[1:0]}                        48 + (0-3)

      1             exceptionVector[4]     {8'h2C, aclLogId1[1:0]}                        44 + (0-3)

      1             exceptionVector[3]     {8'h28, aclLogId0[1:0]}                        40 + (0-3)

      1             exceptionVector[2]     {8'h24, l3SpanId[1:0]}                         36 + (0-3)

      1             exceptionVector[1]     {8'h20, l2SpanId[1:0]}                         32 + (0-3)

      1             exceptionVector[0]    exceptionNumber7:{4'h38, 3'b111}                56 + (0-7)

                                          ... ...

                                          exceptionNumber0:{4'h38, 3'b000}

    CPU LOG exceptionVector[8]

-------------------------------------------------------------------------------------------------------------*/

/****************************************************************************
*
* Functions
*
****************************************************************************/
/****************************************************************************
* Name:       _cm_qmgt_met_fifo_get_exception_index
* Purpose:    Map excep_table index according to exception bitmap.
* Parameters:
* Input:      vect_bit_index -- vector bit number
*             p_qpkt  -- queue management packet pointer
* Output:     p_excp_index -- pointer to save exception index.
* Return:     none.
* Note:       none.
****************************************************************************/
static void
_cm_qmgt_met_fifo_get_exception_index(uint8 vect_bit_index, queue_in_pkt_t *p_qpkt, uint8 *p_excp_index)
{
    queue_packet_info_t *ppkt_info = (queue_packet_info_t *)p_qpkt->pkt_info;
    fwd_ms_met_fifo_t *p_fwd_ms_met_fifo = (fwd_ms_met_fifo_t *)ppkt_info->ms_met_fifo;
    uint8 exception_sub_index =0;

    exception_sub_index = (p_fwd_ms_met_fifo->msg_metfifo.exception_sub_index5_2 << 2)
                                | (p_fwd_ms_met_fifo->msg_metfifo.exception_sub_index1_0);

    if (EXCEPTION_VECT_BIT_CPU_LOG == vect_bit_index)
    {
        *p_excp_index = 26;
        return;
    }

    if (!p_fwd_ms_met_fifo->msg_metfifo.egress_exception)     /* ingress direction exception */
    {
        switch (vect_bit_index)
        {
            case 7:
                *p_excp_index = 31;     /* ingress port log exception */
                break;

            case 6:
                *p_excp_index = 20 + p_fwd_ms_met_fifo->msg_metfifo.acl_log_id3;    /* ingress aclLog3 exception */
                break;

            case 5:
                *p_excp_index = 16 + p_fwd_ms_met_fifo->msg_metfifo.acl_log_id2;    /* ingress aclLog2 exception */
                break;

            case 4:
                *p_excp_index = 12 + p_fwd_ms_met_fifo->msg_metfifo.acl_log_id1;    /* ingress aclLog1 exception */
                break;

            case 3:
                *p_excp_index = 8 + p_fwd_ms_met_fifo->msg_metfifo.acl_log_id0;    /* ingress aclLog0 exception */
                break;

            case 2:
                *p_excp_index = 4 + p_fwd_ms_met_fifo->msg_metfifo.l3_span_id;    /* ingress l3 span id 0 exception */
                break;

            case 1:
                *p_excp_index = 0 + p_fwd_ms_met_fifo->msg_metfifo.l2_span_id;    /* ingress l2 span id 0 exception */
                break;

            case 0:
                if (p_fwd_ms_met_fifo->msg_metfifo.exception_number == 7)
                {
                    *p_excp_index = 192 + exception_sub_index;  /* 192 + (0-63) exceptionSubIndex[5:0] */

                }
                else if (p_fwd_ms_met_fifo->msg_metfifo.exception_number == 3)
                {
                    *p_excp_index = 128 + exception_sub_index;  /* 128 + (0-63) exceptionSubIndex[5:0] */

                }
                else if (p_fwd_ms_met_fifo->msg_metfifo.exception_number == 2)
                {
                    *p_excp_index = 64 + exception_sub_index;   /* 64 + (0-63) exceptionSubIndex[5:0] */

                }
                else
                {
                    *p_excp_index = 24 + p_fwd_ms_met_fifo->msg_metfifo.exception_number;
                }
                break;

            default:
                CMODEL_DEBUG_OUT_INFO("$$ERROR!INVALID ingress exception vection in MetFifo!");
                break;
        }

    }
    else                                                     /* egress direction exception */
    {
        switch (vect_bit_index)
        {
            case 7:
                *p_excp_index = 27;     /* egress port log exception */
                break;

            case 6:
                *p_excp_index = 52 + p_fwd_ms_met_fifo->msg_metfifo.acl_log_id3;    /* egress aclLog3 exception */
                break;

            case 5:
                *p_excp_index = 48 + p_fwd_ms_met_fifo->msg_metfifo.acl_log_id2;    /* egress aclLog2 exception */
                break;

            case 4:
                *p_excp_index = 44 + p_fwd_ms_met_fifo->msg_metfifo.acl_log_id1;    /* egress aclLog1 exception */
                break;

            case 3:
                *p_excp_index = 40 + p_fwd_ms_met_fifo->msg_metfifo.acl_log_id0;    /* egress aclLog0 exception */
                break;

            case 2:
                *p_excp_index = 36 + p_fwd_ms_met_fifo->msg_metfifo.l3_span_id;    /* egress l3 span id 0 exception */
                break;

            case 1:
                *p_excp_index = 32 + p_fwd_ms_met_fifo->msg_metfifo.l2_span_id;    /* egress l2 span id 0 exception */
                break;

            case 0:
                *p_excp_index = 56 + p_fwd_ms_met_fifo->msg_metfifo.exception_number;
                break;

            default:
                CMODEL_DEBUG_OUT_INFO("$$ERROR!INVALID egress exception vection in MetFifo!");
                break;
        }

    }

    return;
}

/****************************************************************************
* Name:       _cm_qmgt_met_fifo_do_exception_enqueue
* Purpose:    All exception enqueue handle.
* Parameters:
* Input:      p_qpkt  -- queue management packet pointer
* Output:     p_remain_rcd -- remained RCD value pointer
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
static int32
_cm_qmgt_met_fifo_do_exception_enqueue(queue_in_pkt_t *p_qpkt, uint16 *p_remain_rcd,
                                                            uint8 source_chip_id, uint16 exception_vector)
{
    queue_packet_info_t *p_pkt_info = (queue_packet_info_t *)p_qpkt->pkt_info;
    fwd_ms_met_fifo_t *p_ms_met_fifo = (fwd_ms_met_fifo_t *)p_pkt_info->ms_met_fifo;
    fwd_ms_enqueue_t *p_ms_enqueue = NULL;
    ds_met_fifo_excp_t ds_met_fifo_excp;
    met_fifo_ctl_t met_fifo_ctl;
    uint8 excp_index = 0;
    uint32 cmd = 0;
    int32 vect_bit_index = 0;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Met Fifo: Do Exception Enqueue");

    sal_memset(&met_fifo_ctl, 0, sizeof(met_fifo_ctl));
    cmd = DRV_IOR(MetFifoCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &met_fifo_ctl));

    for (vect_bit_index = (MAX_EXCEPTION_VECT_BIT_NUM - 1); vect_bit_index >= 0; vect_bit_index--)
    {
        /* select exception to process, convert the selected exception to exceptionIndex[7:0];
           lookup DsMetFifoException using exceptionIndex[7:0] */
        if (!IS_BIT_SET(exception_vector, vect_bit_index))
        {
            continue;
        }

        CLEAR_BIT(exception_vector, vect_bit_index);

        _cm_qmgt_met_fifo_get_exception_index(vect_bit_index, p_qpkt, &excp_index);

        cmd = DRV_IOR(DsMetFifoExcp_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, excp_index, cmd, &ds_met_fifo_excp));

        p_ms_enqueue = (fwd_ms_enqueue_t *)sal_malloc(sizeof(fwd_ms_enqueue_t));
        if (NULL == p_ms_enqueue)
        {
            return DRV_E_NO_MEMORY;
        }
        sal_memset(p_ms_enqueue, 0, sizeof(fwd_ms_enqueue_t));

        /* For every MsEnqueue default value, can be changed by the following assignment */
        p_ms_enqueue->msg_enqueue.src_queue_select = p_ms_met_fifo->msg_metfifo.src_queue_select;
        p_ms_enqueue->msg_enqueue.from_fabric = p_ms_met_fifo->msg_metfifo.from_fabric;
        p_ms_enqueue->msg_enqueue.head_buffer_ptr = p_ms_met_fifo->msg_metfifo.head_buffer_ptr;
        p_ms_enqueue->msg_enqueue.tail_buffer_ptr = p_ms_met_fifo->msg_metfifo.tail_buffer_ptr;
        p_ms_enqueue->msg_enqueue.head_buf_offset = p_ms_met_fifo->msg_metfifo.head_buf_offset;
        p_ms_enqueue->msg_enqueue.buffer_count = p_ms_met_fifo->msg_metfifo.buffer_count;
        p_ms_enqueue->msg_enqueue.header_hash = p_ms_met_fifo->msg_metfifo.header_hash;
        p_ms_enqueue->msg_enqueue.packet_length = p_ms_met_fifo->msg_metfifo.packet_length;
        p_ms_enqueue->msg_enqueue.resource_group_id = p_ms_met_fifo->msg_metfifo.resource_group_id;
        p_ms_enqueue->msg_enqueue.critical_packet = p_ms_met_fifo->msg_metfifo.critical_packet;
        p_ms_enqueue->msg_enqueue.mcast_rcd = p_ms_met_fifo->msg_metfifo.mcast_rcd;
        p_ms_enqueue->msg_enqueue.service_id = p_ms_met_fifo->msg_metfifo.service_id;
        p_ms_enqueue->msg_enqueue.priority = p_ms_met_fifo->msg_metfifo.priority;
        p_ms_enqueue->msg_enqueue.color = p_ms_met_fifo->msg_metfifo.color;
        p_ms_enqueue->msg_enqueue.rx_oam = p_ms_met_fifo->msg_metfifo.rx_oam;
        p_ms_enqueue->msg_enqueue.oam_dest_chip_id = p_ms_met_fifo->msg_metfifo.oam_dest_chip_id;
        p_ms_enqueue->msg_enqueue.fid = p_ms_met_fifo->msg_metfifo.fid;
        p_ms_enqueue->msg_enqueue.rx_oam_type = (p_ms_met_fifo->msg_metfifo.rx_oam_type3_2<<2)
                                                | p_ms_met_fifo->msg_metfifo.rx_oam_type1_0;
        p_ms_enqueue->msg_enqueue.flow_id = p_ms_met_fifo->msg_metfifo.flow_id;
        p_ms_enqueue->msg_enqueue.payload_offset = p_ms_met_fifo->msg_metfifo.payload_offset;
        p_ms_enqueue->msg_enqueue.ecn_en = p_ms_met_fifo->msg_metfifo.ecn_en;
        p_ms_enqueue->msg_enqueue.ecn_aware = p_ms_met_fifo->msg_metfifo.ecn_aware;

        p_ms_enqueue->msg_enqueue.length_adjust_type = p_ms_met_fifo->msg_metfifo.length_adjust_type;
        p_ms_enqueue->msg_enqueue.c2c_check_disable = p_ms_met_fifo->msg_metfifo.c2c_check_disable;
        p_ms_enqueue->msg_enqueue.operation_type = p_ms_met_fifo->msg_metfifo.operation_type;

        p_ms_enqueue->msg_enqueue.src_sgmac_group_id = p_ms_met_fifo->msg_metfifo.src_sgmac_group_id;
        p_ms_enqueue->msg_enqueue.old_dest_map = p_ms_met_fifo->msg_metfifo.old_dest_map;

        p_ms_enqueue->msg_enqueue.dest_select = FALSE;
        p_ms_enqueue->msg_enqueue.pt_enable = FALSE;

        p_ms_enqueue->msg_enqueue.source_chip_id = source_chip_id;

        p_ms_enqueue->msg_enqueue.enqueue_discard = FALSE;

        if ((0 != exception_vector) || (!p_ms_met_fifo->msg_metfifo.dest_id_discard))
        {
            p_ms_enqueue->msg_enqueue.rcd = 1;
            p_ms_enqueue->msg_enqueue.last_enqueue = FALSE;
        }
        else /* last exception*/
        {
            p_ms_enqueue->msg_enqueue.rcd = (*p_remain_rcd)& 0x7F;
            p_ms_enqueue->msg_enqueue.last_enqueue = TRUE;
        }

        (*p_remain_rcd)--;


        p_ms_enqueue->msg_enqueue.next_hop_ext = ds_met_fifo_excp.next_hop_ext;
        p_ms_enqueue->msg_enqueue.length_adjust_type = ds_met_fifo_excp.length_adjust_type;

        p_ms_enqueue->msg_enqueue.dest_map = ds_met_fifo_excp.dest_map;  /* use queueSelType */

        p_ms_enqueue->msg_enqueue.dest_select = TRUE;
        p_ms_enqueue->msg_enqueue.queue_on_chip_id = FALSE;
        p_ms_enqueue->msg_enqueue.replicated_met = FALSE;

        p_ms_enqueue->msg_enqueue.replication_ctl &= 0xFFF;
        p_ms_enqueue->msg_enqueue.replication_ctl |= (p_ms_met_fifo->msg_metfifo.src_sgmac_group_id << 12);

        p_ms_enqueue->msg_enqueue.replication_ctl &= 0xFF800;
        p_ms_enqueue->msg_enqueue.replication_ctl |= (p_ms_met_fifo->msg_metfifo.exception_packet_type << 8)
                                                      | excp_index;

        if(p_ms_met_fifo->msg_metfifo.exception_from_sgmac)
        {
            SET_BIT(p_ms_enqueue->msg_enqueue.replication_ctl, 11);
        }
        else
        {
            CLEAR_BIT(p_ms_enqueue->msg_enqueue.replication_ctl, 11);
        }
        p_ms_enqueue->msg_enqueue.replication_ctl_ext = 0;

        p_ms_enqueue->msg_enqueue.src_queue_select = FALSE;
        p_ms_enqueue->msg_enqueue.rx_oam = FALSE;

        p_ms_enqueue->msg_enqueue.dest_sgmac_group_id = 0;
        if (met_fifo_ctl.exception_reset_src_sgmac)
        {
            p_ms_enqueue->msg_enqueue.src_sgmac_group_id = 0;
        }

        /* Remained fields */
        p_ms_enqueue->msg_enqueue.msg_type = p_ms_met_fifo->msg_metfifo.msg_type;
        list_add_tail(&p_ms_enqueue->head, &p_pkt_info->ms_enqueue_list);

    }

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_qmgt_met_fifo_do_unicast_enqueue
* Purpose:    do unicast enqueue handle.
* Parameters:
* Input:      p_qpkt  -- queue management packet pointer
* Output:     p_remain_rcd -- remained RCD value
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
static int32
_cm_qmgt_met_fifo_do_unicast_enqueue(queue_in_pkt_t *p_qpkt, uint16 *p_remain_rcd,
                                                        uint8 source_chip_id)
{
    queue_packet_info_t *p_pkt_info = (queue_packet_info_t *)p_qpkt->pkt_info;
    fwd_ms_met_fifo_t *p_ms_met_fifo = (fwd_ms_met_fifo_t *)p_pkt_info->ms_met_fifo;
    fwd_ms_enqueue_t *p_ms_enqueue = NULL;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Met Fifo: Do Unicast Enqueue");

    p_ms_enqueue = (fwd_ms_enqueue_t *)sal_malloc(sizeof(fwd_ms_enqueue_t));
    if(NULL == p_ms_enqueue)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(p_ms_enqueue, 0, sizeof(fwd_ms_enqueue_t));

    /* For every MsEnqueue default value, can be changed by the following assignment */
    p_ms_enqueue->msg_enqueue.src_queue_select = p_ms_met_fifo->msg_metfifo.src_queue_select;
    p_ms_enqueue->msg_enqueue.from_fabric = p_ms_met_fifo->msg_metfifo.from_fabric;
    p_ms_enqueue->msg_enqueue.head_buffer_ptr = p_ms_met_fifo->msg_metfifo.head_buffer_ptr;
    p_ms_enqueue->msg_enqueue.tail_buffer_ptr = p_ms_met_fifo->msg_metfifo.tail_buffer_ptr;
    p_ms_enqueue->msg_enqueue.head_buf_offset = p_ms_met_fifo->msg_metfifo.head_buf_offset;
    p_ms_enqueue->msg_enqueue.buffer_count = p_ms_met_fifo->msg_metfifo.buffer_count;
    p_ms_enqueue->msg_enqueue.header_hash = p_ms_met_fifo->msg_metfifo.header_hash;
    p_ms_enqueue->msg_enqueue.packet_length = p_ms_met_fifo->msg_metfifo.packet_length;
    p_ms_enqueue->msg_enqueue.resource_group_id = p_ms_met_fifo->msg_metfifo.resource_group_id;
    p_ms_enqueue->msg_enqueue.critical_packet = p_ms_met_fifo->msg_metfifo.critical_packet;
    p_ms_enqueue->msg_enqueue.mcast_rcd = p_ms_met_fifo->msg_metfifo.mcast_rcd;
    p_ms_enqueue->msg_enqueue.service_id = p_ms_met_fifo->msg_metfifo.service_id;
    p_ms_enqueue->msg_enqueue.priority = p_ms_met_fifo->msg_metfifo.priority;
    p_ms_enqueue->msg_enqueue.color = p_ms_met_fifo->msg_metfifo.color;
    p_ms_enqueue->msg_enqueue.rx_oam = p_ms_met_fifo->msg_metfifo.rx_oam;
    p_ms_enqueue->msg_enqueue.oam_dest_chip_id = p_ms_met_fifo->msg_metfifo.oam_dest_chip_id;
    p_ms_enqueue->msg_enqueue.fid = p_ms_met_fifo->msg_metfifo.fid;
    p_ms_enqueue->msg_enqueue.rx_oam_type = (p_ms_met_fifo->msg_metfifo.rx_oam_type3_2<<2)
                                            | p_ms_met_fifo->msg_metfifo.rx_oam_type1_0;
    p_ms_enqueue->msg_enqueue.flow_id = p_ms_met_fifo->msg_metfifo.flow_id;
    p_ms_enqueue->msg_enqueue.payload_offset = p_ms_met_fifo->msg_metfifo.payload_offset;
    p_ms_enqueue->msg_enqueue.ecn_en = p_ms_met_fifo->msg_metfifo.ecn_en;
    p_ms_enqueue->msg_enqueue.ecn_aware = p_ms_met_fifo->msg_metfifo.ecn_aware;

    p_ms_enqueue->msg_enqueue.length_adjust_type = p_ms_met_fifo->msg_metfifo.length_adjust_type;
    p_ms_enqueue->msg_enqueue.c2c_check_disable = p_ms_met_fifo->msg_metfifo.c2c_check_disable;
    p_ms_enqueue->msg_enqueue.operation_type = p_ms_met_fifo->msg_metfifo.operation_type;

    p_ms_enqueue->msg_enqueue.src_sgmac_group_id = p_ms_met_fifo->msg_metfifo.src_sgmac_group_id;
    p_ms_enqueue->msg_enqueue.old_dest_map = p_ms_met_fifo->msg_metfifo.old_dest_map;

    p_ms_enqueue->msg_enqueue.dest_select = FALSE;
    p_ms_enqueue->msg_enqueue.pt_enable = FALSE;

    p_ms_enqueue->msg_enqueue.source_chip_id = source_chip_id;


    p_ms_enqueue->msg_enqueue.enqueue_discard = FALSE;
    p_ms_enqueue->msg_enqueue.rcd = (*p_remain_rcd)&0x7F;
    p_ms_enqueue->msg_enqueue.last_enqueue = TRUE; /* last en-queue message */
    p_ms_enqueue->msg_enqueue.dest_map = p_ms_met_fifo->msg_metfifo.old_dest_map;
    p_ms_enqueue->msg_enqueue.next_hop_ext = p_ms_met_fifo->msg_metfifo.next_hop_ext;

    p_ms_enqueue->msg_enqueue.replication_ctl = 0;
    p_ms_enqueue->msg_enqueue.replicated_met = FALSE;
    p_ms_enqueue->msg_enqueue.replication_ctl_ext = 0;

    /* when not local switching, queue on chip ID*/
    p_ms_enqueue->msg_enqueue.queue_on_chip_id = (!p_ms_met_fifo->msg_metfifo.local_switching);

    p_ms_enqueue->msg_enqueue.dest_sgmac_group_id = 0;

    /* remained fields */
    p_ms_enqueue->msg_enqueue.msg_type = p_ms_met_fifo->msg_metfifo.msg_type;
    list_add_tail(&p_ms_enqueue->head, &p_pkt_info->ms_enqueue_list);

    return DRV_E_NONE;
}

/****************************************************************************
* Name:       _cm_qmgt_met_fifo_do_multicast_enqueue
* Purpose:    do multicast enqueue handle.
* Parameters:
* Input:      p_qpkt  -- queue management packet pointer
* Output:     p_remain_rcd -- remained RCD value
* Return:     DRV_E_NONE = success.
*             Other = Error Code, please refer to DRV_E_XXX.
* Note:       none.
****************************************************************************/
static int32
_cm_qmgt_met_fifo_do_multicast_enqueue(queue_in_pkt_t *p_qpkt,
                                                        uint16 *p_remain_rcd,
                                                        uint8 source_chip_id,
                                                        uint16 source_port)
{
    #define PORT_BITMAP_MAX_LENGTH 56
    queue_packet_info_t *p_pkt_info = (queue_packet_info_t *)p_qpkt->pkt_info;
    fwd_ms_met_fifo_t *p_ms_met_fifo = (fwd_ms_met_fifo_t *)p_pkt_info->ms_met_fifo;
    fwd_ms_enqueue_t *p_ms_enqueue = NULL;
    ds_met_entry_t ds_met_entry;
    met_fifo_ctl_t met_fifo_ctl;
    ds_aps_bridge_t ds_aps_brg_0;
    ds_aps_bridge_t ds_aps_brg_1;
    ds_aps_bridge_t ds_aps_brg_2;

    uint32 aps_group_id = 0;
    uint8 protecting_en = 0;
    uint32 cmd = 0;
    uint8 end_replication = FALSE;
    uint16 global_dest_port = 0;
    uint32 dsmet_port_bitmap31_0 = 0, dsmet_port_bitmap55_32 = 0, dsmet_logic_dest_port = 0;
    uint32 ds_met_entry_index = 0;
    uint32 end_remote_chip = 0;
    uint8 port_id = 0xFF;
    int8 index = 0;
    uint8 source_port_5_0 = 0;
    bool end_local_rep_from_fabric = FALSE;
    uint8 next_aps_bridge_en1 = FALSE, next_aps_bridge_en2 = FALSE;
    uint16 next_aps_group_id1 = 0, next_aps_group_id2 = 0;

    uint8 is_met = FALSE, end_local_rep = FALSE, is_link_aggregation = FALSE, remote_chip = FALSE, nexthop_ext = FALSE;
    uint16 ucast_id = 0;
    uint32 replication_ctl = 0;
    uint8 last_dest_map_15_12 = 0, replication_ctl_ext = 0;
    uint8 c2c_end_ring = FALSE, is_sgmac_discard_source_replication = FALSE;
    uint8 met_entry_sgmac_group_id = 0;
    uint8 phy_port_check_discard = FALSE;
    uint8 l3_mcast = FALSE;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Met Fifo: Do Multicast Enqueue");

    /* INIT_MET_PTR */
    /* First MsMetFifo.{nextMetEntryPtr[14;0],portBitmap[55:0]} initialized */
    /* multicast group 0 is reserved for internal used */
    sal_memset(&met_fifo_ctl, 0, sizeof(met_fifo_ctl_t));
    cmd = DRV_IOR(MetFifoCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &met_fifo_ctl));

    if (met_fifo_ctl.from_fabric_multicast_en
        && p_ms_met_fifo->msg_metfifo.from_fabric)
    {
        /**** in spec ds, there are no nextMetEntryPtr[14:0] and portBitmap[55:0],
           cmodel should add the two fields by self    *****/
        p_ms_met_fifo->next_met_entry_ptr = (p_ms_met_fifo->msg_metfifo.old_dest_map & 0x7FFF)
                            + met_fifo_ctl.local_met_base;
    }
    else
    {
        p_ms_met_fifo->next_met_entry_ptr = p_ms_met_fifo->msg_metfifo.old_dest_map & 0x7FFF;
    }

    p_ms_met_fifo->next_met_entry_ptr += met_fifo_ctl.mcast_first_met_base; /* first Met be continuous */

    p_ms_met_fifo->port_bitmap_31_0 = 0;
    p_ms_met_fifo->port_bitmap_55_32 = 0;

    /* RETRIEVE_MET */
    for(;;)
    {

        if ((p_ms_met_fifo->port_bitmap_31_0 == 0)
            && (p_ms_met_fifo->port_bitmap_55_32 == 0))
        {
            sal_memset(&ds_met_entry, 0, sizeof(ds_met_entry_t));
            ds_met_entry_index = p_ms_met_fifo->next_met_entry_ptr;
            cmd = DRV_IOR(DsMetEntry_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, ds_met_entry_index, cmd, &ds_met_entry));

            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR,
                                 "[Debug Table Index]: %s[0x%X]\n",
                                 "DsMetEntry_t",
                                 ds_met_entry_index);
            CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_TABLE_PTR,
                                 "DsMetEntry.nextMetEntryPtr: 0x%X\n",
                                 ds_met_entry.next_met_entry_ptr);

            p_ms_met_fifo->current_met_entry = p_ms_met_fifo->next_met_entry_ptr;

            is_met = ds_met_entry.is_met;
            p_ms_met_fifo->next_met_entry_ptr = ds_met_entry.next_met_entry_ptr;
            end_local_rep = ds_met_entry.end_local_rep;
            is_link_aggregation = ds_met_entry.is_link_aggregation;
            remote_chip = ds_met_entry.remote_chip;
            replication_ctl = ds_met_entry.replication_ctl;
            replication_ctl_ext = IS_BIT_SET(ds_met_entry.logic_port_check_en, 2);
            ucast_id = (ds_met_entry.ucast_id15_14 << 14)
                        | (ds_met_entry.ucast_id13 << 13)
                        | (IS_BIT_SET(ds_met_entry.logic_port_check_en, 1) << 12)
                        | (ds_met_entry.ucast_id_low);
            nexthop_ext = ds_met_entry.next_hop_ext;
        }
        else
        {
            end_local_rep = p_ms_met_fifo->end_local_rep;
            is_met = TRUE;
            p_ms_met_fifo->current_met_entry = p_ms_met_fifo->current_met_entry;
        }

        if (met_fifo_ctl.l3_mcast_mode_en &&
            ((met_fifo_ctl.l3_mcast_met_ptr_valid0 && p_ms_met_fifo->current_met_entry > met_fifo_ctl.l3_mcast_met_min_ptr0
                                                  && p_ms_met_fifo->current_met_entry < met_fifo_ctl.l3_mcast_met_max_ptr0) ||
            (met_fifo_ctl.l3_mcast_met_ptr_valid1 && p_ms_met_fifo->current_met_entry > met_fifo_ctl.l3_mcast_met_min_ptr1
                                                  && p_ms_met_fifo->current_met_entry < met_fifo_ctl.l3_mcast_met_max_ptr1)))
        {
            l3_mcast = TRUE;
        }

        p_ms_enqueue = (fwd_ms_enqueue_t *)sal_malloc(sizeof(fwd_ms_enqueue_t));
        if (NULL == p_ms_enqueue)
        {
            return DRV_E_NO_MEMORY;
        }
        sal_memset(p_ms_enqueue, 0, sizeof(fwd_ms_enqueue_t));

        /* For every MsEnqueue default value, can be changed by the following assignment */
        p_ms_enqueue->msg_enqueue.src_queue_select = p_ms_met_fifo->msg_metfifo.src_queue_select;
        p_ms_enqueue->msg_enqueue.from_fabric = p_ms_met_fifo->msg_metfifo.from_fabric;
        p_ms_enqueue->msg_enqueue.head_buffer_ptr = p_ms_met_fifo->msg_metfifo.head_buffer_ptr;
        p_ms_enqueue->msg_enqueue.tail_buffer_ptr = p_ms_met_fifo->msg_metfifo.tail_buffer_ptr;
        p_ms_enqueue->msg_enqueue.head_buf_offset = p_ms_met_fifo->msg_metfifo.head_buf_offset;
        p_ms_enqueue->msg_enqueue.buffer_count = p_ms_met_fifo->msg_metfifo.buffer_count;
        p_ms_enqueue->msg_enqueue.header_hash = p_ms_met_fifo->msg_metfifo.header_hash;
        p_ms_enqueue->msg_enqueue.packet_length = p_ms_met_fifo->msg_metfifo.packet_length;
        p_ms_enqueue->msg_enqueue.resource_group_id = p_ms_met_fifo->msg_metfifo.resource_group_id;
        p_ms_enqueue->msg_enqueue.critical_packet = p_ms_met_fifo->msg_metfifo.critical_packet;
        p_ms_enqueue->msg_enqueue.mcast_rcd = p_ms_met_fifo->msg_metfifo.mcast_rcd;
        p_ms_enqueue->msg_enqueue.service_id = p_ms_met_fifo->msg_metfifo.service_id;
        p_ms_enqueue->msg_enqueue.priority = p_ms_met_fifo->msg_metfifo.priority;
        p_ms_enqueue->msg_enqueue.color = p_ms_met_fifo->msg_metfifo.color;
        p_ms_enqueue->msg_enqueue.rx_oam = p_ms_met_fifo->msg_metfifo.rx_oam;
        p_ms_enqueue->msg_enqueue.oam_dest_chip_id = p_ms_met_fifo->msg_metfifo.oam_dest_chip_id;
        p_ms_enqueue->msg_enqueue.fid = p_ms_met_fifo->msg_metfifo.fid;
        p_ms_enqueue->msg_enqueue.rx_oam_type = (p_ms_met_fifo->msg_metfifo.rx_oam_type3_2<<2)
                                                | p_ms_met_fifo->msg_metfifo.rx_oam_type1_0;
        p_ms_enqueue->msg_enqueue.flow_id = p_ms_met_fifo->msg_metfifo.flow_id;
        p_ms_enqueue->msg_enqueue.payload_offset = p_ms_met_fifo->msg_metfifo.payload_offset;
        p_ms_enqueue->msg_enqueue.ecn_en = p_ms_met_fifo->msg_metfifo.ecn_en;
        p_ms_enqueue->msg_enqueue.ecn_aware = p_ms_met_fifo->msg_metfifo.ecn_aware;

        p_ms_enqueue->msg_enqueue.length_adjust_type = p_ms_met_fifo->msg_metfifo.length_adjust_type;
        p_ms_enqueue->msg_enqueue.c2c_check_disable = p_ms_met_fifo->msg_metfifo.c2c_check_disable;
        p_ms_enqueue->msg_enqueue.operation_type = p_ms_met_fifo->msg_metfifo.operation_type;

        p_ms_enqueue->msg_enqueue.src_sgmac_group_id = p_ms_met_fifo->msg_metfifo.src_sgmac_group_id;
        p_ms_enqueue->msg_enqueue.old_dest_map = p_ms_met_fifo->msg_metfifo.old_dest_map;

        p_ms_enqueue->msg_enqueue.dest_select = FALSE;
        p_ms_enqueue->msg_enqueue.pt_enable = FALSE;
        p_ms_enqueue->msg_enqueue.source_chip_id = source_chip_id;


        p_ms_enqueue->msg_enqueue.msg_type = p_ms_met_fifo->msg_metfifo.msg_type;

       /* REPLICATION */
        if ((p_ms_met_fifo->port_bitmap_31_0 == 0)
            && (p_ms_met_fifo->port_bitmap_55_32 == 0))    /* use DsMetEntry */
        {

            /* APS process */
            if ((!ds_met_entry.mcast_mode) && ds_met_entry.aps_bridge_en)
            {
                /* workingMet         protectingMet
                    local               local
                    local               linkAgg
                    local               remote
                    linkAgg             local
                    linkAgg             linkAgg
                    linkAgg             remote
                    remote              local
                    remote              linkAgg
                    remote              remote
                */

                /* DsApsBridge.workingDestMap = workingDestMap[21:0]/{10'd0, workingUcastId[11:0]} */
                /* DsApsBridge.protectingDestMap = protectingDestMap[21:0]/{10'd0, protectingUcastId[11:0]} */

                /* APS bridge 0 */
                sal_memset(&ds_aps_brg_0, 0, sizeof(ds_aps_brg_0));
                cmd = DRV_IOR(DsApsBridge_t, DRV_ENTRY_FLAG);
                aps_group_id = ds_met_entry.ucast_id_low; /* share field: apsGroupId[11:0] */
                DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, aps_group_id, cmd, &ds_aps_brg_0));

                protecting_en = ds_aps_brg_0.protecting_en;
                if (protecting_en)
                {
                    ucast_id = ds_aps_brg_0.protecting_ucast_id & 0xFFFF;
                    end_local_rep = ds_aps_brg_0.protecting_end_local_rep;
                    is_link_aggregation = ds_aps_brg_0.protecting_is_link_aggregation;
                    remote_chip = ds_aps_brg_0.protecting_remote_chip;
                }
                else
                {
                    ucast_id = ds_aps_brg_0.working_ucast_id & 0xFFFF;
                    end_local_rep = ds_aps_brg_0.working_end_local_rep;
                    is_link_aggregation = ds_aps_brg_0.working_is_link_aggregation;
                    remote_chip = ds_aps_brg_0.working_remote_chip;
                }

                if (ds_aps_brg_0.replication_ctl_en)
                {
                    //==============bug4716 ECO begin ====================
                    //replication_ctl_ext = 0;

                    //if (protecting_en)
                    //{
                    //    replication_ctl = (ds_aps_brg_0.protecting_replication_ctl << 4);
                    //    nexthop_ext = ds_aps_brg_0.protecting_next_hop_ext;
                    //}
                    //else
                    //{
                    //    replication_ctl = (ds_aps_brg_0.working_replication_ctl << 4);
                    //    nexthop_ext = ds_aps_brg_0.working_next_hop_ext;
                    //}
                    if (protecting_en)
                    {
                        replication_ctl_ext = 0;
                        replication_ctl = ((replication_ctl>>4) + (nexthop_ext?2:1))<<4;
                    }
                    //==============bug4716 ECO end ====================
                }

                if (ds_aps_brg_0.protecting_en && ds_aps_brg_0.protecting_next_aps_bridge_en)
                {
                    next_aps_bridge_en1 = TRUE;
                    next_aps_group_id1 = ds_aps_brg_0.protecting_dest_map & 0xFFF;

                }
                else if ((!ds_aps_brg_0.protecting_en) && ds_aps_brg_0.working_next_aps_bridge_en)
                {
                    next_aps_bridge_en1 = TRUE;
                    next_aps_group_id1 = ds_aps_brg_0.working_dest_map & 0xFFF;

                }
                else
                {
                    next_aps_bridge_en1 = FALSE;
                }

                /* APS bridge 1 */
                if (next_aps_bridge_en1)
                {
                    sal_memset(&ds_aps_brg_1, 0, sizeof(ds_aps_brg_1));
                    cmd = DRV_IOR(DsApsBridge_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, next_aps_group_id1, cmd, &ds_aps_brg_1));

                    protecting_en = ds_aps_brg_1.protecting_en;
                    if (protecting_en)
                    {
                        ucast_id = ds_aps_brg_1.protecting_ucast_id & 0xFFFF;
                        end_local_rep = ds_aps_brg_1.protecting_end_local_rep;
                        is_link_aggregation = ds_aps_brg_1.protecting_is_link_aggregation;
                        remote_chip = ds_aps_brg_1.protecting_remote_chip;
                    }
                    else
                    {
                        ucast_id = ds_aps_brg_1.working_ucast_id & 0xFFFF;
                        end_local_rep = ds_aps_brg_1.working_end_local_rep;
                        is_link_aggregation = ds_aps_brg_1.working_is_link_aggregation;
                        remote_chip = ds_aps_brg_1.working_remote_chip;
                    }

                    //==============bug4716 ECO begin ====================
                    /*if (ds_aps_brg_1.replication_ctl_en)
                    {
                        replication_ctl_ext = 0;

                        if (protecting_en)
                        {
                            replication_ctl = (ds_aps_brg_1.protecting_replication_ctl << 4);
                            nexthop_ext = ds_aps_brg_1.protecting_next_hop_ext;
                        }
                        else
                        {
                            replication_ctl = (ds_aps_brg_1.working_replication_ctl << 4);
                            nexthop_ext = ds_aps_brg_1.working_next_hop_ext;
                        }
                    }*/
                    //==============bug4716 ECO end ====================

                    if (ds_aps_brg_1.protecting_en && ds_aps_brg_1.protecting_next_aps_bridge_en)
                    {
                        next_aps_bridge_en2 = TRUE;
                        next_aps_group_id2 = ds_aps_brg_1.protecting_dest_map & 0xFFF;
                    }
                    else if ((!ds_aps_brg_1.protecting_en) && ds_aps_brg_1.working_next_aps_bridge_en)
                    {
                        next_aps_bridge_en2 = TRUE;
                        next_aps_group_id2 = ds_aps_brg_1.working_dest_map & 0xFFF;
                    }
                    else
                    {
                        next_aps_bridge_en2 = FALSE;
                    }
                }

                /* APS bridge 2 */
                if (next_aps_bridge_en2)
                {
                    sal_memset(&ds_aps_brg_2, 0, sizeof(ds_aps_brg_2));

                    cmd = DRV_IOR(DsApsBridge_t, DRV_ENTRY_FLAG);
                    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, next_aps_group_id2, cmd, &ds_aps_brg_2));

                    protecting_en = ds_aps_brg_2.protecting_en;
                    if (protecting_en)
                    {
                        ucast_id = ds_aps_brg_2.protecting_ucast_id & 0xFFFF;
                        end_local_rep = ds_aps_brg_2.protecting_end_local_rep;
                        is_link_aggregation = ds_aps_brg_2.protecting_is_link_aggregation;
                        remote_chip = ds_aps_brg_2.protecting_remote_chip;
                    }
                    else
                    {
                        ucast_id = ds_aps_brg_2.working_ucast_id & 0xFFFF;
                        end_local_rep = ds_aps_brg_2.working_end_local_rep;
                        is_link_aggregation = ds_aps_brg_2.working_is_link_aggregation;
                        remote_chip = ds_aps_brg_2.working_remote_chip;
                    }
                    
                    //==============bug4716 ECO begin ====================
                    /*if (ds_aps_brg_2.replication_ctl_en)
                    {
                        replication_ctl_ext = 0;

                        if (protecting_en)
                        {
                            replication_ctl = (ds_aps_brg_2.protecting_replication_ctl << 4);
                            nexthop_ext = ds_aps_brg_2.protecting_next_hop_ext;
                        }
                        else
                        {
                            replication_ctl = (ds_aps_brg_2.working_replication_ctl << 4);
                            nexthop_ext = ds_aps_brg_2.working_next_hop_ext;
                        }
                    }*/
                    //==============bug4716 ECO end ====================
                }
            }

            if (met_fifo_ctl.stacking_mcast_end_en)
            {
                end_remote_chip = met_fifo_ctl.end_remote_chip;
            }
            /* DsMetEntry.nextHopExt = nextHopExt / portBitmap[31] */
            /* DsMetEntry.logicDestPort7_6 = logicDestPort7_6 / portBitmap[30:29] */
            /* DsMetEntry.leafCheckEn = leafCheckEn / portBitmap[28] */
            /* DsMetEntry.ucastId13 = ucastId[13]/ portBitmap[27] */
            /* DsMetEntry.logicPortTypeCheck = logicPortTypeCheck / portBitmap[26] */
            /* DsMetEntry.logicDestPort5 = logicDestPort5 / ptEnable / portBitmap[25] */
            /* DsMetEntry.logicDestPort4_0 = logicDestPort[4:0] / portBitmap[24:20] */
            /* DsMetEntry.replicationCtl = replicationCtl[19:0] / portBitmap[19:0] */
            dsmet_port_bitmap31_0 = (ds_met_entry.next_hop_ext<<31)
                                    | (ds_met_entry.logic_dest_port7_6<<29)
                                    | (ds_met_entry.leaf_check_en<<28)
                                    | (ds_met_entry.ucast_id13<<27)
                                    | (ds_met_entry.logic_port_type_check<<26)
                                    | (ds_met_entry.logic_dest_port5<<25)
                                    | (ds_met_entry.logic_dest_port4_0<<20)
                                    | ds_met_entry.replication_ctl;

            /* DsMetEntry.logicDestPort12_11 = logicDestPort[12:11] / endRemoteChip[14:13] / portBitmap[55:54] */
            /* DsMetEntry.logicDestPort10 = logicDestPort[10] / stackingLeft  / portBitmap[53] */
            /* DsMetEntry.portBitmap52_50 */
            /* DsMetEntry.logicPortCheckEn = { 1'b0, ucastId12, logicPortCheckEn } / portBitmap[49:47] */
            /* DsMetEntry.logicDestPort9_8 = logicDestPort[9:8] / endRemoteChip[12:11] / portBitmap[46:45] */
            /* DsMetEntry.apsBridgeEn = apsBridgeEn / portBitmap[44] */
            /* DsMetEntry.ucastIdLow = ucastId[11:0]/{1d'0,sgmacGroupId[5:0], destChipId[4:0]}/portBitmap[43:32]/apsGroupId[11:0] */
            dsmet_port_bitmap55_32 = (ds_met_entry.logic_dest_port12_11<<22)
                                    | (ds_met_entry.logic_dest_port10<<21)
                                    | (ds_met_entry.port_bitmap52_50<<18)
                                    | (ds_met_entry.logic_port_check_en<<15)
                                    | (ds_met_entry.logic_dest_port9_8<<13)
                                    | (ds_met_entry.aps_bridge_en<<12)
                                    | ds_met_entry.ucast_id_low;

            end_local_rep_from_fabric
                = (end_local_rep && p_ms_met_fifo->msg_metfifo.from_fabric && (!met_fifo_ctl.force_replication_from_fabric));
            /* C2C end ring */
            c2c_end_ring = p_ms_met_fifo->msg_metfifo.from_fabric && (source_chip_id == met_fifo_ctl.chip_id)
                            && end_local_rep && (p_ms_met_fifo->msg_metfifo.operation_type == OPERATION_TYPE_C2C)
                            && p_ms_met_fifo->msg_metfifo.c2c_check_disable;

            end_replication = end_local_rep_from_fabric || ((*p_remain_rcd) == 1) ||  c2c_end_ring;

            /* discard in METFIFO */
            /* DsMetEntry.ucastIdLow = ucastId[11:0]/{1d'0,sgmacGroupId[5:0], destChipId[4:0]}/
                            portBitmap[43:32]/apsGroupId[11:0] */
            if (((ucast_id >> 5)&0x3F) < 32)
            {
                is_sgmac_discard_source_replication
                    = IS_BIT_SET(met_fifo_ctl.sgmac_discard_source_replication31_0, ((ucast_id >> 5)&0x3F));
            }
            else if (((ucast_id >> 5)&0x3F) < 64)
            {
                is_sgmac_discard_source_replication
                    = IS_BIT_SET(met_fifo_ctl.sgmac_discard_source_replication63_32, ((ucast_id >> 5)&0x3F) - 32);
            }

            met_entry_sgmac_group_id = ((ucast_id >> 5)&0x3F);
            p_ms_enqueue->msg_enqueue.enqueue_discard
                        = (((0x7FFF == (ucast_id & 0x7FFF)) && (!ds_met_entry.mcast_mode))
                            || (p_ms_met_fifo->msg_metfifo.from_fabric && remote_chip && met_fifo_ctl.discard_met_loop) /* from unlink to unlink */
                            || (p_ms_met_fifo->msg_metfifo.from_fabric && remote_chip
                                && met_fifo_ctl.uplink_reflect_check_en
                                && (met_entry_sgmac_group_id != 0) /* ucastId[10:5] */
                                && (p_ms_met_fifo->msg_metfifo.src_sgmac_group_id == ((ucast_id >> 5)&0x3F))) /* Reflect discard */
                            || (remote_chip && !met_fifo_ctl.stacking_broken
                                && IS_BIT_SET(end_remote_chip, source_chip_id)
                                && ((p_ms_met_fifo->msg_metfifo.operation_type != OPERATION_TYPE_C2C)|| (!p_ms_met_fifo->msg_metfifo.c2c_check_disable)))/* broken for cross stacking */
                            || ((!p_ms_met_fifo->msg_metfifo.from_fabric) && remote_chip
                                &&(!met_fifo_ctl.stacking_broken) && is_sgmac_discard_source_replication /* broken for local-originated to each destSgmacGroupId */
                                && ((p_ms_met_fifo->msg_metfifo.operation_type != OPERATION_TYPE_C2C)|| (!p_ms_met_fifo->msg_metfifo.c2c_check_disable)))
                            || ((!p_ms_met_fifo->msg_metfifo.from_fabric) && (!remote_chip)
                                && (p_ms_met_fifo->msg_metfifo.operation_type == OPERATION_TYPE_C2C))); /* discard packet to CPU when not cross-stacking */

            if (p_ms_enqueue->msg_enqueue.enqueue_discard)
            {
                CMODEL_DEBUG_OUT_INFO("enqueueDiscard in MetFifo!!, file:%s line:%d function:%s******\n",
                                      __FILE__, __LINE__, __FUNCTION__);
            }

            if (!ds_met_entry.mcast_mode)   /* Normal */
            {
                p_ms_enqueue->msg_enqueue.replication_ctl = (replication_ctl & 0xFFFFF);
                p_ms_enqueue->msg_enqueue.replication_ctl_ext = replication_ctl_ext;
                p_ms_enqueue->msg_enqueue.next_hop_ext = nexthop_ext;

                if (!ds_met_entry.logic_port_type_check)
                {
                    /* DsMetEntry.logicDestPort5 = logicDestPort5 / ptEnable / portBitmap[25] */
                    p_ms_enqueue->msg_enqueue.pt_enable = ds_met_entry.logic_dest_port5;
                }

                /* Generate destMap */
                if (IS_BIT_SET(p_ms_met_fifo->msg_metfifo.old_dest_map, 21))
                {
                    SET_BIT(p_ms_enqueue->msg_enqueue.dest_map, 21);
                }
                else
                {
                    CLEAR_BIT(p_ms_enqueue->msg_enqueue.dest_map, 21);
                }

                if (remote_chip
                    || (met_fifo_ctl.local_chip_queue_on_chip_id
                       && (!p_ms_met_fifo->msg_metfifo.from_fabric)))   /* to remote */
                {
                    p_ms_enqueue->msg_enqueue.queue_on_chip_id = TRUE; /* mcastId is valid */
                    p_ms_enqueue->msg_enqueue.replicated_met = FALSE;

                    /* overwrite destchipid */
                    /* DsMetEntry.ucastIdLow is also used as {1d'0,sgmacGroupId[5:0], destChipId[4:0]} */
                    SET_DESTCHIPID_IN_DESTMAP(p_ms_enqueue->msg_enqueue.dest_map, (ucast_id & 0x1F));

                    /* MsEnqueue.destMap[15:0] = MsMetFifo.oldDestMap[15:0] */
                    p_ms_enqueue->msg_enqueue.dest_map &= 0x3F0000;
                    p_ms_enqueue->msg_enqueue.dest_map |= (p_ms_met_fifo->msg_metfifo.old_dest_map & 0xFFFF); /* copy */
                    p_ms_enqueue->msg_enqueue.dest_sgmac_group_id = ((ucast_id >> 5)&0x3F);
                }
                else    /* to local */
                {
                    p_ms_enqueue->msg_enqueue.queue_on_chip_id = FALSE;
                    p_ms_enqueue->msg_enqueue.replicated_met = TRUE;

                    /* MsEnqueue.destMap[15:0] = ucastId[15:0] */
                    p_ms_enqueue->msg_enqueue.dest_map &= 0x3F0000;
                    p_ms_enqueue->msg_enqueue.dest_map |= (ucast_id & 0xFFFF);

                    if (is_link_aggregation)
                    {
                        global_dest_port = ((31 << 9) | (ucast_id & 0x1FF));
                        SET_DESTCHIPID_IN_DESTMAP(p_ms_enqueue->msg_enqueue.dest_map, 0x1F);
                    }
                    else
                    {
                        /* address to self */
                        SET_DESTCHIPID_IN_DESTMAP(p_ms_enqueue->msg_enqueue.dest_map, met_fifo_ctl.chip_id);
                        global_dest_port = ((met_fifo_ctl.chip_id << 9) | (ucast_id & 0x1FF));
                    }
                }

                dsmet_logic_dest_port = (ds_met_entry.logic_dest_port12_11 << 11)
                                        | (ds_met_entry.logic_dest_port10 << 10)
                                        | (ds_met_entry.logic_dest_port9_8 << 8)
                                        | (ds_met_entry.logic_dest_port7_6 << 6)
                                        | (ds_met_entry.logic_dest_port5 << 5)
                                        | ds_met_entry.logic_dest_port4_0;
                phy_port_check_discard = ds_met_entry.phy_port_check_discard
                                        && ((!p_ms_met_fifo->msg_metfifo.from_fabric)
                                            || (p_ms_met_fifo->msg_metfifo.operation_type != OPERATION_TYPE_C2C)
                                            || (!p_ms_met_fifo->msg_metfifo.c2c_check_disable));

                if ((phy_port_check_discard && met_fifo_ctl.port_check_en   /*port check before EPE to saving bandwidth */
                            && ((source_port & 0x3FFF) == (global_dest_port & 0x3FFF)))
                     || (ds_met_entry.leaf_check_en && p_ms_met_fifo->msg_metfifo.is_leaf)
                     || (ds_met_entry.logic_port_type_check && p_ms_met_fifo->msg_metfifo.logic_port_type)
                     || (IS_BIT_SET(ds_met_entry.logic_port_check_en, 0)
                            && ((p_ms_met_fifo->msg_metfifo.service_id & 0x3FFF) == (dsmet_logic_dest_port & 0x3FFF)))
                     || (ds_met_entry.aps_bridge_en
                            && remote_chip))  /* Aps to remote chip */
                {
                    p_ms_enqueue->msg_enqueue.enqueue_discard = TRUE;
                    if (p_ms_enqueue->msg_enqueue.enqueue_discard)
                    {
                        CMODEL_DEBUG_OUT_INFO("Discard in MetFifo!!, file:%s line:%d function:%s******\n",
                                              __FILE__, __LINE__, __FUNCTION__);
                    }
                }

                p_ms_met_fifo->port_bitmap_31_0 = 0;
                p_ms_met_fifo->port_bitmap_55_32 = 0;

            }
            else    /* bitmap, use only half queueSelType and must be same for one DsMetEntry */
            {
                last_dest_map_15_12 = (((ucast_id>>14)&0x3)<<2) | met_fifo_ctl.port_bitmap_bit13_12;
                p_ms_met_fifo->last_dest_map_15_12 = last_dest_map_15_12;

                p_ms_met_fifo->port_bitmap_31_0 = dsmet_port_bitmap31_0;
                p_ms_met_fifo->port_bitmap_55_32 = dsmet_port_bitmap55_32;
                p_ms_met_fifo->is_link_aggregation_bitmap = ds_met_entry.is_link_aggregation;

                /* ======== bug 4969 metal fix ECO begin ========= */
                //if (ds_met_entry.phy_port_check_discard && (!remote_chip))
                if (ds_met_entry.phy_port_check_discard && (!remote_chip)
                    && ((((source_port >> 6) & 0x1) == 0) || ((met_fifo_ctl.port_bitmap_next_hop_ptr & 0x1) == 0)))
                /* ======== bug 4969 metal fix ECO end ========= */
                {
                    /* ======== bug 4710 ECO begine ========= */
                    //if ((!p_ms_met_fifo->is_link_aggregation_bitmap)
                    //    && (source_chip_id != 0x1F)
                    //    && (source_chip_id == met_fifo_ctl.chip_id))  /* None Link Aggregation */
                    if ((!p_ms_met_fifo->is_link_aggregation_bitmap)
                        && (((source_port>>9)&0x1F)!= 0x1F)
                        && (source_chip_id == met_fifo_ctl.chip_id))  /* None Link Aggregation */
                    /* ======== bug 4710 ECO end ========= */
                    {
                        /* source is not linkagg, dest is not linkagg. portbitmap stands for port ID */
                        source_port_5_0 = (source_port & 0x3F);
                        if (source_port_5_0 < 32)
                        {
                            CLEAR_BIT(p_ms_met_fifo->port_bitmap_31_0, source_port_5_0);
                        }
                        else if (source_port_5_0 < 56)
                        {
                            CLEAR_BIT(p_ms_met_fifo->port_bitmap_55_32, (source_port_5_0 - 32));
                        }
                    }
                    /* ======== bug 4710 ECO begine ========= */
                    //else if (p_ms_met_fifo->is_link_aggregation_bitmap && (source_chip_id == 0x1F))
                    else if (p_ms_met_fifo->is_link_aggregation_bitmap && (((source_port>>9)&0x1F) == 0x1F))
                    /* ======== bug 4710 ECO end ========= */
                    {
                        /* source /dest both linkagg. portBitmap stands for linkagg group ID.
                           Should use another met entry */
                        source_port_5_0 = (source_port & 0x3F);
                        if (source_port_5_0 < 32)
                        {
                            CLEAR_BIT(p_ms_met_fifo->port_bitmap_31_0, source_port_5_0);
                        }
                        else if (source_port_5_0 < 56)
                        {
                            CLEAR_BIT(p_ms_met_fifo->port_bitmap_55_32, (source_port_5_0 - 32));
                        }
                    }


                }

                if ((p_ms_met_fifo->port_bitmap_31_0 == 0)
                    && (p_ms_met_fifo->port_bitmap_55_32 == 0))
                {
                    p_ms_enqueue->msg_enqueue.enqueue_discard = TRUE;
                }

            }
        }

        if ((p_ms_met_fifo->port_bitmap_31_0 != 0)
            || (p_ms_met_fifo->port_bitmap_55_32 != 0))    /* use portBitmap */
        {
            if (IS_BIT_SET(p_ms_met_fifo->msg_metfifo.old_dest_map, 21))
            {
                SET_BIT(p_ms_enqueue->msg_enqueue.dest_map, 21);
            }
            else
            {
                CLEAR_BIT(p_ms_enqueue->msg_enqueue.dest_map, 21);
            }

            if (!p_ms_met_fifo->is_link_aggregation_bitmap)
            {
                SET_DESTCHIPID_IN_DESTMAP(p_ms_enqueue->msg_enqueue.dest_map, met_fifo_ctl.chip_id); /* address to self */
            }
            else
            {
                SET_DESTCHIPID_IN_DESTMAP(p_ms_enqueue->msg_enqueue.dest_map, 0x1F);  /* address to link aggregation */
            }

            /* MsEnqueue.destMap[15:12] = MsMetFifo.lastDestMap15_12[2:0] */
            p_ms_enqueue->msg_enqueue.dest_map &= 0x3F0FFF;
            p_ms_enqueue->msg_enqueue.dest_map |= (p_ms_met_fifo->last_dest_map_15_12 << 12);

            p_ms_enqueue->msg_enqueue.dest_map &= 0x3FF03F;

            /* MsEnqueue.destMap[5:0] = portId of last bit 1 of portBitMap[55:0] */
            if (p_ms_met_fifo->port_bitmap_55_32 != 0)
            {
                for (index = 55; index >= 32; index--)
                {
                    if (IS_BIT_SET(p_ms_met_fifo->port_bitmap_55_32, index-32))
                    {
                        port_id = index;
                        CLEAR_BIT(p_ms_met_fifo->port_bitmap_55_32, (port_id - 32));
                        break;
                    }
                }
            }
            else if (p_ms_met_fifo->port_bitmap_31_0 != 0)
            {
                for (index = 31; index >= 0; index--)
                {
                    if (IS_BIT_SET(p_ms_met_fifo->port_bitmap_31_0, index))
                    {
                        port_id = index;
                        CLEAR_BIT(p_ms_met_fifo->port_bitmap_31_0, port_id);
                        break;
                    }
                }
            }

            p_ms_enqueue->msg_enqueue.dest_map &= 0x3FFFC0;
            p_ms_enqueue->msg_enqueue.dest_map |= (port_id & 0x3F);

            port_id = 0xFF;

            p_ms_enqueue->msg_enqueue.next_hop_ext = p_ms_met_fifo->msg_metfifo.next_hop_ext;

            if (l3_mcast)
            {
                p_ms_enqueue->msg_enqueue.replication_ctl = ((p_ms_met_fifo->current_met_entry + met_fifo_ctl.l3_mcast_met_nexthop_base) << 4);
                p_ms_enqueue->msg_enqueue.replication_ctl_ext = 0;
            }
            else
            {
                p_ms_enqueue->msg_enqueue.replication_ctl = (met_fifo_ctl.port_bitmap_next_hop_ptr<<4);
                p_ms_enqueue->msg_enqueue.replication_ctl_ext = 0;
            }

            p_ms_enqueue->msg_enqueue.replicated_met = 1;
            p_ms_enqueue->msg_enqueue.queue_on_chip_id = 0;
            p_ms_enqueue->msg_enqueue.dest_sgmac_group_id = 0;

        }

        end_replication = (((p_ms_met_fifo->next_met_entry_ptr == 0x7FFF)
                                && (p_ms_met_fifo->port_bitmap_31_0 == 0)
                                && (p_ms_met_fifo->port_bitmap_55_32 == 0))
                            || ((*p_remain_rcd) == 1) || end_replication) || (!is_met);

        p_ms_enqueue->msg_enqueue.enqueue_discard |= (!is_met);

        p_ms_met_fifo->end_local_rep = end_local_rep;

        /* Pass MsMetFifo.{currentMetEntryPtr[14:0],nextMetEntryPtr[14:0],portBitmap[55:0]} to next replication */

        if (!end_replication)
        {
            p_ms_enqueue->msg_enqueue.last_enqueue = FALSE;
            p_ms_enqueue->msg_enqueue.rcd = 1;
        }
        else
        {
            p_ms_enqueue->msg_enqueue.rcd = (*p_remain_rcd);
            p_ms_enqueue->msg_enqueue.last_enqueue = TRUE;
        }

        (*p_remain_rcd)--;
        list_add_tail(&p_ms_enqueue->head, &p_pkt_info->ms_enqueue_list);

        if (end_replication)
        {
            break;
        }
    }

    return DRV_E_NONE;
}
/****************************************************************************
* Name:       cm_qmgt_met_fifo_handle
* Purpose:    Provides generate en-queue message function.
* Parameters:
* Input:      p_qpkt -- queue management packet pointer
* Output:     p_qpkt -- queue management packet pointer
* Return:     DRV_E_NONE = success.
*             Other -- Error, please refer to DRV_E_XXX.
* Note:       None.
****************************************************************************/
int32
cm_qmgt_met_fifo_handle(queue_in_pkt_t *p_qpkt)
{

    #define RCD_MAX 0x7F
    queue_packet_info_t *p_pkt_info = (queue_packet_info_t *)p_qpkt->pkt_info;
    fwd_ms_met_fifo_t *p_ms_met_fifo = (fwd_ms_met_fifo_t *)p_pkt_info->ms_met_fifo;
    uint16 remaining_rcd = 0;
    uint8 chip_id_match = FALSE, do_met = FALSE;
    uint32 dest_chip_id = 0, mcast = 0, cmd = 0;
    met_fifo_ctl_t met_fifo_ctl;
    uint16 exception_vector = 0;
    uint16 source_port = 0;
    uint8 source_chip_id = 0;

    CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "%s\n", "Qmgt Met Fifo Process");

    /* INIT */
    exception_vector = (p_ms_met_fifo->msg_metfifo.exception_vector8_1 << 1)
                       | p_ms_met_fifo->msg_metfifo.exception_vector0_0;

    source_port = p_ms_met_fifo->msg_metfifo.source_port;
    source_chip_id = (p_ms_met_fifo->msg_metfifo.source_port >> 9) & 0x1F;

    sal_memset(&met_fifo_ctl, 0, sizeof(met_fifo_ctl_t));
    cmd = DRV_IOR(MetFifoCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(p_qpkt->chip_id, 0, cmd, &met_fifo_ctl));

    if (met_fifo_ctl.stacking_en)
    {
        if (((p_ms_met_fifo->msg_metfifo.source_port >> 9) & 0x1F) == 0x1F)
        {
            source_chip_id = (((p_ms_met_fifo->msg_metfifo.source_port >> 14)&0x3)<< 3)
                             |((p_ms_met_fifo->msg_metfifo.source_port >> 6) & 0x7);
            source_port = 0;
            source_port = (0x1F << 9)
                          |(p_ms_met_fifo->msg_metfifo.source_port & 0x3F);
        }
    }

    remaining_rcd = RCD_MAX;

    dest_chip_id =(p_ms_met_fifo->msg_metfifo.old_dest_map >> 16) & 0x1F;
    mcast = (p_ms_met_fifo->msg_metfifo.old_dest_map >> 21) & 0x1;

    chip_id_match = (dest_chip_id == met_fifo_ctl.chip_id)                              /* local destined */
                    ||(p_ms_met_fifo->msg_metfifo.from_fabric && (0x1F == dest_chip_id));   /* fabric/stacking Mcast */

    do_met = p_ms_met_fifo->msg_metfifo.local_switching && mcast && chip_id_match;

    if (p_ms_met_fifo->msg_metfifo.rx_oam)
    {
        do_met = do_met && met_fifo_ctl.ether_oam_multicast_en;
    }

    if (0 != exception_vector)
    {
        DRV_IF_ERROR_RETURN(_cm_qmgt_met_fifo_do_exception_enqueue(p_qpkt, &remaining_rcd, source_chip_id, exception_vector));
    }

    /* DEST_ID_DISCARD_SWITCH */
    if (p_ms_met_fifo->msg_metfifo.dest_id_discard)
    {
        CMODEL_DEBUG_OUT_INFO("++++++ MetFifo Discard Packet!!\n");

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_DISCARD_TYPE, "Qmgt Met Fifo: Discard Dest Id Discard Packet.\n");
        return DRV_E_NONE;
    }

    /* MET_SWITCH */
    if (do_met)
    {
        DRV_IF_ERROR_RETURN(_cm_qmgt_met_fifo_do_multicast_enqueue(p_qpkt, &remaining_rcd, source_chip_id, source_port));
    }
    /* NO_REPLICATION */
    else
    {
        DRV_IF_ERROR_RETURN(_cm_qmgt_met_fifo_do_unicast_enqueue(p_qpkt, &remaining_rcd, source_chip_id));
    }
    return DRV_E_NONE;
}

