/****************************************************************************
 * sim_fwd_interface.c
 *
 * Copyright:    (c)2007 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jack
 * Date:         2011-10-25
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sim_bsr_interface.h"
#include "cm_lib.h"

static pkt_buf_store_info_t _pkt_buf_info;

static bool
_sim_bus_field_compare(uint32 c_field, uint32 v_field, char *name)
{
   char buf[COSIM_PRINT_BUF_MAX_SIZE] = {};
   if (c_field != v_field)
   {
      ASIC_DEBUG_BUS_CMP(buf,"%s mismatch <Cmodel = 0x%x, ASIC = 0x%x>\n", name, c_field, v_field);
      return FALSE;
   }

   return TRUE;
}

static void
_sim_interface_fwd_show_rtl_enqueue_ms(sim_ms_enqueue_t *ms)
{
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};

    ASIC_DEBUG_BUS_CMP(buf,"msg_type:0x%x\n",ms->msg_type);

    ASIC_DEBUG_BUS_CMP(buf,"buffer_count:0x%x\n",ms->buffer_count);

    ASIC_DEBUG_BUS_CMP(buf,"head_buf_offset:0x%x\n",ms->head_buf_offset);

    ASIC_DEBUG_BUS_CMP(buf,"head_buffer_ptr:0x%x\n",ms->head_buffer_ptr);

    //ASIC_DEBUG_BUS_CMP(buf,"resource_group_id:0x%x\n",ms->resource_group_id);

    ASIC_DEBUG_BUS_CMP(buf,"tail_buffer_ptr:0x%x\n",ms->tail_buffer_ptr);

    ASIC_DEBUG_BUS_CMP(buf,"enqueue_discard:0x%x\n",ms->enqueue_discard);

    ASIC_DEBUG_BUS_CMP(buf,"last_enqueue:0x%x\n",ms->last_enqueue);

    ASIC_DEBUG_BUS_CMP(buf,"mcast_rcd:0x%x\n",ms->mcast_rcd);

    ASIC_DEBUG_BUS_CMP(buf,"rcd:0x%x\n",ms->rcd);

    ASIC_DEBUG_BUS_CMP(buf,"packet_length:0x%x\n",ms->packet_length);

    ASIC_DEBUG_BUS_CMP(buf,"source_chip_id:0x%x\n",ms->source_chip_id);

    ASIC_DEBUG_BUS_CMP(buf,"payload_offset:0x%x\n",ms->payload_offset);

    ASIC_DEBUG_BUS_CMP(buf,"fid:0x%x\n",ms->fid);

    ASIC_DEBUG_BUS_CMP(buf,"src_queue_select:0x%x\n",ms->src_queue_select);

    ASIC_DEBUG_BUS_CMP(buf,"pt_enable:0x%x\n",ms->pt_enable);

    ASIC_DEBUG_BUS_CMP(buf,"from_fabric:0x%x\n",ms->from_fabric);

    ASIC_DEBUG_BUS_CMP(buf,"length_adjust_type:0x%x\n",ms->length_adjust_type);

    ASIC_DEBUG_BUS_CMP(buf,"critical_packet:0x%x\n",ms->critical_packet);

    ASIC_DEBUG_BUS_CMP(buf,"c2c_check_disable:0x%x\n",ms->c2c_check_disable);

    ASIC_DEBUG_BUS_CMP(buf,"rx_oam_type:0x%x\n",ms->rx_oam_type);

    ASIC_DEBUG_BUS_CMP(buf,"ecn_en:0x%x\n",ms->ecn_en);

    ASIC_DEBUG_BUS_CMP(buf,"dest_select:0x%x\n",ms->dest_select);

    ASIC_DEBUG_BUS_CMP(buf,"queue_on_chip_id:0x%x\n",ms->queue_on_chip_id);

    ASIC_DEBUG_BUS_CMP(buf,"replicated_met:0x%x\n",ms->replicated_met);

    ASIC_DEBUG_BUS_CMP(buf,"ecn_aware:0x%x\n",ms->ecn_aware);

    ASIC_DEBUG_BUS_CMP(buf,"rx_oam:0x%x\n",ms->rx_oam);

    ASIC_DEBUG_BUS_CMP(buf,"next_hop_ext:0x%x\n",ms->next_hop_ext);

    ASIC_DEBUG_BUS_CMP(buf,"color:0x%x\n",ms->color);

    ASIC_DEBUG_BUS_CMP(buf,"dest_sgmac_group_id:0x%x\n",ms->dest_sgmac_group_id);

    ASIC_DEBUG_BUS_CMP(buf,"operation_type:0x%x\n",ms->operation_type);

    //ASIC_DEBUG_BUS_CMP(buf,"header_hash:0x%x\n",ms->header_hash);

    ASIC_DEBUG_BUS_CMP(buf,"old_dest_map:0x%x\n",ms->old_dest_map);

    ASIC_DEBUG_BUS_CMP(buf,"priority:0x%x\n",ms->priority);

    ASIC_DEBUG_BUS_CMP(buf,"oam_dest_chip_id:0x%x\n",ms->oam_dest_chip_id);

    ASIC_DEBUG_BUS_CMP(buf,"service_id:0x%x\n",ms->service_id);

    ASIC_DEBUG_BUS_CMP(buf,"src_sgmac_group_id:0x%x\n",ms->src_sgmac_group_id);

    ASIC_DEBUG_BUS_CMP(buf,"flow_id:0x%x\n",ms->flow_id);

    ASIC_DEBUG_BUS_CMP(buf,"replication_ctl:0x%x\n",ms->replication_ctl);

    ASIC_DEBUG_BUS_CMP(buf,"dest_map:0x%x\n",ms->dest_map);
}

static void
_sim_interface_bsr_show_mismatch_enqueue_ms(sim_ms_enqueue_t *v_bus, ms_enqueue_t *c_bus)
{

    _sim_bus_field_compare(c_bus->msg_type, v_bus->msg_type, "msg_type");

    _sim_bus_field_compare(c_bus->buffer_count, v_bus->buffer_count, "buffer_count");

    _sim_bus_field_compare(c_bus->head_buf_offset, v_bus->head_buf_offset, "head_buf_offset");

    _sim_bus_field_compare(c_bus->head_buffer_ptr, v_bus->head_buffer_ptr, "head_buffer_ptr");

    //_sim_bus_field_compare(c_bus->resource_group_id, v_bus->resource_group_id, "resource_group_id");

    _sim_bus_field_compare(c_bus->tail_buffer_ptr, v_bus->tail_buffer_ptr, "tail_buffer_ptr");

    _sim_bus_field_compare(c_bus->enqueue_discard, v_bus->enqueue_discard, "enqueue_discard");

    _sim_bus_field_compare(c_bus->last_enqueue, v_bus->last_enqueue, "last_enqueue");

    _sim_bus_field_compare(c_bus->mcast_rcd, v_bus->mcast_rcd, "mcast_rcd");

    _sim_bus_field_compare(c_bus->rcd, v_bus->rcd, "rcd");

    _sim_bus_field_compare(c_bus->packet_length, v_bus->packet_length, "packet_length");

    _sim_bus_field_compare(c_bus->source_chip_id, v_bus->source_chip_id, "source_chip_id");

    _sim_bus_field_compare(c_bus->payload_offset, v_bus->payload_offset, "payload_offset");

    _sim_bus_field_compare(c_bus->fid, v_bus->fid, "fid");

    _sim_bus_field_compare(c_bus->src_queue_select, v_bus->src_queue_select, "src_queue_select");

    _sim_bus_field_compare(c_bus->pt_enable, v_bus->pt_enable, "pt_enable");

    _sim_bus_field_compare(c_bus->from_fabric, v_bus->from_fabric, "from_fabric");

    _sim_bus_field_compare(c_bus->length_adjust_type, v_bus->length_adjust_type, "length_adjust_type");

    _sim_bus_field_compare(c_bus->critical_packet, v_bus->critical_packet, "critical_packet");

    _sim_bus_field_compare(c_bus->c2c_check_disable, v_bus->c2c_check_disable, "c2c_check_disable");

    _sim_bus_field_compare(c_bus->rx_oam_type, v_bus->rx_oam_type, "rx_oam_type");

    _sim_bus_field_compare(c_bus->ecn_en, v_bus->ecn_en, "ecn_en");

    _sim_bus_field_compare(c_bus->dest_select, v_bus->dest_select, "dest_select");

    _sim_bus_field_compare(c_bus->queue_on_chip_id, v_bus->queue_on_chip_id, "queue_on_chip_id");

    _sim_bus_field_compare(c_bus->replicated_met, v_bus->replicated_met, "replicated_met");

    _sim_bus_field_compare(c_bus->ecn_aware, v_bus->ecn_aware, "ecn_aware");

    _sim_bus_field_compare(c_bus->rx_oam, v_bus->rx_oam, "rx_oam");

    _sim_bus_field_compare(c_bus->next_hop_ext, v_bus->next_hop_ext, "next_hop_ext");

    _sim_bus_field_compare(c_bus->color, v_bus->color, "color");

    _sim_bus_field_compare(c_bus->dest_sgmac_group_id, v_bus->dest_sgmac_group_id, "dest_sgmac_group_id");

    _sim_bus_field_compare(c_bus->operation_type, v_bus->operation_type, "operation_type");

    //_sim_bus_field_compare(c_bus->header_hash, v_bus->header_hash, "header_hash");

    _sim_bus_field_compare(c_bus->old_dest_map, v_bus->old_dest_map, "old_dest_map");

    _sim_bus_field_compare(c_bus->priority, v_bus->priority, "priority");

    _sim_bus_field_compare(c_bus->oam_dest_chip_id, v_bus->oam_dest_chip_id, "oam_dest_chip_id");

    _sim_bus_field_compare(c_bus->service_id, v_bus->service_id, "service_id");

    _sim_bus_field_compare(c_bus->src_sgmac_group_id, v_bus->src_sgmac_group_id, "src_sgmac_group_id");

    _sim_bus_field_compare(c_bus->flow_id, v_bus->flow_id, "flow_id");

    _sim_bus_field_compare(c_bus->replication_ctl, v_bus->replication_ctl, "replication_ctl");

    _sim_bus_field_compare(c_bus->dest_map, v_bus->dest_map, "dest_map");
}

static void
_sim_interface_fwd_show_rtl_dequeue_ms(sim_ms_dequeue_t *ms )
{
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};

    ASIC_DEBUG_BUS_CMP(buf,"head_ptr_offset:0x%x\n",ms->head_buf_offset);
    ASIC_DEBUG_BUS_CMP(buf,"head_buffer_ptr:0x%x\n",ms->head_buffer_ptr);


    //ASIC_DEBUG_BUS_CMP(buf,"resource_group_id :0x%x\n",ms->resource_group_id);

    ASIC_DEBUG_BUS_CMP(buf,"release_packet :0x%x\n",ms->release_packet);

    ASIC_DEBUG_BUS_CMP(buf,"mcast_rcd :0x%x\n",ms->mcast_rcd);

    ASIC_DEBUG_BUS_CMP(buf,"rcd :0x%x\n",ms->rcd);

    ASIC_DEBUG_BUS_CMP(buf,"sub_grp_sel :0x%x\n",ms->sub_grp_sel);

    ASIC_DEBUG_BUS_CMP(buf,"packet_length:0x%x\n",ms->packet_length);

    ASIC_DEBUG_BUS_CMP(buf,"chan_pri:0x%x\n",ms->chan_pri);

    ASIC_DEBUG_BUS_CMP(buf,"grp_id:0x%x\n",ms->grp_id);

    ASIC_DEBUG_BUS_CMP(buf,"queue_id:0x%x\n",ms->queue_id);

    ASIC_DEBUG_BUS_CMP(buf,"que_use_cir_deficit:0x%x\n",ms->que_use_cir_deficit);

    ASIC_DEBUG_BUS_CMP(buf,"grp_bucket_upd_vec:0x%x\n",ms->grp_bucket_upd_vec);

    ASIC_DEBUG_BUS_CMP(buf,"congestion_valid:0x%x\n",ms->congestion_valid);

    ASIC_DEBUG_BUS_CMP(buf,"discard:0x%x\n",ms->discard);

    ASIC_DEBUG_BUS_CMP(buf,"dest_select:0x%x\n",ms->dest_select);

    ASIC_DEBUG_BUS_CMP(buf,"length_adjust_type:0x%x\n",ms->length_adjust_type);

    ASIC_DEBUG_BUS_CMP(buf,"pt_enable:0x%x\n",ms->pt_enable);

    ASIC_DEBUG_BUS_CMP(buf,"next_hop_ext:0x%x\n",ms->next_hop_ext);

    ASIC_DEBUG_BUS_CMP(buf,"in_profile:0x%x\n",ms->in_profile);

    ASIC_DEBUG_BUS_CMP(buf,"replication_ctl:0x%x\n",ms->replication_ctl);

    ASIC_DEBUG_BUS_CMP(buf,"dest_map:0x%x\n",ms->dest_map);

}

static void
_sim_interface_bsr_show_mismatch_dequeue_ms(sim_ms_dequeue_t *v_bus, ms_dequeue_t *s_bus)
{

   _sim_bus_field_compare(s_bus->head_ptr_offset,v_bus->head_buf_offset, "head_ptr_offset");
    _sim_bus_field_compare(s_bus->head_buffer_ptr, v_bus->head_buffer_ptr, "head_buffer_ptr");


//    _sim_bus_field_compare(s_bus->resource_group_id , v_bus->resource_group_id, "resource_group_id");

    _sim_bus_field_compare(s_bus->release_packet , v_bus->release_packet, "release_packet");

    _sim_bus_field_compare(s_bus->mcast_rcd , v_bus->mcast_rcd, "mcast_rcd");

    _sim_bus_field_compare(s_bus->rcd , v_bus->rcd, "rcd");

    _sim_bus_field_compare(s_bus->sub_grp_sel , v_bus->sub_grp_sel, "sub_grp_sel");

    _sim_bus_field_compare(s_bus->packet_length, v_bus->packet_length, "packet_length");

    _sim_bus_field_compare(s_bus->chan_pri, v_bus->chan_pri, "chan_pri");

    _sim_bus_field_compare(s_bus->grp_id, v_bus->grp_id, "grp_id");

    _sim_bus_field_compare(s_bus->queue_id, v_bus->queue_id, "queue_id");

//    _sim_bus_field_compare(s_bus->que_use_cir_deficit, v_bus->que_use_cir_deficit, "que_use_cir_deficit");

//    _sim_bus_field_compare(s_bus->grp_bucket_upd_vec, v_bus->grp_bucket_upd_vec, "grp_bucket_upd_vec");

    _sim_bus_field_compare(s_bus->congestion_valid, v_bus->congestion_valid, "congestion_valid");

    _sim_bus_field_compare(s_bus->discard, v_bus->discard, "discard");

    _sim_bus_field_compare(s_bus->dest_select, v_bus->dest_select, "dest_select");

    _sim_bus_field_compare(s_bus->length_adjust_type, v_bus->length_adjust_type, "length_adjust_type");

    _sim_bus_field_compare(s_bus->pt_enable, v_bus->pt_enable, "pt_enable");

    _sim_bus_field_compare(s_bus->next_hop_ext, v_bus->next_hop_ext, "next_hop_ext");

    _sim_bus_field_compare(s_bus->in_profile, v_bus->in_profile, "in_profile");

    _sim_bus_field_compare(s_bus->replication_ctl, v_bus->replication_ctl, "replication_ctl");

    _sim_bus_field_compare(s_bus->dest_map, v_bus->dest_map, "dest_map");

}



int32
cosim_bsr_enqueue_taildrop(void *bus, bool *succ)
{
    int32 ret = DRV_E_NONE;
    list_head_t *pos = NULL;
    sim_ms_enqueue_t  v_ms_enqueue;
    fwd_ms_enqueue_t *c_ms_enqueue = NULL;
    bool match=FALSE, simular=FALSE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};

    DRV_PTR_VALID_CHECK(bus);
    DRV_PTR_VALID_CHECK(succ);
    sal_memset(&v_ms_enqueue, 0, sizeof(v_ms_enqueue));

    ret = ms_enqueue_bus_decode(bus, &v_ms_enqueue);
    if (DRV_E_NONE != ret)
    {
        ASIC_DEBUG_BUS_CMP(buf, "%% ERROR! BSR MsEnqueue Bus decode error!\n");
        return ret;
    }

    list_for_each(pos, &(cosim_db.sim_fwd_list[SIM_FWD_MS_ENQUEUE]))
    {
        c_ms_enqueue = list_entry(pos, fwd_ms_enqueue_t, head);
//		sim_ms_enqueue_t *msg_en_queue = (sim_ms_enqueue_t *)c_ms_enqueue->msg_enqueue;
        match = ms_enqueue_bus_compare(&(c_ms_enqueue->msg_enqueue), &v_ms_enqueue,&simular);
        if (match)
        {
            /*delete_msdequeue_by_seqnum(c_ms_enqueue->sequence_num);
              delete_msenqueue_by_seqnum(c_ms_enqueue->sequence_num);*/
            *succ = TRUE;
            return DRV_E_NONE;
        }
    }

    ASIC_DEBUG_BUS_CMP(buf, "================Can not find tail dropped MsEnqueue in enqueue link list!!!============\n");
    ASIC_DEBUG_BUS_CMP(buf, "ASIC Enqueue Msg:\n");
    _sim_interface_fwd_show_rtl_enqueue_ms(&v_ms_enqueue);
    *succ = FALSE;

    return DRV_E_NONE;
}

void
cosim_bsr_linklist_check(void)
{
    list_head_t *pos = NULL;
    fwd_ms_enqueue_t *ms_enqueue = NULL;
    fwd_ms_dequeue_t *ms_dequeue = NULL;
#if COSIM_PENDING
    /* zhouw note */
    fwd_ms_met_fifo_t *ms_metfifo = NULL;
#endif
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};
    uint32 cnt = 0;

    if (!list_empty(&(cosim_db.sim_fwd_list[SIM_FWD_MS_ENQUEUE])))
    {
        cnt = 0;
        ASIC_DEBUG_BUS_CMP(buf, "===================MsEnqueue Reserved in Enqueue Link List===========\n");
        list_for_each(pos, &(cosim_db.sim_fwd_list[SIM_FWD_MS_ENQUEUE]))
        {
            ms_enqueue = list_entry(pos, fwd_ms_enqueue_t, head);
            ASIC_DEBUG_BUS_CMP(buf, "Enqueue Msg:<NO. %d>\n", cnt);
            _sim_interface_fwd_show_rtl_enqueue_ms((sim_ms_enqueue_t *)(&ms_enqueue->msg_enqueue));
            ASIC_DEBUG_BUS_CMP(buf, "\n");
        }
    }
    else if(!list_empty(&(cosim_db.sim_fwd_list[SIM_FWD_MS_DEQUEUE])))
    {
        cnt = 0;
        ASIC_DEBUG_BUS_CMP(buf, "===================MsDequeue Reserved in Dequeue Link List===========\n");
        list_for_each(pos, &(cosim_db.sim_fwd_list[SIM_FWD_MS_DEQUEUE]))
        {
            ms_dequeue = list_entry(pos, fwd_ms_dequeue_t, head);
            ASIC_DEBUG_BUS_CMP(buf, "Dequeue Msg:<NO. %d>\n", cnt);
            _sim_interface_fwd_show_rtl_dequeue_ms((sim_ms_dequeue_t *)(&ms_dequeue->msg_dequeue));
            ASIC_DEBUG_BUS_CMP (buf, "\n");
        }
    }
#if COSIM_PENDING
    /* zhouw note */
    else if(!list_empty(&(cosim_db.sim_fwd_list[SIM_FWD_MS_MET_FIFO])))
    {
        cnt = 0;
        ASIC_DEBUG_BUS_CMP(buf, "===================MsMetfifo Reserved in Metfifo Link List===========\n");
        list_for_each(pos, &(cosim_db.sim_fwd_list[SIM_FWD_MS_MET_FIFO]))
        {
            ms_metfifo = list_entry(pos, fwd_ms_met_fifo_t, head);
            ASIC_DEBUG_BUS_CMP(buf, "Metfifo Msg:<NO. %d>\n", cnt);
            _sim_interface_fwd_show_rtl_dequeue_ms(ms_metfifo);
            ASIC_DEBUG_BUS_CMP (buf, "\n");
        }
    }
#endif
    else
    {
        return;
    }
}

void
cosim_get_bufstore_info(uint32 head_buffer_ptr, uint32 tail_buffer_ptr,
                        uint32 buffer_count, uint32 head_buf_offset, uint32 msg_type)
{
    _pkt_buf_info.head_buffer_ptr = head_buffer_ptr;
    _pkt_buf_info.tail_buffer_ptr = tail_buffer_ptr;
    _pkt_buf_info.buffer_count = buffer_count;
    _pkt_buf_info.head_buf_offset = head_buf_offset;
    _pkt_buf_info.msg_type = msg_type;
}

int32
cosim_do_bsr(uint32 chipid, uint32 chanid, uint32 pkt_len, uint8 *pkt, uint8 *exception)
{
    queue_in_pkt_t in_pkt;
    list_head_t out_pkt, *pos = NULL;
    int ret;
    out_pkt_t *output=NULL;


    if ((pkt == NULL) || (exception == NULL))
    {
        return DRV_E_INVALID_PTR;
    }

    sal_memset(&in_pkt, 0, sizeof(queue_in_pkt_t));
    INIT_LIST_HEAD(&out_pkt);

    in_pkt.chip_id = chipid;
    in_pkt.chan_id = chanid;
    in_pkt.pkt = sal_malloc(MTU);

    if (NULL == in_pkt.pkt)
    {
        return DRV_E_NO_MEMORY;
    }

    sal_memset(in_pkt.pkt, 0, MTU);
    sal_memcpy(in_pkt.pkt, pkt+GREAT_BELT_HEADER_LEN, pkt_len); /* only raw packet, do not include bheader */
    in_pkt.packet_length = pkt_len;/* do not include bheader len */
    in_pkt.pkt_info = NULL;
    in_pkt.module_bus.dest_id_discard = 0;  /* cmodel mustbe 0 */
    in_pkt.module_bus.pkt_len = pkt_len;    /* cmodel BSR can not support cutThrough */
    sal_memcpy(in_pkt.module_bus.packet_header, pkt, GREAT_BELT_HEADER_LEN);

    in_pkt.exception = sal_malloc(GREAT_BELT_EXCEPTION_LEN);
    if (NULL == in_pkt.exception)
    {
        SAL_LOG_FATAL("\nNo memory when alloc exception memory!");
        return DRV_E_NO_MEMORY;
    }

    sal_memset(in_pkt.exception, 0, GREAT_BELT_EXCEPTION_LEN);
    sal_memcpy(in_pkt.exception, exception, GREAT_BELT_EXCEPTION_LEN);
    DRV_IF_ERROR_RETURN(swap32((uint32*)(in_pkt.exception), GREAT_BELT_EXCEPTION_LEN / 4, NETWORK_TO_HOST));

    ret = cm_do_fwd(&in_pkt, &out_pkt, &_pkt_buf_info);
    if (ret < 0)
    {
        return ret;
    }
    list_for_each(pos, &out_pkt)
    {
        output = list_entry(pos, out_pkt_t, head);
        if (cosim_db.store_outpkt)
        {
            ret = cosim_db.store_outpkt(output->chip_id,
                                        output->chan_id,
                                        output->packet_length,
                                        output->pkt,
                                        SIM_MODULE_FWD,
                                        0, 0);
            if (DRV_E_NONE != ret)
            {
                CMODEL_DEBUG_OUT_INFO("CoSIM: BSR engine store outpkt error ! ret = %d\n", ret);
            }
        }
    }
    list_del_all_and_free(&out_pkt);

    return DRV_E_NONE;
}

int32
sim_store_fwd_dequeue_bus(void *ms_dequeue)
{
    fwd_ms_dequeue_t *new_node = NULL;
    fwd_ms_dequeue_t *message = (fwd_ms_dequeue_t *)ms_dequeue;
    DRV_PTR_VALID_CHECK(ms_dequeue);
    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_FWD], SIM_FWD_MS_DEQUEUE))
    {
        return DRV_E_NONE;
    }
    new_node = (fwd_ms_dequeue_t *)sal_malloc(sizeof(fwd_ms_dequeue_t));
    if (NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }

    sal_memset(new_node, 0, sizeof(fwd_ms_dequeue_t));
    sal_memcpy(&(new_node->msg_dequeue), &(message->msg_dequeue), sizeof(ms_dequeue_t));

    list_add_tail(&new_node->head, &(cosim_db.sim_fwd_list[SIM_FWD_MS_DEQUEUE]));
    return DRV_E_NONE;
}
int32
sim_store_fwd_enqueue_bus(void *ms_enqueue)
{
    fwd_ms_enqueue_t *new_node = NULL;
    fwd_ms_enqueue_t *message = (fwd_ms_enqueue_t *)ms_enqueue;
    DRV_PTR_VALID_CHECK(ms_enqueue);
    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_FWD], SIM_FWD_MS_ENQUEUE))
    {
        return DRV_E_NONE;
    }
    new_node = (fwd_ms_enqueue_t *)ctckal_malloc(sizeof(fwd_ms_enqueue_t));
    if (NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }
    sal_memset(new_node, 0, sizeof(fwd_ms_enqueue_t));

    sal_memcpy(&(new_node->msg_enqueue), &(message->msg_enqueue), sizeof(ms_enqueue_t));
    list_add_tail(&new_node->head, &(cosim_db.sim_fwd_list[SIM_FWD_MS_ENQUEUE]));
    return DRV_E_NONE;
}
int32
sim_store_fwd_met_fifo_bus(void *ms_met_fifo)
{
    fwd_ms_met_fifo_t *new_node = NULL;
    fwd_ms_met_fifo_t *message = (fwd_ms_met_fifo_t *)ms_met_fifo;

    DRV_PTR_VALID_CHECK(ms_met_fifo);

    if (!IS_BIT_SET(cosim_db.sim_cosim_bus_flag[SIM_MODULE_FWD], SIM_FWD_MS_MET_FIFO))
    {
        return DRV_E_NONE;
    }

    new_node = (fwd_ms_met_fifo_t *)sal_malloc(sizeof(fwd_ms_met_fifo_t));
    if (NULL == new_node)
    {
        return DRV_E_NO_MEMORY;
    }

    sal_memset(new_node, 0, sizeof(fwd_ms_met_fifo_t));
    sal_memcpy(&(new_node->msg_metfifo), &(message->msg_metfifo), sizeof(ms_met_fifo_t));

    list_add_tail(&new_node->head, &(cosim_db.sim_fwd_list[SIM_FWD_MS_MET_FIFO]));

    return DRV_E_NONE;
}
int32
cosim_fwd_dequeue_verify(void *bus,bool *succ)
{
    list_head_t *pos = NULL;
    sim_ms_dequeue_t v_ms_dequeue;
    fwd_ms_dequeue_t *c_ms_dequeue = NULL;
    fwd_ms_dequeue_t *s_ms_dequeue = NULL;
    bool match=FALSE, simular=FALSE;
    uint32 cnt = 0;

    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};
    DRV_PTR_VALID_CHECK(bus);
    DRV_PTR_VALID_CHECK(succ);
    sal_memset(&v_ms_dequeue, 0, sizeof(v_ms_dequeue));
    if (list_empty(&(cosim_db.sim_fwd_list[SIM_FWD_MS_DEQUEUE])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "%% ERROR! FWD DEQUEUE verify error! <CModel DEQUEUE List is empty, but RTL is not>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }
    //c_ms_dequeue = list_entry(cosim_db.sim_fwd_list[SIM_FWD_MS_DEQUEUE].next, fwd_ms_dequeue_t, head);
    ret = ms_dequeue_bus_decode(bus, &v_ms_dequeue);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf, "%% ERROR! FWD DEQUEUE bus decode error!\n");
        return ret;
    }

    *succ = FALSE;

    list_for_each(pos, &(cosim_db.sim_fwd_list[SIM_FWD_MS_DEQUEUE]))
    {
        c_ms_dequeue=list_entry(pos, fwd_ms_dequeue_t, head);
        match = ms_dequeue_bus_compare(&(c_ms_dequeue->msg_dequeue), &v_ms_dequeue, &simular);

        if (match)
        {
            *succ = TRUE;
            list_del_all_and_free(&(cosim_db.deq_simular_list));
            list_del(&c_ms_dequeue->head);
            sal_free(c_ms_dequeue);
            c_ms_dequeue = NULL;
            return DRV_E_NONE;
        }

        if (!match && simular)
        {
            /* if simular, add the simular entry into simular list */
            s_ms_dequeue = sal_malloc(sizeof(fwd_ms_dequeue_t));
            if (NULL == s_ms_dequeue)
            {
                return DRV_E_NO_MEMORY;
            }

            sal_memcpy(s_ms_dequeue, c_ms_dequeue, sizeof(fwd_ms_dequeue_t));
            list_add_tail(&s_ms_dequeue->head, &(cosim_db.deq_simular_list));
        }
    }


    if(!(*succ))
    {
        ASIC_DEBUG_BUS_CMP(buf, "=====================Dequeue Msg Mismatch=====================\n");
        ASIC_DEBUG_BUS_CMP(buf, "ASIC Dequeue Msg:\n");
        _sim_interface_fwd_show_rtl_dequeue_ms(&v_ms_dequeue);
        ASIC_DEBUG_BUS_CMP(buf, "\n");

        list_for_each(pos, &(cosim_db.deq_simular_list))
        {
            s_ms_dequeue = list_entry(pos, fwd_ms_dequeue_t, head);

            ASIC_DEBUG_BUS_CMP(buf, "CModel Dequeue Msg:<NO. %d>\n", cnt);
            _sim_interface_bsr_show_mismatch_dequeue_ms(&v_ms_dequeue, &s_ms_dequeue->msg_dequeue);
            ASIC_DEBUG_BUS_CMP(buf, "\n");
            cnt ++;
        }
    }

    list_del_all_and_free(&(cosim_db.deq_simular_list));

  return DRV_E_NONE;
}
int32
cosim_fwd_enqueue_verify(void *bus,bool *succ)
{
    list_head_t *pos = NULL;
    bool match = FALSE, simular = FALSE;
    sim_ms_enqueue_t  v_ms_enqueue;
    fwd_ms_enqueue_t *s_ms_enqueue = NULL,*c_ms_enqueue = NULL;
    uint32 cnt = 0;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};
    DRV_PTR_VALID_CHECK(bus);
    DRV_PTR_VALID_CHECK(succ);

    sal_memset(&v_ms_enqueue, 0, sizeof(v_ms_enqueue));
    if (list_empty(&(cosim_db.sim_fwd_list[SIM_FWD_MS_ENQUEUE])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "%% ERROR! FWD ENQUEUE verify error! <CModel ENQUEUE List is empty, but RTL is not>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }
    c_ms_enqueue = list_entry(cosim_db.sim_fwd_list[SIM_FWD_MS_ENQUEUE].next, fwd_ms_enqueue_t, head);
    ret = ms_enqueue_bus_decode(bus, &v_ms_enqueue);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf, "%% ERROR! FWD ENQUEUE bus decode error!\n");
        return ret;
    }
    *succ = FALSE;

    list_for_each(pos, &(cosim_db.sim_fwd_list[SIM_FWD_MS_ENQUEUE]))
    {
        c_ms_enqueue = list_entry(pos, fwd_ms_enqueue_t, head);
        match = ms_enqueue_bus_compare((&c_ms_enqueue->msg_enqueue), &v_ms_enqueue, &simular);
        if (match)
        {
            *succ = TRUE;
            list_del_all_and_free(&(cosim_db.enq_simular_list));
            list_del(&c_ms_enqueue->head);
            sal_free(c_ms_enqueue);
            c_ms_enqueue = NULL;
            return DRV_E_NONE;
        }

        if (!match && simular)
        {
            /* if simular, add the simular entry into simular list */
            s_ms_enqueue = sal_malloc(sizeof(fwd_ms_enqueue_t));
            if (NULL == s_ms_enqueue)
            {
                return DRV_E_NO_MEMORY;
            }

            sal_memcpy(s_ms_enqueue, c_ms_enqueue, sizeof(fwd_ms_enqueue_t));
            list_add_tail(&s_ms_enqueue->head, &(cosim_db.enq_simular_list));
        }
    }

    if(!(*succ))
    {
        ASIC_DEBUG_BUS_CMP(buf, "=====================Enqueue Msg Mismatch=====================\n");
        ASIC_DEBUG_BUS_CMP(buf, "ASIC Enqueue Msg:\n");
        _sim_interface_fwd_show_rtl_enqueue_ms(&v_ms_enqueue);
        ASIC_DEBUG_BUS_CMP(buf, "\n");
        list_for_each(pos, &(cosim_db.enq_simular_list))
        {
            s_ms_enqueue = list_entry(pos, fwd_ms_enqueue_t, head);

            ASIC_DEBUG_BUS_CMP(buf, "CModel Enqueue Msg:<NO. %d>\n", cnt);
            _sim_interface_bsr_show_mismatch_enqueue_ms(&v_ms_enqueue, &s_ms_enqueue->msg_enqueue);
            ASIC_DEBUG_BUS_CMP(buf, "\n");
        }
    }

    list_del_all_and_free(&(cosim_db.enq_simular_list));

 return DRV_E_NONE;
}
int32
cosim_fwd_met_fifo_verify(void *bus,bool *succ)
{
    sim_ms_met_fifo_t v_ms_met_fifo;
    fwd_ms_met_fifo_t *c_ms_met_fifo = NULL;
    int32 ret = DRV_E_NONE;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};

    DRV_PTR_VALID_CHECK(bus);
    DRV_PTR_VALID_CHECK(succ);
    sal_memset(&v_ms_met_fifo, 0, sizeof(v_ms_met_fifo));
    if (list_empty(&(cosim_db.sim_fwd_list[SIM_FWD_MS_MET_FIFO])))
    {
        ASIC_DEBUG_BUS_CMP(buf, "%% ERROR! FWD MET_FIFO verify error! <CModel MET_FIFO List is empty, but RTL is not>\n");
        *succ = FALSE;
        return DRV_E_NONE;
    }
    c_ms_met_fifo = list_entry(cosim_db.sim_fwd_list[SIM_FWD_MS_MET_FIFO].next, fwd_ms_met_fifo_t, head);
    ret = ms_met_fifo_bus_decode(bus, &v_ms_met_fifo);
    if (ret)
    {
        *succ = FALSE;
        ASIC_DEBUG_BUS_CMP(buf, "%% ERROR! FWD MET_FIFO bus decode error!\n");
        goto RELEASE;
    }

    *succ = ms_met_fifo_bus_compare(&(c_ms_met_fifo->msg_metfifo),&v_ms_met_fifo);
    list_del(&c_ms_met_fifo->head);
    sal_free(c_ms_met_fifo);
    c_ms_met_fifo = NULL;
    return ret;
RELEASE:
    list_del(&c_ms_met_fifo->head);
    sal_free(c_ms_met_fifo);
    c_ms_met_fifo = NULL;
    return ret;
}

