/****************************************************************************
 * sim_check_rtl_tbl.c: Compare table content on simulation verify platform
 *
 * Copyright: (c)2008 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       ZhouW
 * Date:         2008-11-6
 * Reason:       First Create.
 ****************************************************************************/

 /****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sim_table_chk_interface.h"

/* use to control whether to store information when read table or not, because cmodel maybe read exceed one times
    in the same module but rtl only read one times  */

struct ram_store_node_info_s
{
    list_head_t head;

    uint32 cmodel_index;
    uint32 cmodel_data[MAX_ENTRY_WORD];
    uint32 cmodel_entry_size;
};
typedef struct ram_store_node_info_s ram_store_node_info_t;

/*******************************************************************************
 * Name   : sim_store_table_info
 * Purpose: store read ram information in running case process on cmodel
 * Input  : void
 * Output : none.
 * Return : void
 * Note   : N/A
*******************************************************************************/
int32
sim_store_table_info(uint8 chip_id, uint32 tbl_id, uint32 index, uint32 *data, bool is_write_dsoam)
{
#define RAM_MAX_ENTRY_WORD      32

    ram_store_node_info_t *new_node = NULL;
    char buf[COSIM_PRINT_BUF_MAX_SIZE]= {0};
    uint32 id = SIM_DSOAM_MAX;

    if (!sim_interface_initialize)
    {
        return DRV_E_NONE;
    }

    if (!cosim_db.sim_read_tbl_cosim_flag && (!is_write_dsoam)) /* read table operation */
    {
        return DRV_E_NONE;
    }

    if (!cosim_db.sim_write_tbl_cosim_flag && is_write_dsoam)    /* write table operation */
    {
        return DRV_E_NONE;
    }

    if (CHK_IS_REGISTER(tbl_id)) /* do not store register info */
    {
        return DRV_E_NONE;
    }

#if COSIM_PENDING
    /* zhouw note: control whether the read ram operation will result in creating one node and insert the corresponding linklist */
    if (!sim_check_flag_use_control_insert_linklist_op)
    {
        return DRV_E_NONE;
    }
    /* temp code, do not check those table about stats */
    /* because stats code not update in humber cmodel */
    if (SIM_CHECK_IS_STATS_TABLE(tbl_id))
    {
        return DRV_E_NONE;
    }
#endif

    /* creat new node */
    new_node = sal_malloc(sizeof(ram_store_node_info_t));
    if (NULL == new_node)
    {
        ASIC_DEBUG_BUS_CMP(buf,"No memory, creat new node ERROR!\n");
        goto ERROR;
    }
    sal_memset(new_node, 0, sizeof(ram_store_node_info_t));

    /* fill the node process */
    new_node->cmodel_index= index;
    new_node->cmodel_entry_size = TABLE_ENTRY_SIZE(tbl_id)/ 4;     /* uint : word */
    sal_memcpy(new_node->cmodel_data, data, sizeof(uint32)*RAM_MAX_ENTRY_WORD);

    /* insert the node into the corresponding linklist */
    if (!is_write_dsoam)
    {
        if ((tbl_id == DsEthMep_t) || (tbl_id == DsEthRmep_t) || (tbl_id == DsBfdMep_t) || (tbl_id == DsBfdRmep_t))
        {
            tbl_id = DsEthMep_t; /* special process, these table IDs will store only one linklist, add by zhouw */
        }

        list_add_tail(&new_node->head, &cosim_db.sim_table_info_list[tbl_id]);
    }
    else
    {
        switch (tbl_id) /* TBD, interface convert, add by zhouw */
        {
            case DsEthMep_t:
                id = SIM_DSOAM_DsEthMep;
                break;
            case DsEthRmep_t:
                id = SIM_DSOAM_DsEthRmep;
                break;
            case DsBfdMep_t:
                id = SIM_DSOAM_DsBfdMep;
                break;
            case DsBfdRmep_t:
                id = SIM_DSOAM_DsBfdRmep;
                break;
            case AutoGenPktRxPktStats_t:
                id = SIM_DSOAM_AutoGenPktRxPktStats;
                break;
            case AutoGenPktPktCfg_t:
                id = SIM_DSOAM_AutoGenPktPktCfg;
                break;
            case OamDefectCache_t:
                id = SIM_DSOAM_OamDefectCache;
                break;
            case OamErrorDefectCtl_t:
                id = SIM_DSOAM_OamErrorDefectCtl;
                break;
            case DsOamDefectStatus_t:
                id = SIM_DSOAM_DsOamDefectStatus;
                break;
            default:
                ASIC_DEBUG_BUS_CMP(buf,"INVALID OAM ds tableid = %d!\n", tbl_id);
                return DRV_E_INVALID_PARAMETER;
        }
        list_add_tail(&new_node->head, &cosim_db.sim_oam_wt_table_info_list[id]);
    }

    return DRV_E_NONE;

ERROR:
    //sim_check_rtl_addr_interface_release();

    return DRV_E_NO_MEMORY;

}

/*******************************************************************************
 * Name   : cosim_cmp_table
 * Purpose: Asic will use it to check ram used by rtl and ram used ny cmodel in running case
 * Input  : void
 * Output : none.
 * Return : void
 * Note   : N/A
*******************************************************************************/
int32
cosim_cmp_table(rtl_tbl_info_t *rtl_tbl_info_bus, bool *succ)
{
    uint32 rtl_index = 0;
    uint32 rtl_word_num_entry = 0;
    list_head_t *pos = NULL;
    ram_store_node_info_t *node = NULL;
    uint32 i;
    uint32 tbl_id;
    int32 ret = DRV_E_NONE;
    char line[] = "------------------------------------------------------------";
    char buf[COSIM_PRINT_BUF_MAX_SIZE]= {0};
    *succ = FALSE;
    char table_name[128] = {0};
    list_head_t *cmp_linklist = NULL;
    uint32 id = SIM_DSOAM_MAX;
    bool is_no_find_index = TRUE;
    bool is4w = FALSE;
    uint32 cmodel_entry_size = 0;

    if (!sim_interface_initialize)
    {
        return DRV_E_NONE;
    }

    if (!cosim_db.sim_read_tbl_cosim_flag && (!rtl_tbl_info_bus->is_cmp_oam_wr_table)) /* read table operation */
    {
        return DRV_E_NONE;
    }

    if (!cosim_db.sim_write_tbl_cosim_flag && rtl_tbl_info_bus->is_cmp_oam_wr_table)    /* write table operation */
    {
        return DRV_E_NONE;
    }

    if (NULL == rtl_tbl_info_bus)
    {
        ASIC_DEBUG_BUS_CMP(buf,"The pointer about tbl info bus from RTL is INVALID!\n");
        return DRV_E_INVALID_PTR;
    }

    if (NULL == rtl_tbl_info_bus->data)
    {
        ASIC_DEBUG_BUS_CMP(buf,"The data pointer about tbl info bus from RTL is INVALID!\n");
        return DRV_E_INVALID_PTR;
    }

    /* get asic tbl bus info */
    rtl_word_num_entry = rtl_tbl_info_bus->word_num_entry;
    tbl_id = rtl_tbl_info_bus->table_id;

    sal_memset(table_name, 0, 128);
    ret = drv_get_tbl_string_by_id(tbl_id, table_name);
    if (ret < 0)
    {
        ASIC_DEBUG_BUS_CMP(buf, "RTL's table id error: %d can not convet to table name, ERROR!\n", tbl_id);
        return DRV_E_NOT_FOUND_TBL;
    }

    if (CHK_IS_REGISTER(rtl_tbl_info_bus->table_id))
    {
        ASIC_DEBUG_BUS_CMP(buf, "Do not compare register %s !!!\n", table_name);
        return DRV_E_NONE;
    }

    if (rtl_tbl_info_bus->is_cmp_oam_wr_table)
    {
        switch (tbl_id)/* TBD, interface convert, add by zhouw */
        {
            case DsEthMep_t:
                id = SIM_DSOAM_DsEthMep;
                break;
            case DsEthRmep_t:
                id = SIM_DSOAM_DsEthRmep;
                break;
            case DsBfdMep_t:
                id = SIM_DSOAM_DsBfdMep;
                break;
            case DsBfdRmep_t:
                id = SIM_DSOAM_DsBfdRmep;
                break;
            case AutoGenPktRxPktStats_t:
                id = SIM_DSOAM_AutoGenPktRxPktStats;
                break;
            case AutoGenPktPktCfg_t:
                id = SIM_DSOAM_AutoGenPktPktCfg;
                break;
            case OamDefectCache_t:
                id = SIM_DSOAM_OamDefectCache;
                break;
            case OamErrorDefectCtl_t:
                id = SIM_DSOAM_OamErrorDefectCtl;
                break;
            case DsOamDefectStatus_t:
                id = SIM_DSOAM_DsOamDefectStatus;
                break;
            default:
                ASIC_DEBUG_BUS_CMP(buf,"INVALID OAM ds tableid = %d when cmp!\n", tbl_id);
                return DRV_E_INVALID_PARAMETER;
        }
        cmp_linklist = &cosim_db.sim_oam_wt_table_info_list[id];
    }
    else
    {
        if ((tbl_id == DsEthMep_t) || (tbl_id == DsEthRmep_t) || (tbl_id == DsBfdMep_t) || (tbl_id == DsBfdRmep_t))
        {
            tbl_id = DsEthMep_t; /* special process, these table IDs will store into only one linklist, add by zhouw */
        }

        if (tbl_id == DsNextHop4W_t)
        {
            tbl_id = DsNextHop8W_t;
            is4w = TRUE;
        }

        cmp_linklist = &cosim_db.sim_table_info_list[tbl_id];
    }

    /* search in cmodel corresponding table's linklist */
    list_for_each(pos, cmp_linklist)
    {
        rtl_index = rtl_tbl_info_bus->index;
        node = list_entry(pos, ram_store_node_info_t, head);

        if ((is4w) && (rtl_index%2))
        {
            cmodel_entry_size = node->cmodel_entry_size+1;
        }
        else
        {
            cmodel_entry_size = node->cmodel_entry_size;
        }

        /* check the same tbl's entry size between RTL and Cmodel */
        if (rtl_word_num_entry != cmodel_entry_size)
        {
            switch (tbl_id)
            {
                case DsPhyPortExt_t:
                case DsDestPort_t:
                case DsSrcInterface_t:
                case DsStormCtl_t:
                case DsQueueNumGenCtl_t:
                    /* Don't compare entry size for these special table */
                    break;
                default:
                    ASIC_DEBUG_BUS_CMP(buf,"The same table entry size is not equal between RTL and CMODEL! ERROR\n");
                    ASIC_DEBUG_BUS_CMP(buf,"the rtl_word_num_entry: 0x%x is not equal to cmodel_entry_size: 0x%x !!\n",
                            rtl_word_num_entry, cmodel_entry_size);
                    ret = DRV_E_TBL_ENTRY_SIZE_NOT_MATCH;
                    goto DUMP_INFO;
            }
        }

        /* check the table's entry index */
        if (tbl_id == DsMpls_t)
        {
            rtl_index = rtl_index/2;
        }

        if (rtl_index != node->cmodel_index)
        {
            continue;
        }
        is_no_find_index = FALSE;

        /* check the entry index's data */
        for (i = 0; i < rtl_word_num_entry; i++)
        {
            if (!is4w)
            {
                if (node->cmodel_data[rtl_word_num_entry-i-1] != rtl_tbl_info_bus->data[i])
                {
                    break;
                }
            }
            else
            {
                if (rtl_index%2)
                {
                    if (node->cmodel_data[3+rtl_word_num_entry-i-1] != rtl_tbl_info_bus->data[i])
                    {
                        break;
                    }
                }
                else
                {
                    if (node->cmodel_data[rtl_word_num_entry-i-1] != rtl_tbl_info_bus->data[i])
                    {
                        break;
                    }
                }
            }

            if (i == (rtl_word_num_entry - 1))
            {
                *succ = TRUE; /* match */

                /* release the matched node */
                list_del(&node->head);

                if (NULL != node)
                {
                    sal_free(node);
                    node = NULL;
                }
                /*ASIC_DEBUG_BUS_CMP(buf,"PASS: table %s index 0x%x check is ok!!!\n", table_name,rtl_index);*/

                return DRV_E_NONE;
            }
        }
    }

DUMP_INFO:
    if (*succ == FALSE)
    {
        ASIC_DEBUG_BUS_CMP(buf, "RTL get data is not match with Cmodel config!\n");
        if (rtl_tbl_info_bus->is_cmp_oam_wr_table)
        {
            ASIC_DEBUG_BUS_CMP(buf,"\nERROR! RTL Write table %s index 0x%x !", table_name,rtl_index);
        }
        else
        {
            ASIC_DEBUG_BUS_CMP(buf,"\nERROR! RTL read table %s index 0x%x !", table_name,rtl_index);
        }
        ASIC_DEBUG_BUS_CMP(buf,"\n%-.40s", line);
        ASIC_DEBUG_BUS_CMP(buf,"\n%-20s%-20s", table_name, "ASIC");
        ASIC_DEBUG_BUS_CMP(buf,"\n%-.40s", line);
        ASIC_DEBUG_BUS_CMP(buf,"\n%-20s0x%-18x", "Index", rtl_index);
        ASIC_DEBUG_BUS_CMP(buf,"\n%-20s0x%-18x", "Size", rtl_word_num_entry);
        for (i = 0; i < rtl_word_num_entry; i++)
        {
            ASIC_DEBUG_BUS_CMP(buf,"\n%-20s0x%-18x", "Data",rtl_tbl_info_bus->data[i]);
        }
        ASIC_DEBUG_BUS_CMP(buf,"\n%-.40s\n", line);

        if (list_empty((struct list_head *)cmp_linklist))
        {
            ASIC_DEBUG_BUS_CMP(buf,"\nERROR! Cmodel has not stored the table [%s] when do co-sim!", table_name);
        }
        else
        {
            if (is_no_find_index)   /* cmodel do not read/write the index's table */
            {
                if (rtl_tbl_info_bus->is_cmp_oam_wr_table)
                {
                    ASIC_DEBUG_BUS_CMP(buf,"\nERROR! CMODEL do not write table %s 's index 0x%x !", table_name, rtl_index);
                }
                else
                {
                    ASIC_DEBUG_BUS_CMP(buf,"\nERROR! CMODEL do not read table %s 's index 0x%x !", table_name, rtl_index);
                }
                ASIC_DEBUG_BUS_CMP(buf,"\nNOTE: if is DsEthMep/DsEthRmep/DsBfdMep/DsBfdRmep, tableid do not care!");
                return ret;
            }

            /* Dump the table in Cmodel */
            ram_store_node_info_t *dump_node = NULL;
            list_head_t *dump_pos = NULL;
            bool is_same_index = FALSE;
            ASIC_DEBUG_BUS_CMP(buf, "++++ Start Dump CModel table %s index 0x%x info: \n", table_name, rtl_index);
            list_for_each(dump_pos, cmp_linklist)
            {
                dump_node = list_entry(dump_pos, ram_store_node_info_t, head);

                if (dump_node->cmodel_index == rtl_index) /* only printf the same index' cmodel node info */
                {
                    is_same_index |= TRUE;
                    ASIC_DEBUG_BUS_CMP(buf,"\n%-.40s", line);
                    ASIC_DEBUG_BUS_CMP(buf,"\n%-20s%-20s", table_name, "CMODEL");
                    ASIC_DEBUG_BUS_CMP(buf,"\n%-.40s", line);
                    ASIC_DEBUG_BUS_CMP(buf,"\n%-20s0x%-18x", "Index", dump_node->cmodel_index);
                    ASIC_DEBUG_BUS_CMP(buf,"\n%-20s0x%-18x", "Size", dump_node->cmodel_entry_size);
                    for (i = 0; i < dump_node->cmodel_entry_size; i++)
                    {
                        ASIC_DEBUG_BUS_CMP(buf,"\n%-20s0x%-18x", "Data",dump_node->cmodel_data[dump_node->cmodel_entry_size-i-1]);
                    }
                    ASIC_DEBUG_BUS_CMP(buf,"\n%-.40s\n", line);
                }
            }

            if (is_same_index == FALSE)
            {
                ASIC_DEBUG_BUS_CMP(buf, "CModel do not read table %s 's index 0x%x\n", table_name, rtl_index);
                ASIC_DEBUG_BUS_CMP(buf, "CModel only read table %s 's index = ", table_name);
                list_for_each(dump_pos, cmp_linklist)
                {
                    dump_node = list_entry(dump_pos, ram_store_node_info_t, head);
                    ASIC_DEBUG_BUS_CMP(buf, "0x%x ", dump_node->cmodel_index);
                }
                ASIC_DEBUG_BUS_CMP(buf, "\n");
            }

            ASIC_DEBUG_BUS_CMP(buf, "++++ Close Dump CModel table %s index 0x%x info: \n", table_name, rtl_index);
        }
    }

    return ret;
}

static void
_sim_dump_outpkt(sim_pkt_cmp_t * sim_pkt, FILE *fp)
{
    char line[] = "---------------------------------";
    uint8 i = 0;

    if (fp == NULL)
    {
        return;
    }

    sal_fprintf(fp, "\n%s", line);
    sal_fprintf(fp, "\nCMODEL PktLen is:0x%x", sim_pkt->packet_length);
    sal_fprintf(fp, "\nCMODEL ChanId is:0x%x", sim_pkt->chan_id);
    sal_fprintf(fp, "\nCMODEL ChipId is :0x%x", sim_pkt->chip_id);
    sal_fprintf(fp, "\nCMODEL Packet is:");

    for (i = 0; i < sim_pkt->packet_length; i++)
    {
        sal_fprintf(fp, "%02x", sim_pkt->pkt[i]);
        if ((i + 1) % 16 == 0)
        {
            sal_fprintf(fp, "\n");
        }
    }

    sal_fprintf(fp,"\n%s",line);
}


/*******************************************************************************
 * Name   : cosim_chk_table_empty
 * Purpose: check cmodel store linklist whether it is null or not
 * Input  : void
 * Output : none.
 * Return : void
 * Note   : N/A
*******************************************************************************/
int32
cosim_chk_outpkt_empty(FILE *fp, uint8 mod_id)
{
    uint32 i;
    list_head_t *pos = NULL;
    sim_pkt_cmp_t *tmp_sim_pkt = NULL;
    char buf[COSIM_PRINT_BUF_MAX_SIZE] = {0};

    if (cosim_db.sim_dump_flag)
    {
        if (!fp)
        {
           return DRV_E_NONE;
        }

        sal_fprintf(fp, "\n%-6s%-28s%-6s", "*****", "Dump OutPkt_LinkList ", "*****");
    }

    for (i = 0; i < SIM_MAX_CHANN_NUM; i ++)
    {
        if(!list_empty(&(cosim_db.sim_outpkt_list[mod_id][i])))
        {
            ASIC_DEBUG_BUS_CMP(buf,"ERROR! CMODEL packet num is more than RTL!\n");

            list_for_each(pos, &(cosim_db.sim_outpkt_list[mod_id][i]))
            {
                tmp_sim_pkt = list_entry(pos, sim_pkt_cmp_t, head);
                if (cosim_db.sim_dump_flag)
                {
                    _sim_dump_outpkt(tmp_sim_pkt, fp);
                }
            }

            goto ERROR;
        }
    }

    if (cosim_db.sim_dump_flag)
    {
        sal_fprintf(fp, "\n%-6s%-28s%-6s", "*****", "Finish Dump OutPkt_LinkList ", "*****");
    }

    return DRV_E_NONE;

ERROR:
    for (i = 0; i < SIM_MAX_CHANN_NUM; i++)
    {
        list_del_all_and_free(&(cosim_db.sim_outpkt_list[mod_id][i]));
    }

    return DRV_CHECK_LINKLIST_IS_NOT_EMPTY;
}

static int32
_sim_dump_table(uint32 tbl_id, FILE *fp, list_head_t *link_list)
{
    int32 ret;
    char name[128] = {0};
    ram_store_node_info_t *node = NULL;
    list_head_t *pos = NULL;
    bool first_flag = TRUE;
    bool first_line = TRUE;
    uint32 i;
    char line[] = "------------------------------------------------------------";
    char over_line[] = "************************************************************";
    char buf[COSIM_PRINT_BUF_MAX_SIZE]= {0};

    /* check table id */
    ret = drv_get_tbl_string_by_id(tbl_id, name);
    if (ret < 0)
    {
        ASIC_DEBUG_BUS_CMP(buf,"Not find the table id (_sim_dump_table): 0x%0x\n", tbl_id);
        return DRV_E_NOT_FOUND_TBL;
    }

    if (fp != NULL)
    {
        sal_fprintf(fp, "\n\n%.40s", over_line);
        sal_fprintf(fp, "\n%-15s%25s", "Table name: ", name);
        sal_fprintf(fp, "\n%.40s", line);
    }

    /* start dump linklist */
    list_for_each(pos, link_list)
    {
        node = list_entry(pos, ram_store_node_info_t, head);

        if (fp != NULL)
        {
            if (first_flag)
            {
                sal_fprintf(fp, "\n%-10s%-20s%-10s", "Index", "Entry_Size(word)", "Value");
                first_flag = FALSE;
            }

            first_line = TRUE;
            for (i = 0; i < node->cmodel_entry_size; i++)
            {
                if (first_line)
                {
                    sal_fprintf(fp, "\n0x%-8x0x%-18x0x%-8x", node->cmodel_index, node->cmodel_entry_size, node->cmodel_data[i]);
                    first_line = FALSE;
                }
                else
                {
                    sal_fprintf(fp, "\n%-30s0x%-8x", " ", node->cmodel_data[i]);
                }
            }
            sal_fprintf(fp, "\n%.40s", line);
        }
        else   /* no dump operation, find linklist is not null, print check info and return */
        {
            ASIC_DEBUG_BUS_CMP(buf, "Cmodel Linklists still have Members! Please check it! \n");
            return DRV_E_NONE;  /* here need retun error and assure cmodel and rtl identical */
        }
    }

    return DRV_E_NONE;
}

int32
cosim_chk_table_empty(FILE *fp)
{
    uint32 tbl_id = MaxTblId_t;
    int32 ret = DRV_E_NONE;
    bool is_empty = TRUE;
    list_head_t *linklist = NULL;
    sim_oam_write_ds_t id;

    if (cosim_db.sim_dump_flag)
    {
        if (!fp)
        {
            return DRV_E_NONE;
        }
    }

    if (cosim_db.sim_chk_write_tbl_flag)
    {
        if (cosim_db.sim_dump_flag)
        {
            sal_fprintf(fp, "\n%-6s%-28s%-6s", "*****", "Dump Table_LinkList(Write) ", "*****");
        }

        for (id = SIM_DSOAM_DsEthMep; id < SIM_DSOAM_MAX; id++)
        {
            switch (id)       /* TBD, interface convert, add by zhouw */
            {
                case SIM_DSOAM_DsEthMep:
                    tbl_id = DsEthMep_t;
                    break;
                case SIM_DSOAM_DsEthRmep:
                    tbl_id = DsEthRmep_t;
                    break;
                case SIM_DSOAM_DsBfdMep:
                    tbl_id =DsBfdMep_t;
                    break;
                case SIM_DSOAM_AutoGenPktRxPktStats:
                    tbl_id = AutoGenPktRxPktStats_t;
                    break;
                case SIM_DSOAM_AutoGenPktPktCfg:
                    tbl_id = AutoGenPktPktCfg_t;
                    break;
                case SIM_DSOAM_OamDefectCache:
                    tbl_id = OamDefectCache_t;
                    break;
                case SIM_DSOAM_OamErrorDefectCtl:
                    tbl_id = OamErrorDefectCtl_t;
                    break;
                case SIM_DSOAM_DsOamDefectStatus:
                    tbl_id = DsOamDefectStatus_t;
                    break;
                default:
                    tbl_id = DsBfdRmep_t;
                    break;
            }

            linklist = &cosim_db.sim_oam_wt_table_info_list[id];
            /* check whether each table's link list is empty */
            if (!(list_empty(linklist)))
            {
                is_empty = FALSE;

                if (cosim_db.sim_dump_flag)
                {
                    /* dump the linklist process */
                    ret = _sim_dump_table(tbl_id, fp, linklist);
                    if (ret < 0)
                    {
                        return ret;
                    }
                }
            }
        }

        if (cosim_db.sim_dump_flag)
        {
            sal_fprintf(fp, "\n%-6s%-28s%-6s", "*****", "Finish Dump Table_LinkList(Write) ", "*****");
        }
    }
#if 0
    if (cosim_db.sim_chk_read_tbl_flag)
    {
        if (cosim_db.sim_dump_flag)
        {
            sal_fprintf(fp, "\n%-6s%-28s%-6s", "*****", "Dump Table_LinkList(Read) ", "*****");
        }
        /* search each linklist base on table id */
        for (tbl_id = 0; tbl_id < MaxTblId_t; tbl_id++)
        {
            linklist = &(cosim_db.sim_table_info_list[tbl_id]);
            /* check whether each table's link list is empty */
            if (!(list_empty(linklist)))
            {
                is_empty = FALSE;

                if (cosim_db.sim_dump_flag)
                {
                    /* dump the linklist process */
                    ret = _sim_dump_table(tbl_id, fp, linklist);
                    if (ret < 0)
                    {
                        return ret;
                    }
                }
            }
        }

        if (cosim_db.sim_dump_flag)
        {
            sal_fprintf(fp, "\n%-6s%-28s%-6s", "*****", "Finish Dump Table_LinkList(Read) ", "*****");
        }
    }
#endif

    if (is_empty == FALSE)
    {
       return DRV_E_CHECK_CMODEL_LINKLIST_IS_NOT_EMPTY;
    }
    else
    {
        return DRV_E_NONE;
    }
}

