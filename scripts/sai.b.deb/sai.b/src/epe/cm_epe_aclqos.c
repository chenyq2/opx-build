/****************************************************************************
 * cm_epe_aclqos.c    Provides EPE aclqos handle function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz.
 * Date:         2010-10-24.
 * Reason:       First Create.
 *
 * Revision:     V1.0.
 * Author:       JiaK.
 * Date:         2010-11-24.
 * Reason:       Sync spec Revision 5.0.0.
 *
 * Revision:     V2.0.
 * Author:       JiaK.
 * Date:         2010-04-11.
 * Reason:       Sync spec Revision 3.0.3.
 *
 * Revision:     V4.2.1.
 * Author:       Shenhg.
 * Date:         2010-07-04.
 * Reason:       Sync spec Revision 4.2.1.
 *
 * Revision:     V4.2.1.
 * Author:       JiangJf.
 * Date:         2010-07-04.
 * Reason:       Sync epe oam for spec Revision 4.2.1.
 *
 * Revision:     V4.28.2.
 * Author:       wangcy.
 * Date:         2011-09-27.
 * Reason:       Sync spec Revision 4.28.2.
 *
 * Revision:     V4.29.3.
 * Author:       wangcy.
 * Date:         2011-10-10.
 * Reason:       Sync spec Revision 4.29.3.
 *
 * Revision:     V4.31.0
 * Author:       JiaK.
 * Date:         2011-10-22.
 * Reason:       sync spec to v4.31.0
 *
 * Revision:     V5.1.0
 * Author:       JiaK.
 * Date:         2011-12-13.
 * Reason:       sync spec to v5.1.0
 *
 * Revision:     V5.6.0
 * Author:       JiaK.
 * Date:         2012-01-7.
 * Reason:       sync spec to v5.6.0
 *
 * Revision:     V5.9.0
 * Author:       JiaK.
 * Date:         2012-01-19.
 * Reason:       sync spec to v5.9.0
 *
 * Revision:     V5.9.1
 * Author:       Wangcy.
 * Date:         2012-02-04.
 * Reason:       sync spec to v5.9.1
 *
 * Revision:     V5.11.0
 * Author:       Wangcy.
 * Date:         2012-03-01.
 * Reason:       sync spec to v5.11.0
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
#define MAC_ADDRESS_LENGTH 6

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/
struct cm_epe_aclqos_lookup_result_s
{
    uint8  acl_result_valid0;
    uint8  acl_result_valid1;
    uint8  acl_result_valid2;
    uint8  acl_result_valid3;
};
typedef struct cm_epe_aclqos_lookup_result_s cm_epe_aclqos_lookup_result_t;

struct cm_epe_acl_qos_key_info_s
{
    uint16 ether_type;
    uint8  stag_cos;
    uint8  stag_cfi;
    uint8  ctag_cos;
    uint8  ctag_cfi;
    uint8  layer3_type;
    uint8  mac_da[MAC_ADDRESS_LENGTH];
    uint8  layer2_type;
    uint8  mac_sa[MAC_ADDRESS_LENGTH];
    uint8  ip_header_error;
    uint8  is_tcp;
    uint8  is_udp;
    uint8  ip_options;
    uint8  frag_info;
    uint8  dscp;
    uint16 l4_info_mapped;
    uint16 l4_dest_port;
    uint16 l4_source_port;
    uint32 ipv6_flow_label;
    uint32 ipv6_da[4];
    uint32 ipv6_sa[4];
    uint32 ipv4_da;
    uint32 ipv4_sa;
    uint32 mpls_label0;
    uint32 mpls_label1;
    uint32 mpls_label2;
    uint32 mpls_label3;
    uint16 cvlan_id;
    uint16 svlan_id;
    uint32 acl_label_high;
    uint32 acl_label_low;
    uint16 vlan_ptr;
    uint8  is_label;
    uint8  routed_packet;
    uint8  acl_use_label;
    uint8  sub_tbl_id;
    uint8  is_acl_qos_key;
    uint8  ipv4_packet;
    uint8  direction;
    uint8  svlan_id_valid;
    uint8  cvlan_id_valid;
    uint8  is_arp_key;
    uint8  udf_byte0;
    uint8  udf_byte1;
    uint8  udf_byte2;
    uint8  udf_byte3;
};
typedef struct cm_epe_acl_qos_key_info_s cm_epe_acl_qos_key_info_t;

struct cm_epe_acl_qos_info_s
{
    uint32 acl0_stats_valid :1;
    uint32 acl1_stats_valid :1;
    uint32 acl2_stats_valid :1;
    uint32 acl3_stats_valid :1;
    uint32 ds_acl_flow_policer_valid :1;
    uint32 ds_acl_agg_flow_policer_valid :1;
    uint32 acl0_stats_ptr :16;
    uint32 acl1_stats_ptr :16;
    uint32 acl2_stats_ptr :16;
    uint32 acl3_stats_ptr :16;

};
typedef struct cm_epe_acl_qos_info_s cm_epe_acl_qos_info_t;

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/

/****************************************************************************
 * Name:      _cm_epe_aclqos_process_ds_acl0
 * Purpose:   EPE process dsqos and dsacl and get the information from dsqos
              and dsacl.
 * Parameters:
 * Input:     ipkt  -- pointer to epe_in_pkt_t
 *            p_acl_qos_info -- pointer to epe_acl_qos_info
 * Output:    ipkt  -- pointer to epe_in_pkt_t
 * Return:    DRV_E_NONE = success.
 *                 Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_aclqos_process_ds_acl0(epe_in_pkt_t* ipkt, cm_epe_acl_qos_info_t* p_acl_qos_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *)ipkt->pkt_info;
    ds_acl_t* acl_data = NULL;
    epe_acl_qos_ctl_t epe_acl_qos_ctl;
    uint16 random_threshold = 0;
    uint16 stats_ptr = 0;
    uint32 random = 0;
    uint32 cmd = 0;
    uint8  chip_id = ipkt->chip_id;

    /* get DSAclQos Data */
    acl_data = (ds_acl_t *)pkt_info->acl_data0;

    sal_memset(&epe_acl_qos_ctl, 0, sizeof(epe_acl_qos_ctl));
    cmd = DRV_IOR(EpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &epe_acl_qos_ctl));

    /* process discard flags */
    if (acl_data->discard_packet && ((OAM_NONE == pkt_info->rx_oam_type ) || epe_acl_qos_ctl.oam_obey_acl_discard))
    {
        if(!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_ACL_DISCARD;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE DsAcl discardPacket is set by acl0!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* process random log */
#if defined(SDK_IN_KERNEL)
    /* We must NOT generate the ramdom when we do ASIC simulation, since it will lead to mismatch
    between ASIC and CModel. But we need use it when SDK in Kernel, for software emulation need
    it to do some testing */
    ctcutil_rand(0, 0x7FFF, &random);
#endif
    random_threshold = (1 << acl_data->random_threshold_shift);
    if (acl_data->random_log_en && (random < random_threshold))
    {
        pkt_info->acl_log_en0 = TRUE;
        pkt_info->acl_log_id0 = acl_data->acl_log_id;
    }

    /* flow policer */
    if (0x0 != acl_data->flow_policer_ptr)
    {
        pkt_info->flow_policer_valid = TRUE;
        pkt_info->flow_policer_ptr = acl_data->flow_policer_ptr;
        p_acl_qos_info->ds_acl_flow_policer_valid = TRUE;
    }

    if (0x0 != acl_data->agg_flow_policer_ptr)
    {
        pkt_info->agg_flow_policer_valid = TRUE;
        pkt_info->agg_flow_policer_ptr = acl_data->agg_flow_policer_ptr;
        p_acl_qos_info->ds_acl_agg_flow_policer_valid = TRUE;
    }

    /* stats */
    stats_ptr = (acl_data->stats_ptr15_14<<14)|(acl_data->stats_ptr13_12<<12)|
                (acl_data->stats_ptr11_4<<4)|(acl_data->stats_ptr3_0);
    if (0x0 != stats_ptr)
    {
        p_acl_qos_info->acl0_stats_valid = TRUE;
        p_acl_qos_info->acl0_stats_ptr = stats_ptr;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_aclqos_process_ds_acl1
 * Purpose:   EPE process dsqos and dsacl and get the information from dsqos
              and dsacl.
 * Parameters:
 * Input:     ipkt  -- pointer to epe_in_pkt_t
 *            p_acl_qos_info -- pointer to epe_acl_qos_info
 * Output:    ipkt  -- pointer to epe_in_pkt_t
 * Return:    DRV_E_NONE = success.
 *                 Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_aclqos_process_ds_acl1(epe_in_pkt_t* ipkt, cm_epe_acl_qos_info_t* p_acl_qos_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *)ipkt->pkt_info;
    ds_acl_t* acl_data = NULL;
    epe_acl_qos_ctl_t epe_acl_qos_ctl;
    uint16 random_threshold = 0;
    uint16 stats_ptr = 0;
    uint32 random = 0;
    uint32 cmd = 0;
    uint8  chip_id = ipkt->chip_id;

    /* get DSAclQos Data */
    acl_data = (ds_acl_t *)pkt_info->acl_data1;

    sal_memset(&epe_acl_qos_ctl, 0, sizeof(epe_acl_qos_ctl));
    cmd = DRV_IOR(EpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &epe_acl_qos_ctl));

    /* process discard flags */
    if (acl_data->discard_packet && ((OAM_NONE == pkt_info->rx_oam_type ) || epe_acl_qos_ctl.oam_obey_acl_discard))
    {
        if(!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_ACL_DISCARD;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE DsAcl discardPacket is set by acl1!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* process random log */
#if defined(SDK_IN_KERNEL)
    /* We must NOT generate the ramdom when we do ASIC simulation, since it will lead to mismatch
    between ASIC and CModel. But we need use it when SDK in Kernel, for software emulation need
    it to do some testing */
    ctcutil_rand(0, 0x7FFF, &random);
#endif
    random_threshold = (1 << acl_data->random_threshold_shift);
    if (acl_data->random_log_en && (random < random_threshold))
    {
        pkt_info->acl_log_en1 = TRUE;
        pkt_info->acl_log_id1 = acl_data->acl_log_id;
    }

    /* flow policer */
    if (0x0 != acl_data->flow_policer_ptr && !p_acl_qos_info->ds_acl_flow_policer_valid)
    {
        pkt_info->flow_policer_valid = TRUE;
        pkt_info->flow_policer_ptr = acl_data->flow_policer_ptr;
        p_acl_qos_info->ds_acl_flow_policer_valid = TRUE;
    }

    if (0x0 != acl_data->agg_flow_policer_ptr && !p_acl_qos_info->ds_acl_agg_flow_policer_valid)
    {
        pkt_info->agg_flow_policer_valid = TRUE;
        pkt_info->agg_flow_policer_ptr = acl_data->agg_flow_policer_ptr;
        p_acl_qos_info->ds_acl_agg_flow_policer_valid = TRUE;
    }

    /* stats */
    stats_ptr = (acl_data->stats_ptr15_14<<14)|(acl_data->stats_ptr13_12<<12)|
                (acl_data->stats_ptr11_4<<4)|(acl_data->stats_ptr3_0);
    if (0x0 != stats_ptr)
    {
        p_acl_qos_info->acl1_stats_valid = TRUE;
        p_acl_qos_info->acl1_stats_ptr = stats_ptr;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_aclqos_process_ds_acl2
 * Purpose:   EPE process dsqos and dsacl and get the information from dsqos
              and dsacl.
 * Parameters:
 * Input:     ipkt  -- pointer to epe_in_pkt_t
 *            p_acl_qos_info -- pointer to epe_acl_qos_info
 * Output:    ipkt  -- pointer to epe_in_pkt_t
 * Return:    DRV_E_NONE = success.
 *                 Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_aclqos_process_ds_acl2(epe_in_pkt_t* ipkt, cm_epe_acl_qos_info_t* p_acl_qos_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *)ipkt->pkt_info;
    ds_acl_t* acl_data = NULL;
    epe_acl_qos_ctl_t epe_acl_qos_ctl;
    uint16 random_threshold = 0;
    uint16 stats_ptr = 0;
    uint32 random = 0;
    uint32 cmd = 0;
    uint8  chip_id = ipkt->chip_id;

    /* get DSAclQos Data */
    acl_data = (ds_acl_t *)pkt_info->acl_data2;

    sal_memset(&epe_acl_qos_ctl, 0, sizeof(epe_acl_qos_ctl));
    cmd = DRV_IOR(EpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &epe_acl_qos_ctl));

    /* process discard flags */
    if (acl_data->discard_packet && ((OAM_NONE == pkt_info->rx_oam_type ) || epe_acl_qos_ctl.oam_obey_acl_discard))
    {
        if(!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_ACL_DISCARD;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE DsAcl discardPacket is set by acl2!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* process random log */
#if defined(SDK_IN_KERNEL)
    /* We must NOT generate the ramdom when we do ASIC simulation, since it will lead to mismatch
    between ASIC and CModel. But we need use it when SDK in Kernel, for software emulation need
    it to do some testing */
    ctcutil_rand(0, 0x7FFF, &random);
#endif
    random_threshold = (1 << acl_data->random_threshold_shift);
    if (acl_data->random_log_en && (random < random_threshold))
    {
        pkt_info->acl_log_en2 = TRUE;
        pkt_info->acl_log_id2 = acl_data->acl_log_id;
    }

    /* flow policer */
    if (0x0 != acl_data->flow_policer_ptr && !p_acl_qos_info->ds_acl_flow_policer_valid)
    {
        pkt_info->flow_policer_valid = TRUE;
        pkt_info->flow_policer_ptr = acl_data->flow_policer_ptr;
        p_acl_qos_info->ds_acl_flow_policer_valid = TRUE;
    }

    if (0x0 != acl_data->agg_flow_policer_ptr && !p_acl_qos_info->ds_acl_agg_flow_policer_valid)
    {
        pkt_info->agg_flow_policer_valid = TRUE;
        pkt_info->agg_flow_policer_ptr = acl_data->agg_flow_policer_ptr;
        p_acl_qos_info->ds_acl_agg_flow_policer_valid = TRUE;
    }

    /* stats */
    stats_ptr = (acl_data->stats_ptr15_14<<14)|(acl_data->stats_ptr13_12<<12)|
                (acl_data->stats_ptr11_4<<4)|(acl_data->stats_ptr3_0);
    if (0x0 != stats_ptr)
    {
        p_acl_qos_info->acl2_stats_valid = TRUE;
        p_acl_qos_info->acl2_stats_ptr = stats_ptr;
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_aclqos_process_ds_acl3
 * Purpose:   EPE process dsqos and dsacl and get the information from dsqos
              and dsacl.
 * Parameters:
 * Input:     ipkt  -- pointer to epe_in_pkt_t
 *            p_acl_qos_info -- pointer to epe_acl_qos_info
 * Output:    ipkt  -- pointer to epe_in_pkt_t
 * Return:    DRV_E_NONE = success.
 *                 Other = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_aclqos_process_ds_acl3(epe_in_pkt_t* ipkt, cm_epe_acl_qos_info_t* p_acl_qos_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *)ipkt->pkt_info;
    ds_acl_t* acl_data = NULL;
    epe_acl_qos_ctl_t epe_acl_qos_ctl;
    uint16 random_threshold = 0;
    uint16 stats_ptr = 0;
    uint32 random = 0;
    uint32 cmd = 0;
    uint8  chip_id = ipkt->chip_id;

    /* get DSAclQos Data */
    acl_data = (ds_acl_t *)pkt_info->acl_data3;

    sal_memset(&epe_acl_qos_ctl, 0, sizeof(epe_acl_qos_ctl));
    cmd = DRV_IOR(EpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &epe_acl_qos_ctl));

    /* process discard flags */
    if (acl_data->discard_packet && ((OAM_NONE == pkt_info->rx_oam_type ) || epe_acl_qos_ctl.oam_obey_acl_discard))
    {
        if(!pkt_info->discard)
        {
            pkt_info->discard_type = EPE_DISCARD_EGRESS_ACL_DISCARD;
            pkt_info->discard = TRUE;

            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE DsAcl discardPacket is set by acl3!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }
    }

    /* process random log */
#if defined(SDK_IN_KERNEL)
    /* We must NOT generate the ramdom when we do ASIC simulation, since it will lead to mismatch
    between ASIC and CModel. But we need use it when SDK in Kernel, for software emulation need
    it to do some testing */
    ctcutil_rand(0, 0x7FFF, &random);
#endif
    random_threshold = (1 << acl_data->random_threshold_shift);
    if (acl_data->random_log_en && (random < random_threshold))
    {
        pkt_info->acl_log_en3 = TRUE;
        pkt_info->acl_log_id3 = acl_data->acl_log_id;
    }

    /* flow policer */
    if (0x0 != acl_data->flow_policer_ptr && !p_acl_qos_info->ds_acl_flow_policer_valid)
    {
        pkt_info->flow_policer_valid = TRUE;
        pkt_info->flow_policer_ptr = acl_data->flow_policer_ptr;
        p_acl_qos_info->ds_acl_flow_policer_valid = TRUE;
    }

    if (0x0 != acl_data->agg_flow_policer_ptr && !p_acl_qos_info->ds_acl_agg_flow_policer_valid)
    {
        pkt_info->agg_flow_policer_valid = TRUE;
        pkt_info->agg_flow_policer_ptr = acl_data->agg_flow_policer_ptr;
        p_acl_qos_info->ds_acl_agg_flow_policer_valid = TRUE;
    }

    /* stats */
    stats_ptr = (acl_data->stats_ptr15_14<<14)|(acl_data->stats_ptr13_12<<12)|
                (acl_data->stats_ptr11_4<<4)|(acl_data->stats_ptr3_0);
    if (0x0 != stats_ptr)
    {
        p_acl_qos_info->acl3_stats_valid = TRUE;
        p_acl_qos_info->acl3_stats_ptr = stats_ptr;
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:      _cm_epe_aclqos_process_flow_stats
 * Purpose:   EPE process da acl qos lookup result.
 * Parameters:
 * Input:     ipkt  -- point to epe_in_pkt_t store epe packet info.
 *            p_acl_qos_info -- pointer to struct cm_epe_acl_qos_info_t.
 * Output:    ipkt -- point to epe_in_pkt_t store epe packet info.
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_aclqos_process_flow_stats(epe_in_pkt_t *ipkt, cm_epe_acl_qos_info_t* p_acl_qos_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*)ipkt->pkt_info;

    uint8 acl_stats0_valid = FALSE;
    uint8 acl_stats1_valid = FALSE;
    uint16 acl_stats0_ptr = 0;
    uint16 acl_stats1_ptr = 0;

    /* FLOW STATS RPOCESS */
    /* ACL flow stats priority: acl0 > acl1 > acl2 > acl3 */
    if (p_acl_qos_info->acl0_stats_valid)
    {
        acl_stats0_valid = TRUE;
        acl_stats0_ptr = p_acl_qos_info->acl0_stats_ptr;
    }

    if (p_acl_qos_info->acl1_stats_valid)
    {
        if (!acl_stats0_valid)
        {
            acl_stats0_valid = TRUE;
            acl_stats0_ptr = p_acl_qos_info->acl1_stats_ptr;
        }
        else
        {
            acl_stats1_valid = TRUE;
            acl_stats1_ptr = p_acl_qos_info->acl1_stats_ptr;
        }
    }

    if (p_acl_qos_info->acl2_stats_valid)
    {
        if (!acl_stats0_valid)
        {
            acl_stats0_valid = TRUE;
            acl_stats0_ptr = p_acl_qos_info->acl2_stats_ptr;
        }
        else if (!acl_stats1_valid)
        {
            acl_stats1_valid = TRUE;
            acl_stats1_ptr = p_acl_qos_info->acl2_stats_ptr;
        }
    }

    if (p_acl_qos_info->acl3_stats_valid)
    {
        if (!acl_stats0_valid)
        {
            acl_stats0_valid = TRUE;
            acl_stats0_ptr = p_acl_qos_info->acl3_stats_ptr;
        }
        else if (!acl_stats1_valid)
        {
            acl_stats1_valid = TRUE;
            acl_stats1_ptr = p_acl_qos_info->acl3_stats_ptr;
        }
    }

    if (acl_stats0_valid)
    {
        pkt_info->flow_stats0_valid = TRUE;
        pkt_info->flow_stats0_ptr = acl_stats0_ptr;
    }

    if (acl_stats1_valid)
    {
        pkt_info->flow_stats1_valid = TRUE;
        pkt_info->flow_stats1_ptr = acl_stats1_ptr;
    }

    return DRV_E_NONE;

}


/****************************************************************************
 * Name:      _cm_epe_aclqos_process_dsaclqos
 * Purpose:   EPE process da acl qos lookup result.
 * Parameters:
 * Input:     ipkt  -- point to epe_in_pkt_t store epe packet info.
 *            cm_epe_aclqos_lookup_result -- pointer to struct
 *                        cm_epe_aclqos_lookup_result_t which store lookup result.
 * Output:    ipkt -- point to epe_in_pkt_t store epe packet info.
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_aclqos_process_dsaclqos(epe_in_pkt_t* ipkt,
                                            cm_epe_aclqos_lookup_result_t cm_epe_aclqos_lookup_result)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t *) ipkt->pkt_info;
    epe_acl_qos_ctl_t epe_acl_qos_ctl;
    cm_epe_acl_qos_info_t acl_qos_info;

    uint8 discard = FALSE;
    uint8 acl_result_valid0 = FALSE;
    uint8 acl_result_valid1 = FALSE;
    uint8 acl_result_valid2 = FALSE;
    uint8 acl_result_valid3 = FALSE;
    uint32 cmd = 0;

    sal_memset(&acl_qos_info, 0, sizeof(acl_qos_info));
    sal_memset(&epe_acl_qos_ctl, 0, sizeof(epe_acl_qos_ctl));

    cmd = DRV_IOR(EpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_acl_qos_ctl));

    /* POP_RESULT */
    if (pkt_info->acl_en0)
    {
        acl_result_valid0 = cm_epe_aclqos_lookup_result.acl_result_valid0;
    }

    if (pkt_info->acl_en1)
    {
        acl_result_valid1 = cm_epe_aclqos_lookup_result.acl_result_valid1;
    }

    if (pkt_info->acl_en2)
    {
        acl_result_valid2 = cm_epe_aclqos_lookup_result.acl_result_valid2;
    }

    if (pkt_info->acl_en3)
    {
        acl_result_valid3 = cm_epe_aclqos_lookup_result.acl_result_valid3;
    }

    discard = pkt_info->discard;
    /* PROCESS_DS_ACL0 */
    if (!discard && acl_result_valid0)
    {
        DRV_IF_ERROR_RETURN(_cm_epe_aclqos_process_ds_acl0(ipkt, &acl_qos_info));
    }

    /* PROCESS_DS_ACL1 */
    if (!discard && acl_result_valid1)
    {
        DRV_IF_ERROR_RETURN(_cm_epe_aclqos_process_ds_acl1(ipkt, &acl_qos_info));
    }

    /* PROCESS_DS_ACL2 */
    if (!discard && acl_result_valid2)
    {
        DRV_IF_ERROR_RETURN(_cm_epe_aclqos_process_ds_acl2(ipkt, &acl_qos_info));
    }

    /* PROCESS_DS_ACL3 */
    if (!discard && acl_result_valid3)
    {
        DRV_IF_ERROR_RETURN(_cm_epe_aclqos_process_ds_acl3(ipkt, &acl_qos_info));
    }

    DRV_IF_ERROR_RETURN(_cm_epe_aclqos_process_flow_stats(ipkt, &acl_qos_info));

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      _cm_epe_aclqos_get_acl_qos_key_info
 * Purpose:   EPE get acl_qos key info from packet_info.
 * Parameters:
 * Input:     pkt_info  -- packet_info which store parser result.
 *            p_acl_qos_key_info -- pointer to struct cm_epe_acl_qos_key_info_t
 *                                  whick with no acl_qos key info.
 * Output:    p_acl_qos_key_info -- pointer to struct cm_epe_acl_qos_key_info_t
 *                                  with acl_qos key info.
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static void
_cm_epe_aclqos_get_acl_qos_key_info(const epe_packet_info_t* pkt_info,
                                              cm_epe_acl_qos_key_info_t* p_acl_qos_key_info)
{
    parsing_result_t* parser_result = (parsing_result_t *)pkt_info->parser_result;

    p_acl_qos_key_info->ether_type = parser_result->l2_s.layer2_header_protocol;
    p_acl_qos_key_info->stag_cos = parser_result->l2_s.stag_cos;
    p_acl_qos_key_info->stag_cfi = parser_result->l2_s.stag_cfi;
    p_acl_qos_key_info->ctag_cos = parser_result->l2_s.ctag_cos;
    p_acl_qos_key_info->ctag_cfi = parser_result->l2_s.ctag_cfi;
    p_acl_qos_key_info->layer3_type = parser_result->layer3_type;
    p_acl_qos_key_info->mac_da[0] = parser_result->l2_s.mac_da0;
    p_acl_qos_key_info->mac_da[1] = parser_result->l2_s.mac_da1;
    p_acl_qos_key_info->mac_da[2] = parser_result->l2_s.mac_da2;
    p_acl_qos_key_info->mac_da[3] = parser_result->l2_s.mac_da3;
    p_acl_qos_key_info->mac_da[4] = parser_result->l2_s.mac_da4;
    p_acl_qos_key_info->mac_da[5] = parser_result->l2_s.mac_da5;
    p_acl_qos_key_info->layer2_type = parser_result->layer2_type;
    p_acl_qos_key_info->mac_sa[0] = parser_result->l2_s.mac_sa0;
    p_acl_qos_key_info->mac_sa[1] = parser_result->l2_s.mac_sa1;
    p_acl_qos_key_info->mac_sa[2] = parser_result->l2_s.mac_sa2;
    p_acl_qos_key_info->mac_sa[3] = parser_result->l2_s.mac_sa3;
    p_acl_qos_key_info->mac_sa[4] = parser_result->l2_s.mac_sa4;
    p_acl_qos_key_info->mac_sa[5] = parser_result->l2_s.mac_sa5;
    p_acl_qos_key_info->ip_header_error = parser_result->l3_s.ip_header_error;
    p_acl_qos_key_info->is_tcp = parser_result->l4_s.is_tcp;
    p_acl_qos_key_info->is_udp = parser_result->l4_s.is_udp;
    p_acl_qos_key_info->ip_options = parser_result->l3_s.ip_options;
    p_acl_qos_key_info->frag_info = parser_result->l3_s.frag_info;
    p_acl_qos_key_info->dscp = (parser_result->l3_s.tos.ip_tos >> 2) & 0x3F;
    p_acl_qos_key_info->l4_info_mapped = parser_result->l4_s.layer4_info_mapped;
    p_acl_qos_key_info->l4_dest_port = parser_result->l4_s.l4_dst_port.l4_dest_port;
    p_acl_qos_key_info->l4_source_port = parser_result->l4_s.l4_src_port.l4_source_port;
    p_acl_qos_key_info->ipv6_flow_label = parser_result->l3_s.ipv6_flow_label;
    p_acl_qos_key_info->ipv6_da[0] = parser_result->l3_s.ip_da.ipv6.ipda_31_0;
    p_acl_qos_key_info->ipv6_da[1] = parser_result->l3_s.ip_da.ipv6.ipda_63_32;
    p_acl_qos_key_info->ipv6_da[2] = parser_result->l3_s.ip_da.ipv6.ipda_95_64;
    p_acl_qos_key_info->ipv6_da[3] = parser_result->l3_s.ip_da.ipv6.ipda_127_96;
    p_acl_qos_key_info->ipv6_sa[0] = parser_result->l3_s.ip_sa.ipv6.ipsa_31_0;
    p_acl_qos_key_info->ipv6_sa[1] = parser_result->l3_s.ip_sa.ipv6.ipsa_63_32;
    p_acl_qos_key_info->ipv6_sa[2] = parser_result->l3_s.ip_sa.ipv6.ipsa_95_64;
    p_acl_qos_key_info->ipv6_sa[3] = parser_result->l3_s.ip_sa.ipv6.ipsa_127_96;
    p_acl_qos_key_info->ipv4_da = parser_result->l3_s.ip_da.ipv4.ipda;
    p_acl_qos_key_info->ipv4_sa = parser_result->l3_s.ip_sa.ipv4.ipsa;
    p_acl_qos_key_info->mpls_label0 = parser_result->l3_s.ip_da.mpls.mpls_label0;
    p_acl_qos_key_info->mpls_label1 = parser_result->l3_s.ip_da.mpls.mpls_label1;
    p_acl_qos_key_info->mpls_label2 = parser_result->l3_s.ip_da.mpls.mpls_label2;
    p_acl_qos_key_info->mpls_label3 = parser_result->l3_s.ip_da.mpls.mpls_label3;
    p_acl_qos_key_info->svlan_id_valid = parser_result->l2_s.svlan_id_valid;
    p_acl_qos_key_info->cvlan_id_valid = parser_result->l2_s.cvlan_id_valid;
    p_acl_qos_key_info->udf_byte0 = parser_result->udf_byte0;
    p_acl_qos_key_info->udf_byte1 = parser_result->udf_byte1;
    p_acl_qos_key_info->udf_byte2 = parser_result->udf_byte2;
    p_acl_qos_key_info->udf_byte3 = parser_result->udf_byte3;
    p_acl_qos_key_info->cvlan_id = parser_result->l2_s.cvlan_id;
    p_acl_qos_key_info->svlan_id = parser_result->l2_s.svlan_id;
}

/****************************************************************************
 * Name:      _cm_epe_aclqos_construct_aclqosipv6_key
 * Purpose:   EPE assemble acl qos ipv6_key.
 * Parameters:
 * Input:     p_ds_acl_qos_ipv6_key  -- pointer to empty acl_qos_ipv6_key
 *            p_acl_qos_key_info -- pointer to struct cm_epe_acl_qos_key_info_t
 *                                  which store acl_qos_ipv6_key info
 * Output:    p_ds_acl_qos_ipv6_key  -- pointer to struct p_ds_acl_qos_ipv6_key
 *                                  which store acl_qos_ipv6_key info
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static void
_cm_epe_aclqos_construct_aclqosipv6_key(ds_acl_qos_ipv6_key_t* p_ds_acl_qos_ipv6_key,
                                                     const cm_epe_acl_qos_key_info_t* p_acl_qos_key_info)

{
    p_ds_acl_qos_ipv6_key->acl_use_label = p_acl_qos_key_info->acl_use_label & 0x1;
    p_ds_acl_qos_ipv6_key->direction = p_acl_qos_key_info->direction & 0x1;

    p_ds_acl_qos_ipv6_key->is_acl_qos_key0 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key1 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key2 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key3 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key4 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key5 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key6 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_ipv6_key->is_acl_qos_key7 = p_acl_qos_key_info->is_acl_qos_key & 0x1;

    p_ds_acl_qos_ipv6_key->sub_table_id1 = p_acl_qos_key_info->sub_tbl_id & 0x3;
    p_ds_acl_qos_ipv6_key->sub_table_id3 = p_acl_qos_key_info->sub_tbl_id & 0x3;
    p_ds_acl_qos_ipv6_key->sub_table_id5 = p_acl_qos_key_info->sub_tbl_id & 0x3;
    p_ds_acl_qos_ipv6_key->sub_table_id7 = p_acl_qos_key_info->sub_tbl_id & 0x3;

    p_ds_acl_qos_ipv6_key->ip_sa31_0 = p_acl_qos_key_info->ipv6_sa[0];
    p_ds_acl_qos_ipv6_key->ip_sa63_32 = p_acl_qos_key_info->ipv6_sa[1];
    p_ds_acl_qos_ipv6_key->ip_sa71_64 = p_acl_qos_key_info->ipv6_sa[2] & 0xFF;
    p_ds_acl_qos_ipv6_key->ip_sa103_72 = ((p_acl_qos_key_info->ipv6_sa[3] & 0xFF) << 24)
                                          | ((p_acl_qos_key_info->ipv6_sa[2] >> 8) & 0xFFFFFF);
    p_ds_acl_qos_ipv6_key->ip_sa127_104= ((p_acl_qos_key_info->ipv6_sa[3] >> 8) & 0xFFFFFF);

    p_ds_acl_qos_ipv6_key->l4_source_port3_0 = p_acl_qos_key_info->l4_source_port & 0xF;
    p_ds_acl_qos_ipv6_key->l4_source_port11_4 = (p_acl_qos_key_info->l4_source_port >> 4)&0xFF;
    p_ds_acl_qos_ipv6_key->l4_source_port15_12 = (p_acl_qos_key_info->l4_source_port >> 12)&0xF;

    p_ds_acl_qos_ipv6_key->l4_dest_port5_0 = p_acl_qos_key_info->l4_dest_port & 0x3F;
    p_ds_acl_qos_ipv6_key->l4_dest_port15_6 = (p_acl_qos_key_info->l4_dest_port >> 6) & 0x3FF;

    p_ds_acl_qos_ipv6_key->ip_da31_0 = p_acl_qos_key_info->ipv6_da[0];
    p_ds_acl_qos_ipv6_key->ip_da63_32 = p_acl_qos_key_info->ipv6_da[1];
    p_ds_acl_qos_ipv6_key->ip_da71_64 = p_acl_qos_key_info->ipv6_da[2] & 0xFF;
    p_ds_acl_qos_ipv6_key->ip_da103_72 = ((p_acl_qos_key_info->ipv6_da[3] & 0xFF) << 24)
                                          | ((p_acl_qos_key_info->ipv6_da[2] >> 8) & 0xFFFFFF);
    p_ds_acl_qos_ipv6_key->ip_da127_104 = ((p_acl_qos_key_info->ipv6_da[3] >> 8) & 0xFFFFFF);

    p_ds_acl_qos_ipv6_key->is_label = p_acl_qos_key_info->is_label & 0x1;
    p_ds_acl_qos_ipv6_key->is_udp = p_acl_qos_key_info->is_udp & 0x1;
    p_ds_acl_qos_ipv6_key->is_tcp = p_acl_qos_key_info->is_tcp & 0x1;
    p_ds_acl_qos_ipv6_key->routed_packet = p_acl_qos_key_info->routed_packet & 0x1;

    p_ds_acl_qos_ipv6_key->acl_label0 = IS_BIT_SET(p_acl_qos_key_info->acl_label_low, 0);
    p_ds_acl_qos_ipv6_key->acl_label6_1 = ((p_acl_qos_key_info->acl_label_low >> 1) & 0x3F);
    p_ds_acl_qos_ipv6_key->acl_label9_7 = ((p_acl_qos_key_info->acl_label_low >> 7) & 0x7);
    p_ds_acl_qos_ipv6_key->acl_label10 = IS_BIT_SET(p_acl_qos_key_info->acl_label_low, 10);
    p_ds_acl_qos_ipv6_key->acl_label14_11 = ((p_acl_qos_key_info->acl_label_low >> 11) & 0xF);
    p_ds_acl_qos_ipv6_key->acl_label16_15 = ((p_acl_qos_key_info->acl_label_low >> 15) & 0x3);
    p_ds_acl_qos_ipv6_key->acl_label19_17 = ((p_acl_qos_key_info->acl_label_low >> 17) & 0x7);
    p_ds_acl_qos_ipv6_key->acl_label51_20 = ((p_acl_qos_key_info->acl_label_low >> 20) & 0xFFF)
                                            | ((p_acl_qos_key_info->acl_label_high & 0xFFFFF) << 12);
    p_ds_acl_qos_ipv6_key->acl_label55_52 = ((p_acl_qos_key_info->acl_label_high >> 20) & 0xF);

    p_ds_acl_qos_ipv6_key->l4_info_mapped = p_acl_qos_key_info->l4_info_mapped & 0xFFF;
    p_ds_acl_qos_ipv6_key->frag_info = p_acl_qos_key_info->frag_info & 0x3;
    p_ds_acl_qos_ipv6_key->ip_options = p_acl_qos_key_info->ip_options & 0x1;
    p_ds_acl_qos_ipv6_key->ip_header_error = p_acl_qos_key_info->ip_header_error & 0x1;
    p_ds_acl_qos_ipv6_key->layer3_type = p_acl_qos_key_info->layer3_type & 0xF;
    p_ds_acl_qos_ipv6_key->ipv6_flow_label = p_acl_qos_key_info->ipv6_flow_label & 0xFFFFF;
    p_ds_acl_qos_ipv6_key->dscp = p_acl_qos_key_info->dscp & 0x3F;
    p_ds_acl_qos_ipv6_key->ether_type = p_acl_qos_key_info->ether_type;
    p_ds_acl_qos_ipv6_key->svlan_id = p_acl_qos_key_info->svlan_id & 0xFFF;
    p_ds_acl_qos_ipv6_key->cvlan_id = p_acl_qos_key_info->cvlan_id & 0xFFF;
    p_ds_acl_qos_ipv6_key->svlan_id_valid = p_acl_qos_key_info->svlan_id_valid & 0x1;
    p_ds_acl_qos_ipv6_key->cvlan_id_valid = p_acl_qos_key_info->cvlan_id_valid & 0x1;

    p_ds_acl_qos_ipv6_key->mac_sa31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_sa[3], p_acl_qos_key_info->mac_sa[2],
                                                    p_acl_qos_key_info->mac_sa[1], p_acl_qos_key_info->mac_sa[0]);
    p_ds_acl_qos_ipv6_key->mac_sa47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_sa[5], p_acl_qos_key_info->mac_sa[4]);

    p_ds_acl_qos_ipv6_key->mac_da31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_da[3], p_acl_qos_key_info->mac_da[2],
                                                    p_acl_qos_key_info->mac_da[1], p_acl_qos_key_info->mac_da[0]);
    p_ds_acl_qos_ipv6_key->mac_da47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_da[5], p_acl_qos_key_info->mac_da[4]);
    p_ds_acl_qos_ipv6_key->vlan_ptr = p_acl_qos_key_info->vlan_ptr & 0x1FFF;
    p_ds_acl_qos_ipv6_key->stag_cos = p_acl_qos_key_info->stag_cos & 0x7;
    p_ds_acl_qos_ipv6_key->stag_cfi = p_acl_qos_key_info->stag_cfi & 0x1;
    p_ds_acl_qos_ipv6_key->ctag_cos = p_acl_qos_key_info->ctag_cos & 0x7;
    p_ds_acl_qos_ipv6_key->ctag_cfi = p_acl_qos_key_info->ctag_cfi & 0x1;
    p_ds_acl_qos_ipv6_key->layer2_type = p_acl_qos_key_info->layer2_type & 0xF;
}

/****************************************************************************
 * Name:      _cm_epe_aclqos_construct_aclqosipv4_key
 * Purpose:   EPE assemble acl qos ipv4_key.
 * Parameters:
 * Input:     p_ds_acl_qos_ipv4_key  -- pointer to empty acl_qos_ipv4_key
 *            p_acl_qos_key_info -- pointer to struct cm_epe_acl_qos_key_info_t
 *                                  which store acl_qos_ipv4_key info
 * Output:    p_ds_acl_qos_ipv4_key  -- pointer to struct p_ds_acl_qos_ipv4_key
 *                                  which store acl_qos_ipv4_key info
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static void
_cm_epe_aclqos_construct_aclqosipv4_key(ds_acl_qos_ipv4_key_t* p_ds_acl_qos_ipv4_key,
                                                cm_epe_acl_qos_key_info_t* p_acl_qos_key_info)
{
    p_ds_acl_qos_ipv4_key->is_acl_qos_key0 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_ipv4_key->is_acl_qos_key1 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_ipv4_key->is_acl_qos_key2 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_ipv4_key->is_acl_qos_key3 = p_acl_qos_key_info->is_acl_qos_key & 0x1;

    p_ds_acl_qos_ipv4_key->sub_table_id1 = p_acl_qos_key_info->sub_tbl_id & 0x3;
    p_ds_acl_qos_ipv4_key->sub_table_id3 = p_acl_qos_key_info->sub_tbl_id & 0x3;

    p_ds_acl_qos_ipv4_key->acl_use_label = p_acl_qos_key_info->acl_use_label & 0x1;
    p_ds_acl_qos_ipv4_key->direction = p_acl_qos_key_info->direction & 0x1;

    p_ds_acl_qos_ipv4_key->ip_sa = p_acl_qos_key_info->ipv4_sa;
    p_ds_acl_qos_ipv4_key->ip_da = p_acl_qos_key_info->ipv4_da;
    p_ds_acl_qos_ipv4_key->is_label = p_acl_qos_key_info->is_label & 0x1;
    p_ds_acl_qos_ipv4_key->l4_source_port = p_acl_qos_key_info->l4_source_port;
    p_ds_acl_qos_ipv4_key->l4_dest_port = p_acl_qos_key_info->l4_dest_port;
    p_ds_acl_qos_ipv4_key->ipv4_packet = p_acl_qos_key_info->ipv4_packet & 0x1;

    p_ds_acl_qos_ipv4_key->svlan_id_valid = p_acl_qos_key_info->svlan_id_valid & 0x1;
    p_ds_acl_qos_ipv4_key->cvlan_id_valid = p_acl_qos_key_info->cvlan_id_valid & 0x1;

    p_ds_acl_qos_ipv4_key->l4_info_mapped = p_acl_qos_key_info->l4_info_mapped & 0xFFF;
    p_ds_acl_qos_ipv4_key->dscp = p_acl_qos_key_info->dscp & 0x3F;
    p_ds_acl_qos_ipv4_key->frag_info = p_acl_qos_key_info->frag_info & 0x3;
    p_ds_acl_qos_ipv4_key->ip_options = p_acl_qos_key_info->ip_options & 0x1;
    p_ds_acl_qos_ipv4_key->is_udp = p_acl_qos_key_info->is_udp & 0x1;
    p_ds_acl_qos_ipv4_key->is_tcp = p_acl_qos_key_info->is_tcp & 0x1;
    p_ds_acl_qos_ipv4_key->routed_packet = p_acl_qos_key_info->routed_packet & 0x1;
    p_ds_acl_qos_ipv4_key->ip_header_error = p_acl_qos_key_info->ip_header_error & 0x1;

    p_ds_acl_qos_ipv4_key->mac_sa31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_sa[3], p_acl_qos_key_info->mac_sa[2],
                                                    p_acl_qos_key_info->mac_sa[1], p_acl_qos_key_info->mac_sa[0]);
    p_ds_acl_qos_ipv4_key->mac_sa47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_sa[5], p_acl_qos_key_info->mac_sa[4]);

    p_ds_acl_qos_ipv4_key->svlan_id = p_acl_qos_key_info->svlan_id & 0xFFF;
    p_ds_acl_qos_ipv4_key->ctag_cfi = p_acl_qos_key_info->ctag_cfi & 0x1;
    p_ds_acl_qos_ipv4_key->ctag_cos = p_acl_qos_key_info->ctag_cos & 0x7;

    p_ds_acl_qos_ipv4_key->mac_da31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_da[3], p_acl_qos_key_info->mac_da[2],
                                                    p_acl_qos_key_info->mac_da[1], p_acl_qos_key_info->mac_da[0]);
    p_ds_acl_qos_ipv4_key->mac_da47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_da[5], p_acl_qos_key_info->mac_da[4]);

    p_ds_acl_qos_ipv4_key->stag_cfi = p_acl_qos_key_info->stag_cfi & 0x1;
    p_ds_acl_qos_ipv4_key->stag_cos = p_acl_qos_key_info->stag_cos & 0x7;
    p_ds_acl_qos_ipv4_key->cvlan_id = p_acl_qos_key_info->cvlan_id & 0xFFF;

    p_ds_acl_qos_ipv4_key->acl_label9_0   = ((p_acl_qos_key_info->acl_label_low)  & 0x3FF);
    p_ds_acl_qos_ipv4_key->acl_label19_10 = ((p_acl_qos_key_info->acl_label_low >> 10) & 0x3FF);
    p_ds_acl_qos_ipv4_key->acl_label28_20 = ((p_acl_qos_key_info->acl_label_low >> 20) & 0x1FF);
    p_ds_acl_qos_ipv4_key->acl_label32_29 = ((p_acl_qos_key_info->acl_label_low >> 29) & 0x7)
                                               | (((p_acl_qos_key_info->acl_label_high ) & 0x1) << 3);
    p_ds_acl_qos_ipv4_key->acl_label41_33 = ((p_acl_qos_key_info->acl_label_high >> 1) & 0x1FF);
    p_ds_acl_qos_ipv4_key->acl_label53_42 = ((p_acl_qos_key_info->acl_label_high >> 10) & 0xFFF);
    p_ds_acl_qos_ipv4_key->acl_label55_54 = ((p_acl_qos_key_info->acl_label_high >> 22) & 0x3);

    p_ds_acl_qos_ipv4_key->is_arp_key = p_acl_qos_key_info->is_arp_key;

}

/****************************************************************************
 * Name:      _cm_epe_aclqos_construct_aclqosmpls_key
 * Purpose:   EPE assemble acl qos mpls_key.
 * Parameters:
 * Input:     p_ds_acl_qos_mpls_key  -- pointer to empty ds_acl_qos_mpls_key_t
 *            p_acl_qos_key_info -- pointer to struct cm_epe_acl_qos_key_info_t
 *                                  which store acl_qos_mpls_key info
 * Output:    p_ds_acl_qos_mpls_key  -- pointer to struct ds_acl_qos_mpls_key_t
 *                                  which store acl_qos_mpls_key info
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static void
_cm_epe_aclqos_construct_aclqosmpls_key(ds_acl_qos_mpls_key_t* p_ds_acl_qos_mpls_key,
                                                cm_epe_acl_qos_key_info_t* p_acl_qos_key_info)
{
    p_ds_acl_qos_mpls_key->is_acl_qos_key0 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_mpls_key->is_acl_qos_key1 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_mpls_key->is_acl_qos_key2 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_mpls_key->is_acl_qos_key3 = p_acl_qos_key_info->is_acl_qos_key & 0x1;

    p_ds_acl_qos_mpls_key->sub_table_id1 = p_acl_qos_key_info->sub_tbl_id & 0x3;
    p_ds_acl_qos_mpls_key->sub_table_id3 = p_acl_qos_key_info->sub_tbl_id & 0x3;

    p_ds_acl_qos_mpls_key->acl_use_label = p_acl_qos_key_info->acl_use_label & 0x1;
    p_ds_acl_qos_mpls_key->direction = p_acl_qos_key_info->direction & 0x1;

    p_ds_acl_qos_mpls_key->mpls_label0 = p_acl_qos_key_info->mpls_label0;
    p_ds_acl_qos_mpls_key->mpls_label1 = p_acl_qos_key_info->mpls_label1;
    p_ds_acl_qos_mpls_key->mpls_label2 = p_acl_qos_key_info->mpls_label2;
    p_ds_acl_qos_mpls_key->mpls_label3 = p_acl_qos_key_info->mpls_label3;

    p_ds_acl_qos_mpls_key->is_label = p_acl_qos_key_info->is_label & 0x1;
    p_ds_acl_qos_mpls_key->routed_packet = p_acl_qos_key_info->routed_packet & 0x1;
    p_ds_acl_qos_mpls_key->mac_sa31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_sa[3], p_acl_qos_key_info->mac_sa[2],
                                                    p_acl_qos_key_info->mac_sa[1], p_acl_qos_key_info->mac_sa[0]);
    p_ds_acl_qos_mpls_key->mac_sa47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_sa[5], p_acl_qos_key_info->mac_sa[4]);
    p_ds_acl_qos_mpls_key->svlan_id = p_acl_qos_key_info->svlan_id & 0xFFF;
    p_ds_acl_qos_mpls_key->ctag_cfi = p_acl_qos_key_info->ctag_cfi & 0x1;
    p_ds_acl_qos_mpls_key->ctag_cos = p_acl_qos_key_info->ctag_cos & 0x7;
    p_ds_acl_qos_mpls_key->mac_da31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_da[3], p_acl_qos_key_info->mac_da[2],
                                                    p_acl_qos_key_info->mac_da[1], p_acl_qos_key_info->mac_da[0]);
    p_ds_acl_qos_mpls_key->mac_da47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_da[5], p_acl_qos_key_info->mac_da[4]);

    p_ds_acl_qos_mpls_key->stag_cfi = p_acl_qos_key_info->stag_cfi & 0x1;
    p_ds_acl_qos_mpls_key->stag_cos = p_acl_qos_key_info->stag_cos & 0x7;
    p_ds_acl_qos_mpls_key->cvlan_id = p_acl_qos_key_info->cvlan_id & 0xFFF;

    p_ds_acl_qos_mpls_key->acl_label11_0 = (p_acl_qos_key_info->acl_label_low & 0xFFF);
    p_ds_acl_qos_mpls_key->acl_label24_12 = (p_acl_qos_key_info->acl_label_low >> 12) & 0x1FFF;
    p_ds_acl_qos_mpls_key->acl_label37_25 = ((p_acl_qos_key_info->acl_label_low >> 25) & 0x7F)
                                        |((p_acl_qos_key_info->acl_label_high & 0x3F) << 7);
    p_ds_acl_qos_mpls_key->acl_label51_38 = (p_acl_qos_key_info->acl_label_high >> 6) & 0x3FFF;
}

/****************************************************************************
 * Name:      _cm_epe_aclqos_construct_aclqosmac_key
 * Purpose:   EPE assemble acl qos mac_key.
 * Parameters:
 * Input:     p_ds_acl_qos_mac_key  -- pointer to empty p_ds_acl_qos_mac_key
 *            p_acl_qos_key_info -- pointer to struct cm_epe_acl_qos_key_info_t
 *                                  which store acl_qos_mac_key info
 * Output:    p_ds_acl_qos_mac_key  -- pointer to struct p_ds_acl_qos_mac_key
 *                                  which store acl_qos_mac_key info
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static void
_cm_epe_aclqos_construct_aclqosmac_key(ds_acl_qos_mac_key_t* p_ds_acl_qos_mac_key,
                                                                    cm_epe_acl_qos_key_info_t* p_acl_qos_key_info)
{
    p_ds_acl_qos_mac_key->is_acl_qos_key0 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_mac_key->is_acl_qos_key1 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_mac_key->is_acl_qos_key2 = p_acl_qos_key_info->is_acl_qos_key & 0x1;
    p_ds_acl_qos_mac_key->is_acl_qos_key3 = p_acl_qos_key_info->is_acl_qos_key & 0x1;

    p_ds_acl_qos_mac_key->sub_table_id1 = p_acl_qos_key_info->sub_tbl_id & 0x3;
    p_ds_acl_qos_mac_key->sub_table_id3 = p_acl_qos_key_info->sub_tbl_id & 0x3;

    p_ds_acl_qos_mac_key->acl_use_label = p_acl_qos_key_info->acl_use_label & 0x1;
    p_ds_acl_qos_mac_key->direction = p_acl_qos_key_info->direction & 0x1;

    p_ds_acl_qos_mac_key->mac_sa31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_sa[3], p_acl_qos_key_info->mac_sa[2],
                                                   p_acl_qos_key_info->mac_sa[1], p_acl_qos_key_info->mac_sa[0]);
    p_ds_acl_qos_mac_key->mac_sa47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_sa[5], p_acl_qos_key_info->mac_sa[4]);

    p_ds_acl_qos_mac_key->layer2_type = p_acl_qos_key_info->layer2_type& 0xF;
    p_ds_acl_qos_mac_key->is_label = p_acl_qos_key_info->is_label & 0x1;
    p_ds_acl_qos_mac_key->mac_da31_0 = MAKE_UINT32(p_acl_qos_key_info->mac_da[3], p_acl_qos_key_info->mac_da[2],
                                                   p_acl_qos_key_info->mac_da[1], p_acl_qos_key_info->mac_da[0]);
    p_ds_acl_qos_mac_key->mac_da47_32 = MAKE_UINT16(p_acl_qos_key_info->mac_da[5], p_acl_qos_key_info->mac_da[4]);

    p_ds_acl_qos_mac_key->layer3_type = p_acl_qos_key_info->layer3_type & 0xF;
    p_ds_acl_qos_mac_key->svlan_id_valid = p_acl_qos_key_info->svlan_id_valid & 0x1;
    p_ds_acl_qos_mac_key->cvlan_id_valid = p_acl_qos_key_info->cvlan_id_valid & 0x1;
    p_ds_acl_qos_mac_key->ctag_cfi = p_acl_qos_key_info->ctag_cfi & 0x1;
    p_ds_acl_qos_mac_key->ctag_cos = p_acl_qos_key_info->ctag_cos & 0x7;
    p_ds_acl_qos_mac_key->stag_cfi = p_acl_qos_key_info->stag_cfi & 0x1;
    p_ds_acl_qos_mac_key->stag_cos = p_acl_qos_key_info->stag_cos & 0x7;
    p_ds_acl_qos_mac_key->ether_type = p_acl_qos_key_info->ether_type;
    p_ds_acl_qos_mac_key->vlan_ptr = p_acl_qos_key_info->vlan_ptr & 0x1FFF;

    p_ds_acl_qos_mac_key->acl_label10_0= (p_acl_qos_key_info->acl_label_low & 0x7FF);
    p_ds_acl_qos_mac_key->acl_label19_11= ((p_acl_qos_key_info->acl_label_low >> 11) & 0x1FF);
    p_ds_acl_qos_mac_key->acl_label35_20= ((p_acl_qos_key_info->acl_label_low >> 20) & 0xFFF)
                                        | ((p_acl_qos_key_info->acl_label_high & 0xF) << 12);
    p_ds_acl_qos_mac_key->acl_label51_36= ((p_acl_qos_key_info->acl_label_high >> 4) & 0xFFFF);
    p_ds_acl_qos_mac_key->acl_label55_52= ((p_acl_qos_key_info->acl_label_high >> 20) & 0xF);

    p_ds_acl_qos_mac_key->ip_da = p_acl_qos_key_info->ipv4_da;
    p_ds_acl_qos_mac_key->ip_sa = p_acl_qos_key_info->ipv4_sa;

}


/****************************************************************************
 * Name:      _cm_epe_aclqos_aclqos_lookup
 * Purpose:   EPE do qos and acl lookup to get the aclindex and qosindex.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 *            look_rlt -- pointer to struct cm_epe_aclqos_lookup_aclqos_result_t
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 *            look_rlt -- pointer to struct cm_epe_aclqos_lookup_aclqos_result_t
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_aclqos_aclqos_lookup(epe_in_pkt_t* ipkt, cm_epe_aclqos_lookup_result_t* look_rlt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    ds_acl_qos_ipv6_key_t ds_acl_qos_ipv6_key;
    ds_acl_qos_ipv4_key_t ds_acl_qos_ipv4_key;
    ds_acl_qos_mpls_key_t ds_acl_qos_mpls_key;
    ds_acl_qos_mac_key_t ds_acl_qos_mac_key;
    epe_acl_qos_ctl_t epe_acl_qos_ctl;
    tcam_lkp_outputs_t tcam_lookup_result;
    tcam_lkp_inputs_t tcam_lookup_info;
    cm_epe_acl_qos_key_info_t acl_qos_key_info;

    uint8 acl_en = FALSE, ipv6_acl_en = FALSE;
    uint8 is_ipv4_or_mpls = FALSE, is_ipv6 = FALSE;
    uint8 is_label = FALSE;
    uint8 l3_route_operation = FALSE;
    uint8 l2_acl_en0 = FALSE, l2_acl_en1 = FALSE, l2_acl_en2 = FALSE, l2_acl_en3 = FALSE;
    uint8 l3_acl_en0 = FALSE, l3_acl_en1 = FALSE, l3_acl_en2 = FALSE, l3_acl_en3 = FALSE;
    uint8 l2_ipv6_acl_en0 = FALSE, l2_ipv6_acl_en1 = FALSE;
    uint8 l3_ipv6_acl_en0 = FALSE, l3_ipv6_acl_en1 = FALSE;
    uint8 tcam_key_type = 0;

    uint32 chip_id = ipkt->chip_id;
    uint32 cmd = 0;
    uint32 oam_obey_acl_qos = 0;
    uint8 err_free = FALSE;


    sal_memset(&acl_qos_key_info, 0, sizeof(acl_qos_key_info));

    /* ACL_QOS_LOOKUP_INIT */
    sal_memset(&epe_acl_qos_ctl, 0, sizeof(epe_acl_qos_ctl));
    cmd = DRV_IOR(EpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &epe_acl_qos_ctl));

    if (!pkt_info->from_cpu_or_oam &&
        ((pkt_info->rx_oam_type == OAM_NONE) || epe_acl_qos_ctl.oam_obey_acl_qos))
    {
        oam_obey_acl_qos = TRUE;
    }
    else
    {
        oam_obey_acl_qos = FALSE;
    }

    l3_route_operation = (CM_PLD_OP_ROUTE == pkt_info->payload_operation)
                         || (CM_PLD_OP_ROUTE_NOTTL == pkt_info->payload_operation)
                         || (CM_PLD_OP_ROUTE_COMPACT == pkt_info->payload_operation);
    l2_acl_en0 = pkt_info->l2_acl_en0 && oam_obey_acl_qos;
    l2_acl_en1 = pkt_info->l2_acl_en1 && oam_obey_acl_qos;
    l2_acl_en2 = pkt_info->l2_acl_en2 && oam_obey_acl_qos;
    l2_acl_en3 = pkt_info->l2_acl_en3 && oam_obey_acl_qos;
    l2_ipv6_acl_en0 = pkt_info->l2_ipv6_acl_en0 && oam_obey_acl_qos;
    l2_ipv6_acl_en1 = pkt_info->l2_ipv6_acl_en1 && oam_obey_acl_qos;
    l3_acl_en0 = pkt_info->l3_acl_en0
                 && ((!pkt_info->l3_acl_routed_only) || l3_route_operation)
                 && oam_obey_acl_qos;
    l3_acl_en1 = pkt_info->l3_acl_en1
                 && ((!pkt_info->l3_acl_routed_only) || l3_route_operation)
                 && oam_obey_acl_qos;
    l3_acl_en2 = pkt_info->l3_acl_en2
                 && ((!pkt_info->l3_acl_routed_only) || l3_route_operation)
                 && oam_obey_acl_qos;
    l3_acl_en3 = pkt_info->l3_acl_en3
                 && ((!pkt_info->l3_acl_routed_only) || l3_route_operation)
                 && oam_obey_acl_qos;
    l3_ipv6_acl_en0 = pkt_info->l3_ipv6_acl_en0
                      && (!pkt_info->l3_acl_routed_only || l3_route_operation)
                      && oam_obey_acl_qos;
    l3_ipv6_acl_en1 = pkt_info->l3_ipv6_acl_en1
                      && (!pkt_info->l3_acl_routed_only || l3_route_operation)
                      && oam_obey_acl_qos;

    if (pkt_info->service_acl_qos_en)
    {
        l2_acl_en0 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 0);
        l2_acl_en1 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 1);
        l2_acl_en2 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 2);
        l2_acl_en3 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 3);
        l2_ipv6_acl_en0 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 4);
        l2_ipv6_acl_en1 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 5);
        l3_acl_en0 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 6);
        l3_acl_en1 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 7);
        l3_acl_en2 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 8);
        l3_acl_en3 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 9);
        l3_ipv6_acl_en0 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 10);
        l3_ipv6_acl_en1 = pkt_info->service_acl_qos_en
                        && oam_obey_acl_qos
                        && IS_BIT_SET(epe_acl_qos_ctl.service_acl_qos_en, 11);

        is_label = FALSE;
    }
    else
    {
        is_label = TRUE;
    }

    if (pkt_info->packet_header_en
                        && (pkt_info->packet_header_en_egress
                        || epe_acl_qos_ctl.packet_header_en_acl_ingress))
    {
        l3_acl_en0 = FALSE;
        l3_acl_en1 = FALSE;
        l3_acl_en2 = FALSE;
        l3_acl_en3 = FALSE;
    }

    acl_qos_key_info.acl_label_low = 0;
    acl_qos_key_info.acl_label_high =0;

    if (!pkt_info->service_acl_qos_en)
    {
        if (pkt_info->acl_port_num < 32)
        {
            /* port bitmap */
            SET_BIT(acl_qos_key_info.acl_label_low, pkt_info->acl_port_num);
        }
        else
        {
            SET_BIT(acl_qos_key_info.acl_label_high, (pkt_info->acl_port_num - 32));
        }
    }
    else
    {
        acl_qos_key_info.acl_label_low = pkt_info->logic_dest_port;
        acl_qos_key_info.acl_label_high = 0;
    }

    _cm_epe_aclqos_get_acl_qos_key_info(pkt_info, &acl_qos_key_info);

    acl_qos_key_info.routed_packet = l3_route_operation & 0x1;
    acl_qos_key_info.vlan_ptr = pkt_info->dest_vlan_ptr & 0x1FFF;

    if ((L3_TYPE_IPV6 == acl_qos_key_info.layer3_type)
            && !acl_qos_key_info.is_tcp
            && !acl_qos_key_info.is_udp)
    {
        acl_qos_key_info.l4_dest_port = acl_qos_key_info.l4_info_mapped & 0xFFF;
    }

    if (L3_TYPE_IPV4 == acl_qos_key_info.layer3_type)
    {
        acl_qos_key_info.ipv4_packet = TRUE;
    }

    acl_qos_key_info.is_label = is_label;

    /* ACL_QOS_LOOKUP_IMPLEMENT */
    sal_memset(&tcam_lookup_result, 0, sizeof(tcam_lookup_result));

    acl_en = l2_acl_en0 || l2_acl_en1 || l2_acl_en2 || l2_acl_en3
             || l3_acl_en0 || l3_acl_en1 || l3_acl_en2 || l3_acl_en3;

    ipv6_acl_en = l2_ipv6_acl_en0 || l2_ipv6_acl_en1 || l3_ipv6_acl_en0 || l3_ipv6_acl_en1;

    is_ipv4_or_mpls = ( L3_TYPE_IPV4 == acl_qos_key_info.layer3_type )
                      || (( L3_TYPE_MPLS == acl_qos_key_info.layer3_type )
                      || ( L3_TYPE_MPLSMCAST == acl_qos_key_info.layer3_type));

    is_ipv6 = (L3_TYPE_IPV6 == acl_qos_key_info.layer3_type);

    err_free = ((!parser_result->l3_s.ip_header_error) &&
                (( L3_TYPE_IPV4 == acl_qos_key_info.layer3_type ) || ( L3_TYPE_IPV6 == parser_result->layer3_type )))
                || ( L3_TYPE_MPLS == acl_qos_key_info.layer3_type )
                || ( L3_TYPE_MPLSMCAST == acl_qos_key_info.layer3_type );

    if ((is_ipv4_or_mpls && (!pkt_info->force_ipv4_to_mackey || epe_acl_qos_ctl.merge_mac_ip_acl_key)
            && acl_en && err_free)
       || (is_ipv6 && (!pkt_info->force_ipv6_to_mackey || epe_acl_qos_ctl.merge_mac_ip_acl_key )
            && ipv6_acl_en && err_free)
       || (!is_ipv4_or_mpls && !is_ipv6 && epe_acl_qos_ctl.merge_mac_ip_acl_key && (acl_en || ipv6_acl_en))) /* IP key */
    {

        CTC_CMODEL_DEBUG_OUT(CTC_CMODEL_DEBUG_FLAG_FWD_PATH, "[Debug Fwd Path]-->> %s\n", "EPE ACLQoS Process");
        if (ipv6_acl_en && ((L3_TYPE_IPV6 == acl_qos_key_info.layer3_type)
                || pkt_info->force_ipv6_key
                || ((L3_TYPE_TRILL == acl_qos_key_info.layer3_type)
                && epe_acl_qos_ctl.trill_use_ipv6_key)
                || ((L3_TYPE_ARP == acl_qos_key_info.layer3_type)
                && epe_acl_qos_ctl.arp_use_ipv6_key)
                || ((L3_TYPE_IPV4 != acl_qos_key_info.layer3_type)
                && (L3_TYPE_MPLS != acl_qos_key_info.layer3_type)
                && (L3_TYPE_MPLSMCAST != acl_qos_key_info.layer3_type)
                && epe_acl_qos_ctl.non_ip_mpls_use_ipv6_key)))
        {
            /* IPV6 key */
            pkt_info->acl_en0 = l2_ipv6_acl_en0 || l3_ipv6_acl_en0;
            pkt_info->acl_en1 = l2_ipv6_acl_en1 || l3_ipv6_acl_en1;

            if (!pkt_info->service_acl_qos_en && pkt_info->ipv6_key_use_label)
            {
                acl_qos_key_info.acl_label_low = (pkt_info->l3_acl_label << 10) | (pkt_info->l2_acl_label);
                acl_qos_key_info.acl_label_high = 0;
            }

            sal_memset(&ds_acl_qos_ipv6_key, 0, sizeof(ds_acl_qos_ipv6_key_t));

            tcam_key_type = (1 << 6)
                            | (pkt_info->acl_en0 << 5)
                            | (pkt_info->acl_en1 << 4)
                            | (pkt_info->acl_en2 << 3)
                            | (pkt_info->acl_en3 << 2);

            acl_qos_key_info.acl_use_label = pkt_info->ipv6_key_use_label;
            acl_qos_key_info.direction = TCAM_KEY_DIR_EPE;

            acl_qos_key_info.is_acl_qos_key = TRUE;
            acl_qos_key_info.sub_tbl_id = (epe_acl_qos_ctl.acl_qos_lookup_ctl0 & 0x3);   /* subtableId */

            _cm_epe_aclqos_construct_aclqosipv6_key(&ds_acl_qos_ipv6_key, &acl_qos_key_info);

            /* do search */
            tcam_lookup_info.chip_id = ipkt->chip_id;
            tcam_lookup_info.tcam_key_size = (epe_acl_qos_ctl.acl_qos_lookup_ctl0 >> 2) & 0x3;   /* keySize */
            tcam_lookup_info.tcam_key_type = tcam_key_type & 0x7F;
            tcam_lookup_info.tcam_key = &ds_acl_qos_ipv6_key;

            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->acl_data0;
            tcam_lookup_result.tcam_lkp_output[1].ds_ad = pkt_info->acl_data1;
            tcam_lookup_result.tcam_lkp_output[2].ds_ad = pkt_info->acl_data2;
            tcam_lookup_result.tcam_lkp_output[3].ds_ad = pkt_info->acl_data3;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
        }
        else if (L3_TYPE_IPV4 == (acl_qos_key_info.layer3_type & 0xF) )
        {
            /* IPV4 key */
            pkt_info->acl_en0 = l2_acl_en0 || l3_acl_en0;
            pkt_info->acl_en1 = l2_acl_en1 || l3_acl_en1;
            pkt_info->acl_en2 = l2_acl_en2 || l3_acl_en2;
            pkt_info->acl_en3 = l2_acl_en3 || l3_acl_en3;

            if (!pkt_info->service_acl_qos_en && pkt_info->ipv4_key_use_label)
            {
                acl_qos_key_info.acl_label_low = (pkt_info->l3_acl_label << 10) | pkt_info->l2_acl_label;
                acl_qos_key_info.acl_label_high = 0;
            }

            sal_memset(&ds_acl_qos_ipv4_key, 0, sizeof(ds_acl_qos_ipv4_key));

            tcam_key_type = (1 << 6)
                            | (pkt_info->acl_en0 << 5)
                            | (pkt_info->acl_en1 << 4)
                            | (pkt_info->acl_en2 << 3)
                            | (pkt_info->acl_en3 << 2)
                            | 0x1;

            acl_qos_key_info.is_acl_qos_key = TRUE;
            acl_qos_key_info.sub_tbl_id = (epe_acl_qos_ctl.acl_qos_lookup_ctl1 & 0x3); /* subtableId */

            acl_qos_key_info.acl_use_label = pkt_info->ipv4_key_use_label;
            acl_qos_key_info.direction = TCAM_KEY_DIR_EPE;
            acl_qos_key_info.is_arp_key = FALSE;

            _cm_epe_aclqos_construct_aclqosipv4_key(&ds_acl_qos_ipv4_key, &acl_qos_key_info);

            /* do serarch */
            tcam_lookup_info.chip_id = ipkt->chip_id;
            tcam_lookup_info.tcam_key_size = (epe_acl_qos_ctl.acl_qos_lookup_ctl1 >> 2) & 0x3;
            tcam_lookup_info.tcam_key_type = tcam_key_type & 0x7F;
            tcam_lookup_info.tcam_key = &ds_acl_qos_ipv4_key;

            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->acl_data0;
            tcam_lookup_result.tcam_lkp_output[1].ds_ad = pkt_info->acl_data1;
            tcam_lookup_result.tcam_lkp_output[2].ds_ad = pkt_info->acl_data2;
            tcam_lookup_result.tcam_lkp_output[3].ds_ad = pkt_info->acl_data3;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
        }
        else if (( L3_TYPE_MPLS == (acl_qos_key_info.layer3_type & 0xF))
                || ( L3_TYPE_MPLSMCAST == (acl_qos_key_info.layer3_type & 0xF)))
        {
            /* MPLS Key */
            pkt_info->acl_en0 = l2_acl_en0 || l3_acl_en0;
            pkt_info->acl_en1 = l2_acl_en1 || l3_acl_en1;
            pkt_info->acl_en2 = l2_acl_en2 || l3_acl_en2;
            pkt_info->acl_en3 = l2_acl_en3 || l3_acl_en3;

            if (!pkt_info->service_acl_qos_en && pkt_info->mpls_key_use_label)
            {
                acl_qos_key_info.acl_label_low = (pkt_info->l3_acl_label << 10) | pkt_info->l2_acl_label;
                acl_qos_key_info.acl_label_high = 0;
            }

            sal_memset(&ds_acl_qos_mpls_key, 0, sizeof(ds_acl_qos_mpls_key_t));

            tcam_key_type = (1 << 6)
                            | (pkt_info->acl_en0 << 5)
                            | (pkt_info->acl_en1 << 4)
                            | (pkt_info->acl_en2 << 3)
                            | (pkt_info->acl_en3 << 2)
                            | 0x1;

            acl_qos_key_info.is_acl_qos_key = TRUE;
            acl_qos_key_info.sub_tbl_id = (epe_acl_qos_ctl.acl_qos_lookup_ctl3 & 0x3);   /* subtableId */

            acl_qos_key_info.acl_use_label = pkt_info->mpls_key_use_label;
            acl_qos_key_info.direction = TCAM_KEY_DIR_EPE;

            _cm_epe_aclqos_construct_aclqosmpls_key(&ds_acl_qos_mpls_key, &acl_qos_key_info);

            /* do search */
            tcam_lookup_info.chip_id = ipkt->chip_id;
            tcam_lookup_info.tcam_key_size = (epe_acl_qos_ctl.acl_qos_lookup_ctl3 >> 2) & 0x3;
            tcam_lookup_info.tcam_key_type = tcam_key_type;
            tcam_lookup_info.tcam_key = &ds_acl_qos_mpls_key;

            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->acl_data0;
            tcam_lookup_result.tcam_lkp_output[1].ds_ad = pkt_info->acl_data1;
            tcam_lookup_result.tcam_lkp_output[2].ds_ad = pkt_info->acl_data2;
            tcam_lookup_result.tcam_lkp_output[3].ds_ad = pkt_info->acl_data3;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
        }
        else if (acl_en)
        {
            /* IPV4 key */
            pkt_info->acl_en0 = l2_acl_en0 || l3_acl_en0;
            pkt_info->acl_en1 = l2_acl_en1 || l3_acl_en1;
            pkt_info->acl_en2 = l2_acl_en2 || l3_acl_en2;
            pkt_info->acl_en3 = l2_acl_en3 || l3_acl_en3;

            if (!pkt_info->service_acl_qos_en && pkt_info->ipv4_key_use_label)
            {
                acl_qos_key_info.acl_label_low = (pkt_info->l3_acl_label << 10) | pkt_info->l2_acl_label;
                acl_qos_key_info.acl_label_high = 0;
            }

            sal_memset(&ds_acl_qos_ipv4_key, 0, sizeof(ds_acl_qos_ipv4_key));

            tcam_key_type = (1 << 6)
                            | (pkt_info->acl_en0 << 5)
                            | (pkt_info->acl_en1 << 4)
                            | (pkt_info->acl_en2 << 3)
                            | (pkt_info->acl_en3 << 2)
                            | 0x1;

            acl_qos_key_info.is_acl_qos_key = TRUE;
            acl_qos_key_info.sub_tbl_id = (epe_acl_qos_ctl.acl_qos_lookup_ctl1 & 0x3);   /* subtableId */

            acl_qos_key_info.acl_use_label = pkt_info->ipv4_key_use_label;
            acl_qos_key_info.direction = TCAM_KEY_DIR_EPE;
            /* resue ipsa for lay2type and ethertype*/
            if (((L3_TYPE_ARP == (acl_qos_key_info.layer3_type & 0xF)) && !epe_acl_qos_ctl.ip_sa_mode_for_arp)
                || ((L3_TYPE_TRILL == (acl_qos_key_info.layer3_type & 0xF)) && !epe_acl_qos_ctl.ip_sa_mode_for_trill)
                || ((L3_TYPE_FCOE == (acl_qos_key_info.layer3_type & 0xF)) && !epe_acl_qos_ctl.ip_sa_mode_for_fcoe))
            {
                acl_qos_key_info.ipv4_sa = ((acl_qos_key_info.layer2_type & 0xF) << 16) | (acl_qos_key_info.ether_type);
            }

            acl_qos_key_info.is_arp_key = (acl_qos_key_info.layer3_type == L3_TYPE_ARP);
            if (acl_qos_key_info.layer3_type == L3_TYPE_ARP)
            {
                acl_qos_key_info.l4_source_port = parser_result->l3_s.ip_da.arp.arp_op_code;
            }

            _cm_epe_aclqos_construct_aclqosipv4_key(&ds_acl_qos_ipv4_key, &acl_qos_key_info);

            /* do search */
            tcam_lookup_info.chip_id = ipkt->chip_id;
            tcam_lookup_info.tcam_key_size = (epe_acl_qos_ctl.acl_qos_lookup_ctl1 >> 2) & 0x3;
            tcam_lookup_info.tcam_key_type = tcam_key_type;
            tcam_lookup_info.tcam_key = &ds_acl_qos_ipv4_key;

            tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->acl_data0;
            tcam_lookup_result.tcam_lkp_output[1].ds_ad = pkt_info->acl_data1;
            tcam_lookup_result.tcam_lkp_output[2].ds_ad = pkt_info->acl_data2;
            tcam_lookup_result.tcam_lkp_output[3].ds_ad = pkt_info->acl_data3;

            DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
        }
        else
        {
            /* do nothing */
        }
    }
    else if (acl_en)
    {
        /* MAC key*/
        pkt_info->acl_en0 = l2_acl_en0 || l3_acl_en0;
        pkt_info->acl_en1 = l2_acl_en1 || l3_acl_en1;
        pkt_info->acl_en2 = l2_acl_en2 || l3_acl_en2;
        pkt_info->acl_en3 = l2_acl_en3 || l3_acl_en3;

        if (!pkt_info->service_acl_qos_en && pkt_info->mac_key_use_label)
        {
            acl_qos_key_info.acl_label_low = (pkt_info->l3_acl_label << 10) | pkt_info->l2_acl_label;
            acl_qos_key_info.acl_label_high = 0;
        }

        sal_memset(&ds_acl_qos_mac_key, 0, sizeof(ds_acl_qos_mac_key));

        tcam_key_type = (1 << 6)
                        | (pkt_info->acl_en0 << 5)
                        | (pkt_info->acl_en1 << 4)
                        | (pkt_info->acl_en2 << 3)
                        | (pkt_info->acl_en3 << 2)
                        | 0x2;

        acl_qos_key_info.is_acl_qos_key = TRUE;
        acl_qos_key_info.sub_tbl_id = (epe_acl_qos_ctl.acl_qos_lookup_ctl2 & 0x3);   /* subtableId */

        acl_qos_key_info.acl_use_label = pkt_info->mac_key_use_label;
        acl_qos_key_info.direction = TCAM_KEY_DIR_EPE;

        _cm_epe_aclqos_construct_aclqosmac_key(&ds_acl_qos_mac_key, &acl_qos_key_info);

        ds_acl_qos_mac_key.svlan_id = (L3_TYPE_CMAC == acl_qos_key_info.layer3_type)
                                      ? ((parser_result->l3_s.ip_da.cmac.itag_tci.share.isid >> 12) & 0xFFF)
                                      : (acl_qos_key_info.svlan_id & 0xFFF);
        ds_acl_qos_mac_key.cvlan_id = (L3_TYPE_CMAC == acl_qos_key_info.layer3_type)
                                           ? (parser_result->l3_s.ip_da.cmac.itag_tci.share.isid & 0xFFF)
                                           : ((acl_qos_key_info.cvlan_id) & 0xFFF);

        if (L3_TYPE_ARP == parser_result->layer3_type)
        {
            ds_acl_qos_mac_key.arp_op_code0_0 = parser_result->l3_s.ip_da.arp.arp_op_code & 0x1;
            ds_acl_qos_mac_key.arp_op_code15_1 = ((parser_result->l3_s.ip_da.arp.arp_op_code >> 1) & 0x7FFF);
        }
        else
        {
            ds_acl_qos_mac_key.arp_op_code0_0 = 0;
            ds_acl_qos_mac_key.arp_op_code15_1 = 0;
        }

        /* do search */
        tcam_lookup_info.chip_id = ipkt->chip_id;
        tcam_lookup_info.tcam_key_size = (epe_acl_qos_ctl.acl_qos_lookup_ctl2 >> 2) & 0x3;
        tcam_lookup_info.tcam_key_type = tcam_key_type;
        tcam_lookup_info.tcam_key = &ds_acl_qos_mac_key;

        tcam_lookup_result.tcam_lkp_output[0].ds_ad = pkt_info->acl_data0;
        tcam_lookup_result.tcam_lkp_output[1].ds_ad = pkt_info->acl_data1;
        tcam_lookup_result.tcam_lkp_output[2].ds_ad = pkt_info->acl_data2;
        tcam_lookup_result.tcam_lkp_output[3].ds_ad = pkt_info->acl_data3;

        DRV_IF_ERROR_RETURN(cm_com_tcam_engine_handle(&tcam_lookup_info, &tcam_lookup_result));
    }

    look_rlt->acl_result_valid0 = tcam_lookup_result.tcam_lkp_output[0].tcam_lkp_result_valid;
    look_rlt->acl_result_valid1 = tcam_lookup_result.tcam_lkp_output[1].tcam_lkp_result_valid;
    look_rlt->acl_result_valid2 = tcam_lookup_result.tcam_lkp_output[2].tcam_lkp_result_valid;
    look_rlt->acl_result_valid3 = tcam_lookup_result.tcam_lkp_output[3].tcam_lkp_result_valid;

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:      _cm_epe_aclqos_oam_lm_hash_lookup
 * Purpose:   perform ACL/QOS oam lm hash lookup
 * Parameters:
 * Input:     chip_id  --id of chip
 *            pkt_info  -- pointer to epe_packet_info_t
 *            lm_lookup_num  -- lm lookup num
 *            mpls_lm_valid_indx  -- mpls lm valid index
 *                     header ,and processing informations
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_aclqos_oam_lm_hash_lookup(uint32 chip_id, epe_packet_info_t* pkt_info,
                                                uint8 lm_lookup_num, uint8 mpls_lm_valid_indx)
{
    uint32 cmd = 0;

    userid_key_t oam_hash_key;
    lookup_result_t lookup_result_mpls_label_oam;
    userid_key_type_t userid_key_type = USERID_KEY_TYPE_DISABLE;

    oam_extra_result_t oam_extra_result;
    epe_acl_qos_ctl_t epe_acl_qos_ctl;

    uint8 mpls_lm_exp = 0;

    sal_memset(&lookup_result_mpls_label_oam, 0, sizeof(lookup_result_mpls_label_oam));
    sal_memset(&oam_extra_result, 0, sizeof(oam_extra_result_t));

    sal_memset(&epe_acl_qos_ctl, 0, sizeof(epe_acl_qos_ctl_t));
    cmd = DRV_IOR(EpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(chip_id, 0, cmd, &epe_acl_qos_ctl));

    switch(mpls_lm_valid_indx)
    {
        case 2:
            pkt_info->lm_lookup_type = LM_MPLS;
            oam_hash_key.key.mpls_label_oam.mpls_label = pkt_info->mpls_lm_label2;
            mpls_lm_exp = pkt_info->mpls_lm_exp2;
            oam_hash_key.key.mpls_label_oam.mpls_label_space =
                (pkt_info->mpls_lm_label2 >= epe_acl_qos_ctl.min_interface_label)? pkt_info->mpls_label_space : 0;

            break;
        case 1:
            pkt_info->lm_lookup_type = LM_MPLS;
            oam_hash_key.key.mpls_label_oam.mpls_label = pkt_info->mpls_lm_label1;
            mpls_lm_exp = pkt_info->mpls_lm_exp1;
            oam_hash_key.key.mpls_label_oam.mpls_label_space =
                (pkt_info->mpls_lm_label1 >= epe_acl_qos_ctl.min_interface_label)? pkt_info->mpls_label_space : 0;

            break;
        case 0:
            pkt_info->lm_lookup_type = LM_MPLS;
            oam_hash_key.key.mpls_label_oam.mpls_label = pkt_info->mpls_lm_label0;
            mpls_lm_exp = pkt_info->mpls_lm_exp0;
            oam_hash_key.key.mpls_label_oam.mpls_label_space =
                (pkt_info->mpls_lm_label0 >= epe_acl_qos_ctl.min_interface_label)? pkt_info->mpls_label_space : 0;

            break;
        default:
            break;
    }

    if (0 == (lm_lookup_num & 0x3))
    {
        pkt_info->lm_lookup_en0 = TRUE;
        pkt_info->packet_cos0 = mpls_lm_exp;

        oam_extra_result.chan = pkt_info->lm_chan0_data;
        oam_extra_result.info = pkt_info->lm_info0;
        lookup_result_mpls_label_oam.extra = &oam_extra_result;
    }
    else if (1 == (lm_lookup_num & 0x3))
    {
        pkt_info->lm_lookup_en1 = TRUE;
        pkt_info->packet_cos1 = mpls_lm_exp;

        oam_extra_result.chan = pkt_info->lm_chan1_data;
        oam_extra_result.info = pkt_info->lm_info1;
        lookup_result_mpls_label_oam.extra = &oam_extra_result;
    }
    else if (2 == (lm_lookup_num & 0x3))
    {
        pkt_info->lm_lookup_en2 = TRUE;
        pkt_info->packet_cos2 = mpls_lm_exp;

        oam_extra_result.chan = pkt_info->lm_chan2_data;
        oam_extra_result.info = pkt_info->lm_info2;
        lookup_result_mpls_label_oam.extra = &oam_extra_result;
    }

    userid_key_type = USERID_KEY_TYPE_MPLS_LABEL_OAM;

    DRV_IF_ERROR_RETURN(cm_com_userid_hash_lookup_request(chip_id, pkt_info->local_phy_port, &oam_hash_key,
                                                  userid_key_type, USERID_DIRECTION_OTHER,
                                                  &lookup_result_mpls_label_oam));
    /*save lookup result to pkt_info */
    switch(lm_lookup_num & 0x3)
    {
        case 0:
            pkt_info->lm_result_valid0 = lookup_result_mpls_label_oam.valid;
            pkt_info->hash_conflict0 = lookup_result_mpls_label_oam.conflict;
            break;
        case 1:
            pkt_info->lm_result_valid1 = lookup_result_mpls_label_oam.valid;
            pkt_info->hash_conflict1 = lookup_result_mpls_label_oam.conflict;
            break;
        case 2:
            pkt_info->lm_result_valid2 = lookup_result_mpls_label_oam.valid;
            pkt_info->hash_conflict2 = lookup_result_mpls_label_oam.conflict;
            break;
        default:
            break;
    }

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:      _cm_epe_aclqos_oam_lookup
 * Purpose:   perform ACL/QOS oam lookup.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
static int32
_cm_epe_aclqos_oam_lookup(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    userid_key_t oam_hash_key;
    userid_key_type_t userid_key_type = USERID_KEY_TYPE_DISABLE;

    epe_acl_qos_ctl_t epe_acl_qos_ctl;

    lookup_result_t lookup_result_ether_oam;
    lookup_result_t lookup_result_mpls_section_oam;
    oam_extra_result_t oam_extra_result;

    uint32 cmd = 0;
    uint8 lm_lookup_num = 0;

    sal_memset(&oam_hash_key, 0 ,sizeof(userid_key_t));
    sal_memset(&lookup_result_ether_oam, 0, sizeof(lookup_result_ether_oam));
    sal_memset(&lookup_result_mpls_section_oam, 0, sizeof(lookup_result_mpls_section_oam));

    sal_memset(&epe_acl_qos_ctl, 0, sizeof(epe_acl_qos_ctl_t));
    cmd = DRV_IOR(EpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_acl_qos_ctl));

    /* OAM_LOOKUPS */
    pkt_info->oam_lookup_en = (OAM_ETHER == pkt_info->rx_oam_type);

    if (pkt_info->ether_lm_valid )   /* ETHERNET_LM */
    {
        pkt_info->lm_lookup_type = LM_ETHER;
        pkt_info->lm_lookup_en0 = TRUE;
    }

    if (parser_result->l2_s.svlan_id_valid)
    {
        pkt_info->packet_cos0 = parser_result->l2_s.stag_cos;
    }
    else
    {
        pkt_info->packet_cos0 = pkt_info->default_pcp;
    }

    if ((OAM_ETHER == pkt_info->rx_oam_type) || pkt_info->ether_lm_valid )
    {
        userid_key_type = pkt_info->oam_use_fid ? USERID_KEY_TYPE_ETHER_FID_OAM : USERID_KEY_TYPE_ETHER_VLAN_OAM;
        oam_hash_key.xport.global.src = pkt_info->global_dest_port;

        if (pkt_info->oam_use_fid)
        {
            oam_hash_key.key.ether_fid_oam.vlan_id = pkt_info->fid;
        }
        else if (!epe_acl_qos_ctl.oam_lookup_user_vlan_id)
        {
            oam_hash_key.key.ether_vlan_oam.vlan_id = pkt_info->dest_vlan_ptr&0xFFF;
        }
        else
        {
            oam_hash_key.key.ether_vlan_oam.vlan_id = pkt_info->oam_vlan;
        }

        if (pkt_info->oam_use_fid)
        {
            oam_hash_key.key.ether_fid_oam.is_fid = pkt_info->oam_use_fid;
        }
        else
        {
            oam_hash_key.key.ether_vlan_oam.is_fid = pkt_info->oam_use_fid;
        }

        sal_memset(&oam_extra_result, 0, sizeof(oam_extra_result_t));

        oam_extra_result.chan = pkt_info->lm_chan0_data;
        oam_extra_result.info = pkt_info->lm_info0;
        lookup_result_ether_oam.extra = &oam_extra_result;

        DRV_IF_ERROR_RETURN(cm_com_userid_hash_lookup_request(ipkt->chip_id, pkt_info->local_phy_port, &oam_hash_key,
                                                    userid_key_type, USERID_DIRECTION_OTHER, &lookup_result_ether_oam));
        /*save lookup result to pkt_info */
        pkt_info->lm_result_valid0 = lookup_result_ether_oam.valid;
        pkt_info->hash_conflict0 = lookup_result_ether_oam.conflict;
    }
    else
    {
        /* Maximum 3 MPLS LM lookups, No MPLS OAM lookup in EPE */
        lm_lookup_num = 0;

        if (pkt_info->mpls_section_lm_en
            && ((L3_TYPE_MPLS == parser_result->layer3_type) || (L3_TYPE_MPLSMCAST == parser_result->layer3_type)))
        {
            /* MPLS section OAM/LM */
            pkt_info->lm_lookup_type = LM_MPLS;
            if (0 == (lm_lookup_num & 0x3))
            {
                pkt_info->lm_lookup_en0 = TRUE;
                pkt_info->packet_cos0 = pkt_info->section_lm_exp;
            }

            if (pkt_info->link_or_section_oam)
            {
                pkt_info->oam_lookup_num = 0;
            }

            lm_lookup_num = (lm_lookup_num + 1) & 0x3;

            userid_key_type = USERID_KEY_TYPE_MPLS_SECTION_OAM;
            /* used as interfaceId[9:0],linkagg ??? */
            oam_hash_key.key.mpls_section_oam.interface_id = (epe_acl_qos_ctl.mpls_section_oam_use_port) ?
                                                            (pkt_info->local_phy_port) : (pkt_info->interface_id);

            sal_memset(&oam_extra_result, 0, sizeof(oam_extra_result_t));
            oam_extra_result.chan = pkt_info->lm_chan0_data;
            oam_extra_result.info = pkt_info->lm_info0;
            lookup_result_mpls_section_oam.extra = &oam_extra_result;

            DRV_IF_ERROR_RETURN(cm_com_userid_hash_lookup_request(ipkt->chip_id, pkt_info->local_phy_port, &oam_hash_key,
                                             userid_key_type, USERID_DIRECTION_OTHER, &lookup_result_mpls_section_oam));

            /*save lookup result to pkt_info */
            pkt_info->lm_result_valid0 = lookup_result_mpls_section_oam.valid;
            pkt_info->hash_conflict0 = lookup_result_mpls_section_oam.conflict;

        }


        if (pkt_info->mpls_lm_valid2)
        {
            /* first label OAM/LM */
            DRV_IF_ERROR_RETURN(_cm_epe_aclqos_oam_lm_hash_lookup(ipkt->chip_id, pkt_info, lm_lookup_num, 2));
            lm_lookup_num = (lm_lookup_num + 1) & 0x3;
        }

        if (pkt_info->mpls_lm_valid1)
        {
            /* second label OAM/LM */
            DRV_IF_ERROR_RETURN(_cm_epe_aclqos_oam_lm_hash_lookup(ipkt->chip_id, pkt_info, lm_lookup_num, 1));
            lm_lookup_num = (lm_lookup_num + 1) & 0x3;
        }

        if (pkt_info->mpls_lm_valid0 && (3 != lm_lookup_num))
        {
            /* third label OAM/LM */
            DRV_IF_ERROR_RETURN(_cm_epe_aclqos_oam_lm_hash_lookup(ipkt->chip_id, pkt_info, lm_lookup_num, 0));
            if (pkt_info->oam_lookup_num == 0)
            {
                pkt_info->oam_lookup_num = lm_lookup_num;
            }
        }
        else if (pkt_info->mpls_lm_valid0 && (0 == pkt_info->oam_lookup_num))
        {
            pkt_info->oam_lookup_num = 3;
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name:      cm_epe_aclqos_handle
 * Purpose:   perform output ACL/QOS operations.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32
cm_epe_aclqos_handle(epe_in_pkt_t* ipkt)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_acl_qos_ctl_t epe_acl_qos_ctl;
    cm_epe_aclqos_lookup_result_t cm_epe_aclqos_lookup_result;
    uint32 cmd = 0;

    sal_memset(&cm_epe_aclqos_lookup_result, 0, sizeof(cm_epe_aclqos_lookup_result_t));

    sal_memset(&epe_acl_qos_ctl, 0, sizeof(epe_acl_qos_ctl_t));
    cmd = DRV_IOR(EpeAclQosCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_acl_qos_ctl));

    if (pkt_info->packet_header_en && epe_acl_qos_ctl.stacking_disable_acl)
    {
        /* PACKET_INFO */
        pkt_info->is_tcp = parser_result->l4_s.is_tcp;
        pkt_info->is_udp = parser_result->l4_s.is_udp;
    }
    else
    {
        if (!pkt_info->discard)
        {
        /* ACL_QOS_LOOKUPS */
            DRV_IF_ERROR_RETURN(_cm_epe_aclqos_aclqos_lookup(ipkt, &cm_epe_aclqos_lookup_result));
        }
        /* OAM_LOOKUPS */
        DRV_IF_ERROR_RETURN(_cm_epe_aclqos_oam_lookup(ipkt));

        /* ACL_QOS_RESULT */
        DRV_IF_ERROR_RETURN(_cm_epe_aclqos_process_dsaclqos(ipkt, cm_epe_aclqos_lookup_result));

        /* PACKET_INFO */
        pkt_info->is_tcp = parser_result->l4_s.is_tcp;
        pkt_info->is_udp = parser_result->l4_s.is_udp;
    }

    return DRV_E_NONE;
}

