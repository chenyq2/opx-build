/****************************************************************************
 * cm_epe_hdr_eidt.c    Provides EPE header editing function.
 *
 * Copyright:    (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       JiaKun.
 * Date:         2010-11-24.
 * Reason:       First Create for spec V5.0.0.
 *
 * Modify History:
 * Revision:     V2.0.
 * Author:       JiaKun.
 * Date:         2011-04-15.
 * Reason:       sync spec to v3.0.3
 *
 * Modify History:
 * Revision:     V4.2.1
 * Author:       JiangJf.
 * Date:         2011-07-04.
 * Reason:       sync spec to v4.2.1
 *
 * Revision:     V5.1.0
 * Author:       JiaK.
 * Date:         2011-12-13.
 * Reason:       sync spec to v5.1.0
 *
 * Revision:     V5.6.0
 * Author:       JiaK.
 * Date:         2012-01-7.
 * Reason:       sync spec to v5.6.0
 *
 * Revision:     V5.9.0
 * Author:       JiaK.
 * Date:         2012-01-19.
 * Reason:       sync spec to v5.9.0
 *
 * Revision:     V5.11.0
 * Author:       Wangcy.
 * Date:         2012-03-01.
 * Reason:       sync spec to v5.11.0
 *
 * Revision:     V5.15.0.
 * Author:       ZhouW.
 * Date:         2012-03-23.
 * Reason:       Sync to SpecV5.15.0.
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
struct cm_epe_oam_mep_chan_param_s
{
    void*   p_ds_oam_chan;
    void*   p_ds_lm_chan0;
    void*   p_ds_lm_chan1;
    void*   p_ds_lm_chan2;
    oam_info_t*  p_oam_info;
    oam_info_t*  p_lm_info0;
    oam_info_t*  p_lm_info1;
    oam_info_t*  p_lm_info2;
    uint8   mep_en;
    uint8   low_level_discard_en;
    uint8   oam_result_valid;
    uint8   lm_result_valid0;
    uint8   lm_result_valid1;
    uint8   lm_result_valid2;
    uint8   mpls_lm_type0;
    uint8   mpls_lm_type1;
    uint8   mpls_lm_type2;
    uint8   *compared_lm_cos;

    uint8   rx_oam_type;
    uint8   oam_dest_chip_id;
    uint16  mep_index ;
    uint8   dm_en;
    uint8   lm_received_packet;
    uint32  rxtx_fcl ;
    uint8 low_level_down_lm_disable;
};
typedef struct cm_epe_oam_mep_chan_param_s cm_epe_oam_mep_chan_param_t;

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/

/****************************************************************************
 * Name:      cm_epe_oam_process_mep_chan
 * Purpose:   perform oam operation.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 *            cm_epe_oam_mep_chan_param  -- pointer parameter to store some param
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32
_cm_epe_oam_mep_chan_process(epe_in_pkt_t* ipkt,
                                             cm_epe_oam_mep_chan_param_t* cm_epe_oam_mep_chan_param,
                                             cm_oam_lm_info_t* lm_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    ds_mpls_pbt_bfd_oam_chan_t *p_ds_mpls_pbt_bfd_oam_chan = NULL;
    ds_eth_oam_chan_t *p_ds_eth_oam_chan = NULL;
    ds_mpls_pbt_bfd_oam_chan_t* p_ds_lm_chan0 = NULL;
    ds_mpls_pbt_bfd_oam_chan_t* p_ds_lm_chan1 = NULL;
    ds_mpls_pbt_bfd_oam_chan_t* p_ds_lm_chan2 = NULL;

    mep_level_info_t mep_up_info[MAX_MEP_LEVEL];
    mep_level_info_t mep_down_info[MAX_MEP_LEVEL];
    oam_info_t*  p_oam_info = NULL;

    epe_oam_ctl_t epe_oam_ctl;

    uint8 lm_num = 0;
    uint8 mep_en = FALSE;
    uint8 low_level_discard_en = FALSE;
    uint8 oam_result_valid  = FALSE;
    uint8 lm_result_valid0 = FALSE;
    uint8 lm_result_valid1 = FALSE;
    uint8 lm_result_valid2 = FALSE;
    uint32 cmd = 0;

    cm_oam_chan_info_t chan_info;
    cm_oam_chan_rslt_t chan_rslt;

    uint8 is_ether_dm_packet = FALSE;

    uint8 oam_level = 0;
    uint8 rx_oam_type = OAM_NONE;

    uint8 oam_dest_chip_id  = 0;
    uint16 mep_index        = 0;
    uint8 dm_en             = FALSE;
    uint8 low_level_down_lm_disable = FALSE;

    rx_oam_type      = cm_epe_oam_mep_chan_param->rx_oam_type;

    oam_result_valid = cm_epe_oam_mep_chan_param->oam_result_valid;

    lm_result_valid0 = cm_epe_oam_mep_chan_param->lm_result_valid0;
    lm_result_valid1 = cm_epe_oam_mep_chan_param->lm_result_valid1;
    lm_result_valid2 = cm_epe_oam_mep_chan_param->lm_result_valid2;
    p_oam_info = cm_epe_oam_mep_chan_param->p_oam_info;

    sal_memset(mep_up_info, 0, sizeof(mep_up_info));
    sal_memset(mep_down_info, 0, sizeof(mep_down_info));
    sal_memset(&epe_oam_ctl, 0, sizeof(epe_oam_ctl_t));
    cmd = DRV_IOR(EpeOamCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_oam_ctl));

    /* MPLS LM */
    is_ether_dm_packet =  (OAM_OP_1DM == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code)
                          || (OAM_OP_DMM == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code)
                          || (OAM_OP_DMR == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code);

    if(LM_MPLS == pkt_info->lm_lookup_type)
    {
        if(lm_result_valid0)
        {
            p_ds_lm_chan0 = cm_epe_oam_mep_chan_param->p_ds_lm_chan0;
            lm_info->valid[0] = TRUE;
            lm_info->is_up[0] = FALSE;
            lm_info->lm_index_base[0] =  p_ds_lm_chan0->lm_index_base;
            lm_info->lm_type[0] = p_ds_lm_chan0->lm_type;
            lm_info->lm_cos_type[0] = p_ds_lm_chan0->lm_cos_type;
            lm_info->lm_cos[0] = p_ds_lm_chan0->lm_cos;

            cm_epe_oam_mep_chan_param->compared_lm_cos[0] = pkt_info->packet_cos0;
            cm_epe_oam_mep_chan_param->mpls_lm_type0 = p_ds_lm_chan0->mpls_lm_type;
        }

        if(lm_result_valid1)
        {
            p_ds_lm_chan1 = cm_epe_oam_mep_chan_param->p_ds_lm_chan1;
            lm_info->valid[1] = TRUE;
            lm_info->is_up[1] = FALSE;
            lm_info->lm_index_base[1] =  p_ds_lm_chan1->lm_index_base;
            lm_info->lm_type[1] = p_ds_lm_chan1->lm_type;
            lm_info->lm_cos_type[1] = p_ds_lm_chan1->lm_cos_type;
            lm_info->lm_cos[1] = p_ds_lm_chan1->lm_cos;

            cm_epe_oam_mep_chan_param->compared_lm_cos[1] = pkt_info->packet_cos1;
            cm_epe_oam_mep_chan_param->mpls_lm_type1 = p_ds_lm_chan1->mpls_lm_type;
        }

        if(lm_result_valid2)
        {
            p_ds_lm_chan2 = cm_epe_oam_mep_chan_param->p_ds_lm_chan2;
            lm_info->valid[2] = TRUE;
            lm_info->is_up[2] = FALSE;
            lm_info->lm_index_base[2] =  p_ds_lm_chan2->lm_index_base;
            lm_info->lm_type[2] = p_ds_lm_chan2->lm_type;
            lm_info->lm_cos_type[2] = p_ds_lm_chan2->lm_cos_type;
            lm_info->lm_cos[2] = p_ds_lm_chan2->lm_cos;

            cm_epe_oam_mep_chan_param->compared_lm_cos[2] = pkt_info->packet_cos2;
            cm_epe_oam_mep_chan_param->mpls_lm_type2 = p_ds_lm_chan2->mpls_lm_type;
        }
    }
    else  /* Ethernet LM & MEP INFO */
    {
        cm_epe_oam_mep_chan_param->compared_lm_cos[0] = pkt_info->packet_cos0; /* packet CoS */
        cm_epe_oam_mep_chan_param->compared_lm_cos[1] = pkt_info->packet_cos0;
        cm_epe_oam_mep_chan_param->compared_lm_cos[2] = pkt_info->packet_cos0;

        if(LM_TYPE_NONE != pkt_info->link_lm_type)
        {/* Link LM, lmNum always 0 */
            lm_info->lm_index_base[0] = pkt_info->link_lm_index_base;
            lm_info->valid[0] = TRUE;
            lm_info->is_up[0] = FALSE;
            lm_info->lm_level[0] = 0;
            lm_info->lm_type[0] = pkt_info->link_lm_type;
            lm_info->lm_cos_type[0] = pkt_info->link_lm_cos_type;
            lm_info->lm_cos[0] = pkt_info->link_lm_cos;

            lm_num = 1;
        }

        //==========bug 4672    ECO begin=============
        //if(((LM_ETHER == pkt_info->lm_lookup_type) || (OAM_ETHER == rx_oam_type)) && lm_result_valid0)
        if(oam_result_valid || lm_result_valid0)
        //==========bug 4672    ECO end=============
        {
            sal_memset(&chan_info, 0, sizeof(cm_oam_chan_info_t));
            sal_memset(&chan_rslt, 0, sizeof(cm_oam_chan_rslt_t));
            chan_info.next_lm = lm_num;
            chan_info.p_ds_eth_oam_chan = pkt_info->lm_chan0_data;
            chan_info.p_oam_chan_info = pkt_info->lm_info0;
            chan_rslt.lm_info = lm_info;
            chan_rslt.mep_down_info = mep_down_info;
            chan_rslt.mep_up_info = mep_up_info;

            cm_com_oam_get_mep_info(&chan_info, &chan_rslt);
        }

        if(LM_TYPE_NONE != pkt_info->link_lm_type)
        {/*link lm*/
            pkt_info->lm_lookup_type = LM_ETHER;
        }

    }

    /* Ethernet OAM */
    oam_level = parser_result->l3_s.ip_da.eth_oam.eth_oam_level;
    if(!pkt_info->discard && oam_result_valid && pkt_info->from_cpu_or_oam && pkt_info->is_up
        && (OAM_ETHER == rx_oam_type) && mep_up_info[oam_level].valid)
    {
        pkt_info->discard = TRUE;
        pkt_info->discard_type = EPE_DISCARD_OAM_TO_LOCAL_DISCARD;
        CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE OAM Module OamToLocal discard!\n");
        CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
    }
    else if(!pkt_info->discard && oam_result_valid && !pkt_info->from_cpu_or_oam
        && (OAM_ETHER == rx_oam_type))
    {
        p_ds_eth_oam_chan = cm_epe_oam_mep_chan_param->p_ds_oam_chan;
        oam_dest_chip_id = p_ds_eth_oam_chan->oam_dest_chip_id;

        if(mep_up_info[oam_level].valid)    /* always receive CCM when MEP is valid */
        {
            mep_index = mep_up_info[oam_level].mep_index;
            mep_en = TRUE;
            dm_en = is_ether_dm_packet;
        }
        else if(oam_level < chan_rslt.up_min_valid_lvl)
        {
            mep_index = mep_up_info[chan_rslt.up_min_valid_lvl].mep_index;
            mep_en = TRUE;
            low_level_down_lm_disable = TRUE;
        }
        else if(oam_level <= chan_rslt.down_max_valid_lvl)
        {
            mep_index = mep_down_info[chan_rslt.down_max_valid_lvl].mep_index;
            mep_en = TRUE;
            low_level_discard_en = TRUE;
        }
    }
    else if(!pkt_info->discard && oam_result_valid && (rx_oam_type != OAM_NONE) && !pkt_info->from_cpu_or_oam)
    { /* Non-Ethernet OAM */
        p_ds_mpls_pbt_bfd_oam_chan = cm_epe_oam_mep_chan_param->p_ds_oam_chan;
        oam_dest_chip_id = p_ds_mpls_pbt_bfd_oam_chan->oam_dest_chip_id;
        mep_index = p_ds_mpls_pbt_bfd_oam_chan->mep_index;
        mep_en = TRUE;
    }


    cm_epe_oam_mep_chan_param->low_level_discard_en = low_level_discard_en;
    cm_epe_oam_mep_chan_param->mep_en       = mep_en;
    cm_epe_oam_mep_chan_param->dm_en        = dm_en;
    cm_epe_oam_mep_chan_param->mep_index    = mep_index;
    cm_epe_oam_mep_chan_param->oam_dest_chip_id = oam_dest_chip_id;
    cm_epe_oam_mep_chan_param->low_level_down_lm_disable = low_level_down_lm_disable;

    return DRV_E_NONE;
}


/****************************************************************************
 * Name:      _cm_epe_oam_lm_process
 * Purpose:   perform oam lm operation.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 *            cm_epe_oam_mep_chan_param -- lm chan data
 *            lm_info -- lm information struct
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32
_cm_epe_oam_lm_process(epe_in_pkt_t* ipkt, cm_epe_oam_mep_chan_param_t* cm_epe_oam_mep_chan_param, cm_oam_lm_info_t* lm_info)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;
    epe_oam_ctl_t epe_oam_ctl;

    ds_oam_lm_stats0_t ds_oam_lm_stats;

    uint8 lm_stats_en0 = FALSE;
    uint8 lm_stats_en1 = FALSE;
    uint8 lm_stats_en2 = FALSE;
    uint8 ether_lm_enable = FALSE;
    uint8 mpls_lm_enable = FALSE;
    uint8 lm_ptr_num = 0;
    uint16 lm_index0 = 0;
    uint16 lm_index1 = 0;
    uint16 lm_index2 = 0;
    uint16 lm_stats_ptr0 = 0;
    uint16 lm_stats_ptr1 = 0;
    uint16 lm_stats_ptr2 = 0;
    uint32 cmd = 0;

    uint8 is_mpls_oam       = FALSE;
    uint8 is_mpls_ach_lm    = FALSE;
    uint8 is_mpls_y1731_oam = FALSE;
    uint8 is_mpls_y1731_aps_or_ccm = FALSE;
    uint8 is_mpls_y1731_aps = FALSE;
    uint8 is_mpls_y1731_ccm = FALSE;
    uint8 is_mpls_y1731_lmm_or_lmr = FALSE;
    uint8 is_mpls_y1731_lmm = FALSE;
    uint8 is_mpls_y1731_lmr = FALSE;
    uint8 mpls_lm_valid = FALSE;

    uint8 is_single_lm0 = FALSE;
    uint8 is_single_lm1 = FALSE;
    uint8 is_single_lm2 = FALSE;
    uint8 is_dual_lm0 = FALSE;
    uint8 is_dual_lm1 = FALSE;
    uint8 is_dual_lm2 = FALSE;

    uint8 lm_mpls_data_packet = FALSE;

    uint8 lm_mpls_oam_packet0 = FALSE;
    uint8 lm_mpls_oam_packet1 = FALSE;
    uint8 lm_mpls_oam_packet2 = FALSE;

    uint8 lm_cos_match0 = FALSE;
    uint8 lm_cos_match1 = FALSE;
    uint8 lm_cos_match2 = FALSE;

    uint8 is_mpls_lm_packet0   = FALSE;
    uint8 is_mpls_lm_packet1   = FALSE;
    uint8 is_mpls_lm_packet2   = FALSE;


    uint8 is_ether_oam = FALSE;
    uint8 is_ether_oam_aps = FALSE;
    uint8 is_ether_oam_ccm = FALSE;
    uint8 is_ether_oam_aps_or_ccm = FALSE;
    uint8 is_ether_oam_lmm_or_lmr = FALSE;
    uint8 is_ether_oam_lmm = FALSE;
    uint8 is_ether_oam_lmr = FALSE;
    uint8 ether_lm_valid = FALSE;

    uint8 is_ether_oam_equal_level0 = FALSE;
    uint8 is_ether_oam_equal_level1 = FALSE;
    uint8 is_ether_oam_equal_level2 = FALSE;

    uint8  lm_ether_oam_packet0 = FALSE;
    uint8  lm_ether_oam_packet1 = FALSE;
    uint8  lm_ether_oam_packet2 = FALSE;

    uint8  is_ether_lm_packet0    = FALSE;
    uint8  is_ether_lm_packet1    = FALSE;
    uint8  is_ether_lm_packet2    = FALSE;

    uint8 lm_packet_type = EPE_LM_PACKET_TYPE_NONE;
    uint8 lm_received_packet = FALSE;
    uint32 rxtx_fcl = 0;
    bool discard_down_lm_en = FALSE, discard_up_lm_en = FALSE, discard_mpls_lm_en = FALSE;

    sal_memset(&epe_oam_ctl, 0, sizeof(epe_oam_ctl_t));
    cmd = DRV_IOR(EpeOamCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_oam_ctl));


    /*LM decision (per traffic class in-profile, 100% losses within loss-of-conitnuty) infered LM???*/
    is_mpls_oam     = (L4_TYPE_ACH_OAM == parser_result->layer4_type);
    is_mpls_ach_lm  = (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_DLM)
                        || (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_DLMDM);
    is_mpls_y1731_oam = (parser_result->l4_s.layer4_user_type == L4_USER_TYPE_ACHOAM_ACH_Y1731);
    is_mpls_y1731_aps_or_ccm = (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_APS)
                                || (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_CCM);
    is_mpls_y1731_aps =  (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_APS);
    is_mpls_y1731_ccm =  (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_CCM);
    is_mpls_y1731_lmm_or_lmr = (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_LMM)
                                || (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_LMR);
    is_mpls_y1731_lmm =   (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_LMM);
    is_mpls_y1731_lmr =   (parser_result->l4_s.ptp_oam_ach.y1731_oam.y1731_oam_op_code == OAM_OP_LMR);

    mpls_lm_valid = (LM_MPLS == pkt_info->lm_lookup_type);

    is_single_lm0 = (LM_TYPE_SINGLE == lm_info->lm_type[0]);
    is_single_lm1 = (LM_TYPE_SINGLE == lm_info->lm_type[1]);
    is_single_lm2 = (LM_TYPE_SINGLE == lm_info->lm_type[2]);
    is_dual_lm0   = (LM_TYPE_DUAL == lm_info->lm_type[0]);
    is_dual_lm1   = (LM_TYPE_DUAL == lm_info->lm_type[1]);
    is_dual_lm2   = (LM_TYPE_DUAL == lm_info->lm_type[2]);

    lm_mpls_data_packet = (L4_TYPE_ACH_OAM != parser_result->layer4_type);
    lm_mpls_oam_packet0 = is_mpls_oam && is_mpls_y1731_oam && epe_oam_ctl.lm_proactive_mpls_oam_packet
                            && ((is_single_lm0 && is_mpls_y1731_aps_or_ccm) || (is_dual_lm0 && is_mpls_y1731_aps));
    lm_mpls_oam_packet1 = is_mpls_oam && is_mpls_y1731_oam && epe_oam_ctl.lm_proactive_mpls_oam_packet
                            && ((is_single_lm1 && is_mpls_y1731_aps_or_ccm) || (is_dual_lm1 && is_mpls_y1731_aps));
    lm_mpls_oam_packet2 = is_mpls_oam && is_mpls_y1731_oam && epe_oam_ctl.lm_proactive_mpls_oam_packet
                            && ((is_single_lm2 && is_mpls_y1731_aps_or_ccm) || (is_dual_lm2 && is_mpls_y1731_aps));

    lm_cos_match0 = (cm_epe_oam_mep_chan_param->compared_lm_cos[0] == lm_info->lm_cos[0])
                            || (LM_COS_TYPE_SPECIFIED_COS != lm_info->lm_cos_type[0]);
    lm_cos_match1 = (cm_epe_oam_mep_chan_param->compared_lm_cos[1] == lm_info->lm_cos[1])
                            || (LM_COS_TYPE_SPECIFIED_COS != lm_info->lm_cos_type[1]);
    lm_cos_match2 = (cm_epe_oam_mep_chan_param->compared_lm_cos[2] == lm_info->lm_cos[2])
                            || (LM_COS_TYPE_SPECIFIED_COS != lm_info->lm_cos_type[2]);

    is_mpls_lm_packet0 = mpls_lm_valid && lm_info->valid[0] &&
                        (lm_mpls_data_packet || lm_mpls_oam_packet0 || (0 != pkt_info->oam_lookup_num)) &&
                        lm_cos_match0;
    is_mpls_lm_packet1 = mpls_lm_valid && lm_info->valid[1] &&
                        (lm_mpls_data_packet || lm_mpls_oam_packet1 || (1 != pkt_info->oam_lookup_num)) &&
                        lm_cos_match1;
    is_mpls_lm_packet2 = mpls_lm_valid && lm_info->valid[2] &&
                        (lm_mpls_data_packet || lm_mpls_oam_packet2 || (2 != pkt_info->oam_lookup_num)) &&
                        lm_cos_match2;


    is_ether_oam = (L3_TYPE_ETHEROAM == parser_result->layer3_type);
    is_ether_oam_aps = (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_APS);
    is_ether_oam_ccm = (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_CCM);
    is_ether_oam_aps_or_ccm = ((parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_APS)||
                                (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_CCM));
    is_ether_oam_lmm_or_lmr = ((parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_LMM) ||
                                (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_LMR));
    is_ether_oam_lmm = (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_LMM);
    is_ether_oam_lmr = (parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code == OAM_OP_LMR);
    ether_lm_valid = (LM_ETHER == pkt_info->lm_lookup_type);

    is_ether_oam_equal_level0 = (parser_result->l3_s.ip_da.eth_oam.eth_oam_level == lm_info->lm_level[0]);
    is_ether_oam_equal_level1 = (parser_result->l3_s.ip_da.eth_oam.eth_oam_level == lm_info->lm_level[1]);
    is_ether_oam_equal_level2 = (parser_result->l3_s.ip_da.eth_oam.eth_oam_level == lm_info->lm_level[2]);

    lm_ether_oam_packet0  = is_ether_oam && is_ether_oam_equal_level0 &&
                            ((is_single_lm0 && is_ether_oam_aps_or_ccm) || (is_dual_lm0 && is_ether_oam_aps))&&
                            epe_oam_ctl.lm_proactive_ether_oam_packet;

    lm_ether_oam_packet1  = is_ether_oam && is_ether_oam_equal_level1 &&
                            ((is_single_lm1 && is_ether_oam_aps_or_ccm) || (is_dual_lm1 && is_ether_oam_aps))&&
                            epe_oam_ctl.lm_proactive_ether_oam_packet;
    lm_ether_oam_packet2  = is_ether_oam && is_ether_oam_equal_level2 &&
                            ((is_single_lm2 && is_ether_oam_aps_or_ccm) || (is_dual_lm2 && is_ether_oam_aps))&&
                            epe_oam_ctl.lm_proactive_ether_oam_packet;

    is_ether_lm_packet0   = ether_lm_valid && lm_info->valid[0] &&
                            (!is_ether_oam || lm_ether_oam_packet0 ||
                            (parser_result->l3_s.ip_da.eth_oam.eth_oam_level > lm_info->lm_level[0])) &&
                            lm_cos_match0;
    is_ether_lm_packet1   = ether_lm_valid && lm_info->valid[1] &&
                            (!is_ether_oam || lm_ether_oam_packet1 ||
                            (parser_result->l3_s.ip_da.eth_oam.eth_oam_level > lm_info->lm_level[1])) &&
                            lm_cos_match1;
    is_ether_lm_packet2   = ether_lm_valid && lm_info->valid[2] &&
                            (!is_ether_oam || lm_ether_oam_packet2 ||
                            (parser_result->l3_s.ip_da.eth_oam.eth_oam_level > lm_info->lm_level[2])) &&
                            lm_cos_match2;

    lm_stats_en0 = (is_mpls_lm_packet0 || is_ether_lm_packet0) &&
                    ((COLOR_GREEN == pkt_info->color) || !epe_oam_ctl.lm_green_packet);
    lm_stats_en1 = (is_mpls_lm_packet1 || is_ether_lm_packet1) &&
                    ((COLOR_GREEN == pkt_info->color) || !epe_oam_ctl.lm_green_packet);
    lm_stats_en2 = (is_mpls_lm_packet2 || is_ether_lm_packet2) &&
                    ((COLOR_GREEN == pkt_info->color) || !epe_oam_ctl.lm_green_packet);

    lm_index0 = lm_info->lm_index_base[0] + ((lm_info->lm_cos_type[0] != LM_COS_TYPE_PER_COS) ?
            0 : cm_epe_oam_mep_chan_param->compared_lm_cos[0]);
    lm_stats_ptr0 = lm_index0 & 0x3FFF;
    lm_index1 = lm_info->lm_index_base[1] + ((lm_info->lm_cos_type[1] != LM_COS_TYPE_PER_COS) ?
            0 : cm_epe_oam_mep_chan_param->compared_lm_cos[1]);
    lm_stats_ptr1 = lm_index1 & 0x3FFF;
    lm_index2 = lm_info->lm_index_base[2] + ((lm_info->lm_cos_type[2] != LM_COS_TYPE_PER_COS) ?
            0 : cm_epe_oam_mep_chan_param->compared_lm_cos[2]);
    lm_stats_ptr2 = lm_index2 & 0x3FFF;

    if (pkt_info->discard_type < 32)
    {
        discard_up_lm_en = IS_BIT_SET(epe_oam_ctl.discard_up_lm_en31_0, pkt_info->discard_type);
        discard_down_lm_en = IS_BIT_SET(epe_oam_ctl.discard_down_lm_en31_0, pkt_info->discard_type);
        discard_mpls_lm_en = IS_BIT_SET(epe_oam_ctl.discard_mpls_lm_en31_0, pkt_info->discard_type);
    }
    else
    {
        discard_up_lm_en = IS_BIT_SET(epe_oam_ctl.discard_up_lm_en63_32, pkt_info->discard_type);
        discard_down_lm_en = IS_BIT_SET(epe_oam_ctl.discard_down_lm_en63_32, pkt_info->discard_type);
        discard_mpls_lm_en = IS_BIT_SET(epe_oam_ctl.discard_mpls_lm_en63_32, pkt_info->discard_type);
    }

    if(lm_stats_en0)/* RAM1 for 0-255,RAM 2 for 256-383, RAM 2 for 384-511 */
    {
        sal_memset(&ds_oam_lm_stats, 0, sizeof(ds_oam_lm_stats));
        LM_CMD_READ(ipkt->chip_id, lm_stats_ptr0, cmd, ds_oam_lm_stats);

        if(LM_MPLS == pkt_info->lm_lookup_type)
        {
            if (!pkt_info->discard || discard_mpls_lm_en)
            {
                if (cm_epe_oam_mep_chan_param->mpls_lm_type0)
                {
                    ds_oam_lm_stats.tx_fcb_r++; /*txp[31:0]*/
                    if (ds_oam_lm_stats.tx_fcb_r == 0) /*overflow*/
                    {
                        ds_oam_lm_stats.tx_fcf_r++;/*txp[63:32]*/
                    }
                }
                else
                {
                    ds_oam_lm_stats.tx_fcl = ds_oam_lm_stats.tx_fcl + 1;
                }
            }
        }
        else if (lm_info->is_up[0])
        {
            if ((!pkt_info->discard || discard_up_lm_en) && (!pkt_info->from_cpu_lm_up_disable))
            {
                ds_oam_lm_stats.rx_fcl = ds_oam_lm_stats.rx_fcl + 1;
            }
        }
        else if (((pkt_info->link_lm_type != LM_TYPE_NONE) && (!pkt_info->discard || epe_oam_ctl.discard_link_lm_en)) /* link LM */
            || ((pkt_info->link_lm_type == LM_TYPE_NONE)
                && (!pkt_info->discard || discard_down_lm_en) /* Down LM */
                && (!pkt_info->from_cpu_lm_down_disable)
                && (!cm_epe_oam_mep_chan_param->mep_en)
                && (!cm_epe_oam_mep_chan_param->low_level_down_lm_disable)
                && (!pkt_info->ether_oam_discard)))
        {
            ds_oam_lm_stats.tx_fcl = ds_oam_lm_stats.tx_fcl + 1;
        }

        LM_CMD_WRITE(ipkt->chip_id, lm_stats_ptr0, cmd, ds_oam_lm_stats);
    }


    if(lm_stats_en1)
    {
        sal_memset(&ds_oam_lm_stats, 0, sizeof(ds_oam_lm_stats));
        LM_CMD_READ(ipkt->chip_id, lm_stats_ptr1, cmd, ds_oam_lm_stats);

        if(LM_MPLS == pkt_info->lm_lookup_type) /* per MPLS or global */
        {
            if (!pkt_info->discard || discard_mpls_lm_en)
            {
                if (cm_epe_oam_mep_chan_param->mpls_lm_type1)
                {
                    ds_oam_lm_stats.tx_fcb_r++; /*txp[31:0]*/
                    if (ds_oam_lm_stats.tx_fcb_r == 0) /*overflow*/
                    {
                        ds_oam_lm_stats.tx_fcf_r++;/*txp[63:32]*/
                    }
                }
                else
                {
                    ds_oam_lm_stats.tx_fcl = ds_oam_lm_stats.tx_fcl + 1;
                }
            }
        }
        else if (lm_info->is_up[1])
        {
            if ((!pkt_info->discard || discard_up_lm_en) && (!pkt_info->from_cpu_lm_up_disable))
            {
                ds_oam_lm_stats.rx_fcl = ds_oam_lm_stats.rx_fcl + 1;
            }
        }
        else if (
            //==========bug 4696    ECO begin=============
            //(pkt_info->link_lm_type == LM_TYPE_NONE)
            //&&
            //==========bug 4696    ECO end=============
            (!pkt_info->discard || discard_down_lm_en)  /* Down LM */
            && (!pkt_info->from_cpu_lm_down_disable)
            && (!cm_epe_oam_mep_chan_param->mep_en)
            && (!cm_epe_oam_mep_chan_param->low_level_down_lm_disable)
            && (!pkt_info->ether_oam_discard))
        {
            ds_oam_lm_stats.tx_fcl = ds_oam_lm_stats.tx_fcl + 1;
        }

        LM_CMD_WRITE(ipkt->chip_id, lm_stats_ptr1, cmd, ds_oam_lm_stats);
    }

    if(lm_stats_en2)
    {
        sal_memset(&ds_oam_lm_stats, 0, sizeof(ds_oam_lm_stats));
        LM_CMD_READ(ipkt->chip_id, lm_stats_ptr2, cmd, ds_oam_lm_stats);

        if(LM_MPLS == pkt_info->lm_lookup_type)
        {
            if(!pkt_info->discard || discard_mpls_lm_en)
            {
                if (cm_epe_oam_mep_chan_param->mpls_lm_type2)
                {
                    ds_oam_lm_stats.tx_fcb_r++; /*txp[31:0]*/
                    if (ds_oam_lm_stats.tx_fcb_r == 0) /*overflow*/
                    {
                        ds_oam_lm_stats.tx_fcf_r++;/*txp[63:32]*/
                    }
                }
                else
                {
                    ds_oam_lm_stats.tx_fcl = ds_oam_lm_stats.tx_fcl + 1;
                }
            }
        }
        else if (lm_info->is_up[2])
        {
            if ((!pkt_info->discard || discard_up_lm_en) && (!pkt_info->from_cpu_lm_up_disable))
            {
                ds_oam_lm_stats.rx_fcl = ds_oam_lm_stats.rx_fcl + 1;
            }
        }
        else if (
            //==========bug 4696    ECO begin=============
            //(pkt_info->link_lm_type == LM_TYPE_NONE)
            //&&
            //==========bug 4696    ECO end=============
            (!pkt_info->discard || discard_down_lm_en)  /* Down LM */
            && (!pkt_info->from_cpu_lm_down_disable)
            && (!cm_epe_oam_mep_chan_param->mep_en)
            && (!cm_epe_oam_mep_chan_param->low_level_down_lm_disable)
            && (!pkt_info->ether_oam_discard))
        {
            ds_oam_lm_stats.tx_fcl = ds_oam_lm_stats.tx_fcl + 1;
        }

        LM_CMD_WRITE(ipkt->chip_id, lm_stats_ptr2, cmd, ds_oam_lm_stats);
    }

    if(is_ether_oam)
    {
        if(lm_info->valid[0] && ((is_dual_lm0 && is_ether_oam_ccm) || (is_single_lm0 && is_ether_oam_lmm_or_lmr)) &&
            is_ether_oam_equal_level0 && lm_cos_match0 )/*level & COS match 0*/
        {
            ether_lm_enable = TRUE;
            lm_ptr_num = 0;
        }
        else if(lm_info->valid[1] && ((is_dual_lm1 && is_ether_oam_ccm) || (is_single_lm1 && is_ether_oam_lmm_or_lmr)) &&
            is_ether_oam_equal_level1 && lm_cos_match1 )/*level & COS match 1*/
        {
            ether_lm_enable = TRUE;
            lm_ptr_num = 1;
        }
        else if(lm_info->valid[2] && ((is_dual_lm2 && is_ether_oam_ccm) || (is_single_lm2 && is_ether_oam_lmm_or_lmr)) &&
            is_ether_oam_equal_level2 && lm_cos_match2 )/*level & COS match 2*/
        {
            ether_lm_enable = TRUE;
            lm_ptr_num = 2;
        }
    }

    if(((L3_TYPE_MPLS == parser_result->layer3_type) || (L3_TYPE_MPLSMCAST == parser_result->layer3_type))
        && is_mpls_oam)
    {
        if(lm_info->valid[0] && ((is_dual_lm0 && is_mpls_y1731_oam && is_mpls_y1731_ccm)
            ||(is_single_lm0 && ((is_mpls_y1731_oam && is_mpls_y1731_lmm_or_lmr) || is_mpls_ach_lm)))
            && (pkt_info->oam_lookup_num == 0)
            && lm_cos_match0)
        {
            mpls_lm_enable = TRUE;
            lm_ptr_num = 0;
        }
        else if(lm_info->valid[1] && ((is_dual_lm1 && is_mpls_y1731_oam && is_mpls_y1731_ccm)
            ||(is_single_lm1 && ((is_mpls_y1731_oam && is_mpls_y1731_lmm_or_lmr) || is_mpls_ach_lm)))
            && (pkt_info->oam_lookup_num == 1)
            && lm_cos_match1)
        {
            mpls_lm_enable = TRUE;
            lm_ptr_num = 1;
        }
        else if(lm_info->valid[2] && ((is_dual_lm2 && is_mpls_y1731_oam && is_mpls_y1731_ccm)
            ||(is_single_lm2 && ((is_mpls_y1731_oam && is_mpls_y1731_lmm_or_lmr) || is_mpls_ach_lm)))
            && (pkt_info->oam_lookup_num == 2)
            && lm_cos_match2)
        {
            mpls_lm_enable = TRUE;
            lm_ptr_num = 2;
        }
    }


    if(ether_lm_enable && is_ether_oam_ccm)/*Ethernet CCM*/
    {
        lm_packet_type = EPE_LM_PACKET_TYPE_ETHER_CCM;
    }
    else if(ether_lm_enable && is_ether_oam_lmm)/*Ether LMM*/
    {
        lm_packet_type = EPE_LM_PACKET_TYPE_ETHER_LMM;
    }
    else if(ether_lm_enable && is_ether_oam_lmr)/*Ether LMR*/
    {
        lm_packet_type = EPE_LM_PACKET_TYPE_ETHER_LMR;
    }
    else if (mpls_lm_enable && is_mpls_ach_lm)
    {
        lm_packet_type = EPE_LM_PACKET_TYPE_ACH;/*LM ACH enabled, 64 bits or 32 bits?*/
    }
    else if(mpls_lm_enable && is_mpls_y1731_oam && is_mpls_y1731_ccm)
    {
        lm_packet_type = EPE_LM_PACKET_TYPE_TP1731_CCM;/*MPLS-TP Y1731 CCM*/
    }
    else if(mpls_lm_enable && is_mpls_y1731_oam && is_mpls_y1731_lmm)
    {
        lm_packet_type = EPE_LM_PACKET_TYPE_TP1731_LMM;/*MPLS-TP Y1731 LMM*/
    }
    else if(mpls_lm_enable && is_mpls_y1731_oam && is_mpls_y1731_lmr)
    {
        lm_packet_type = EPE_LM_PACKET_TYPE_TP1731_LMR;/*MPLS-TP Y1731 LMR*/
    }
    else if (SHARE_TYPE_LMTX != pkt_info->share_type)
    {
        lm_packet_type = EPE_LM_PACKET_TYPE_NONE;/* no LM */
    }

    if(EPE_LM_PACKET_TYPE_NONE != lm_packet_type)
    {
        sal_memset(&ds_oam_lm_stats, 0, sizeof(ds_oam_lm_stats));
        if(0 == lm_ptr_num)
        {
            LM_CMD_READ(ipkt->chip_id, lm_stats_ptr0, cmd, ds_oam_lm_stats);
        }
        else if(1 == lm_ptr_num)
        {
            LM_CMD_READ(ipkt->chip_id, lm_stats_ptr1, cmd, ds_oam_lm_stats);
        }
        else if(2 == lm_ptr_num)
        {
            LM_CMD_READ(ipkt->chip_id, lm_stats_ptr2, cmd, ds_oam_lm_stats);
        }
    }

    if(pkt_info->from_cpu_or_oam && IS_BIT_SET(lm_packet_type, 3) && ((lm_packet_type&0x3) == 0))
    {
        pkt_info->share_type = SHARE_TYPE_LMTX; /* Ethernet/MPLS-TP CCM */
        pkt_info->share_fields_u.lmtx.lm_packet_type = lm_packet_type & 0x7;
        pkt_info->share_fields_u.lmtx.rxtx_fcl = ds_oam_lm_stats.tx_fcl;      /* local counter TxFcl when TX */
        pkt_info->share_fields_u.lmtx.rx_fcb = ds_oam_lm_stats.rx_fcl_r;    /* local counter TxFcl last RX */
        pkt_info->share_fields_u.lmtx.tx_fcb = ds_oam_lm_stats.tx_fcf_r;    /* packet's TxFCf last RX */

    }
    else if(pkt_info->from_cpu_or_oam && IS_BIT_SET(lm_packet_type, 3) && ((lm_packet_type&0x3) == 1))
    {
        pkt_info->share_type = SHARE_TYPE_LMTX;  /* Ethernet/MPLS-TP LMM */
        pkt_info->share_fields_u.lmtx.lm_packet_type = lm_packet_type & 0x7;
        pkt_info->share_fields_u.lmtx.rxtx_fcl = ds_oam_lm_stats.tx_fcl;
        pkt_info->share_fields_u.lmtx.rx_fcb = 0;
        pkt_info->share_fields_u.lmtx.tx_fcb = 0;
    }
    else if(pkt_info->from_cpu_or_oam && IS_BIT_SET(lm_packet_type, 3) && ((lm_packet_type&0x3) == 2))
    {
        pkt_info->share_type = SHARE_TYPE_LMTX;  /* Ethernet/MPLS-TP LMR */
        pkt_info->share_fields_u.lmtx.lm_packet_type = lm_packet_type & 0x7;
        pkt_info->share_fields_u.lmtx.rxtx_fcl = ds_oam_lm_stats.tx_fcl;
        pkt_info->share_fields_u.lmtx.rx_fcb = 0;
        pkt_info->share_fields_u.lmtx.tx_fcb = 0;
    }
    else if(pkt_info->from_cpu_or_oam && (EPE_LM_PACKET_TYPE_ACH == lm_packet_type))
    {

        pkt_info->share_type = SHARE_TYPE_LMTX;  /*MPLS-TP ACH LM*/
        pkt_info->share_fields_u.lmtx.lm_packet_type = lm_packet_type & 0x7;
        pkt_info->share_fields_u.lmtx.rx_fcb = 0;

        if(IS_BIT_SET(parser_result->l4_s.ptp_oam_ach.ach_lm.ach_lm_flag, 3)) /*64 bits counter*/
        {
            pkt_info->share_fields_u.lmtx.tx_fcb = ds_oam_lm_stats.tx_fcf_r; /*txp[63:32]*/
            pkt_info->share_fields_u.lmtx.rxtx_fcl = ds_oam_lm_stats.tx_fcb_r; /*txp[31:0]*/
        }
        else
        {
            pkt_info->share_fields_u.lmtx.tx_fcb = 0;
            pkt_info->share_fields_u.lmtx.rxtx_fcl = ds_oam_lm_stats.tx_fcb_r;
        }
    }
    else if(!pkt_info->from_cpu_or_oam && IS_BIT_SET(lm_packet_type, 3) && ((lm_packet_type&0x3) == 0))
    {
        lm_received_packet = TRUE;
        ds_oam_lm_stats.tx_fcf_r = parser_result->l3_s.ip_sa.eth_oam.tx_fcf;
        ds_oam_lm_stats.rx_fcb_r = parser_result->l3_s.ip_sa.eth_oam.rx_fcb;
        ds_oam_lm_stats.tx_fcb_r = parser_result->l3_s.ip_sa.eth_oam.tx_fcb;
        ds_oam_lm_stats.rx_fcl_r = ds_oam_lm_stats.rx_fcl;

        if(0 == lm_ptr_num)
        {
            LM_CMD_WRITE(ipkt->chip_id, lm_stats_ptr0, cmd, ds_oam_lm_stats);
        }
        else if(1 == lm_ptr_num)
        {
            LM_CMD_WRITE(ipkt->chip_id, lm_stats_ptr1, cmd, ds_oam_lm_stats);
        }
        else if(2 == lm_ptr_num)
        {
            LM_CMD_WRITE(ipkt->chip_id, lm_stats_ptr2, cmd, ds_oam_lm_stats);
        }

    }
    else if (!pkt_info->from_cpu_or_oam && IS_BIT_SET(lm_packet_type, 3) && ((lm_packet_type&0x3) == 1))
    {
        lm_received_packet = TRUE;
        rxtx_fcl = ds_oam_lm_stats.rx_fcl;
    }
    else if (!pkt_info->from_cpu_or_oam && IS_BIT_SET(lm_packet_type, 3) && ((lm_packet_type&0x3) == 2))
    {
        lm_received_packet = TRUE;
        rxtx_fcl = ds_oam_lm_stats.rx_fcl;
    }

    cm_epe_oam_mep_chan_param->lm_received_packet = lm_received_packet;
    cm_epe_oam_mep_chan_param->rxtx_fcl = rxtx_fcl;
    return DRV_E_NONE;
}
/****************************************************************************
 * Name:      cm_epe_oam_process_handle
 * Purpose:   perform oam operation.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:    ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32
cm_epe_oam_process_handle(epe_in_pkt_t* ipkt)
{
    epe_oam_ctl_t epe_oam_ctl;
    uint32 cmd = 0;

    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    parsing_result_t* parser_result = (parsing_result_t*) pkt_info->parser_result;

    cm_epe_oam_mep_chan_param_t cm_epe_oam_mep_chan_param;
    cm_oam_lm_info_t lm_info;
    oam_info_t*  p_oam_info = NULL;

    /*tmp*/
    uint8 lm_result_valid0_temp = FALSE;
    uint8 hash_conflict0_tmp    = FALSE;
    void *ds_lm_chan0_tmp       = NULL;
    oam_info_t* lm_chan_info0_tmp = NULL;

    ds_mpls_pbt_bfd_oam_chan_t *p_ds_mpls_pbt_bfd_oam_chan = NULL;
    ds_eth_oam_chan_t *p_ds_eth_oam_chan = NULL;

    uint8 oam_result_valid = FALSE;
    uint8 lm_result_valid0 = FALSE;
    uint8 lm_result_valid1 = FALSE;
    uint8 lm_result_valid2 = FALSE;

    uint8 mep_en = FALSE;
    uint8 mip_en = FALSE;
    uint8 hash_conflict = FALSE;
    void *ds_lm_chan0 = NULL;
    void *ds_lm_chan1 = NULL;
    void *ds_lm_chan2 = NULL;

    oam_info_t *lm_info0 = NULL;
    oam_info_t *lm_info1 = NULL;
    oam_info_t *lm_info2 = NULL;

    void *ds_oam_chan       = NULL;
    oam_info_t *oam_info    = NULL;

    uint8   compared_lm_cos[MAX_LM_INFO_NUM] = {0};

    uint8   rx_oam_type = OAM_NONE;
    uint8   oam_dest_chip_id = 0;
    uint16  mep_index = 0;
    uint8   dm_en = FALSE;
    uint8   lm_received_packet = FALSE;
    uint32  rxtx_fcl = 0;

    /* POP_DS */
    if (pkt_info->lm_lookup_en0 || (pkt_info->oam_lookup_en && (0 == pkt_info->oam_lookup_num)))
    {/* first pop */

        lm_result_valid0_temp = pkt_info->lm_result_valid0;
        ds_lm_chan0_tmp       = pkt_info->lm_chan0_data;
        lm_chan_info0_tmp     = pkt_info->lm_info0;
        hash_conflict0_tmp    = pkt_info->hash_conflict0;

        if (pkt_info->lm_lookup_en0)
        {
            lm_result_valid0 = lm_result_valid0_temp;
            ds_lm_chan0  = ds_lm_chan0_tmp;
            lm_info0     = lm_chan_info0_tmp;

            ds_oam_chan = ds_lm_chan0_tmp;
            oam_info    = lm_chan_info0_tmp;
        }

        if (pkt_info->oam_lookup_en && (0 == pkt_info->oam_lookup_num))
        {
            oam_result_valid    = lm_result_valid0_temp;
            ds_oam_chan         = ds_lm_chan0_tmp;
            oam_info            = lm_chan_info0_tmp;
        }
        hash_conflict       = hash_conflict0_tmp;
    }

    if (pkt_info->lm_lookup_en0 && pkt_info->lm_lookup_en1)
    {/* second pop, only lm */

        lm_result_valid0_temp = pkt_info->lm_result_valid1;
        ds_lm_chan0_tmp       = pkt_info->lm_chan1_data;
        lm_chan_info0_tmp     = pkt_info->lm_info1;
        hash_conflict0_tmp    = pkt_info->hash_conflict1;

        lm_result_valid1 = lm_result_valid0_temp;
        ds_lm_chan1  = ds_lm_chan0_tmp;
        lm_info1     = lm_chan_info0_tmp;

        ds_oam_chan         = ds_lm_chan0_tmp;
        oam_info            = lm_chan_info0_tmp;
    }

    if (pkt_info->lm_lookup_en0 && pkt_info->lm_lookup_en1 && pkt_info->lm_lookup_en2)
    {/* third pop, only lm */
        lm_result_valid0_temp = pkt_info->lm_result_valid2;
        ds_lm_chan0_tmp       = pkt_info->lm_chan2_data;
        lm_chan_info0_tmp     = pkt_info->lm_info2;
        hash_conflict0_tmp    = pkt_info->hash_conflict2;


        lm_result_valid2 = lm_result_valid0_temp;
        ds_lm_chan2  = ds_lm_chan0_tmp;
        lm_info2     = lm_chan_info0_tmp;

        ds_oam_chan         = ds_lm_chan0_tmp;
        oam_info            = lm_chan_info0_tmp;
    }
    rx_oam_type = pkt_info->rx_oam_type;

    /*DS_MEP_CHAN_PROCESS*/
    sal_memset(&cm_epe_oam_mep_chan_param, 0, sizeof(cm_epe_oam_mep_chan_param));
    cm_epe_oam_mep_chan_param.p_ds_oam_chan = ds_oam_chan;
    cm_epe_oam_mep_chan_param.p_ds_lm_chan0 = ds_lm_chan0;
    cm_epe_oam_mep_chan_param.p_ds_lm_chan1 = ds_lm_chan1;
    cm_epe_oam_mep_chan_param.p_ds_lm_chan2 = ds_lm_chan2;
    cm_epe_oam_mep_chan_param.p_oam_info    = oam_info;
    cm_epe_oam_mep_chan_param.p_lm_info0    = lm_info0;
    cm_epe_oam_mep_chan_param.p_lm_info1    = lm_info1;
    cm_epe_oam_mep_chan_param.p_lm_info2    = lm_info2;
    cm_epe_oam_mep_chan_param.oam_result_valid = oam_result_valid;
    cm_epe_oam_mep_chan_param.lm_result_valid0 = lm_result_valid0;
    cm_epe_oam_mep_chan_param.lm_result_valid1 = lm_result_valid1;
    cm_epe_oam_mep_chan_param.lm_result_valid2 = lm_result_valid2;
    cm_epe_oam_mep_chan_param.compared_lm_cos = compared_lm_cos;

    cm_epe_oam_mep_chan_param.rx_oam_type = rx_oam_type;
    sal_memset(&lm_info, 0, sizeof(cm_oam_lm_info_t));
    DRV_IF_ERROR_RETURN(_cm_epe_oam_mep_chan_process(ipkt, &cm_epe_oam_mep_chan_param, &lm_info));

    mep_en              = cm_epe_oam_mep_chan_param.mep_en;
    oam_dest_chip_id    = cm_epe_oam_mep_chan_param.oam_dest_chip_id;
    mep_index           = cm_epe_oam_mep_chan_param.mep_index;
    dm_en               = cm_epe_oam_mep_chan_param.dm_en;

    /*LM_PROCESS*/
    DRV_IF_ERROR_RETURN(_cm_epe_oam_lm_process(ipkt, &cm_epe_oam_mep_chan_param ,&lm_info));
    lm_received_packet = cm_epe_oam_mep_chan_param.lm_received_packet;
    rxtx_fcl = cm_epe_oam_mep_chan_param.rxtx_fcl;

    p_oam_info = (oam_info_t*)pkt_info->lm_info0;

    /* RX_OAM_TYPE */
    /* MIP decision */
    if((L3_TYPE_ETHEROAM == parser_result->layer3_type) && oam_result_valid
        && IS_BIT_SET((p_oam_info->mip_bitmap << 1), parser_result->l3_s.ip_da.eth_oam.eth_oam_level)
        && (((OAM_OP_LBM == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code) && pkt_info->is_port_mac)
            || (OAM_OP_LTM == parser_result->l3_s.ip_da.eth_oam.eth_oam_op_code)))/*MIP*/
    {
        mip_en = TRUE; /* discard, etherOamDiscard ??? */

        if(OAM_ETHER == rx_oam_type)
        {
            p_ds_eth_oam_chan = ds_oam_chan;
            oam_dest_chip_id = p_ds_eth_oam_chan->oam_dest_chip_id;
        }
        else
        {
            p_ds_mpls_pbt_bfd_oam_chan  = ds_oam_chan;
            oam_dest_chip_id = p_ds_mpls_pbt_bfd_oam_chan->oam_dest_chip_id;;
        }
    }

    sal_memset(&epe_oam_ctl, 0, sizeof(epe_oam_ctl_t));
    cmd = DRV_IOR(EpeOamCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &epe_oam_ctl));

    if(!mep_en && !mip_en && hash_conflict && (OAM_NONE != rx_oam_type)
        && !pkt_info->from_cpu_or_oam)/* to CPU for more process */
    {
        if(!pkt_info->discard)
        {
            pkt_info->discard = TRUE;
            pkt_info->discard_type = EPE_DISCARD_OAM_HASH_CONFILICT_DISCARD;
            CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE_DISCARD_OAM_HASH_CONFLICT!\n");
            CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
        }

        if (epe_oam_ctl.oam_hash_conflict_exception_en && !pkt_info->exception_en)
        {
            pkt_info->exception_en = TRUE;
            pkt_info->exception_index = EXCEPTION_TYPE_OAM_1;
        }
    }

    if (rx_oam_type == OAM_ETHER)
    {
        if ((!mep_en || cm_epe_oam_mep_chan_param.low_level_discard_en)
                 && !mip_en && pkt_info->ether_oam_edge_port
                 && (!pkt_info->from_cpu_or_oam || pkt_info->is_up)) /* ETHEROAM over Tunnel process by oamTunnelEn in NEXTHOP */
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = EPE_DISCARD_OAM_EGDE_PORT_DISCARD;

                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE_DISCARD_OAM_EGDE_PORT_DISCARD!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if ((!mep_en || (cm_epe_oam_mep_chan_param.low_level_discard_en
                 && epe_oam_ctl.low_level_oam_filtering_en))
                 && !mip_en && pkt_info->ether_oam_discard)
        {
            if (!pkt_info->discard)
            {
                pkt_info->discard = TRUE;
                pkt_info->discard_type = EPE_DISCARD_OAM_FILTERING_DISCARD;

                CMODEL_DEBUG_OUT_INFO("++++ Discard! EPE_DISCARD_OAM_FILTERING_DISCARD!\n");
                CMODEL_DEBUG_OUT_FILE_LINE_FUNC();
            }
        }
        else if (!mep_en && !mip_en)
        {
            rx_oam_type = OAM_NONE;
        }
    }
    else if ((rx_oam_type != OAM_NONE) && !mep_en && !mip_en) /* MPLS OAM TX as normal packet to network port */
    {
        rx_oam_type = OAM_NONE;
    }

    if((OAM_NONE != rx_oam_type) && !(pkt_info->exception_en
        && ((pkt_info->exception_index == 3) || (pkt_info->exception_index == 4))))
    {
        pkt_info->share_type = SHARE_TYPE_OAM;
        pkt_info->share_fields_u.oam.oam_dest_chip_id   = oam_dest_chip_id;
        pkt_info->share_fields_u.oam.mip_en             = mip_en;
        pkt_info->share_fields_u.oam.mep_index          = mep_index;
        pkt_info->share_fields_u.oam.rx_oam_type        = rx_oam_type;
        pkt_info->share_fields_u.oam.lm_received_packet = lm_received_packet;
        pkt_info->share_fields_u.oam.dm_en              = dm_en;

        pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0   = rxtx_fcl;

        pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32=0;

        if(dm_en)
        {
            uint32 msb = 0;
            uint32 lsb = 0;
            GET_PTP_ENGINE_TIMESTAMP(PTP_ENGINE_ACCESS_EPE_NEXTHOP, FALSE, &msb, &lsb);

            pkt_info->share_fields_u.oam.rx_fcb_or_time_stamp_63_32 = (msb >> 2);
            pkt_info->share_fields_u.oam.rxtx_fcl_or_time_stamp_31_0 = ((msb&0x3) << 30)| (lsb&0x3FFFFFFF);
        }
    }
    return DRV_E_NONE;
}


