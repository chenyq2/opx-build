/****************************************************************************
 * cm_epe_net_tx.c: provide  epe net tx function
 *
 *
 * Copyright: (c)2010 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     V1.0.
 * Author:       Jiangsz
 * Date:         2010-10-25.
 * Reason:       First Create.
 *
 * Modify History:
 * Revision:     V2.0.
 * Author:       Jiangsz
 * Date:         2011-04-14.
 * Reason:       First Create.
 *
 * Revision:     V4.3.0
 * Author:       Zhouw.
 * Date:         2011-07-01.
 * Reason:       Sync spec Revision 4.3.0.
 *
 * Revision:     V4.7.1
 * Author:       JiaK.
 * Date:         2011-07-28.
 * Reason:       Sync spec revision 4.7.1.
 *
 * Revision:     V4.28
 * Author:       JiaK.
 * Date:         2011-09-29.
 * Reason:       Sync spec revision 4.28.
 *
 * Revision:     V4.29.3
 * Author:       JiaK.
 * Date:         2011-10-10.
 * Reason:       Sync spec revision 4.29.3
 *
 * Revision:     V4.31.0
 * Author:       JiaK.
 * Date:         2011-10-22.
 * Reason:       sync spec to v4.31.0
 *
 * Revision:     V5.1.0
 * Author:       JiaK.
 * Date:         2011-12-9.
 * Reason:       sync spec to v5.1.0
 *
 * Revision:     V5.6.0
 * Author:       JiaK.
 * Date:         2012-01-7.
 * Reason:       sync spec to v5.6.0
 *
 * Revision:     V5.15.2.
 * Author:       ZhouW.
 * Date:         2012-04-01.
 * Reason:       Sync to SpecV5.15.2.
 ****************************************************************************/
#include "sal.h"
#include "drv_lib.h"
#include "cm_lib.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/
extern bool higig_en;

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/
/****************************************************************************
 * Name:      cm_epe_net_tx_handle
 * Purpose:   EPE process net transmit packet.
 * Parameters:
 * Input:     ipkt  -- pointer to buffer which save input packet and packet
 *                     header ,and processing informations
 * Output:    out_pkt_l  -- pointer to list of out packet
 * Return:    DRV_E_NONE = success.
 *            Other      = Error, please refer to DRV_E_XXX.
 * Note:      none.
****************************************************************************/
int32 cm_epe_net_tx_handle(epe_in_pkt_t* ipkt, list_head_t* out_pkt_list)
{
    epe_packet_info_t* pkt_info = (epe_packet_info_t*) ipkt->pkt_info;
    greatbelt_exception_info_t* bexception = pkt_info->bexception;
    ms_packet_header_t bheader;
    greatbelt_packet_header_t cm_packet_header;
    out_pkt_t* out_pkt = NULL;
    out_pkt_t* eloop_pkt = NULL;
    queue_in_pkt_t qpkt;
    uint32 exception_vector = 0;
    net_tx_int_lk_ctl_t nettx_interlaken_ctl;
    int_lk_intf_cfg_t interlaken_intf_cfg;
    ds_dest_ptp_chan_t ds_dst_ptp_chan;
    mac_message_type_t mac_msg;
    ms_net_tx_t* p_ms_net_tx = &(ipkt->ms_net_tx);
    net_tx_cfg_chan_id_t net_tx_cfg_chan_id ;

    uint32 total_len = 0;
    uint32 crc = 0;
    int32 ret = 0;
    uint32 cmd = 0;
    uint32 channel_id = ipkt->chan_id, interlaken_channelid = 0;

    sal_memset(&bheader, 0, sizeof(ms_packet_header_t));
    sal_memcpy(&bheader, pkt_info->bheader, GREAT_BELT_HEADER_LEN);
    swap32(((uint32*)(&bheader)),GREAT_BELT_HEADER_LEN / 4,NETWORK_TO_HOST);

    /* some PTP temp var */
    uint32 ts_63_to_32 = 0, ts_31_to_0 = 0;
    bool to_mac = !((p_ms_net_tx->loopback_en) || bexception->exception_vector); /* need to confirm ?? add by zhouw */

    uint16 egress_latency = 0;

    /* some sgmac tc dp var */
    bool to_sgmac = FALSE;
    uint32 index = 0;
    net_tx_sgmac_priority_map_table_t net_tx_sgmac_priority_map_table;
    /* need to confirm ?? add by shenhg */
    to_sgmac = higig_en && to_mac && ((channel_id>=SGMAC_MIN_CHANID_SUPPORT_HIGIG)&&(channel_id<=SGMAC_MAX_CHANID_SUPPORT_HIGIG));

    // QCN packet genetation
    // receive information from IPE FWD {globalSrcPort[13:0], priority[5:0], macSa[47:0], macDa[47:0],
    // localPhyPort[6:0], cnmBytes{12..35}, qcnFb[5:0], qcnQoffset[15:0], qcnDelta[15:0], svlanIdValid, stagCos[2:0],
    // svlanId[11:0], cvlanIdValid, ctagCos[2:0], cvlanId[11:0], cnTagValid, cnFlowId[15:0]
    // qcnFromIpe ignore

    /* Pause & PFC */

    sal_memset(&cm_packet_header, 0, sizeof(cm_packet_header));
    cm_gen_greatbelt_packet_header(&bheader, &cm_packet_header, TRUE);

    sal_memset(&nettx_interlaken_ctl, 0, sizeof(nettx_interlaken_ctl));
    cmd = DRV_IOR(NetTxIntLkCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &nettx_interlaken_ctl));

    sal_memset(&interlaken_intf_cfg, 0, sizeof(interlaken_intf_cfg));
    cmd = DRV_IOR(IntLkIntfCfg_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &interlaken_intf_cfg));

    sal_memset(&net_tx_cfg_chan_id, 0, sizeof(net_tx_cfg_chan_id));
    cmd = DRV_IOR(NetTxCfgChanId_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, 0, cmd, &net_tx_cfg_chan_id));


    if (net_tx_cfg_chan_id.cfg_int_lk_chan_en_int&&(channel_id == net_tx_cfg_chan_id.cfg_int_lk_chan_id_int)
        && nettx_interlaken_ctl.int_lk_fabric_mode)
    {/* fabricMode */
        interlaken_channelid
            = nettx_interlaken_ctl.int_lk_fabric_local_phy_port & 0x7F;
        ipkt->module_bus.sub_chan_id =  interlaken_channelid;
    }
    else if (net_tx_cfg_chan_id.cfg_int_lk_chan_en_int&&(channel_id == net_tx_cfg_chan_id.cfg_int_lk_chan_id_int)
             && (!interlaken_intf_cfg.int_lk_slave_mode))
    {/* destination port for MacAgg */
        interlaken_channelid = (cm_packet_header.dest_id & 0x7F)
                               - (nettx_interlaken_ctl.int_lk_local_phy_port_base & 0x7F);
        ipkt->module_bus.sub_chan_id =  interlaken_channelid;
    }
    else if (net_tx_cfg_chan_id.cfg_int_lk_chan_en_int&&(channel_id == net_tx_cfg_chan_id.cfg_int_lk_chan_id_int)
            && interlaken_intf_cfg.int_lk_slave_mode)
    {/* source port form MacAgg */
        interlaken_channelid = (cm_packet_header.source_port & 0x7F)
                               - (nettx_interlaken_ctl.int_lk_local_phy_port_base & 0x7F);
        ipkt->module_bus.sub_chan_id =  interlaken_channelid;
    }

    sal_memset(&mac_msg, 0, sizeof(mac_msg));
    if (to_mac && (cm_packet_header.operation_type == OPERATION_TYPE_PTP))
    {
        sal_memset(&ds_dst_ptp_chan, 0, sizeof(ds_dst_ptp_chan));
        cmd = DRV_IOR(DsDestPtpChan_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, channel_id, cmd, &ds_dst_ptp_chan));

        mac_msg.frag_info1 = p_ms_net_tx->frag_info1;
        mac_msg.udp_ptp = p_ms_net_tx->udp_ptp;
        mac_msg.layer4_checksum = p_ms_net_tx->layer4_check_sum;
        mac_msg.ptp_sequence_id = cm_packet_header.source_port_isolate_id_u.share1.ptp_sequence_id;
        mac_msg.ptp_edit_type = cm_packet_header.source_port_isolate_id_u.share1.ptp_edit_type;
        mac_msg.udp_check_sum_offset = p_ms_net_tx->ptp_offset - 2;

        mac_msg.time_stamp_valid = TRUE;
        egress_latency = ds_dst_ptp_chan.egress_latency;

        if (cm_packet_header.source_port_isolate_id_u.share1.ptp_offset_type == PTP_OFFSET_TYPE_OTHER)
        {//DM
            if (!IS_BIT_SET(mac_msg.ptp_edit_type, 0))
            {
                mac_msg.timestamp.high_63_32 = 0;
                mac_msg.timestamp.low_31_0 = egress_latency & 0xFFFF;
            }
            else
            {
                cm_get_ptp_timestamp_in_header(&cm_packet_header,&mac_msg.timestamp.high_63_32,&mac_msg.timestamp.low_31_0);
            }
            mac_msg.timestamp_offset = p_ms_net_tx->ptp_offset; /* total offset */
        }
        else
        {
            if (mac_msg.ptp_edit_type != PTP_CORRECTION)
            {//PTP OC/BC, PacketHeader.timeStamp is timegap with s + ns
                /* !MsNetTx.timeStamp62 come from (refer spec review??)*/
                mac_msg.timestamp.low_31_0 = egress_latency;

                if (PTP_OFFSET_TYPE_PTPV1 == cm_packet_header.source_port_isolate_id_u.share1.ptp_offset_type)
                {
                    mac_msg.timestamp_offset = p_ms_net_tx->ptp_offset + 40;
                }
                else
                {
                    mac_msg.timestamp_offset = p_ms_net_tx->ptp_offset + 36; /* PTPv2 highest 2 bytes is ignored */
                }
            }
            else // PTP TC
            {
                cm_uint64_t tmp_64_a, tmp_64_b;
                cm_get_ptp_timestamp_in_header(&cm_packet_header,&ts_63_to_32,&ts_31_to_0);
                tmp_64_a.low_31_0 = ts_31_to_0;
                tmp_64_a.high_63_32 = ts_63_to_32;

                tmp_64_b.low_31_0 = egress_latency & 0xFFFF;
                tmp_64_b.high_63_32 = 0;

                mac_msg.timestamp = cm_sub64(tmp_64_a, tmp_64_b);

                mac_msg.timestamp_offset = p_ms_net_tx->ptp_offset + 8;
            }
        }

        mac_msg.is_ptp_offset = !(cm_packet_header.source_port_isolate_id_u.share1.ptp_offset_type >> 1);
    }

    /* add by shenhg */
    if(to_sgmac)
    {
        cmd = DRV_IOR(NetTxSgmacPriorityMapTable_t, DRV_ENTRY_FLAG);
        index = pkt_info->priority<<2 | pkt_info->color;
        DRV_IF_ERROR_RETURN(CM_IOCTL(ipkt->chip_id, index, cmd, &net_tx_sgmac_priority_map_table));
        mac_msg.tc = net_tx_sgmac_priority_map_table.tc;
        mac_msg.dp = net_tx_sgmac_priority_map_table.dp;
    }

    /* adaptive calling to re use old code */
    ret = sim_epe_create_output(ipkt, &qpkt);
    if (DRV_E_NONE != ret)
    {
        CMODEL_DEBUG_OUT_INFO(" create_epe_output error!\n");
        return ret;
    }

    INIT_LIST_HEAD(out_pkt_list);

    if (pkt_info->tmp_complete_discard)
    {
        sal_free(qpkt.pkt);
        qpkt.pkt = NULL;
        return DRV_E_NONE;
    }

    exception_vector = bexception->exception_vector;

    /* EGRESS_LOOPBACK & EFRESS_LOG */
    if ((p_ms_net_tx->loopback_en) || exception_vector) /* MsNetTx.loopbackEn */
    {
        /* SendPacketToBufferStore */
        /* packet will be stored in Buffer store if there are egress exception (ELOG) or when destIdDiscard is 1'b0
           (in case of ELOOP, ELOOP channel is 61, please see BSR channel assignment)*/
        eloop_pkt = sal_malloc(sizeof(out_pkt_t));
        if (NULL == eloop_pkt)
        {
            CMODEL_DEBUG_OUT_INFO("ERROR! No memory in EPE NetTX when malloc eloop output packet!\n");
            eloop_pkt->pkt = NULL;
            goto ERROR;
        }
        sal_memset(eloop_pkt, 0, sizeof(out_pkt_t));

        eloop_pkt->pkt = sal_malloc(MTU);
        if (NULL == eloop_pkt->pkt)
        {
            CMODEL_DEBUG_OUT_INFO("ERROR! No memory in EPE NetTX when malloc eloop packet!\n");
            goto ERROR;
        }

        sal_memset(eloop_pkt->pkt, 0, MTU);
        sal_memcpy(eloop_pkt->pkt, qpkt.pkt, MTU);

        eloop_pkt->exception = sal_malloc(sizeof(greatbelt_exception_info_t));
        if (NULL == eloop_pkt->exception)
        {
            CMODEL_DEBUG_OUT_INFO("No memory in EPE NetTX!\n");
            goto ERROR;
        }
        sal_memset(eloop_pkt->exception, 0, sizeof(greatbelt_exception_info_t));
        eloop_pkt->chan_id = E_LOOPBACK_CHANID;
        eloop_pkt->chip_id = qpkt.chip_id;
        eloop_pkt->local_phy_port = qpkt.local_phy_port;
        eloop_pkt->pkt_id = qpkt.pkt_id;
        eloop_pkt->packet_length = qpkt.packet_length;
        sal_memcpy(eloop_pkt->module_bus.packet_header, pkt_info->bheader, GREAT_BELT_HEADER_LEN);
        sal_memcpy(eloop_pkt->exception, pkt_info->bexception, sizeof(greatbelt_exception_info_t));
        eloop_pkt->dest_queue = SIM_FWD_Q;

        list_add_tail(&eloop_pkt->head, out_pkt_list);
    }

    if (p_ms_net_tx->mac_valid)
    {
        /* re-calculate the crc */
        ctcutil_crc32(0xFFFFFFFF, qpkt.pkt, (qpkt.packet_length - 4), &crc);
        swap32(&crc, 1, HOST_TO_NETWORK);
        total_len = qpkt.packet_length;
        qpkt.pkt[total_len - 4] = (crc >> 24) & 0xFF;
        qpkt.pkt[total_len - 3] = (crc >> 16) & 0xFF;
        qpkt.pkt[total_len - 2] = (crc >> 8) & 0xFF;
        qpkt.pkt[total_len - 1] = crc & 0xFF;

        /* output the pkt into file */
        ret = sim_output_packet(qpkt.pkt, qpkt.packet_length, qpkt.chip_id, qpkt.chan_id);
        if (DRV_E_NONE != ret)
        {
            CMODEL_DEBUG_OUT_INFO("ERROR! EPE output packet error! ret = %d\n", ret);
        }

        out_pkt = sal_malloc(sizeof(out_pkt_t));
        if (NULL == out_pkt)
        {
            CMODEL_DEBUG_OUT_INFO("ERROR! No memory in EPE NetTX!\n");
            goto ERROR;
        }

        sal_memset(out_pkt, 0, sizeof(out_pkt_t));

        out_pkt->pkt = sal_malloc(MTU);
        if (NULL == out_pkt->pkt)
        {
            CMODEL_DEBUG_OUT_INFO("ERROR! No memory in EPE NetTX!\n");
            goto ERROR;
        }
        sal_memset(out_pkt->pkt, 0, MTU);
        sal_memcpy(out_pkt->pkt, qpkt.pkt, qpkt.packet_length);

        out_pkt->exception = sal_malloc(sizeof(greatbelt_exception_info_t));
        if (NULL == out_pkt->exception)
        {
            CMODEL_DEBUG_OUT_INFO("ERROR! No memory in EPE netTX!\n");
            goto ERROR;
        }
        sal_memset(out_pkt->exception, 0, sizeof(greatbelt_exception_info_t));

        out_pkt->chan_id = qpkt.chan_id;
        out_pkt->chip_id = qpkt.chip_id;
        out_pkt->local_phy_port = qpkt.local_phy_port;
        out_pkt->pkt_id = qpkt.pkt_id;
        out_pkt->packet_length = qpkt.packet_length;
        out_pkt->dest_queue = SIM_NETTX_Q;
        sal_memcpy(&(out_pkt->mac_msg), &mac_msg, sizeof(mac_message_type_t));
        sal_memcpy(&out_pkt->module_bus, &qpkt.module_bus, sizeof(qpkt.module_bus));

        list_add_tail(&out_pkt->head, out_pkt_list);
    }

    /* MAC_RX (MacRx process) */

    /* MAC_TX (MacTx process)*/

    /* CPU Mac section (CPU MacTx process) */

    /* HCGIG_HEADER_GENERATION(MacTx process) */

    if (qpkt.pkt)
    {
        sal_free(qpkt.pkt);
        qpkt.pkt = NULL;
    }
    return DRV_E_NONE;

ERROR:
    if (eloop_pkt != NULL)
    {
        if (eloop_pkt->pkt != NULL)
        {
            sal_free(eloop_pkt->pkt);
            eloop_pkt->pkt = NULL;
        }
        if (eloop_pkt->exception != NULL)
        {
            sal_free(eloop_pkt->exception);
            eloop_pkt->exception = NULL;
        }
        sal_free(eloop_pkt);
        eloop_pkt = NULL;
    }

    if (out_pkt != NULL)
    {
        if (out_pkt->pkt != NULL)
        {
            sal_free(out_pkt->pkt);
            out_pkt->pkt = NULL;
        }
        if (out_pkt->pkt != NULL)
        {
            sal_free(out_pkt->exception);
            out_pkt->exception = NULL;
        }
        sal_free(out_pkt);
        out_pkt = NULL;
    }
    return DRV_E_NO_MEMORY;

}

